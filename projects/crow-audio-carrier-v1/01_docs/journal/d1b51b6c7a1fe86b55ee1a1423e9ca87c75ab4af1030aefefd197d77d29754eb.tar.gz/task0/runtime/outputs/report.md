# Recorded canonical attempt

- qualify: rc=0, 19.523246s; full raw output execution.log
- normal: rc=2, 91.395724s; full raw output execution.log
- public-continuation: rc=1, 3.882703s; full raw output execution.log
- Authored input hashes: 593/593
- All generated identities are in execution.json.
- Stop at the last actual recorded gate. No routing or release acceptance.
