from pathlib import Path,PurePosixPath
import json,tarfile,hashlib,shutil
s=Path(__file__).parent;o=s.parent/'outputs'
for name in ['report.md','evidence.json','result.json']:
 shutil.copyfile(o/name,s/('final-'+name))
exclude={'seal.log','seal-runtime.json','verify-seal.log','verify-seal-runtime.json','verify-seal-command.json'}
paths=[]
for f in sorted(s.rglob('*')):
 assert not f.is_symlink(),f
 if f.is_file() and f.name not in exclude:
  assert not f.name.endswith(('.tar','.tar.gz','.tgz')),f
  paths.append(f)
archive=o/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for f in paths:t.add(f,arcname=f.relative_to(s).as_posix(),recursive=False)
rows=[];seen=set()
with tarfile.open(archive,'r:gz') as t:
 for m in t.getmembers():
  assert m.isfile() and not m.issym() and not m.islnk(),m.name
  q=PurePosixPath(m.name);assert not q.is_absolute() and '..' not in q.parts and m.name not in seen,m.name
  seen.add(m.name)
  data=t.extractfile(m).read();assert len(data)==m.size
  original=s/m.name;assert data==original.read_bytes()
  rows.append({'path':m.name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
assert len(rows)==len(paths)
b=archive.read_bytes();manifest={'archive_sha256':hashlib.sha256(b).hexdigest(),'archive_size':len(b),'member_count':len(rows),'members':rows}
(o/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='members'}))
