review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_supply_mountedframe1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

Limited group coverage: U_AUDIO, U_BUCK, U_PWR only. All commissioned instances PASS. No whole-board acceptance; immutable hashes above are supplied metadata, not independently reviewed whole-board conclusions.

Scope and method

Fresh agent /root/rj45_pin_carrier_supply_mountedframe1. Engineering inputs restricted to supplied protocol, dossiers, exact selected primary PDFs. No live design, schematic, project history or external datasheets read. Dossier embedded verification notes were not used as evidence.
All three front-mounted at 0 degrees: native board minus component center equals component-top (+x right,+y down). No reflection or rotation needed when comparing explicit manufacturer TOP VIEW. TPS mechanical underside drawing converted to top by y reflection only as crosscheck; never mirror the dossier.
Pin-to-net category sanity from native dossier net labels and the visible inter-instance PWR_EN connection. Component values, whole-net endpoint census, decoupling, pullup values, threshold math, timing, routing and assembly process are not verified by this pin-only commission. No whole-board acceptance.

Primary documents (exact frozen bytes)
- projects/crow-audio-carrier-v1/02_parts/AP63205WU-7/AP63205_DS41326_Rev3-2.pdf; SHA256 ef99daa3789d835bc025dfcb4c605c5c2e6d3e7223e86d40b33e6b497ea5a722; 1226090 bytes.
- projects/crow-audio-carrier-v1/02_parts/TPS389001DSER/TPS3890_SLVSD65A.pdf; SHA256 ee79599730e7606ba9718d9820b411020e3dcd9ff7d44572f8ee63fead15b9d0; 1203677 bytes.

U_AUDIO — VERDICT: PASS

Measured native pads: 6; unique numbered pads: 6; independently expected and observed physical identities: 6; exposed pads: expected 0, observed 0; fused lands: 0; aliases: 0.
Primary: TPS3890 SLVSD65A SHA256 ee79599730e7606ba9718d9820b411020e3dcd9ff7d44572f8ee63fead15b9d0, PDF p3 DSE Top View/Pin Functions, p24 DSE0006A Package Outline and p25 Example Board Layout (4220552/B), p12 Figure23 and p13 Figure24; supporting p4 operating range and p19 exact TPS389001DSER package entry.
Expected pin1 upper left, left 1/2/3 downward, right 6/5/4 downward, CCW, three terminals per side, no EP. Observed exact order and pin1=(-0.55,-0.5). Six isolated lands match example: pin1 0.8x0.25mm, others 0.7x0.25mm; left outside edges align at -0.95mm, other centers x=±0.6mm and y pitch=0.5mm. The longer pin1 land is an identity feature, not an exposed pad or fused alias.
Measured signed double area in x-right/y-down frame: -2.375 mm² (negative means CCW). Maximum native-to-component-top translation residual 2.89e-15 mm. Expected versus observed pin rows:
- U_AUDIO pin 1 (SENSE): expected Monitored-voltage sense node (adjustable 1.15V threshold); observed ADC_SENSE — PASS at pin/net-kind scope.
- U_AUDIO pin 2 (GND): expected Ground; observed GND — PASS at pin/net-kind scope.
- U_AUDIO pin 3 (MR_N): expected Active-low manual reset control, or VDD when unused; observed PWR_EN — PASS at pin/net-kind scope.
- U_AUDIO pin 4 (VDD): expected Supply rail 1.5 to 5.5V; observed 5V_LDO_HOLD — PASS at pin/net-kind scope.
- U_AUDIO pin 5 (CT): expected Dedicated timing-capacitor node; observed AUDIO_CT — PASS at pin/net-kind scope.
- U_AUDIO pin 6 (RESET_N): expected Active-low open-drain reset/control output; observed AUDIO_EN — PASS at pin/net-kind scope.

U_BUCK — VERDICT: PASS

Measured native pads: 6; unique numbered pads: 6; independently expected and observed physical identities: 6; exposed pads: expected 0, observed 0; fused lands: 0; aliases: 0.
Primary: DS41326 Rev.3-2 SHA256 ef99daa3789d835bc025dfcb4c605c5c2e6d3e7223e86d40b33e6b497ea5a722, PDF p1 Pin Assignments, p2 Figure1 and Pin Descriptions, p17 TSOT26 outline/land figures; supporting p12 section9 and p16 ordering table.
Expected pin1 upper left, left 1/2/3 downward, right 6/5/4 downward, CCW, three pins per side, 0.95mm pitch and no EP. Observed component-top pin1=(-1.1375,-0.95), W 1/2/3 and E 6/5/4 with exactly that pitch and CCW. The native land pattern uses 1.32x0.6mm lands at x=±1.1375; manufacturer suggested lands (rotated) are 1.0x0.7mm at x=±1.1. These are not identical recommendations, but preserve isolated physical terminal identity and lead landing, with no pin-map defect.
Measured signed double area in x-right/y-down frame: -8.645 mm² (negative means CCW). Maximum native-to-component-top translation residual 2.89e-15 mm. Expected versus observed pin rows:
- U_BUCK pin 1 (FB): expected Fixed AP63205 5V output sense, direct connection to regulated output per Figure 1; observed 5V_BUCK — PASS at pin/net-kind scope.
- U_BUCK pin 2 (EN): expected Enable may connect to VIN for automatic startup; observed 12V_BUCK_IN — PASS at pin/net-kind scope.
- U_BUCK pin 3 (VIN): expected Power input 3.8 to 32V; observed 12V_BUCK_IN — PASS at pin/net-kind scope.
- U_BUCK pin 4 (GND): expected Power ground; observed GND — PASS at pin/net-kind scope.
- U_BUCK pin 5 (SW): expected Switch-node net feeding output filter; observed BUCK_SW — PASS at pin/net-kind scope.
- U_BUCK pin 6 (BST): expected Bootstrap supply node, capacitor referenced to SW; observed BUCK_BST — PASS at pin/net-kind scope.

U_PWR — VERDICT: PASS

Measured native pads: 6; unique numbered pads: 6; independently expected and observed physical identities: 6; exposed pads: expected 0, observed 0; fused lands: 0; aliases: 0.
Primary: TPS3890 SLVSD65A SHA256 ee79599730e7606ba9718d9820b411020e3dcd9ff7d44572f8ee63fead15b9d0, PDF p3 DSE Top View/Pin Functions, p24 DSE0006A Package Outline and p25 Example Board Layout (4220552/B), p12 Figure23 and p13 Figure24; supporting p4 operating range and p19 exact TPS389001DSER package entry.
Expected pin1 upper left, left 1/2/3 downward, right 6/5/4 downward, CCW, three terminals per side, no EP. Observed exact order and pin1=(-0.55,-0.5). Six isolated lands match example: pin1 0.8x0.25mm, others 0.7x0.25mm; left outside edges align at -0.95mm, other centers x=±0.6mm and y pitch=0.5mm. The longer pin1 land is an identity feature, not an exposed pad or fused alias.
Measured signed double area in x-right/y-down frame: -2.375 mm² (negative means CCW). Maximum native-to-component-top translation residual 2.89e-15 mm. Expected versus observed pin rows:
- U_PWR pin 1 (SENSE): expected Monitored-voltage sense node (adjustable 1.15V threshold); observed PWR_SENSE — PASS at pin/net-kind scope.
- U_PWR pin 2 (GND): expected Ground; observed GND — PASS at pin/net-kind scope.
- U_PWR pin 3 (MR_N): expected Active-low manual reset control, or VDD when unused; observed 5V_LDO_HOLD — PASS at pin/net-kind scope.
- U_PWR pin 4 (VDD): expected Supply rail 1.5 to 5.5V; observed 5V_LDO_HOLD — PASS at pin/net-kind scope.
- U_PWR pin 5 (CT): expected Dedicated timing-capacitor node; observed PWR_CT — PASS at pin/net-kind scope.
- U_PWR pin 6 (RESET_N): expected Active-low open-drain reset/control output; observed PWR_EN — PASS at pin/net-kind scope.

Pairwise symmetry — PASS

All six functions/positions/sizes identical. U_PWR MR_N=5V_LDO_HOLD (same as VDD); U_PWR RESET_N=PWR_EN directly shares U_AUDIO MR_N=PWR_EN. Sense, CT and output nets remain instance-specific. This variation is explicitly compatible with TPS3890 p12 Figure23 and section8.3.2; it is not a function swap.

Unresolved findings: none within this limited pin-review commission. Electrical network values and endpoint implementation are outside the supplied dossier scope and are not certified here.

Evidence: evidence.json contains exact envelope subject, per-pin findings and all measured native rows. evidence.tar.gz retains the inspected figure images, native dossier copies, independent derivation, measurement script/results, source digest verification, commands/methods and subprocess logs/runtime. evidence-manifest.json inventories and hashes every regular archive member.
