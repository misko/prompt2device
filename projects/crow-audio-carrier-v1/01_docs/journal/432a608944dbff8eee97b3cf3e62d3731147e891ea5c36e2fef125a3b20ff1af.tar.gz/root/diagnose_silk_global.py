from pathlib import Path
import sys,json,math,copy,collections,time
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent/'silk-global-diagnosis';D.mkdir(exist_ok=True)
sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'))
import pcbnew,yaml
from generate_board_generic import BoardBuilder,box_of,hit,MM,silk_stroke,REFDES_STROKE_OVER_SIZE,REFDES_STROKE_MIN
cfg=yaml.safe_load((P/'03_src/floorplan.yaml').read_text());B=BoardBuilder(copy.deepcopy(cfg),P,D/'candidate.kicad_pcb');B.board=pcbnew.LoadBoard(str(P/'04_kicad/crow_audio_carrier_v1.kicad_pcb'));B.fps={f.GetReference():f for f in B.board.GetFootprints()};B.hole_refs={r for r in B.fps if r.startswith(('H','FID'))};B._own_cent=[(r,MM(f.GetPosition().x),MM(f.GetPosition().y)) for r,f in sorted(B.fps.items()) if r not in B.hole_refs]
# Only a bounded scratch geometry/label feasibility experiment. No source, route, waiver, or live edits.
class Index:
 def __init__(self,rects=()):
  self.cells=collections.defaultdict(list)
  for c in rects:self.add(c)
 def keys(self,c):
  for x in range(math.floor(c[0]/5),math.floor(c[2]/5)+1):
   for y in range(math.floor(c[1]/5),math.floor(c[3]/5)+1):yield(x,y)
 def add(self,c):
  for k in self.keys(c):self.cells[k].append(c)
 def collision(self,c):return any(hit(c,o) for k in self.keys(c) for o in self.cells[k])
pads,silk=B._obstacles(.16);captions=[]
# Put channel captions in clear strips analogous to already accepted CH3. Validate, never infer clear.
for g in B.board.GetDrawings():
 if g.GetClass()=='PCB_TEXT' and g.IsOnLayer(pcbnew.F_SilkS):
  if g.GetText().startswith('CH') and g.GetText()[2:].isdigit():
   n=int(g.GetText()[2:]);g.SetPosition(pcbnew.VECTOR2I_MM(36+32*((n-1)%4),34 if n<=4 else 106))
  c=box_of(g.GetBoundingBox(),.08);silk.append(c);captions.append({'text':g.GetText(),'box':c,'body_or_pad_collision':any(hit(c,o) for o in pads)})
# Human-operated references remain fixed. Other refdes get a simultaneous new allocation.
fixed=[];movable=[]
for r,f in B.fps.items():
 if r in B.hole_refs:continue
 if r.startswith(('J','F','U','Q','TP')) and f.Reference().IsVisible():fixed.append(r);silk.append(box_of(f.Reference().GetBoundingBox(),.08))
 else:movable.append(r)
static=Index(pads+silk);slots={};start=time.monotonic()
for r in movable:
 f=B.fps[r];t=f.Reference();fx,fy=MM(f.GetPosition().x),MM(f.GetPosition().y);choices=[]
 for rot in [0,90]:
  t.SetPosition(pcbnew.VECTOR2I_MM(fx,fy));t.SetTextAngleDegrees(rot);t.SetTextSize(pcbnew.VECTOR2I_MM(.7,.7));t.SetTextThickness(pcbnew.FromMM(silk_stroke(.7,B.silk_floors()[1],REFDES_STROKE_OVER_SIZE,REFDES_STROKE_MIN)));rel=box_of(t.GetBoundingBox());rel=[rel[0]-fx,rel[1]-fy,rel[2]-fx,rel[3]-fy]
  for iy in range(-30,31):
   for ix in range(-30,31):
    x,y=fx+ix*.5,fy+iy*.5;c=(x+rel[0],y+rel[1],x+rel[2],y+rel[3])
    if not B._in_frame(c) or static.collision(c):continue
    owned,a,b,other=B._ownership(c,r);choices.append((not owned,max(a-b,0),a,rot,x,y,c,other,b))
 choices.sort();slots[r]=choices
 print(r,len(choices),flush=True)
occupied=Index();rows=[]
for r in sorted(movable,key=lambda r:(len(slots[r]),-len(r),r)):
 candidates=[x for x in slots[r] if not occupied.collision(x[6])];best=candidates[0] if candidates else None;t=B.fps[r].Reference()
 if best:
  _,deficit,a,rot,x,y,c,other,b=best;t.SetPosition(pcbnew.VECTOR2I_MM(x,y));t.SetTextAngleDegrees(rot);t.SetVisible(True);occupied.add((c[0]-.08,c[1]-.08,c[2]+.08,c[3]+.08))
 else:t.SetVisible(False)
 rows.append({'ref':r,'candidate_count':len(slots[r]),'at':None if not best else [best[4],best[5]],'rot':None if not best else best[3],'ownership_deficit':None if not best else best[1]})
result={'fixed':len(fixed),'reallocated':sum(x['at'] is not None for x in rows),'unplaced':[x['ref'] for x in rows if not x['at']],'rows':rows,'captions':captions,'elapsed_s':time.monotonic()-start,'limits':'Diagnostic label arrangement only. Current source min size .55 deliberately not used; all reallocated labels .7mm. No gate, ownership exception or source acceptance.'};(D/'result.json').write_text(json.dumps(result,indent=2)+'\n');pcbnew.SaveBoard(str(D/'candidate.kicad_pcb'),B.board);print(json.dumps({k:v for k,v in result.items() if k not in ('rows','captions')}))
