from pathlib import Path
import sys,json,math,copy
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent/'silk-source-diagnosis';D.mkdir(exist_ok=True)
sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'))
import pcbnew,yaml
from generate_board_generic import BoardBuilder,box_of,hit,MM,silk_stroke,REFDES_STROKE_OVER_SIZE,REFDES_STROKE_MIN
cfg=yaml.safe_load((P/'03_src/floorplan.yaml').read_text());B=BoardBuilder(copy.deepcopy(cfg),P,D/'candidate.kicad_pcb');B.board=pcbnew.LoadBoard(str(P/'04_kicad/crow_audio_carrier_v1.kicad_pcb'));B.fps={f.GetReference():f for f in B.board.GetFootprints()};B.hole_refs={r for r in B.fps if r.startswith(('H','FID'))};B._own_cent=[(r,MM(f.GetPosition().x),MM(f.GetPosition().y)) for r,f in sorted(B.fps.items()) if r not in B.hole_refs]
# Strictly diagnostic: current visible labels are obstacles, no live artifact writes.
pads,silk=B._obstacles(.16)
for g in B.board.GetDrawings():
 if g.GetClass()=='PCB_TEXT' and g.IsOnLayer(pcbnew.F_SilkS):silk.append(box_of(g.GetBoundingBox(),.08))
for f in B.board.GetFootprints():
 if f.Reference().IsVisible():silk.append(box_of(f.Reference().GetBoundingBox(),.08))
rows=[]
for r in json.loads((P/'04_kicad/refdes_waiver.json').read_text()):
 f=B.fps[r];t=f.Reference();fx,fy=MM(f.GetPosition().x),MM(f.GetPosition().y);choices=[]
 for rot in [0,90]:
  t.SetTextAngleDegrees(rot);t.SetTextSize(pcbnew.VECTOR2I_MM(.7,.7));t.SetTextThickness(pcbnew.FromMM(silk_stroke(.7,B.silk_floors()[1],REFDES_STROKE_OVER_SIZE,REFDES_STROKE_MIN)))
  # Finite .25mm diagnostic census, no acceptance or blind iterative generation.
  for iy in range(-44,45):
   for ix in range(-44,45):
    x,y=fx+ix*.25,fy+iy*.25;t.SetPosition(pcbnew.VECTOR2I_MM(x,y));c=box_of(t.GetBoundingBox())
    if not B._in_frame(c) or any(hit(c,o) for o in pads) or any(hit(c,o) for o in silk):continue
    owned,a,b,other=B._ownership(c,r);choices.append({'at':[x,y],'rot':rot,'owned':owned,'own_mm':a,'other_mm':b,'other_ref':other,'box':c})
 choices.sort(key=lambda c:(not c['owned'],max(c['own_mm']-c['other_mm'],0),c['own_mm']))
 if choices:
  best=choices[0];t.SetPosition(pcbnew.VECTOR2I_MM(*best['at']));t.SetTextAngleDegrees(best['rot']);t.SetVisible(True);silk.append(best['box'])
 else:t.SetVisible(False);best=None
 rows.append({'ref':r,'legal_slots':len(choices),'owned_slots':sum(x['owned'] for x in choices),'best':best});print(json.dumps(rows[-1]),flush=True)
(D/'slots.json').write_text(json.dumps(rows,indent=2)+'\n');pcbnew.SaveBoard(str(D/'candidate.kicad_pcb'),B.board)
print(json.dumps({'printed':sum(x['best'] is not None for x in rows),'owned':sum(bool(x['best'] and x['best']['owned']) for x in rows),'unplaced':[x['ref'] for x in rows if not x['best']]}))
