from pathlib import Path
import tarfile,io,json,hashlib,shutil
from datetime import datetime,timezone
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911');sha=lambda b:hashlib.sha256(b).hexdigest();files={}
for prefix in ['current-placement-review-gate','current-placement-input-checkpoint','current-placement-handoff','current-placement-contracts','silk-slot-diagnosis','silk-global-diagnosis']:
 for f in I.glob(prefix+'*'):
  if f.is_file():files['logs/'+f.name]=f
for n in ['diagnose_silk_slots.py','diagnose_silk_global.py','current-placement-preservation-result.json','preserve_placement_closeout.py']:
 files['root/'+n]=D/n
for folder in ['silk-source-diagnosis','silk-global-diagnosis']:
 for f in (D/folder).rglob('*'):
  if f.is_file():files['root/'+f.relative_to(D).as_posix()]=f
m={n:{'sha256':sha(f.read_bytes()),'size':f.stat().st_size} for n,f in files.items()};tmp=D/'placement-closeout.tar.gz'
with tarfile.open(tmp,'w:gz',compresslevel=3) as t:
 for n,f in files.items():t.add(f,arcname=n,recursive=False)
 b=(json.dumps({'members':m},indent=2)+'\n').encode();z=tarfile.TarInfo('MANIFEST.json');z.size=len(b);t.addfile(z,io.BytesIO(b))
h=sha(tmp.read_bytes());out=P/'01_docs/journal'/(h+'.tar.gz');assert not out.exists();shutil.copyfile(tmp,out)
with tarfile.open(out) as t:
 for n,r in m.items():b=t.extractfile(n).read();assert sha(b)==r['sha256'] and len(b)==r['size']
with (P/'01_docs/journal/contracts.md').open('a') as f:f.write(f'\n\n## Allowed current placement closeout and label diagnosis\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Root current placement audit/closure raw failures and corrections, two bounded scratch-only label arrangements, exact scripts/results and input checkpoint; no layout or source repair acceptance |\n')
with (P/'01_docs/journal/schematic.md').open('a') as f:f.write(f'\n- Closeout {datetime.now(timezone.utc).isoformat()}: sourcecheckpoint575/575unchanged; handoff6417bytes valid. Contracts firstfailed on newdatedrender filename missing the source field; renamed the uncommitted exact-byte review to2026-09-11_0d80ee92_independent_render.md withinexistingcontract. No reviewtext, gate or ratchet changed. Correctedaudit17401files,2873existingdebt/26unitsheld,0strays. Rawbothfailures/corrections and2scratchlabeldiagnoses archived/reopened in {h}.tar.gz ({out.stat().st_size}bytes,{len(m)}payloadmembers). CanonicalPR-REVIEWremainsFAIL2findings; this records completed placement generation and complete failedjudgment, not placement acceptance.\n')
print(json.dumps({'archive':str(out),'size':out.stat().st_size,'members':len(m)}))
