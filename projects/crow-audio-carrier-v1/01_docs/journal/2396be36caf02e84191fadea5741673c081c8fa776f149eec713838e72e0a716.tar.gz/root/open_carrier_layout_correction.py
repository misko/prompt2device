from pathlib import Path
from datetime import datetime, timezone, timedelta
import sys, json, hashlib, shutil, tempfile
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901'); N=Path(__file__).parent
P=R/'projects/crow-audio-carrier-v1'; name='rj45-carrier-layout-correction1'
assert not (N/(name+'-opened.json')).exists()
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput, subject_identity
from pipeline_runtime import open_agent_attempt
D=Path(tempfile.mkdtemp(prefix=name+'-'))
cp=json.loads((P/'06_build/checkpoints/prelayout-inputs.json').read_text())
paths={R/k.removeprefix('repo:') for k in cp['files']}
for folder in ['skills/pcb-design/scripts','skills/kicad-pcb/scripts','skills/jlcpcb-fab/scripts']:
 paths.update((R/folder).glob('*.py'))
for rel in ['CLAUDE.md','skills/pcb-design/SKILL.md','skills/kicad-pcb/SKILL.md','skills/pcb-design/references/execution-runtime.md','skills/pcb-design/references/lifecycle-and-backtrack.md','skills/kicad-pcb/references/design-policies.md','skills/kicad-pcb/references/source-to-prep-authority.md','skills/kicad-pcb/references/placement-and-proximity.md','skills/kicad-pcb/references/layout-precedents.md','skills/kicad-pcb/references/route-ownership.md']:
 paths.add(R/rel)
paths.update((P/'01_docs/decisions').glob('*.md'))
paths.update((P/'04_kicad').glob('*.kicad_*'))
paths.update((P/'06_build/route').glob('r0.kicad_*'))
paths.update((P/'06_build/netlists').glob('*.net'))
for rel in ['01_docs/STATUS.md','01_docs/findings.yaml','06_build/checkpoints/prelayout-inputs.json','03_src/rules/integration.yaml']:
 paths.add(P/rel)
for p in sorted(paths):
 assert p.is_file() and not p.is_symlink(),p
 q=D/'input'/p.relative_to(R);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for kind in ['primary','adc','policy']:
 task='rj45-carrier-layout-gap-'+kind+'1'; meta=json.loads((N/(task+'-opened.json')).read_text()); close=json.loads((N/(task+'-closeout-summary.json')).read_text());assert close['delivery_status']=='PASS'
 q=D/'findings'/kind;q.mkdir(parents=True)
 for fn in ['report.md','evidence.json','evidence-manifest.json','evidence.tar.gz']:
  shutil.copy2(Path(meta['output_dir'])/fn,q/fn)
 shutil.copy2(N/(task+'-closeout-summary.json'),q/'closeout.json')
shutil.copy2('/tmp/carrier-locator-implementation-availability-6c_4vwal/preflight.py',D/'preflight.py')
now=datetime.now(timezone.utc);cut=now+timedelta(minutes=30);hard=now+timedelta(minutes=40)
(D/'TASK.md').write_text(f'''# Carrier coherent source correction after completed layout reviews

Root remains sole live writer. You own only isolated scratch candidates; frozen input/ and findings/ are read-only. No live repo edits, Git mutations, release changes, children, reviewer self-acceptance, full conductor or routing search. Read CLAUDE, skill/runtime and named canon, then the three complete findings reports. Fresh source author, exact current source packet. Two coherent candidate revisions maximum, zero replacement, no reset of any earlier investigation or candidate count. Stop on repeated non-improvement. Work cutoff {cut.isoformat()}; hard {hard.isoformat()}. Reserve time for final packaging.

Fix this complete coherent set through owning source, preserving manufacturer parts, electrical graph, component count, connector pose/pin/mate/cable/model/approval geometry, all copper/clearance/ampacity/proximity thresholds and first-article boundaries:
1. ADC-VMID-RETURN-01: four capacitor GND pads directly overlap broad F.Cu by0.574948620474mm² each; intended nearest-GND_A seed trees are bypassed. Source-own bounded pour/via reservations and, only if causally needed, local return seed adjustments so each VMID bank reaches its own nearest GND_A junction before general plane access. Preserve individual GND_A6/8 and GND_D30 plane drops and no surface paddle shortcut. Prove on regenerated+prepared+filled native copper, graph cut of designated junction/drop, not net-name equality or zero opens. Do not isolate general ground planes or add an invented all-layer moat. Read the exact primary Figure10 wording and provide explicit source decision reconciling ambiguous digital-cutout applicability; never silently rewrite deprecated to duplicated. FILT feed-after-bulk routing remains owed; no gratuitous bulk relocation or new FILTN resistor.
2. POL-01: move only eight existing CH1..CH8 labels into proper jack ownership under unchanged mixed-side P-SILK-OWN, with legibility/ink clearance. No duplicates/side waiver/checker edit.
3. POL-02: smallest one-ref R_PWR_PU pose correction to actual copper gap <=2.5mm, with margin. Reviewer diagnostic [32.4,53.92,90] gives2.492242mm but is not accepted. Native rounded-copper metric governs; recheck local clearance/adjacency and unchanged remaining poses.
4. POL-03: complete source integration.yaml U_BUCK complexity-weighted module decision and correct full external-support inventory. Remove U_ADC itself from ADC external supports; enumerate complete current support boundary honestly. Threshold10 governs complete inventory, never a selected subset. Existing primary/architecture evidence may support decision; any missing source needed must be explicitly reported. No imposed architecture/part change or stock research. A new ADR or append explicit decision to existing appropriate ADR is allowed; maintain contracts for any new name.
5. The preceding native prepared12 starved thermals and2 GND opens have exact identities. Within this same source batch, address the12 actual one-spoke pads through existing exact per-pad zone-connection source mechanism if independently justified (no global2-spoke requirement relaxation): C_ADC_CM4P.2,C_ADC_CM4N.2,C_ISO1..8.2,U_LDO_EN.3,C_VDDA1_10N.2. Respect new VMID return reservations and quiet-cell paths. The2 GND opens U_PWR.2/R_PWR_BOT.2 and U_AUDIO.2 may remain declared route obligations; do not fabricate closure or modify routed artifact in place.

Allowed proposed source files: project03_src/floorplan.yaml,03_src/route.yaml ONLY causal local return seed correction if needed,03_src/rules/integration.yaml, corresponding project01_docs/decisions/*.md and nearest contracts.md if needed; exact TPS389001DSER part.yaml measurement-method prose only if needed to remove misleading bbox authority, without threshold/schema change. No shared tool/skill/checker or other source changes. Additional needed change requires concrete handback, not silent expansion.

Create complete disposable candidate project from frozen input using existing generators/prepare APIs and unchanged methods. A source proof is not normal project gate acceptance. Use pipeline_runtime.run_stage with explicit cwd/environment and finite deadlines for all substantive native/check processes. Keep all prior candidate bytes/logs. Reopen/hash-check selected old evidence archive members only; don't nest old archives in new archive. Native DRC must preserve and classify EVERY violation/open/parity row; inherited raw-row classifications may be reused only after full native identity verification. Native matrix should compare current/r0 and candidate: all333 poses except explicit resistor, parts/pads/nets/side, all seeded copper, actual filled VMID dominance, GND drop/paddle paths, thermal identities, entire silk policy and all affected adjacency. Existing full-review remaining route/first-article claims stay explicit. Inspect actual resulting top silk image and relevant copper views.

Five declared outputs: report.md,evidence.json,evidence-manifest.json,evidence.tar.gz,result.json. Evidence domain_result is CANDIDATE_READY, DEFECTIVE or INCOMPLETE; author never grants independent SOUND. Record exact source pre/post hashes and full candidate history. Archive source_candidate/<repo-relative paths>, beforeimages, methods, raw native evidence, actual views and runtime (no symlinks/traversal/duplicate names/recursive archives). Manifest archive_sha256/archive_size/member_count/members(path,size,sha256), reopen every member. result exact envelope subject/checks evidence-complete,inputs-verified,review-complete PASS only for honest complete delivery. Provided preflight.py after packaging; actual FINAL before cutoff, no claim of source adoption or later release gates. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.
''')
items=[]
for p in sorted(D.rglob('*')):
 if p.is_file():
  b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(D).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
s=subject_identity('carrier_layout_source_correction',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
e=TaskEnvelope(schema=2,task_id=name,stage_id='KICAD-PLACEMENT',run_id=name,subject=s,executor='agent',execution_class='local',recommended_agent_role='authoring',agent_role='authoring',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=2,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']})
o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),agent_id='/root/carrier_rj45_layout_correction1',work_cutoff=cut.isoformat());(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2));print(len(items),'frozen inputs')
