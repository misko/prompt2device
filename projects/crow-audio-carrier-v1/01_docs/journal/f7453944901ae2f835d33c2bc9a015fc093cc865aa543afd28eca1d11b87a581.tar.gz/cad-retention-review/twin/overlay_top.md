# Twin render faithfulness — twin_top.png (`--side top`)

board_sha256: 0d80ee923dbbae34995fa892e5fc2224b489e5d4afc1a03dc2a7836c44a31058
a-render_verdict: PASS
- calibration: **6.4357 px/mm** x, **6.4336 px/mm** y, anisotropy **1.0003** (tol 0.02) — orthographic, projection valid
- board edge: 19.950..170.050 x, 19.950..120.050 y mm
- courtyards drawn (F.CrtYd): **340**; footprints with no courtyard on EITHER layer: 0
- **COVERAGE: 84 measured / 333 refs with an expected body** (249 unresolvable, 0 resolvable but NOT measured, 0 with no JLC model at all)
- tolerance: **1.00 mm** on both the centre delta and the outward excursion
- pixel measurement: **populated-minus-same-camera-bare RGB delta** (threshold 12)
- expected-model register: `twin_adjudications.yaml` (9 LCSC transform entries)
- overlay: `twin_top_courtyard_overlay.png`

**Red** = footprint courtyard (what gets fabricated). **Amber** = a ref jlc_twin flagged. **Green** = EXPECTED body (mesh x JLC's own model transform x board placement). **Magenta** = MEASURED body (pixels). **Blue** = board edge.

A body outside its red box with green and magenta AGREEING is a **3D-model** defect with no board exposure — gerbers and CPL derive from pads, never from the model. Green and magenta DISAGREEING is a **render** defect: the picture is not the board, and any visual review done on it is void.

## Graded refs (84)

| ref | LCSC | fit | centre delta mm | outward mm | edge deltas L,T,R,B mm | body px | courtyard excursion mm |
|---|---|---|---|---|---|---|---|
| `C_FILT2_470U` | LOCAL | 0deg @0.00mm | 0.381 | 0.080 | -0.76,-0.08,-0.00,+0.06 | 2393 | 0.000 |
| `C_FILT1_470U` | LOCAL | 0deg @0.00mm | 0.381 | 0.080 | -0.76,-0.06,-0.00,+0.08 | 2401 | 0.000 |
| `D_HOLD` | C85098 | 0deg @0.19mm | 0.316 | 0.000 | +1.36,+0.09,-0.73,-0.07 | 192 | 0.000 |
| `D_BUCK_IN` | C154439 | NONE (best 0.57mm) -> JLC's own transform | 0.315 | 0.089 | -0.09,-0.01,-0.20,-0.55 | 318 | 0.000 |
| `D_IN` | C83846 | 0deg @0.21mm | 0.281 | 0.000 | +0.73,+0.07,-0.17,-0.11 | 465 | 0.000 |
| `U_TDM` | C23654 | 270deg @0.02mm | 0.209 | 0.000 | +0.62,+0.04,-1.00,-0.22 | 82 | 0.002 |
| `U_AFE1` | C2863402 | 270deg @0.13mm | 0.195 | 0.000 | +0.94,+0.11,-1.33,-0.12 | 541 | 0.000 |
| `U_AFE5` | C2863402 | 270deg @0.13mm | 0.195 | 0.000 | +0.94,+0.12,-1.33,-0.11 | 541 | 0.000 |
| `J11` | LOCAL | 0deg @0.00mm | 0.186 | 0.108 | -0.11,+0.04,-0.24,-0.17 | 1608 | 0.000 |
| `C_HOLD1` | LOCAL | 0deg @0.00mm | 0.185 | 0.080 | -0.19,-0.06,+0.56,+0.08 | 2413 | 0.000 |
| `F7` | C3761431 | UNAVAILABLE (no vendor pad comparison) | 0.184 | 0.000 | -0.10,+0.12,-0.27,-0.13 | 486 | 0.000 |
| `J7` | LOCAL | 0deg @0.00mm | 0.182 | 0.071 | -0.07,+0.11,-0.28,-0.19 | 5799 | 0.054 |
| `J3` | LOCAL | 0deg @0.00mm | 0.182 | 0.071 | -0.07,+0.19,-0.28,-0.11 | 5819 | 0.054 |
| `Q_PRE_EN` | C85047 | 180deg @0.20mm | 0.180 | 0.000 | +0.56,+0.03,-0.86,-0.23 | 56 | 0.050 |
| `Q_RST1` | C85047 | 180deg @0.20mm | 0.177 | 0.000 | +0.53,+0.13,-0.89,-0.13 | 56 | 0.050 |
| `J10` | LOCAL | 0deg @0.00mm | 0.175 | 0.108 | -0.11,+0.11,-0.24,-0.10 | 1609 | 0.000 |
| `F8` | C3761431 | UNAVAILABLE (no vendor pad comparison) | 0.175 | 0.000 | -0.09,+0.12,-0.26,-0.13 | 486 | 0.000 |
| `C_A4P` | LOCAL | 0deg @0.00mm | 0.175 | 0.110 | -0.11,+0.09,-0.24,-0.06 | 1233 | 0.000 |
| `C_A8N` | LOCAL | 0deg @0.00mm | 0.175 | 0.110 | -0.11,+0.06,-0.24,-0.09 | 1234 | 0.000 |
| `U_ISO8` | C53283916 | 270deg @0.05mm | 0.174 | 0.000 | -0.05,+0.07,-0.29,-0.16 | 81 | 0.000 |
| `J8` | LOCAL | 0deg @0.00mm | 0.173 | 0.062 | -0.06,+0.11,-0.27,-0.19 | 5820 | 0.054 |
| `J4` | LOCAL | 0deg @0.00mm | 0.173 | 0.062 | -0.06,+0.19,-0.27,-0.11 | 5815 | 0.054 |
| `C_A3N` | LOCAL | 0deg @0.00mm | 0.171 | 0.107 | -0.11,+0.09,-0.23,-0.06 | 1232 | 0.000 |
| `C_A7P` | LOCAL | 0deg @0.00mm | 0.171 | 0.107 | -0.11,+0.06,-0.23,-0.09 | 1233 | 0.000 |
| `U_ISO4` | C53283916 | 270deg @0.05mm | 0.171 | 0.000 | -0.05,+0.01,-0.29,-0.07 | 85 | 0.000 |
| `F3` | C3761431 | UNAVAILABLE (no vendor pad comparison) | 0.170 | 0.000 | -0.09,+0.13,-0.25,-0.12 | 486 | 0.000 |
| `C_A4N` | LOCAL | 0deg @0.00mm | 0.163 | 0.098 | -0.10,+0.09,-0.23,-0.06 | 1233 | 0.000 |
| `C_A8P` | LOCAL | 0deg @0.00mm | 0.163 | 0.098 | -0.10,+0.06,-0.23,-0.09 | 1234 | 0.000 |
| `F4` | C3761431 | UNAVAILABLE (no vendor pad comparison) | 0.161 | 0.000 | -0.08,+0.13,-0.25,-0.12 | 486 | 0.000 |
| `U_RST2` | C123302 | 180deg @0.10mm | 0.157 | 0.000 | +0.67,+0.10,-0.99,-0.14 | 224 | 0.089 |
| `C_OPA_BULK` | C84494 | 0deg @0.05mm | 0.152 | 0.000 | -0.09,+0.02,-0.18,-0.15 | 203 | 0.000 |
| `C_LDO_OUT` | C84494 | 0deg @0.05mm | 0.145 | 0.000 | -0.09,+0.04,-0.18,-0.13 | 204 | 0.000 |
| `U_RST1` | C96333 | 180deg @0.08mm | 0.143 | 0.000 | +0.53,+0.03,-0.74,-0.23 | 58 | 0.021 |
| `U_OE` | C131093 | 180deg @0.20mm | 0.143 | 0.000 | +0.72,+0.04,-0.95,-0.21 | 68 | 0.033 |
| `U_LDO` | C7452883 | 270deg @0.00mm | 0.135 | 0.021 | -0.01,-0.02,-0.21,-0.13 | 326 | 0.000 |
| `U_ISO5` | C53283916 | 270deg @0.05mm | 0.126 | 0.000 | -0.08,+0.07,-0.16,-0.16 | 90 | 0.000 |
| `C_A1P` | LOCAL | 0deg @0.00mm | 0.124 | 0.000 | +0.02,+0.09,-0.26,-0.06 | 1193 | 0.000 |
| `C_A5N` | LOCAL | 0deg @0.00mm | 0.124 | 0.000 | +0.02,+0.06,-0.26,-0.09 | 1194 | 0.000 |
| `U_ISO1` | C53283916 | 270deg @0.05mm | 0.121 | 0.000 | -0.08,+0.01,-0.16,-0.07 | 96 | 0.000 |
| `U_ISO6` | C53283916 | 270deg @0.05mm | 0.117 | 0.000 | -0.07,+0.07,-0.15,-0.16 | 90 | 0.000 |
| `J6` | LOCAL | 0deg @0.00mm | 0.116 | 0.080 | -0.08,+0.11,-0.14,-0.19 | 5747 | 0.054 |
| `J2` | LOCAL | 0deg @0.00mm | 0.116 | 0.080 | -0.08,+0.19,-0.14,-0.11 | 5764 | 0.054 |
| `F6` | C3761431 | UNAVAILABLE (no vendor pad comparison) | 0.115 | 0.000 | +0.05,+0.12,-0.28,-0.13 | 468 | 0.000 |
| `C_A2P` | LOCAL | 0deg @0.00mm | 0.115 | 0.000 | +0.03,+0.09,-0.26,-0.06 | 1195 | 0.000 |
| `C_A6N` | LOCAL | 0deg @0.00mm | 0.115 | 0.000 | +0.03,+0.06,-0.26,-0.09 | 1195 | 0.000 |
| `C_LDO_IN` | C84494 | 0deg @0.04mm | 0.114 | 0.000 | -0.05,-0.06,-0.14,-0.07 | 219 | 0.000 |
| `Q_IN` | C780842 | 270deg @0.01mm | 0.113 | 0.031 | +0.09,-0.03,-0.28,-0.09 | 288 | 0.013 |
| `U_ISO2` | C53283916 | 270deg @0.05mm | 0.113 | 0.000 | -0.07,+0.01,-0.15,-0.07 | 96 | 0.000 |
| `C_A1N` | LOCAL | 0deg @0.00mm | 0.112 | 0.000 | +0.03,+0.09,-0.25,-0.06 | 1195 | 0.000 |
| `C_A5P` | LOCAL | 0deg @0.00mm | 0.112 | 0.000 | +0.03,+0.06,-0.25,-0.09 | 1195 | 0.000 |
| `C_BUCK_IN3` | C597579 | 0deg @0.05mm | 0.112 | 0.000 | -0.06,+0.04,-0.15,-0.13 | 204 | 0.000 |
| `C_BUCK_IN` | C597579 | 0deg @0.05mm | 0.110 | 0.000 | -0.06,-0.03,-0.15,-0.05 | 219 | 0.000 |
| `C_BUCK_IN2` | C597579 | 0deg @0.05mm | 0.110 | 0.000 | -0.06,+0.05,-0.15,-0.12 | 204 | 0.000 |
| `U_ISO7` | C53283916 | 270deg @0.05mm | 0.109 | 0.000 | -0.06,+0.07,-0.14,-0.16 | 90 | 0.000 |
| `U_AFE2` | C2863402 | 270deg @0.13mm | 0.108 | 0.000 | +1.10,+0.11,-1.32,-0.12 | 540 | 0.000 |
| `U_AFE6` | C2863402 | 270deg @0.13mm | 0.108 | 0.000 | +1.10,+0.12,-1.32,-0.11 | 540 | 0.000 |
| `C_A3P` | LOCAL | 0deg @0.00mm | 0.106 | 0.000 | +0.04,+0.09,-0.25,-0.06 | 1196 | 0.000 |
| `C_A7N` | LOCAL | 0deg @0.00mm | 0.106 | 0.000 | +0.04,+0.06,-0.25,-0.09 | 1196 | 0.000 |
| `U_ISO3` | C53283916 | 270deg @0.05mm | 0.104 | 0.000 | -0.06,+0.01,-0.14,-0.07 | 96 | 0.000 |
| `C_A2N` | LOCAL | 0deg @0.00mm | 0.103 | 0.000 | +0.04,+0.09,-0.24,-0.06 | 1196 | 0.000 |
| `C_A6P` | LOCAL | 0deg @0.00mm | 0.103 | 0.000 | +0.04,+0.06,-0.24,-0.09 | 1196 | 0.000 |
| `F2` | C3761431 | UNAVAILABLE (no vendor pad comparison) | 0.101 | 0.000 | +0.06,+0.13,-0.26,-0.12 | 468 | 0.000 |
| `L_BUCK` | C6937839 | 0deg @0.00mm | 0.100 | 0.057 | -0.03,-0.06,-0.15,-0.03 | 486 | 0.000 |
| `C_BUCK_O3` | C84494 | 0deg @0.04mm | 0.100 | 0.000 | -0.05,+0.06,-0.14,-0.11 | 204 | 0.000 |
| `U_AFE7` | C2863402 | 270deg @0.13mm | 0.099 | 0.000 | +0.96,+0.12,-1.16,-0.11 | 541 | 0.000 |
| `C_BUCK_O2` | C84494 | 0deg @0.04mm | 0.099 | 0.000 | -0.05,-0.02,-0.14,-0.03 | 219 | 0.000 |
| `C_BUCK_O1` | C84494 | 0deg @0.04mm | 0.098 | 0.000 | -0.05,+0.07,-0.14,-0.10 | 204 | 0.000 |
| `U_TDM_SCH` | C6076 | 180deg @0.20mm | 0.096 | 0.000 | +0.72,+0.02,-0.90,-0.08 | 89 | 0.033 |
| `C_HOLD2` | LOCAL | 0deg @0.00mm | 0.095 | 0.122 | -0.15,-0.12,-0.01,+0.02 | 2395 | 0.000 |
| `U_AFE4` | C2863402 | 270deg @0.13mm | 0.091 | 0.000 | +0.97,+0.11,-1.15,-0.12 | 564 | 0.000 |
| `U_AFE8` | C2863402 | 270deg @0.13mm | 0.091 | 0.000 | +0.97,+0.12,-1.15,-0.11 | 564 | 0.000 |
| `U_DUMP` | C131093 | 180deg @0.20mm | 0.078 | 0.000 | +0.79,+0.19,-0.88,-0.07 | 69 | 0.032 |
| `J9` | LOCAL | 0deg @0.00mm | 0.076 | 0.000 | +0.14,+0.07,-0.22,-0.20 | 3422 | 0.005 |
| `U_BUCK` | C2071056 | 270deg @0.06mm | 0.076 | 0.000 | +0.64,+0.01,-0.77,-0.09 | 90 | 0.000 |
| `Q_PRE` | C15127 | 180deg @0.28mm | 0.071 | 0.000 | +0.56,+0.14,-0.70,-0.12 | 57 | 0.071 |
| `U_ADC` | LOCAL | 0deg @0.00mm | 0.068 | 0.000 | +0.03,+0.10,-0.17,-0.10 | 1224 | 0.000 |
| `Q_DUMP` | C20917 | 180deg @0.08mm | 0.058 | 0.000 | +0.65,+0.15,-0.76,-0.11 | 56 | 0.021 |
| `J5` | LOCAL | 0deg @0.00mm | 0.057 | 0.000 | +0.07,+0.11,-0.15,-0.19 | 5804 | 0.054 |
| `J1` | LOCAL | 0deg @0.00mm | 0.057 | 0.000 | +0.07,+0.19,-0.15,-0.11 | 5819 | 0.054 |
| `U_LDO_EN` | C131093 | 180deg @0.20mm | 0.051 | 0.000 | +0.79,+0.03,-0.88,-0.07 | 66 | 0.032 |
| `F5` | C3761431 | UNAVAILABLE (no vendor pad comparison) | 0.047 | 0.000 | +0.04,+0.12,-0.13,-0.13 | 486 | 0.000 |
| `F_IN` | LOCAL | 0deg @0.00mm | 0.042 | 0.000 | -0.28,-0.04,+0.19,+0.03 | 1488 | 0.000 |
| `F1` | C3761431 | UNAVAILABLE (no vendor pad comparison) | 0.033 | 0.000 | +0.05,+0.13,-0.12,-0.12 | 486 | 0.000 |
| `U_AFE3` | C2863402 | 270deg @0.13mm | 0.022 | 0.000 | +1.11,+0.11,-1.16,-0.12 | 539 | 0.000 |

## Not measurable by construction (249) — named, never silently passed

- `C_ADC_CM1N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ADC_CM1P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ADC_CM2N` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ADC_CM2P` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ADC_CM3N` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ADC_CM3P` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ADC_CM4N` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ADC_CM4P` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ADC_CM5N` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ADC_CM5P` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ADC_CM6N` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ADC_CM6P` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ADC_CM7N` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ADC_CM7P` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ADC_CM8N` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ADC_CM8P` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_AUDIO` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_AUDIO_CT1` — body 1.60x0.80 mm is under the 2.0 mm resolvability floor (5.1 px, and erosion costs 4 px)
- `C_AUDIO_CT2` — body 1.60x0.80 mm is under the 2.0 mm resolvability floor (5.1 px, and erosion costs 4 px)
- `C_BUCK_BST` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_CLK` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_DUMP_LOGIC` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_DUMP_TIME` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FB1N` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_FB1P` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_FB2N` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_FB2P` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_FB3N` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_FB3P` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_FB4N` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_FB4P` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_FB5N` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_FB5P` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_FB6N` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_FB6P` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_FB7N` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_FB7P` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_FB8N` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_FB8P` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_FILT1_10U` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILT1_1U` — body 1.60x0.80 mm is under the 2.0 mm resolvability floor (5.1 px, and erosion costs 4 px)
- `C_FILT2_10U` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILT2_1U` — body 1.60x0.80 mm is under the 2.0 mm resolvability floor (5.1 px, and erosion costs 4 px)
- `C_FILTER1N1` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER1N2` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER1P1` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER1P2` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER2N1` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER2N2` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER2P1` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER2P2` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER3N1` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER3N2` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER3P1` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER3P2` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER4N1` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER4N2` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER4P1` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER4P2` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER5N1` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER5N2` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER5P1` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER5P2` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER6N1` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER6N2` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER6P1` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER6P2` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER7N1` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER7N2` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER7P1` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER7P2` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER8N1` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER8N2` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER8P1` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_FILTER8P2` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_ISO1` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ISO2` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ISO3` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ISO4` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ISO5` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ISO6` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ISO7` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_ISO8` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_LDO_A` — body 1.60x0.80 mm is under the 2.0 mm resolvability floor (5.1 px, and erosion costs 4 px)
- `C_LDO_D` — body 1.60x0.80 mm is under the 2.0 mm resolvability floor (5.1 px, and erosion costs 4 px)
- `C_LDO_EN` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_LDO_NR4` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_LDO_NR5` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_OE` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_OPA1` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_OPA2` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_OPA3` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_OPA4` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_OPA5` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_OPA6` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_OPA7` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_OPA8` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_PWR` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_PWR_CT` — body 1.60x0.80 mm is under the 2.0 mm resolvability floor (5.1 px, and erosion costs 4 px)
- `C_RST1` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_RST2` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_RST_T` — body 0.80x1.60 mm is under the 2.0 mm resolvability floor (5.1 px, and erosion costs 4 px)
- `C_TDM` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_TDM_SCH` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_VDDA1_10N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_VDDA1_4U7` — body 1.60x0.80 mm is under the 2.0 mm resolvability floor (5.1 px, and erosion costs 4 px)
- `C_VDDA2_10N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_VDDA2_4U7` — body 1.60x0.80 mm is under the 2.0 mm resolvability floor (5.1 px, and erosion costs 4 px)
- `C_VDDIO` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `C_VMID1_470N` — body 1.60x0.80 mm is under the 2.0 mm resolvability floor (5.1 px, and erosion costs 4 px)
- `C_VMID1_4U7` — body 1.60x0.80 mm is under the 2.0 mm resolvability floor (5.1 px, and erosion costs 4 px)
- `C_VMID1_EXT_10U` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_VMID1_EXT_1U` — body 1.60x0.80 mm is under the 2.0 mm resolvability floor (5.1 px, and erosion costs 4 px)
- `C_VMID2_470N` — body 1.60x0.80 mm is under the 2.0 mm resolvability floor (5.1 px, and erosion costs 4 px)
- `C_VMID2_4U7` — body 1.60x0.80 mm is under the 2.0 mm resolvability floor (5.1 px, and erosion costs 4 px)
- `C_VMID2_EXT_10U` — body 2.00x1.30 mm is under the 2.0 mm resolvability floor (8.4 px, and erosion costs 4 px)
- `C_VMID2_EXT_1U` — body 1.60x0.80 mm is under the 2.0 mm resolvability floor (5.1 px, and erosion costs 4 px)
- `D_QIN_GS` — body 3.71x1.60 mm is under the 2.0 mm resolvability floor (10.3 px, and erosion costs 4 px)
- `R_ADC_BOT` — body 0.81x1.62 mm is under the 2.0 mm resolvability floor (5.2 px, and erosion costs 4 px)
- `R_ADC_PD1N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_ADC_PD1P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_ADC_PD2N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_ADC_PD2P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_ADC_PD3N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_ADC_PD3P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_ADC_PD4N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_ADC_PD4P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_ADC_PD5N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_ADC_PD5P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_ADC_PD6N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_ADC_PD6P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_ADC_PD7N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_ADC_PD7P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_ADC_PD8N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_ADC_PD8P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_ADC_TOP` — body 0.81x1.62 mm is under the 2.0 mm resolvability floor (5.2 px, and erosion costs 4 px)
- `R_AUDIO_PD` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_AUDIO_PU` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_B1N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_B1P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_B2N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_B2P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_B3N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_B3P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_B4N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_B4P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_B5N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_B5P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_B6N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_B6P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_B7N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_B7P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_B8N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_B8P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_BCLK` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_CFG1` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_CFG2` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_CFG4` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_CFG5` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_DUMP` — body 1.60x3.20 mm is under the 2.0 mm resolvability floor (10.3 px, and erosion costs 4 px)
- `R_DUMP_PD` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_DUMP_TIME1` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_DUMP_TIME2` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_FILT1P` — body 3.20x1.60 mm is under the 2.0 mm resolvability floor (10.3 px, and erosion costs 4 px)
- `R_FILT2P` — body 3.20x1.60 mm is under the 2.0 mm resolvability floor (10.3 px, and erosion costs 4 px)
- `R_FSYNC` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_IN1N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_IN1P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_IN2N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_IN2P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_IN3N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_IN3P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_IN4N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_IN4P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_IN5N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_IN5P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_IN6N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_IN6P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_IN7N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_IN7P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_IN8N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_IN8P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_LDO_SET` — body 1.62x0.81 mm is under the 2.0 mm resolvability floor (5.2 px, and erosion costs 4 px)
- `R_MCH_BCLK_PD` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_MCH_FSYNC_PD` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_MCH_MCLK_PD` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_MCH_SENSE` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_MCH_SENSE_PD` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_MCLK` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_OPA_BLEED1` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_OPA_BLEED2` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_OUT1N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_OUT1P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_OUT2N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_OUT2P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_OUT3N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_OUT3P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_OUT4N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_OUT4P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_OUT5N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_OUT5P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_OUT6N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_OUT6P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_OUT7N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_OUT7P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_OUT8N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_OUT8P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_PRE` — body 3.20x1.60 mm is under the 2.0 mm resolvability floor (10.3 px, and erosion costs 4 px)
- `R_PRE_G` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_PWR_BOT` — body 1.62x0.81 mm is under the 2.0 mm resolvability floor (5.2 px, and erosion costs 4 px)
- `R_PWR_PU` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_PWR_TOP` — body 3.49x0.90 mm is under the 2.0 mm resolvability floor (5.8 px, and erosion costs 4 px)
- `R_QIN_G` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_RESET_GPD` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_RESET_PU` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_RST_T` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_TDM` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_TDM_PD` — body 0.50x1.00 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_VMID1_BOT` — body 0.81x1.62 mm is under the 2.0 mm resolvability floor (5.2 px, and erosion costs 4 px)
- `R_VMID1_TOP` — body 0.81x1.62 mm is under the 2.0 mm resolvability floor (5.2 px, and erosion costs 4 px)
- `R_VMID2_BOT` — body 0.81x1.62 mm is under the 2.0 mm resolvability floor (5.2 px, and erosion costs 4 px)
- `R_VMID2_TOP` — body 0.81x1.62 mm is under the 2.0 mm resolvability floor (5.2 px, and erosion costs 4 px)
- `R_X1N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_X1P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_X2N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_X2P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_X3N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_X3P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_X4N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_X4P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_X5N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_X5P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_X6N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_X6P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_X7N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_X7P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_X8N` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `R_X8P` — body 1.00x0.50 mm is under the 2.0 mm resolvability floor (3.2 px, and erosion costs 4 px)
- `U_AUDIO` — body 1.52x1.50 mm is under the 2.0 mm resolvability floor (9.7 px, and erosion costs 4 px)
- `U_CLK` — body 3.51x2.00 mm is under the 2.0 mm resolvability floor (12.9 px, and erosion costs 4 px)
- `U_ESD1` — body 1.60x1.60 mm is under the 2.0 mm resolvability floor (10.3 px, and erosion costs 4 px)
- `U_ESD2` — body 1.60x1.60 mm is under the 2.0 mm resolvability floor (10.3 px, and erosion costs 4 px)
- `U_ESD3` — body 1.60x1.60 mm is under the 2.0 mm resolvability floor (10.3 px, and erosion costs 4 px)
- `U_ESD4` — body 1.60x1.60 mm is under the 2.0 mm resolvability floor (10.3 px, and erosion costs 4 px)
- `U_ESD5` — body 1.60x1.60 mm is under the 2.0 mm resolvability floor (10.3 px, and erosion costs 4 px)
- `U_ESD6` — body 1.60x1.60 mm is under the 2.0 mm resolvability floor (10.3 px, and erosion costs 4 px)
- `U_ESD7` — body 1.60x1.60 mm is under the 2.0 mm resolvability floor (10.3 px, and erosion costs 4 px)
- `U_ESD8` — body 1.60x1.60 mm is under the 2.0 mm resolvability floor (10.3 px, and erosion costs 4 px)
- `U_PWR` — body 1.52x1.50 mm is under the 2.0 mm resolvability floor (9.7 px, and erosion costs 4 px)

## 3 ref(s) flagged by jlc_twin

| ref | status | detail |
|---|---|---|
| `D_BUCK_IN` | **MOUNT-FALLBACK** | best 0.57mm at 0deg, over 0.5mm — body mounted at JLC's OWN footprint transform (offset 0, their model rot_z), NOT at the failed fit. The render is therefore what JLC's own CAD says, and is  |
| `D_HOLD` | **POLARITY-CHECK** | 2-pad polarized part: verify the model's polarity marking vs our silk in the render (if the model is unmarked, verify via the JLC order preview) - machine checks cannot see a 180-flipped sym |
| `D_HOLD` | **POLARITY-FIT-BLIND** | no usable polarity marking on JLC's footprint — the numbering-free channel cannot run, so ONLY the human order-preview gate stands between this part and a 180deg reversal |
| `D_QIN_GS` | **POLARITY-CHECK** | 2-pad polarized part: verify the model's polarity marking vs our silk in the render (if the model is unmarked, verify via the JLC order preview) - machine checks cannot see a 180-flipped sym |

