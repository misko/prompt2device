# Detailed design and first-article math

## ADR0021 source candidate, 2026-09-09 (not generation admission)

Actual source: sixteen post-tee10k input limiters,50mohm WSLP1206 feed,
470uF local OPA reservoir, two47uF OPA ceramics and300+100+100ohm bleed.
Bias tees and spoke envelope are unchanged.85 new electrical invariants pin
values/terminals; source entries95/95 and39 moved/new instances against322
isolated native footprints do not establish routed inductance or ampacity.

The prior unloaded precharge residual1.817mV was not a loaded bound. The
corrected conditional calculation includes2mA controls and104uA leakage
reserve through22ohm+2%, then evaluates equalization with an explicit0.1ohm
path-resistance budget. Hot leakage and path minima require qualification;
this is not a repeated coupled finite-L proof.

AP63205 primary HS peak2.5/3.1A min/max and LS valley2.5/3.9A min/max do
not cap capacitor redistribution.4A feed stress is only an engineering
budget (.84W versus.85W at85C). Retained2.5A/1.20mm routing planning is
NOT4A acceptance and must be reconciled before generation. Connected cold
starts and rapid restarts remain in scope. Full native regeneration/review owed.

Status: engineering candidate, not ready for source acceptance or release.
ADR-0009 supersedes the TPS7A24 power branch with a TPS7A92 held-input,
supervised precharge/discharge and eight-channel isolation candidate. Its
conditional source screens pass; low-rail cold-start, startup, shutdown,
stability/reverse current, audio, lifetime drift and thermal qualification
remain OWED. This is not source acceptance or a physical-qualification waiver.
All unmeasured values below are CITED or explicitly ASSUMED.

## LDO rise versus final settling — correction, 2026-09-09

TI SBVS318B p14 Figure36 and p19 Equation5 distinguish the initial
soft-start charge interval from the final RC settling phase. The previous
`NR_full_ramp_screen_ms` label was incorrect; the unchanged
3.9174124–9.9986061 ms arithmetic is now named
`NR_linear_charge_equivalent_ms`. The conditional 10–90% screen and all
existing acceptance limits are unchanged. Neither calculation establishes
full settling in10ms.

For47nF, the explicitly approximate two-phase estimate is
`t97 = 0.97 * 0.8V * 47nF / 6.2uA`, followed by
`t97_to_99 = 280kohm * 47nF * ln(0.03/0.01)`.
The sum is approximately20.34ms. The first phase uses TI's approximate
linear equation, not a solution of Figure36's parallel resistor path;
the tail uses typical resistance and transition level. No guaranteed
maximum, loaded-bank tracking or arbitrary-restart bound follows. NR is
assumed initially discharged only for this estimate. The250ohm typical
active-discharge specification is for OUT, not an NR reset-time guarantee.
Executable calculation and independent tail-integration regression live in
`03_src/check_power_source.py` and `03_src/tests/test_power_source.py`.
See [the retained research](research/2026-09-09-nr-settling-and-restart.md).

## TDM timing

At 48,000 samples/s with eight 32-bit slots:

`BCLK = 48,000 × 8 × 32 = 12.288 MHz = 256 Fs`.

`MCLK = 24.576 MHz = 512 Fs`.

FSYNC is one BCLK period high per frame. CS5308P DOUT1 launches on falling BCLK and the MCHStreamer is expected to sample on rising BCLK. This edge and the MCHStreamer’s 24-MSB extraction are not inferred as passed; first article must capture MCLK/BCLK/FSYNC/DOUT and decode known per-channel tones.

## Reset screening calculation

Candidate timing: `Rext = 100 kΩ ±1%`, `Cext = 220 nF ±10% X7R`.

- nominal `R × C = 22.0 ms`;
- component-only worst-low before voltage/temperature bias: `99 kΩ × 198 nF = 19.602 ms`;
- even an explicit conservative screening coefficient `K = 0.5` gives `9.801 ms`, 9.8× the required 1 ms low interval.

The `K = 0.5` value is an engineering screen, not a TI guarantee. TI SCES586E gives typical and maximum pulse duration, not a guaranteed minimum. Therefore the physical acceptance test, not this arithmetic, closes the requirement. Supervisor delay 120–350 ms supplies the initial-high interval and is 60× the 2 ms minimum at its specified low corner.

## Audio headroom

2026-09-09: ADR0023 supersedes the OPA1656 calculation in the next paragraph
with OPA2320AIDR on existing5V_OPA. It is retained as the origin of the locked
interface, not current amplifier authority. `check_power_source.py --source-only`
uses the new primary common-mode specification while retaining conservative
load/hold allocations and explicit source-engineering obligations. New
reference-current arithmetic is conditional on its declared voltage envelope;
reference leakage/loading/settling and actual filter loops remain to be closed.

Carrier receive gain is 1 V/V differential. The shared interface now caps pod
output at 1.2 Vrms differential. The OPA1656 guaranteed input common-mode
ceiling at the 4.85 V rail floor is 2.60 V (`V+ - 2.25 V`). A balanced
1.2 Vrms differential signal moves each leg by 0.8485 V peak; with the
first-article VMID upper acceptance of 1.70 V, the positive leg reaches
2.5485 V, leaving only 51.5 mV to that guaranteed limit. The corresponding
mathematical ceiling is 1.2728 Vrms, so 1.2 Vrms is a source contract, not a
production common-mode or distortion guarantee. The pod's reduced-gain model
is approximately 0.952 Vrms worst case, leaving 0.248 Vrms (2.01 dB) below the
interface ceiling.

ADR-0008 replaces the unknown ADC_VMID production spread as the buffer's
DC source with two external half-supply dividers. Historical initial1percent
calculation, superseded by ADR0024's precision resistor adoption: with the
3.23–3.34 V first-article rail window and each 10 kOhm resistor independently ±1%,
`VEXT_min = 3.23 * 9.9/(10.1+9.9) = 1.59885 V` and
`VEXT_max = 3.34 * 10.1/(9.9+10.1) = 1.68670 V`.
These are initial component/DC corners, not a complete temperature, leakage,
amplifier-offset or production common-mode guarantee. The upper resistor
power is `3.34^2 * 10100/(9900+10100)^2 = 0.282 mW`, far below its
62.5 mW room-temperature rating. The divider current totals about 0.334 mA
for both channels at the upper rail; it is charged to the unchanged 150 mA
ADC/reference allocation, not silently added to it.

ADR0024 retains equal10k nominal dividers and uses the already-adopted
RT0603BRD0710KL/C95204, initial0.1percent and25ppm/C. The exact source
regression independently solves the two divider corners with reference
capacitor IR, amplifier bias/offset and a signed eight-leg leakage screen.
It rejects the former source at1.594756V; the conditional initial screen is
not a hot/lifetime guarantee. See
[reference loading and model authority](research/2026-09-09-reference-loading-and-model-authority.md).
Panasonic's3uA limit applies at20C two minutes after rated voltage, not
throughout startup or at85C. The first-article1.60..1.70V window is unchanged.

Each divider's nominal Thevenin resistance is 5 kOhm. Its 10 uF + 1 uF
bypass gives a nominal 55 ms time constant, about 253 ms to 99% for a
first-order step. These larger existing KEMET identities are chosen as
engineering margin: the existing 0.34425 derating screen leaves 3.4425 uF
and 0.34425 uF, above Figure 2-2's nominal 2.2 uF / 220 nF example. That
figure is not a published minimum-capacitance specification. This is reference settling,
not a supply-pin ramp. The existing 120 ms minimum reset-supervisor delay
is shorter than the nominal 99% reference settling and cannot prove audio
readiness. First-article capture must establish valid-audio delay. Both raw
ADC_VMID nodes retain independent decoupling and no external follower load.

Measure both `VMID1_BUF` and `VMID2_BUF` at 1.60–1.70 V over the allowed
4.85–5.15 V OPA rail, representative loading, and the first-article
temperature screen. Inject a balanced 1.2 Vrms differential tone and measure
distortion while observing both op-amp input legs. These measurements are an
explicit first-article hold; no clipping or production guarantee is inferred
from nominal VMID.

## Input protection and hot-current screen

ADR-0009 supersedes the historical 0.933 A estimate below: the corrected
0.30 A local 5 V allocation derives approximately 0.964 A at the admitted
input floor, still within the unchanged 1.0 A trunk allocation. The full
all-channel demand screen is 0.2673 A at 5 V, not the older 0.25 A allocation.

Maximum intended spoke load is 0.80 A. The connector-selection estimate adds 0.10 A local load for 0.90 A, but the executable rail-power/efficiency calculation is stricter: 0.933 A worst-case input at 11.4 V. The trunk copper and F_IN are therefore screened at a rounded 1.0 A, while 0.90 A remains only the nominal harness-selection load. Littelfuse publishes 1.60 A hold at 70 °C and 1.27 A at 85 °C for 2920L260/33, versus only 0.63/0.50 A for the rejected 1812L110/33. Its 0.075 Ω post-trip/reflow maximum plus Q_IN's 25 mΩ room-temperature maximum implies about 100 mV at 1.0 A before hot resistance, branch protection, copper and contacts. This is a screening calculation, not proof of the narrow 11.4 V input to 10.8 V output-header budget.

Each `1812L035/60MR` branch is budgeted at its published 1.700 Ω post-trip/reflow maximum, not a typical resistance. Its published hold current is 0.20 A at 70 °C and 0.16 A at 85 °C, leaving 60% hot-table headroom over the 0.10 A spoke load. The common input path is charged separately at the rounded 1.0 A trunk current: 0.075 Ω input-PPTC `R1max`, 0.025 Ω PFET maximum and 0.100 Ω common-copper allocation. The branch path adds 0.400 Ω per-spoke copper/joints and 0.100 Ω output-header allocation. With 20% charged to both stages, 11.4 V derives 11.16 V at `12V_PROTECTED` and 10.896 V at the carrier header, retaining 96 mV over the 10.8 V floor. Qualify all eight at temperature using four-wire measurements at J9 and each J1–J8, including self-heating and one shorted branch. If the voltage floor or nuisance-trip requirement is missed, change the protection/source boundary; do not average ports or substitute typical resistance.

The carrier 0.35/0.70 A PPTC is the cable/pre-pod tier; the pod's 0.10/0.25 A `0ZCJ0010FF2E` is the downstream-board tier. The 22 AWG spoke conductor is rated 2.2 A at 25 °C, the selected contact 7 A, and the carrier branch uses the 1.0 A `POD_POWER` routing class, so the 0.70 A trip ceiling does not reduce continuous-path capacity. It still does not establish selectivity or interruption. The branch part's 10 A maximum fault rating bounds the selected COTS source, and 0.15 s is guaranteed only at the datasheet's 8 A test point. Characterize source short/hiccup/foldback and use a current-limited first-article fault plan; do not impose 8 A on the installed harness.

Q_IN uses the low-loss PFET reverse-hookup topology: input/fuse to drain, protected load rail to source, gate pulled to ground, and a 12 V zener cathode at source/anode at gate. Test both static input polarities at a current-limited supply. The shunt SMBJ remains transient-only and must not be described as sustained-overvoltage cutoff.

## MCH independent-power screen

Official J3 pin 2 supplies 3.3 V up to 200 mA. The corrected presence divider
is 300 Ω / 10 kΩ: nominal current `3.3 V / 10.3 kΩ = 0.320 mA` and gate
voltage about 3.204 V. A genuine Nexperia74LVC1G14 Schmitt inverter now
drives OE push-pull with its own100 nF bypass; the former OE pull-up and
2N7002K are removed because DC leakage arithmetic could not prove either
OE input slew or low-VGS MOSFET conduction.
See ADR-0005 and `03_src/check_clock_defaults.py` for the leakage, resistor
drift and load allocations. Sense threshold targets and power/cable
transitions remain physical measurements; no interpolated threshold or
guaranteed hot-plug performance is invented.

Test carrier/MCH states off/off, on/off, off/on and on/on, plus each cable
alone. The three corrected 10 kΩ clock pull-downs yield a 0.0515 V
receiver-only leakage bound and a 0.2575 V screen with the extra 20 µA
module/cable/board allocation. Clock-driver DC burden is below 0.4 mA per
line under the stated bounds; miniDSP publishes no guaranteed drive table,
so validate actual loaded voltage and transitions. With carrier off/MCH on,
measure both carrier rails for back-power through the Ioff buffers. Data may
reach J10 only when J3 sense is present. No glitch-free hot-plug claim is made.

## Cable RC screen

The prospective harness uses Belden7939A shielded Cat5e per parent ADR0012: blue pair for balanced audio, orange/green/brown pairs each carrying positive and return in parallel. The old6541PA90.2pF/m calculation is superseded. The new datasheet does not supply a reliable pair-capacitance value; its capacitance-unbalance row must not be substituted. Measure pair capacitance, gain, noise/crosstalk and relative phase on representative4m and worst-case15m harnesses under concurrent power load. Installed port lengths and analog qualification remain OWED. The calculated hot power loop including0.30ohm pigtail/join/contact allocation is1.4725ohm; at0.10A and10.8V input the pod receives10.65275V. The allocation requires physical verification.

## First-article acceptance summary

- reset: initial high >2 ms, low 5–40 ms, final high stable across the admitted 11.4/12.0/13.2 V J9 input range and temperature screen;
- clocks: 24.576 MHz MCLK, 12.288 MHz BCLK, 48 kHz one-BCLK FSYNC; no missing/extra edges;
- data: slots 0–7 map J1–J8 and retain the intended signed 24 MSBs;
- gain: unity carrier differential gain within the selected resistor tolerance; no clipping at the agreed pod maximum;
- common mode: both buffered VMID nodes remain 1.60–1.70 V across the admitted
  5 V rail/load/temperature screen, and the 1.2 Vrms differential electrical
  input passes the agreed distortion limit without either OPA2320 input
  exceeding its guaranteed common-mode range; this is first-article evidence,
  not a production VMID guarantee;
- crosstalk/noise/phase: measured with both a nominal 4 m-radius representative assembly and a 15 m worst-case bench cable, one driven channel and seven terminated channels; installed per-port lengths remain survey-OWED;
- power: all eight 0.10 A pod loads sustained simultaneously without protection nuisance trip or rail violation;
- power-domain: four carrier/MCH power states and split J10/J11 cable states show no back-power, false clocks or unintended DOUT drive;
- safety: shield drains terminate at chassis entry, not through Micro-Fit or pod ground; no claim for direct lightning exposure.

## 2026-09-09 — ADR0022 buck reverse-port correction

[ADR0022](decisions/0022-buck-input-reverse-isolation.md) supersedes the
old direct12V_PROTECTED buck VIN/EN connection and the shutdown screen's
omission of local reverse-port/control/recovery loading. D_BUCK_IN US1B-13-F
isolates12V_BUCK_IN and all three10uF input ceramics.9.86V local input
floor includes1.3V engineering forward drop; unchanged total allocation is
0.985345543A. Charging topology downstream, OPA50mOhm feed, signal path,
supervisor/dump sequence and sealed pod remain unchanged.

The revised conditional320us shutdown screen charges100uA diode leakage,
1mA local reverse-port/control draw and100nC recovery charge, obtaining
4.501285055V.100nC and1mA are explicit prototype budgets, not AP63205 or
US1B manufacturer guarantees. The final balanced averaged removal experiment
and timestep/sensitivity evidence are in the reverse-port verification packet.
It makes no all-state audio or thermal conclusion.
Ordinary high-input removal keeps pod diodes off; near-dropout brownout can
reconnect them in the old architecture. New input isolation cuts that sustained
load without reducing5V_OPA. Connected starts and correlated partial-CT/ADC
rapid restart remain included and require the retained current-duration work.
