from pathlib import Path
import hashlib,json,tarfile,gzip,io
from datetime import datetime,timezone
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911');J=R/'projects/crow-audio-carrier-v1/01_docs/journal'
payload={}
def add(p,k):
 assert p.is_file() and not p.is_symlink() and k not in payload;payload[k]=p.read_bytes()
for p in (N/'docs-correction-payload').rglob('*'):
 if p.is_file():add(p,'correction/'+p.relative_to(N/'docs-correction-payload').as_posix())
for name in ['reconcile_docs.py','current_detail.md','docs-correction-applied.json','archive_document_restart.py','preserve_terminal_review.py','open_native_schematic_review.py','open_rj45_docs_schematic_availability.py']:
 add(N/name,'methods/'+name)
add(Path(__file__),'methods/'+Path(__file__).name)
for p in N.glob('*restart-summary.json'):
 add(p,'restart-records/'+p.name)
for prefix in ['weid-pod-full-native-ground','weid-pod-resume-ground','weid-pod-full-native-bypass','weid-pod-resume-bypass','weid-carrier-full-native-visual','weid-carrier-resume-visual','weid-carrier-full-native-label','weid-carrier-resume-label','weid-pod-full-native-docs','weid-pod-resume-docs','weid-carrier-full-native-docs','weid-carrier-resume-docs','weid-docs-contracts','weid-carrier-docs-preview']:
 for p in I.glob(prefix+'*'):
  if p.is_file():add(p,'runtime/'+p.name)
for name in ['rj45-corrected-schematic-availability','rj45-docs-schematic-availability']:
 meta=json.loads((N/(name+'-opened.json')).read_text());D=Path(meta['project'])
 for p in D.rglob('*'):
  if p.is_file():add(p,'availability/'+name+'/'+p.relative_to(D).as_posix())
 for suffix in ['-opened.json','-host-final.json']:add(N/(name+suffix),'availability-root/'+name+suffix)
 for p in I.glob(name+'-close*'):
  if p.is_file():add(p,'availability-root/'+p.name)
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 P=R/'projects'/slug
 for folder in ['06_build/checkpoints','06_build/netlists']:
  for p in (P/folder).glob('*'):
   if p.is_file():add(p,'current/'+slug+'/'+p.relative_to(P).as_posix())
 for filename in ['03_tscircuit/build/circuit.json','03_tscircuit/build/schematic.pdf','06_build/erc.rpt','06_build/erc_errors.rpt','06_build/build_provenance.json']:
  add(P/filename,'current/'+slug+'/'+filename)
 for p in (P/'04_kicad').glob('*.kicad_sch'):add(p,'current/'+slug+'/'+p.relative_to(P).as_posix())
record={'date':datetime.now(timezone.utc).isoformat(),'scope':'Document/TSX corrections, preserved previous visual attempts, full regenerated schematics and fresh availability. Native electrical gates pass; fresh independent reviews running. No accepted schematic-stage, new PCB, release or order claim. Root late-close TIMED_OUT reviews remain separately preserved; no changed deadline or acceptance.'}
payload['CHECKPOINT.json']=(json.dumps(record,indent=2)+'\n').encode()
payload['MANIFEST.json']=(json.dumps({'files':[{'path':k,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()} for k,b in sorted(payload.items())]},indent=2)+'\n').encode()
buf=io.BytesIO()
with gzip.GzipFile(fileobj=buf,mode='wb',mtime=0) as gz:
 with tarfile.open(fileobj=gz,mode='w') as t:
  for k,b in sorted(payload.items()):
   m=tarfile.TarInfo(k);m.size=len(b);m.mode=0o644;t.addfile(m,io.BytesIO(b))
b=buf.getvalue()
with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as t:
 ms=t.getmembers();assert len(ms)==len(payload)==len({m.name for m in ms})
 for m in ms:assert m.isfile() and t.extractfile(m).read()==payload[m.name]
h=hashlib.sha256(b).hexdigest();p=J/(h+'.tar.gz');assert not p.exists();p.write_bytes(b)
with (J/'contracts.md').open('a') as f:f.write(f'\n## Allowed RJ45 drawing and document checkpoint\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Source correction pre/postimages, prior visual attempt logs, exact regenerated native subjects and fresh reviewer availability; no review/release acceptance |\n\nAudit: SHA-256 equals filename; {len(b)}bytes/{len(payload)}regular members including MANIFEST, all reopened.\n')
summary={'sha256':h,'size':len(b),'members':len(payload),**record};(N/'docs-checkpoint-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
