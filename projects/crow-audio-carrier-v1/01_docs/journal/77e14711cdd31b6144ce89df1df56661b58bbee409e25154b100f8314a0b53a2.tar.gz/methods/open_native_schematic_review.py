from pathlib import Path
from datetime import datetime,timezone,timedelta
import sys,json,hashlib,shutil,tempfile
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
slug,lens=sys.argv[1:3];revision=sys.argv[3] if len(sys.argv)>3 else '';short='pod' if 'pod' in slug else 'carrier';name=f'rj45-{short}-{lens}-review'+('-'+revision if revision else '');D=Path(tempfile.mkdtemp(prefix=name+'-'));P=D/'project';live=R/'projects'/slug
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'))
from pre_route_review_check import digest,netlist_digest,design_rules_digest
for directory in ['02_parts','03_src','03_tscircuit/src']:
 shutil.copytree(live/directory,P/directory,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
files=['03_tscircuit/manifest.yaml','03_tscircuit/build/circuit.json','03_tscircuit/build/schematic.pdf','06_build/build_provenance.json','06_build/erc.rpt','06_build/erc_errors.rpt']
files += [str(p.relative_to(live)) for p in (live/'04_kicad').glob('*.kicad_sch')]
files += [str(p.relative_to(live)) for p in (live/'06_build/netlists').glob('*.net')]
files += [str(p.relative_to(live)) for p in (live/'06_build/checkpoints').glob('*.json')]
files += [str(p.relative_to(live)) for p in (live/'01_docs').glob('*') if p.is_file()]
files += [str(p.relative_to(live)) for folder in ['decisions','sourcing'] for p in (live/'01_docs'/folder).rglob('*') if p.is_file()]
files += [str(p.relative_to(live)) for p in (live/'06_build/verification').glob('connector_assembly*.json')]
files += [str(p.relative_to(live)) for p in (live/'06_build/sourcing').glob('*') if p.is_file()]
for rel in sorted(set(files)):
 src=live/rel
 if src.exists():
  dst=P/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
for rel in ['CLAUDE.md','skills/pcb-design/SKILL.md','skills/pcb-design/references/execution-runtime.md','skills/pcb-design/references/review-and-publication.md','skills/kicad-pcb/references/design-policies.md','skills/kicad-pcb/references/tscircuit-folder.md','skills/kicad-pcb/scripts/pre_route_review_check.py']:
 dst=D/'context'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/rel,dst)
for kind in ['topology','schematic_render']:
 dst=D/'previous-reviews'/f'pre-route_{kind}.md';dst.parent.mkdir(exist_ok=True);shutil.copy2(live/'08_reviews'/dst.name,dst)
if revision:
 for previous_lens in ['topology','readability']:
  meta=json.loads((N/f'rj45-{short}-{previous_lens}-review-opened.json').read_text())
  out=Path(meta['output_dir']);dst=D/'original-rj45-reviews'/previous_lens;dst.mkdir(parents=True)
  for filename in ['report.md','evidence.json','evidence-manifest.json']:shutil.copy2(out/filename,dst/filename)
  old=Path(meta['project'])/'project'
  if previous_lens=='topology':
   for folder in ['03_tscircuit/src','06_build/netlists']:
    shutil.copytree(old/folder,D/'previous-source'/folder)
   shutil.copy2(old/'03_tscircuit/build/circuit.json',D/'previous-source/circuit.json')
if revision=='docs':
 for previous_lens in ['topology','readability']:
  meta=json.loads((N/f'rj45-{short}-{previous_lens}-review-corrected-opened.json').read_text())
  dst=D/'corrected-rj45-reviews'/previous_lens;dst.mkdir(parents=True)
  for filename in ['report.md','evidence.json','evidence-manifest.json']:shutil.copy2(Path(meta['output_dir'])/filename,dst/filename)
  shutil.copy2(Path(meta['envelope']).parent/'attempt.json',dst/'delivery-attempt.json')
shutil.copy2('/tmp/carrier-locator-implementation-availability-6c_4vwal/preflight.py',D/'preflight.py')
net=next((P/'06_build/netlists').glob('*.net'));parts=sorted((P/'02_parts').glob('*/part.yaml'))
hashes={'netlist_sha256':netlist_digest(net),'parts_sha256':hashlib.sha256(b''.join(p.relative_to(P).as_posix().encode()+b'\0'+p.read_bytes()+b'\0' for p in parts)).hexdigest(),'design_rules_sha256':design_rules_digest(P),'schematic_pdf_sha256':digest(P/'03_tscircuit/build/schematic.pdf'),'exact_netlist_sha256':digest(net),'circuit_json_sha256':digest(P/'03_tscircuit/build/circuit.json'),'kicad_schematic_sha256':digest(next((P/'04_kicad').glob('*.kicad_sch')))}
(D/'expected-subject.json').write_text(json.dumps(hashes,indent=2)+'\n')
now=datetime.now(timezone.utc);cut=now+timedelta(minutes=11);hard=now+timedelta(minutes=14)
(D/'TASK.md').write_text(f'''Required fresh independent {lens} review of {slug}'s newly generated RJ45 schematic. Root is sole live author; review frozen project/ only, no design edits. Read envelope/preflight, context canon, current source/rules/dossiers, fresh native schematic/netlist/CircuitJSON and delivered PDF. Previous reviews are historical Micro-Fit or preceding CAT proposal witnesses and do NOT accept new bytes. Source acceptance at commit8a2d3620 covers95 engineering files; native review is new. Post-adoption fixes: pod coarse TSX J1 position moved [-26,15] to[-24,-5] to fit larger jack; carrier presentation corrected stale4pin override to10pins and audio+wire fromJ3 toJ5; all8 power merges closed by unchanged native gate. No generic gate bypass. Full conductor reaches fresh prelayout, public-catalog screen allows design only; blank operator response and no allocation remain.

Revision {revision or 'initial'}: when revision is named, original-rj45-reviews/ contains completed original topology and readability reports; previous-source/ freezes prior authored source/native netlist/CircuitJSON for independent delta comparison. New correction is source-owned pod C10/C11 schematic row moved from y2 to y3, after two local-GND-label candidates were preserved and abandoned for collisions, or carrier explicit jack body height/ground clearance, jack poseX-8.5to-10 for value/ref separation, CHASSIS label aboveleft shell and U_CLK supply label rise. Root machine/visual checks are supporting evidence only. Independently compare old/new topology and all PDF pages, preserving original DEFECTIVE findings. The topology review can use independently proved electrical equivalence plus a fresh integrated lens; do not rerun unrelated checker source suites.

For docs revision, current architecture/derived brief/first-article plan/detail and ADR follow-through were reconciled with already accepted source, preserving prompt/log history. Carrier R_ADC_PDnP/C_ADC_CMnP rows moved y2.7 to4, and MCH_FSYNC label x-5.9 to-6.5, to close the two additional corrected-review findings. corrected-rj45-reviews/ retains that full 19-page census and electrical SOUND. Both pod corrected engineering verdicts were SOUND but ROOT LATE CLOSE caused delivery TIMED_OUT; neither is admissible gate acceptance. Root preserved these failures without editing deadlines. Independently verify current docs/source agreement and exact output. Set sys.dont_write_bytecode=True BEFORE importing frozen context scripts; prior reviewer cache generation was caught and preserved. Readability must perform a systematic all-page green-wire/ground-bar versus text-glyph census, visually adjudicating candidates, not just finding the old defects.

One lens per reviewer: topology independently verify all connector pin/net identities, source->native fidelity, protection/rating facts, shield isolation and unchanged circuitry with fresh integrated look. Do not infer electrical equivalence from hashes alone; apply relevant source/native invariants and negative controls. Readability independently inspect every actual delivered PDF page using rendered images, countpages/text/geometry, visually inspect pin labels, polarity/NC and wireflow; confirm all10 J pins clearly shown and correct3power/3return/audio/shield assignments. Merely reading extracted text is not visual review. Source-only descriptions or manufacturer body drawings cannot prove generated schematic. Pin5AUDIO+,4AUDIO-,1/3/7+12V,2/6/8GND,9/10shell. Carrier shellCHASSIS, podPOD_SHIELD neither tiedtoGND. Customanalog/power over factoryCat6A RJ45, NOT Ethernet/PoE; poweroffmating. Existing sourcefirstarticle admission is mandatorySOURCEPASS plus authenticFULLINCOMPLETE(23carrier9pod physical unknowns), not physicalPASS. Existing carrierADR7/podADR5 authorize prototype progression FIRST-ARTICLE-ONLY / DO-NOT-ORDER, do not invent an order/physical measurement gate before schematic review. Routing/placement/layout/render/DRC/fab/release all separate and owed; LAYOUT001closed3/3 unchanged.

Use shared /usr/bin/python3 pipeline_runtime.run_stage for every engineering/native subprocess, finite timeout/directargv/cwd, retained rawlogs/runtime. Scratch/output only writable. Host tools view_image allowed for screenshots. Freezeverify before/after using provided preflight.py. Bind full raw and semantic envelope subject in evidence.json (recipe: subject_identity('native_schematic_review',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())]), items=envelope input_packet listed order, pipeline_identity import); independently compute gate fields in expected-subject.json with frozen pre_route_review_check.py; do not trust provided hashes unverified. Report.md required flat fields review_stage:pre-route, review_kind:{'topology' if lens=='topology' else 'schematic_render'}, reviewer identity, context:FRESH, date, design_verdict:SOUND|DEFECTIVE|INCOMPLETE, order_verdict:DO-NOT-ORDER, exact hashes. Explicit measured coverage/denominators, severity and actionable locations, inherited scope and physical limitations. SOUND only if independently justified. Domain rejection is valid delivery, never fakeSOUND.

Outputs exactly report.md,evidence.json,evidence-manifest.json,evidence.tar.gz,result.json. evidence.json includes verdict and envelope subject, methods/counts/findings. Evidence archive stores reproducible scratch methods/fixtures/runtime/raw logs and exact frozen input manifest or copies as needed; hash and reopen every regular member, manifest keys archive_sha256/archive_size/member_count/members (path,size,sha256). No symlinks, traversal or duplicatepaths. Do not include recursively generated archive or huge unrelated trees. result.json exact envelope subject, checks evidence-complete/inputs-verified/review-complete PASS for completed honest review, unresolved empty only delivery complete. Finish work and actualFINAL by{cut.isoformat()}, hard{hard.isoformat()}, reserve3minpackaging, zero replacements. Only root may adopt outputs later after actualFINAL/closure/freshness. Root continues independent other-board/stock/document work. No live project or source mutations.
''')
items=[]
for p in sorted(D.rglob('*')):
 if p.is_file():
  b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(D).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
s=subject_identity('native_schematic_review',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
e=TaskEnvelope(schema=2,task_id=name,stage_id='KICAD-SCHEMATIC',run_id=name,subject=s,executor='reviewer',execution_class='review_wait',recommended_agent_role='judgment',agent_role='judgment',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']})
o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),agent_id=f'/root/carrier_rj45_native_{short}_{lens}'+('_'+revision.replace('-','_') if revision else ''),work_cutoff=cut.isoformat());(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o));print(len(items),'frozen files')
