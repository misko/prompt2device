from pathlib import Path
import hashlib,json
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
A=R/'projects/crow-audio-carrier-v1';P=R/'projects/crow-mic-pod-v3';S=R/'projects/crow-roof-array-v1';N=Path(__file__).parent
before={};after={}
def load(p):
 b=p.read_bytes();before[str(p.relative_to(R))]=b;return b.decode()
def save(p,s):
 after[str(p.relative_to(R))]=s.encode()
def replace(s,old,new):
 assert old in s,old[:120];return s.replace(old,new)
current='''The adopted source uses Würth 615008160221 nonmagnetic shielded 8P8C
jacks and complete Weidmüller 8909650150 factory 15 m Cat6A S/FTP PUR cords.
Pins 1/3/7 carry +12 V, 2/6/8 return, 5 AUDIO+ and 4 AUDIO−. Shell pads
9/10 join carrier CHASSIS or pod POD_SHIELD; neither net connects to circuit
GND. The pod shield island is isolated from circuit ground, not disconnected
from the cord shield. These ports carry custom analog audio and power;
label them “POD AUDIO +12V / NOT ETHERNET OR POE” and mate with power off.
No field crimps, splices or pigtails belong to this spoke assembly.

Exact manufacturer STEP establishes a nominal complete plug end of
57.98 × 13.70 × 18.456687 mm and a 22.986 mm nominal grip diameter.
These are nominal CAD envelopes, not manufacturing or installed-service
limits. Cable OD is 6.1–6.5 mm; retain the 67 mm bend planning floor.
The three parallel power pairs give the conditional hot-loop screen
`290 Ω/km × 0.015 km / 3 × 1.25 + 0.300 Ω = 2.1125 Ω`, hence
10.58875 V at 0.10 A from 10.8 V. Contact allowance, finished-loop resistance,
power sharing, fault behavior, mating/service and environmental performance
remain measured obligations. UV is unestablished; PUR alone is not evidence.
The source adoption is recorded in the carrier schematic journal at
2026-09-12 20:08 UTC. Native review, routing and release are separate gates.
'''
fault='''Protection is two-tier: carrier `1812L035/60MR` covers cable/pre-pod
faults; pod `0ZCJ0010FF2E` covers downstream-board faults. The carrier
0.70 A trip specification is a thermal PPTC characteristic, not a precision
current limit. Würth specifies 1.5 A per jack contact; the factory cord uses
26 AWG stranded conductors in three parallel positive/return pairs. Normal
0.10 A branch current would divide to about 33.3 mA per power contact with
equal paths. Neither equal sharing nor cable/plug fault ampacity is established
by those figures, and three contacts do not automatically triple the rating.
Do not inherit the former 22 AWG cable or Micro-Fit current ratings.
The COTS source's prospective short current must remain within the branch
PPTC's 10 A fault rating. Its 0.15 s trip point at 8 A does not authorize an
8 A installed-cord test. Hot resistance, source foldback, trip energy,
selectivity and one-fault/seven-healthy recovery remain first-article holds.'''
p=P/'01_docs/ARCHITECTURE.md';s=load(p)
s=replace(s,'Micro-Fit pin 1 (+12V_POD)','RJ45 J1 pins 1/3/7 (+12V_POD)')
s=replace(s,'-> J1 pin 3','-> J1 pin 5')
s=replace(s,"J1 pin 2 is the sole spoke return. The cable's shields are deliberately not\nconnector pins: they terminate at carrier chassis and are insulated at the pod.","J1 pins 2/6/8 carry the spoke return. Shell pads 9/10 join the isolated\nPOD_SHIELD island, which remains separate from GND. The factory cord shield\nis continuous to carrier CHASSIS; its panel bond requires qualification.")
s=replace(s,"At 15 m, Belden's 90.2 pF/m conductor-to-conductor value gives about 1.35 nF\ndifferential cable capacitance. A 100 Ω source resistor on each leg yields a\nnominal differential RC pole around 0.59 MHz, far above 20 kHz. That arithmetic\nis not a substitute for stability, noise and EMC tests with the real cable.","The selected Weidmüller cord has no established pair-capacitance value in\nthe accepted source packet. Do not reuse the former Belden capacitance or RC\npole. Measure the complete cord's capacitance, gain, relative phase, noise\nand stability with both 100 Ω output resistors and concurrent power loading.")
s=s[:s.index('## Prospective Cat5e harness')]+ '## Adopted factory RJ45 spoke — 2026-09-12\n\n'+current
save(p,s)
p=A/'01_docs/ARCHITECTURE.md';s=load(p)
s=replace(s,'Fresh conductor regeneration and independent native review remain owed;\nthe existing native board is stale and unrouted.', 'Native RJ45 schematics have been generated; corrected exact-subject review\nand subsequent PCB generation remain owed. The existing PCB is stale and unrouted.')
s=replace(s,'eight four-wire spokes','eight factory RJ45 analog/power spokes')
s=replace(s,'exact four-wire drop','exact Kelvin-measured voltage drop')
i=s.index('Protection is deliberately two-tier.');j=s.index('\n\n## Eight-channel analog path',i);s=s[:i]+fault+s[j:]
s=replace(s,'Each spoke connector is Molex 43650-0400, straight-through pins 1 `+12V_POD`, 2 `GND`, 3 `AUDIO+`, 4 `AUDIO−`. Physical nets are indexed per port (`12V_PODn`, `AUDIO_Pn`, `AUDIO_Nn`).','Each spoke connector is Würth 615008160221: pins 1/3/7 `+12V_POD`,\n2/6/8 `GND`, 5 `AUDIO+`, 4 `AUDIO−`, and shell pads 9/10 `CHASSIS`.\nPhysical nets are indexed per port (`12V_PODn`, `AUDIO_Pn`, `AUDIO_Nn`).')
i=s.index('## Prospective Cat5e harness');j=s.index('## Fixed logical pod',i);s=s[:i]+'## Adopted factory RJ45 spoke — 2026-09-12\n\n'+current+'\n'+s[j:]
save(p,s)
p=S/'01_docs/ARCHITECTURE.md';s=load(p)
s=replace(s,'[ADR 0011](decisions/0011-internal-microfit-cable-gland-spokes.md)\nowns the internal Micro-Fit and cable-gland spoke boundary.','[ADR 0013](decisions/0013-factory-rj45-pod-spokes.md) supersedes the\nspoke connector/cable choices in ADR0011/0012 with the factory RJ45 source.\nInstalled dry-zone entry, restraint and enclosure qualification remain owed.')
s=replace(s,'and remain isolated at the pod;', 'and connect to an isolated POD_SHIELD island at the pod;')
s=replace(s,'insulated at each pod.', 'on an isolated POD_SHIELD island at each pod, separate from circuit GND.')
i=s.index('both child boards use the same right-angle');j=s.index('\n## Audio and network timing boundary',i)
s=s[:i]+current+'''\n`check_spoke_interface.py` requires agreement at the parent, carrier and pod.
Installed cable length, dry-zone entry, strain relief, chassis bond and full
service envelope remain enclosure/system obligations.

'''+fault+'''\n\nThe separate building uplink is genuine standards-compliant PoE/Ethernet.
It also uses RJ45/Cat6 hardware, so physical connector compatibility cannot
identify the electrical function. Never connect a pod port to networking or
PoE equipment. Keep the two port groups clearly marked and separated.
PoE/Ethernet, internal USB and the MCHStreamer interfaces each retain their
own compiled contracts at every represented end.
'''+s[j:]
s=replace(s,'prospectively fixes TDM','fixes the adopted source mapping of TDM');save(p,s)
# Correct living derived requirements; preserve original prompt and dated logs.
for base in [A,P,S]:
 p=base/'01_docs/BRIEF.md';s=load(p)
 notice='''## Current source interpretation — 2026-09-12

The later user-approved factory RJ45 direction supersedes the spoke
Micro-Fit/Belden/Cat5e assumptions retained in the dated log below. The current
source selects Würth 615008160221 and Weidmüller 8909650150 Cat6A cords,
with the exact pin map in `03_src/rules/spoke_interface.yaml`. This is
source adoption, not hardware qualification or release acceptance.

'''
 s=replace(s,'## End goal — definition of done',notice+'## End goal — definition of done')
 if base==A:
  s=replace(s,'Eight active-balanced spokes map deterministically to ADC channels 1–8 and TDM slots 0–7 on exact reviewed artifacts.','Logical pods 1–8 map to physical ADC4,3,2,1,5,6,7,8; slots 0–7 carry pods4,3,2,1,5,6,7,8 under ADR0027 on exact reviewed artifacts.')
  s=replace(s,'Every receive channel realizes the Cirrus AN0556 Figure 2 topology and the two buffered VMID domains pass exact review and bench qualification.','Every receive channel realizes the Cirrus-derived unity/filter topology with ADR0025 shared-rail OPA2320, grounded filter shunts and two passive external VMID domains; exact review and bench qualification pass.')
  s=replace(s,'Eight exact Micro-Fit spoke headers','Eight exact Würth 615008160221 RJ45 spoke jacks')
  s=replace(s,'Carrier Micro-Fit output header','Carrier RJ45 output jack')
  s=replace(s,'J3 pin 2 is microamp presence sense only.','J3 pin 2 is about 0.320 mA presence sense only.')
 elif base==P:
  s=replace(s,'J1 implements the shared straight-through four-wire spoke contract exactly: pin 1 `12V_POD`, pin 2 `GND`, pin 3 `AUDIO_P`, pin 4 `AUDIO_N`.','J1 implements the shared factory RJ45 spoke contract: pins 1/3/7 `12V_POD`, 2/6/8 `GND`, 5 `AUDIO_P`, 4 `AUDIO_N`, shell 9/10 isolated `POD_SHIELD`.')
  s=replace(s,'Exact AOM-5024L-HD-R capsule, OPA1679IDR, TPS7A4901DGNR, Micro-Fit assembly and Belden 6541PA cable','Exact AOM-5024L-HD-R capsule, OPA1679IDR, TPS7A4901DGNR, Würth 615008160221 jack and Weidmüller 8909650150 cord')
  s=replace(s,'One simple four-wire roof home run per microphone.','One complete factory RJ45 analog/power cord per microphone.')
  s=replace(s,'keep shields outside the PCB conductors and qualify exact 4 m/15 m harnesses.','keep POD_SHIELD isolated from GND and qualify the exact factory 15 m cord; installed-length alternatives require their own identity and evidence.')
  s=replace(s,'reviews, fabrication gates and first-article evidence must close before order or\ndeployment.','reviews and fabrication gates precede a separately authorized prototype order\nunder ADR0005. Measured first-article evidence precedes tested/deployment claims.')
  s=replace(s,'through exact 4 m and 15 m harnesses into the carrier receiver.','through the exact selected 15 m cord into the carrier receiver; any shorter installed cord requires exact-source adoption and qualification.')
 else:
  s=replace(s,'accepted non-Ethernet internal-Micro-Fit/cable-gland boundary in ADR 0011','adopted non-Ethernet factory RJ45 analog/power boundary in ADR 0013')
 save(p,s)
p=A/'03_tscircuit/src/schematic_presentation.tsx';s=load(p)
s=replace(s,'[`R_ADC_PD${n}P`]:[7.7,2.7,-90]','[`R_ADC_PD${n}P`]:[7.7,4,-90]')
s=replace(s,'[`C_ADC_CM${n}P`]:[10.2,2.7,-90]','[`C_ADC_CM${n}P`]:[10.2,4,-90]')
s=replace(s,'schX={-5.9} schY={-5} anchorSide="right"','schX={-6.5} schY={-5} anchorSide="right"')
save(p,s)
# First-article instructions must name the adopted population and rail probes.
p=A/'01_docs/FIRST_ARTICLE_TEST_PLAN.md';s=load(p)
i=s.index('## Amplifier/reference revision');j=s.index('## Authority and scope')
s=s[:i]+'''## Current shared-rail source — 2026-09-12

ADR0025 supersedes the former independent 5V_OPA supply and ninth reference
amplifier. Current population is 333 components: eight OPA2320 duals share
3V3_ADC with CS5308P, powered by LT3041ADE#TRPBF; the two external bias
banks are passive 1k/1k dividers. VMID1_EXT/VMID2_EXT retain the planned
1.60–1.70 V acceptance window. ADC_VMID1/2 are separate internal-reference
outputs. No removed VMID buffer or TPS7A92 rail is a current probe target.

The bounded steady estimates are 222.374 mA on shared3V3 (230 mA allocation),
250.414 mA on local5V (300 mA allocation) and 0.985346 A total with eight
0.10 A spokes. These are source calculations, not hardware readings.
The 0.20 A first-power current limit below is not proof of adequate startup
headroom. Qualify source foldback and an instrumented startup procedure
before physical power; never raise the limit during an unexplained failure.

Retain cold start, slow brownout, removal after a low-input dwell, correlated
restart, mute/reset/dump operation, reverse recovery and capacitor/thermal
qualification. Verify ADR0025's explicit 50 pC switch-charge, 100 mV return
error and 50 mV amplifier tracking allocations, including negative ADC-pin
excursions. Capture shared rail, held input, SET, external/internal references,
FILT banks, enables and all relevant currents. Validate all 32 grounded
filter shunts and their local return loops under full-level eight-channel
audio. The 8.389 ms charge/SET99 screen is not a guaranteed supply ramp.
Noise, distortion, settling, drift and actual LT3041 thermal behavior remain
measured obligations; no reference-board thermal or noise result is inherited.

'''+s[j:]
s=replace(s,'`12V_PROTECTED`, `5V_OPA`, `3V3_ADC`, `VMID1_BUF` and `VMID2_BUF`','`12V_PROTECTED`, `5V_BUCK`, `3V3_ADC`, `VMID1_EXT` and `VMID2_EXT`')
s=replace(s,'2026-09-08 source amendment: fitted census is302, including U_TDM_SCH,','Retained digital-interface amendment: the current population includes U_TDM_SCH,')
s=replace(s,'the existing150mA\n3V3_ADC total budget','the existing150mA\nADC/reference suballocation within the230mA shared3V3 budget')
s=replace(s,'both buffered VMID nodes','both passive external VMID nodes')
s=replace(s,'with exact 4 m installed-length and 15 m boundary harnesses.','with the exact selected 15 m factory cord. A nominal 4 m array radius does\n      not select a 4 m cord; any shorter cord needs exact-source adoption first.')
s=replace(s,'BUCK_SW,5V_BUCK,5V_OPA,5V_LDO_HOLD','BUCK_SW,5V_BUCK,3V3_ADC,5V_LDO_HOLD')
save(p,s)
# Preserve initial ADR handbacks and append the later verified source adoption.
for base,pat in [(A,'0028*'),(P,'0007-rj45*'),(S,'0013*')]:
 p=next((base/'01_docs/decisions').glob(pat));s=load(p)
 s+='''\n## Source adoption follow-through — 2026-09-12

The independently accepted 95-file source was adopted at commit8a2d3620,
as recorded in the carrier schematic journal at20:08 UTC. The initial
proposed/pending wording above is the original handback. Exact native
schematic review and subsequent PCB/routing/release gates remain separate;
no stale generated board or prior sealed release gains acceptance here.
''';save(p,s)
# Store exact old/new documentation and drawing bytes before applying once.
out=N/'docs-correction-payload';assert not out.exists();out.mkdir()
for rel,b in before.items():
 p=out/'before'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
for rel,b in after.items():
 assert (R/rel).read_bytes()==before[rel];p=out/'after'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
for rel,b in after.items():(R/rel).write_bytes(b)
record=[{'path':rel,'old_sha256':hashlib.sha256(before[rel]).hexdigest(),'new_sha256':hashlib.sha256(b).hexdigest()} for rel,b in sorted(after.items())]
(N/'docs-correction-applied.json').write_text(json.dumps(record,indent=2)+'\n')
print('Applied',len(record),'exact source/document files; original prompt and dated logs preserved.')
