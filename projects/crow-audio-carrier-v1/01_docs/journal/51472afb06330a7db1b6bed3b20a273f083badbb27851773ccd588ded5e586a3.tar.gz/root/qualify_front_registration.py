from pathlib import Path
import os, sys, json, hashlib, copy, yaml
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901'); P=R/'projects/crow-audio-carrier-v1'; N=Path('/tmp/carrier-rj45-20260912'); D=N/'front-registration-source'
D.mkdir(exist_ok=False)
source=P/'03_src/rules/model_registration.yaml'; board=P/'04_kicad/crow_audio_carrier_v1.kicad_pcb'
before=source.read_bytes(); assert before.count(b'  mount_side: back\n')==1
old=yaml.safe_load(before); after=before.replace(b'  mount_side: back\n',b'  mount_side: front\n'); new=yaml.safe_load(after)
expected=copy.deepcopy(old); target=next(g for g in expected['groups'] if g['id']=='littelfuse-1812l035-native-package'); assert target['refs']==['F'+str(i) for i in range(1,9)] and target['mount_side']=='back'; target['mount_side']='front'; assert expected==new
(D/'before.yaml').write_bytes(before); (D/'after.yaml').write_bytes(after)
os.environ['KICAD10_3DMODEL_DIR']='/home/mouse9911/.local/share/kicad/10.0/3dmodels';sys.path.insert(0,str(R/'skills/jlcpcb-fab/scripts'));import model_registration_gate as gate
import pcbnew
b=pcbnew.LoadBoard(str(board)); results=[]
for oldgroup,newgroup in zip(old['groups'],new['groups']):
 values=gate.normalized_group(newgroup['id'],newgroup); tup, rows=gate.tuple_for(board,values)
 instances=[]
 for ref in values['refs']:
  fp=b.FindFootprintByReference(ref); actual=gate.native.mounted_side(fp); assert actual==values['mount_side'];instances.append({'ref':ref,'actual_side':actual,'layer':b.GetLayerName(fp.GetLayer())})
 if oldgroup['id']==target['id']:
  try:gate.tuple_for(board,gate.normalized_group(oldgroup['id'],oldgroup))
  except ValueError as ex: error=str(ex);assert 'declared mount_side back differs from actual front' in error
  else:raise AssertionError('old declaration unexpectedly accepted')
  cached=False
 else:
  oldtup,_=gate.tuple_for(board,gate.normalized_group(oldgroup['id'],oldgroup)); assert oldtup==tup
  names=gate.declared_outputs(values['refs'],rows[0]['model'].suffix,values['mount_side']);cached=gate.accepted_cache_valid(P/'06_build/pre_route/native_registration'/oldgroup['id'],tup,values['refs'],names,values['registration_datum']); assert cached
 results.append({'id':newgroup['id'],'tuple':tup,'instances':instances,'unchanged_cache_valid':cached})
assert len(results)==6 and sum(len(g['instances']) for g in results)==28
result={'verdict':'SOURCE_TUPLES_PASS_NATIVE_NEW_REGISTRATION_OWED','source_path':str(source.relative_to(R)),'preimage_sha256':hashlib.sha256(before).hexdigest(),'postimage_sha256':hashlib.sha256(after).hexdigest(),'board_sha256':hashlib.sha256(board.read_bytes()).hexdigest(),'old_source_rejection':error,'groups':results,'group_count':6,'instance_count':28,'change':'Only Littelfuse F1-F8 mount_side back to front; all other parsed and byte content preserved','native_construction':0,'live_writes':0}
assert source.read_bytes()==before
(D/'qualification.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps({k:v for k,v in result.items() if k!='groups'},indent=2))
