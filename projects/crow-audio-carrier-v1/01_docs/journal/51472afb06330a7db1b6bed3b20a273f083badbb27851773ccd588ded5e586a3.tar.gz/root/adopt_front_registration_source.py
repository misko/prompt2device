from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,sys
N=Path('/tmp/carrier-rj45-20260912');R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');D=N/'front-registration-source';name='rj45-front-registration-review1'
meta=json.loads((N/(name+'-opened.json')).read_text());close=json.loads((N/(name+'-closeout-summary.json')).read_text());assert close['delivery_status']=='PASS' and close['engineering_verdict']=='SOUND'
O=Path(meta['output_dir']);env=json.loads(Path(meta['envelope']).read_text());q=json.loads((D/'qualification.json').read_text());assert q['postimage_sha256'] in (O/'report.md').read_text()
for row in env['input_packet']:
 p=Path(meta['project'])/row['path'];data=p.read_bytes();assert len(data)==row['size'] and hashlib.sha256(data).hexdigest()==row['sha256']
source=R/q['source_path'];before=(D/'before.yaml').read_bytes();after=(D/'after.yaml').read_bytes();assert source.read_bytes()==before and hashlib.sha256(before).hexdigest()==q['preimage_sha256'] and hashlib.sha256(after).hexdigest()==q['postimage_sha256'];assert (Path(meta['project'])/'proposal/after.yaml').read_bytes()==after
boards={}
for slug,stem in [('crow-audio-carrier-v1','crow_audio_carrier_v1'),('crow-mic-pod-v3','crow_mic_pod_v3')]:
 p=R/'projects'/slug/'04_kicad'/(stem+'.kicad_pcb');boards[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
assert boards[str(R/'projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb')]==q['board_sha256']
source.write_bytes(after)
for p,h in boards.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
result={'created_at':datetime.now(timezone.utc).isoformat(),'decision':'ADOPT_EXACT_REVIEWED_FRONT_REGISTRATION_SOURCE','source_path':q['source_path'],'preimage_sha256':q['preimage_sha256'],'postimage_sha256':q['postimage_sha256'],'review_archive':close['sha256'],'frozen_inputs_reverified':len(env['input_packet']),'boards_unchanged':boards,'scope':'Only F1-F8 registration mount_side back to front; all geometry/models/numerics unchanged. Normal carrier source/checkpoint/schematic renewal owed; no current placement/orientation/routing/release acceptance.'}
(N/'front-registration-reviewed-source-adoption.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
