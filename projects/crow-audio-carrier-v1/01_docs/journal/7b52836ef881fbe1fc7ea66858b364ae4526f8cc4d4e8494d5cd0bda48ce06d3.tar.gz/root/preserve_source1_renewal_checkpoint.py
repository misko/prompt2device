from pathlib import Path
import json,hashlib,tarfile,gzip,io
from datetime import datetime,timezone
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911');A=R/'projects/crow-audio-carrier-v1';P=R/'projects/crow-mic-pod-v3';payload={}
def add(p,key):
 assert p.is_file() and not p.is_symlink() and key not in payload,key
 payload[key]=p.read_bytes()
for name in ['carrier-recovery-source-adoption.json','crow-audio-carrier-v1-source1-review-adoption.json','carrier-source1-prior-placement-classification.json','classify_carrier_source1_prior.py','preserve_source1_renewal_checkpoint.py','adopt_native_reviews.py','open_next_placement.py','open_current_native_review.py','open_pod_clamp_seed_source.py']:
 add(N/name,'root/'+name)
for p in (N/'carrier-source1-prior-drc').iterdir():add(p,'carrier-prior-native/'+p.name)
for B,label in [(A,'carrier'),(P,'pod')]:
 for rel in ['06_build/drc/gate.json','06_build/agent_handoff.yaml','01_docs/STATUS.md']:
  add(B/rel,label+'-current/'+rel)
for prefix in ['carrier-recovery-source1-','carrier-source1-','pod-clamp-source-dback-','rj45-carrier-source1-schematic-availability-close','rj45-carrier-readability-review-source1-close','rj45-carrier-topology-review-source1-close']:
 for p in I.glob(prefix+'*'):
  if p.is_file():add(p,'runtime/'+p.name)
name='rj45-carrier-source1-schematic-availability';m=json.loads((N/(name+'-opened.json')).read_text());D=Path(m['project']);E=Path(m['envelope']);assert json.loads((E.parent/'attempt.json').read_text())['status']=='PASS'
for row in json.loads(E.read_text())['input_packet']:
 p=D/row['path'];b=p.read_bytes();assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256'];add(p,'availability/inputs/'+row['path'])
for p in E.parent.iterdir():
 if p.is_file():add(p,'availability/allocation/'+p.name)
for p in Path(m['output_dir']).iterdir():
 if p.is_file():add(p,'availability/outputs/'+p.name)
for suffix in ['-opened.json','-host-final.json']:add(N/(name+suffix),'root/'+name+suffix)
record={'created_at':datetime.now(timezone.utc).isoformat(),'scope':'Carrier accepted nine-file source normal regeneration and exact current schematic review adoption. Preceding live PCB remains failed104violations/499unconnected/0parity, individually classified. Pod current placement0/58/0 with three source prep refusals. No updated carrier placement, routing, release or ordering acceptance.'};payload['CHECKPOINT.json']=(json.dumps(record,indent=2)+'\n').encode();payload['MANIFEST.json']=(json.dumps({'files':[{'path':k,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()} for k,b in sorted(payload.items())]},indent=2)+'\n').encode();tmp=N/'source1-renewal-checkpoint.tmp'
with tmp.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for k,b in sorted(payload.items()):
    x=tarfile.TarInfo(k);x.size=len(b);x.mode=0o644;t.addfile(x,io.BytesIO(b))
with tarfile.open(tmp) as t:
 assert len(t.getmembers())==len(payload)==len({x.name for x in t.getmembers()})
 for x in t.getmembers():assert x.isfile() and t.extractfile(x).read()==payload[x.name]
b=tmp.read_bytes();h=hashlib.sha256(b).hexdigest();J=A/'01_docs/journal';p=J/(h+'.tar.gz');assert not p.exists();p.write_bytes(b)
with (J/'contracts.md').open('a') as f:f.write(f'\n## Allowed source1 schematic renewal checkpoint\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Exact carrier source adoption and normal regeneration, fresh reviewer availability and review adoption, preceding native failure classifications and root runtime records |\n\nAudit: SHA-256 equals filename; {len(b)} bytes / {len(payload)} regular members, all reopened against MANIFEST.json. No placement, route, release or order acceptance.\n')
summary={'sha256':h,'archive':str(p),'size':len(b),'members':len(payload),**record};(N/'source1-renewal-checkpoint-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
