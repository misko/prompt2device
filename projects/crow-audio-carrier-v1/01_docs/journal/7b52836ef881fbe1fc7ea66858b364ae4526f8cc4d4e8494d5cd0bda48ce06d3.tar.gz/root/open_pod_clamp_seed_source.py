from pathlib import Path
from datetime import datetime,timezone,timedelta
import sys,json,hashlib,shutil,tempfile
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;slug='crow-mic-pod-v3';P=R/'projects'/slug;name='rj45-pod-clamp-seed-source';D=Path(tempfile.mkdtemp(prefix=name+'-'))
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
cp=json.loads((P/'06_build/checkpoints/prelayout-inputs.json').read_text());paths={R/k.removeprefix('repo:') for k in cp['files']}
for rel in ['CLAUDE.md','tests/README.md','skills/pcb-design/SKILL.md','skills/pcb-design/references/lifecycle-and-backtrack.md','skills/pcb-design/references/execution-runtime.md','skills/kicad-pcb/references/design-policies.md','skills/kicad-pcb/references/source-to-prep-authority.md','skills/kicad-pcb/references/placement-and-proximity.md','skills/kicad-pcb/references/routing-pipeline.md']:
 paths.add(R/rel)
paths.update((P/'04_kicad').glob('*.kicad_*'));paths.update((P/'06_build/netlists').glob('*.net'));paths.update((P/'03_src/tests').glob('*.py'))
for rel in ['01_docs/STATUS.md','01_docs/findings.yaml','06_build/agent_handoff.yaml','06_build/drc/gate.json','06_build/drc/pre_route.json','06_build/build_provenance.json']:
 paths.add(P/rel)
for p in sorted(paths):
 assert p.is_file() and not p.is_symlink(),p;q=D/'input'/p.relative_to(R);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
m=json.loads((N/'rj45-pod-placement-after-recovery1-opened.json').read_text());assert json.loads((Path(m['envelope']).parent/'attempt.json').read_text())['status']=='PASS';O=Path(m['output_dir'])
for filename in ['report.md','evidence.json','evidence-manifest.json']:
 q=D/'failure'/filename;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(O/filename,q)
shutil.copy2('/tmp/carrier-locator-implementation-availability-6c_4vwal/preflight.py',D/'preflight.py')
now=datetime.now(timezone.utc);cut=now+timedelta(minutes=20);hard=now+timedelta(minutes=30)
(D/'TASK.md').write_text(f'''# Fresh D-BACK source owner: three pod clamp seed paths

Read only TASK, exact input/ source/canon/current native board and frozen failure/ evidence. Root owns all live projects. READ_ONLY inputs; construct isolated scratch candidate. No live changes, no children, no commits, no route search/import, no part/placement/SCH/policy edits. Work cutoff {cut.isoformat()}, hard {hard.isoformat()}. Actual FINAL promptly after required output/preflight. No replacement; maximum TWO candidate source revisions total. Preserve every attempt and do not relabel earlier source campaigns or LAYOUT001closed3/3.

Prior accepted source has a current SOUND schematic (recovery1 reviews, commit2d3c8ef5). One normal mechanical continuation, preserved0b077b50, generated40parts/4holes and passed placement feasibility7/7, models32/32, P-LAND69/103 and native0violations/58unconnected/0parity. It then refused THREE seed primitives before any seed copper was saved. The current native board and failed r0 each have0tracks. Exact measured defect:
- GND U3.4 B.Cu0.50mm begins(49.7825,27.36), which is actual U3.1 NC1. Actual U3.4 GND is(48.3575,28.36).
- AUDIO_P J1.5 B.Cu0.26mm ends(48.3575,27.36), actual U3.5 AUDIO_N. Actual U3.3 AUDIO_P is(49.7825,28.36).
- AUDIO_N J1.4 B.Cu0.26mm ends(49.7825,28.36), actual U3.3 AUDIO_P. Actual U3.5 AUDIO_N is(48.3575,27.36).
These are inherited measurements to rederive from exact native pads/nets/side/geometry, not authority to blindly copy coordinates. The source pin map is correct; authored route points are wrong after underside transform. Source question is whether legal short connector-to-clamp prefixes and a GND-contact return fit with the LOCKED current placement and all existing requirements. No fourth fuse-placement or alternate connector/package search.

Own source ONLY projects/{slug}/03_src/route.yaml. Correct only segments of the three named stubs, including necessary escape corners. Keep all other seed paths (especially D1/D2 branch ordering), source routes, keepouts, geometry, MPNs, pin maps, netclasses, widths, via floors, budgets and assembly/physical obligations unchanged. Optional regression additions only in existing03_src/tests/test_check_realized_routes.py, if they provide meaningful independent native/source coverage; do not mirror a new helper with its own test or weaken existing known-bad controls. No shared code change. If a governing source/backend cannot express the remedy, report concrete blocker rather than broadening scope.

Constraints: B.Cu only and NO vias for both connector-to-U3 prefixes; AUDIO_P J1.5→U3.3, AUDIO_N J1.4→U3.5, with U3 pad first before downstream R12/R13 branches. Keep source maximum lengths (positive4.0mm,negative4.2mm; independently read owning rules). Ground U3.4 goes to actual GND jack contact, never shell9/10/POD_SHIELD. Keep0.50mm ground,0.26mm audio,0.15mm seed clearance and all existing native rules unchanged. Swapping endpoint coordinates alone may cross the package's other pads; inspect whole widened segment shapes and inter-seed collisions, not endpoints alone. Use actual node/UUID mapping and independent native geometry. Keep U3/J1 poses,rotations/layers and model registries byte-identical.

Evidence required:
1. Reproduce unchanged original three refusals through the actual stock prep consumer in scratch. Preserve original log/raw native source. This is the known-bad, not a test of another artificial rule.
2. At most2 source revisions. Use stock generator if needed and stock route_and_stitch_generic.py prep on an isolated board, never KRT/global routing. Candidate prep must save accepted source copper only after whole-config checks pass. Run generate_rules LAST before actual native severity-all/refill/parity/exit-code DRC. Classify every violation, unconnected and parity row by exact subjects; expected remaining unrouted rows are not final-clean acceptance. Do not drop via or saved-copper defects as irrelevant merely because these three stubs pass.
3. Independently reopen saved candidate, prove exact start/end native pad number/net/side, layer/via/width, centerline lengths, clamp-first topology and no same-net alternative branch bypass. Verify all unrelated source bytes and native footprint/pad/model projections unchanged. Use the existing realized-route consumer/oracle for these connected prefixes where its scope permits; an incomplete full-route check is not PASS. Preserve negative controls for wrong pad, opposite net, wrong side, via insertion, overlength and pre-clamp branch as appropriate using current maintained tests.
4. Visually inspect native B.Cu/Fab detail of the entire J1/U3 area with actual saved copper and pad numbers; mirrored bottom physical view when assessing body/service. Machine/native collision proof, not appearance, owns clearance. Report feasibility distinctly from authoring/gate acceptance.

All engineering/native/process work via shared pipeline_runtime.run_stage, explicit cwd/env, finite180s child budget, /usr/bin/python3 -B andPYTHONDONTWRITEBYTECODE=1. Methods may be read-only from {R}/skills and system libraries with actual hashes recorded; no hidden live writes. Candidate deps may be copied from input; do not duplicate large unchanged dependencies into final archive.

Five outputs exactly report.md,evidence.json,evidence-manifest.json,evidence.tar.gz,result.json. evidence domain_result string and exact subject; change pre/postimages, variants and all measured counts/findings. Archive source_candidate/<repo-relative changed files>, beforeimages, raw methods/logs/runtime and independent native/visual evidence. Manifest archive_sha256/archive_size/member_count/members(path,size,sha256), independently reopen regular members with no symlinks/duplicates/traversal/recursivearchives. result exactsubject with evidence-complete/inputs-verified/review-complete checks for honest complete handback; domain success separate. Verify all frozen inputs before/after and providedpreflight.py after packaging. No promotion/checkpoint refresh or review adoption. FIRST-ARTICLE-ONLY/DO-NOT-ORDER; existing physical9pod/23carrier obligations stay at the admitted prototype boundary, not extra prerequisites. Return exact failure owner if source correction cannot close the gate.
''')
items=[]
for p in sorted(D.rglob('*')):
 if p.is_file():b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(D).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
s=subject_identity('pod_clamp_seed_correction',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())]);e=TaskEnvelope(schema=2,task_id=name,stage_id='KICAD-PLACEMENT',run_id=name,subject=s,executor='agent',execution_class='local',recommended_agent_role='authoring',agent_role='authoring',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=2,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']});o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),agent_id='/root/carrier_rj45_pod_clamp_seed_source',work_cutoff=cut.isoformat());(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2));print(len(items),'frozeninputs')
