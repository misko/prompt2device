subject: crow-audio-carrier-v1 ADR0027 ground-pad mode source correction
date: 2026-09-12
reviewer: Codex independent judgment agent /root/carrier_channel_thermal_review
context-given: FRESH; immutable 22-file original packet plus separately authenticated narrow test supplement
source_commit: 3fc3935a (unfixed source baseline) plus reviewed packet correction
previous_source_commit: f2675b43 (accepted pre-map board/source baseline)
task_id: channel-thermal-review
run_id: channel-thermal-review
stage_id: KICAD-PLACEMENT
input_handoff_id: channel-thermal-review
envelope_file_sha256: 5db47fc41e1f1fc6b3078a2bfde83a37b8da5e037d8998bc23a85623eebe3087
subject_raw_sha256: 3a5418253cb1ac6668146c18c6d253eeb8b63553e35592380652841a2401c3bb
subject_semantic_sha256: 833b50b0764997c4faf48b330cb62467ee6b1b5146da207ed9b54019c53a3a4b
floorplan_sha256: 254792603dcbed3b65b2cef9d73f95fb09083e50ad4c518701325cbba7b353d2
unfixed_floorplan_sha256: a38a355cdecf6798d9d46682a7d75d9096bcead5e8370d57f586ef395896389e
board_sha256: 25287c83682141495ac07ae7fdf541bd92156891abf3294fd15fca83ffed5b9b
previous_board_sha256: 9aa1c2c821a31129176a8b519b9a211d78dfc011adb997a64470c03d0726891f
pre_route_json_sha256: 1fa058b971ee506d29fc66b7d1ea43529119e65f1d97d6a27e28380a0f0e7b45
design_rules_sha256: unavailable-in-isolated-packet (owning design_rules_digest API returned None)
review_stage: source-correction
review_kind: thermal-ground-pad-mode
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
completed_at: 2026-09-12T03:35:47Z

# Independent focused source-correction review

The proposed source correction is **SOUND for the bounded ADR0027 ground-pad-mode migration**. This is a noncanonical focused source report. It is not a green-board, canonical placement, PIN, layout, render, route, release, or order acceptance.

The original packet was verified 22/22 by exact declared size and SHA-256 before and after inspection. The authenticated supplement manifest is `ed361a661a3506cca1fad9b73fba7253a45a5f30ad685951ce7b8f131cf281a6`; its three declared members verified 3/3. The later focused green command/runtime/log were separately copied and hashed in evidence. No packet input was edited.

The entire proposed production-source delta is one exact selector migration in `floorplan.yaml`: `C_ADC_CM3N,C_ADC_CM3P` becomes `C_ADC_CM2N,C_ADC_CM2P`. `C_ADC_CM6N/P`, `R_AUDIO_PD`, `C_VMID1_EXT_1U`, `R_ADC_PD1P`, `U_OE`, `U_TDM_SCH`, and `U_LDO` remain selected exactly as before. No placement coordinate, rotation, geometry limit, net assignment, zone policy, or routing/electrical declaration changes. The supplemental test delta makes the same CM3-to-CM2 change in the fixed ten-target expectation and adds an accurate explanatory comment; it changes no production source.

Native `pcbnew` inspection covered all 340 footprints, 1,002 pads, every GND pad local-zone mode, and all 16 ADC common-mode pad-2 locations on each of the accepted pre-map, unfixed, and actual failed current boards. The accepted pre-map board has full/solid mode on physical pad-2 sites `(93.0,64.32)` and `(94.25,64.32)`, then named `C_ADC_CM3P/N`. ADR0027 exchanged logical references across fixed lands, so those same physical sites are now `C_ADC_CM2P/N`. The failed current board instead retains full mode on `C_ADC_CM3P/N` at `(99.4,64.32)` and `(100.65,64.32)`. Thus it simultaneously omits two required physical exceptions and adds two unnecessary solid connections. The other nine full-mode GND pads, including `C_ADC_CM6P/N`, are identical by reference, pad, and physical position. Count equality alone (11 solid GND pads on each board, ten source-owned plus U_ADC.49) would have missed this error.

The supplied `pre_route.json` independently reports exactly 2/2 DRC violations, both `starved_thermal`: `C_ADC_CM2P.2` and `C_ADC_CM2N.2`, each with one spoke where two are required. It also contains 499 ordinary unrouted `unconnected_items`, outside this correction lens. There is no schematic parity finding. The supplied enhanced native projection fails on exactly four CM references because the actual current board is intentionally the stale failed before-state. No corrected native board was generated or projected, and no green DRC result is claimed.

The production consumer is direct and unambiguous: `patterns_for(ref)` matches each exact list member and the placement loop applies `ZONE_CONNECTION_FULL` only when the selected pad number and `on_net: GND` guard agree. The correction therefore changes local zone mode only for `C_ADC_CM2P/N.2` in the next generated board; it removes the stale mode from `C_ADC_CM3P/N.2`. No wildcard, duplicate selector, alternate override, or broad net match appears in the reviewed delta.

The new property test is independent of that consumer: it derives initial physical poses with the source placement builder, enumerates all declared override payloads by physical pose, and compares the complete multiset with the accepted pre-map source. It proves nonvacuity with a positive count and then mutates CM2 back to CM3, requiring inequality. The original omission is therefore hostile to the test. The existing ten-target ground test is complementary: it validates exact ref/pad cardinality, native GND identity, top-SMD realization, omission hostility, and rejection of broad/wrong-net/extra-pad declarations. Its stale CM3 target caused the supplied full 337-test run's sole failure; the reviewed CM2 target update is the required logical-name migration and the focused map-plus-ground rerun passes 13/13 in 7.048 seconds. The post-update full 337-test rerun is neither supplied nor claimed here.

No P0/P1/P2 source defect was found in the reviewed correction. The normal downstream gates remain: parent-owned full 337-source-suite completion; canonical corrected-board generation; placement qualification; corrected native projection; fresh filled-zone DRC; independent PIN, layout, and render reviews; route acceptance; release checks; and order authorization. Existing `LAYOUT-001` corridor history remains 3/3 spent, no further diagnostic route is admitted, and `DO-NOT-ORDER` remains in force.
