from pathlib import Path
import sys,json,hashlib,tarfile,io,shutil
from datetime import datetime,timezone
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911');j=json.loads(Path('/tmp/carrier-thermal-schematic-delta-opened.json').read_text());root=Path(j['project']);A=Path(j['attempt']).parent;O=A/'outputs'
sys.path.insert(0,str(R/'skills/pcb-design/scripts'));sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet
import pre_route_review_check as g
sha=lambda b:hashlib.sha256(b).hexdigest();e=TaskEnvelope.from_json(Path(j['envelope']).read_text());a=json.loads((A/'attempt.json').read_text());assert a['status']=='PASS';assert verify_input_packet(e,root)[0]
for n,m in a['output']['completion']['outputs'].items():b=(O/n).read_bytes();assert len(b)==m['size'] and sha(b)==m['sha256'],n
live=0
for p in (root/'current').rglob('*'):
 if p.is_file():assert p.read_bytes()==(P/p.relative_to(root/'current')).read_bytes(),str(p);live+=1
m=json.loads((O/'evidence-manifest.json').read_text());arc=m.get('archive',m);arc=({'sha256':m['archive_sha256'],'size':m['archive_size']} if isinstance(arc,str) else arc);assert sha((O/'evidence.tar.gz').read_bytes())==arc['sha256'] and (O/'evidence.tar.gz').stat().st_size==arc['size'];rows=m['members'];rows=[dict(v,path=k) for k,v in rows.items()] if isinstance(rows,dict) else rows
with tarfile.open(O/'evidence.tar.gz') as t:
 assert all(x.isfile() or x.isdir() for x in t.getmembers())
 files=[x for x in t.getmembers() if x.isfile()];assert len(files)==len(rows)>0 and set(x.name for x in files)==set(x['path'] for x in rows)
 for x in rows:b=t.extractfile(x['path']).read();assert len(b)==x['size'] and sha(b)==x['sha256'],x['path']
parts=sorted((P/'02_parts').glob('*/part.yaml'));expected={'netlist_sha256':g.netlist_digest(P/'06_build/netlists/crow_audio_carrier_v1.net'),'parts_sha256':sha(b''.join(p.relative_to(P).as_posix().encode()+b'\0'+p.read_bytes()+b'\0' for p in parts)),'design_rules_sha256':g.design_rules_digest(P)}
for kind in ['topology','schematic_render']:
 f=O/(kind+'.md');import re
 for key in ['review_stage','review_kind','design_verdict','order_verdict','netlist_sha256','parts_sha256','design_rules_sha256','source_commit']:
  assert len(re.findall(r'^'+key+r':',f.read_text(),re.M))==1,(kind,key)
 fields=g.fields(f);assert fields['design_verdict']=='SOUND' and fields['order_verdict']=='DO-NOT-ORDER';assert fields['review_stage']=='pre-route' and fields['review_kind']==kind
 for k,v in expected.items():assert fields[k]==v,(kind,k)
 assert fields['source_commit']==json.loads((root/'bindings.json').read_text())['source_commit']
 if kind=='schematic_render':assert fields['schematic_pdf_sha256']==sha((P/'03_tscircuit/build/schematic.pdf').read_bytes())
proof={'verified_at':datetime.now(timezone.utc).isoformat(),'envelope_inputs':len(e.input_packet),'live_current_files':live,'review_archive_members':len(rows),'exact_bindings':expected,'root_visual_inspection':json.loads((D/'thermal-root-visual.json').read_text()),'envelope_file_sha256':sha(Path(j['envelope']).read_bytes()),'runtime_canonical_envelope_sha256':j['envelope_sha256'],'envelope_identity_note':'Root records raw envelope-file SHA and the runtime canonical serialization SHA as different representations. Input verification and closed delivery bind the actual envelope; the two encodings are not interchangeable.','limits':'Fresh zero-electrical-delta review with explicit inherited ratings scope; no physical/routing/release acceptance'}
(D/'thermal-delta-adoption-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
payload={}
for item in e.input_packet:payload['packet/'+item.path]=root/item.path
for p in A.glob('*.json'):payload['attempt/'+p.name]=p
for p in O.iterdir():
 if p.is_file():payload['outputs/'+p.name]=p
for n in ['adopt_thermal_delta.py','thermal-delta-adoption-proof.json','thermal-root-visual.json','thermal-native-delta.json','check_thermal_native_delta.py','thermal-adc-page14.png']:payload['root/'+n]=D/n
for prefix in ['thermal-canonical-source-checkpoint','thermal-root-']:
 for p in I.glob(prefix+'*'):
  if p.is_file():payload['root/'+p.name]=p
# Reference exact committed input preimages and deduplicate input bytes.
import subprocess
refs={};seen={};cache={}
for n,p in list(sorted(payload.items())):
 b=p.read_bytes();h=sha(b);candidates=[]
 for side,rev in [('current','9e00dcf23d03b244164476b51fc705ea0728d440'),('previous','3fc3935a')]:
  lead='packet/'+side+'/'
  if n.startswith(lead):candidates.append((rev,'projects/crow-audio-carrier-v1/'+n[len(lead):]))
 if n.startswith('packet/authority/'):
  candidates.append(('9e00dcf23d03b244164476b51fc705ea0728d440',n.removeprefix('packet/authority/')))
 matched=False
 for rev,rel in candidates:
  key=(rev,rel)
  if key not in cache:
   raw=subprocess.run(['git','show',rev+':'+rel],cwd=R,capture_output=True);cache[key]=(len(raw.stdout),sha(raw.stdout)) if raw.returncode==0 else None
  if cache[key]==(len(b),h):
   refs[n]={'git_commit':rev,'path':rel,'size':len(b),'sha256':h};del payload[n];matched=True;break
 if matched:continue
 if h in seen:refs[n]={'archive_member':seen[h],'size':len(b),'sha256':h};del payload[n]
 else:seen[h]=n
(D/'thermal-delta-references.json').write_text(json.dumps(refs,indent=2)+'\n');payload['root/references.json']=D/'thermal-delta-references.json'
manifest={n:{'size':p.stat().st_size,'sha256':sha(p.read_bytes())} for n,p in payload.items()};temp=D/'thermal-delta-accepted.tar.gz'
with tarfile.open(temp,'w:gz',compresslevel=3) as t:
 for n,p in payload.items():t.add(p,arcname=n,recursive=False)
 b=(json.dumps({'members':manifest},indent=2)+'\n').encode();x=tarfile.TarInfo('MANIFEST.json');x.size=len(b);t.addfile(x,io.BytesIO(b))
h=sha(temp.read_bytes());dest=P/'01_docs/journal'/f'{h}.tar.gz';assert not dest.exists();shutil.copyfile(temp,dest)
with tarfile.open(dest) as t:
 assert len(t.getmembers())==len(manifest)+1
 for n,x in manifest.items():b=t.extractfile(n).read();assert len(b)==x['size'] and sha(b)==x['sha256'],n
for kind in ['topology','schematic_render']:
 b=(O/(kind+'.md')).read_bytes();dated=P/'08_reviews'/f'2026-09-12_thermal_9e00dcf2_{kind}.md';assert not dated.exists();dated.write_bytes(b);(P/'08_reviews'/('pre-route_'+kind+'.md')).write_bytes(b)
with (P/'01_docs/journal/contracts.md').open('a') as f:f.write(f'\n\n## Allowed accepted thermal-correction schematic renewal review\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Immutable complete fresh thermal-correction topology/readability zero-electrical-delta packet, exact two witnesses, raw native/PDF comparison and visual evidence, timely delivery and root reopening |\n')
result={'archive':str(dest),'sha256':h,'payload_members':len(manifest),'verified_references':len(refs),'size':dest.stat().st_size,**proof};(D/'thermal-delta-adoption-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
