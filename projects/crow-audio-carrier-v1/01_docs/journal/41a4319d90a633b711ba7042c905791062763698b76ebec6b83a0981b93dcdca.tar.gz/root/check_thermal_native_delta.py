from pathlib import Path
import sys,json,hashlib
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');D=Path(__file__).parent;Q=Path('/tmp/carrier-thermal-schematic-delta-ejefg1lq');sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'));from generate_board_generic import parse_netlist
n='06_build/netlists/crow_audio_carrier_v1.net';a,ap,an=parse_netlist(Q/'previous'/n);b,bp,bn=parse_netlist(Q/'current'/n);assert a==b and set(ap)==set(bp)
changes=[{'ref':k[0],'pin':k[1],'before':ap[k],'after':bp[k]} for k in sorted(ap) if ap[k]!=bp[k]]
assert not changes,changes
r={'scope':'Root comparison of exact canonical exported netlists using shared native-text parser; independent reviewer separately re-exports native schematic. No PCB acceptance.','components':len(a),'pin_memberships':len(ap),'before_nets':len(an),'after_nets':len(bn),'changes':changes,'before_sha256':hashlib.sha256((Q/'previous'/n).read_bytes()).hexdigest(),'after_sha256':hashlib.sha256((Q/'current'/n).read_bytes()).hexdigest()};(D/'thermal-native-delta.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
