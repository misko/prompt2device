# Source implementation: exact dedicated ADC2 return-pad NONE mode

Root accepts the independent upstream decision: preserve C_VDDA2_10N.2's
existing dedicated seed/via return by explicitly declaring no zone connection.
Current generator ignores none, and project ground census assumes every explicit
override is full. Implement and qualify this representation repair ONLY.
Five product native candidates remain spent. No candidate6 admitted; no BOARD
construction, board generation, Fill, Save, prep, router or property-modified
board experiments. Native isolated FOOTPRINT/PAD tests WITHOUT BOARD allowed.
Read decision report and corrected via count first: failed placement is 0tracks
+11thermalvias, NOT zero vias. The raw graph correctly has44via-layer nodes.

Work on scratch/work copy of before; root alone writes live repository. Scope:
- skills/kicad-pcb/scripts/generate_board_generic.py: exact mapping full|thermal|none
  to native enum in REAL BoardBuilder.place_parts; invalid present values reject
  (including values under otherwise nonmatching selectors). Absent mode preserves
  existing inheritance/clearance-only behavior. Preserve valid generic selector,
  glob, on_net, net assignment, side and full/thermal behavior globally.
- tests/t1_generate_board.py maintained selected fixtures of ACTUAL consumer,
  isolated real native pads and footprint, fake container Add/GetFootprints,
  WITHOUT pcbnew.BOARD. Independent native getter is oracle; no same mapping
  oracle. Genuine pre-fix RED against old consumer, not import/setup ERROR.
  Test all3modes, absent inheritance, clearance-only, invalid/malformed values,
  filters, valid generic patterns. Do not run whole existing generator suite
  because it creates boards; root broader qualification later with admission.
- projects/crow-audio-carrier-v1/03_src/floorplan.yaml only exact new pattern
  match:[C_VDDA2_10N], pads:['2'],on_net:GND,zone_connection:none.
  Preserve all32existing full overrides and every other source property.
- project03_src/tests/test_ground_connections.py: separately enumerate32FULL
  and1NONE target, preserve existing TARGETS/public inspect tuple compatibility
  if other callers depend on it. Exact mode census rejects missing, duplicate,
  wrongnet, unknown/conflicting modes, broad refs/pads, unintended targets,
  conflicting patterns. Actual source-level negative controls. Existing native
  BOARD side fixture must NOT run for this commission; report explicitly owed.
- skills/pcb-design/templates/contracts/03_src/contracts.md and current A copy:
  document enum and closed invalid value behavior/absent inheritance. No other
  project copies or sealed release edits.
- A01_docs/decisions/0015* append precise source-mode intent/qualification and
  still-owed native return graph/cut and all placement checks. No floor changes.
  Check exact filename. No new numeric bounds without provenance.

No broadened direct plane/full connections, global thermal gap/spokewidth/minimum
change, reservation edits, route geometry, placement, rules, budget, gates or
allowance edits. Existing ADC2 reservation and ADC_WEST_LOCAL xmin89.35 retained.
Existing32FULL, CM exchange, ESDpad4full, regulatorhost and quiet returns retained.
Unknown generic mode failclosed must not impose project-only exact selectors
on every project. Existing pad mode absent remains inherited.

Before edits inspect tests/README.md and CLAUDE/canon source contracts. Read actual
method/deps; real method is place_parts, not place. /usr/bin/python3 has pcbnew.
Git-history tests need explicit GIT_DIR pointing at real worktree gitdir plus
GIT_WORK_TREE scratch/work. Do not reinterpret missing historical Git/netlist or
imports as expectedRED. Preserve all raw failures and correct setup as setup.
Source geometry helpers native_geometry generally load unattached footprints;
inspect methods before running. No entire suite blindly if BOARD construction.

Deliver complete exact changed-file before/after manifest with nonchanges checked,
maintained selected RED/GREEN and complete actual mode-census. Failclosed checker
changes need positive, knownbad and declared blindspot property controls. Fresh
independent review follows; this author cannot accept source or admit native6.
Source schema/numeric provenance preflight and full tests remain owed unless
actually run on complete required inputs. Stop engineering at cutoff and honestly
report incomplete coverage. Keep implementation owner through routine repairs
within this one source-only handoff; no children/replacements/live writes.


Delivery mechanics: Allocated scratch: /tmp/rj45-none-return-source1-38set4i4/06_build/task_runs/rj45-none-return-source1/scratch . Final outputs: /tmp/rj45-none-return-source1-38set4i4/06_build/task_runs/rj45-none-return-source1/outputs . Root sole live writer. Frozen packet read-only; make working copies under the allocated scratch dir only. No live writes, commits, children, background processes, or source adoption. Verify every envelope input before/after. Use /usr/bin/python3 -B and shared pipeline_runtime.run_stage for finite direct-argv subprocesses, explicit cwd/environment, raw stdout/stderr/runtime retained under scratch. Shared runtime is at /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts. Images can be opened with view_image.

Work cutoff 2026-09-13T23:40:43.781794+00:00, hard 2026-09-13T23:47:43.781794+00:00, zero replacements. Stop engineering at work cutoff and return actual FINAL promptly. Preserve honest INCOMPLETE if coverage absent; delivery PASS means complete honest handback, never engineering acceptance. Outputs exactly report.md, evidence.json, evidence-manifest.json, evidence.tar.gz, result.json. evidence.json requires verdict SOUND|DEFECTIVE|INCOMPLETE and exact envelope subject, methods, findings and measured counts. Archive all actual methods/raw evidence/runtime; manifest archive_sha256/archive_size/member_count/members with path,size,sha256; reopen every regular member, no symlink/traversal/duplicate/recursive archive. result.json exact subject, checks inputs-verified/review-complete/evidence-complete PASS only when factually complete delivery; unresolved [] for delivered honest findings. Use preflight.py with exact envelope after packaging to validate delivery. Final response gives domain verdict and unresolved findings, exact report and archive.
