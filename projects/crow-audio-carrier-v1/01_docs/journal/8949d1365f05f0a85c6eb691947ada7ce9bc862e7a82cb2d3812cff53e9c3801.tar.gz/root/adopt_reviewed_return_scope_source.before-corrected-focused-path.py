from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
N=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');Q=Path('/tmp/crow-adc2-native5-preparation-8jf47vo0');m=json.loads((N/'rj45-candidate5-thermal-dback1-opened.json').read_text());S=Path(m['scratch_dir']);O=Path(m['output_dir']);close=json.loads((N/'rj45-candidate5-thermal-dback1-closeout-summary.json').read_text());e=json.loads((O/'evidence.json').read_text());assert close['delivery_status']=='PASS' and e['source_composition_verdict']=='SOUND' and e['verdict']=='DEFECTIVE'
for name,count in [('final23-result.json',23),('focused38-result.json',38)]:
 d=json.loads((S/name).read_text());assert d['success'] and d['run']==count and not d['errors'] and not d['failures']
assert json.loads((S/'original20-invariance.json').read_text())['original20_preserved']
rows=json.loads((Q/'composed-source-manifest.json').read_text())['files'];assert len(rows)==5
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();payload=[]
for row in rows:
 dst=R/row['path'];src=Q/'work'/row['path'];review=S/'work'/row['path']
 assert sha(dst)==row['before_sha256']
 assert sha(src)==sha(review)==row['after_sha256']
 payload.append((dst,src.read_bytes()))
native={str(R/'projects'/slug/'04_kicad'/stem):sha(R/'projects'/slug/'04_kicad'/stem) for slug,stem in [('crow-audio-carrier-v1','crow_audio_carrier_v1.kicad_pcb'),('crow-mic-pod-v3','crow_mic_pod_v3.kicad_pcb')]}
for dst,data in payload:dst.write_bytes(data)
assert all(sha(Path(p))==h for p,h in native.items())
record={'adopted_at':datetime.now(timezone.utc).isoformat(),'scope':'Exact independently SOUND five-file source composition only. Native candidate5 remainsDEFECTIVE and was not adopted. Complete source/checkpoint renewal is deferred until coherent thermal-mode representation correction; no stale checkpoint restamp or candidate6 admission.','source_files':rows,'independent_review_archive':close['sha256'],'review_erratum':'candidate5-review-via-count-erratum.json corrects prose/countfield to0tracks+11thermalvias; original raw graph contains44via-layer nodes and diagnosis/source verdict unchanged.','native_unchanged':native}
(N/'return-scope-source-adoption.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
