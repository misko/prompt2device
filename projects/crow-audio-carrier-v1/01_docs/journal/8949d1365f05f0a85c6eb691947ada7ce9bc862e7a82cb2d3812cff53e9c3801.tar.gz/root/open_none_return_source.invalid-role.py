from pathlib import Path
import json
import thermal_review_common as common
ns={'__file__':common.__file__}
exec(compile(Path(common.__file__).read_text().replace('rj45-placement-thermal-availability-opened.json','rj45-final-source-native-availability-opened.json'),'<current-probe>','exec'),ns)
R,N=common.R,common.N
m=json.loads((N/'rj45-candidate5-thermal-dback1-opened.json').read_text()); D=Path(m['project']); O=Path(m['output_dir']); S=Path(m['scratch_dir'])
assert json.loads(Path(m['attempt']).read_text())['status']=='PASS'
A=R/'projects/crow-audio-carrier-v1'
copies=[(A/'03_src','before/projects/crow-audio-carrier-v1/03_src'),(A/'02_parts','before/projects/crow-audio-carrier-v1/02_parts'),(A/'03_tscircuit/src','before/projects/crow-audio-carrier-v1/03_tscircuit/src'),(A/'06_build/netlists','before/projects/crow-audio-carrier-v1/06_build/netlists'),(A/'01_docs/decisions','before/projects/crow-audio-carrier-v1/01_docs/decisions'),(A/'01_docs/findings.yaml','current-handoff/findings.yaml'),(R/'skills','before/skills'),(R/'tests','before/tests'),(R/'scripts','before/scripts'),(R/'CLAUDE.md','canon/CLAUDE.md'),(R/'contracts.md','canon/contracts.md'),(O,'decision'),(N/'candidate5-review-via-count-erratum.json','decision/via-count-erratum.json'),(N/'return-scope-source-adoption.json','decision/source-adoption.json')]
for name in ['exact-official-sources.json','ring-intersections.json','affected-population.json','native-inspection.json']:
 if (S/name).is_file():copies.append((S/name,'decision/'+name))
task='''# Source implementation: exact dedicated ADC2 return-pad NONE mode

Root accepts the independent upstream decision: preserve C_VDDA2_10N.2's
existing dedicated seed/via return by explicitly declaring no zone connection.
Current generator ignores none, and project ground census assumes every explicit
override is full. Implement and qualify this representation repair ONLY.
Five product native candidates remain spent. No candidate6 admitted; no BOARD
construction, board generation, Fill, Save, prep, router or property-modified
board experiments. Native isolated FOOTPRINT/PAD tests WITHOUT BOARD allowed.
Read decision report and corrected via count first: failed placement is 0tracks
+11thermalvias, NOT zero vias. The raw graph correctly has44via-layer nodes.

Work on scratch/work copy of before; root alone writes live repository. Scope:
- skills/kicad-pcb/scripts/generate_board_generic.py: exact mapping full|thermal|none
  to native enum in REAL BoardBuilder.place_parts; invalid present values reject
  (including values under otherwise nonmatching selectors). Absent mode preserves
  existing inheritance/clearance-only behavior. Preserve valid generic selector,
  glob, on_net, net assignment, side and full/thermal behavior globally.
- tests/t1_generate_board.py maintained selected fixtures of ACTUAL consumer,
  isolated real native pads and footprint, fake container Add/GetFootprints,
  WITHOUT pcbnew.BOARD. Independent native getter is oracle; no same mapping
  oracle. Genuine pre-fix RED against old consumer, not import/setup ERROR.
  Test all3modes, absent inheritance, clearance-only, invalid/malformed values,
  filters, valid generic patterns. Do not run whole existing generator suite
  because it creates boards; root broader qualification later with admission.
- projects/crow-audio-carrier-v1/03_src/floorplan.yaml only exact new pattern
  match:[C_VDDA2_10N], pads:['2'],on_net:GND,zone_connection:none.
  Preserve all32existing full overrides and every other source property.
- project03_src/tests/test_ground_connections.py: separately enumerate32FULL
  and1NONE target, preserve existing TARGETS/public inspect tuple compatibility
  if other callers depend on it. Exact mode census rejects missing, duplicate,
  wrongnet, unknown/conflicting modes, broad refs/pads, unintended targets,
  conflicting patterns. Actual source-level negative controls. Existing native
  BOARD side fixture must NOT run for this commission; report explicitly owed.
- skills/pcb-design/templates/contracts/03_src/contracts.md and current A copy:
  document enum and closed invalid value behavior/absent inheritance. No other
  project copies or sealed release edits.
- A01_docs/decisions/0015* append precise source-mode intent/qualification and
  still-owed native return graph/cut and all placement checks. No floor changes.
  Check exact filename. No new numeric bounds without provenance.

No broadened direct plane/full connections, global thermal gap/spokewidth/minimum
change, reservation edits, route geometry, placement, rules, budget, gates or
allowance edits. Existing ADC2 reservation and ADC_WEST_LOCAL xmin89.35 retained.
Existing32FULL, CM exchange, ESDpad4full, regulatorhost and quiet returns retained.
Unknown generic mode failclosed must not impose project-only exact selectors
on every project. Existing pad mode absent remains inherited.

Before edits inspect tests/README.md and CLAUDE/canon source contracts. Read actual
method/deps; real method is place_parts, not place. /usr/bin/python3 has pcbnew.
Git-history tests need explicit GIT_DIR pointing at real worktree gitdir plus
GIT_WORK_TREE scratch/work. Do not reinterpret missing historical Git/netlist or
imports as expectedRED. Preserve all raw failures and correct setup as setup.
Source geometry helpers native_geometry generally load unattached footprints;
inspect methods before running. No entire suite blindly if BOARD construction.

Deliver complete exact changed-file before/after manifest with nonchanges checked,
maintained selected RED/GREEN and complete actual mode-census. Failclosed checker
changes need positive, knownbad and declared blindspot property controls. Fresh
independent review follows; this author cannot accept source or admit native6.
Source schema/numeric provenance preflight and full tests remain owed unless
actually run on complete required inputs. Stop engineering at cutoff and honestly
report incomplete coverage. Keep implementation owner through routine repairs
within this one source-only handoff; no children/replacements/live writes.
'''
ns['open_task']('rj45-none-return-source1',task,copies,minutes=25,role='implementation')
