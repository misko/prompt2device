review_stage: pre-route
review_kind: render
reviewer: OpenAI Codex fresh independent reviewer
context: FRESH
design_verdict: DEFECTIVE
order_verdict: DO-NOT-ORDER
completed_at: 2026-09-14T03:19:11.613243+00:00
board_sha256: 92a4e2fc0fecde845f2dfa0d9e2f5bfbd943372962fb449d699a98d957fc5633
design_rules_sha256: 7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c
subject_raw_sha256: 426d13588ea1466ecd8e4697ad787c1c095c61e4e15bcd5133190435271121ff
subject_semantic_sha256: 68b4f2ca3dc505a8fe394479317ab2544bd4f62f6d21665ccdb66eb97a0d306d
locator_manifest_sha256: 1dbd47a33fd57e5cd5af3c2ad52fe444e2479ad89fe5cfd7c67e4b6c4a2e91dd
locator_reviewed_refs: ["C_AUDIO_CT2","C_FILT1_10U","C_FILT2_10U","C_PWR_CT","C_VDDA2_10N","C_VMID1_470N","C_VMID1_4U7","C_VMID2_470N","C_VMID2_4U7","R_ADC_BOT","R_ADC_PD6N","R_ADC_TOP","R_AUDIO_PD","R_AUDIO_PU","R_DUMP_TIME2","R_FILT1P","R_IN6N","R_PRE_G","R_PWR_TOP","R_VMID1_BOT","R_VMID1_TOP","R_VMID2_BOT","R_X6N"]

The exact native top and orientation scenes are coherent: all eight RJ45 mouths face outward, J9 faces west, J10/J11 are vertical, the four board holes and rectangular edges are present, the top population is dense and labels/polarity cues are visible. Source measurement found 340 footprints, 333 component model instances, 1,050 pads and 159 drilled pads on a 154.1 mm × 100.1 mm board. The seven model-free footprints are four mounting holes and three fiducials. Catalog component-body twin fidelity remains a separate gate.

ERROR RND-BOTTOM-001 — F1–F8 and U_ESD1–U_ESD8 — owner: Carrier render pipeline owner. The accepted bottom image visibly depicts all 16 bodies beneath the opaque board, while the exact PCB places all 340 footprints on F.Cu and assembly.yaml declares top-only population, explicitly including those refs. Native registration side profiles also place the fuse/ESD bodies above the front surface. This whole-board native render contradiction blocks A-RENDER. Correct the bottom render/model-side interpretation and regenerate exact-board bottom evidence.

The complete HTML/PDF/PNG locator atlas was reopened. All 23 declared reference omissions have unique, readable top-side pages whose highlighted bodies, numbered pads, coordinates, rotations, values/MPNs and pad nets agree with the exact source. Locator acceptance is SOUND for those 23 refs.

Measurement limits: views do not qualify physical tolerances, mated fit, latch service access, soldering, thermal behavior or electrical performance. Repeated-row rear faces remain partly occluded in low views; elevated views preserve the real occlusion and suffice for orientation. The TMUX2821 model is nominal and drawing-derived; F1–F8 are maximum-envelope drawing-derived bodies with illustrative terminal bands; R_PWR_TOP is nominal. FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains mandatory for this unrouted custom analog/DC Cat6A/RJ45 carrier; it is not Ethernet/PoE and mating is power-off only.
