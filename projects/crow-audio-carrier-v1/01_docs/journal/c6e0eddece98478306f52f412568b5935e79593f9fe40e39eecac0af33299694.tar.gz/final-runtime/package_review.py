from __future__ import annotations
import hashlib, json, os, tarfile, tempfile
from datetime import datetime, timezone
from pathlib import Path
from PIL import Image

ROOT=Path('/tmp/rj45-carrier-render-locator-toponly2-svcm2m9v')
RUN=ROOT/'06_build/task_runs/rj45-carrier-render-locator-toponly2'
SCR=RUN/'scratch'; OUT=RUN/'outputs'; OUT.mkdir(exist_ok=True)
env=json.loads((RUN/'envelope.json').read_text())
subject=env['subject']; completed=datetime.now(timezone.utc).isoformat(timespec='microseconds')
refs=[x['ref'] for x in json.loads((ROOT/'current-locator/assembly_locator_manifest.json').read_text())['page_refs']]
locator_manifest_sha='1dbd47a33fd57e5cd5af3c2ad52fe444e2479ad89fe5cfd7c67e4b6c4a2e91dd'
board_sha='92a4e2fc0fecde845f2dfa0d9e2f5bfbd943372962fb449d699a98d957fc5633'
rules_sha='7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c'

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()

# Exact identities of every visually inspected supplied image/document.
visual=[]
for p in sorted((ROOT/'project/06_build/pre_route/orientation').rglob('*.png'))+sorted((ROOT/'project/06_build/pre_route/orientation-supplement').glob('*.png'))+[ROOT/'project/06_build/pre_route/approved_native_bottom.png']+sorted((ROOT/'current-locator').glob('*.png')):
 with Image.open(p) as im: dims=list(im.size)
 visual.append({'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p),'size':p.stat().st_size,'pixels':dims})
for p in [ROOT/'current-locator/assembly_locator.html',ROOT/'current-locator/assembly_locator.pdf',ROOT/'current-locator/assembly_locator.json',ROOT/'current-locator/assembly_locator_manifest.json']:
 visual.append({'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p),'size':p.stat().st_size})
(SCR/'reviewed_artifact_identities.json').write_text(json.dumps({'count':len(visual),'items':visual},indent=2)+'\n')

# Reverify all frozen inputs after the review and immediately before packaging.
after=[]
for x in env['input_packet']:
 p=ROOT/x['path']; actual=sha(p) if p.is_file() else None
 after.append({'path':x['path'],'exists':p.is_file(),'size':p.stat().st_size if p.is_file() else None,'sha256':actual,'expected_size':x['size'],'expected_sha256':x['sha256']})
all_after=all(x['exists'] and x['size']==x['expected_size'] and x['sha256']==x['expected_sha256'] for x in after)
(SCR/'input_verification_after.json').write_text(json.dumps({'count':len(after),'all_match':all_after,'items':after},indent=2)+'\n')
assert all_after

finding={
 'id':'RND-BOTTOM-001','severity':'ERROR','owner':'Carrier render pipeline owner',
 'refs':['F1','F2','F3','F4','F5','F6','F7','F8','U_ESD1','U_ESD2','U_ESD3','U_ESD4','U_ESD5','U_ESD6','U_ESD7','U_ESD8'],
 'coordinates_mm':{'F1':[29.0,25.86],'F2':[61.0,25.86],'F3':[93.0,25.86],'F4':[125.0,25.86],'F5':[52.0,114.14],'F6':[84.0,114.14],'F7':[116.0,114.14],'F8':[148.0,114.14],'U_ESD1':[40.5,34.75],'U_ESD2':[72.5,34.75],'U_ESD3':[104.5,34.75],'U_ESD4':[136.5,34.75],'U_ESD5':[40.5,105.25],'U_ESD6':[72.5,105.25],'U_ESD7':[104.5,105.25],'U_ESD8':[136.5,105.25]},
 'finding':'approved_native_bottom.png visibly presents all eight fuse bodies and all eight SOT-553 ESD bodies on the underside of the opaque board.',
 'source_conflict':'The exact board places every footprint on F.Cu; rules/assembly.yaml declares sides:[top], bottom_population:none, and explicitly requires F1-F8 plus U_ESD1-U_ESD8 on top. Native registration side profiles also place these bodies above the front surface.',
 'impact':'The registered full-scene bottom view contradicts the authoritative mounting side and cannot support A-RENDER assembly judgment. Correct the bottom render/model-side interpretation and regenerate exact-board evidence.',
 'evidence':['project/06_build/pre_route/approved_native_bottom.png','project/04_kicad/crow_audio_carrier_v1.kicad_pcb','project/03_src/rules/assembly.yaml','project/06_build/pre_route/native_registration/littelfuse-1812l035-native-package/native_side_front.png','project/06_build/pre_route/native_registration/ti-dsg0008a-native-package/native_side_front.png']}

evidence={
 'schema':1,'review_stage':'pre-route','review_kind':'render','reviewer':'OpenAI Codex fresh independent reviewer','context':'FRESH','completed_at':completed,
 'verdict':'DEFECTIVE','order_verdict':'DO-NOT-ORDER','subject':subject,'board_sha256':board_sha,'design_rules_sha256':rules_sha,
 'locator_manifest_sha256':locator_manifest_sha,'locator_reviewed_refs':refs,
 'scope':{'native_full_board_render':True,'catalog_twin_fidelity':'separate; not substituted or re-adjudicated','routing':'unrouted; route acceptance not performed','connector_refs':[f'J{i}' for i in range(1,12)]},
 'methods':[
  {'id':'M-INPUT','method':'SHA-256 and size verification of all 719 envelope inputs before and after review','runtime':'inspect_packet.runtime.json; package runtime retained by caller'},
  {'id':'M-SOURCE','method':'pcbnew reopened exact board; counted footprints, models, pads, drilled pads, sides and Edge.Cuts; semantic design-rules digest computed with frozen pre_route_review_check.design_rules_digest(project)'},
  {'id':'M-VISUAL','method':'Visually inspected populated_top, all registered cardinal/top/oblique orientation views, approved_native_bottom, all native registration group evidence, and all 23 locator PNG pages; reopened locator HTML/PDF/JSON identities and manifest.'},
  {'id':'M-CORRESPONDENCE','method':'Cross-checked connector orientation, visible mouths/keying/pin-1 cues, board edge/holes, component body interactions, source layers, assembly declarations, exact locator coordinates/rotations/pad nets, and native registration limitations.'}
 ],
 'measured_counts':{'envelope_inputs':719,'footprints':340,'assembly_parts':333,'model_paths_resolved':333,'model_paths_expected':333,'non_body_footprints_without_models':7,'top_footprints':340,'bottom_footprints':0,'pads':1050,'drilled_pads':159,'edge_cuts_primitives':4,'board_width_mm':154.1,'board_height_mm':100.1,'connector_refs_reviewed':11,'rj45_jacks':8,'power_connectors':1,'vertical_headers':2,'locator_exception_refs_reviewed':23,'bottom_render_wrong_side_bodies':16},
 'findings':[finding],
 'accepted_observations':[
  'Top and oblique native scenes show a coherent rectangular board, four mounting holes, dense top population, readable functional labels, eight outward-facing keyed RJ45 mouths, west-facing keyed J9, and vertical J10/J11 headers without visible inter-body collision.',
  'The locator atlas uniquely circles and numbers pads for exactly the 23 declared hidden references; every page agrees with the frozen top-side source coordinates, rotation, value/MPN and pad-net identity.',
  'Native group registration supports pad/body correspondence for the six declared groups. TMUX2821 is a drawing-derived nominal visual body; F1-F8 use maximum-envelope drawing-derived bodies with illustrative terminal bands; R_PWR_TOP is nominal. These limits do not establish catalog-body twin fidelity or tolerance/service qualification.'
 ],
 'measurement_limits':['Orthographic renders do not establish physical tolerance, mated cable clearance, latch service access, solder-process suitability, thermal behavior or first-article electrical performance.','J1-J8 rear faces remain partly occluded in low views by repeated row geometry; elevated full-scene views preserve honest occlusion and provide sufficient orientation evidence.','The locator body boxes are assembly context, not manufacturing geometry.'],
 'first_article_hold':'FIRST-ARTICLE-ONLY / DO-NOT-ORDER; custom analog/DC over Cat6A/RJ45, not Ethernet/PoE; mate only with power off.'
}
(OUT/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')

report='\n'.join([
'review_stage: pre-route','review_kind: render','reviewer: OpenAI Codex fresh independent reviewer','context: FRESH','design_verdict: DEFECTIVE','order_verdict: DO-NOT-ORDER',f'completed_at: {completed}',f'board_sha256: {board_sha}',f'design_rules_sha256: {rules_sha}',f'subject_raw_sha256: {subject["raw_sha256"]}',f'subject_semantic_sha256: {subject["semantic_sha256"]}',f'locator_manifest_sha256: {locator_manifest_sha}',f'locator_reviewed_refs: {json.dumps(refs,separators=(",",":"))}','',
'The exact native top and orientation scenes are coherent: all eight RJ45 mouths face outward, J9 faces west, J10/J11 are vertical, the four board holes and rectangular edges are present, the top population is dense and labels/polarity cues are visible. Source measurement found 340 footprints, 333 component model instances, 1,050 pads and 159 drilled pads on a 154.1 mm × 100.1 mm board. The seven model-free footprints are four mounting holes and three fiducials. Catalog component-body twin fidelity remains a separate gate.','',
'ERROR RND-BOTTOM-001 — F1–F8 and U_ESD1–U_ESD8 — owner: Carrier render pipeline owner. The accepted bottom image visibly depicts all 16 bodies beneath the opaque board, while the exact PCB places all 340 footprints on F.Cu and assembly.yaml declares top-only population, explicitly including those refs. Native registration side profiles also place the fuse/ESD bodies above the front surface. This whole-board native render contradiction blocks A-RENDER. Correct the bottom render/model-side interpretation and regenerate exact-board bottom evidence.','',
'The complete HTML/PDF/PNG locator atlas was reopened. All 23 declared reference omissions have unique, readable top-side pages whose highlighted bodies, numbered pads, coordinates, rotations, values/MPNs and pad nets agree with the exact source. Locator acceptance is SOUND for those 23 refs.','',
'Measurement limits: views do not qualify physical tolerances, mated fit, latch service access, soldering, thermal behavior or electrical performance. Repeated-row rear faces remain partly occluded in low views; elevated views preserve the real occlusion and suffice for orientation. The TMUX2821 model is nominal and drawing-derived; F1–F8 are maximum-envelope drawing-derived bodies with illustrative terminal bands; R_PWR_TOP is nominal. FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains mandatory for this unrouted custom analog/DC Cat6A/RJ45 carrier; it is not Ethernet/PoE and mating is power-off only.',''])
(OUT/'report.md').write_text(report)

members=[]
source_names=['input_verification_before.json','input_verification_after.json','board_measurements.json','reviewed_artifact_identities.json','orientation_contact_sheet.jpg','locator_contact_sheet.jpg','inspect_packet.py','inspect_packet.log','inspect_packet.runtime.json','measure_board.py','measure_board.log','measure_board.runtime.json','measure_board_retry.log','measure_board_retry.runtime.json']
archive=OUT/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tf:
 for name in source_names:
  p=SCR/name
  if not p.is_file(): continue
  arc='evidence/'+name; tf.add(p,arcname=arc,recursive=False)
  members.append({'path':arc,'size':p.stat().st_size,'sha256':sha(p)})
# Reopen and authenticate every regular member; reject unsafe/duplicate/nested archive forms.
seen=set()
with tarfile.open(archive,'r:gz') as tf:
 rows=tf.getmembers(); assert len(rows)==len(members)
 for ti in rows:
  assert ti.isfile() and not ti.issym() and not ti.islnk() and ti.name not in seen and '..' not in Path(ti.name).parts and not ti.name.startswith('/') and not ti.name.endswith(('.tar','.tar.gz','.tgz','.zip'))
  seen.add(ti.name); data=tf.extractfile(ti).read(); expected=next(x for x in members if x['path']==ti.name)
  assert len(data)==expected['size'] and hashlib.sha256(data).hexdigest()==expected['sha256']
manifest={'schema':1,'archive_sha256':sha(archive),'archive_size':archive.stat().st_size,'member_count':len(members),'members':members,'reopen_validation':'PASS','constraints':{'regular_members_only':True,'no_symlinks':True,'no_traversal':True,'no_duplicates':True,'no_recursive_archives':True}}
(OUT/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'result.json').write_text(json.dumps({'subject':subject,'checks':{'inputs-verified':'PASS','review-complete':'PASS','evidence-complete':'PASS'},'unresolved':[]},indent=2)+'\n')
print(json.dumps({'completed_at':completed,'verdict':'DEFECTIVE','outputs':sorted(p.name for p in OUT.iterdir()),'archive_sha256':manifest['archive_sha256']}))
