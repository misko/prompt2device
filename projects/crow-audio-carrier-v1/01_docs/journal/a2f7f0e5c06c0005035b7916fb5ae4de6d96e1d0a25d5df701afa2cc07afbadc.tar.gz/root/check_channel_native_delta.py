from pathlib import Path
import sys,json,hashlib
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');D=Path(__file__).parent;Q=Path('/tmp/carrier-channel-schematic-delta-brmggjfi');sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'));from generate_board_generic import parse_netlist
n='06_build/netlists/crow_audio_carrier_v1.net';a,ap,an=parse_netlist(Q/'previous'/n);b,bp,bn=parse_netlist(Q/'current'/n);assert a==b and set(ap)==set(bp)
changes=[{'ref':k[0],'pin':k[1],'before':ap[k],'after':bp[k]} for k in sorted(ap) if ap[k]!=bp[k]]
expected={'40':('ADC1P','ADC4P'),'39':('ADC1N','ADC4N'),'42':('ADC2P','ADC3P'),'41':('ADC2N','ADC3N'),'46':('ADC3P','ADC2P'),'45':('ADC3N','ADC2N'),'48':('ADC4P','ADC1P'),'47':('ADC4N','ADC1N')}
assert len(changes)==8 and all(x['ref']=='U_ADC' and (x['before'],x['after'])==expected[x['pin']] for x in changes),changes
r={'scope':'Root comparison of exact canonical exported netlists using shared native-text parser; independent reviewer separately re-exports native schematic. No PCB acceptance.','components':len(a),'pin_memberships':len(ap),'before_nets':len(an),'after_nets':len(bn),'changes':changes,'before_sha256':hashlib.sha256((Q/'previous'/n).read_bytes()).hexdigest(),'after_sha256':hashlib.sha256((Q/'current'/n).read_bytes()).hexdigest()};(D/'channel-native-delta.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
