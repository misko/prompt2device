# Independent review of the prescribed model-registration completion

**ACCEPT**, limited to completion of the prior candidate1 prescription and the exact eight-fuse model-registration argument. The nine proposed source files are admissible for ordinary root-owned integration. No completed source was adopted by this reviewer. Candidate2 remains rejected; cumulative algorithm variants remain two, with zero new variants.

The allocated subject is raw `44ba477be7c466e40bc6326b41a4a9969e79749f458fe8be2bcef554a9c134f1`, semantic `56ddbfe9cc3aaace67de298022dc4c92057d19293156d0b7d35afd017eb69b3f`. Canonical envelope SHA is `d600b575d810d7c3666b8adc2d1d08cf7abc1ccf227d7040c9d31e9ca1c04e6e`.

## Completion findings — MEASURED

All 246 frozen input sizes/digests verify. All nine baseline files match the live-before identities, and all nine original-candidate afterimages match the prior review's source rows. The prior archive was reopened and verified across all 277 regular members with no duplicate paths, links or traversal. Exact PCB and model hashes also match both the named live root and root's isolated completion repository.

The only completion changes beyond candidate1 are the exact prescribed module-docstring VACUITY block, one new decorated fixture, and its explanatory documentation. The native-engine algorithm AST excluding the module docstring is identical to candidate1. All 17 baseline helper/test functions and all 20 candidate1 helper/test functions retain identical ASTs, including decorators. Removing the one new function leaves the entire candidate1 test-module AST identical. The orchestrator and project/template contract/rule files are byte-identical to candidate1. All ten existing known-bad tests remain required-fail controls; none is reclassified.

The new fixture has exactly the prescribed title, `kind="vacuity"`, and `gate="native_model_registration.py"`. Its first assertion is `must_pass` on the X180 malicious back-mounted subject. It requires a graded group and a three-row measurement denominator before changing height. It then requires `must_fail` and the signed-side reason with the unchanged 0.750 floor. Height h is the only independent contrast parameter: 1 to 3 mm, with translation h/2. Reopening the generated models confirms that exact two-field dependent change; XY, external poses, pads and limits are preserved.

The documentation correctly distinguishes visible exterior pixels from full-volume exclusion, retains the independent exact-model geometry obligation, and explicitly preserves existing required-fail controls. Its statements agree with the prior native-consumer diagnosis: the malicious 1 mm model is partly exterior, not wholly buried.

## Fresh targeted execution — MEASURED

The owning maintained runner `/usr/bin/python3 -B tests/t1_model_registration.py --only=omits` ran once in an isolated input-copy/completion-overlay repository through shared `pipeline_runtime.run_stage`, with explicit cwd/environment and a 300-second ceiling. It returned PASS in 6.329 seconds: one fixture passed, thirteen skipped, one declared blind spot reproduced. The selection contains zero known-bad fixtures and is not represented as the broad regression suite.

| Arm | Owning gate result | Graded refs | Signed back fraction | Floor |
|---|---|---:|---:|---:|
| X180, nested Box h=1 mm | malicious false PASS | R1/R2/R3, 3/3 | 1.000000 | 0.750 |
| Same subject, h=3 mm, translation h/2 | required signed-side FAIL | same three orientations | 0.653401 | 0.750 |

The accepted malicious receipt, failed contrast report, models, coupons and rendered evidence are preserved in the fresh review archive. The routine KiCad enum diagnostics remain in the raw log; they did not replace the signed-side failure assertion.

## Reopened inherited evidence — INHERITED, not rerun

Root's current maintained suite reports **14 passed / 0 failed / 10 known-bad / 1 declared blind spot**. Root's current carrier run reports **6/6 groups**. Their logs and runtime sidecars were reopened, along with every group receipt and aggregate manifest binding. The corrected owning-path G-CONTRACT audit reports 100/100 verdict-printing scripts, 19 fixtured vacuity conditions and **81 OWED** declarations, against floor 17. Its earlier wrong-path invocation failed and remains preserved; the corrected result is not fleet-wide completeness.

The eight-fuse receipt grades **F1–F8, 8/8 bodies and 16/16 pad overlaps**, actual and declared back side, bottom X-mirrored camera, signed fraction 1.000000 at floor 0.750, maximum center delta 0.031362 mm and minimum reported overlap 1.930 mm². Native-engine identity changes from candidate1 `b850006d16210828808d698147595aed1848242895a4fdce47a30ea947f114ad` to completed `40ee9a88cc7fbbe7f2183ae4c11576ed6293605076e0e333c23103189b6f0795` under the existing v4 prefix. All six current receipts bind the completed identity. This is fresh root rendering under changed tool bytes, not old receipts restamped by this reviewer.

Prior independent native geometry is inherited because the full carrier PCB remains SHA256 `9c30a147b2d94babd98bc2af4150d4e87270d2efb81a8bd39e88f1b9529a99f4` and the exact model remains `edd6c3054b944bb9436d3943f1b5da78396621e59065dde98e828219fa62cde9`. Whole-PCB equality preserves all eight poses: F1–F4 native 0°, F5–F8 native 180°, B.Cu, zero external model offset/rotation and unit scale. Their full native census is retained in evidence.json.

That independently reviewed direct-coordinate model comprises three rectangular solids, 24 corners and 18 faces, with no internal transforms. Its 4.730 × 3.410 × 1.800 mm drawing envelope occupies Z −2.600..−0.800 mm outside the nominal 1.600 mm board, except the zero-volume contact plane. Standoff is zero; outward depth is 1.800 mm. The prior real-model X180 inversion occupies −0.800..+1.000 mm and fails at signed fraction 0.062581. This is evidence for these exact bytes, not a universal volume guarantee or physical qualification. The prior 13-test suite, original-source RED swap, restored mounted tests and rejected candidate2 controls are inherited explicitly, not independently repeated here.

## Scope and handback

There are no unresolved findings within this bounded completion review. Root remains sole live writer and owns source adoption, ordinary integration and current checkpoint/schematic/placement renewal. Every downstream routing, assembly, release, order and physical gate remains separately required. This declaration/fixture does not grant general model-volume acceptance, solder qualification or carrier placement acceptance.

The five-file handback binds the allocated subject. The archive contains only fresh review methods, verification records and this review's fixture artifacts; it contains no prior nested archive. Every archived member is reopened and checked against its size/digest, rejecting links, duplicates and unsafe paths. Frozen inputs are rechecked before delivery. Delivery PASS means the review handback is complete, not that downstream engineering work is complete.
