from pathlib import Path
import hashlib,json,re,tarfile,shutil,sys

ROOT=Path('/tmp/rj45-pin-carrier-supply-clockground1-m9kqx5i_')
RUN=ROOT/'06_build/task_runs/rj45-pin-carrier-supply-clockground1'
SCRATCH=RUN/'scratch'; OUT=RUN/'outputs'
envelope=json.loads((RUN/'envelope.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
checks=[]
for item in envelope['input_packet']:
    p=ROOT/item['path']; data=p.read_bytes()
    assert sha(data)==item['sha256'] and len(data)==item['size']
    checks.append(dict(path=item['path'],sha256=sha(data),size=len(data)))
(SCRATCH/'inputs-after.json').write_text(json.dumps(checks,indent=2)+'\n')
native={}
for ref in ['U_AUDIO','U_BUCK','U_PWR']:
    p=ROOT/'dossiers'/f'{ref}.md'; shutil.copy2(p,SCRATCH/p.name)
    rows=[]
    for line in p.read_text().splitlines():
        if re.match(r'^\| [1-6] \|',line):
            fields=[v.strip() for v in line.split('|')[1:-1]]
            coords=lambda v:[float(x) for x in v.strip('()').split(',')]
            rows.append(dict(pin=int(fields[0]),local_mm=coords(fields[1]),side=fields[2],size_mm=fields[3],function=fields[4],net=fields[5],native_mm=coords(fields[6])))
    assert len(rows)==6 and len({r['pin'] for r in rows})==6
    area=sum(a['local_mm'][0]*b['local_mm'][1]-b['local_mm'][0]*a['local_mm'][1] for a,b in zip(rows,rows[1:]+rows[:1]))/2
    pos=[42,66] if ref=='U_BUCK' else [33,61.1 if ref=='U_AUDIO' else 56.7]
    assert all(abs(r['native_mm'][i]-pos[i]-r['local_mm'][i])<1e-6 for r in rows for i in [0,1])
    assert area<0
    native[ref]=dict(native_pad_count=6,physical_identity_count=6,unique_pad_numbers=6,exposed_pad_count=0,alias_count=0,duplicate_numbers=0,signed_area_mm2_y_down=area,winding='CCW',mounted_side='front',coordinate_check='PASS',rows=rows)
(SCRATCH/'native-measurements.json').write_text(json.dumps(native,indent=2)+'\n')
sources=[i for i in envelope['input_packet'] if i['path'].endswith('.pdf')]
tps=next(i for i in sources if 'TPS3890' in i['path']); buck=next(i for i in sources if 'AP63205' in i['path'])
expected={
 'U_BUCK': ['FB: fixed 5 V output sense, directly connected to regulated output','EN: VIN tie explicitly permitted','VIN: input power rail within 3.8–32 V','GND: ground','SW: switching-node net for output inductor','BST: bootstrap net, distinct from SW, for SW-referenced capacitor'],
 'U_AUDIO':['SENSE: monitored/divided voltage net','GND: ground','MR_N: high enables normal sensing; low forces reset','VDD: 1.5–5.5 V supply rail','CT: timing-capacitor node','RESET_N: open-drain reset output with external pullup for high state'],
 'U_PWR':['SENSE: monitored/divided voltage net','GND: ground','MR_N: high enables normal sensing; supply tie valid','VDD: 1.5–5.5 V supply rail','CT: timing-capacitor node','RESET_N: open-drain reset output with external pullup for high state']}
findings=[]
for ref,data in native.items():
    for row,exp in zip(data['rows'],expected[ref]):
        findings.append(dict(ref=ref,pin=row['pin'],expected=exp,observed=f"{row['function']} on {row['net']}",identity_verdict='PASS',electrical_verdict='QUESTION' if (ref!='U_BUCK' and row['pin']==6) or (ref=='U_AUDIO' and row['pin']==3) else 'PASS'))
questions=[dict(id='Q-PWR-PULLUP',ref='U_PWR',pin=6,detail='PWR_EN is an open-drain RESET output and drives U_AUDIO MR_N. Dossier shows no pullup path. Provide net-local connectivity proving its pullup resistance, rail and resulting logic-high voltage; absence is not established.'),dict(id='Q-AUDIO-PULLUP',ref='U_AUDIO',pin=6,detail='AUDIO_EN is an open-drain RESET output. Dossier shows no pullup path. Provide net-local connectivity proving the pullup resistance and rail, and the receiving enable input voltage compatibility; absence is not established.')]
methods=['SHA-256 and byte-size verification of every envelope input before and after review.','pdftotext for page discovery and supporting function text; pdftoppm actual primary PDF pages rendered at 110/120 dpi, then view_image inspection before reading native dossiers.','Manufacturer top-view pin1 and CCW identities independently recorded before native comparison; bottom mechanical DSE view converted by y reflection only for source interpretation, not to excuse native winding.','Parsed every native dossier row; counted physical identities, pads, aliases and EP; recalculated signed polygon area and checked native coordinates against front-mounted zero-rotation translation.','Compared each of 18 function/net pairs and both supervisor instances; open-drain high-state evidence absent is QUESTION, not assumed defect.','Finite direct-argv subprocesses run using pipeline_runtime.run_stage with explicit cwd/environment; raw combined output and runtime receipts retained. Initial file reads used direct shell commands; no engineering subprocess or rendering was unbounded.','Reopened all archive regular members and verified exact digest and size, safe paths, no duplicates, links or recursive archives.']
evidence=dict(verdict='INCOMPLETE',subject=envelope['subject'],review_stage='pre-route',review_kind='pin',reviewer='fresh independent agent /root/rj45_pin_carrier_supply_clockground1',context='FRESH',coverage=['U_AUDIO','U_BUCK','U_PWR'],methods=methods,primary_documents=sources,figures={'AP63205':['PDF p1 Pin Assignments TOP VIEW','PDF p2 Figure 1 Typical Application Circuit','PDF p16 ordering and top-view marking','PDF p17 TSOT26 package outline and suggested pad layout'],'TPS3890':['PDF p3 section 6 Pin Configuration and Functions TOP VIEW','PDF p17 Figure 27 Recommended Layout','PDF p24 DSE0006A package outline 4220552/B bottom view','PDF p25 Example Board Layout']},measured_counts=native,findings=findings,questions=questions,per_ref_verdict={'U_AUDIO':'QUESTION','U_BUCK':'PASS','U_PWR':'QUESTION'},limitations='Limited pin-review group coverage only. No whole-board acceptance. Net names establish functional class, not passive values or actual voltage waveforms; open-drain pullups specifically require missing connectivity evidence.')
(OUT/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
lines=['review_stage: pre-route','review_kind: pin','reviewer: fresh independent agent /root/rj45_pin_carrier_supply_clockground1','context: FRESH','design_verdict: INCOMPLETE','order_verdict: DO-NOT-ORDER','board_sha256: e85b1461a82f3d3853c19fae694693816e31570d23d37019ef187d6428bea4ae','parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1','design_rules_sha256: e6d5b0b89efd79051b082f70b283ec7e85e1170ed11ddb94581744d26904c9c7','','Subject bindings above are immutable metadata, not reviewed conclusions. Exact envelope subject: '+json.dumps(envelope['subject']), '', 'Coverage is limited to U_AUDIO, U_BUCK and U_PWR. No whole-board acceptance. All package/pin identities pass; two missing electrical facts prevent SOUND. No definite pin/package defect was observed.','','Manufacturer figures were inspected before opening native dossiers. Both manufacturers show pin 1 at upper-left, pins 1/2/3 down the left and 4/5/6 up the right: CCW top view. All native parts are front-mounted at zero rotation; component-top +x right/+y down matches those figures directly without reflection. Native translations were independently checked. TPS PDF p24 is the bottom mechanical view (pin1 lower-left); reflecting its y coordinate produces p3 top view. This conversion was applied only to the manufacturer bottom drawing.','','Both packages have six distinct physical contacts, no EP, no fused identities and no aliases. TI DSE pin1 has an extended land; observed 0.8 × 0.25 mm at (-0.55,-0.5) and remaining 0.7 × 0.25 mm lands at x ±0.6 match PDF p25. AP63205 .95 mm pitch and three terminals per side match TSOT26; native pads are a library land-pattern variant rather than an exact copy of the suggested .7 × 1.0 mm lands. This does not alter physical pin identity.']
for ref in ['U_AUDIO','U_BUCK','U_PWR']:
    source=buck if ref=='U_BUCK' else tps
    data=native[ref]
    lines += ['',ref+' VERDICT: '+evidence['per_ref_verdict'][ref],f"Measured native pads: 6; distinct physical identities: 6; unique pad numbers: 6; EP: 0; aliases: 0; signed component-top polygon area: {data['signed_area_mm2_y_down']:.6f} mm² (negative for CCW with +y down).",'Primary PDF: '+source['path'],'Primary SHA-256: '+source['sha256'],'Figures: '+('; '.join(evidence['figures']['AP63205' if ref=='U_BUCK' else 'TPS3890']))]
    for f in [f for f in findings if f['ref']==ref]:lines.append(f"{ref} pin {f['pin']}: expected {f['expected']}; observed {f['observed']}. Identity PASS; net sanity {f['electrical_verdict']}.")
    for q in [q for q in questions if q['ref']==ref]:lines.append(q['id']+': '+q['detail'])
lines += ['', 'U_BUCK pin 1 on 5V_BUCK is correct for this fixed-output AP63205: p2 Figure 1 explicitly connects FB directly to 5 V output. The generic divider text is not grounds for a false failure. EN and VIN sharing the input rail is explicitly allowed. SW and BST retain distinct correct physical identities; bootstrap capacitor and inductor values are outside this pin-only evidence.', '', 'Pairwise supervisor comparison: all six physical pin positions and functions are identical. SENSE, CT and RESET use corresponding dedicated net classes; GND and VDD match. U_PWR MR_N is tied to its supply, whereas U_AUDIO MR_N is PWR_EN, the first supervisor’s open-drain RESET output. This is a plausible cascade, but its high-state pullup must be demonstrated. Both RESET outputs need valid pullup paths. The dossier cannot establish those paths or their absence, so these are QUESTION findings, not FAIL.', '', 'Methods:']+['- '+m for m in methods]+['','Delivery checks grade complete, honest handback. They do not promote INCOMPLETE engineering to acceptance.']
(OUT/'report.md').write_text('\n'.join(lines)+'\n')
shutil.copy2(ROOT/'pin-review-protocol.md',SCRATCH/'pin-review-protocol.md')
shutil.copy2(ROOT/'TASK.md',SCRATCH/'TASK.md')
shutil.copy2(RUN/'envelope.json',SCRATCH/'envelope-copy.json')
(SCRATCH/'methods.json').write_text(json.dumps(methods,indent=2)+'\n')
archive=OUT/'evidence.tar.gz'
members=[]
with tarfile.open(archive,'w:gz') as tar:
    files=[(p,'scratch/'+p.relative_to(SCRATCH).as_posix()) for p in sorted(SCRATCH.rglob('*')) if p.is_file() and not p.is_symlink() and p.name not in ['preflight.log','preflight-runtime.json']]
    files += [(OUT/'report.md','report.md'),(OUT/'evidence.json','evidence.json')]
    for p,name in files:
        assert not p.is_symlink();tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    seen=set()
    for member in tar.getmembers():
        p=Path(member.name)
        assert member.isfile() and not p.is_absolute() and '..' not in p.parts and member.name not in seen and not member.name.endswith(('.tar','.tar.gz'))
        seen.add(member.name);data=tar.extractfile(member).read();assert len(data)==member.size
        members.append(dict(path=member.name,size=len(data),sha256=sha(data)))
(OUT/'evidence-manifest.json').write_text(json.dumps(dict(archive_sha256=sha(archive.read_bytes()),archive_size=archive.stat().st_size,member_count=len(members),members=members),indent=2)+'\n')
(OUT/'result.json').write_text(json.dumps(dict(subject=envelope['subject'],checks={k:'PASS' for k in envelope['completion']['checks']},unresolved=[]),indent=2)+'\n')
print(json.dumps(dict(domain_verdict='INCOMPLETE',outputs=sorted(p.name for p in OUT.iterdir()),archive_members=len(members),questions=questions)))
