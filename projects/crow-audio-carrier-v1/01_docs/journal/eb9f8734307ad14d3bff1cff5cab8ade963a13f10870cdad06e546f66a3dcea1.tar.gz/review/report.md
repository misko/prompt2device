review_stage: pre-route
review_kind: pin
reviewer: fresh independent agent /root/rj45_pin_carrier_supply_clockground1
context: FRESH
design_verdict: INCOMPLETE
order_verdict: DO-NOT-ORDER
board_sha256: e85b1461a82f3d3853c19fae694693816e31570d23d37019ef187d6428bea4ae
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: e6d5b0b89efd79051b082f70b283ec7e85e1170ed11ddb94581744d26904c9c7

Subject bindings above are immutable metadata, not reviewed conclusions. Exact envelope subject: {"raw_sha256": "83fc99ca7ddd91d81c84802dec46944d110a6234780275d043cc12092e8b19da", "semantic_sha256": "1c5ab8a6ed1f97c38258c29e43e81abaf5925eb808e174a28f4f13a15ebfa44c"}

Coverage is limited to U_AUDIO, U_BUCK and U_PWR. No whole-board acceptance. All package/pin identities pass; two missing electrical facts prevent SOUND. No definite pin/package defect was observed.

Manufacturer figures were inspected before opening native dossiers. Both manufacturers show pin 1 at upper-left, pins 1/2/3 down the left and 4/5/6 up the right: CCW top view. All native parts are front-mounted at zero rotation; component-top +x right/+y down matches those figures directly without reflection. Native translations were independently checked. TPS PDF p24 is the bottom mechanical view (pin1 lower-left); reflecting its y coordinate produces p3 top view. This conversion was applied only to the manufacturer bottom drawing.

Both packages have six distinct physical contacts, no EP, no fused identities and no aliases. TI DSE pin1 has an extended land; observed 0.8 × 0.25 mm at (-0.55,-0.5) and remaining 0.7 × 0.25 mm lands at x ±0.6 match PDF p25. AP63205 .95 mm pitch and three terminals per side match TSOT26; native pads are a library land-pattern variant rather than an exact copy of the suggested .7 × 1.0 mm lands. This does not alter physical pin identity.

U_AUDIO VERDICT: QUESTION
Measured native pads: 6; distinct physical identities: 6; unique pad numbers: 6; EP: 0; aliases: 0; signed component-top polygon area: -1.187500 mm² (negative for CCW with +y down).
Primary PDF: projects/crow-audio-carrier-v1/02_parts/TPS389001DSER/TPS3890_SLVSD65A.pdf
Primary SHA-256: ee79599730e7606ba9718d9820b411020e3dcd9ff7d44572f8ee63fead15b9d0
Figures: PDF p3 section 6 Pin Configuration and Functions TOP VIEW; PDF p17 Figure 27 Recommended Layout; PDF p24 DSE0006A package outline 4220552/B bottom view; PDF p25 Example Board Layout
U_AUDIO pin 1: expected SENSE: monitored/divided voltage net; observed SENSE on ADC_SENSE. Identity PASS; net sanity PASS.
U_AUDIO pin 2: expected GND: ground; observed GND on GND. Identity PASS; net sanity PASS.
U_AUDIO pin 3: expected MR_N: high enables normal sensing; low forces reset; observed MR_N on PWR_EN. Identity PASS; net sanity QUESTION.
U_AUDIO pin 4: expected VDD: 1.5–5.5 V supply rail; observed VDD on 5V_LDO_HOLD. Identity PASS; net sanity PASS.
U_AUDIO pin 5: expected CT: timing-capacitor node; observed CT on AUDIO_CT. Identity PASS; net sanity PASS.
U_AUDIO pin 6: expected RESET_N: open-drain reset output with external pullup for high state; observed RESET_N on AUDIO_EN. Identity PASS; net sanity QUESTION.
Q-AUDIO-PULLUP: AUDIO_EN is an open-drain RESET output. Dossier shows no pullup path. Provide net-local connectivity proving the pullup resistance and rail, and the receiving enable input voltage compatibility; absence is not established.

U_BUCK VERDICT: PASS
Measured native pads: 6; distinct physical identities: 6; unique pad numbers: 6; EP: 0; aliases: 0; signed component-top polygon area: -4.322500 mm² (negative for CCW with +y down).
Primary PDF: projects/crow-audio-carrier-v1/02_parts/AP63205WU-7/AP63205_DS41326_Rev3-2.pdf
Primary SHA-256: ef99daa3789d835bc025dfcb4c605c5c2e6d3e7223e86d40b33e6b497ea5a722
Figures: PDF p1 Pin Assignments TOP VIEW; PDF p2 Figure 1 Typical Application Circuit; PDF p16 ordering and top-view marking; PDF p17 TSOT26 package outline and suggested pad layout
U_BUCK pin 1: expected FB: fixed 5 V output sense, directly connected to regulated output; observed FB on 5V_BUCK. Identity PASS; net sanity PASS.
U_BUCK pin 2: expected EN: VIN tie explicitly permitted; observed EN on 12V_BUCK_IN. Identity PASS; net sanity PASS.
U_BUCK pin 3: expected VIN: input power rail within 3.8–32 V; observed VIN on 12V_BUCK_IN. Identity PASS; net sanity PASS.
U_BUCK pin 4: expected GND: ground; observed GND on GND. Identity PASS; net sanity PASS.
U_BUCK pin 5: expected SW: switching-node net for output inductor; observed SW on BUCK_SW. Identity PASS; net sanity PASS.
U_BUCK pin 6: expected BST: bootstrap net, distinct from SW, for SW-referenced capacitor; observed BST on BUCK_BST. Identity PASS; net sanity PASS.

U_PWR VERDICT: QUESTION
Measured native pads: 6; distinct physical identities: 6; unique pad numbers: 6; EP: 0; aliases: 0; signed component-top polygon area: -1.187500 mm² (negative for CCW with +y down).
Primary PDF: projects/crow-audio-carrier-v1/02_parts/TPS389001DSER/TPS3890_SLVSD65A.pdf
Primary SHA-256: ee79599730e7606ba9718d9820b411020e3dcd9ff7d44572f8ee63fead15b9d0
Figures: PDF p3 section 6 Pin Configuration and Functions TOP VIEW; PDF p17 Figure 27 Recommended Layout; PDF p24 DSE0006A package outline 4220552/B bottom view; PDF p25 Example Board Layout
U_PWR pin 1: expected SENSE: monitored/divided voltage net; observed SENSE on PWR_SENSE. Identity PASS; net sanity PASS.
U_PWR pin 2: expected GND: ground; observed GND on GND. Identity PASS; net sanity PASS.
U_PWR pin 3: expected MR_N: high enables normal sensing; supply tie valid; observed MR_N on 5V_LDO_HOLD. Identity PASS; net sanity PASS.
U_PWR pin 4: expected VDD: 1.5–5.5 V supply rail; observed VDD on 5V_LDO_HOLD. Identity PASS; net sanity PASS.
U_PWR pin 5: expected CT: timing-capacitor node; observed CT on PWR_CT. Identity PASS; net sanity PASS.
U_PWR pin 6: expected RESET_N: open-drain reset output with external pullup for high state; observed RESET_N on PWR_EN. Identity PASS; net sanity QUESTION.
Q-PWR-PULLUP: PWR_EN is an open-drain RESET output and drives U_AUDIO MR_N. Dossier shows no pullup path. Provide net-local connectivity proving its pullup resistance, rail and resulting logic-high voltage; absence is not established.

U_BUCK pin 1 on 5V_BUCK is correct for this fixed-output AP63205: p2 Figure 1 explicitly connects FB directly to 5 V output. The generic divider text is not grounds for a false failure. EN and VIN sharing the input rail is explicitly allowed. SW and BST retain distinct correct physical identities; bootstrap capacitor and inductor values are outside this pin-only evidence.

Pairwise supervisor comparison: all six physical pin positions and functions are identical. SENSE, CT and RESET use corresponding dedicated net classes; GND and VDD match. U_PWR MR_N is tied to its supply, whereas U_AUDIO MR_N is PWR_EN, the first supervisor’s open-drain RESET output. This is a plausible cascade, but its high-state pullup must be demonstrated. Both RESET outputs need valid pullup paths. The dossier cannot establish those paths or their absence, so these are QUESTION findings, not FAIL.

Methods:
- SHA-256 and byte-size verification of every envelope input before and after review.
- pdftotext for page discovery and supporting function text; pdftoppm actual primary PDF pages rendered at 110/120 dpi, then view_image inspection before reading native dossiers.
- Manufacturer top-view pin1 and CCW identities independently recorded before native comparison; bottom mechanical DSE view converted by y reflection only for source interpretation, not to excuse native winding.
- Parsed every native dossier row; counted physical identities, pads, aliases and EP; recalculated signed polygon area and checked native coordinates against front-mounted zero-rotation translation.
- Compared each of 18 function/net pairs and both supervisor instances; open-drain high-state evidence absent is QUESTION, not assumed defect.
- Finite direct-argv subprocesses run using pipeline_runtime.run_stage with explicit cwd/environment; raw combined output and runtime receipts retained. Initial file reads used direct shell commands; no engineering subprocess or rendering was unbounded.
- Reopened all archive regular members and verified exact digest and size, safe paths, no duplicates, links or recursive archives.

Delivery checks grade complete, honest handback. They do not promote INCOMPLETE engineering to acceptance.
