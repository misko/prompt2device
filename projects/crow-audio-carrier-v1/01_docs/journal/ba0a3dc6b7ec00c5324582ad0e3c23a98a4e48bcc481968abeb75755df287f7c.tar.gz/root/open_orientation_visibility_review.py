from pathlib import Path
from datetime import datetime,timezone,timedelta
import json,sys,hashlib,shutil,tempfile
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;P=R/'projects/crow-audio-carrier-v1';name='rj45-orientation-visibility-review'
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
for old in ['rj45-launch-orientation-availability','rj45-carrier-placement-after-model1']:
 m=json.loads((N/(old+'-opened.json')).read_text());assert json.loads((Path(m['envelope']).parent/'attempt.json').read_text())['status']=='PASS'
D=Path(tempfile.mkdtemp(prefix=name+'-'));H=P/'06_build/handoffs/rj45-carrier-placement-after-model1';shutil.copytree(H/'context',D/'input')
def copy(src,rel):
 dst=D/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
for src in sorted((P/'04_kicad').glob('*')):
 if src.is_file():copy(src,'input/projects/crow-audio-carrier-v1/04_kicad/'+src.name)
for rel in ['skills/jlcpcb-fab/references/connector-orientation.md','skills/jlcpcb-fab/scripts/connector_orientation_gate.py','tests/t1_connector_orientation.py','tests/README.md']:
 src=R/rel
 if src.exists():copy(src,'input/'+rel)
shutil.copytree(P/'06_build/pre_route/orientation',D/'orientation')
for src in (P/'06_build/pre_route').glob('*model*'):
 if src.is_file():copy(src,'registration/'+src.name)
for src in Path(m['output_dir']).iterdir():
 if src.is_file() and src.name!='evidence.tar.gz':copy(src,'placement-handback/'+src.name)
for rel in ['01_docs/STATUS.md','06_build/agent_handoff.yaml']:
 copy(P/rel,'placement-handback/'+Path(rel).name)
copy(Path('/tmp/carrier-locator-implementation-availability-6c_4vwal/preflight.py'),'preflight.py')
now=datetime.now(timezone.utc);cut=now+timedelta(minutes=15);hard=now+timedelta(minutes=25)
(D/'TASK.md').write_text((N/'orientation_visibility_review_task.txt').read_text().format(cut=cut.isoformat(),hard=hard.isoformat()))
items=[]
for p in sorted(D.rglob('*')):
 if p.is_file():
  b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(D).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
s=subject_identity('orientation_visibility_dback',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
e=TaskEnvelope(schema=2,task_id=name,stage_id='KICAD-PLACEMENT',run_id=name,subject=s,executor='agent',execution_class='review_wait',recommended_agent_role='judgment',agent_role='judgment',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']})
o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),agent_id='/root/carrier_rj45_orientation_visibility_review',work_cutoff=cut.isoformat());(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2));print(len(items),'frozen inputs')
