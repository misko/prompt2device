import pathlib,json,hashlib,tarfile,io,datetime
S=pathlib.Path(__file__).parent;P=S.parents[3];O=S.parent/'outputs';O.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();E=json.loads((S.parent/'envelope.json').read_text());source=json.loads((S/'final-source-manifest.json').read_text());assert len(source)==30
methods=[dict(path='review/'+p.name,size=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(S.glob('*.py'))]
counts=dict(frozen_inputs=2791,author_archive_members=1920,supplement_files=6,additional_root_logs=2,final_source_files=30,source_native_primitives={'carrier':434,'pod':92},fitted={'carrier':333,'pod':32},fitted_smd={'carrier':306,'pod':31},netlist_pins={'carrier':985,'pod':103},npth={'carrier':21,'pod':6},native_ground_components={'carrier':[556,1,1],'pod':[30,3]},original_drc_rows={'carrier':505,'pod':40},fresh_drc_rows={'carrier':505,'pod':40},unattributed_rows=0,independent_tests=91,hostile_cases=25,retained_failed_author_stages=25,carrier_regions=83,carrier_new_full_ground_pads=14,carrier_native_full_ground_pads=33)
evidence=dict(schema=1,verdict='SOUND',subject=E['subject'],scope='Exact final supplemented source composition plus existing candidate4 native construction; no route/placement/service/release acceptance',original_composition=dict(verdict='DEFECTIVE',files=json.loads((S/'source-manifest.json').read_text()),finding='38 OWED exceeds unchanged 37 ceiling; pod ADR0009 lacks bound provenance'),final_composition=dict(verdict='SOUND',files=source),supplement=dict(manifest_sha256='6d51a07367f0739d6e82e7ed9ebcb79c421f09f1692ac3429d43159abf457bfa',files=json.loads((S/'supplement/verified-after.json').read_text()),original_text_preserved=True,physical_bound_grade='ESTIMATED',routed_evaluator_present=False),native_boards={k:json.loads((S/f'{k}-independent-native.json').read_text())['board_sha256'] for k in ['carrier','pod']},methods=methods,measured_counts=counts,findings=[dict(id='ORIGINAL-BOUND-PROVENANCE',status='DEFECTIVE_ORIGINAL_RESOLVED_IN_EXACT_SUPPLEMENT',detail='Original 38 OWED; final 37 OWED with one new honest ESTIMATED bound and no threshold change'),dict(id='ROUTING-OWED',status='OWED',detail='67 owned dangling seeds, 478 opens, exact per-row owners and polygon attribution retained; analog paths and listed ground returns unfinished'),dict(id='ORDINARY-PLACEMENT',status='OWED',detail='Nine actual P-OUT connector courtyard reports remain; current J9 service/registered orientation and mechanical qualification required'),dict(id='ASSEMBLY-RELEASE',status='OWED',detail='Population MANIFEST, order-preview and final release are not satisfied'),dict(id='ENTRY-CHECKER-SCOPE',status='MEASURED_LIMITATION',detail='Entry-only checker accepts GND width mutation; separate independent launch checks verify current exact invariant')],coverage_ledger=['review/independent-graph-audit.json','review/independent-closure.json','review/carrier-independent-native.json','review/pod-independent-native.json','review/carrier-independent-detail.json','review/pod-independent-detail.json','review/independent-final-checks.json','review/metadata-integrity.json','review/independent-hostile-controls.json','review/retained-failures.json'],source_adoption_performed=False,engineering_finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
(O/'evidence.json').write_text(json.dumps(evidence,indent=2));body=(S/'report-body.md').read_text();body+='\n\n| Accepted repository path | Final SHA256 |\n|---|---|\n'+'\n'.join('| '+r['path']+' | `'+r['sha256']+'` |' for r in source)+'\n';(O/'report.md').write_text(body)
result=dict(subject=E['subject'],checks={'inputs-verified':'PASS','review-complete':'PASS','evidence-complete':'PASS'},unresolved=[]);(O/'result.json').write_text(json.dumps(result,indent=2))
files={}
def add(p,n):
 assert p.is_file() and not p.is_symlink();assert n not in files;files[n]=p.read_bytes()
for p in sorted(S.iterdir()):
 if p.is_file() and p.suffix not in ['.gz','.zip','.tar'] and not p.name.startswith(('package_review.log','package_review.runtime','delivery_preflight')):add(p,'review/'+p.name)
for p in sorted((S/'supplement').iterdir()):
 if p.is_file():add(p,'review/supplement/'+p.name)
for p in sorted((P/'author-evidence/logs').iterdir()):
 if p.is_file():add(p,'retained/'+str(p.relative_to(P)))
for p in sorted((P/'author-evidence/views').iterdir()):
 if p.is_file():add(p,'retained/'+str(p.relative_to(P)))
for folder in ['decisions','root']:
 for p in sorted((P/folder).rglob('*')):
  if p.is_file() and p.suffix in ['.md','.json','.log','.txt']:add(p,'retained/'+str(p.relative_to(P)))
for r in source:add(S/'work'/r['path'],'accepted-source/'+r['path'])
for name in ['source-pre-post-manifest.json','carrier-drc.json','pod-drc.json','carrier-drc-final-classification.json','pod-drc-final-classification.json']:
 p=P/'author-evidence'/name
 if p.exists():add(p,'retained/author-evidence/'+name)
for rel in ['author-delivery/report.md','author-delivery/evidence.json','author-delivery/evidence-manifest.json','original-input/CLAUDE.md','original-input/tests/README.md','original-input/skills/pcb-design/SKILL.md','TASK.md']:
 p=P/rel
 if p.exists():add(p,'authority/'+rel)
add(S.parent/'envelope.json','authority/envelope.json')
for name in ['evidence.json','report.md','result.json']:add(O/name,'handback/'+name)
arc=O/'evidence.tar.gz';members=[]
with tarfile.open(arc,'w:gz',compresslevel=1) as t:
 for name,b in sorted(files.items()):
  assert not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts and not name.endswith(('.tar.gz','.zip','.tar','.tgz'));i=tarfile.TarInfo(name);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b));members.append(dict(path=name,size=len(b),sha256=sha(b)))
expected={r['path']:r for r in members};seen=set()
with tarfile.open(arc,'r:gz') as t:
 for i in t:
  assert i.isfile() and i.name not in seen and not i.issym() and not i.islnk();seen.add(i.name);b=t.extractfile(i).read();assert dict(path=i.name,size=len(b),sha256=sha(b))==expected[i.name]
assert len(seen)==len(members);data=arc.read_bytes();manifest=dict(archive_sha256=sha(data),archive_size=len(data),member_count=len(members),members=members);(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2));print('verdict SOUND; archive',manifest['archive_sha256'],'bytes',len(data),'members',len(members),'all reopened')
