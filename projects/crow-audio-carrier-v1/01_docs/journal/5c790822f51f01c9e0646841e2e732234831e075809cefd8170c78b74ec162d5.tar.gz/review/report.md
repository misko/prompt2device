review_stage: pre-route
review_kind: pin
reviewer: fresh agent /root/rj45_pin_carrier_rectifiers_mountedframe1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

subject.raw_sha256: 8ca61cdfa828d55e100a2622527d3167977e7b08eee28bb75fc2b61cde88ca4d
subject.semantic_sha256: ab79b176f9b3a15f62813cb7237d8a96e3882477eab719519d36bbb2b9a1ae4f

All six commissioned references PASS. This is limited group coverage only, not whole-board acceptance. Order remains DO-NOT-ORDER. The three board/parts/rules bindings above are immutable supplied metadata, not independently reviewed whole-artifact conclusions.

Independent figure-derived expectations and coordinate method

For all front-mounted parts, component-top uses x-right/y-down and no reflection of native relative coordinates; inverse native KiCad rotation and translation checked explicitly. All coordinate errors are 0 mm at dossier precision.
Two collinear terminals establish no winding. No manufacturer numeric pin labels exist for these parts; project pad numbers were checked as positive/negative or cathode/anode physical identities, not claimed as manufacturer numbering.
Panasonic underside drawing: negative up, positive down at chamfered end. Reflect y to form top view, then rotate counterclockwise 90 degrees to positive-left/negative-right. Top negative-semicircle marking independently reaches the same result by 180-degree rotation. Diode top marking and outline: cathode band left, anode right; no mirror used. Bottom diode photographs were distinguished and not substituted for top views.

Native census: 12 pads / 12 unique artifact identities / 12 physical terminal identities across six references; zero EPs and zero fused aliases. All six explicitly front mounted. No missing or collapsed identity. No CW/CCW conclusion is possible or required for these two-terminal collinear packages.

C_FILT1_470U — VERDICT: PASS
Measured: native pads 2; unique pad identities 2; physical terminals 2; EP 0; fused aliases 0.
Primary: projects/crow-audio-carrier-v1/02_parts/EEEFK1A471P/Panasonic_FK_ABA0000C1181_20260210.pdf; SHA-256 b36857d089adaddf3042b33bf11d0f7d83bf70734e983f33b7827152e11854e3; figures: p1 Marking and Dimensions; p2 Land / Pad pattern, Standard products size F; p3 Characteristics list EEEFK1A471P.
C_FILT1_470U pin 1 (POSITIVE): expected Positive terminal on positive rail vs observed POSITIVE on FILT1P, component-top W at [-3.55, 0.0] mm; native [91.55, 55.3] mm. PASS.
C_FILT1_470U pin 2 (NEGATIVE): expected Negative marked terminal on ground vs observed NEGATIVE on GND, component-top E at [3.55, 0.0] mm; native [84.45, 55.3] mm. PASS.
Expected 4.0 x 2.0 mm lands, 3.1 mm gap and 7.1 mm pitch; observed exact match.
Package/polarity: two opposed terminals, no EP and no collapsed identities. The datasheet assigns physical polarity rather than numeric pins; pad 1 is an artifact convention, with no manufacturer pin-1 corner. Mounted-frame check and physical polarity mapping PASS.

C_FILT2_470U — VERDICT: PASS
Measured: native pads 2; unique pad identities 2; physical terminals 2; EP 0; fused aliases 0.
Primary: projects/crow-audio-carrier-v1/02_parts/EEEFK1A471P/Panasonic_FK_ABA0000C1181_20260210.pdf; SHA-256 b36857d089adaddf3042b33bf11d0f7d83bf70734e983f33b7827152e11854e3; figures: p1 Marking and Dimensions; p2 Land / Pad pattern, Standard products size F; p3 Characteristics list EEEFK1A471P.
C_FILT2_470U pin 1 (POSITIVE): expected Positive terminal on positive rail vs observed POSITIVE on FILT2P, component-top W at [-3.55, 0.0] mm; native [91.55, 84.7] mm. PASS.
C_FILT2_470U pin 2 (NEGATIVE): expected Negative marked terminal on ground vs observed NEGATIVE on GND, component-top E at [3.55, 0.0] mm; native [84.45, 84.7] mm. PASS.
Expected 4.0 x 2.0 mm lands, 3.1 mm gap and 7.1 mm pitch; observed exact match.
Package/polarity: two opposed terminals, no EP and no collapsed identities. The datasheet assigns physical polarity rather than numeric pins; pad 1 is an artifact convention, with no manufacturer pin-1 corner. Mounted-frame check and physical polarity mapping PASS.

C_HOLD1 — VERDICT: PASS
Measured: native pads 2; unique pad identities 2; physical terminals 2; EP 0; fused aliases 0.
Primary: projects/crow-audio-carrier-v1/02_parts/EEEFK1A471P/Panasonic_FK_ABA0000C1181_20260210.pdf; SHA-256 b36857d089adaddf3042b33bf11d0f7d83bf70734e983f33b7827152e11854e3; figures: p1 Marking and Dimensions; p2 Land / Pad pattern, Standard products size F; p3 Characteristics list EEEFK1A471P.
C_HOLD1 pin 1 (POSITIVE): expected Positive terminal on positive rail vs observed POSITIVE on 5V_LDO_HOLD, component-top W at [-3.55, 0.0] mm; native [55.45, 83.9] mm. PASS.
C_HOLD1 pin 2 (NEGATIVE): expected Negative marked terminal on ground vs observed NEGATIVE on GND, component-top E at [3.55, 0.0] mm; native [62.55, 83.9] mm. PASS.
Expected 4.0 x 2.0 mm lands, 3.1 mm gap and 7.1 mm pitch; observed exact match.
Package/polarity: two opposed terminals, no EP and no collapsed identities. The datasheet assigns physical polarity rather than numeric pins; pad 1 is an artifact convention, with no manufacturer pin-1 corner. Mounted-frame check and physical polarity mapping PASS.

C_HOLD2 — VERDICT: PASS
Measured: native pads 2; unique pad identities 2; physical terminals 2; EP 0; fused aliases 0.
Primary: projects/crow-audio-carrier-v1/02_parts/EEEFK1A471P/Panasonic_FK_ABA0000C1181_20260210.pdf; SHA-256 b36857d089adaddf3042b33bf11d0f7d83bf70734e983f33b7827152e11854e3; figures: p1 Marking and Dimensions; p2 Land / Pad pattern, Standard products size F; p3 Characteristics list EEEFK1A471P.
C_HOLD2 pin 1 (POSITIVE): expected Positive terminal on positive rail vs observed POSITIVE on 5V_LDO_HOLD, component-top W at [-3.55, 0.0] mm; native [59.55, 95.0] mm. PASS.
C_HOLD2 pin 2 (NEGATIVE): expected Negative marked terminal on ground vs observed NEGATIVE on GND, component-top E at [3.55, 0.0] mm; native [52.45, 95.0] mm. PASS.
Expected 4.0 x 2.0 mm lands, 3.1 mm gap and 7.1 mm pitch; observed exact match.
Package/polarity: two opposed terminals, no EP and no collapsed identities. The datasheet assigns physical polarity rather than numeric pins; pad 1 is an artifact convention, with no manufacturer pin-1 corner. Mounted-frame check and physical polarity mapping PASS.

D_BUCK_IN — VERDICT: PASS
Measured: native pads 2; unique pad identities 2; physical terminals 2; EP 0; fused aliases 0.
Primary: projects/crow-audio-carrier-v1/02_parts/US1B-13-F/Diodes_US1A_US1M_DS16008_Rev11-2.pdf; SHA-256 d50b2773c0300d97a77f5125419098c8130ecaf967202a44be2b182de8a15c1f; figures: p1 Top View / Bottom View and Marking Information; p4 Package Outline Dimensions and Suggested Pad Layout.
D_BUCK_IN pin 1 (K): expected Cathode at marked band on downstream feed rail vs observed K on 12V_BUCK_IN, component-top W at [-2.0, 0.0] mm; native [26.0, 60.0] mm. PASS.
D_BUCK_IN pin 2 (A): expected Anode opposite the band on upstream supply rail vs observed A on 12V_PROTECTED, component-top E at [2.0, 0.0] mm; native [26.0, 56.0] mm. PASS.
Expected suggested 2.5 x 1.7 mm lands, 1.5 mm gap and 4.0 mm pitch; observed 2.5 x 1.8 mm lands with exact gap and pitch. Additional 0.1 mm transverse width preserves terminal identity, separation and contact; no pin/package defect.
Package/polarity: two opposed terminals, no EP and no collapsed identities. The datasheet assigns physical polarity rather than numeric pins; pad 1 is an artifact convention, with no manufacturer pin-1 corner. Mounted-frame check and physical polarity mapping PASS.

D_HOLD — VERDICT: PASS
Measured: native pads 2; unique pad identities 2; physical terminals 2; EP 0; fused aliases 0.
Primary: projects/crow-audio-carrier-v1/02_parts/B340A-13-F/B340A_DS30891_Rev19-2.pdf; SHA-256 453cbd34d996482abd07ac694c4e2d812d26b1d679d05ee325acc5c3eeb79917; figures: p1 Top View / Bottom View and Marking Information; p6 Package Outline Dimensions and Suggested Pad Layout.
D_HOLD pin 1 (K): expected Cathode at marked band on downstream feed rail vs observed K on 5V_LDO_FEED, component-top W at [-2.0, 0.0] mm; native [48.4, 58.1] mm. PASS.
D_HOLD pin 2 (A): expected Anode opposite the band on upstream supply rail vs observed A on 5V_BUCK, component-top E at [2.0, 0.0] mm; native [52.4, 58.1] mm. PASS.
Expected suggested 2.5 x 1.7 mm lands, 1.5 mm gap and 4.0 mm pitch; observed 2.5 x 1.8 mm lands with exact gap and pitch. Additional 0.1 mm transverse width preserves terminal identity, separation and contact; no pin/package defect.
Package/polarity: two opposed terminals, no EP and no collapsed identities. The datasheet assigns physical polarity rather than numeric pins; pad 1 is an artifact convention, with no manufacturer pin-1 corner. Mounted-frame check and physical polarity mapping PASS.

Instance symmetry: All four capacitors preserve pad 1 POSITIVE to a positive rail and pad 2 NEGATIVE to GND. FILT1P and FILT2P form structurally identical filter instances; C_HOLD1 and C_HOLD2 both connect to 5V_LDO_HOLD/GND despite different rotations. Both SMA rectifiers use pad 1 K on downstream feed and pad 2 A on upstream supply.

Electrical sanity uses the supplied net roles: FILT1P/FILT2P and 5V_LDO_HOLD are positive-rail names relative to GND; D_BUCK_IN conducts from 12V_PROTECTED (A) to 12V_BUCK_IN (K); D_HOLD conducts from 5V_BUCK (A) to 5V_LDO_FEED (K). The map does not place either cathode on its upstream source, and all capacitor negative terminals are grounded. Circuit operating limits and provenance of rail names are outside this pin-review scope.

No unresolved findings. No electrical or package defect found in this commissioned group. No live engineering source was read or modified. Native dossier counts are measured from the supplied frozen dossiers, not from a live board.

Evidence retention: all eight inspected figure images, native dossiers, exact primary PDF digests, independent derivation, measurements, scripts and raw/runtime records are in evidence.tar.gz. Full PDFs remain bound in the frozen input packet. Input hashes verified before and after review; artifact archive reopened member by member. Delivery-check PASS denotes an honest complete handback, not permission to order.
