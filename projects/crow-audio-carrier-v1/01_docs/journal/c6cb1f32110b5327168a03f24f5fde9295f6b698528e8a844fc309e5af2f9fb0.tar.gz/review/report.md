review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_clock_reset_mountedframe1
context: CONTINUED-INDEPENDENT — original fresh pin reviewer plus narrowly requested native timing facts
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
release_scope: FIRST-ARTICLE-ONLY
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7
raw_sha256: b5390e268fbe6aae1c6473f5b3751257fccf22500ef5ae8c8447e1fe8535368c
semantic_sha256: e76082a564e654d65c2a0d2467dd0f112671cce2605be796ca8fa3121df6282e

All commissioned references U_CLK, U_RST1 and U_RST2 PASS the limited pre-route pin review. The new native timing endpoints resolve original Q1. This is not whole-board, route, manufacture, timing-performance or order acceptance. R_RST_T and C_RST_T are supporting facts, not an expansion of the commissioned group.

Continuation provenance: original task rj45-pin-carrier-clock-reset-mountedframe1 completed an independent fresh review with INCOMPLETE only for timing-network context. Its immutable report SHA-256 is 3f1c045fbe63df645d6c2d33a6dff1cfa60843b4b68a766e8d63e27781e059c2. Original evidence archive SHA-256 is 41da62400bcc59e2114d92cc92e0f22bc2af71276ffe0b8187e1c82b71bbb702; the supplied previous-closeout.json binds the later coordinator closeout archive b606a80f07722b6993e01ccc14be3e6c36eac3becf046e3baeb88627e208ca40. Original subject raw=47fabbbe2be37cf731bb0d35722ea44927020eaeca0471bf6e3f1f88e70e6820, semantic=d43e737695c86bd2850abd52fc7e0a30628ec85c28092ca217d62332819f0b32. The new envelope subject above binds the augmented review packet; the board/parts/rules bindings remain unchanged.

Inherited proof, explicitly not repeated: all original IC package figure observations, native physical identity counts, CCW winding, pin-1 positions, function assignments and symmetry checks. Original dossier hashes remain U_CLK=a83dc75f6f008611ee89ada8435e11938fea99d89e633442192ee611d5085a1a, U_RST1=5b4367a4fd57d59270f2babd4e832c1a475187c418be55f27f75f413252d3493, U_RST2=ab41a044054ea6e1c408c30addd3de59d24972b5f3a13a81b6819ecfb8d46e2c. Exact original IC primary PDF hashes also remain unchanged. Prior inspected PNGs, measurements and original findings are retained as clearly labeled inherited evidence. No old output was edited, and no live design source was read. Context is continued independent review, not a newly fresh agent, notwithstanding the envelope's generic context_mode field.

| Ref | Verdict | Native pads / physical identities | Expected versus observed package |
|---|---|---|---|
| U_CLK | PASS | 8 / 8 | DCU VSSOP, 4 leads per side, pin 1 upper-left, 1..4 down left and 5..8 up right, CCW, 0.5 mm pitch; matches |
| U_RST1 | PASS | 3 / 3 | DBZ SOT23-3, pins 1 upper-left/2 lower-left/3 center-right, CCW, 1.9 mm 1-to-2 spacing; matches |
| U_RST2 | PASS | 8 / 8 | DCT SSOP, 4 leads per side, pin 1 upper-left, 1..4 down left and 5..8 up right, CCW, 0.65 mm pitch; matches |

All three original ICs are front-mounted at native rotation 0, with component-top +x right/+y down; only translation was needed. Expected and observed EP counts are zero for each. No fused identities, aliases, missing pads or duplicate pad identities were found. Signed native component-top polygon areas are respectively -4.2, -1.78125 and -6.63 mm2, with zero coordinate conversion residual. Comparison used the selected manufacturer's TOP views without any mirror. U_RST1 dossier N/S side labels for pins 1/2 do not change their actual left-side coordinates.

U_CLK VERDICT: PASS
Primary TI SCES366L SHA-256 d541afbccf6270522f5ba33b86ca31da0ec6bbf497c0d1f8ba265e9ac2e1faec: inherited PDF p.3 DCU Top View/Pin Functions, p.19 DCU0008A outline.
Expected/observed pin functions and net kinds: 1=1A input/MCH_MCLK; 2=3Y output/FSYNC_BUF; 3=2A input/MCH_BCLK; 4=GND/GND; 5=2Y output/BCLK_BUF; 6=3A input/MCH_FSYNC; 7=1Y output/MCLK_BUF; 8=VCC/3V3_ADC. All PASS. Channel symmetry is preserved: 1->7 MCLK, 3->5 BCLK, 6->2 FSYNC.

U_RST1 VERDICT: PASS
Primary TI SBVS193D SHA-256 5f9a9581d1b8df7f0b2a480a71dac6993c9aba3b05767ad22641d151434f5dd3: inherited PDF p.5 TPS3839 DBZ Top View/Pin Functions, p.28 DBZ0003A outline.
Expected/observed: 1=ground/GND; 2=active-low push-pull RESET output/POR_N; 3=positive monitored VDD/3V3_ADC. All PASS.

U_RST2 VERDICT: PASS
Primary TI SCES586E SHA-256 7248ef0ff62af4d2da172bb2900f0f1f136a6ae90109a6485228e01269fa1c1d: inherited PDF p.3 Figure 4-1/Table 4-1, p.23 DCT0008A outline, p.13 Table 7-1; newly viewed PDF p.1 Description/Logic Diagram and p.14 Figure 8-1.
Expected/observed: 1=A held low/GND; 2=B held high/3V3_ADC; 3=active-low CLR/POR_N; 4=ground/GND; 5=positive Q pulse/RESET_PULSE_H; 6=Cext/RESET_C; 7=Rext/Cext/RESET_RC; 8=VCC/3V3_ADC. All PASS. Original proof established that rising CLR triggers the pulse with A low and B high. U_RST1.2 and U_RST2.3 share POR_N and the same power domain. There are no duplicate same-part instances within this group; all three buffer channels and reset-chain polarity were checked.

New Q1 resolution: C_RST_T.1=RESET_C=U_RST2.6; C_RST_T.2=RESET_RC=U_RST2.7=R_RST_T.2; R_RST_T.1=3V3_ADC=U_RST2.8. Thus the actual supplied passive endpoints implement Cext-to-Rext/Cext capacitance and Rext/Cext-to-VCC resistance. No conflicting attachment is present in the supplied timing network.
The primary requires the capacitor between IC pins 6 and 7, with pin 6 going only to the external capacitor, and the resistor from pin 7 to VCC. The supplied C_RST_T and R_RST_T endpoints establish these functional connections. This closes the original requested connection question, without making a pulse-duration or global net-census claim.

New supporting physical checks:
R_RST_T: 2 native pads / 2 distinct terminal identities, 0 EP, 0 fused aliases. Native front mount rotation 90 degrees maps local (-0.51,0)/(+0.51,0) mm to board (122.6,76.51)/(122.6,75.49) mm with zero residual. Pad 1 on 3V3_ADC, pad 2 on RESET_RC. Yageo exact RC0402FR-07100KL primary SHA-256 e42aa2b39be7476fef25efbe4656acbbc246d2b9b625d64db6b46e0f5e34d7af, PDF p.1 dimensional image and specifications: 0402 1.0 x 0.5 mm two-terminal 100 kohm resistor, 1%, nonpolar; mapping PASS.
C_RST_T: 2 native pads / 2 distinct terminal identities, 0 EP, 0 fused aliases. Native front mount rotation 90 degrees maps local (-0.775,0)/(+0.775,0) mm to board (122.6,73.975)/(122.6,72.425) mm with zero residual. Pad 1 on RESET_C, pad 2 on RESET_RC. Samsung exact CL10B224KA8NNNC primary SHA-256 00c61e295f03297000302fb2c7b2e5d5557edba7ca3dd0989e872718e9aa89c2, PDF p.1 Structure & Dimension: 0603 1.6 x 0.8 mm 220 nF/25 V X7R nonpolar MLCC, opposing end terminations; mapping PASS.
For these two-terminal, collinear passives, winding is not applicable. Their primary figures provide no polarity or unique pin-1 end; terminal interchange is valid, without collapsing either physical identity. No unsupported CW/CCW finding is applied. Author verification notes and capacitor derating assumptions in dossiers were not used as evidence.

Measured coverage: 19 original commissioned IC pads/19 identities inherited; 4 supporting passive pads/4 identities newly checked. Every augmented envelope input was verified before and after review. All four newly inspected primary PNGs and the inherited physical proof are archived. Archive regular members were reopened and SHA-256/size checked; final supplied preflight validates exact outputs, subject and unchanged writer scope. Delivery PASS means complete handback. The original INCOMPLETE remains immutable; this report resolves it only for the exact unchanged original inputs plus supplied new facts.
