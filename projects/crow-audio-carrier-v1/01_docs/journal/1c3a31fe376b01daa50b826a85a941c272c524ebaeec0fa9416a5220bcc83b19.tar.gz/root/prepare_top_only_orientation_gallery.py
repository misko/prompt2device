from pathlib import Path
import json,hashlib,pcbnew
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
rows=[];sections=[]
for label,slug,expected in [('Carrier','crow-audio-carrier-v1',306),('Pod','crow-mic-pod-v3',31)]:
 P=R/'projects'/slug;bp=next((P/'04_kicad').glob('*.kicad_pcb'));b=pcbnew.LoadBoard(str(bp));sm=[f for f in b.GetFootprints() if f.GetAttributes()&pcbnew.FP_SMD and not f.IsDNP()];assert len(sm)==expected and all(f.GetLayer()==pcbnew.F_Cu for f in sm)
 O=P/'06_build/pre_route/orientation';r=json.loads((O/'orientation_receipt.json').read_text());assert r['verdict']=='PASS' and not r['failures'];assert hashlib.sha256(bp.read_bytes()).hexdigest()==r['observed_board_sha256']
 sec=[f'## {label}',f"Subject: `{r['subject_sha256']}`. All {expected} fitted SMD components are on top."]
 for group in r['review_groups']:
  pass
 for key,h in sorted(r['evidence'].items()):
  p=O/key;assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==h;name=p.stem.replace('_',' — ');sec.append(f'![{label} {name}]({p})')
 sections.append('\n\n'.join(sec));rows.append({'project':slug,'subject':r['subject_sha256'],'board_sha256':r['observed_board_sha256'],'receipt':str(O/'orientation_receipt.json'),'images':r['evidence'],'fitted_smd_top':expected})
out=R/'projects/crow-roof-array-v1/06_build/top-only-connector-review.md';out.write_text('''# Current top-only connector orientation review

Review the mouth, top mounting side, latch/keying and cable approach in every image below. Carrier J1–J4 face north, J5–J8 south, and power J9 west; pod J1 faces north. The repeated carrier RJ45 rows each have one exact-model/pose representative, with every instance separately machine-checked.

This is the current enlarged carrier and top-only assembly scene. Carrier power J9 sits 3.08 mm inboard of the west board edge; check the shown cable approach. Green arrows show the intended outward direction. Where rear features are occluded, flag anything needed for the orientation judgment that cannot be seen.

This decision covers connector orientation. Physical cable fit, latch operation and service qualification remain first-article obligations; routing and release checks are still pending.

'''+ '\n\n'.join(sections)+'\n');(N/'top-only-connector-review-manifest.json').write_text(json.dumps({'gallery':str(out),'gallery_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'boards':rows,'approval':'PENDING explicit human decision'},indent=2)+'\n');print(out)
