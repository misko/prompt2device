review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_tvs_clockground1 (actual fresh agent)
context: FRESH
design_verdict: INCOMPLETE
order_verdict: DO-NOT-ORDER
board_sha256: e85b1461a82f3d3853c19fae694693816e31570d23d37019ef187d6428bea4ae
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: e6d5b0b89efd79051b082f70b283ec7e85e1170ed11ddb94581744d26904c9c7

Limited coverage: D_IN and D_QIN_GS only; no whole-board acceptance. The three immutable hashes above are subject metadata, not independently reviewed conclusions.

Independent manufacturer derivation preceded reading the native dossier tables. Inspected actual pdftoppm images: Littelfuse SMBJ v4 (2025-07-04), PDF pages 1, 5, 6; Diodes DS18004 Rev.38-2, PDF pages 1, 4. Supplementary text extraction was used only for document navigation and electrical descriptions. No schematic, live project, historical review or author rationale was used as engineering evidence; dossier verification notes were not adopted.

D_IN — VERDICT: PASS
Primary SHA-256: d7df155be4b1f612085401e8c946f065e284d65a0e7de22b9225a7b73946e51b.
Figures: page 1 Functional Diagram; page 5 Dimensions, DO-214AA (SMB J-Bend); page 6 Part Marking System and Part Numbering System.
Manufacturer expectation: SMBJ15A is the unidirectional variant (C designates bidirectional). The marked body top has a cathode band adjacent to one of two opposed terminals. Page 5 shows the band at left; page 6 shows the same band at top, equivalent by 90-degree rotation. Neither is a bottom-view pin numbering diagram. The underside terminal photo on page 1 is not used to infer top-view polarity. No numeric pin labels or EP are specified; artifact numbers 1=K and 2=A name the two independently identified terminals, not manufacturer numeric labels. No CW/CCW winding can be defined for two collinear terminals.
Measured: 2 native pads, 2 unique pad numbers, 2 physical terminal identities, 0 EP, 0 fused aliases, 1 instance. Explicit front/F.Cu mounting and component-top +x right/+y down frame require no reflection.
D_IN pin 1 (K): expected band-side cathode on the positive protected rail; observed west (-2.15,0), native (30.649999,82.300000), 12V_PROTECTED.
D_IN pin 2 (A): expected opposite-end anode to ground for a unidirectional positive-rail shunt TVS; observed east (+2.15,0), native (34.949999,82.300000), GND.
Two 2.5x2.3 mm pads separated by 4.3 mm center-to-center preserve two distinct contacts. Observed left-K/right-A matches the marked top by rotation only. The dossier's n/a winding is appropriate; no mirror was introduced.

D_QIN_GS — VERDICT: QUESTION
Primary SHA-256: 0fbd7d137524820f0160594065cbceb8c6b3188757c328416d08fceb7418202f.
Figures: page 1 SOD123 Top View and Marking Information; page 4 Package Outline Dimensions and Suggested Pad Layout.
Manufacturer expectation: SOD123 has two opposed leads; page 1 marking illustration places the cathode band at the left end and the opposite end is anode. Page 4 shows the two lead ends and two suggested lands, with no exposed pad. No numeric manufacturer pin labels exist in these figures. Artifact numbers 1=K, 2=A denote the physical terminals; pin 1 is an end, not a multi-pin package corner. The page 1 top view and printed marking establish body-top interpretation; page 4 side/end projections establish lead geometry, not an alternate mirrored numbering. Two collinear terminals establish no winding.
Measured: 2 native pads, 2 unique pad numbers, 2 physical terminal identities, 0 EP, 0 fused aliases, 1 instance. Explicit front/F.Cu mounting and component-top +x right/+y down frame require no reflection.
D_QIN_GS pin 1 (K): expected band-side cathode; observed west (-1.65,0), native (40.750000,71.000000), 12V_PROTECTED.
D_QIN_GS pin 2 (A): expected opposite-end anode; observed east (+1.65,0), native (44.050000,71.000000), Q_IN_GATE.
Two 0.9x1.2 mm pads separated by 3.3 mm center-to-center preserve two distinct contacts. Geometry/polarity assignment matches the manufacturer marked top; no mirror is required and n/a winding is correct.
QUESTION Q1: This connection is consistent with a negative-VGS clamp for a high-side P-channel Q_IN whose source is 12V_PROTECTED. The supplied packet does not establish Q_IN channel type or its source net. Required missing fact: a digest-bound Q_IN pin dossier or equivalent primary circuit connection evidence identifying channel type and source=12V_PROTECTED. Without that fact, the gate-source function-to-net sanity check cannot be completed. This is missing context, not a demonstrated reversed diode.

Instance symmetry: both commissioned refs were individually checked. They are different parts with different roles, one instance each; duplicate-part pairwise comparison is not applicable. Both retain band-side K on west pad 1 and A on east pad 2; their different anode nets reflect the stated differing roles, with Q1 still unresolved.

No electrical/package defect was demonstrated. Group verdict remains INCOMPLETE because Q1 prevents all commissioned refs from passing. Voltage-clamp margin, transistor ratings, transient energy, assembly graphics, routing and whole-board behavior are outside this supplied pin-review evidence.
