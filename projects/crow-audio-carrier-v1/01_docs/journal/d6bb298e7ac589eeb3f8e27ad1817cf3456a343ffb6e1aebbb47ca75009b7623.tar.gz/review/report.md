review_stage: pre-route
review_kind: topology
reviewer_identity: /root/carrier_rj45_native_carrier_topology_cm8ncenter1
context: FRESH
date: 2026-09-15T17:14:33.457449+00:00
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
netlist_sha256: 1cec3ea0b47b6f0e715b769abed4253ccc2aaf8cbfa6808685f74539df8f2805
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: e6d5b0b89efd79051b082f70b283ec7e85e1170ed11ddb94581744d26904c9c7
schematic_pdf_sha256: b2a1072151304d4eee9216d853004f9ac80731fa0b75aad26eef9deccc32a45f
exact_netlist_sha256: c940f23996c5886f24ac0bdd48978ba3daca489b0487bb25451076f84af777c9
circuit_json_sha256: a7f2d4510b91fd4ded3643f2aaa6b3bd8c153daf93896aaaa8ab4422600d739c
kicad_schematic_sha256: 0cd311e34d9e6d03f7bba082d43b762589b0aa1459b3fc813c2f982d8cbbf737

Independent judgment

SOUND for the exact pre-route schematic within the declared laboratory first-article scope. No blocking topology, value, identity, connected-pin, connector or power-domain defect was found. This is a fresh judgment of current bytes, not a restamped historical witness. DO-NOT-ORDER remains mandatory.

Measured review

I independently evaluated the TSX JSX declarations without invoking the circuit producer, tokenized the native netlist and schematic S-expressions, and reconstructed circuit.json electrical connectivity by union-find over source_trace edges. All 333 component sets match TSX, circuit.json, manifest, native schematic and native netlist. All 333 values, MPNs and dossier footprints agree; 120 resistance strings differ only in unit spelling. Native schematic properties match the exported netlist. All 943 connected nodes agree between independently evaluated source, reconstructed circuit.json and native netlist. The native inventory additionally contains 42 explicit NC nodes: 985 nodes on 221 nets total. The 988 dossier physical pin identities resolve to these 985 native identities through the three explicitly documented Q_IN drain aliases (6/7/8 to5), with no missing identity.

I separately evaluated all 205 current invariant rows against my native inventory: 152 pin assertions, 51 value assertions, one series-chain assertion and one rail-capacitor census pass. The shared electrical-invariants gate also passes205/205. The current frozen analog checker applied to that independent inventory passes eight channels, eight amplifiers,16 input current-limit resistors,16 same-leg feedback resistors,32 independent shunts, two external bias dividers, two direct reference-negative returns and two polarized reference bulk capacitors. The independent parser did not regenerate or freshly re-export the native schematic; property agreement is not represented as another native wire-connectivity export.

All429 packet files and all seven current subject hashes were recomputed before review and verified again after. The normalized electrical netlist and entire part-dossier digest equal the authenticated clockbridge1 report, independently confirming unchanged electrical topology and part bytes. The rules, exact netlist, circuit.json, PDF and schematic hashes differ and are bound here freshly. The old route/floorplan files are not in this frozen packet; therefore I do not claim a full bytewise geometry delta against them. Historical primary-datasheet review remains supporting comparison for unchanged parts, not current acceptance of changed geometry. No broad repeated70-datasheet archaeology or broad unit suite was performed.

Changed source facts and digital contracts

C_ADC_CM8N is1nF, GRM1555C1H102JA01D,0402, on ADC8N/GND. Its current source placement is(100.25,77.2),270degrees. Frozen U_ADC footprint pad21 offset(1,2.95), with center(96,70), gives(97,72.95). The capacitor ADC8N source landing is(100.25,76.72); pad-center distance is4.97748932696mm, within the unchanged5mm dossier ceiling. Applying the TASK's prior x100.65 coordinate gives5.24741841290mm; that is explicitly a recomputation of the supplied predecessor coordinate, not a recovered prior-file measurement. Current ADC8N F.Cu copper reaches the moved landing; its GND leaf runs(100.25,77.68) to(100.25,78.35), with its declared via at that endpoint. Final native-board adjacency and copper geometry remain separate gates.

R_FSYNC remains22ohm, CRCW120622R0FKEAHP, Resistor_SMD:R_1206_3216Metric, C844025. Both native properties and source agree with the exact dossier. Its two nodes are FSYNC_BUF and ADC_FSYNC. The supplied Vishay20043 revision20260317 dossier declares750mW/1%/100ppm/C; the unchanged package selection does not establish a50ohm interconnect or parasitic model. U_CLK pin mapping,100nF local bypass, three10k input pull-downs and three22ohm clock source resistors remain consistent. FSYNC_BUF and BCLK_BUF now each have one narrow item, respectively1.15mm and1.05mm; current ownership prose agrees, resolving the historical P2 stale-number observation.

Both digital path groups explicitly declare no_vias:true and cover13 nets. I independently counted110 authored seed segments, allF.Cu, with zero vias. Ten nets have seed copper; ADC_TDM, TDM_CLEAN and TDM_BUFFERED have none in this seed inventory and retain the front-only clocks wave for completion. This is not a claim that all13 nets are already fully routed. Every per-net seed subnominal count/length fits the3-item/3mm ceilings. Maximum length is ADC_FSYNC2.827200mm; ADC_MCLK is2.627305mm/3items. The clock wave explicitly permits onlyF.Cu,0.25mm clearance,0.36mm ordinary per-net widths and0.18mm absolute minimum with those same budgets. The power-wide F/B permissions do not override these digital declarations. LDO_D_FILT ownership explicitly acknowledges its plated transfers and0.35mm F/B tree.

The frozen clock/DC and TDM calculations, applied to my independent native inventory, pass9/9 and7/7 checks. Their timing, load, slew and leakage assumptions remain conditional; they do not prove actual module/cable behavior or production corners. Final-board trace widths, return planes, no-via realization, field solve and waveforms remain owed.

Connector, protection and power

Every one of80 J1..J8 contacts matches the custom interface:1/3/7=12V_PODn,2/6/8=GND,5=AUDIO_Pn,4=AUDIO_Nn,9/10=CHASSIS. CHASSIS has exactly16 shell nodes and no component connects it toGND. These cables carry custom analog/power, not Ethernet or PoE. Physical factory-cord mating, panel bond, ESD integration and prototype qualification remain open.

The native inventory and current invariant set independently confirm J9→F_IN→Q_IN drain and Q_IN source→12V_PROTECTED, the correctly oriented12V gate-source clamp, gate pulldown and SMBJ15A cathode-to-protected-bus/anode-toGND. D_BUCK_IN isolates the buck reservoir; only it, U_BUCK and the three input ceramics own12V_BUCK_IN. The adopted transient allocation24.4V plus20%=29.28V stays below32V buck/50V ceramics. This does not establish sustained overvoltage cutoff or complete downstream backfeed blocking.

The CS5308P, LT3041 and all eight OPA2320 duals share3V3_ADC. The two1k/1k external half-supply bias banks remain separate from internal ADC VMID outputs. The held supply, precharge, supervisors, analog-isolation gates, dump chain and hardware high-low-high reset have consistent current native endpoints and supply domains. The frozen protection power screen run on my native inventory passes10/10 checks. Its receipt retains historical producer-oriented wording ('native stale and unreviewed'); that field is not adopted as a statement about this freshly compared native inventory. Only its actual arithmetic/check results are used. Charge injection, tracking, aging/ESR/ESL, thermal behavior, ramp endpoints, selective fault clearing, signal performance and actual independent power-state behavior remain first-article obligations.

Visual corroboration and limits

I visually inspected all19 current delivered PDF pages as individual1600-pixel raster images. Pages1–5 expose the protection/regulated/held/enable chains; pages6–13 show all10 contacts on each jack, polarity and analog channel continuity; pages14–16 show ADC configurations, NCs, bypass and separate reference banks; pages17–19 show the clock, TDM and reset chains. The crowded page17 has distinguishable nonconnecting bridges. No topology-changing wire/ground-bar conflict, lost connector contact, wrong polarity or unreadable critical label was found. This supports topology and does not replace the separately commissioned readability lens.

Frozen ERC has0 errors and2637 warnings, comprising2068 endpoint_off_grid and569 lib_symbol_issues for embedded elt library configuration. This is inherited report evidence, not a fresh ERC run or zero-warning claim. The four ignored categories remain singleton global labels, four-way connections, SPICE models and footprint filters.

No blocking finding remains in this topology lens. Final native board, routing, placement, thermal/process proof, manufacturer assembly allocation and physical qualification are outside this verdict. No board was generated/saved; no live engineering file, commit or accepted review was edited, and no child agent was launched. The archive retains the reviewer methods, successful and failed bounded-run logs/runtime records, per-invariant results, exact inventory, delta census and all19 images. Initial review-method setup mistakes (MPN property-key assumption; treating every digital net as seeded) were corrected openly; their raw failure logs remain. An initial scratch filename inspect.py shadowed Python's standard module before runtime startup; the file was renamed, its explicit disclosure retained, and all affected engineering verification rerun successfully under the bounded runtime. Parent alone closes the adapter and adopts any witness.
