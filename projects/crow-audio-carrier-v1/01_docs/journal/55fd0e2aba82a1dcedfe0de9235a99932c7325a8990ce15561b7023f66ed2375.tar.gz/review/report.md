review_stage: pre-route
review_kind: topology
reviewer_identity: /root/carrier_rj45_native_carrier_topology_clockbridge1
context: FRESH
date: 2026-09-15T16:57:12.835287+00:00
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
netlist_sha256: 1cec3ea0b47b6f0e715b769abed4253ccc2aaf8cbfa6808685f74539df8f2805
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: 9105377c94ef87fc6d4428e63f03238d73c4a125055bc9d7e344bad9583c23f2
schematic_pdf_sha256: d021b558dc7c47ae2ef8d0311938d0e383bd36c38ad61ca5a9c7c2a3ba6a9251
exact_netlist_sha256: 130d685473c4748718f52b87df28e7bf3a024a588d008262bc155ce4e6e0c2cd
circuit_json_sha256: bca07b36701275128b715ee8425ca4e4a2ca32609e50dcdd5058d5dc4d10c7a5
kicad_schematic_sha256: 213d3047640734935c4fd2bc0416a7611e69788f4c2d8ceb0ee0daf12c9181f0

Independent topology judgment

The exact frozen schematic is electrically coherent within its declared FIRST-ARTICLE-ONLY laboratory-prototype scope. I found no blocking topology, component-identity, value, connected-pin, shield-isolation or clock-termination defect. This verdict does not establish production suitability, physical qualification, final-board routing or orderability. Historical reviews and the parent's geometry results were not used as acceptance evidence.

Authority and method

I followed the copied TASK, CLAUDE.md, schematic/electrical/meta canon, pcb-design review/publication and bounded-runtime instructions. The entire 429-item input packet was hashed before review and again after review. All seven subject hashes were recomputed using the frozen pre_route_review_check.py digest functions and matched expected-subject.json. The allocated envelope canonical SHA-256 is be712e23829a0a5adf2b08ce786fc70fa2157f4132d409e7a97bfc81c53d4517.

The retained source.tsx evaluates JSX declarations with a lightweight element walker, without invoking the circuit producer or generating a board. inventory.py independently tokenizes native KiCad S-expressions and compares the TSX component/connection declarations against the frozen exported native netlist. A separate union-find over circuit.json source_trace edges reconstructs all generated electrical source connections. Native schematic symbol properties and manifest sets are checked independently. This is a comparison to the delivered native netlist; I did not regenerate a schematic or re-export it with KiCad. The native schematic property census is not misrepresented as a second fresh KiCad wire-connectivity export.

Measured coverage

- Component refdes sets agree exactly: 333 TSX, 333 circuit.json, 333 manifest, 333 native schematic and 333 native netlist components. All 333 MPNs and native footprints match their part dossiers; no populated part lacks a dossier.
- All 333 values agree after normalizing resistance-unit spelling. The 120 raw differences are ordinary resistance strings such as 100k versus 100kΩ, not electrical changes. Native schematic/netlist value, MPN and footprint properties have zero differences.
- 985 native nodes comprise 943 connected nodes and 42 explicit no-connect nodes on 221 nets (179 connected nets plus 42 singleton NC nets). TSX and circuit.json both independently match all 943 connected nodes; no extra native connected node remains.
- Q_IN physical drain positions 6/7/8 intentionally map to fused schematic/footprint identity 5. The dossier explicitly declares all three aliases and the Diodes DS37204 Rev.2-2 p.1 package/equivalent circuit confirms the common drain. These resolve the three initial physical-pin census candidates without changing any input.
- The shared electrical-invariants gate passes 205/205. constraints.py independently evaluates the same 152 pin assertions, 51 values, one series chain and one rail-capacitor census against my independently parsed native inventory: 205/205 pass. Protection-ADR coverage is 7/7.
- All 70 locally hash-pinned primary datasheet files match their dossier hashes. The full dossier tree contains 89 records including historical and external assembly items. Every populated native component has a locally hash-pinned primary datasheet; this does not claim fresh online sourcing or all 89 records are installed components.

Clock cell and digital boundary

R_FSYNC is 22 Ω, CRCW120622R0FKEAHP, Resistor_SMD:R_1206_3216Metric, supplier identity C844025. Its two pins are FSYNC_BUF and ADC_FSYNC. The actual native schematic value/footprint/MPN and TSX agree. Vishay document 20043 revision 17-Mar-2026 pp.1-2 supports the 1206 HP family, 0.75 W P70 rating subject to its thermal condition, 1%/100 ppm/K option and EA packaging. The larger package is not accepted as a solved parasitic/impedance model.

TI SCES366L p.3 independently confirms U_CLK DCU pins 1/7 = 1A/1Y, 3/5 = 2A/2Y, 6/2 = 3A/3Y, 4 GND and 8 VCC. The three clocks retain their individual 10k pulldowns, buffer and 22 Ω source resistors. C_CLK is 100nF across 3V3_ADC/GND. The TDM path is ADC DOUT1 → true noninverting Schmitt → presence-interlocked tri-state buffer → 33 Ω → J10.2. MCH_3V3_SENSE owns sensing, not the carrier supply.

Both governed digital path groups explicitly set no_vias:true, covering 13 nets. I counted 110 actual digital source segments, all F.Cu, zero source vias. All 13 per-net subnominal counts/lengths satisfy the three-item/3mm ceilings. The current maximum is ADC_FSYNC at 2.827200mm; ADC_MCLK is 2.627305mm/three items. The clock wave permits only F.Cu and declares 0.36mm ordinary widths, 0.25mm clearance and bounded 0.18mm launches. Power's separate F/B permissions do not relax those declarations. Final saved-board width, clearance, topology, return-plane and no-via checks remain required.

The conditional logic screens pass 9/9 bias checks and 7/7 TDM checks using independently parsed native nodes. The timing screen leaves only 1.521094ns after its declared device/path/setup allocations. That is an engineering screen, not a guaranteed module/cable timing measurement. Clock waveform, receiver load, absent-domain leakage, slow-input current, actual capacitance and four power-state behavior remain first-article obligations.

Connector, protection and power assessment

All 80 contacts of J1..J8 match the exact custom interface: 1/3/7 branch +12V, 2/6/8 GND, 5 AUDIO+, 4 AUDIO−, 9/10 CHASSIS. CHASSIS consists of exactly the 16 shell nodes; no component joins it to GND. Würth drawing 615008160221 revision001.003 pp.1-2 fixes the contact numbering and 1.5A current rating. The board ports are custom analog/power; they are not Ethernet or PoE. The factory cord, panel bond, isolation, hot loop and physical mating are still unqualified.

The native source confirms J9 → F_IN → Q_IN drain, Q_IN source → protected bus; the 12V gate-source clamp and gate pull-down have correct endpoints. SMBJ15A cathode is on 12V_PROTECTED and anode on GND. D_BUCK_IN isolates the local buck VIN reservoir from the shared spoke bus; only its diode, U_BUCK and three input ceramics own 12V_BUCK_IN. The power rules admit a 24.4V transient clamp plus20% (=29.28V), below the declared 32V buck and 50V input-cap limits. This is bounded transient protection, not sustained overvoltage cutoff or complete backfeed isolation.

The LT3041 and all eight OPA2320 duals share 3V3_ADC with the CS5308P. The obsolete split amplifier rail is absent. Two passive 1k/1k bias banks remain separate from ADC internal VMID outputs. The native analog contract covers eight channels, 16 ADC pulldowns, 32 independent filter shunts and the TMUX isolation endpoints. Retained precharge, held supply, supervisors, Schmitt enable/dump chain and reset pulse have consistent polarity and supply domains.

The frozen power screen, supplied with my native inventory, passes10/10 checks: shared3V3 222.374mA/230mA, local5V 250.414mA/300mA, upstream 0.985346A/1A, carrier output floor10.896V/10.8V. The rail barrier margin is3.113634mA; the combined relative-pin allocation243.759mV/300mV and startup charge screen8.388607ms/10ms are conditional. Switch charge, return error, amplifier tracking, capacitor aging/ESR/ESL, reverse recovery, loaded ramp, PPTC fault selectivity and real thermal behavior are not manufacturer-guaranteed by those calculations. The explicit unqualified ESD installation restriction and transient-current hold remain in force.

Visual corroboration and ERC limits

I visually inspected the actual delivered PDF as 19 individual1600-pixel images, including every analog jack page6–13, ADC page14, clock page17 and TDM/reset pages18–19. Labels, supply/ground separation, polarized-cap positive marks, NC marks, source termination and connector contacts are readable. Crossings on the crowded clock page use distinguishable nonconnecting bridges; no topology-changing visual conflict was identified. This corroborates topology and does not replace the separately commissioned readability witness.

The frozen ERC report has0 errors and2637 warnings:2068 endpoint_off_grid and569 lib_symbol_issues concerning the embedded elt library configuration. These are retained/explicitly classified generated-artifact warnings, not a zero-warning claim or a new ERC run. Its four ignored categories are global-label singleton, four-way connection, SPICE model and footprint-filter checks. Exact connected-node agreement provides additional evidence against accidental net merging; routing and final native qualification are outside this review.

Findings and limits

P2 TOPO-P2-01: route.yaml ownership explanatory prose still says FSYNC_BUF1.40mm and BCLK_BUF two short items. The actual current source is FSYNC_BUF1.15mm/one item and BCLK_BUF1.05mm/one subnominal item. The operative source and budgets pass; the stale explanatory numbers should be refreshed in a later source revision. No numeric floor, no-via permission or connectivity acceptance is inferred from that prose.

The 19-page visual evidence, exact inventories, per-invariant outcomes, per-net width/count census, primary images, scripts, raw logs and runtime records are archived. Initial tool setup failures are retained honestly: an incompatible --min-invariants flag, absent PyMuPDF and project checkers' unavailable /tmp/skills parser path. Their replacement methods were respectively separate actual grading, bounded pdftoppm, and direct calls with an independently parsed native inventory. None is concealed as an engineering pass. No broad unit suite, live design edit, board generation/save, child agent, commit or adoption was performed. Parent alone closes the adapter.
