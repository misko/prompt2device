import sys,json,hashlib,tarfile,re,collections
from pathlib import Path
from datetime import datetime,timezone
sys.dont_write_bytecode=True
S=Path(__file__).parent;A=S.parent;R=A.parents[2];P=R/'project';O=A/'outputs';env=json.loads((A/'envelope.json').read_text());inv=json.loads((S/'inventory.json').read_text());ass=json.loads((S/'assessment.json').read_text());cons=json.loads((S/'constraints.json').read_text())
assert hashlib.sha256(json.dumps(env,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='be712e23829a0a5adf2b08ce786fc70fa2157f4132d409e7a97bfc81c53d4517'
assert cons['invariant_pass']==205 and not ass['semantic_value_differences']
assert all(x['within_3mm_3items'] for x in cons['digital_nets'].values())
assert all(v['hash_match'] for v in ass['datasheets'])
for x in inv['identity_pin_differences']:assert x[0]=='missing_dossier_pin' and x[1] in ['Q_IN.6','Q_IN.7','Q_IN.8']
for k in ('extra_native_connected_nodes','circuit_pin_differences','native_schematic_property_differences','missing_dossiers'):assert not inv[k]
assert not any(inv['ref_differences'].values())
now=datetime.now(timezone.utc).isoformat();identity='/root/carrier_rj45_native_carrier_topology_clockbridge1'
findings=[{'id':'TOPO-P2-01','severity':'P2','disposition':'nonblocking explanatory-text maintenance','finding':'route.yaml ownership.why for FSYNC_BUF still describes 1.40 mm and BCLK_BUF two subnominal items. Actual frozen sources measure FSYNC_BUF 1.150000 mm/one item and BCLK_BUF 1.050000 mm/one subnominal item. The operative geometry and width/count budgets pass.','evidence':'constraints.json'}, {'id':'TOPO-LIMIT-01','severity':'qualification hold','disposition':'DO-NOT-ORDER retained','finding':'Physical mate/prototype qualification, capacitor/transient/thermal captures, switch-charge and return-error allocations, final SI/timing/routing and actual assembly allocation remain owed under the existing first-article scope.'}]
counts={**inv['counts'],'electrical_invariants':205,'pin_on_net_invariants':152,'part_value_invariants':51,'series_chain_invariants':1,'net_has_part_invariants':1,'connector_contacts':80,'chassis_nodes':16,'digital_nets':13,'digital_source_items':110,'digital_source_vias':0,'schematic_pdf_pages_viewed':19,'hashed_primary_datasheet_files':len(ass['datasheets'])}
report=f'''review_stage: pre-route
review_kind: topology
reviewer_identity: {identity}
context: FRESH
date: {now}
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
'''+''.join(f'{k}: {v}\n' for k,v in inv['subject_hashes'].items())+'''
Independent topology judgment

The exact frozen schematic is electrically coherent within its declared FIRST-ARTICLE-ONLY laboratory-prototype scope. I found no blocking topology, component-identity, value, connected-pin, shield-isolation or clock-termination defect. This verdict does not establish production suitability, physical qualification, final-board routing or orderability. Historical reviews and the parent's geometry results were not used as acceptance evidence.

Authority and method

I followed the copied TASK, CLAUDE.md, schematic/electrical/meta canon, pcb-design review/publication and bounded-runtime instructions. The entire 429-item input packet was hashed before review and again after review. All seven subject hashes were recomputed using the frozen pre_route_review_check.py digest functions and matched expected-subject.json. The allocated envelope canonical SHA-256 is be712e23829a0a5adf2b08ce786fc70fa2157f4132d409e7a97bfc81c53d4517.

The retained source.tsx evaluates JSX declarations with a lightweight element walker, without invoking the circuit producer or generating a board. inventory.py independently tokenizes native KiCad S-expressions and compares the TSX component/connection declarations against the frozen exported native netlist. A separate union-find over circuit.json source_trace edges reconstructs all generated electrical source connections. Native schematic symbol properties and manifest sets are checked independently. This is a comparison to the delivered native netlist; I did not regenerate a schematic or re-export it with KiCad. The native schematic property census is not misrepresented as a second fresh KiCad wire-connectivity export.

Measured coverage

- Component refdes sets agree exactly: 333 TSX, 333 circuit.json, 333 manifest, 333 native schematic and 333 native netlist components. All 333 MPNs and native footprints match their part dossiers; no populated part lacks a dossier.
- All 333 values agree after normalizing resistance-unit spelling. The 120 raw differences are ordinary resistance strings such as 100k versus 100kΩ, not electrical changes. Native schematic/netlist value, MPN and footprint properties have zero differences.
- 985 native nodes comprise 943 connected nodes and 42 explicit no-connect nodes on 221 nets (179 connected nets plus 42 singleton NC nets). TSX and circuit.json both independently match all 943 connected nodes; no extra native connected node remains.
- Q_IN physical drain positions 6/7/8 intentionally map to fused schematic/footprint identity 5. The dossier explicitly declares all three aliases and the Diodes DS37204 Rev.2-2 p.1 package/equivalent circuit confirms the common drain. These resolve the three initial physical-pin census candidates without changing any input.
- The shared electrical-invariants gate passes 205/205. constraints.py independently evaluates the same 152 pin assertions, 51 values, one series chain and one rail-capacitor census against my independently parsed native inventory: 205/205 pass. Protection-ADR coverage is 7/7.
- All 70 locally hash-pinned primary datasheet files match their dossier hashes. The full dossier tree contains 89 records including historical and external assembly items. Every populated native component has a locally hash-pinned primary datasheet; this does not claim fresh online sourcing or all 89 records are installed components.

Clock cell and digital boundary

R_FSYNC is 22 Ω, CRCW120622R0FKEAHP, Resistor_SMD:R_1206_3216Metric, supplier identity C844025. Its two pins are FSYNC_BUF and ADC_FSYNC. The actual native schematic value/footprint/MPN and TSX agree. Vishay document 20043 revision 17-Mar-2026 pp.1-2 supports the 1206 HP family, 0.75 W P70 rating subject to its thermal condition, 1%/100 ppm/K option and EA packaging. The larger package is not accepted as a solved parasitic/impedance model.

TI SCES366L p.3 independently confirms U_CLK DCU pins 1/7 = 1A/1Y, 3/5 = 2A/2Y, 6/2 = 3A/3Y, 4 GND and 8 VCC. The three clocks retain their individual 10k pulldowns, buffer and 22 Ω source resistors. C_CLK is 100nF across 3V3_ADC/GND. The TDM path is ADC DOUT1 → true noninverting Schmitt → presence-interlocked tri-state buffer → 33 Ω → J10.2. MCH_3V3_SENSE owns sensing, not the carrier supply.

Both governed digital path groups explicitly set no_vias:true, covering 13 nets. I counted 110 actual digital source segments, all F.Cu, zero source vias. All 13 per-net subnominal counts/lengths satisfy the three-item/3mm ceilings. The current maximum is ADC_FSYNC at 2.827200mm; ADC_MCLK is 2.627305mm/three items. The clock wave permits only F.Cu and declares 0.36mm ordinary widths, 0.25mm clearance and bounded 0.18mm launches. Power's separate F/B permissions do not relax those declarations. Final saved-board width, clearance, topology, return-plane and no-via checks remain required.

The conditional logic screens pass 9/9 bias checks and 7/7 TDM checks using independently parsed native nodes. The timing screen leaves only 1.521094ns after its declared device/path/setup allocations. That is an engineering screen, not a guaranteed module/cable timing measurement. Clock waveform, receiver load, absent-domain leakage, slow-input current, actual capacitance and four power-state behavior remain first-article obligations.

Connector, protection and power assessment

All 80 contacts of J1..J8 match the exact custom interface: 1/3/7 branch +12V, 2/6/8 GND, 5 AUDIO+, 4 AUDIO−, 9/10 CHASSIS. CHASSIS consists of exactly the 16 shell nodes; no component joins it to GND. Würth drawing 615008160221 revision001.003 pp.1-2 fixes the contact numbering and 1.5A current rating. The board ports are custom analog/power; they are not Ethernet or PoE. The factory cord, panel bond, isolation, hot loop and physical mating are still unqualified.

The native source confirms J9 → F_IN → Q_IN drain, Q_IN source → protected bus; the 12V gate-source clamp and gate pull-down have correct endpoints. SMBJ15A cathode is on 12V_PROTECTED and anode on GND. D_BUCK_IN isolates the local buck VIN reservoir from the shared spoke bus; only its diode, U_BUCK and three input ceramics own 12V_BUCK_IN. The power rules admit a 24.4V transient clamp plus20% (=29.28V), below the declared 32V buck and 50V input-cap limits. This is bounded transient protection, not sustained overvoltage cutoff or complete backfeed isolation.

The LT3041 and all eight OPA2320 duals share 3V3_ADC with the CS5308P. The obsolete split amplifier rail is absent. Two passive 1k/1k bias banks remain separate from ADC internal VMID outputs. The native analog contract covers eight channels, 16 ADC pulldowns, 32 independent filter shunts and the TMUX isolation endpoints. Retained precharge, held supply, supervisors, Schmitt enable/dump chain and reset pulse have consistent polarity and supply domains.

The frozen power screen, supplied with my native inventory, passes10/10 checks: shared3V3 222.374mA/230mA, local5V 250.414mA/300mA, upstream 0.985346A/1A, carrier output floor10.896V/10.8V. The rail barrier margin is3.113634mA; the combined relative-pin allocation243.759mV/300mV and startup charge screen8.388607ms/10ms are conditional. Switch charge, return error, amplifier tracking, capacitor aging/ESR/ESL, reverse recovery, loaded ramp, PPTC fault selectivity and real thermal behavior are not manufacturer-guaranteed by those calculations. The explicit unqualified ESD installation restriction and transient-current hold remain in force.

Visual corroboration and ERC limits

I visually inspected the actual delivered PDF as 19 individual1600-pixel images, including every analog jack page6–13, ADC page14, clock page17 and TDM/reset pages18–19. Labels, supply/ground separation, polarized-cap positive marks, NC marks, source termination and connector contacts are readable. Crossings on the crowded clock page use distinguishable nonconnecting bridges; no topology-changing visual conflict was identified. This corroborates topology and does not replace the separately commissioned readability witness.

The frozen ERC report has0 errors and2637 warnings:2068 endpoint_off_grid and569 lib_symbol_issues concerning the embedded elt library configuration. These are retained/explicitly classified generated-artifact warnings, not a zero-warning claim or a new ERC run. Its four ignored categories are global-label singleton, four-way connection, SPICE model and footprint-filter checks. Exact connected-node agreement provides additional evidence against accidental net merging; routing and final native qualification are outside this review.

Findings and limits

P2 TOPO-P2-01: route.yaml ownership explanatory prose still says FSYNC_BUF1.40mm and BCLK_BUF two short items. The actual current source is FSYNC_BUF1.15mm/one item and BCLK_BUF1.05mm/one subnominal item. The operative source and budgets pass; the stale explanatory numbers should be refreshed in a later source revision. No numeric floor, no-via permission or connectivity acceptance is inferred from that prose.

The 19-page visual evidence, exact inventories, per-invariant outcomes, per-net width/count census, primary images, scripts, raw logs and runtime records are archived. Initial tool setup failures are retained honestly: an incompatible --min-invariants flag, absent PyMuPDF and project checkers' unavailable /tmp/skills parser path. Their replacement methods were respectively separate actual grading, bounded pdftoppm, and direct calls with an independently parsed native inventory. None is concealed as an engineering pass. No broad unit suite, live design edit, board generation/save, child agent, commit or adoption was performed. Parent alone closes the adapter.
'''
(O/'report.md').write_text(report)
visual=[{'page':n,'image':f'images/page-{n:02d}.png','viewed':True,'finding':'No blocking topology/label/polarity/NC conflict identified at reviewed scale'} for n in range(1,20)]
(S/'visual-observations.json').write_text(json.dumps(visual,indent=2))
# Verify the complete packet after all engineering review activity, before packaging.
bad=[]
for it in env['input_packet']:
 data=(R/it['path']).read_bytes()
 if len(data)!=it['size'] or hashlib.sha256(data).hexdigest()!=it['sha256']:bad.append(it['path'])
assert not bad
(S/'after.json').write_text(json.dumps({'count':len(env['input_packet']),'bad':bad},indent=2))
evidence={'review_stage':'pre-route','review_kind':'topology','reviewer_identity':identity,'context':'FRESH','date':now,'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','subject':env['subject'],'envelope_subject':env['subject'],'envelope_canonical_sha256':'be712e23829a0a5adf2b08ce786fc70fa2157f4132d409e7a97bfc81c53d4517','subject_hashes':inv['subject_hashes'],'counts':counts,'methods':['Independent TSX element evaluation','Independent native S-expression component/pin parser','Independent circuit.json electrical union-find','Native schematic identity property census','All205 independent invariant evaluations plus shared gate','Frozen project power/clock validators consuming independent native inventory','All19 actual PDF pages visually inspected','Whole frozen packet hash verification before/after','Archive all regular members reopened and hashed'],'findings':findings,'limits':['Prototype schematic verdict only','No fresh KiCad re-export or ERC invocation','No routed-board or physical-mating qualification','No order allocation','No production/SI/environmental-survival claim']}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2))
# Archive actual evidence only; no recursive archive or symlink members.
paths=sorted(p for p in S.rglob('*') if p.is_file() and p.name!='package.py')
assert all(not p.is_symlink() and not any(p.name.endswith(suffix) for suffix in ('.tar','.tar.gz','.tgz','.zip')) for p in paths)
with tarfile.open(O/'evidence.tar.gz','w:gz') as tar:
 for p in paths:tar.add(p,arcname=p.relative_to(S).as_posix(),recursive=False)
members=[];seen=set()
with tarfile.open(O/'evidence.tar.gz','r:gz') as tar:
 for m in tar.getmembers():
  assert m.isfile() and m.name not in seen and not m.name.startswith('/') and '..' not in Path(m.name).parts
  seen.add(m.name);data=tar.extractfile(m).read();assert len(data)==m.size
  assert data==(S/m.name).read_bytes()
  members.append({'path':m.name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
b=(O/'evidence.tar.gz').read_bytes();manifest={'archive_sha256':hashlib.sha256(b).hexdigest(),'archive_size':len(b),'member_count':len(members),'members':members};(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2))
(O/'result.json').write_text(json.dumps({'subject':env['subject'],'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]},indent=2))
print(json.dumps({'outputs':sorted(p.name for p in O.iterdir()),'archive_sha256':manifest['archive_sha256'],'archive_size':len(b),'member_count':len(members),'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER'},indent=2))
