"""Root full-checkout qualification; consumes an already closed exact author delivery.
No BOARD/LoadBoard/SaveBoard/Fill or board generation is admitted by this script.
The caller supplies an independently reopened seven-file source manifest.
"""
from pathlib import Path
import json,hashlib,sys,os,shutil
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;Q=Path('/tmp/crow-none-return-full-qualification-20260913')
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
spec=json.loads(Path(sys.argv[1]).read_text());assert spec['scope']=='EXACT_CLOSED_NONE_SOURCE_AUTHOR_PLUS_ROOT_POLYGON_HELPER'
assert len(spec['files'])==8
assert len({r['path'] for r in spec['files']})==8
assert not (N/'none-root-qualification').exists()
rows=[]
for row in spec['files']:
 p=Q/row['path'];src=Path(row['after_path']);b=src.read_bytes()
 assert hashlib.sha256(p.read_bytes()).hexdigest()==row['before_sha256'],str(p)
 assert hashlib.sha256(b).hexdigest()==row['after_sha256'],str(src)
 rows.append((p,b))
for p,b in rows:p.write_bytes(b)
L=N/'none-root-qualification';L.mkdir(exist_ok=False)
env={k:os.environ[k] for k in ['PATH','HOME','LANG'] if k in os.environ};env['PYTHONDONTWRITEBYTECODE']='1'
results=[]
for name,args in [
 ('schema',['skills/kicad-pcb/scripts/schema_reader_audit.py','--root',str(Q)]),
 ('bounds',['skills/kicad-pcb/scripts/adr_bound_provenance.py',str(Q),'--repo-root',str(Q),'--timeout','30']),
 ('contracts',['tests/t1_contracts.py'])]:
 cmd=['/usr/bin/python3','-B',*args]
 result=run_stage({'id':'none-source-'+name,'work_class':'local','timeout_s':300},cmd,log_path=L/(name+'.log'),cwd=Q,env=env,console_line_limit=4,console_tail_lines=3)
 results.append({'name':name,'argv':cmd,'cwd':str(Q),'runtime':result.to_mapping()})
 (L/'results.json').write_text(json.dumps(results,indent=2)+'\n')
# Retain every result even if a pure source gate fails; no native producer follows.
for row in spec['files']:assert hashlib.sha256((Q/row['path']).read_bytes()).hexdigest()==row['after_sha256']
print(json.dumps({'source_files':len(rows),'results':{r['name']:r['runtime']['status'] for r in results},'native_generation':False}))
raise SystemExit(0 if all(r['runtime']['status']=='PASS' for r in results) else 1)
