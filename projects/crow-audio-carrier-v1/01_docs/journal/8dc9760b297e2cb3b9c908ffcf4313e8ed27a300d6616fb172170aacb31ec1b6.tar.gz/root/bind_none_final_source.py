from pathlib import Path
import json,hashlib,subprocess
N=Path(__file__).parent;Q=Path('/tmp/crow-none-return-full-qualification-20260913');spec=json.loads((N/'none-final-governance/input-source-spec.json').read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=Q,text=True,timeout=15).strip();changed=subprocess.check_output(['git','diff','--name-only'],cwd=Q,text=True,timeout=15).splitlines();assert head.startswith('516013e8');assert set(changed)=={r['path'] for r in spec['files']}
for row in spec['files']:
 assert hashlib.sha256((Q/row['path']).read_bytes()).hexdigest()==row['after_sha256']
 old=subprocess.check_output(['git','show','HEAD:'+row['path']],cwd=Q,timeout=15);assert hashlib.sha256(old).hexdigest()==row['before_sha256']
t=json.loads((N/'none-root-qualification/focused-tests.json').read_text());assert t['project_testsRun']==63 and not t['project_errors'] and not t['project_failures'] and all(r['status']=='PASS' for r in t['consumer'])
g=json.loads((N/'none-final-governance/results.json').read_text());assert len(g)==3 and all(r['runtime']['status']=='PASS' for r in g)
binding={'base_commit':head,'worktree':str(Q),'source':spec,'tracked_delta_exact':True,'focused_project_tests':63,'consumer_tests':4,'governance':{r['name']:r['runtime']['status'] for r in g},'native_or_source_adoption':False,'qualification_inputs':'Complete detached Git checkout at base commit plus exactly9 verified postimages; current netlists are unchanged copies and hash-recorded in none-full-qualification-preparation.json. Fresh reviewers receive required source copies plus this complete-tree recipe, actual raw commands/logs and evidence; no partial-tree aggregate substituted.'}
(N/'none-final-source-binding.json').write_text(json.dumps(binding,indent=2)+'\n');print(json.dumps({'source_files':9,'base_commit':head,'project_tests':63,'consumer_tests':4,'governance':binding['governance']}))
