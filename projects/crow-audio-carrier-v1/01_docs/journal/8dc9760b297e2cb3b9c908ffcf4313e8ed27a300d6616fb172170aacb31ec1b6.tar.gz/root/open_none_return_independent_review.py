from pathlib import Path
import json
import thermal_review_common as common
ns={'__file__':common.__file__};exec(compile(Path(common.__file__).read_text().replace('rj45-placement-thermal-availability-opened.json','rj45-none-return-review-availability-opened.json'),'<current-NONE-probe>','exec'),ns)
R,N=common.R,common.N;Q=Path('/tmp/crow-none-return-full-qualification-20260913');m=json.loads((N/'rj45-none-return-source1-opened.json').read_text());D=Path(m['project']);S=Path(m['scratch_dir']);O=Path(m['output_dir'])
assert json.loads(Path(m['attempt']).read_text())['status']=='PASS';binding=json.loads((N/'none-final-source-binding.json').read_text());assert all(x=='PASS' for x in binding['governance'].values())
copies=[(D/'before','before'),(D/'canon','canon'),(O,'author-delivery'),(S/'changed-files.json','author/changed-files.json'),(S/'changed-before','author/changed-before'),(S/'source.patch','author/source.patch'),(N/'regulator-polygon-proposal','root-helper'),(N/'findings-narrative-schema-correction','root-narrative'),(N/'none-root-qualification','root-preflight/original'),(N/'none-final-governance','root-preflight/final'),(N/'none-final-source-binding.json','root-preflight/source-binding.json'),(N/'source-polygon-reader-census.json','root-preflight/polygon-reader-census.json'),(N/'pad-mode-compatibility-inventory.json','root-preflight/pad-mode-compatibility.json'),(N/'none-full-qualification-preparation.json','root-preflight/netlist-dependencies.json'),(R/'projects/crow-audio-carrier-v1/01_docs/STATUS.md','current-handoff/STATUS.md'),(R/'projects/crow-audio-carrier-v1/01_docs/findings.yaml','current-handoff/findings.yaml'),(N/'candidate5-completed-assessment.json','current-handoff/five-spent-assessment.json'),(N/'candidate5-review-via-count-erratum.json','current-handoff/candidate5-count-erratum.json'),(N/'none-composed-source-spec.json','root-preflight/composed-source-spec.json')]
for rel in ['projects/crow-audio-carrier-v1/03_src','projects/crow-audio-carrier-v1/02_parts','projects/crow-audio-carrier-v1/03_tscircuit/src','projects/crow-audio-carrier-v1/06_build/netlists','projects/crow-audio-carrier-v1/01_docs/decisions','skills','scripts','tests']:
 copies.append((Q/rel,'after/'+rel))
for name in ['qualify_none_composed_tests.py','qualify_none_overlay.py','qualify_none_final_governance.py','bind_none_final_source.py','diagnose_regulator_polygon_reader.py','prepare_regulator_polygon_proposal.py','qualify_regulator_polygon_proposal.py','regulator-polygon-diagnostic.json','regulator-polygon-diagnostic-before.py','regulator-polygon-diagnostic-after.py','normalize_findings_narrative.py','none-composed-source-spec-before-narrative.json']:
 copies.append((N/name,'root-methods/'+name))
for p in Path('/tmp/carrier-connector-integration-20260911').iterdir():
 if p.is_file() and p.name.startswith(('none-composed-','none-final-','none-schema-after-','regulator-polygon-')):copies.append((p,'root-runtime/'+p.name))
task=(N/'none-return-independent-review-TASK.md').read_text()+'''

Final composition clarification: author EXACT7 files plus root test_regulator_source.py
helper correction and root findings.yaml narrative normalization =9 exact postimages.
Author7 still INCOMPLETE delivery with source-mode evidence and procedural DEFECTIVE;
root helper was NOT incorporated or accepted by author. Root helper reuses existing
ADC test area_shape inside inspect (lazy import avoids mutual helper import cycle),
changes only2 keepout conversions, keeps8 original methods AST-identical and adds
one method with4 concave/enclosing/layer/deny controls. Existing full9-method proposal
against old inspect yields7 KeyError rect records (semantic consumer ERROR, not
import/setup error or false-PASS claim); final9 passes. Exact8 original methods also
passed preceding in-memory diagnostic, which is not normal gate acceptance. Review
this complete correction now, not just the previously exposed coverage gap.

Root static census has6polygon keepouts (2pour-only+4via-only),27 directrect reader
sites across8testfiles. Classify full affected population independently: tracks-only
loops and explicitly rectangular net-rule scopes need not be bugs. Existing source
helper shape implementation is test_adc_source.area_shape, not board generator's
method. Verify independent geometry controls and no accidental new broad permission.

Root final full-checkout source proof: Git516013e8 plus exactly9 afterimages,
63 explicit project tests +4 actual consumer methods PASS with native-operation
guards; final complete schema914/914(809PROVEN,0orphan),numeric bound provenance,
contracts17/17 with13knownbad PASS. Original8file preflight had1orphan metadata key
findings[].reassessment; root moved its exact narrative into existing finding field,
all states/history/budgets unchanged. This metadata correction is already live;
other8postimages remain isolated. Original failure retained; final9file preflight
reran all3governance checks, not restamped. All listed source bytes remain frozen.

Current-handoff STATUS predates this commission: source author has actually FINALed
and closed PASS; root is now commissioning YOU. No source or native acceptance follows
from that stale narrative. All5productattempts remain spent and no candidate6 admitted.
'''
ns['open_task']('rj45-none-return-independent-review1',task,copies,minutes=25)
