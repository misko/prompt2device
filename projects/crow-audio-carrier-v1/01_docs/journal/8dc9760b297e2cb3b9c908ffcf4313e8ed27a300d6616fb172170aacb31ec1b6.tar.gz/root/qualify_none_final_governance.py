from pathlib import Path
import json,hashlib,sys,os
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;Q=Path('/tmp/crow-none-return-full-qualification-20260913');L=N/'none-final-governance';L.mkdir(exist_ok=False)
spec=json.loads((N/'none-composed-source-spec.json').read_text());assert len(spec['files'])==9;(L/'input-source-spec.json').write_text(json.dumps(spec,indent=2)+'\n')
def verify():
 for row in spec['files']:assert hashlib.sha256((Q/row['path']).read_bytes()).hexdigest()==row['after_sha256']
verify();sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
results=[];env={k:os.environ[k] for k in ['PATH','HOME','LANG'] if k in os.environ};env['PYTHONDONTWRITEBYTECODE']='1'
for name,args in [('schema',['skills/kicad-pcb/scripts/schema_reader_audit.py','--root',str(Q)]),('bounds',['skills/kicad-pcb/scripts/adr_bound_provenance.py',str(Q),'--repo-root',str(Q),'--timeout','30']),('contracts',['tests/t1_contracts.py'])]:
 cmd=['/usr/bin/python3','-B',*args];r=run_stage({'id':'none-final-'+name,'work_class':'local','timeout_s':180},cmd,log_path=L/(name+'.log'),cwd=Q,env=env,console_line_limit=4,console_tail_lines=3);results.append({'name':name,'argv':cmd,'cwd':str(Q),'runtime':r.to_mapping()});(L/'results.json').write_text(json.dumps(results,indent=2)+'\n')
verify();print(json.dumps({'source_files':9,'results':{r['name']:r['runtime']['status'] for r in results}}));raise SystemExit(0 if all(r['runtime']['status']=='PASS' for r in results) else 1)
