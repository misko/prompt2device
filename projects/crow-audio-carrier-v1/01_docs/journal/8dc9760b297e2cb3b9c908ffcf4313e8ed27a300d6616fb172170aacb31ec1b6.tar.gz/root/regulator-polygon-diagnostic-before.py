def inspect(floor, route, nets, geometry):
    from test_thermal_source import thermal_rows
    rows = segment_rows(route)
    selected = [r for r in rows if r['id'] in CELL_PINS]
    ordinary = via_rows(route)
    thermal = thermal_rows(floor, geometry)
    vias = ordinary + thermal
    failures = []
    counts = Counter()
    pads = {p['id']: p for p in geometry['pads']}
    def check(a, b, kind, gap):
        counts[kind] += 1
        if a['shape'].Collide(b['shape'], round(gap*1e6)-2 if gap else 0):
            failures.append((kind, a['id'], b['id']))
    for pin in CELL_PINS:
        own = [r for r in selected if r['id'] == pin]
        if not own or any(r['net'] != pads[pin]['net'] for r in own):
            failures.append(('pin-net-or-coverage', pin))
        elif not any(r['shape'].Collide(pads[pin]['shape'], 0) for r in own):
            failures.append(('unreached-pin', pin))
    for row in selected:
        if row['layer'] != 'F.Cu':
            failures.append(('unreviewed-layer', row['id']))
        bounds = floor['board']['outline']; radius = row['width']/2
        if not all(bounds['x0']+.8+radius <= x <= bounds['x1']-.8-radius
                   and bounds['y0']+.8+radius <= y <= bounds['y1']-.8-radius
                   for x, y in (row['a'], row['b'])):
            failures.append(('edge', row['id']))
        for pad in pads.values():
            if row['net'] != pad['net']:
                check(row, pad, 'segment/native-pad', .25)
        for hole in geometry['holes']:
            check(row, hole, 'segment/native-hole', .255)
        for area in floor['keepouts']:
            if 'F.Cu' in area['layers'] and 'tracks' in area['deny']:
                check(row, dict(id=area['name'], shape=rect_shape(area['rect'])), 'segment/keepout', 0)
        for via in vias:
            if row['net'] != via['net']:
                check(row, via, 'segment/via', .25)
            # Only each ordinary via's own authored connection is intentional.
            # No thermal-hole shortcut or blanket same-GND drill exemption.
            if via['pin'] != row['id'] or via in thermal:
                check(row, dict(id=via['id'], shape=via['hole']), 'segment/via-hole', .255)
    for i, row in enumerate(rows):
        for other in rows[i+1:]:
            if (row['id'] in CELL_PINS or other['id'] in CELL_PINS) and row['net'] != other['net']:
                check(row, other, 'segment/segment', .25)
    for via in [v for v in ordinary if v['pin'] in CELL_PINS]:
        for fp in geometry['footprints']:
            for pad in fp.Pads():
                for layer in (pcbnew.F_Cu, pcbnew.In1_Cu, pcbnew.In2_Cu, pcbnew.B_Cu):
                    if pad.IsOnCopperLayer() and pad.IsOnLayer(layer):
                        check(dict(id=via['id'], shape=via['hole']),
                              dict(id=fp.GetReference()+'.'+pad.GetNumber(), shape=pad.GetEffectiveShape(layer)),
                              'via/no-pad-drill', .255)
        for pad in pads.values():
            if pad['net'] != via['net']:
                check(via, pad, 'via/native-pad', .25)
        for hole in geometry['holes']:
            check(dict(id=via['id'], shape=via['hole']), hole, 'via/native-hole', .5)
        for area in floor['keepouts']:
            if 'F.Cu' in area['layers'] and 'vias' in area['deny']:
                check(via, dict(id=area['name'], shape=rect_shape(area['rect'])), 'via/keepout', 0)
        for other in vias:
            if other['id'] == via['id']:
                continue
            check(dict(id=via['id'], shape=via['hole']),
                  dict(id=other['id'], shape=other['hole']), 'via/hole-pair', .5)
            if other['net'] != via['net']:
                check(via, other, 'via/copper-pair', .25)
        for row in rows:
            if row['net'] != via['net']:
                check(via, row, 'via/segment', .25)
    failures += [('extent', p) for p in extent_errors(floor, route, nets)]
    return dict(failures=failures, checks=dict(counts), segments=len(selected),
                vias=sum(v['pin'] in CELL_PINS for v in ordinary))
