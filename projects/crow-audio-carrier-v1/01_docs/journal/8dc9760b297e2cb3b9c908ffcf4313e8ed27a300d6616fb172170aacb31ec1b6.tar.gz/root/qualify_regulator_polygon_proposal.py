from pathlib import Path
import sys,inspect,importlib.util,json,unittest
import pcbnew
N=Path(__file__).parent;D=N/'regulator-polygon-proposal';Q=Path('/tmp/crow-none-return-full-qualification-20260913');T=Q/'projects/crow-audio-carrier-v1/03_src/tests';phase=sys.argv[1];assert phase in ['old-consumer','final']
for name in ['BOARD','LoadBoard','SaveBoard','ZONE_FILLER']:
 def forbidden(*a,_name=name,**k):raise AssertionError('Forbidden native operation '+_name)
 setattr(pcbnew,name,forbidden)
sys.path.insert(0,str(T))
spec=importlib.util.spec_from_file_location('test_regulator_source',D/'after.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
if phase=='old-consumer':
 old=(N/'regulator-polygon-diagnostic-before.py').read_text();exec(compile(old,'<original regulator inspect>','exec'),m.__dict__)
suite=unittest.defaultTestLoader.loadTestsFromTestCase(m.RegulatorSourceTests);assert suite.countTestCases()==9
r=unittest.TextTestRunner(verbosity=2).run(suite)
record={'scope':'Maintained nine-method proposal against '+phase+' inspect. Native BOARD/load/save/fill guarded. Old semantic rect KeyError is an unsupported-source consumer error, not an import/setup RED or false-PASS claim.','testsRun':r.testsRun,'failures':[(str(t),s) for t,s in r.failures],'errors':[(str(t),s) for t,s in r.errors]}
(D/(phase+'-result.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'testsRun':r.testsRun,'failures':len(r.failures),'errors':len(r.errors)}))
raise SystemExit(0 if r.wasSuccessful() else 1)
