from pathlib import Path
import sys,json,os,unittest,time,traceback,subprocess,hashlib
import pcbnew
N=Path(__file__).parent;Q=Path('/tmp/crow-none-return-full-qualification-20260913');L=N/'none-root-qualification'
for name in ['BOARD','LoadBoard','SaveBoard','ZONE_FILLER']:
 def forbidden(*a,_name=name,**k):raise AssertionError('Forbidden native operation '+_name)
 setattr(pcbnew,name,forbidden)
spec=json.loads((N/'none-composed-source-spec.json').read_text())
for row in spec['files']:assert hashlib.sha256((Q/row['path']).read_bytes()).hexdigest()==row['after_sha256']
sys.path.insert(0,str(Q/'tests'));sys.path.insert(0,str(Q/'skills/kicad-pcb/scripts'))
import t1_generate_board as gen
consumer=[];original_popen=subprocess.Popen
def no_subprocess(*a,**kw):raise AssertionError('Subprocess forbidden in isolated consumer test')
subprocess.Popen=no_subprocess
try:
 for name in ['t_pad_override_native_modes','t_pad_override_native_inheritance','t_pad_override_native_generic_selectors','t_pad_override_native_invalid_modes']:
  now=time.monotonic();err=None
  try:getattr(gen,name)()
  except Exception:err=traceback.format_exc()
  consumer.append({'name':name,'status':'FAIL' if err else 'PASS','error':err,'elapsed_s':time.monotonic()-now})
finally:subprocess.Popen=original_popen
sys.path.insert(0,str(Q/'projects/crow-audio-carrier-v1/03_src/tests'))
os.environ['GIT_DIR']=(Q/'.git').read_text().strip().split(': ',1)[1];os.environ['GIT_WORK_TREE']=str(Q)
classes=['test_ground_connections.GroundConnectionTests','test_regulator_source.RegulatorSourceTests','test_route_source_contract.RouteSourceContractTests','test_adc_feed_source.AdcFeedSourceTests','test_adc_feed_source.Adc2ReservationTests','test_thermal_source.ThermalSourceTests']
all_ids=[]
def flatten(s):
 for t in s:
  if isinstance(t,unittest.TestSuite):yield from flatten(t)
  else:yield t
for name in classes:
 for t in flatten(unittest.defaultTestLoader.loadTestsFromName(name)):
  if t.id().endswith('test_targets_are_real_smd_ground_lands_on_declared_sides'):continue
  all_ids.append(t.id())
all_ids += ['test_adc_channel_map.ChannelMapTests.test_pad_overrides_follow_physical_lands_through_ref_exchange','test_local_placement_source.LocalPlacementSourceTests.test_exact_eight_clamp_pad4_ground_override']
assert len(all_ids)==len(set(all_ids)) and len(all_ids)>43
suite=unittest.defaultTestLoader.loadTestsFromNames(all_ids)
r=unittest.TextTestRunner(verbosity=2).run(suite)
for row in spec['files']:assert hashlib.sha256((Q/row['path']).read_bytes()).hexdigest()==row['after_sha256']
result={'scope':'Exact final nine-file composition in complete detached checkout; native BOARD/load/save/fill guarded. Four actual consumer methods additionally prohibit subprocess; explicit project tests permit Git historical input only as their existing methods require. Board-based ground-side fixture remains excluded/owed.','consumer':consumer,'project_ids':all_ids,'project_testsRun':r.testsRun,'project_failures':[(str(t),s) for t,s in r.failures],'project_errors':[(str(t),s) for t,s in r.errors],'source_postimages_unchanged':True}
(L/'focused-tests.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'consumer_pass':sum(x['status']=='PASS' for x in consumer),'consumer_total':len(consumer),'project_tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors)}))
raise SystemExit(0 if r.wasSuccessful() and all(x['status']=='PASS' for x in consumer) else 1)
