from pathlib import Path
import sys,inspect,json,hashlib,unittest
import pcbnew
N=Path(__file__).parent;Q=Path('/tmp/crow-none-return-full-qualification-20260913');T=Q/'projects/crow-audio-carrier-v1/03_src/tests'
for name in ['BOARD','LoadBoard','SaveBoard','ZONE_FILLER']:
 def forbidden(*a,_name=name,**k):raise AssertionError('Forbidden native operation '+_name)
 setattr(pcbnew,name,forbidden)
sys.path.insert(0,str(T))
import test_regulator_source as reg
old=inspect.getsource(reg.inspect)
assert old.count("rect_shape(area['rect'])")==2
new=old.replace('    rows = segment_rows(route)','    from test_adc_source import area_shape\n    rows = segment_rows(route)',1).replace("rect_shape(area['rect'])",'area_shape(area)')
assert '    from test_adc_source import area_shape\n' in new
(N/'regulator-polygon-diagnostic-before.py').write_text(old)
(N/'regulator-polygon-diagnostic-after.py').write_text(new)
exec(compile(new,'<DIAGNOSTIC polygon reader only>','exec'),reg.__dict__)
suite=unittest.defaultTestLoader.loadTestsFromTestCase(reg.RegulatorSourceTests)
r=unittest.TextTestRunner(verbosity=2).run(suite)
record={'scope':'DIAGNOSTIC only: two rect-only keepout conversions in existing regulator inspect replaced IN MEMORY by existing source-test area_shape supporting source polygons. Original live/Q source untouched; no normal gate acceptance, no BOARD/load/save/fill.','source_sha256':hashlib.sha256((T/'test_regulator_source.py').read_bytes()).hexdigest(),'testsRun':r.testsRun,'failures':[(str(t),s) for t,s in r.failures],'errors':[(str(t),s) for t,s in r.errors]}
(N/'regulator-polygon-diagnostic.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k] for k in ['testsRun','failures','errors']}))
raise SystemExit(0 if r.wasSuccessful() else 1)
