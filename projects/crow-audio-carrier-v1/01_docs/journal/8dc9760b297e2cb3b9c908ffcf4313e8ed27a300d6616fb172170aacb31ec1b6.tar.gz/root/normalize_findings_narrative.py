from pathlib import Path
import yaml,json,hashlib,copy
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');Q=Path('/tmp/crow-none-return-full-qualification-20260913');N=Path(__file__).parent
rel='projects/crow-audio-carrier-v1/01_docs/findings.yaml';p=R/rel;raw=p.read_text();data=yaml.safe_load(raw);before=copy.deepcopy(data)
start=raw.index('- id: CARRIER-ROUTE-SOURCE-BASELINE-001');prefix=raw[:start];part=raw[start:]
a=part.index('  reassessment: ');b=part.index('  closes_when:',a)
paragraph=part[a:b];content=paragraph.replace('  reassessment: ','    ',1)
changed=prefix+part[:a]+content+part[b:];after=yaml.safe_load(changed)
olditems=before['findings'];newitems=after['findings'];assert len(olditems)==len(newitems)
for old,new in zip(olditems,newitems):
 if old['id']=='CARRIER-ROUTE-SOURCE-BASELINE-001':
  expected=copy.deepcopy(old);extra=expected.pop('reassessment');expected['finding']+=' '+extra;assert new==expected
 else:assert old==new
assert (Q/rel).read_text()==raw
D=N/'findings-narrative-schema-correction';D.mkdir(exist_ok=False);(D/'before.yaml').write_text(raw);(D/'after.yaml').write_text(changed)
p.write_text(changed);(Q/rel).write_text(changed)
row={'path':rel,'before_sha256':hashlib.sha256(raw.encode()).hexdigest(),'after_sha256':hashlib.sha256(changed.encode()).hexdigest(),'after_path':str(D/'after.yaml'),'scope':'Root narrative-only schema correction: move undeclared reassessment text verbatim into existing finding. All finding states and investigation histories/budgets unchanged; no new schema field/reader claim.'}
(D/'manifest.json').write_text(json.dumps(row,indent=2)+'\n')
specp=N/'none-composed-source-spec.json';spec=json.loads(specp.read_text());assert len(spec['files'])==8;(N/'none-composed-source-spec-before-narrative.json').write_text(specp.read_text());spec['files'].append(row);specp.write_text(json.dumps(spec,indent=2)+'\n');print(json.dumps(row))
