from pathlib import Path
import hashlib,json
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;D=N/'regulator-polygon-proposal';D.mkdir(exist_ok=False)
rel='projects/crow-audio-carrier-v1/03_src/tests/test_regulator_source.py';before=(R/rel).read_text();assert before.count("rect_shape(area['rect'])")==2
new=before.replace('    from test_thermal_source import thermal_rows\n','    from test_thermal_source import thermal_rows\n    # Existing ADC source-test reader handles exact concave polygon keepouts.\n    # Import here because that module imports our via/extent helpers.\n    from test_adc_source import area_shape\n',1).replace("rect_shape(area['rect'])",'area_shape(area)')
method='''    def test_polygon_via_keepout_uses_actual_shape_and_scope(self):
        # Before this repair, valid current via-only polygons raised KeyError
        # in inspect before any classification. This is a real consumer error,
        # not an import/setup failure or a false-PASS regression claim.
        # A concave L has the via inside its bbox but outside actual copper;
        # the enclosing triangle must be detected. Native board DRC stays owed.
        via = next(v for v in via_rows(self.route) if v['pin'] in CELL_PINS)
        x, y = via['at']
        self.assertLess(via['size'] / 2, 1.)
        outlines = {
            'concave': [(-2., -2.), (2., -2.), (2., -1.),
                        (-1., -1.), (-1., 2.), (-2., 2.)],
            'enclosing': [(-1., -1.), (1., -1.), (0., 1.)],
        }
        for shape, layers, deny, expected in [
            ('concave', ['F.Cu'], ['vias'], False),
            ('enclosing', ['F.Cu'], ['vias'], True),
            ('enclosing', ['In1.Cu'], ['vias'], False),
            ('enclosing', ['F.Cu'], ['tracks'], False),
        ]:
            with self.subTest(shape=shape, layers=layers, deny=deny):
                floor = copy.deepcopy(self.floor)
                area = dict(name='REGULATOR_POLYGON_CONTROL', layers=layers,
                            deny=deny, points=[[x+dx, y+dy]
                                              for dx, dy in outlines[shape]])
                floor['keepouts'].append(area)
                report = inspect(floor, self.route, self.nets, self.geometry)
                finding = ('via/keepout', via['id'], area['name'])
                self.assertEqual(finding in report['failures'], expected)

'''
anchor="\n\nif __name__ == '__main__':";assert anchor in new
new=new.replace(anchor,'\n\n'+method+anchor,1)
(D/'before.py').write_text(before);(D/'after.py').write_text(new)
record={'path':rel,'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(new.encode()).hexdigest(),'after_path':str(D/'after.py'),'scope':'Proposed test-helper-only exact polygon consumption using existing independent source-test shape reader; preserves all8 original test methods and adds4 scoped polygon controls. No live adoption or native board generation. Pre-fix valid product source consumer KeyError retained; not an import/setup RED claim.'}
(D/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
