from pathlib import Path
from collections import Counter
import hashlib,json,yaml
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
rows=[];sources=[];errors=[]
for parent in ['projects','archived_projects','examples','skills/pcb-design/templates']:
 for p in sorted((R/parent).rglob('floorplan.yaml')):
  if any(x in p.parts for x in ['07_releases','06_build','node_modules']):continue
  try:d=yaml.safe_load(p.read_text())
  except Exception as e:errors.append({'path':str(p.relative_to(R)),'error':str(e)});continue
  if not isinstance(d,dict):continue
  sources.append({'path':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
  for i,pat in enumerate((d.get('placement') or {}).get('patterns') or []):
   for j,ov in enumerate(pat.get('pad_overrides') or []):
    rows.append({'path':str(p.relative_to(R)),'pattern':i,'override':j,'match':pat.get('match'),'pads':ov.get('pads'),'on_net':ov.get('on_net'),'mode_present':'zone_connection' in ov,'mode':ov.get('zone_connection'),'clearance_present':'clearance' in ov})
invalid=[r for r in rows if r['mode_present'] and r['mode'] not in ['full','thermal','none']]
out={'scope':'Read-only authored floorplan compatibility inventory excluding disposable build and immutable releases; no native generation. Broadening absent-mode behavior remains forbidden. YAML errors are not interpreted as absent overrides.','sources':sources,'overrides':rows,'invalid_modes':invalid,'errors':errors,'counts':{'source_files':len(sources),'overrides':len(rows),'modes':dict(Counter(str(r['mode']) if r['mode_present'] else '<absent>' for r in rows)),'invalid_modes':len(invalid),'errors':len(errors)}}
(N/'pad-mode-compatibility-inventory.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out['counts']))
