from pathlib import Path
import json,hashlib,tarfile,shutil
s=Path(__file__).parent;root=s.parents[3];out=s.parent/"outputs";out.mkdir(exist_ok=True)
e=json.loads((s.parent/"envelope.json").read_text());measured=json.loads((s/"measured.json").read_text())
for name in ["TASK.md","pin-review-protocol.md","preflight.py","previous-closeout.json","previous-completed-report.md"]:shutil.copyfile(root/name,s/name)
shutil.copyfile(root/"supplement/declared-architecture.md",s/"declared-architecture.md")
shutil.copyfile(s.parent/"envelope.json",s/"envelope.json")
findings=[{"ref":"J10","verdict":"PASS","finding":"MCH manual p24 Table12 TDM8 exactly matches pins2/9/10/11/12 and intentionally unused pins1/3-8. Manual p10 Figure1 top-view identities agree by 90-degree rotation."},{"ref":"J11","verdict":"PASS","finding":"MCH manual p10 Table1 and p8 section2.4 confirm J3 pins1 GND/2 3.3V; remaining contacts unused by declared sense-only interface, including optional inverted BCLK at11. Top-view physical identities agree."},{"ref":"J10,J11","verdict":"PASS","finding":"Distinct MCH J1/J3 application roles independently explain former symmetry question; passive package identity does not impose identical nets."},{"ref":"J9","verdict":"PASS","finding":"Original physical and function-net finding preserved, dossier byte identity verified and counts remeasured."}]
obj={"verdict":"SOUND","subject":e["subject"],"context":"Independent original review continued with requested native/primary facts; not a new fresh agent","reviewer":"/root/rj45_pin_carrier_headers_clockground1","review_stage":"pre-route","review_kind":"pin","order_verdict":"DO-NOT-ORDER","coverage":["J10","J11","J9"],"inherited_coverage":"Original manufacturer physical-figure inspection, winding interpretation, counts and identity checks for all three refs; exact dossier and PDF digests unchanged.","new_coverage":"Visual MCH manual p8/p10/p24 and TCSD sheets1-4; declared application allocation compared to native net tables; physical counts and native transforms remeasured.","methods":["Verified all 13 envelope input hashes and sizes before and after review.","Used finite pipeline_runtime.run_stage with direct argv and explicit cwd/env for pdftoppm, text location and native measurements.","Inspected actual page images, including explicit top-of-board Fig1 and TDM8 Table12; interpreted female mating-face separately.","Compared declared separate MCH J1/J3 port roles against manufacturer functions and every native dossier pin.","Retained original closed review unchanged and inherited inspected images; no live source reads or edits.","Reopened every archive regular member and checked no traversal, duplicate, symlink or recursive archive; exact-envelope preflight validates delivery."],"findings":findings,"measured_counts":measured,"unresolved_pin_findings":[],"separate_physical_holds":["Exact fitted cable correspondence, seating/depth, retention and labeling","First-article powered and interface tests","Whole-board acceptance and release authorization"],"primary_documents":[x for x in e["input_packet"] if x["path"].endswith(".pdf")],"application_context":[x for x in e["input_packet"] if x["path"]=="supplement/declared-architecture.md"],"original_report_sha256":"abc5eb37d241d424e6d17699df5f9e809fb045b9995f7e6e250a1b9a43901bc2"}
(s/"evidence.json").write_text(json.dumps(obj,indent=2))
for name in ["report.md","evidence.json"]:shutil.copyfile(s/name,out/name)
archive=out/"evidence.tar.gz";files=sorted(p for p in s.rglob("*") if p.is_file() and not p.name.startswith("preflight-final"))
with tarfile.open(archive,"w:gz") as tf:
 for p in files:
  assert not p.is_symlink();tf.add(p,arcname=p.relative_to(s).as_posix(),recursive=False)
rows=[];seen=set()
with tarfile.open(archive,"r:gz") as tf:
 for m in tf.getmembers():
  assert m.isfile() and not m.issym() and not m.islnk() and m.name not in seen and not Path(m.name).is_absolute() and ".." not in Path(m.name).parts and not m.name.endswith((".tar",".tar.gz",".tgz"));seen.add(m.name)
  data=tf.extractfile(m).read();assert len(data)==m.size and data==(s/m.name).read_bytes()
  rows.append(dict(path=m.name,size=len(data),sha256=hashlib.sha256(data).hexdigest()))
(out/"evidence-manifest.json").write_text(json.dumps(dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_size=archive.stat().st_size,member_count=len(rows),members=rows),indent=2))
(out/"result.json").write_text(json.dumps(dict(subject=e["subject"],checks={x:"PASS" for x in e["completion"]["checks"]},unresolved=[]),indent=2))
print(json.dumps(dict(verdict="SOUND",outputs=str(out),member_count=len(rows))))
