review_stage: pre-route
review_kind: pin
reviewer: agent /root/rj45_pin_carrier_headers_clockground1
context: Independent original review continued with requested native/primary facts; not a new fresh agent
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: e85b1461a82f3d3853c19fae694693816e31570d23d37019ef187d6428bea4ae
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: e6d5b0b89efd79051b082f70b283ec7e85e1170ed11ddb94581744d26904c9c7

Limited group coverage: J10, J11, J9 only. All three PASS for physical pin identity and declared application pin allocation. This is not whole-board, cable-fit, routing, signal-integrity or release acceptance. FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains. Original report abc5eb37d241d424e6d17699df5f9e809fb045b9995f7e6e250a1b9a43901bc2 remains immutable; the former missing-context questions are resolved below with additional primary evidence. Envelope context_mode is mechanically FRESH, but this report truthfully records continued reviewer context.

Inherited physical coverage, independently established in the original review: actual Samtec and Molex figure images were inspected before native dossiers. All three are front-mounted, with explicit component-top coordinates (+x right, +y down) and no mount reflection. Current dossiers and both physical primary PDFs have identical SHA256 to those reviewed originally. Native positions and counts were measured again in this continuation.

Samtec TMM-Series_RevAS.pdf SHA256 66d9ffaa15ef8ff9b1614640d81fd2d1c2c6629b522df0cddc64acac3e73efc3, PDF page 1 / sheet 1, FIG. 1 numbered post-side plan and -D section: twelve separate contacts, six positions, two rows, 2 mm pitch. Pin 1 is lower left in the post-side drawing; odds progress rightward on lower row, evens above. A clockwise 90-degree rotation maps it to each dossier, odds at (0,2*k) and evens at (2,2*k), k=0..5. The unnumbered bottom/tail-side plan was not substituted. Alternating-row numbering is not a perimeter winding, so the dossier's CW label is not a standalone correctness test. No EP, fusion or identity collapse. The relevant standard -D geometry is present despite the selected PDF containing only sheet 1 of 2.

New primary evidence was visually inspected from rendered pages:
- MCHStreamer_User_Manual.pdf SHA256 2cf36d628df68607d007b971a13a3a578916d74629d6660571daf218cfbc6edd: page 10 Figure 1 explicitly labels top of board. Module J1 has pin 1 lower left, odds along lower row and evens above; module J3 has pin 1 upper left, odds down left and evens down right. J1 rotates clockwise 90 degrees to the carrier component-top frame; J3 already matches it. No mirror is needed for either header.
- Same manual page 24 Table 12 TDM8 column supplies exact J1 functions and identifies J3 pin 11 as inverted BCLK. Page 10 Table 1 gives J3 pin 1 ground and pin 2 3.3V. Page 8 section 2.4 independently confirms J3 pin 2 is an external 3.3V output (200 mA maximum).
- TCSD-Series_RevBE.pdf SHA256 fa4643ec2ea321bf7bc186d20bf8c1b31a7fb0b3d335662c2ba8eba9007b108b: sheets 1-4 inspected. Sheet 1 shows the 2 mm double-row female IDC assembly and first-position indicator, standard colored-conductor side, and explicit -RW reverse-wiring alternative. Sheet 2 shows reverse-notch/socket and daisy-chain alternatives. Female mating-face views are not male component-top views. This family drawing supports contact/marker interpretation but does not prove which cable variant is installed or close physical fit/continuity qualification.
- Declared architecture SHA256 7379a67fca6e891e2f56751589cb953b5f8ad69857c6722712d211ea98c8e9ee, ADC and clocks section, supplies application intent: J10 serves MCH J1 in TDM8 receive mode; J11 serves MCH J3 ground and rail sense only. Intent was compared against primary manual facts, not treated as manufacturer authority.

J10 VERDICT: PASS
Measured 12 native numbered pads / 12 distinct electrical physical identities / 12 unique numbered lands / 0 EP / 0 aliases / 0 listed unnumbered mechanical features. Manufacturer geometry and every physical identity match as above.
J10 pin 1 (ROW1_COL1): manual TDM8 J1 output Ch1-8 may be unused by this recording-only carrier; architecture explicitly requires no connection; observed unconnected-(J10-NC1-Pad1).
J10 pin 2 (ROW1_COL2): expected module TDM input Ch1-8; observed ADC_TDM, consistent with carrier ADC stream to module.
J10 pins 3,4,5,6,7,8 (ROW2_COL1 through ROW4_COL2): expected unused in TDM8 Table 12; observed six individually named unconnected nets, with separate pads retained.
J10 pin 9 (ROW5_COL1): expected module MCLK output; observed MCH_MCLK.
J10 pin 10 (ROW5_COL2): expected module BCLK output; observed MCH_BCLK.
J10 pin 11 (ROW6_COL1): expected module ground, explicitly Table 12; observed GND. This closes the named clock-ground mapping question.
J10 pin 12 (ROW6_COL2): expected module FSYNC output; observed MCH_FSYNC.

J11 VERDICT: PASS
Measured 12 native numbered pads / 12 distinct electrical physical identities / 12 unique numbered lands / 0 EP / 0 aliases / 0 listed unnumbered mechanical features. Manufacturer geometry and every physical identity match as above.
J11 pin 1 (ROW1_COL1): expected MCH J3 GND; observed GND.
J11 pin 2 (ROW1_COL2): expected MCH J3 3.3V output used as sense input by carrier; observed MCH_3V3_SENSE. Architecture declares about 0.320 mA sensing and no carrier-rail supply; loading/current is declared context, not independently remeasured by this pin review.
J11 pins 3,4,5,6,7,8,9,10,12: expected unused by this TDM8 sense-only interface; observed nine distinct individually named unconnected nets. PDM sample functions in Table 1 are not imposed on the TDM8 firmware.
J11 pin 11 (ROW6_COL1): expected optional inverted BCLK output under Table 12; unused by declared carrier interface; observed unconnected-(J11-NC11-Pad11), no conflict.
Pairwise review: J10 and J11 have the same passive contact geometry but connect to different module ports, J1 and J3. Differences at 1,2,9,10,11,12 agree with those primary-defined port roles. No symmetry defect remains; identical application nets are not required of passive headers with distinct purposes.

J9 VERDICT: PASS (original independent finding retained)
Primary Molex Molex_436501000_SD_revD8.pdf SHA256 b8942b95bc3fe4c02171de9e714d99b2688055e249ba1524e3c2a8c3cf78eaa3, PDF page 1 / sheet 1 of 1, PCB LAYOUT: COMPONENT SIDE, PCB LAYOUT: 2 CKT, material table 43650-0200.
Measured 2 native numbered pads / 2 physical electrical identities / 2 unique numbered lands / 1 unnumbered 3 mm NPTH mechanical peg / 0 EP / 0 aliases. Manufacturer circuit 1 at right, circuit 2 at left, peg centered 4.32 mm below contact line; rotating 180 degrees gives dossier pin 1 (0,0), pin 2 (3,0), peg (1.5,-4.32). This verifies identity relative to peg; two collinear contacts alone establish no winding. No mirror is used. Numbered contact drill dimensions are absent from dossier and not certified by this pin-identity review.
J9 pin 1 (+12V_IN): expected rail-type net for declared passive input contact; observed 12V_IN.
J9 pin 2 (GND): expected declared ground; observed GND. Manufacturer imposes no intrinsic connector polarity. Harness assembly and first-article fit remain separate.

No unresolved pin-review questions remain within this commissioned group. Actual fitted cable correspondence, seating/depth, retention and labeling remain separately owed physical evidence, as do powered tests and complete board acceptance. The archive retains inherited inspected figures and methods, new inspected manual/cable figures, native dossiers, measured per-pin data, scripts, raw logs/runtime records and input digests. Exact primary PDFs remain available in the frozen digest-bound packet.
