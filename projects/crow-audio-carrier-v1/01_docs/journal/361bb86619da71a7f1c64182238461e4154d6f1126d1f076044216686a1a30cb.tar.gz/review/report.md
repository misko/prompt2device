review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_conversion_mountedframe1 (actual fresh agent)
context: FRESH
design_verdict: INCOMPLETE
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7
subject_raw_sha256: 084c8feea47a96890190eb4e165a289213c3182484692775ad05c2995190f84f
subject_semantic_sha256: cff15c2597f85a783ec9ab7a5133740a27b050694cac0be01dcb54c166b510c2

Coverage is limited to U_ADC and U_LDO, one instance of each. This is no whole-board acceptance and no routing, assembly orientation-file, thermal or decoupling-layout approval. Exact supplied primary PDFs and native dossiers were the only engineering sources. The three immutable board/parts/rules bindings above are commission metadata, not independently reproduced conclusions.

## U_ADC — VERDICT: QUESTION

Primary: Cirrus CS5308P DS1314F1, SHA-256 6ca42cc09ac47ebdacacaee435f05e3f9c34b83d5692e52a2d8a26533e810e57. Actual inspected images: PDF p.4 Figure 1-1; p.5 Table 1-1; p.6 Table 1-2; p.8 Figure 2-2; pp.19–20 Tables 4-1–4-4; p.93 Figure 10-1.

Package/identity PASS: Figure 1-1 explicitly says TOP VIEW, THROUGH PACKAGE. Pin 1 is the upper-left terminal of the west row; numbering runs 1–12 downward on west, 13–24 left-to-right on south, 25–36 upward on east, and 37–48 right-to-left on north. This is CCW in the specified component-top frame. Dossier is front F.Cu, +x right/+y down, rotation zero: no reflection or rotation is needed. Independent shoelace calculation yields signed twice-area -67.37 mm² in y-down coordinates, consistent with CCW. Pin 1 observed (-2.95,-2.20), pin 12 (-2.95,+2.20), pin 24 (+2.20,+2.95), pin 36 (+2.95,-2.20), pin 48 (-2.20,-2.95). Exactly 12 lands per edge and 0.4 mm pitch match the figure.

Figure 10-1's right-hand drawing is BOTTOM VIEW: reflecting its x coordinate yields the top view, placing physical pin 1 back at upper left. That explicit manufacturer-view conversion is separate from mounting; no reflection was applied to the already component-top dossier. The 6 × 6 mm QFN has 48 separate perimeter contacts and one exposed die-attach paddle, nominally 4.6 × 4.6 mm. The dossier has 49 numbered native pad rows, 49 unique numbers, 49 distinct native centers and 49 mapped physical identities (48 terminals plus paddle mapped to artifact number 49); zero missing or duplicate numbered pads. PAD is the datasheet name, not a manufacturer-assigned number 49. No fused identities or aliases are needed. Nine additional unnumbered paste/mechanical pads are stated by the dossier but omitted from its table; their count is reported, not independently measured from native rows.

U_ADC pin 49 (PAD/EP): expected common ground per Table 1-1 footnote and 4.6 × 4.6 mm exposed-pad geometry; observed center (0,0), 4.6 × 4.6 mm, GND — PASS for pin/net identity.
U_ADC pins 5,9,31 (VDD_A1,VDD_A2,VDD_IO): expected analog supplies tied together and an I/O rail; observed 3V3_ADC on all three — PASS for rail class and identity.
U_ADC pins 6,8,30 (GND_A,GND_A,GND_D): expected ground; observed GND — PASS.
U_ADC pins 32,33 (LDO_D_FILT,VDD_D): expected internal digital LDO output tied directly to digital supply, per p.19 section 4.1; observed common LDO_D_FILT net — PASS.
U_ADC pin 7 (LDO_A_FILT): expected dedicated LDO bypass node; observed LDO_A_FILT — PASS for net class.
U_ADC pins 1,12 (ADC_VMID1,ADC_VMID2): expected separate midpoint reference/bypass nodes; observed VMID1 and VMID2 — PASS for net class.
U_ADC pins 17,44 (ADC_FILT2N,ADC_FILT1N): expected ground-side filter connections as explicitly drawn in Figure 2-2; observed GND — PASS.
U_ADC pins 18,43 (ADC_FILT2P,ADC_FILT1P): expected dedicated filtered analog-supply nodes; observed FILT2P and FILT1P — PASS for net class. Associated resistor/capacitor values are outside this pin-table evidence.
U_ADC pins 13,14,15,16,19,20,21,22 (IN5N/P,IN6N/P,IN7N/P,IN8N/P): expected matched differential input net pairs with preserved polarity; observed ADC5N/P, ADC6N/P, ADC7N/P, ADC8N/P — PASS for identity and net class.
U_ADC pins 39,40,41,42,45,46,47,48 (IN1N/P,IN2N/P,IN3N/P,IN4N/P): expected differential pairs preserving N/P; observed ADC4N/P, ADC3N/P, ADC2N/P, ADC1N/P respectively — PASS for pin identity and polarity. Channel-label permutation 1↔4 and 2↔3 is explicitly observed; the datasource does not establish external system channel ordering, which is not inferred here.
U_ADC pins 23,24,29,34 (RESET active-low,ASP_FSYNC,ASP_BCLK,MCLK): expected reset and clock/synchronization signal nodes; observed ADC_RESET_N, ADC_FSYNC, ADC_BCLK, ADC_MCLK — PASS for pin/net class; frequencies and timing are not provided.
U_ADC pins 26–28 (ASP_DOUT2–4): expected floating termination when unused per Table 1-2; observed unique unconnected-(U_ADC-ASP_DOUTx_NC-Padn) nets — termination matches unused-output rule; mode applicability remains under Q1.
U_ADC pins 35–38 (SPI_SDO/I2C_SCL,SPI_SCK,SPI_SDI/I2C_SDA,SPI_CS): expected GND/GND/GND/VDD_IO when unused per Table 1-2; observed GND/GND/GND/3V3_ADC — termination matches the unused-port rule; mode applicability remains under Q1.
U_ADC pin 4 (CONFIG3/HGC_SDO): expected a valid hardware configuration pull or unused-pin ground; observed GND. In hardware maximum-slot TDM this selects slots 0–7 per Table 4-2; actual hardware mode is unresolved under Q1.
U_ADC pins 2,3,10,11,25 (CONFIG1,CONFIG2/HGC_SCK,CONFIG4/HGC_CS,CONFIG5,ASP_DOUT1): expected valid configuration resistances to the specified rail and a corresponding serial-output configuration; observed CFG1, CFG2, CFG4, CFG5 and TDM_RAW. Q1 — QUESTION: provide the actual configuration resistor values and rail endpoints on CFG1, CFG2, CFG4 and CFG5, and the intended ASP mode. Table 4-1 permits CONFIG1 to select software mode (direct VDD_A tie) or hardware modes, while CONFIG2 selects TDM/I2S/left-justified operation. Named CFG nets alone do not establish which is selected. The grounded control port and unused DOUT2–4 are electrically sanctioned only with the appropriate operating configuration. No definite error is asserted from the missing context.

All 49 numbered rows have matching primary pin functions; Q1 concerns mode-dependent net use, not package winding. One U_ADC instance was supplied, so inter-instance symmetry is not applicable. Within the ADC, all eight N/P channel pairs preserve polarity; filter/reference groups use the same kind of nodes.

## U_LDO — VERDICT: PASS

Primary: Analog Devices LT3041 Rev.A, SHA-256 35dda1deb2ffc9e20545ebe2aefd2fbd690cf9b04e8772290fd4991a4b8ef584. Actual inspected images: PDF pp.7–8 Figure 3 and Table 3; p.31 Figures 87–89; p.36 Figure 98, package 05-08-1708 and ordering guide. PDF p.2 was also rendered and inspected to locate pin configuration; it is the contents page, not pinout evidence.

Figure 3 is explicitly TOP VIEW: pins 1–7 descend the left row, 8–14 ascend the right row, with pin 1 upper left and exposed pad 15 centered and grounded. This is CCW. Dossier is front F.Cu with zero rotation; no mirror or rotation is needed against Figure 3. Measured perimeter signed twice-area is -17.4 mm², CCW in y-down coordinates. Pad 1 (-1.45,-1.50), 7 (-1.45,+1.50), 8 (+1.45,+1.50), 14 (+1.45,-1.50) agree. Seven pads per long row at 0.5 mm pitch are present. The dossier's radial N/S labels on the four corner terminals are classifier labels; their actual coordinates place them at the ends of the two side rows and match the manufacturer image.

Figure 98 bottom-view drawing has pin 1 at lower right; mirror x to convert to top view (pin 1 lower left), then rotate clockwise 90° to obtain Figure 3/dossier orientation (pin 1 upper left). Figure 98 recommended lands rotate correspondingly to a 3 × 4 mm body orientation, 1.7 × 3.3 mm EP, 0.7 × 0.25 mm peripheral lands, 0.5 mm pitch, and ±1.45 mm side-row center coordinates. All match observed pad geometry. The exact ADE#TRPBF orderable package is listed against 05-08-1708.

Measured 15 numbered native pad rows, 15 unique numbers, 15 distinct native centers and 15 physical identities (14 perimeter terminals plus EP15); zero missing or duplicate numbered pads. No fused identities or aliases. Eight omitted unnumbered paste/mechanical pads are stated by the dossier only, not independently counted from native rows.

U_LDO pins 1,2,3 (IN): expected common input supply; observed 5V_LDO_HOLD — PASS.
U_LDO pin 4 (VIOC): expected unused tracking output may float, as Figures 87–89 explicitly show; observed unconnected-(U_LDO-VIOC_NC-Pad4) — PASS. This is an unused functional output, not a manufacturer NC pin.
U_LDO pin 5 (EN/UV): expected enable/UVLO signal or input-tied enable, not an unconnected pin; observed LDO_EN — PASS for net class. Threshold/divider values are not supplied or accepted by this pin review.
U_LDO pin 6 (PG): expected unused open-drain output floating per Table 3; observed unconnected-(U_LDO-PG_NC-Pad6) — PASS.
U_LDO pin 7 (ILIM): expected GND if external programmable limit is unused per Table 3; observed GND — PASS.
U_LDO pin 8 (PGFB): expected IN when power-good and fast-start functions are unused per Table 3 and Figure 89; observed 5V_LDO_HOLD, identical to IN — PASS.
U_LDO pin 9 (SET): expected dedicated regulation setpoint resistor/bypass node; observed LDO_NR, distinct from input/output/ground — PASS for net class. Programming resistance and output-voltage accuracy are outside this dossier.
U_LDO pins 10,11,15 (GND,GND,EPAD): expected ground, including the electrical exposed-pad connection; observed GND on all three — PASS.
U_LDO pin 12 (OUTS): expected output-sense connection; observed 3V3_ADC, identical to output pins — PASS for net connectivity; Kelvin routing is not reviewed pre-route.
U_LDO pins 13,14 (OUT): expected common output rail; observed 3V3_ADC — PASS.

Only one U_LDO instance was supplied. Internal symmetry holds across all three IN terminals, both OUT terminals, both GND terminals and EP ground.

## Method, limitations, and handback meaning

Every envelope input is verified by SHA-256 and byte count before and after the review. Manufacturer images were rendered using pdftoppm and opened using view_image; pdftotext/rg only located and supported primary text. Actual numbered pad rows, unique identities, native coordinate centers, front-to-component-top conversion and signed winding were measured from the frozen native dossiers. No live board, schematic, historical review or author explanation was consulted. The dossier tables were read during initial packet bootstrap before first image rendering; the subsequent engineering derivation used actual manufacturer figure images. This sequencing limitation is disclosed rather than claiming a strictly figure-first read order.

No inference of resistor values, routing quality, capacitor presence, or configuration from a net's name is made. Net-class passes do not certify the surrounding circuit. Q1 is the sole unresolved engineering finding: operating mode is essential to accepting the ADC's explicit unused-port wiring. Domain verdict remains INCOMPLETE; DO-NOT-ORDER is mandatory. Delivery PASS means this honest limited review, including its QUESTION, is fully handed back; it is not design acceptance. The result.json unresolved array addresses undelivered work, not the engineering question preserved in this report and evidence.json.
