from placement_review_common import *
name='rj45-top-only-launch-reassessment1';old=json.loads((N/'rj45-top-only-correction1-opened.json').read_text());assert json.loads(Path(old['attempt']).read_text())['status']=='ERROR'
D0=Path(old['project']);S=Path(old['scratch_dir']);copies=[(D0/'input','input')]
for rel in ['methods','logs','native-placement','carrier-native-measurements.json','pod-native-measurements.json','carrier-placement-drc.json','pod-drc.json','carrier-drc-classification.json','pod-drc-classification.json','analytical-next-decision-options.json','analytic-fanout-preflight.json','source-construction-checks.json','views']:
 copies.append((S/rel,'recovered/'+rel))
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 for rel in ['03_src','04_kicad','06_build/route']:
  p=S/'work/projects'/slug/rel
  if p.exists():copies.append((p,'candidate/'+slug+'/'+rel))
for fn in ['rj45-top-only-correction1-recovery.json','rj45-top-only-correction1-provider-recovery-summary.json']:
 copies.append((N/fn,'root/'+fn))
copies.append((R/'projects/crow-audio-carrier-v1/01_docs/findings.yaml','current-findings.yaml'))
for task in ['rj45-top-only-reassessment1','rj45-adc-return-reassessment1']:
 m=json.loads((N/(task+'-opened.json')).read_text())
 for fn in ['report.md','evidence.json']:copies.append((Path(m['output_dir'])/fn,'prior-decisions/'+task+'/'+fn))
task='''# Fresh independent upstream protection-width/launch decision after candidate3 failure

Read-only independent D-BACK judgment per PCB skills; root solelivewriter. SourceworkeractualproviderERROR before fiveoutputs, notdeliveryPASS. Root942inputverificationand245memberrecovery preservesactualnative/methods/logs and17changedsourcefiles. BotholdADRs remainunfinished/copiedhistoricalproposals. Do notinfer completeauthorhandback. No sourceauthoring, newnativecandidate, generation, routing orbudgetreset. Currenttop-onlynativecandidate3 population306A/31Ptop/0bottom;154x100/60x40. Actual3/3spentinledger. Priorindependentmount/benddecisionpreserved; nowreopen upstreamtracewidth/postlaunchboundary fromcompletecausal evidence.

Evaluate ALLcauses together and chooseADMIT_OWNING_SOURCE_CORRECTION orREASSESS_ARCHITECTURE:
1 Carrier16Pprefix/postlaunchseedrefusals: native0.195001mmNC2gap againstunchangedprep0.20, source0.26tracewidth. Fixedpadcenterendcap gives0.5pitch−.175padhalfheight−.13radius=.195, so detourcannotcure fixedwidth/endpoints. Proposed0.20mm signalwidth (existinggoverningminimum) gives.225001analyticalgap; evaluateTIprimarynearconnector/noIOstubs/shortbroadGND andsystemsignal/currentauthority, notjustfittingchecker. Alternativein-padendpoint displacement vs0.20uniformsignalconstruction ifappropriate, no arbitraryclearancefloorchange. GND0.50andpower0.60widthsunmodified. Pathgeometry9/7.5length8.6/5.7centerceilingpreserved; no preclampvia orbranch.
2 PodNpostvia47.85,35.25dia.6/drill.3annulusoverlapsU3.5at47.2875,35.25size.675x.35by.075mm thoughcenteroutside. Carrier8Npostviasdia.5samegeometryoverlap.025analytical. Sharedcriticalpath graphrejectscorrectly; don'texpandchecker/filtercontact. Proposedrearward1.0mmNpostlaunch, podvia47.2875,36.25 andtransformed8carriercenters retainsviafamily/endpointsatclamp, removesoverlap. Root/authoranalyticaloptionsnativegap.525P/.575A; entireforeignpad/seed/region/bodyservicecensusneeded. No unchanged27launchrestriction aftera justifiedchangeddecision; specifyexactwhich9Nlaunchesand36signalwidthdeclarationschange, retainothergeometryGND/Pvia/contactdominance. Preserve failedknownbad via-contactcontrol.
3 CarrierDRC40rows/499opens/0parity:8pad-clearance dueoldPKG_PAD_ESD*_2_3pads_only0.15regionstillbottomoldpose and32CHcaption silk/mask collisions(8+24). Regionmustfollowactualtoppackagepads, neverextendpads_onlytosignals/vias. Retainunchangedclass/minimumrules. SourcecaptionF1distance3.34>3 too. Independently censusallsource-ownedregions/keepouts/silk tiedtoany17movedSMD/8jack/2mount/FID, includingoldUser2/3universalNPTHs. AdmittedsourcecorrectedactualHmountscopeandexplicitall21NPTHbarrels(4H+16RJ45+1J9) retainsfloors. Fullfanout64segmentsanalytic .55minimum; notsavedcarrierprep, mustgenerateandgrade. Decidefinitecoherentsourceconstraintswithnohiddenfirstfailuretail.
4 Projectsourceconsumers/testsuseoldbottom/oldlength/oldonebankassumption;17recoveredchangedfilespartiallyupdate. Review completebefore/post onlyforwidth/launch/sourcecontractboundary, notsourceacceptance. Authorhistorical0.26geometryvsoldconsumerexact.20 mismatchmustbereconciledtruthfully. Requirechangedpolicyknownbadtests andexactsourceindependentacceptancebeforeadoption. No sharedchecker/schemachange.

Rootwill combine justifiedprotectiondecisionwithalreadyindependentlyadmittedADC supplydrop+VMID/14thermalsettings/sourceprimarydecision andmetadata correctioninONEnewsourcebatch beforeexpensivenormalrenewal. YourreviewneednotrederivetheADCscope; retainfullpriorreviewconstraints andcurrentpodR13/C10groundowed. No erasedoldcandidatehistory. Ifadmit, recommendONEspecific boundedcumulativecandidate4 underreviewedchangedwidth/launch/regiondecision; do notclaimexisting3/3ledgerautomaticallypermitsit. Scopeandcumulativeexceptionmustberecordedexplicitlybyroot. Ifreject, givecredibleupstreamalternativewithfewerassumptions; do notloop .005mm nudges.

Fresh exactnative/sourcegeometryread/finiteanalyticalcontrolsallowedwithoutsave/newPCBprimitives; primarysupplieddossiersPDFsreadandhash. Timeboxed20minutes; completeactualFINALquicklywhenquestiondecided. EvidenceverdictSOUNDonlyforreassessment, notcompletecurrentfailedsource. RawrecoverysourcehasunfinishedADRs/policyandnoauthority. Preserveallproof/limits, noorder/release/firstarticleclaims. Verifyallfrozeninputs beforeafter; safelyreopenonlyneededhistoricalbytes anddonotnestoldarchives. Includecoverage/unknowns so nextownerhascompletework ratherthananotherpiecemealtrial.
'''
open_task(name,task,copies,minutes=20,role='judgment')
