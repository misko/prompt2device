# SOUND reassessment — admit a constrained owning-source correction

**Decision: ADMIT_OWNING_SOURCE_CORRECTION.** Admit the proposed carrier outline x16..170/y20..120 (154×100 mm), left mounting centers x21, and the retained candidate2 component poses. For protection prefixes, admit candidate1 AUDIO+ and the candidate1 AUDIO− construction **only with its final 90° elbow replaced by one ordinary 45° chamfer**. Reject an unmodified wholesale return to candidate1: its AUDIO− path is not fully chamfered. This additional restriction follows the root's clarification during this review and the independent primary/native findings below.

SOUND applies solely to this constrained reassessment and next-owner decision. Both historical source candidates remain INCOMPLETE; no whole-board/source adoption, routing admission, generated carrier, release, purchase, or physical qualification is accepted. Historical native candidates remain 2/2 spent, routing pilots 0, and this reassessment adds zero. The new owner must be explicitly admitted under a new bounded corrective scope; this report does not reopen the historical budget.

## 1. Carrier mechanical boundary — source correction admitted

Independent native-footprint controls reproduce the current F1/H1 collision and analytically evaluate the proposed mounting decision. No board was generated or saved.

| Quantity | Candidate2 x22 hole | Proposed x21 hole |
|---|---:|---:|
| Exact circle-to-rectangle nominal gap | −0.210 mm | +0.790 mm |
| Gap including both 0.05 mm graphic strokes | −0.260 mm | +0.740 mm |
| Native polygon projected x gap | −0.299999 mm | +0.700001 mm |
| Native courtyard polygons collide | yes | no |

The known-bad control uses F1 courtyard x25.24..32.76/y23.90..27.82 and H1 radius3.45 mm. Native polygonization expands the combined bounds another0.04 mm beyond the graphic strokes. The proposed separation therefore is not a guessed margin over the rounded0.300 mm failure window. It retains0.700001 mm separation under the unchanged native courtyard representation. Polygon controls and exact methods are archived.

Both left centers retain5 mm from west and north/south edges. The3.2 mm NPTH leaves3.4 mm nominal drill-to-edge,3.35 mm to the inner edge of the0.10 mm outline graphic, and1.525 mm courtyard-stroke-to-edge (1.475 mm to that graphic). The native polygon extends to within1.502474 mm of the north/south edge; its west projection leaves1.50753 mm. Neither edge margin is a fastener qualification. The unchanged prep mounting keepout radius3.2 mm leaves1.8 mm to the physical edge; its future copper exclusion must follow the moved holes.

At H1 the nearest other courtyard remains F1; conservative bounding-box checks put FID1 at least3.781 mm away and J1 at least8.420 mm away. H3's nearest item is FID3 at least3.781 mm away, followed by J5 at least6.280 mm. F1 maximum-body west edge26.635 gives2.185 mm from the nominal H1 radius3.45 envelope; F1 copper west edge25.495 gives1.045 mm. No exact screw, washer, standoff or driver envelope is selected in the supplied boundary. The generic M3 footprint must not be represented as proving an actual fastener/tool.

Retain the candidate2 north-bank +2 mm/south-bank −2 mm jack offsets,32 mm repetition, clamp/fuse poses and FID1(25,33). The RJ45 mouths retain0.50 mm nominal north/south overhang. Their free EMI fingers, shell slots and locating holes remain part of the geometry. Width growth makes the board4 mm larger than the original150 mm state and1 mm larger than candidate2's153 mm state; neither historic state is erased.

**J9 is an explicit affected interface.** Its native front is x19.08: baseline overhang0.92 mm becomes candidate2 setback2.08 mm and proposed setback3.08 mm. The source `edge_faces` assertion checks body-versus-pad direction, not physical mouth exposure. Thus it cannot clear this change. The supplied connector contract already marks J9 seating/exposure/service and enclosure stack unknown; no locked numerical setback is contradicted. Admit the outline decision at source scope, but renew exact J9 mate/latch/tool/pigtail/restraint and enclosure scenes. A later demonstrated collision is a source defect, not a physical-test waiver. Parent architecture and any enclosure/mount interface dimensions must explicitly adopt154×100 and the x21 centers before their downstream proofs can be current.

## 2. Protection placement and representation — constrained correction admitted

I read the exact stored TI SLLSEG9C section10.1, its Figure12 image, Würth drawing001.003 page1, both proposed ADRs, exact native pad/body geometry, and all11 before/post source hashes. TI requires connector-near placement, straight routing, avoiding sharp corners through generous rounding, and reducing coupling to nearby unprotected conductors. Figure12 depicts ordinary straight/45° direction changes and a local ground via. TI supplies no3/4.2/9 mm protection ceiling or numerical corner radius.

The exact jack nominal shell is local x[−3.93,11.07]/y[−6.36,7.09]; pin5 is(4.08,0). Its nearest shell edge is6.36 mm away and rear edge7.09 mm. A top clamp outside the occupied shell cannot honor the inherited4.0 mm center/4.2 mm prefix budget. Board growth does not remove that intrinsic obstruction. Mouth/service space prevents a front cell; side springs and locating holes constrain the sides. A rear cell is a justified practical construction, not a proof of the global shortest layout.

The retained clamp center is local(2.5,8.89),180° for a north jack. The rear courtyard threshold is y>8.54, so the selected cell supplies0.35 mm nominal courtyard separation (0.30 mm with strokes),1.00 mm nominal body gap and1.125 mm copper/shell gap. This clearance has a purpose beyond rounding an electrical budget. The TI package drawing allows1.7 mm body extent versus the native1.6 mm nominal Fab dimension and up to0.15 mm mold flash per side; Würth's axial dimension tolerance is±0.15 mm. A centered, single-axis sensitivity consumes0.05+0.15+0.15=0.35 mm of the nominal1.00 mm body gap, leaving0.65 mm **before** the unclosed placement/seating/datum/tool stack. This is not a guaranteed installed minimum. Do not substitute the Fab or courtyard line for a rework-tool or thermal qualification envelope.

| Pod quantity, independently measured | AUDIO+ | AUDIO− |
|---|---:|---:|
| Saved candidate2 prefix | 8.719085 mm | 6.991305 mm |
| Pad-center distance | 8.434729 mm | 5.538173 mm |
| Native pad copper gap | 7.587931 mm | 4.662686 mm |
| Candidate1 source polyline length | 8.749330 mm | 7.172201 mm |
| Candidate1 turns | 45°,45° | 45°,45°,90° |
| Constrained ordinary-chamfer length | unchanged | 6.967176 mm |

All18 source prefixes (pod2/carrier16) retain the candidate2 first/last endpoints. All27 post-clamp and GND launch declarations are exactly unchanged. The16 carrier prefixes are the same32 mm repeated cells, with a180° transform for the south bank.

**Reject the exact AUDIO−90° elbow.** Its pod location(46.4,35.25) is0.8875 mm before U3.5. Figure12's45° depiction does not justify calling that corner chamfered; the retained0.35 mm fillet shows a gentler change is possible. The constrained next-owner alternative cuts only that elbow by0.35 mm on each leg: pod(46.4,34.9)→(46.75,35.25), or jack-local(0.9,9.04)→(1.25,9.39), with the appropriate bank transform. This is one ordinary chamfer, not arc tessellation. It preserves the entry, clamp pad, ground and downstream endpoints and reduces the excessive90° change to two45° changes.

Engineering judgment: Figure12 is adequate primary precedent to admit this ordinary45° representation for the prototype source correction; section10.1's field-concentration/coupling intent remains binding. Neither a radius waiver nor equivalence to the0.35 mm arcs is claimed. The two45° bends on AUDIO+ and the resulting45° bends on AUDIO− avoid the identified right-angle elbow while using existing supported primitives. There is no need to weaken the checker or add arc filtering/adapter code in this correction.

Independent analytical `SHAPE_SEGMENT` controls against the saved pod's pads/copper give0.195001 mm minimum for the original AUDIO+ polyline and0.420001 mm for both the original AUDIO− polyline and the single-chamfer alternative. These were newly measured analytical context controls, **not inherited candidate2 clearance**. Foreign saved AUDIO paths remain rounded in those individual controls; full joint source-generated straight/chamfered copper still requires fresh native clearance, pad-contact and critical-path acceptance. The0.127 mm floor remains unchanged. Source coordinates also undergo the existing emitter's micron rounding; that must be graded on the saved board.

The proposed9.0/7.5 mm routed and8.6/5.7 mm center ceilings, and carrier7.7 mm entry-ESD copper gap, are admitted as bounded construction budgets for this specific cell. They are supported by intrinsic jack geometry, modest routing overhead around the staggered pad field and local clamp pads, preserved pad-first topology and the return construction. Merely fitting those numbers would not justify them. Moving the cell farther away, arbitrary detours, an off-pad prefix branch or a prefix via reopens this judgment.

## 3. Native topology and honest open work

The saved pod has31/31 fitted SMD on F.Cu and0 on B.Cu; all44 native footprint/pad/net identities match baseline. Only U3 changes pose/side, to(48,34.75,180,F.Cu). Independently reopened saved prefixes have5/7 native primitives, all F.Cu, and each contacts exactly one non-prefix same-net launch at the clamp pad. No prefix via or off-pad pre-clamp branch was found. The0.50 mm GND launch is0.850000 mm to a dedicated via; native connectivity reaches J1.2/6/8, and the via contacts F.Cu fill and the single B.Cu ground island. J1 shell remains separate. This proves connectivity, not transient impedance or system ESD immunity.

All39 classified DRC rows match the exact native UUIDs/types:6 dangling warnings,33 opens,0 parity findings. C10.2's isolated GND return is explicitly still owed. The other downstream routes and vias remain actual open work. The author is correct to report the complete source INCOMPLETE. The unsupportedPCB_ARC failure in both old/proposed shared critical-path controls remains a failed gate; native measurements do not replace it.

The fuse4.845 mm copper gap exceeds the old4.5 mm ceiling. A5.0 mm adjacency allowance is justifiable at source scope only with a real around-hole fanout: straight0.60 mm copper would overlap the locating hole by1.190 mm. An independent analytical detour through(31.615,29),(36.8,29),(38,27.8), between F1.2 and J1.1, has11.962056 mm centerline length,0.550 mm hole-edge clearance versus0.25 required, and conservative clearance≥0.95865 mm to nearby non-power signal-pad rectangles. It establishes that an around-hole corridor can exist; it is not an authored route or full fanout proof. All eight cells, parallel contacts1/3/7, returns, actual0.60 mm widths, prep keepouts, hole rules, path resistance/current transfer, fault response and changed copper heat sinking remain to be proven without weaker limits or bottom SMD.

Unrelated carrier obligations remain separately open: ADC VMID bank dominance, thermal12, C_VDDA1_10N.2 ground-pocket regression, FILTP reservoir ordering, AP63205 classification/local support inventory and truthful ADC/module support metadata. R_PWR_PU's+0.04 mm source correction still needs candidate-native proof. Pod historical R13/C10 rescue is not silently adopted. The accepted all-fitted-SMD sideguard is separately accepted code and does not accept physical source.

## 4. Next owner and evidence boundary

The owning PCB source author must record the mechanical decision and constrained primitive choice in the proposed ADRs and affected geometry/source files, retaining exact parts, pin map, electrical graph, protection/current/fault/voltage limits, layer stack and width/clearance floors. No schematic or part replacement is justified by this evidence. Renew outline/mount/connector interface authority, then generate under an explicitly new admitted correction budget and grade exact native output: all-top population on both boards, pad/body/courtyard/drill/edge/fastener scenes, common repeated-cell geometry, around-hole power fanout, supported critical-path length/dominance/no-stub/no-prefix-via checks, broad ground return, placement/refill/parity DRC and first-article/source qualification receipts.

Unclassified or known geometry defects block design admission; plan-bound installed connector/tolerance/system ESD unknowns remain the existing FIRST-ARTICLE-ONLY holds under ADR0007. DO-NOT-ORDER remains. No threshold-only waiver, erased failure or new native trial is part of this reassessment.

814 envelope inputs were verified before and after; all11 source before/post bindings match. The author archive was safely reopened and all1,399 regular members hashed and matched to its manifest;22 selected members were extracted with hash checks. Cached qualification's315 dependency files match current bytes. This report archives the actual analytical methods, raw runtime evidence, selected primary/native evidence, exact source-hash checks, control results and delivery receipts. Bootstrap issues (wrapper result-field assumption, temporary Python module shadow, unavailable optional Shapely) are disclosed in the failure notes; successful controls use the retained bounded runtime and native geometry without Shapely.
