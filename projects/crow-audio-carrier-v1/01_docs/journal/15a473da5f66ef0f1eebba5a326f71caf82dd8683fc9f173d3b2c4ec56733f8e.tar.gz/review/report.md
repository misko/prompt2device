review_stage: pre-route
review_kind: scoped ADC layout gap
reviewer: /root/rj45_carrier_layout_gap_adc1
domain_verdict: DEFECTIVE
order_verdict: DO-NOT-ORDER

The ADC return topology is defective: all four VMID bypass ground pads contact broad F.Cu ground before the intended nearest-GND_A junction. The authored local tracks exist in r0, but those junctions do not control filled return paths. The same contacts exist in filled canonical current, making this a source reservation/topology defect rather than missing preparation copper. FILT feed-after-bulk branches remain routing obligations. This is not whole-board layout acceptance.

Exact input identity

{"raw_sha256": "94f95260f4839b662b0274830a71fa750f5604708e2519a12d95e3f21c8899ec", "semantic_sha256": "1c76f4cf53801a6b2da89bc1816f88916863bbfc30892e6976bf64b2adb3c05b"}

Envelope canonical SHA256: c71c9db43ffa4ecd58c2f61e726bda77a2168544dd8f7d69299989a57096e08b. All569 packet inputs verified before and after;0 mismatches.

| Input | SHA256 |
|---|---|
|04_kicad/crow_audio_carrier_v1.kicad_pcb|`d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de`|
|04_kicad/crow_audio_carrier_v1.kicad_dru|`c86b53ca8630718200667bc19a6633971f0967b2a546a8fb1b63c7b544d314f5`|
|06_build/route/r0.kicad_pcb|`b75acca754b864d8c69df51b8343f21cf01ec9640325216c5e96f466f83861b1`|
|06_build/route/r0.kicad_dru|`c86b53ca8630718200667bc19a6633971f0967b2a546a8fb1b63c7b544d314f5`|
|03_src/floorplan.yaml|`74b9f8d03f7de0ef40b7a731ffe1b60e1addd99db6d5a2364335d7e48e449029`|
|03_src/route.yaml|`360911a5f112b91d0b90c8179d9b60035a5ba3254592c28e4da24c114d94bf31`|
|02_parts/CS5308P-DN/part.yaml|`4b536a26ecbe4a1fe16b04ecf7969a0ff79ce47f87757b1381118df278d2333c`|
|03_src/rules/stackup.yaml|`8ff67bd8adebc884baac6c2b5ec0d2b641d28279c9db99529d86a012aea90f03`|
|03_src/rules/nets.yaml|`3557aa03b99862ddb349413882ea7905a017465b7d72ff8fbcf427b1cf6a67de`|

New evidence and scope

KiCad10.0.4 filled both exact boards in memory without saving. All4 saved fill lists were empty, so this is native recomputation from hashed inputs. The extraction covers relevant ADC objects in x84–107,y50–90mm plus all ground-zone islands/layers. Effective-shape collisions create planar graph edges; physical same-UUID barrels create layer edges. Net-name equality is only a search filter. Filled outline islands and holes are retained. No full-board DRC campaign was repeated.

Current has169 layer nodes/149 edges; r0 has303/435. r0 includes92 scoped pads,93 tracks,72 via layer nodes (18 physical vias) and46 islands; current has92 pads,0 tracks,36 via layer nodes (9 local paddle vias),41 islands.31 local ADC/support GND-pad contact rows are retained per board. All92 pad identities are unchanged;51/51 relevant source segment primitives from15 seed rows match r0 within2nm. Complete geometry/paths are in current-geometry.json,r0-geometry.json,adc-adjudication.json,native-contact-witness.json. Absence of a surface paddle path is supported by the isolated local paddle island with all its contacts inside this scope.

Actual primary images inspected: July2025 CS530x guide p10/Fig8,p11/Fig9,p12/Fig10 and CS5308P DS1314F1 p8/Fig2-2. PDF hashes and all4 page images are archived. Selected-DN Fig2-2 directly grounds FILT1N/FILT2N; generic Fig9's negative0-ohm branch is not a missing selected-DN part. Adopted source capacitor values and limits remain fixed.

Ground-pin topology

|Pin|Own r0 drop (mm)|F.Cu path to paddle|Common inner-plane path|
|---|---|---|---|
|GND_A6|91.6,69.5|None|Present|
|GND_A8|89.8,71.5|None|Present|
|GND_D30|100.85,70.55|None|Present|
|FILT1N44|95.1,65.45|None|Present|
|FILT2N17|95.1,74.55|None|Present|

Example: GA6 pad → track112fca6a-e758-4ccd-a799-281c99bce65f, (93.05,69.8)→(92.15,69.8) → trackcb290367-0fc3-4b74-9028-cdb738e529a9 to(91.6,69.5) → via0ea7d7a4-2123-45de-bda8-f7e83bfb72b3 → In1 zone4106a4c6-dbf7-42e8-a3c4-418a94b4f329 island9 → paddle via1d0bec0f-7f4d-4c40-8dcc-3a3675bd9536 → U_ADC.49. All5 complete paths and9 paddle vias are recorded. This satisfies r0's own-drop/no-direct-paddle property only. Canonical current has no local seed tracks and does not demonstrate those connections itself.

ADC-VMID-RETURN-01 — source topology defect

Each C_VMID1_470N.2,C_VMID1_4U7.2,C_VMID2_470N.2,C_VMID2_4U7.2 intersects F.Cu fill by0.574948620474mm² on both boards. In r0 all4 enter zoneb8eb10fd-90c4-4416-8fa6-e153f4efd8dd island15. Native BooleanIntersection corroborates native collision. Source has paddle barriers but leaves these return pads/spines pour-accessible.

Nearest-GND_A selection is correct in source: VMID1's470nF/4.7uF GND-pad center distances to pin6 are5.216380/6.676498mm, versus5.866057/7.392944mm to pin8. VMID2 distances to pin8 are4.908220/6.325790mm versus5.536301/7.032469mm to pin6. These are geometric comparisons, not routed-length limits. Each intended track-only tree reaches only its own nearest GND_A. Filling creates additional paths.

Removing GA6 and every layer of its designated via still leaves either VMID1 capacitor connected through island15 → VMID2 via22057a86-f9cb-49af-b5de-8361198ee350 at(89.8,71.5) → In1 island9. Removing GA8 and every layer of its designated via still leaves either VMID2 capacitor connected through island15 → via2fa106e1-f4b3-453c-be4c-945c78ffbf06 at(102.6,69.32) → In1 island9.

All4 also have surface paths to GND_D. Example: VMID1 capacitor → island15 → track8cf471ea-6b23-448d-a721-1c3dbbdf49b5 → tracke8b51d39-cdb7-4a1b-9e1f-acae024d20c5 → track2ed8366c-21a5-4520-a04f-bd327d28738c → U_ADC.30. Full widths/coordinates accompany IDs in the graph.

Thus4/4 nearest-return topology dominance checks fail. This does not quantify AC current distribution or noise. Next owner:carrier source/preparation return-topology owner. Correct source reservation/return architecture, regenerate and recheck actual filled copper. No source edit, placement move or waiver is adopted here.

ADC-FILT-BRANCH-02 — routing obligation

Both FILTP banks each contain3 separate conductor components: ADC+1uF+10uF; isolated470uF positive pad; isolated R_FILTxP.2. Each bulk/feed output pad has0 native neighboring conductors. ADC43/18 each reaches its two local ceramics through actual source-matched tracks. Distances to ADC pads are approximately2.450129,4.500000,12.494999mm for1uF,10uF,470uF; resistor output is8.557243mm. Small/mid/bulk placement priority is present, but distances cannot prove branch order.

Feed-after-bulk therefore does not yet exist on either bank. There is no already-routed wrong-order branch to call a source defect. Next owner:FILT route owner. Route resistor output into the reservoir-side branch and then local ceramics/ADC; prove ordering from actual copper. No mandatory component move is established. Negative terminals follow selected-DN direct-GND authority.

ADC-DIGITAL-CUTOUT-03 — applicability limitation

Figure10's own-GND_D/no-direct-paddle condition is met in r0. Source expressly preserves inner planes and only F.Cu barriers. At x98.34/98.425/98.51mm,y67.7..72.3mm in0.1mm steps: F.Cu0/141 filled-ground probes; In1/In2/B each141/141, on both boards. Native rule-area inventory and inspected inner copper view corroborate this geometry.

The guide requests a digital-side cutout but says it should be “deprecated on all ground layers.” That wording is not silently changed to “duplicated.” Its finite depicted pattern differs from the source's explicit decision and does not justify inventing a plane split beneath the package. Complete cutout conformance cannot be claimed until carrier source/layout authority reconciles the applicability. No all-layer moat, new physical qualification requirement or waiver is created here.

Inherited versus new evidence

Prior archive SHA256b69926c07fd5b686b14da61928e681b0a95d5741571d55047837cf62df3da64e was verified;3 selected members safely reopened/hash-checked. It matches both exact board hashes/current DRU. Retained full-board DRC: native0 physical violations/499 opens/0 parity; r0 12 starved thermals,39 dangling tracks,5 dangling vias,469 opens,0 parity, including2 GND opens. These remain source/route obligations and were not reclassified. Old ADC coverage was explicitly incomplete; all new topology judgments use fresh native evidence.

Per-property coverage is in evidence.json. Scoped verdict DEFECTIVE; FILT routing and digital-cutout interpretation remain engineering obligations rather than missing delivery files. First-article physical qualification is separate from design-only fabrication. DO-NOT-ORDER persists. No whole-board layout, routing, thermal, SI, assembly or release acceptance.

Evidence handling

Archive includes actual methods,raw data,source matches,graph cuts,logs/runtime,native copper views,inspected primary pages. Initial bootstrap reads/script writes used exec_command; substantive engineering measurements and primary rendering used bounded shared runtime. Failed exploratory/API attempts remain history; named final files govern. Initial via GetWidth metadata warnings did not alter native effective contact shapes; widths match bounds and final method specifies the layer. Delivery-only packaging/preflight logs remain in scratch to avoid recursive archive validation. No source files changed, boards saved, children spawned or waiver created. Delivery PASS is complete honest handback, not engineering acceptance.
