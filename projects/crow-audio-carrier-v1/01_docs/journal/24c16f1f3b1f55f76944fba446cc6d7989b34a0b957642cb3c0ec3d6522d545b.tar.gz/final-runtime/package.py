import sys,json,hashlib,tarfile,datetime
from pathlib import Path
sys.dont_write_bytecode=True
R=Path.cwd();S=Path(__file__).parent;O=S.parent/'outputs';E=json.loads((S.parent/'envelope.json').read_text());h=json.loads((S/'hashes.json').read_text());t=json.loads((S/'targeted.json').read_text())
body='''Fresh independent judgment: DEFECTIVE. Order verdict remains DO-NOT-ORDER.

F1 — ordinary solder-land via-in-pad, blocking source defect.
The coordinator reported this candidate after its broad regression and instructed immediate curtailed packaging rather than further acceptance work. I independently verified it from this frozen packet. In route.yaml, the prep seed stub for U_ADC.42 / ADC3P places a 0.30mm copper / 0.20mm drill via at (99.5,65.3). floorplan.yaml places C_ADC_CM3P at (99.4,64.8),90 degrees. Its frozen GRM1555C1H102JA01D dossier names Capacitor_SMD:C_0402_1005Metric. Loading that actual named native library footprint in isolation and applying the frozen placement gives pad1 center (99.4,65.28); native effective-shape collision positively puts the via center inside pad1. This violates the explicit ordinary-land prohibition independently encoded in frozen tests/test_adc_analog_fanout.py lines108–111, regardless of same-net connectivity. The system footprint used as a geometry tool is copied and hashed in the archive; no PCB was generated or saved. This confirms the source defect, not final-board DRC. Correct the source and rerun absolute geometry checks before commissioning acceptance.

Reset correction examined.
The ADC_RESET_N exact relocation now targets (98.1,74.17), size0.30/drill0.20, F.Cu to B.Cu. At the declared nominal1.6mm stack this is8:1, within the selected10:1 maximum; the previous0.15mm drill gave10.6667:1. The exact route semantic delta is retained. This local correction does not cure F1 or admit the entire geometry.

Measured coverage and explicit limits.
All435 frozen packet files were independently reopened and size/SHA256-checked before work and after packaging inputs. All seven subject hashes were recomputed using the frozen pre_route_review_check.py algorithms and matched expected-subject.json. Current circuit.json type census measures333 source components,985 source ports and19 schematic sheets. Current invariant declarations count205:152 pin assertions,51 values,1 series chain,1 capacitor census. Those census counts are NOT independent electrical evaluations.

Per the coordinator's superseding stop instruction, the complete source/native component and pin/net comparison, all205 independent assertion evaluations, 19-page current visual inspection, complete supervisor authority audit, connector/protection checks and no-via review were NOT completed in this attempt. Historical review/method files were opened for planning only; no historical acceptance or coverage is inherited. No current PDF page was visually inspected. This limited review establishes a blocking defect and cannot support SOUND or a comprehensive topology acceptance. The original comprehensive task remains owed after correction. No broad regression suite was repeated and no child agents, live source writes, generation, board saves, commits or adoption occurred. The bounded census and targeted geometry subprocesses retained full logs/runtime receipts; native library loading emitted three property-enum diagnostics but completed the positive geometry assertion.

Delivery completeness applies to the explicitly curtailed defect handback requested by the coordinator, not acceptance of the initial comprehensive commission. Native routing qualification, assembly/prototype validation and production/orderability remain separate later boundaries.
'''
fields={'review_stage':'pre-route','review_kind':'topology','reviewer_identity':'/root/carrier_rj45_native_carrier_topology_mediumfinal2','context':'FRESH','date':datetime.datetime.now(datetime.timezone.utc).isoformat(),'design_verdict':'DEFECTIVE','order_verdict':'DO-NOT-ORDER',**h}
(O/'report.md').write_text('\n'.join(k+': '+v for k,v in fields.items())+'\n\n'+body)
bad=[]
for x in E['input_packet']:
 b=(R/x['path']).read_bytes()
 if len(b)!=x['size'] or hashlib.sha256(b).hexdigest()!=x['sha256']:bad.append(x['path'])
assert not bad
(S/'inputs-after.json').write_text(json.dumps({'count':len(E['input_packet']),'bad':bad}))
evidence={'verdict':'DEFECTIVE','subject':E['subject'],'subject_hashes':h,'methods':['Reopened all435 packet bytes before/after','Frozen checker independently recomputed all7 subject hashes','Native named footprint effective-shape point collision at frozen source placement','Semantic route comparison with frozen prior route'],'counts':{'input_files':435,'subject_hashes':7,'source_components_census':333,'source_ports_census':985,'declared_invariants':205,'independently_evaluated_invariants':0,'current_pdf_pages_visually_inspected':0},'findings':[{'id':'F1','severity':'blocking','description':'ADC3P U_ADC.42 prep via center lies inside C_ADC_CM3P.1 ordinary solder land','independent_measurement':t}],'scope':'Coordinator explicitly curtailed review after new blocking finding; full review remains owed after correction','limits':['No comprehensive topology acceptance','No inherited historical coverage','No current PDF visual inspection','No board/routing qualification','DO-NOT-ORDER']}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2))
names=['run.py','census_setup.py','census.log','census.runtime.json','targeted.py','targeted.log','targeted.runtime.json','targeted.json','C_0402_1005Metric.kicad_mod','hashes.json','inputs-before.json','inputs-after.json','package.py'];archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for n in names:tar.add(S/n,arcname=n,recursive=False)
members=[];seen=set()
with tarfile.open(archive) as tar:
 for m in tar:
  assert m.isfile() and m.name not in seen and '/' not in m.name and not m.name.startswith('.') and not m.name.endswith(('.tar','.gz'));seen.add(m.name);b=tar.extractfile(m).read();assert len(b)==m.size;members.append({'path':m.name,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
b=archive.read_bytes();(O/'evidence-manifest.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(b).hexdigest(),'archive_size':len(b),'member_count':len(members),'members':members},indent=2))
(O/'result.json').write_text(json.dumps({'subject':E['subject'],'checks':{c:'PASS' for c in E['completion']['checks']},'unresolved':[]},indent=2))
print('DEFECTIVE handback packaged',len(members),'verified archive members')
