from placement_review_common import *
name='rj45-pod-return-reassessment1'
old=Path('/tmp/rj45-pod-escape-ground-source1-5cyv1w7y');recovery=json.loads((N/'rj45-top-only-correction1-opened.json').read_text());S=Path(recovery['scratch_dir'])
copies=[(old/'input','input'),(old/'06_build/task_runs/rj45-pod-escape-ground-source1/outputs/report.md','historical/report.md')]
for rel in ['03_src','04_kicad','06_build/route']:
 p=S/'work/projects/crow-mic-pod-v3'/rel
 if p.exists():copies.append((p,'current-candidate/'+rel))
for rel in ['01_docs/BRIEF.md','01_docs/STATUS.md','01_docs/findings.yaml','03_src/rules/nets.yaml','02_parts']:
 copies.append((R/'projects/crow-mic-pod-v3'/rel,'current-authority/'+rel))
# Historic isolated source proposal is evidence only; select its single route postimage and actual inventory without nested archive.
hs=old/'06_build/task_runs/rj45-pod-escape-ground-source1/scratch'
for p in hs.rglob('*'):
 if p.is_file() and (p.name=='route.yaml' or p.suffix in ['.json','.py']):copies.append((p,'historic-scratch/'+p.relative_to(hs).as_posix()))
task='''# Fresh independent pod ground/escape upstream reassessment

Follow PCB skills' fresh D-BACK review, READ_ONLY, root sole live writer. This is a concrete separate residual cause review alongside the top-only protection review. No new native board/candidate, source authoring, routing pilot or adoption. Three historical actual RJ45 routing candidates all failed the same R13.2 via-in-pad; one later isolated SOURCE proposal was interrupted by top-only user direction before any native generation. These counts remain spent; do not imply the proposal is qualified.

Current candidate3 has all31 fitted SMD on top, unchanged60x40 outline. Exact board/source supplied. Its U3 top-only postclamp N via collision is being independently reviewed by a different owner; do not repair it here. BALANCED_AUDIO min_width remains0.25 mm; class/rule floors unchanged. Root will combine separately accepted upstream corrections into one coherent source batch; exact combined source/native still needs fresh acceptance.

Decide whether ONE fixed source-owned R13.2 escape and C10.2 independent GND connection is physically admissible on the current top-only placement, rather than repeating the failed router geometry. R13.2 center62.9125,36, pad1.025x1.4. Historic via62.4,35.6 (dia0.6/drill0.3) overlaps its land. Proposed northward F.Cu exit to62.9125,34.7 needs exact source path, width and full native pad/foreign copper/seed/hole/region/via clearance. Proposed C10.2 GND via51.2,49 dia0.6/drill0.3 likewise needs its full source stub and broad-plane return proof. Do not infer a valid via from its center alone. If proposed coordinates fail, identify upstream causal constraint, not a free grid search until green. Finite read-only analytical controls and in-memory fill without Save are allowed; no new saved PCB or generator. Cite exact primary and source rules.

For ground, independently verify all native layers, full annular disk, connected fill component and source seed graph; distinguish existing C5.2 and U3 clamp GND returns from C10.2. Supply a complete affected-object census and precise next-owner constraints. All reported clearance/thermal/open claims must be measured or explicitly inherited with exact source. Preserve individual old failure rows and known-bad contact. Do not promise whole-board routing feasibility from these local checks, or change pre-clamp entry topology, protection/GND widths, operating limits, schematic, hardware, 60x40 outline or manufacturing floors.

Return SOUND only for ADMIT_OWNING_SOURCE_CORRECTION with exact geometry/constraints and one fixed bounded implementation recommendation if supported; otherwise DEFECTIVE or INCOMPLETE with REASSESS_ARCHITECTURE and decisive missing cause/authority. No current whole source/native acceptance is requested. Prior budgets retained; root must explicitly admit any new implementation before generation. Archive actual independent methods, raw geometry/graph/controls/runtime and selected primary facts, no nested historical archives. Complete promptly when the finite question is decided.
'''
open_task(name,task,copies,minutes=20,role='judgment')
