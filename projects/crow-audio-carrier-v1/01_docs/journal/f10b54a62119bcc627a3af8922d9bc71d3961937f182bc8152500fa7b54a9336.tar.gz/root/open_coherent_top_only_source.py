from placement_review_common import *
name='rj45-coherent-top-only-source1'
closed=json.loads((N/'rj45-top-only-launch-reassessment1-opened.json').read_text());assert json.loads(Path(closed['attempt']).read_text())['status']=='PASS'
old=json.loads((N/'rj45-top-only-correction1-opened.json').read_text());D0=Path(old['project']);S=Path(old['scratch_dir'])
copies=[(D0/'input','input'),(S/'work','candidate3-work'),(S/'methods','candidate3-methods')]
for fn in ['carrier-drc-classification.json','pod-drc-classification.json','carrier-placement-drc.json','pod-drc.json','source-construction-checks.json']:
 copies.append((S/fn,'candidate3-evidence/'+fn))
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 for rel in ['03_src/tests','03_src/check_analog_paths.py','01_docs/BRIEF.md','01_docs/findings.yaml','01_docs/STATUS.md','01_docs/decisions','02_parts/TPD2E2U06DRLR/part.yaml']:
  p=R/'projects'/slug/rel
  if p.exists():copies.append((p,'live-preimages/'+slug+'/'+rel))
for rel in ['tests/README.md','CLAUDE.md','skills/pcb-design/SKILL.md','skills/pcb-design/references/lifecycle-and-backtrack.md','skills/pcb-design/references/execution-runtime.md']:
 copies.append((R/rel,'governing/'+rel))
for task in ['rj45-top-only-reassessment1','rj45-adc-return-reassessment1','rj45-top-only-launch-reassessment1']:
 meta=json.loads((N/(task+'-opened.json')).read_text());O=Path(meta['output_dir'])
 for fn in ['report.md','evidence.json','evidence-manifest.json','evidence.tar.gz']:
  copies.append((O/fn,'decisions/'+task+'/'+fn))
for p in (N/'adc-source-fragment').rglob('*'):
 if p.is_file() and 'metadata-check' not in p.parts:copies.append((p,'adc-source-fragment/'+p.relative_to(N/'adc-source-fragment').as_posix()))
for fn in ['rj45-top-only-correction1-recovery.json','rj45-top-only-correction1-provider-recovery-summary.json','carrier-module-boundary-inventory.json','top-only-candidate4-decision-admission.json']:
 copies.append((N/fn,'root/'+fn))
for prefix in ['adc-source-metadata-check','adc-source-power-metadata-check','adc-source-converter-topology-check','adc-source-off-control-check']:
 for p in Path('/tmp/carrier-connector-integration-20260911').glob(prefix+'*'):
  if p.is_file():copies.append((p,'root-checks/'+p.name))
# Complete historical ADC methods as supplemental proof tools; do not import old board poses.
a=json.loads((N/'rj45-carrier-layout-correction1-opened.json').read_text());AS=Path(a['scratch_dir'])
for rel in ['methods','candidate2/projects/crow-audio-carrier-v1/03_src/floorplan.yaml']:
 p=AS/rel
 if p.exists():copies.append((p,'historical-adc/'+rel))
task=(N/'coherent_top_only_source_task.md').read_text()
open_task(name,task,copies,minutes=45,role='authoring')
