from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,io,datetime
S=Path(__file__).parent;R=S.parents[3];O=S.parent/'outputs';E=json.loads((S.parent/'envelope.json').read_text());H=json.loads((R/'expected-subject.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
verified=[]
for x in E['input_packet']:
 p=R/x['path'];assert not p.is_symlink();b=p.read_bytes();assert len(b)==x['size'] and sha(b)==x['sha256'];verified.append(x['path'])
(S/'inputs-after.json').write_text(json.dumps({'count':len(verified),'paths':verified},indent=2))
headers={'review_stage':'pre-route','review_kind':'topology','reviewer_identity':'Codex /root/carrier_rj45_native_carrier_topology_frontreg1','context':'FRESH','date':'2026-09-14','design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER',**H}
report='\n'.join(f'{k}: {v}' for k,v in headers.items())+'\n\n'+(S/'report-body.md').read_text();(O/'report.md').write_text(report)
evidence={'schema':1,'verdict':'SOUND','order_verdict':'DO-NOT-ORDER','review_stage':'pre-route','review_kind':'topology','context':'FRESH','reviewer_identity':headers['reviewer_identity'],'subject':E['subject'],'hashes':H,'methods':['Complete before/after envelope byte verification','Complete preceding/current file hashes and parsed YAML delta','Independent native balanced S-expression census','Independent CircuitJSON union-find graph partition comparison','Separate bounded JSX evaluation and all connected pin/MPN comparison','Fresh native schematic netlist export and owning normalized hash','Maintained 205-invariant, ADR, analog, power and clock/TDM screens','All-page Poppler/Pillow RGB body equality plus actual integrated/detailed visual inspection'],'counts':json.loads((S/'counts.json').read_text()),'source_verification':json.loads((S/'source-verification.json').read_text()),'source_delta':json.loads((S/'registration-semantic-delta.json').read_text()),'findings':[],'retained_limits':['FIRST-ARTICLE-ONLY / DO-NOT-ORDER','ERC 0 errors / 2637 classified warnings','Connector SOURCE PASS / FULL INCOMPLETE 23 findings','Conditional 23-reference locator exception requires current atlas/render acceptance','Carrier-only; pod population outside commissioned packet','Native PCB, physical qualification, orientation, routing and release outside this review'],'visual_inspection':{'all_page_montages':[1,2,3,4],'full_size_pages':[3,6,14],'current_headers':19,'pixel_equal_body_pages':19,'scale_max_pixels':1684,'excluded_header_y_lt':120},'inputs_verified_before':750,'inputs_verified_after':750}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
exclude={'packaging.log','packaging.runtime.json','preflight.log','preflight.runtime.json'}
members=[]
with tarfile.open(O/'evidence.tar.gz','w:gz') as tf:
 for p in sorted(S.rglob('*')):
  if not p.is_file() or p.name in exclude:continue
  assert not p.is_symlink();name='evidence/'+str(p.relative_to(S));data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tf.addfile(info,io.BytesIO(data));members.append({'path':name,'size':len(data),'sha256':sha(data)})
 for name in ['report.md','evidence.json']:
  data=(O/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tf.addfile(info,io.BytesIO(data));members.append({'path':name,'size':len(data),'sha256':sha(data)})
members.sort(key=lambda x:x['path']);seen=set();expected={x['path']:x for x in members}
with tarfile.open(O/'evidence.tar.gz','r:gz') as tf:
 for item in tf:
  path=PurePosixPath(item.name);assert item.isfile() and not path.is_absolute() and '..' not in path.parts and item.name not in seen and not item.name.endswith(('.tar','.tar.gz','.tgz'));seen.add(item.name);data=tf.extractfile(item).read();assert expected[item.name]=={'path':item.name,'size':len(data),'sha256':sha(data)}
assert seen==set(expected)
archive=(O/'evidence.tar.gz').read_bytes();manifest={'schema':1,'archive_sha256':sha(archive),'archive_size':len(archive),'member_count':len(members),'members':members};(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(O/'result.json').write_text(json.dumps({'subject':E['subject'],'checks':{x:'PASS' for x in E['completion']['checks']},'unresolved':[]},indent=2)+'\n')
assert {p.name for p in O.iterdir()}=={'report.md','evidence.json','evidence-manifest.json','evidence.tar.gz','result.json'}
print(json.dumps({'outputs':str(O),'archive_sha256':manifest['archive_sha256'],'archive_size':len(archive),'members_reopened':len(members),'inputs_verified':len(verified),'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER'}))
