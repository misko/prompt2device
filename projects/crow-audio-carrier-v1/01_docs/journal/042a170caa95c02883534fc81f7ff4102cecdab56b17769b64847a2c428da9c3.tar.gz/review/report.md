review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_power_fets_mountedframe1 (actual fresh agent)
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

Limited coverage: Q_IN and Q_PRE only, all commissioned instances. This is a pin-domain judgment from the supplied frozen dossiers and exact primary PDFs, not whole-board acceptance or authorization to order. The three SHA bindings above are immutable supplied subject metadata, not independently reviewed board-wide conclusions.

Q_IN — VERDICT: PASS

Primary: DMP6023LFG, DS37204 Rev. 2-2, January 2015, SHA-256 1ea244be5e0fe4195ad20cb2da0960ac622b6efc19cf9e579c9eb8ef5777fa27. Inspected images: PDF p.1 POWERDI3333-8 Bottom View/Top View/Equivalent Circuit, and p.5 Package Outline Dimensions and Suggested Pad Layout (unnumbered package figures).

Expected package: eight physical terminal identities, source 1–3, gate 4, and fused drain 5–8. The exposed drain paddle is electrically drain; no separate ninth ground/EP identity exists. The underside outline has 1 upper left, 4 upper right, 5 lower right, 8 lower left. Reflect that BOTTOM VIEW vertically once to obtain TOP VIEW: 1 lower left, 4 lower right, 5 upper right, 8 upper left. Then a clockwise 90-degree rotation in the screen frame (+x right, +y down) gives 1 upper left through 4 lower left, with drain 5–8 on the right, matching the dossier. Manufacturer top physical ordering is CCW. The p.5 suggested land pattern independently corroborates that conversion.

Observed: explicitly front-mounted at native rotation 0; local coordinates are COMPONENT-TOP, requiring no mounting reflection. The dossier's reported n/a winding for the collinear surviving perimeter row is appropriate: neither that row nor one fused drain centroid is a measurement of the full eight-pin winding. Individual source/gate identities and the drain side resolve the orientation without a further mirror. Native-to-local coordinate checks agree within 1.5e-14 mm numerical residual.

Measured census from the native dossier table: 5 numbered records / 5 distinct native identities (1–5), plus 3 explicitly declared physical aliases (6,7,8 -> schematic 5 and footprint 5), preserving all 8 physical identities. The dossier separately reports 8 unnumbered paste/mechanical pads, excluded from terminal identity counts; their individual geometry is not present in the supplied table. The manufacturer p.1 copper image and p.5 connected drain land establish actual fusion, not merely equal nets. Each alias declares fused:true, a reason, and primary figure evidence. Central exposed drain copper is represented by pad 5, 1.71 x 2.37 mm, at local (+0.455,0).

Q_IN pin 1 (SOURCE): expected first marked source on the three-source row; observed (-1.5,-0.975), SOURCE, 12V_PROTECTED — agrees.
Q_IN pin 2 (SOURCE): expected next source on the same row; observed (-1.5,-0.325), SOURCE, 12V_PROTECTED — agrees.
Q_IN pin 3 (SOURCE): expected third source adjacent to gate; observed (-1.5,+0.325), SOURCE, 12V_PROTECTED — agrees.
Q_IN pin 4 (GATE): expected terminal at the opposite end of the source/gate row from pin 1; observed (-1.5,+0.975), GATE, Q_IN_GATE — agrees.
Q_IN pin 5 (DRAIN): expected the opposite-side common drain/exposed paddle; observed pad 5, DRAIN_COMMON, 12V_FUSED — agrees.
Q_IN pin 6 (DRAIN): expected the same manufacturer-fused drain; observed declared physical identity 6 aliased to pad 5, 12V_FUSED — agrees.
Q_IN pin 7 (DRAIN): expected the same manufacturer-fused drain; observed declared physical identity 7 aliased to pad 5, 12V_FUSED — agrees.
Q_IN pin 8 (DRAIN): expected the same manufacturer-fused drain; observed declared physical identity 8 aliased to pad 5, 12V_FUSED — agrees.

The p.1 P-channel equivalent circuit shows body-diode conduction D -> S, hence the observed mapping permits 12V_FUSED -> 12V_PROTECTED. This is electrically consistent with input protection net roles; the gate is on its named control net and both current terminals are rail nets. This pin check does not establish gate-bias values, switching timing, or voltage/transient adequacy.

Q_PRE — VERDICT: PASS

Primary: AO3401A Rev 3.1, December 2023, SHA-256 0d8e3261ae280e007b5837fff60c55142f2d92af71edc4d02aee6f7a760a785c. Inspected image: PDF p.1 SOT23 Top View/Bottom View and adjacent MOSFET equivalent circuit (unnumbered figures).

Expected package: three terminals and no exposed pad. In the manufacturer TOP VIEW the marked gate lead and source lead occupy the same two-lead edge; drain is the sole opposite lead. Physical G -> S -> D order is CCW when flattened into the top frame. The PDF identifies the terminals by G/S/D rather than printed numeric labels; the gate-adjacent dot establishes the marked corner. Acceptance is based on those directly pictured physical function positions, not on importing a different part's numeric pinout. A rotation aligns G at the upper-left paired position, S at lower left, and D on the right, as the dossier assigns 1,2,3. No top/bottom or mounting mirror is needed.

Observed: front mount, native rotation 180 degrees, with explicit COMPONENT-TOP coordinates. Measured census is 3 numbered native table records / 3 distinct identities / 3 physical terminals, no aliases, no EP. No unnumbered pads are reported. The 1 -> 2 -> 3 polygon has signed screen-coordinate area -1.78125 mm^2, confirming CCW, and the native 180-degree transform matches within 7.2e-15 mm. Cardinal N/S tags reflect the coordinate classifier; actual coordinates establish that 1 and 2 form the left pair.

Q_PRE pin 1 (G): expected the dot-adjacent paired gate lead; observed (-0.9375,-0.95), G, PRE_GATE — agrees.
Q_PRE pin 2 (S): expected the other paired source lead; observed (-0.9375,+0.95), S, 5V_LDO_FEED — agrees.
Q_PRE pin 3 (D): expected the sole opposite drain lead; observed (+0.9375,0), D, 5V_LDO_HOLD — agrees.

The pictured P-channel diode conducts D -> S, hence the mapping gives 5V_LDO_HOLD -> 5V_LDO_FEED diode direction. Source on the feed rail and drain on the held rail are consistent with a controlled high-side P-channel switch; the gate is on PRE_GATE. The dossier does not establish rail timing or control voltage, and no such claim is made.

Instance symmetry: both commissioned FETs were individually checked. They are different packages, so literal pin numbers are not comparable across the pair. In both cases every gate goes to a named gate-control net, source/drain identities go to rail nets, and common-terminal identities are consistent. The different body-diode direction relative to the named input/output rails follows the observed input-protection versus feed-switch connection; there is no physical function/net-class swap. No additional instances of either device are supplied or claimed reviewed.

Methods and integrity: all envelope inputs hash/size verified before and after review. Primary figures were rendered using bounded direct-argv pdftoppm calls through shared pipeline_runtime.run_stage, then visually inspected with view_image before dossier comparison. pdftotext assisted page navigation only. Independent figure expectations were recorded before opening dossiers. A retained Python method counted table identities/aliases and checked mounted-frame arithmetic. The archive preserves the inspected images, native dossier copies, exact input hash receipts, methods and subprocess raw logs/runtime. No live design source was inspected, and no children were delegated.

Unresolved findings: none within this commissioned pin domain. Both refs PASS; therefore the limited design verdict is SOUND. Order verdict remains DO-NOT-ORDER for this pre-route group-only review.
