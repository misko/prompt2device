import json,hashlib,tarfile,io,csv
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
B=Path('/tmp/rj45-pod-topology-review-recovery1-tmw2cntr');S=Path(__file__).parent;O=S.parent/'outputs';P=B/'project'
e=json.loads((S.parent/'envelope.json').read_text());h=json.loads((S/'hashes.json').read_text());g=json.loads((S/'graph-evidence.json').read_text());f=json.loads((S/'final-analysis.json').read_text());v=json.loads((S/'page-equivalence.json').read_text())
rows=[]
for i in e['input_packet']:
 d=(B/i['path']).read_bytes();rows.append({'path':i['path'],'size':len(d),'sha256':hashlib.sha256(d).hexdigest(),'pass':len(d)==i['size'] and hashlib.sha256(d).hexdigest()==i['sha256']})
assert len(rows)==195 and all(r['pass'] for r in rows)
(S/'inputs-after.json').write_text(json.dumps(rows,indent=2))
resp=list(csv.DictReader((P/'06_build/sourcing/prelayout_response.csv').open()));assert len(resp)==22 and all(not v for r in resp for k,v in r.items() if k!='Requested LCSC')
rules=list((P/'03_src/rules').glob('*.yaml'));assert len(rules)==16
header={'review_stage':'pre-route','review_kind':'topology','revieweridentity':'carrier_rj45_native_pod_topology_recovery1','reviewer_identity':'/root/carrier_rj45_native_pod_topology_recovery1','context':'FRESH','date':datetime.now(timezone.utc).isoformat(),'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER',**h}
(O/'report.md').write_text('\n'.join(f'{k}: {v}' for k,v in header.items())+'\n\n'+(S/'report-body.md').read_text())
ev={'schema':1,'review_stage':'pre-route','review_kind':'topology','revieweridentity':header['revieweridentity'],'context':'FRESH','subject':e['subject'],'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','verdict':'SOUND','hashes':h,'methods':['Exact before/after envelope packet digest and byte-size verification','Frozen owning hash algorithms independently executed','Independent S-expression native graph parser and TSX hand map/CircuitJSON traversal','Fresh native netlist export after scratch qualification','All-page 140 dpi RGB raster comparison and integrated visual inspection','Exact package figures inspected and source/native part identity/value checks','Fresh arithmetic, invariant, label, count and circuit-only source-value checks'],'counts':{'input_files_verified_before':195,'input_files_verified_after':195,'hashes_recomputed':7,'comparison_files':23,'unchanged_rule_yaml':16,'part_dossiers':34,'native_components':40,'native_nets':24,'connected_nets':20,'native_pin_nodes':103,'connected_source_pin_nodes':99,'explicit_nc_nodes':4,'connector_census':1,'connector_pins_checked':10,'first_power_installed':33,'testpoints':7,'passive_values_checked':25,'invariants_passed':39,'invariants_total':39,'labels_surviving':19,'labels_total':19,'pdf_pages_compared':4,'pdf_pages_visually_inspected':4,'pdf_body_pixels_compared':7399000,'pdf_body_pixels_changed':0,'erc_errors':0,'erc_warnings':158,'physical_obligations_owed':9,'blank_operator_response_rows':22},'source_delta':json.loads((S/'source-delta.json').read_text()),'findings':[],'limitations':['Topology-only current schematic witness; no layout, routing, release or order acceptance','Physical connector FULL remains INCOMPLETE with nine existing obligations','158 classified native ERC warnings remain; not all-severity clean','Strict fab P-FACT unavailable at schematic stage: 0/16 reached, no PASS claimed; all 25 native R/C values independently checked and authoring source-value gate PASS','DC jack ceiling is an explicit project application inference; 150 VAC is not a DC manufacturer rating','No prior review verdict imported; prior subject is comparison-only','Initial helper filename collided with stdlib inspect during runtime import; all inventory/hash conclusions were rerun under run_stage after rename; no source edits','Historical PCB/old Micro-Fit artifacts excluded from current schematic judgment'],'measurements':{'pages':v,'graph':{k:vv for k,vv in g.items() if k not in ('components_full','nets_full','alias_only_traces')},'electrical':f},'evidence_complete':True}
(O/'evidence.json').write_text(json.dumps(ev,indent=2))
# The live packaging log is excluded so every archived runtime log is a completed immutable observation.
excluded={'package.log','package.runtime.json'}
files=[p for p in sorted(S.rglob('*')) if p.is_file() and p.name not in excluded and not p.name.endswith(('.tar','.tar.gz','.tgz'))]
assert not any(p.is_symlink() for p in files)
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in files:
  data=p.read_bytes();name='scratch/'+p.relative_to(S).as_posix();ti=tarfile.TarInfo(name);ti.size=len(data);ti.mode=0o644;t.addfile(ti,io.BytesIO(data))
members=[];seen=set()
with tarfile.open(archive,'r:gz') as t:
 for x in t.getmembers():
  p=PurePosixPath(x.name);assert x.isfile() and not x.issym() and not x.islnk() and not p.is_absolute() and '..' not in p.parts and x.name not in seen;seen.add(x.name)
  data=t.extractfile(x).read();assert len(data)==x.size
  original=(S/Path(*p.parts[1:])).read_bytes();assert data==original
  members.append({'path':x.name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
ad=archive.read_bytes();manifest={'archive_sha256':hashlib.sha256(ad).hexdigest(),'archive_size':len(ad),'member_count':len(members),'members':members,'verification':'Every regular member independently reopened and compared byte-for-byte to scratch; no symlinks, traversal, duplicates or recursive archives.'}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2))
(O/'result.json').write_text(json.dumps({'subject':e['subject'],'checks':{k:'PASS' for k in e['completion']['checks']},'unresolved':[]},indent=2))
assert {p.name for p in O.iterdir()}=={'report.md','evidence.json','evidence-manifest.json','evidence.tar.gz','result.json'}
print(json.dumps({'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','files':5,'archive_members':len(members),'archive_size':len(ad),'inputs_verified':195,'subject':e['subject']},indent=2))
