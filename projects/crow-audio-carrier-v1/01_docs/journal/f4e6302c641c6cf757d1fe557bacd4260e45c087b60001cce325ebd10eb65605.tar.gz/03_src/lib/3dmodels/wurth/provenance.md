# Wurth615008160221 manufacturer native model

Source: https://www.we-online.com/components/products/download/KiCad_WR-MJ%20%28rev26c%29.zip retrieved2026-09-12. WholezipSHA256 80e868f8f2d362198e4523cc6f424d292a46f637f4cf366a3231c2800d257914. Original exactnativefootprintSHA256 0a4a62dc8be59e02aa157d0ef910422ae381dc81ba7300d891fd8066ed0001c7. Original modelSHA256 3f902b89d4bd756b121be056782deff312efb127c9c48f2c798ebd6db0e59f49. Modelcopiedunchanged; no translation/rotation/scale applied. Footprintpreservesall geometry and remaps manufacturer's S1/S2 labels to electrical pads9/10; modelpathandlibrarynameadaptedonly. BlankNPTHremainunnumbered.

Native modelmathYisoppositetoKiCadPCB+Y-down. Mouthmodel+Y6.360054=>footprint-Y6.36. Originpad1. Barebody15x13.45x14.7mm; freeEMIfingers enlargeactual11-solid modelbox tox[-5.058081,12.218081],y[-7.09,6.360054],z[-3.254712,15.838181]. RootOCPmeasurement corroboratesmodelregistration, notmanufacturer tolerancelimits or physicalfit. Manufacturerdrawing001.003 governstolerances.

The separatelydownloadedgenericSTEP reportsoneunresolvedreference; it isretainedforensicandnotusedhere. Manufacturer KiCadmodel importswithoutthaterror. Initialsource-researchpin/tableerrors areexplicitlyrejected; see source-researcharchive168cb286ee392f49e1ec95ab9e66077b0069bb63ca653665095a3d7262204160. Assembly/latch/panelbondandtemperature testsremainowed.
