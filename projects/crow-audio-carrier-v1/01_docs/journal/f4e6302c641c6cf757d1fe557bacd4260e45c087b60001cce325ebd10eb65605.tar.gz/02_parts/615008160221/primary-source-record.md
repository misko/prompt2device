# Würth 615008160221 source record

The manufacturer drawing is revision 001.003, dated 2025-07-09 and retrieved
2026-09-12. Its local PDF SHA-256 is
`6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048`.
Source: https://www.we-online.com/components/products/datasheet/615008160221.pdf

The body is nominally 15 × 13.45 × 14.7 mm above the PCB, with ±0.15 mm
on those dimensions. The manufacturer KiCad WR-MJ library, revision 26c,
supplies the exact native footprint and STEP; provenance is recorded beside
the model. Include the free EMI fingers when evaluating the full geometry.
The STEP is nominal CAD, not a qualified manufacturing tolerance envelope.

There are eight signal drills of 0.8 mm, two unnumbered 3.18 mm locating
holes and two shield slots of 1 × 2 mm. Same-row pitch is 2.04 mm, stagger
is 1.02 mm and row spacing is 4 mm. Manufacturer shield pads S1/S2 are
renamed 9/10 without changing geometry. The circuit assignment belongs to
the synchronized spoke contract and TSX source.

Published 1.5 A and 20 mΩ maximum contact resistance apply to the jack,
not the Weidmuller cord. Manual soldering, bottom clamp assembly, system ESD,
wet entry, populated mating and installed tolerances require qualification.

## DC application basis — source review pending

The exact manufacturer's [Gigabit modular-jack product page](https://www.we-online.com/en/components/products/WR_MJ_MODULAR_JACKS_OVER)
lists 615008160221 in the range stated to be PoE++ compatible under
IEEE 802.3bt. This is application evidence separate from the exact datasheet's
150 VAC working rating. The latter remains explicitly AC and is never copied
into a DC maximum field. Retrieved 2026-09-12; raw page SHA-256:
`4103cebf3e1024dbd2aae87115e2f676627ae5b3e1cb6cfd1d4f6e0bd556fae4`.

Engineering inference for source review: PoE uses DC common-mode power on
these contacts, with a 57 V supply ceiling. A corroborating manufacturer
[PoE++ application page](https://www.we-online.com/en/components/products/WE-POE-PLUS-PLUS)
identifies 37–57 V DC input in that application. It is contextual voltage
information, not a rating transferred from a transformer to this jack.

For this power-off-mated, dry IP20, 13.2 V maximum normal spoke, adopt a
project insulation design ceiling of 28.5 V DC (57/2, a project 2x reserve).
The existing E-SURGE recommended/absolute comparison fields both use that
same deliberately lower project ceiling; neither asserts that the manufacturer
publishes a 28.5 V or 150 V DC absolute maximum. The 24.4 V component clamp
plus 10% coordination margin is 26.84 V, below 28.5 V by 1.66 V.
This is a bounded application assessment, not an AC-to-DC conversion, current
rating, surge waveform guarantee, PoE interoperability claim or hot-plug rating.
Physical first-article qualification and the upstream transient/source bounds
remain owed under the existing first-article-only restriction.
