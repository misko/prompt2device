from pathlib import Path,PurePosixPath
import json,hashlib,tarfile
s=Path(__file__).resolve().parent;r=s.parents[3];out=s.parent/'outputs';out.mkdir(exist_ok=True);e=json.loads((s.parent/'envelope.json').read_text());v=json.loads((s/'verification.json').read_text());manifest=json.loads((s/'source-manifest.json').read_text());prior=json.loads((s/'failed-review-verified.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
methods=[]
for p in sorted((s/'raw').glob('*.runtime.json')):
 name=p.name[:-len('.runtime.json')]
 if name.startswith(('package','preflight')):continue
 methods.append(dict(name=name,command=json.loads((s/'raw'/f'{name}.command.json').read_text()),runtime=json.loads(p.read_text()),raw_log='raw/'+name+'.log'))
provenance=dict(failed_review_archive_sha256=prior['archive_sha256'],failed_review_archive_members_verified=prior['members'],failed_review_report_sha256=sha(r/'failed-review/report.md'),original_combined_manifest_sha256=sha(r/'source-manifest.json'),original_manifest_path='commission/original-source-manifest.json',failed_review_archive_path=str(r/'failed-review/evidence.tar.gz'),failed_review_copied=False,original_closeouts_unchanged=True)
(s/'methods.json').write_text(json.dumps(methods,indent=2));(s/'provenance.json').write_text(json.dumps(provenance,indent=2))
report=f'''# Locator startup repair — candidate 2 of 2

**SOURCE SOUND: exact combined13-file candidate2 is ready for fresh independent source integrity review.** The confirmed F-STARTUP-SIDE defect is corrected in scratch. No source was adopted and no checkpoint or downstream acceptance is renewed. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.

Envelope subject: raw `{e['subject']['raw_sha256']}`; semantic `{e['subject']['semantic_sha256']}`. This is the second and final candidate under the original allowance, not a reset. All1066 frozen input records were verified before and after. The prior failed-review archive was fully reopened and verified:4492/4492 regular members, SHA `{prior['archive_sha256']}`. Its complete report, startup method and rendered reproduction were read and inspected. Only relevant extracted review evidence and hashes are copied into this delivery; the original424MB archive and nested source-author archives are not duplicated.

## Fresh reproduction and correction

The exact13 reviewed candidate1 postimages were applied only after checking original live-before hashes and reviewed after hashes. `candidate1` was retained byte-for-byte. A fresh actual carrier export using it returned0 and generated the known-defective HTML. The independent reviewer’s original startup method was rerun on that export: empty startup showed317 top references; valid U_ESD1 startup showed16 bottom references; `#DOES_NOT_EXIST` showed333 references from both sides underTop and returned1 on the population assertion. A fresh actual Firefox screenshot independently reproduces that visible mixture.

The maintained regression now creates a new DOM for each startup, rather than first selecting a valid reference. Against the exact candidate1 HTML it was RED: unknown startup exposed333 components, and malformed percent/UTF-8 escapes threw URIError before initialization completed. The native mixed-side unittest was also RED against unchanged candidate1 generator/template/checker bytes, with only the new test installed.

Candidate2 initializes every component group hidden and displays `No component selected; choose a reference or viewing side.` before decoding the initial URL fragment. Valid decoded selection applies the existing mounted-side filter. A malformed fragment is caught and follows the existing invalid-selection branch; it clears identity/crosshair/hash and leaves the public search/side controls available. No fallback selection is silently substituted for an invalid URL. Empty/default startup still selects the existing first exception. Existing unknown-after-valid behavior, valid top/bottom search, side switching and empty-side behavior are preserved.

Only four files changed from the exact reviewed candidate1: HTML template, maintained JavaScript UI control, one added native Python unittest, and an appended test-catalog entry in README. All other9 combined postimages—including all3 pin files—remain byte-identical. Native board bytes, generator, independent checker, projection, physical limits, source exceptions, artifact schema/membership and acceptance requirements were not changed. The same governance already requires truthful mounted-side views; this bug fix introduces no new schema or waiver. All31 prior locator test methods are AST-identical; the new method increases the suite to32.

## Measured GREEN evidence

- Maintained native locator suite:32/32 passed. Public locator entry:3/3 passed, including2 known-bad controls. Existing333/333 reference selections, mounted-side visible membership/crosshairs, top→bottom→top selector transitions, unknown-after-valid clearing and top-only empty-bottom controls remain green.
- Fresh-DOM matrix:8/8 passed on the actual mixed-side carrier HTML. Empty fragment and bare `#` select the first top exception; explicit top shows317top only; explicit bottom shows16bottom only; unknown and three malformed encodings show0 components with no identity/crosshair. All invalid startup cases then successfully recover through search and side controls. Observations contain complete initial/result counts, not merely success text.
- The independent reviewer’s unchanged startup method is GREEN on the fresh candidate2 export:317top for default,16bottom for U_ESD1,0visible for unknown. The original method, fresh RED/GREEN output and observations are retained.
- Six actual Firefox startup screenshots were generated and opened: candidate1 unknown (both sides visible), candidate2 default/top/bottom (correct selected population and readable identity), candidate2 unknown and malformed (empty component map, explicit no-selection instruction and error). The latter confirms malformed decoding does not abort the actual browser script. Browser headless/graphics/juggler shutdown warnings remain in lossless raw logs despite successful screenshots. The minimal-DOM test grades transitions; screenshots provide actual-browser rendering evidence. This is author verification, not independent usability acceptance.
- Fresh actual candidate2 assembly export and separate public exact checker both pass:333/333 locator references=317top+16bottom,1043 pads,25/25 exceptions/pages,28 manifest members plus the manifest itself. Native population is340 footprints including7 board-only fiducials/mounts. BOM is51 lines/300 references; CPL300=284top+16bottom. All33 off-BOM native components remain in locator context. The current board SHA is `{v['board_sha256']}`; candidate2 locator manifest SHA is `{v['manifest_sha256']}`.
- Candidate1 and candidate2 export JSON data, BOM, CPL and all25 atlas PNGs are byte-identical; this is a source-preservation measurement, not a golden-file regression test. Native full context, pad geometry and exceptions remain exactly the already reviewed subject. The new manifest comes from a real export and binds the changed template; no old manifest was restamped.

## Scope, handback and remaining owners

A full1046-file candidate-source census proves exactly four changes from candidate1 and no additions/deletions. All1066 frozen inputs remain hash/size-identical. The13-file `source-manifest.json` preserves original live-before hashes and sizes and final candidate2 after hashes and sizes. `proposal/<relative path>` contains all13 final files; `original/` contains original preimages and `reviewed-candidate1/` contains all13 reviewed intermediate files. Both candidate1→candidate2 and original→candidate2 unified diffs are provided. All3 pin postimages and the existing pin test-catalog description are preserved; unchanged pin methods were not rerun, as commissioned.

Full-checkout contract checks belong to root after independent source acceptance. They were not rerun or repaired here. The prior exact review reports the partial-corpus baseline limitations (12pass/5fail contract suite and1 C-ALLOW audit finding in that packet), with skill↔contract sync passing. Those remain explicit inherited limits; no full-checkout green claim is made.

All new engineering commands used shared `pipeline_runtime.run_stage`, finite deadlines, explicit cwd/environment, exact argv receipts and original PID/time/status outputs. Combined stdout/stderr logs are lossless. Full inherited environments are passed explicitly but not serialized as secret-bearing snapshots; declared overrides are retained. Packaging/preflight cannot be recursively included in the archive they validate, so their logs remain in scratch. Browser profiles and recursive archives are excluded. Gerber ZIPs likewise remain in scratch; the fresh locator artifacts, BOM/CPL, artifact indexes and per-layer export files are archived. This is locator/source evidence, not fabrication release validation.

No unresolved startup defect was observed in the bounded controls. The next owner is a fresh independent reviewer of this exact combined13-file candidate. Only root may adopt accepted source and perform the remaining full-checkout qualification, current checkpoint renewal and exact-artifact downstream reviews. **SOURCE SOUND does not authorize placement, routing, release/order, electrical operation or first-article assembly.**
'''
(out/'report.md').write_text(report)
evidence=dict(schema=1,verdict='SOUND',subject=e['subject'],candidate_number=2,candidate_limit=2,ready_for_fresh_independent_review=True,adopted=False,source_manifest=manifest,provenance=provenance,counts=v,methods=methods,findings=[dict(id='F-STARTUP-SIDE',status='CORRECTED_IN_CANDIDATE2',baseline='Unknown initial fragment shows317top+16bottom underTop',candidate='Unknown and malformed startup shows0components; valid/default sides and recovery preserved',red=['independent-startup-red','maintained-startup-red','native-startup-red'],green=['independent-startup-green','maintained-startup-green','native-startup-green','maintained-native-suite','public-locator-suite','current-exact-check']),dict(id='PARTIAL-CORPUS-QUALIFICATION',status='INHERITED_LIMITATION',detail='No full-checkout contracts rerun; root owns qualifying checks after independent source acceptance.')],unresolved_engineering=[],policy='FIRST-ARTICLE-ONLY / DO-NOT-ORDER')
(out/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n');(out/'result.json').write_text(json.dumps(dict(subject=e['subject'],checks={k:'PASS' for k in e['completion']['checks']},unresolved=[]),indent=2)+'\n')
files={}
def add(p,name):
 pp=PurePosixPath(name);assert p.is_file() and not p.is_symlink() and name not in files;assert not pp.is_absolute() and '..' not in pp.parts;assert not name.endswith(('.zip','.tar.gz','.tgz','.tar'));files[name]=p
for folder in ['proposal','original','reviewed-candidate1','raw','failed-review-extract','candidate1-export','candidate2-export']:
 for p in sorted((s/folder).rglob('*')):
  if p.is_file() and not p.name.endswith(('.zip','.tar.gz','.tgz','.tar')) and not (folder=='raw' and p.name.startswith(('package','preflight'))):add(p,folder+'/'+p.relative_to(s/folder).as_posix())
for p in sorted(s.iterdir()):
 if p.is_file() and p.suffix in ['.py','.json','.png','.diff']:add(p,p.name)
for name in ['TASK.md','preflight.py']:add(r/name,'commission/'+name)
add(r/'source-manifest.json','commission/original-source-manifest.json');add(s.parent/'envelope.json','commission/envelope.json')
for name in ['report.md','evidence.json','evidence-manifest.json']:add(r/'failed-review'/name,'commission/failed-review/'+name)
for rel in ['projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb','projects/crow-audio-carrier-v1/03_src/rules/assembly_locator.yaml','projects/crow-audio-carrier-v1/03_src/rules/assembly.yaml','projects/crow-audio-carrier-v1/03_src/rules/policy_waivers.yaml']:add(s/'repo'/rel,'native-inputs/'+rel)
for name in ['report.md','evidence.json','result.json']:add(out/name,'handback/'+name)
archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
seen=set();members=[]
with tarfile.open(archive) as t:
 for m in t.getmembers():
  pp=PurePosixPath(m.name);assert m.isfile() and not m.issym() and not m.islnk() and not pp.is_absolute() and '..' not in pp.parts and m.name not in seen;seen.add(m.name);data=t.extractfile(m).read();assert len(data)==m.size and hashlib.sha256(data).hexdigest()==sha(files[m.name]);members.append(dict(path=m.name,size=m.size,sha256=hashlib.sha256(data).hexdigest()))
assert seen==set(files)
index=dict(archive_sha256=sha(archive),archive_size=archive.stat().st_size,member_count=len(members),members=members);(out/'evidence-manifest.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps({k:v for k,v in index.items() if k!='members'}));print('Combined source postimages:',len(manifest),'candidate2 changed source files:',len(v['changed_from_candidate1']))
