import sys
import json
from dataclasses import asdict
from pathlib import Path

sys.dont_write_bytecode = True
SCRIPTS = Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
sys.path.insert(0, str(SCRIPTS))
from pipeline_runtime import run_stage

root = Path('/tmp/carrier-channel-adc-pin-27sdvtg4')
scratch = root / '06_build/task_runs/channel-adc-pin/scratch'
pdf = root / 'CS5308P_DS1314F1.pdf'
spec = {'id': 'pdf_review', 'work_class': 'local', 'timeout_s': 60, 'produces': []}
commands = [
    ('pdfinfo', ['/usr/bin/pdfinfo', str(pdf)]),
    ('pdftotext', ['/usr/bin/pdftotext', '-f', '4', '-l', '5', '-layout', str(pdf), str(scratch / 'datasheet-pages-4-5.txt')]),
    ('pdftoppm', ['/usr/bin/pdftoppm', '-png', '-r', '160', '-f', '4', '-l', '5', str(pdf), str(scratch / 'datasheet-page')]),
]
for name, command in commands:
    out = run_stage(spec, command, log_path=scratch / f'{name}.run3.raw.log', cwd=scratch, console=None)
    (scratch / f'{name}.run3.outcome.json').write_text(json.dumps(asdict(out), indent=2, default=str) + '\n')
    if out.returncode != 0:
        raise SystemExit(f'{name} failed: {out.returncode}')
