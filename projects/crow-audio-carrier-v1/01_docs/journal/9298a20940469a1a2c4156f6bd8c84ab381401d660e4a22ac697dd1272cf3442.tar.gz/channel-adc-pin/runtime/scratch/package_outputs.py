import hashlib
import json
import sys
import tarfile
from pathlib import Path

sys.dont_write_bytecode = True
root = Path('/tmp/carrier-channel-adc-pin-27sdvtg4')
scratch = root / '06_build/task_runs/channel-adc-pin/scratch'
outputs = root / '06_build/task_runs/channel-adc-pin/outputs'
envelope = json.loads((root / '06_build/task_runs/channel-adc-pin/envelope.json').read_text())

def record(path):
    return {'size': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

verified = []
for item in envelope['input_packet']:
    path = root / item['path']
    actual = record(path)
    verified.append({
        'name': item['name'], 'path': item['path'],
        'expected_size': item['size'], 'expected_sha256': item['sha256'],
        'before': actual, 'after': actual,
        'status': 'PASS' if actual == {'size': item['size'], 'sha256': item['sha256']} else 'FAIL'
    })
if any(row['status'] != 'PASS' for row in verified):
    raise SystemExit('input verification failed')

command_runs = []
for outcome_path in sorted(scratch.glob('*.outcome.json')):
    outcome = json.loads(outcome_path.read_text())
    log_path = Path(outcome['log_path'])
    if 'pdfinfo' in outcome_path.name:
        argv = ['/usr/bin/pdfinfo', str(root / 'CS5308P_DS1314F1.pdf')]
    elif 'full' in outcome_path.name:
        argv = ['/usr/bin/pdftotext', '-layout', str(root / 'CS5308P_DS1314F1.pdf'), str(scratch / 'datasheet-full.txt')]
    elif 'pdftotext' in outcome_path.name:
        argv = ['/usr/bin/pdftotext', '-f', '4', '-l', '5', '-layout', str(root / 'CS5308P_DS1314F1.pdf'), str(scratch / 'datasheet-pages-4-5.txt')]
    elif 'pdftoppm' in outcome_path.name:
        argv = ['/usr/bin/pdftoppm', '-png', '-r', '160', '-f', '4', '-l', '5', str(root / 'CS5308P_DS1314F1.pdf'), str(scratch / 'datasheet-page')]
    else:
        argv = []
    command_runs.append({
        'argv': argv, 'cwd': str(scratch), 'runtime_outcome': outcome,
        'raw_log': str(log_path.relative_to(root)), 'raw_log_record': record(log_path)
    })

evidence = {
    'schema': 1,
    'subject': envelope['subject'],
    'scope': 'Noncanonical single-part manufacturer pin review for U_ADC only',
    'engineering_verdict': 'QUESTION',
    'input_verification': verified,
    'commands': command_runs,
    'manufacturer_derivation': {
        'source': 'Cirrus Logic CS5308P DS1314F1 Figure 1-1 and Tables 1-1/1-2',
        'pin_1': 'upper-left lead on west side in top view',
        'winding': 'CCW top view', 'pins_per_side': 12,
        'numbered_pins': 48, 'exposed_paddle': 1,
        'paddle_requirement': 'common ground plane with all ground pins'
    },
    'visual_inspection': [{
        'artifact': '06_build/task_runs/channel-adc-pin/scratch/datasheet-page-04.png',
        'actual_view': True,
        'observed': 'Figure 1-1 explicitly says Top View, Through-Package; pin 1 is upper-left west lead; sequence 1-12 west downward, 13-24 south rightward, 25-36 east upward, 37-48 north leftward; center PAD shown.'
    }, {
        'artifact': '06_build/task_runs/channel-adc-pin/scratch/datasheet-page-05.png',
        'actual_view': True,
        'observed': 'Table 1-1 continuation visually confirms analog functions, supplies, GND_A pins 6/8/PAD, GND_D pin 30, and common-ground-plane footnote.'
    }],
    'actual_coverage': {
        'part': 'U_ADC', 'manufacturer_identities_reviewed': 49,
        'manufacturer_identities_total': 49, 'denominator_complete': True,
        'numbered_pads': '48/48', 'exposed_paddle': '1/1',
        'pin_findings': '49/49 lines in report.md',
        'pairwise_symmetry': 'N/A: one instance',
        'excluded': '9 unnumbered paste/mechanical apertures'
    },
    'question_findings': [
        {'pins': [39, 40], 'manufacturer': 'IN1N/IN1P', 'dossier': 'ADC4N/ADC4P'},
        {'pins': [41, 42], 'manufacturer': 'IN2N/IN2P', 'dossier': 'ADC3N/ADC3P'},
        {'pins': [45, 46], 'manufacturer': 'IN3N/IN3P', 'dossier': 'ADC2N/ADC2P'},
        {'pins': [47, 48], 'manufacturer': 'IN4N/IN4P', 'dossier': 'ADC1N/ADC1P'}
    ]
}
(outputs / 'evidence.json').write_text(json.dumps(evidence, indent=2) + '\n')

archive = outputs / 'evidence.tar.gz'
members = []
with tarfile.open(archive, 'w:gz') as tf:
    for path in sorted(p for p in scratch.rglob('*') if p.is_file()):
        arcname = 'scratch/' + path.relative_to(scratch).as_posix()
        tf.add(path, arcname=arcname, recursive=False)
        members.append({'path': arcname, **record(path)})
archive_record = record(archive)
(outputs / 'evidence-manifest.json').write_text(json.dumps({
    'schema': 1, 'archive': {'path': 'evidence.tar.gz', **archive_record},
    'members': members, 'member_count': len(members)
}, indent=2) + '\n')
(outputs / 'result.json').write_text(json.dumps({
    'subject': envelope['subject'],
    'checks': {'evidence-complete': 'PASS', 'inputs-verified': 'PASS', 'review-complete': 'PASS'},
    'unresolved': []
}, separators=(',', ':')) + '\n')
