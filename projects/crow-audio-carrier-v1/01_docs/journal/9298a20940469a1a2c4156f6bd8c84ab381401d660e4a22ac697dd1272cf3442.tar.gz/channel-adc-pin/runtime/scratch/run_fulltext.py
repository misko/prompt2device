import json
import sys
from dataclasses import asdict
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, '/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_runtime import run_stage

root = Path('/tmp/carrier-channel-adc-pin-27sdvtg4')
scratch = root / '06_build/task_runs/channel-adc-pin/scratch'
spec = {'id': 'pdf_text_review', 'work_class': 'local', 'timeout_s': 60, 'produces': []}
cmd = ['/usr/bin/pdftotext', '-layout', str(root / 'CS5308P_DS1314F1.pdf'), str(scratch / 'datasheet-full.txt')]
out = run_stage(spec, cmd, log_path=scratch / 'pdftotext-full.raw.log', cwd=scratch, console=None)
(scratch / 'pdftotext-full.outcome.json').write_text(json.dumps(asdict(out), indent=2, default=str) + '\n')
raise SystemExit(out.returncode)
