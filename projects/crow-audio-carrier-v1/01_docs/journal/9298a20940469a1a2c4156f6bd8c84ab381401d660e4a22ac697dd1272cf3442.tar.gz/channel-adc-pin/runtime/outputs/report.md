# CS5308P U_ADC manufacturer pin review — 2026-09-12

- Subject: raw_sha256 `a25f0e4fd57a033eb4e426874fa592e558d23d9da094808f5945e4bdbdbf42ef`; semantic_sha256 `60b507c10aa2f780b72b6af65e3084400e5f58c5f63d94b458ce87b0fdb19070`
- Reviewer: fresh-context judgment agent, channel-adc-pin
- Context given: pin-review-protocol.md, U_ADC.md dossier, and exact Cirrus Logic CS5308P DS1314F1 PDF only
- Scope: noncanonical single-part manufacturer pin/winding/function/net-kind review for later root aggregation; this is not a whole-board soundness claim
- Exact datasheet: `CS5308P_DS1314F1.pdf`, SHA-256 `6ca42cc09ac47ebdacacaee435f05e3f9c34b83d5692e52a2d8a26533e810e57`, 4,623,200 bytes
- Engineering verdict: **QUESTION**
- Evidence verdict: **PASS** (49/49 manufacturer identities covered; cited drawing rendered and visually inspected)

## Independent manufacturer derivation

Cirrus Logic DS1314F1 Figure 1-1, PDF page 4, is explicitly a top view through the package. Pin 1 is the upper-left lead on the west side. Pins 1–12 run downward on the west side, 13–24 left-to-right on the south side, 25–36 bottom-to-top on the east side, and 37–48 right-to-left on the north side. This is counterclockwise numbering with 12 pins per side. Table 1-1 identifies 48 perimeter pins plus a ground paddle; its ground note requires pins 6, 8, 30, and the paddle to share the common ground plane. The dossier's coordinate frame has +y downward, and its pad positions reproduce this top-view sequence without reflection. No manufacturer-fused numbered identities exist and no numbered dossier identity is collapsed.

## U_ADC

VERDICT: QUESTION

The footprint winding, pin-1 corner, side counts, 48 numbered pads, exposed paddle, functions, power/ground kinds, unused digital-interface termination kinds, and analog/digital signal kinds agree with the manufacturer evidence. The unresolved item is the reverse channel-name permutation on manufacturer channels 1–4: the dossier connects IN1 to ADC4, IN2 to ADC3, IN3 to ADC2, and IN4 to ADC1. Those nets are electrically suitable differential analog-input nets, but the supplied isolated evidence cannot establish whether that identity permutation is intentional. This requires design-context confirmation and is therefore a QUESTION under the protocol.

U_ADC pin 1 (ADC_VMID1): expected mid-rail reference output vs dossier VMID1; PASS.
U_ADC pin 2 (CONFIG1): expected hardware-control resistor/strap net vs dossier CFG1; PASS by net kind.
U_ADC pin 3 (CONFIG2/HGC_SCK): expected hardware-control/HGC clock net vs dossier CFG2; PASS by net kind.
U_ADC pin 4 (CONFIG3/HGC_SDO): expected hardware-control/HGC data output or ground termination when unused vs dossier GND; PASS.
U_ADC pin 5 (VDD_A1): expected analog supply rail vs dossier 3V3_ADC; PASS.
U_ADC pin 6 (GND_A): expected common analog ground plane vs dossier GND; PASS.
U_ADC pin 7 (LDO_A_FILT): expected LDO-A external capacitor node vs dossier LDO_A_FILT; PASS by net kind.
U_ADC pin 8 (GND_A): expected common analog ground plane vs dossier GND; PASS.
U_ADC pin 9 (VDD_A2): expected analog supply rail vs dossier 3V3_ADC; PASS.
U_ADC pin 10 (CONFIG4/HGC_CS): expected hardware-control/HGC chip-select net vs dossier CFG4; PASS by net kind.
U_ADC pin 11 (CONFIG5): expected hardware-control resistor/strap net vs dossier CFG5; PASS by net kind.
U_ADC pin 12 (ADC_VMID2): expected mid-rail reference output vs dossier VMID2; PASS.
U_ADC pin 13 (IN5N): expected channel-5 negative analog input vs dossier ADC5N; PASS.
U_ADC pin 14 (IN5P): expected channel-5 positive analog input vs dossier ADC5P; PASS.
U_ADC pin 15 (IN6N): expected channel-6 negative analog input vs dossier ADC6N; PASS.
U_ADC pin 16 (IN6P): expected channel-6 positive analog input vs dossier ADC6P; PASS.
U_ADC pin 17 (ADC_FILT2N): expected ADC-filter-2 negative/external-capacitor node vs dossier GND; PASS by typical-connection net kind.
U_ADC pin 18 (ADC_FILT2P): expected ADC-filter-2 positive node fed from VDD_A through 1 ohm vs dossier FILT2P; PASS by filter-node kind; passive connectivity is outside the dossier.
U_ADC pin 19 (IN7N): expected channel-7 negative analog input vs dossier ADC7N; PASS.
U_ADC pin 20 (IN7P): expected channel-7 positive analog input vs dossier ADC7P; PASS.
U_ADC pin 21 (IN8N): expected channel-8 negative analog input vs dossier ADC8N; PASS.
U_ADC pin 22 (IN8P): expected channel-8 positive analog input vs dossier ADC8P; PASS.
U_ADC pin 23 (RESET): expected active-low digital reset control vs dossier ADC_RESET_N; PASS.
U_ADC pin 24 (ASP_FSYNC): expected audio serial frame-sync net vs dossier ADC_FSYNC; PASS.
U_ADC pin 25 (ASP_DOUT1): expected audio serial data output vs dossier TDM_RAW; PASS.
U_ADC pin 26 (ASP_DOUT2): expected audio serial data output, permitted to float unused vs dossier unconnected-(U_ADC-ASP_DOUT2_NC-Pad26); PASS.
U_ADC pin 27 (ASP_DOUT3): expected audio serial data output, permitted to float unused vs dossier unconnected-(U_ADC-ASP_DOUT3_NC-Pad27); PASS.
U_ADC pin 28 (ASP_DOUT4): expected audio serial data output, permitted to float unused vs dossier unconnected-(U_ADC-ASP_DOUT4_NC-Pad28); PASS.
U_ADC pin 29 (ASP_BCLK): expected audio serial bit-clock net vs dossier ADC_BCLK; PASS.
U_ADC pin 30 (GND_D): expected common digital ground plane vs dossier GND; PASS.
U_ADC pin 31 (VDD_IO): expected digital-I/O supply rail vs dossier 3V3_ADC; PASS.
U_ADC pin 32 (LDO_D_FILT): expected LDO-D external-capacitor/output node vs dossier LDO_D_FILT; PASS.
U_ADC pin 33 (VDD_D): expected internal-LDO-powered digital supply tied to LDO_D_FILT in the typical connection vs dossier LDO_D_FILT; PASS.
U_ADC pin 34 (MCLK): expected master-clock input vs dossier ADC_MCLK; PASS.
U_ADC pin 35 (SPI_SDO/I2C_SCL): expected control-port signal or ground when unused vs dossier GND; PASS.
U_ADC pin 36 (SPI_SCK): expected SPI clock or ground when unused vs dossier GND; PASS.
U_ADC pin 37 (SPI_SDI/I2C_SDA): expected control-port signal or ground when unused vs dossier GND; PASS.
U_ADC pin 38 (SPI_CS): expected active-low chip select or VDD_IO when unused vs dossier 3V3_ADC; PASS.
U_ADC pin 39 (IN1N): expected channel-1 negative analog input vs dossier ADC4N; QUESTION: electrical kind/polarity is sane, channel identity is reversed.
U_ADC pin 40 (IN1P): expected channel-1 positive analog input vs dossier ADC4P; QUESTION: electrical kind/polarity is sane, channel identity is reversed.
U_ADC pin 41 (IN2N): expected channel-2 negative analog input vs dossier ADC3N; QUESTION: electrical kind/polarity is sane, channel identity is reversed.
U_ADC pin 42 (IN2P): expected channel-2 positive analog input vs dossier ADC3P; QUESTION: electrical kind/polarity is sane, channel identity is reversed.
U_ADC pin 43 (ADC_FILT1P): expected ADC-filter-1 positive node fed from VDD_A through 1 ohm vs dossier FILT1P; PASS by filter-node kind; passive connectivity is outside the dossier.
U_ADC pin 44 (ADC_FILT1N): expected ADC-filter-1 negative/external-capacitor node vs dossier GND; PASS by typical-connection net kind.
U_ADC pin 45 (IN3N): expected channel-3 negative analog input vs dossier ADC2N; QUESTION: electrical kind/polarity is sane, channel identity is reversed.
U_ADC pin 46 (IN3P): expected channel-3 positive analog input vs dossier ADC2P; QUESTION: electrical kind/polarity is sane, channel identity is reversed.
U_ADC pin 47 (IN4N): expected channel-4 negative analog input vs dossier ADC1N; QUESTION: electrical kind/polarity is sane, channel identity is reversed.
U_ADC pin 48 (IN4P): expected channel-4 positive analog input vs dossier ADC1P; QUESTION: electrical kind/polarity is sane, channel identity is reversed.
U_ADC pin 49 (EP/GND_A paddle): expected exposed paddle tied to the common ground plane directly under the device vs dossier center 4.6 x 4.6 pad on GND; PASS.

Coverage: 49/49 manufacturer electrical identities. Package comparison: pin 1 upper-left west-side lead PASS; CCW winding PASS; 12 pins per side PASS; numbered pin count 48/48 PASS; exposed paddle 1/1 PASS; identity collapse 0; undeclared aliases 0. Pairwise multi-instance symmetry is not applicable because this dossier contains one instance. Nine unnumbered paste/mechanical apertures are not manufacturer electrical identities and are excluded from the 49-pin denominator.

Required resolution: confirm from design-owned channel assignment evidence that the IN1↔ADC4, IN2↔ADC3, IN3↔ADC2, and IN4↔ADC1 permutation is intentional. If it is not intentional, correct the symbol/net mapping before order.
