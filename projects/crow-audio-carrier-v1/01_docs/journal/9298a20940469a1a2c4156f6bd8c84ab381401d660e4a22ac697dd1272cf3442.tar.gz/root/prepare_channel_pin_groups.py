"""Prepare fresh-context pin groups ONLY after corrected placement generation."""
from pathlib import Path
import json,hashlib,shutil,tempfile,sys
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent
sys.path.insert(0,str(D));from open_review import open_review
sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'));from pin_audit import part_authority,datasheet_path
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=json.loads((D/'channel-pin-transfer-proof.json').read_text());assert proof['expected_transformed_projection_equal'];assert sha(P/'04_kicad/crow_audio_carrier_v1.kicad_pcb')==proof['board_sha256'];assert proof['board_sha256']!='25287c83682141495ac07ae7fdf541bd92156891abf3294fd15fca83ffed5b9b'
# Root must already run pin_audit via bounded runtime on the exact new board,
# current generated assembly BOM and selected manufacturer parts. No generation
# or review admission from an old dossier is inferred by this preparation.
dossiers=D/'channel-current-pin-dossiers';manifest=json.loads((dossiers/'subject.json').read_text());assert manifest['board_sha256']==proof['board_sha256']
groups={'channel-adc-pin':['U_ADC'],'channel-cm-pin':[f'C_ADC_CM{n}{leg}' for n in range(1,5) for leg in 'PN']};opened=[]
for name,refs in groups.items():
 root=Path(tempfile.mkdtemp(prefix='carrier-'+name+'-'));shutil.copyfile(R/'skills/kicad-pcb/references/pin-review-protocol.md',root/'pin-review-protocol.md')
 for ref in refs:
  doc=dossiers/(ref+'.md');assert sha(doc)==manifest['dossiers'][ref]['sha256'];shutil.copyfile(doc,root/doc.name)
 for mpn in sorted({manifest['dossiers'][ref]['mpn'] for ref in refs}):
  part,auth=part_authority(P/'02_parts',mpn);pdf=Path(datasheet_path(part,auth['datasheet']));shutil.copyfile(pdf,root/pdf.name)
 opened.append(open_review(root,name,'Agent-role judgment. Fresh manufacturer-derived pin review. Read pin-review-protocol.md; derive pin-1/winding/count/EP/functions/nonpolarity from the exact supplied datasheet FIRST, then compare the supplied pin_audit dossiers for '+','.join(refs)+'. These are the ONLY engineering inputs. No schematic, history, author hypothesis or live board access. Do not use design rationale or infer missing context; QUESTION if needed. Actual datasheet pin drawing must be rendered and viewed. Dossiers extracted from native boardSHA'+proof['board_sha256']+'. Review per-part PASS|FAIL|QUESTION and concrete per-pin findings, complete denominator. This is a noncanonical group report for later root aggregation, not a whole-board SOUND claim. Do not fill canonical net/rules/parts fields from unavailable data. All new work only allocated scratch and outputs. Retain every input hash and exact datasheet SHA, full raw renderer/native command logs via bounded runtime. No children, no network, no installs. Return complete output promptly when all required protocol checks are covered.',12))
(D/'channel-pin-groups-opened.json').write_text(json.dumps(opened,indent=2)+'\n')
