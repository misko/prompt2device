from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,sys,tarfile,io
sys.dont_write_bytecode=True
D=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';I=Path('/tmp/carrier-connector-integration-20260911')
sys.path.insert(0,str(R/'skills/pcb-design/scripts'));from pipeline_execution import TaskEnvelope,verify_input_packet
sha=lambda b:hashlib.sha256(b).hexdigest();files={};tasks=[]
for name in ['locator-omission-dback','channel-adc-pin','channel-cm-pin']:
 j=json.loads((D/(name+'-opened.json')).read_text())[0];base=Path(j['project']);A=Path(j['attempt']).parent;e=TaskEnvelope.from_json(Path(j['envelope']).read_text());a=json.loads(Path(j['attempt']).read_text());assert a['status']=='PASS' and verify_input_packet(e,base)[0]
 for n,m in a['output']['completion']['outputs'].items():
  f=Path(j['output_dir'])/n;b=f.read_bytes();assert sha(b)==m['sha256'] and len(b)==m['size']
 for item in e.input_packet:files[name+'/inputs/'+item.path]=base/item.path
 for f in A.rglob('*'):
  if f.is_file():files[name+'/runtime/'+f.relative_to(A).as_posix()]=f
 for suffix in ['-opened.json','-reopening.json']:files['root/'+name+suffix]=D/(name+suffix)
 tasks.append({'name':name,'inputs_verified':len(e.input_packet),'outputs_verified':len(a['output']['completion']['outputs']),'status':a['status']})
for f in (D/'channel-current-pin-dossiers').rglob('*'):
 if f.is_file():files['current-dossiers/'+f.relative_to(D/'channel-current-pin-dossiers').as_posix()]=f
for n in ['preserve_pin_and_silk_diagnosis.py','prepare_channel_pin_groups.py','commission_locator_omission_dback.py','channel-pin-transfer-proof.json','locator-pin-parallel-subject.json','thermal-archive-member-types.json']:
 files['root/'+n]=D/n
for pattern in ['channel-pin-dossiers-*','locator-omission-current-handoff-*']:
 for f in I.glob(pattern):
  if f.is_file():files['root/validation/'+f.name]=f
seen={};refs={}
for n,f in list(sorted(files.items())):
 b=f.read_bytes();h=sha(b)
 if h in seen:refs[n]={'archive_member':seen[h],'size':len(b),'sha256':h};del files[n]
 else:seen[h]=n
members={n:{'size':f.stat().st_size,'sha256':sha(f.read_bytes())} for n,f in sorted(files.items())};tmp=D/'pin-and-silk-diagnosis.tar.gz'
with tarfile.open(tmp,'w:gz',compresslevel=3) as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 b=(json.dumps({'members':members,'references':refs,'tasks':tasks},indent=2)+'\n').encode();m=tarfile.TarInfo('MANIFEST.json');m.size=len(b);t.addfile(m,io.BytesIO(b))
h=sha(tmp.read_bytes());out=D/(h+'.tar.gz');assert not out.exists();tmp.rename(out)
with tarfile.open(out) as t:
 names=t.getnames();assert len(names)==len(set(names));assert set(names)==set(members)|{'MANIFEST.json'};assert all(x.isfile() and not Path(x.name).is_absolute() and '..' not in Path(x.name).parts for x in t.getmembers())
 for n,m in members.items():b=t.extractfile(n).read();assert sha(b)==m['sha256'] and len(b)==m['size']
 for n,m in refs.items():b=t.extractfile(m['archive_member']).read();assert sha(b)==m['sha256'] and len(b)==m['size']
result={'time':datetime.now(timezone.utc).isoformat(),'archive':str(out),'sha256':h,'size':out.stat().st_size,'members':len(members),'references':len(refs),'tasks':tasks};(D/'pin-and-silk-diagnosis-preservation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
