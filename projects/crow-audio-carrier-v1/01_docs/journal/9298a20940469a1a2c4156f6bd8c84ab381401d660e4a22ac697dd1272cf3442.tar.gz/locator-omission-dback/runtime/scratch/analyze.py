import sys
sys.dont_write_bytecode = True
from pathlib import Path
import hashlib, json, math
import pcbnew

ROOT=Path('/tmp/carrier-locator-omission-dback-nn4jv622')
S=ROOT/'06_build/task_runs/locator-omission-dback/scratch'
E=json.loads((ROOT/'06_build/task_runs/locator-omission-dback/envelope.json').read_text())

def rec(p):
    b=p.read_bytes(); return {'path':str(p.relative_to(ROOT)),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def verify():
    rows=[]; bad=[]
    for x in E['input_packet']:
        p=ROOT/x['path']; got=rec(p); rows.append(got)
        if got['size']!=x['size'] or got['sha256']!=x['sha256']: bad.append({'path':x['path'],'expected':x,'actual':got})
    return {'count':len(rows),'bad':bad,'rows':rows}

def board(path):
    b=pcbnew.LoadBoard(str(path)); out={}; pads=[]; zones=[]
    for f in b.GetFootprints():
        r=f.GetReference(); t=f.Reference(); pos=f.GetPosition()
        out[r]={'x':pcbnew.ToMM(pos.x),'y':pcbnew.ToMM(pos.y),'rotation':f.GetOrientationDegrees(),
                'side':'bottom' if f.IsFlipped() else 'top','visible':bool(t.IsVisible()),
                'text_x':pcbnew.ToMM(t.GetPosition().x),'text_y':pcbnew.ToMM(t.GetPosition().y),
                'text_rot':t.GetTextAngleDegrees(),'text_h':pcbnew.ToMM(t.GetTextHeight()),
                'layer':b.GetLayerName(t.GetLayer()),'value':f.GetValue()}
        for p in f.Pads():
            q=p.GetPosition(); sz=p.GetSize(); drill=p.GetDrillSize()
            pads.append([r,p.GetNumber(),pcbnew.ToMM(q.x),pcbnew.ToMM(q.y),pcbnew.ToMM(sz.x),pcbnew.ToMM(sz.y),pcbnew.ToMM(drill.x),pcbnew.ToMM(drill.y),p.GetNetname(),p.GetShape(),p.GetAttribute(),p.GetLayerSet().FmtHex()])
    for z in b.Zones():
        zones.append([z.GetNetname(),z.GetLayerSet().FmtHex(),z.GetPadConnection(),z.GetThermalReliefGap(),z.GetThermalReliefSpokeWidth(),z.GetMinThickness(),z.GetZoneName()])
    return {'footprints':out,'pads':sorted(pads),'zones':sorted(zones)}

v=verify(); (S/'input-verification-before.json').write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
old=board(ROOT/'previous/04_kicad/crow_audio_carrier_v1.kicad_pcb')
cur=board(ROOT/'project/04_kicad/crow_audio_carrier_v1.kicad_pcb')
oldh=sorted(r for r,x in old['footprints'].items() if not x['visible'] and not r.startswith(('H','FID')))
curh=sorted(r for r,x in cur['footprints'].items() if not x['visible'] and not r.startswith(('H','FID')))
refs=sorted(set(old['footprints'])|set(cur['footprints']))
changed=[]
for r in refs:
    a=old['footprints'].get(r); c=cur['footprints'].get(r)
    if a != c: changed.append({'ref':r,'old':a,'current':c})
data={'old_hidden':oldh,'current_hidden':curh,'newly_hidden':sorted(set(curh)-set(oldh)),
      'newly_visible':sorted(set(oldh)-set(curh)),'old_hidden_count':len(oldh),'current_hidden_count':len(curh),
      'changed_footprint_or_reference_records':changed,
      'pad_geometry_net_exact_equal':old['pads']==cur['pads'],'zone_modes_exact_equal':old['zones']==cur['zones'],
      'old_pad_count':len(old['pads']),'current_pad_count':len(cur['pads']),'old_zone_count':len(old['zones']),'current_zone_count':len(cur['zones'])}
(S/'board-comparison.json').write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in data.items() if k not in ('changed_footprint_or_reference_records',)},indent=2))
