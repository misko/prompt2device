import sys
sys.dont_write_bytecode=True
from pathlib import Path
sys.path.insert(0,'/tmp/carrier-locator-omission-dback-nn4jv622/authority/skills/kicad-pcb/scripts')
from pre_route_review_check import design_rules_digest
print(design_rules_digest(Path('/tmp/carrier-locator-omission-dback-nn4jv622/project')))
