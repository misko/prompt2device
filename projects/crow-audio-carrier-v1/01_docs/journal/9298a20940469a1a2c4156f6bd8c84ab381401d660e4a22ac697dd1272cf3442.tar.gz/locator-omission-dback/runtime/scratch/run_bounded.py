import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json, os
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_runtime import run_stage
S=Path('/tmp/carrier-locator-omission-dback-nn4jv622/06_build/task_runs/locator-omission-dback/scratch')
class Spec:
    id='locator_analysis'; work_class='local'; timeout_s=180; produces=()
label=os.environ.get('LOCATOR_STAGE_LABEL','bounded-analysis')
cmd=sys.argv[1:]
o=run_stage(Spec(),cmd,log_path=S/(label+'.log'),cwd=S,console=None)
payload=json.dumps(o.to_mapping(),indent=2,sort_keys=True)
(S/(label+'-outcome.json')).write_text(payload+'\n')
print(payload)
raise SystemExit(0 if o.returncode==0 else o.returncode)
