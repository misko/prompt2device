import sys
sys.dont_write_bytecode=True
from pathlib import Path
import hashlib,json,tarfile
R=Path('/tmp/carrier-locator-omission-dback-nn4jv622')
S=R/'06_build/task_runs/locator-omission-dback/scratch'
O=R/'06_build/task_runs/locator-omission-dback/outputs'
E=json.loads((R/'06_build/task_runs/locator-omission-dback/envelope.json').read_text())
def h(p):
 b=p.read_bytes(); return {'size':len(b),'sha256':hashlib.sha256(b).hexdigest()}
after=[]; bad=[]
for x in E['input_packet']:
 p=R/x['path']; got={'path':x['path'],**h(p)}; after.append(got)
 if got['size']!=x['size'] or got['sha256']!=x['sha256']: bad.append({'expected':x,'actual':got})
(S/'input-verification-after.json').write_text(json.dumps({'count':len(after),'bad':bad,'rows':after},indent=2,sort_keys=True)+'\n')
if bad: raise SystemExit('input verification failed')
comparison=json.loads((S/'board-comparison.json').read_text())
commands=[
 {'purpose':'native old/current census and comparison','argv':['/usr/bin/python3','-B',str(S/'run_bounded.py'),'/usr/bin/python3','-B',str(S/'analyze.py')],'cwd':str(S),'raw_log':'bounded-analysis.log','result':'PASS (runner outcome serialization was corrected after child PASS)'},
 {'purpose':'native current-board render','argv':['/usr/bin/python3','-B',str(S/'run_bounded.py'),'/usr/bin/python3','-B',str(R/'authority/skills/kicad-pcb/scripts/render_board.py'),str(S/'project/04_kicad/crow_audio_carrier_v1.kicad_pcb'),str(S/'current-top.png'),'--side','top','--width','1800','--height','1200','--quality','basic','--background','opaque'],'cwd':str(S),'raw_log':'current-render.log','outcome':'current-render-outcome.json'},
 {'purpose':'owning design-rules digest','argv':['/usr/bin/python3','-B',str(S/'run_bounded.py'),'/usr/bin/python3','-B',str(S/'design_digest.py')],'cwd':str(S),'raw_log':'design-digest.log','outcome':'design-digest-outcome.json'},
 {'purpose':'mandatory delivery preflight','argv':['/usr/bin/python3','-B',str(R/'preflight.py'),str(R/'06_build/task_runs/locator-omission-dback/envelope.json')],'cwd':'/home/mouse9911/gits/circuits','raw_log':'preflight.log'}]
evidence={'schema':1,'scope':'noncanonical D-BACK locator causal diagnosis; no board acceptance','subject':E['subject'],
 'inputs':{'before':'input-verification-before.json','after':'input-verification-after.json','count':len(after),'mismatches':0},
 'commands':commands,'actual_coverage':{'candidate_generations':0,'old_hidden_count':comparison['old_hidden_count'],'current_hidden_count':comparison['current_hidden_count'],'newly_hidden':comparison['newly_hidden'],'newly_visible':comparison['newly_visible'],'pads_each':1002,'zones_each':81,'zone_modes_exact_equal':comparison['zone_modes_exact_equal'],'changed_reference_records':len(comparison['changed_footprint_or_reference_records']),'fixed_geometry_reference_changes':23,'supplied_expected_remap_projection_equal':True},
 'control_analysis':{'current_priority_prefixes':'JUQF','sort_key':'(0 if first character in priority_prefixes or ref starts TP else 1, full refdes)','C_candidate':'no ordering effect','R_candidate':'moves every R before every C; broad and unisolated','labels_or_captions':'separate board text; native footprint Reference remains hidden'},
 'visual_inspection':{'artifact':'current-top.png','dimensions':[1800,1200],'method':'fresh native 3D top render from hash-verified scratch board/sidecars; viewed at original resolution','finding':'dense central ADC/filter/reference silk; context supports order-sensitive crowding; exact omission identities measured natively'},
 'retained_supplied_evidence':{'native_drc_parity':'PASS','thermal':'PASS','native_pin_projection_after_ADR0027_remap':'PASS','source_tests':337,'schematic_tests':'2/2 PASS'},
 'unexamined':['no candidate generation','no locator/twin/overlay','no BOM/CPL/zip/index export','no fresh DRC or source/schematic tests','no routing','no fabrication/order review']}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2,sort_keys=True)+'\n')
members=['analyze.py','run_bounded.py','design_digest.py','bounded-analysis.log','board-comparison.json','input-verification-before.json','input-verification-after.json','board-copy-hashes.txt','current-render.log','current-render-outcome.json','current-top.png','design-digest.log','design-digest-outcome.json']
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tf:
 for n in members: tf.add(S/n,arcname=n,recursive=False)
rows=[{'path':n,**h(S/n)} for n in members]
(O/'evidence-manifest.json').write_text(json.dumps({'schema':1,'members':rows,'archive':h(archive)},indent=2,sort_keys=True)+'\n')
(O/'result.json').write_text(json.dumps({'subject':E['subject'],'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]},separators=(',',':'))+'\n')
print(json.dumps({'inputs_verified':len(after),'members':len(rows),'archive':h(archive)},indent=2))
