# crow-audio-carrier-v1 — carrier channel common-mode capacitor manufacturer pin review

- date: 2026-09-11 (America/Los_Angeles)
- reviewer: fresh-context judgment reviewer, task `channel-cm-pin`
- context_given: `pin-review-protocol.md`, eight named capacitor dossiers, and the exact supplied manufacturer PDF only
- source_commit: unavailable (not supplied in the isolated packet)
- board_sha256: `0ab5b6dae425074f2515dc3c3d737e56f2292d83140590dca592b7b964e73090` (stated by the task envelope text)
- subject_raw_sha256: `588f2698135b3c5bb97deab23ce63c2f7ef642e55dd7425c596a542f6323881f`
- subject_semantic_sha256: `72f7236c8da856391b4483b0b85ea1c662b4787a6bc330d5b4d4c6dc02d182e7`
- scope: noncanonical, manufacturer-derived part-group pin review; this is not a whole-board SOUND claim
- engineering_verdict: **PASS**
- evidence_verdict: **PASS**

## Manufacturer facts derived before dossier comparison

Exact evidence: Murata `GRM1555C1H102JA01-01A.pdf`, SHA-256 `805014e8a9a42ab11f8dd048f0cf32802dd3353b1d772118468e03222f9ec5d9`, 1,949,268 bytes.

The rendered Type & Dimension drawing on PDF page 2 was visually inspected at the protocol-required 80 dpi. It shows a symmetric rectangular multilayer ceramic chip with one external electrode on each of the two opposite ends. It has no pin-1 marker, numbered terminal, anode/cathode mark, or orientation mark. The same page identifies the device as a chip multilayer ceramic capacitor and gives size code 1005M (0402), with L = 1.0 ± 0.05 mm, W = 0.5 ± 0.05 mm, and T = 0.5 ± 0.05 mm. The specification tests voltage proof and insulation resistance “between the terminations,” without assigning distinct terminal identities.

Manufacturer-derived terminal facts:

- physical terminal count: 2 external end electrodes
- terminal identity and function: two interchangeable capacitor terminations; the manufacturer does not assign terminal numbers or distinct A/B functions
- polarity: nonpolar; no anode/cathode or mounting orientation is specified, and the terminal construction is symmetric
- pin-1 corner, winding, and pins per side: not applicable to this two-terminal unnumbered chip
- exposed pad: none
- package: 1005M (EIA 0402), matching the dossier footprint package class `C_0402_1005Metric`
- electrical rating relevant to identity: C0G, 1000 pF ±5%, DC 50 V

Accordingly, dossier pad numbers 1 and 2 and functions A and B are artifact-local aliases. Either physical termination may occupy either end. A manufacturer winding comparison is inapplicable, but both physical identities must remain present.

## Complete per-instance review

### C_ADC_CM1P — VERDICT: PASS

- C_ADC_CM1P pin 1 (A): expected one of two interchangeable, nonpolar capacitor terminations on a channel-class net vs dossier shows west pad on `ADC1P`; PASS.
- C_ADC_CM1P pin 2 (B): expected the other interchangeable, nonpolar capacitor termination, with no manufacturer-required net vs dossier shows east pad on `GND`; PASS.
- Count/package/EP: expected two end terminals, 1005M (0402), and no EP vs dossier shows exactly two opposed pads in `C_0402_1005Metric` and no EP; PASS.

### C_ADC_CM1N — VERDICT: PASS

- C_ADC_CM1N pin 1 (A): expected one of two interchangeable, nonpolar capacitor terminations on a channel-class net vs dossier shows west pad on `ADC1N`; PASS.
- C_ADC_CM1N pin 2 (B): expected the other interchangeable, nonpolar capacitor termination, with no manufacturer-required net vs dossier shows east pad on `GND`; PASS.
- Count/package/EP: expected two end terminals, 1005M (0402), and no EP vs dossier shows exactly two opposed pads in `C_0402_1005Metric` and no EP; PASS.

### C_ADC_CM2P — VERDICT: PASS

- C_ADC_CM2P pin 1 (A): expected one of two interchangeable, nonpolar capacitor terminations on a channel-class net vs dossier shows west pad on `ADC2P`; PASS.
- C_ADC_CM2P pin 2 (B): expected the other interchangeable, nonpolar capacitor termination, with no manufacturer-required net vs dossier shows east pad on `GND`; PASS.
- Count/package/EP: expected two end terminals, 1005M (0402), and no EP vs dossier shows exactly two opposed pads in `C_0402_1005Metric` and no EP; PASS.

### C_ADC_CM2N — VERDICT: PASS

- C_ADC_CM2N pin 1 (A): expected one of two interchangeable, nonpolar capacitor terminations on a channel-class net vs dossier shows west pad on `ADC2N`; PASS.
- C_ADC_CM2N pin 2 (B): expected the other interchangeable, nonpolar capacitor termination, with no manufacturer-required net vs dossier shows east pad on `GND`; PASS.
- Count/package/EP: expected two end terminals, 1005M (0402), and no EP vs dossier shows exactly two opposed pads in `C_0402_1005Metric` and no EP; PASS.

### C_ADC_CM3P — VERDICT: PASS

- C_ADC_CM3P pin 1 (A): expected one of two interchangeable, nonpolar capacitor terminations on a channel-class net vs dossier shows west pad on `ADC3P`; PASS.
- C_ADC_CM3P pin 2 (B): expected the other interchangeable, nonpolar capacitor termination, with no manufacturer-required net vs dossier shows east pad on `GND`; PASS.
- Count/package/EP: expected two end terminals, 1005M (0402), and no EP vs dossier shows exactly two opposed pads in `C_0402_1005Metric` and no EP; PASS.

### C_ADC_CM3N — VERDICT: PASS

- C_ADC_CM3N pin 1 (A): expected one of two interchangeable, nonpolar capacitor terminations on a channel-class net vs dossier shows west pad on `ADC3N`; PASS.
- C_ADC_CM3N pin 2 (B): expected the other interchangeable, nonpolar capacitor termination, with no manufacturer-required net vs dossier shows east pad on `GND`; PASS.
- Count/package/EP: expected two end terminals, 1005M (0402), and no EP vs dossier shows exactly two opposed pads in `C_0402_1005Metric` and no EP; PASS.

### C_ADC_CM4P — VERDICT: PASS

- C_ADC_CM4P pin 1 (A): expected one of two interchangeable, nonpolar capacitor terminations on a channel-class net vs dossier shows west pad on `ADC4P`; PASS.
- C_ADC_CM4P pin 2 (B): expected the other interchangeable, nonpolar capacitor termination, with no manufacturer-required net vs dossier shows east pad on `GND`; PASS.
- Count/package/EP: expected two end terminals, 1005M (0402), and no EP vs dossier shows exactly two opposed pads in `C_0402_1005Metric` and no EP; PASS.

### C_ADC_CM4N — VERDICT: PASS

- C_ADC_CM4N pin 1 (A): expected one of two interchangeable, nonpolar capacitor terminations on a channel-class net vs dossier shows west pad on `ADC4N`; PASS.
- C_ADC_CM4N pin 2 (B): expected the other interchangeable, nonpolar capacitor termination, with no manufacturer-required net vs dossier shows east pad on `GND`; PASS.
- Count/package/EP: expected two end terminals, 1005M (0402), and no EP vs dossier shows exactly two opposed pads in `C_0402_1005Metric` and no EP; PASS.

## Pairwise symmetry and denominator

All eight instances preserve the same structure: artifact pad 1 is on its own `ADC{1..4}{P|N}` channel net, artifact pad 2 is on `GND`, both physical end electrodes exist, and no EP is introduced. Rotation changes board orientation only; because the manufacturer component is unnumbered and nonpolar, the 0°/90° placements create no winding or mirror hazard.

- instances reviewed: 8/8
- dossier pads reviewed: 16/16
- manufacturer terminal-count checks: 8/8
- package/no-EP checks: 8/8
- unresolved findings: 0

This PASS establishes only that the supplied dossiers are consistent with the exact manufacturer's terminal construction, polarity, terminal count, and package identity. It does not judge the wider circuit or board.
