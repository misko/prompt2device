#!/usr/bin/python3
import hashlib
import json
import sys
import tarfile
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path("/tmp/carrier-channel-cm-pin-p8cz1s23")
RUN = ROOT / "06_build/task_runs/channel-cm-pin"
SCRATCH = RUN / "scratch"
OUT = RUN / "outputs"
ENVELOPE = json.loads((RUN / "envelope.json").read_text())


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def verify_inputs():
    rows = []
    for item in ENVELOPE["input_packet"]:
        path = ROOT / item["path"]
        observed_size = path.stat().st_size
        observed_sha256 = digest(path)
        rows.append({
            "name": item["name"],
            "path": item["path"],
            "expected_size": item["size"],
            "observed_size": observed_size,
            "expected_sha256": item["sha256"],
            "observed_sha256": observed_sha256,
            "status": "PASS" if observed_size == item["size"] and observed_sha256 == item["sha256"] else "FAIL",
        })
    if any(row["status"] != "PASS" for row in rows):
        raise RuntimeError("input verification failed")
    return rows


before = verify_inputs()
commands = []
for path in sorted(SCRATCH.glob("*.log.json")):
    record = json.loads(path.read_text())
    commands.append({
        "argv": record["argv"],
        "cwd": record["cwd"],
        "returncode": record["outcome"]["returncode"],
        "status": record["outcome"]["status"],
        "started_at": record["outcome"]["started_at"],
        "finished_at": record["outcome"]["finished_at"],
        "elapsed_s": record["outcome"]["elapsed_s"],
        "raw_stdout_stderr": str(Path(record["outcome"]["log_path"]).relative_to(ROOT)),
        "runtime_record": str(path.relative_to(ROOT)),
    })

evidence = {
    "schema": 1,
    "task": "channel-cm-pin",
    "scope": "noncanonical manufacturer-derived pin review of eight supplied capacitor dossiers",
    "subject": ENVELOPE["subject"],
    "generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    "exact_datasheet": {
        "path": "GRM1555C1H102JA01-01A.pdf",
        "sha256": "805014e8a9a42ab11f8dd048f0cf32802dd3353b1d772118468e03222f9ec5d9",
        "size": 1949268,
    },
    "manufacturer_derivation": {
        "manufacturer": "Murata",
        "part": "GRM1555C1H102JA01D",
        "type": "chip multilayer ceramic capacitor",
        "terminals": 2,
        "terminal_identity": "two interchangeable external end electrodes; manufacturer assigns no pin numbers",
        "polarity": "nonpolar",
        "pin_1_corner": "not applicable",
        "winding": "not applicable",
        "pins_per_side": "one electrode at each opposed end; numbered-side convention not applicable",
        "exposed_pad": "none",
        "package": "1005M (0402), 1.0 x 0.5 x 0.5 mm",
    },
    "visual_inspection": [{
        "performed": True,
        "tool": "view_image",
        "render": "06_build/task_runs/channel-cm-pin/scratch/datasheet-page-02.png",
        "source_page": 2,
        "render_dpi": 80,
        "detail": "original",
        "observations": [
            "symmetric rectangular chip body",
            "one external electrode on each opposite end",
            "no pin-1, anode/cathode, or orientation marking",
            "size code 1005M (0402) and dimensions are legible",
        ],
    }],
    "commands": commands,
    "input_verification_before": before,
    "coverage": {
        "instances_expected": 8,
        "instances_reviewed": 8,
        "pads_expected": 16,
        "pads_reviewed": 16,
        "terminal_count_checks": "8/8",
        "package_and_ep_checks": "8/8",
        "pairwise_symmetry_checked": True,
        "instance_verdicts": {
            "C_ADC_CM1P": "PASS", "C_ADC_CM1N": "PASS",
            "C_ADC_CM2P": "PASS", "C_ADC_CM2N": "PASS",
            "C_ADC_CM3P": "PASS", "C_ADC_CM3N": "PASS",
            "C_ADC_CM4P": "PASS", "C_ADC_CM4N": "PASS",
        },
        "engineering_verdict": "PASS",
        "unresolved": [],
    },
}

(OUT / "evidence.json").write_text(json.dumps(evidence, indent=2, sort_keys=True) + "\n")
(OUT / "result.json").write_text(json.dumps({
    "subject": ENVELOPE["subject"],
    "checks": {"evidence-complete": "PASS", "inputs-verified": "PASS", "review-complete": "PASS"},
    "unresolved": [],
}, separators=(",", ":")) + "\n")

archive = OUT / "evidence.tar.gz"
members = [p for p in sorted(SCRATCH.rglob("*")) if p.is_file()]
with tarfile.open(archive, "w:gz") as tf:
    for path in members:
        tf.add(path, arcname=path.relative_to(SCRATCH).as_posix(), recursive=False)

manifest_members = []
with tarfile.open(archive, "r:gz") as tf:
    archive_names = tf.getnames()
expected_names = [p.relative_to(SCRATCH).as_posix() for p in members]
if archive_names != expected_names:
    raise RuntimeError("archive membership mismatch")
for path in members:
    manifest_members.append({
        "path": path.relative_to(SCRATCH).as_posix(),
        "size": path.stat().st_size,
        "sha256": digest(path),
    })

after = verify_inputs()
evidence["input_verification_after"] = after
(OUT / "evidence.json").write_text(json.dumps(evidence, indent=2, sort_keys=True) + "\n")
(OUT / "evidence-manifest.json").write_text(json.dumps({
    "schema": 1,
    "archive": {"path": "evidence.tar.gz", "size": archive.stat().st_size, "sha256": digest(archive)},
    "members": manifest_members,
    "member_count": len(manifest_members),
}, indent=2, sort_keys=True) + "\n")
