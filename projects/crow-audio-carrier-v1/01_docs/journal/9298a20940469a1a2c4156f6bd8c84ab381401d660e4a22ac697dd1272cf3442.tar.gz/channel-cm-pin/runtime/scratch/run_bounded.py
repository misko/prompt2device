#!/usr/bin/python3
import json
import os
import sys
from pathlib import Path

sys.dont_write_bytecode = True
SCRIPTS = Path("/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts")
sys.path.insert(0, str(SCRIPTS))
from pipeline_runtime import run_stage


def main() -> int:
    if len(sys.argv) < 3:
        raise SystemExit("usage: run_bounded.py LOG COMMAND [ARG ...]")
    log_path = Path(sys.argv[1])
    command = sys.argv[2:]
    spec = {"id": log_path.stem.replace("-", "_"), "work_class": "local", "timeout_s": 60.0}
    events = []
    outcome = run_stage(
        spec,
        command,
        log_path=log_path,
        cwd=Path("/tmp/carrier-channel-cm-pin-p8cz1s23"),
        env=dict(os.environ),
        heartbeat_s=5.0,
        event_sink=events.append,
    )
    record = {
        "argv": command,
        "cwd": "/tmp/carrier-channel-cm-pin-p8cz1s23",
        "outcome": outcome.to_mapping(),
        "events": events,
    }
    Path(str(log_path) + ".json").write_text(json.dumps(record, indent=2, default=str) + "\n")
    return int(outcome.returncode or 0)


if __name__ == "__main__":
    raise SystemExit(main())
