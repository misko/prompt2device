review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 92a4e2fc0fecde845f2dfa0d9e2f5bfbd943372962fb449d699a98d957fc5633
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: 7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c

# Fresh independent pin review — carrier-control-fets

Coverage is explicitly limited to Q_DUMP, Q_PRE_EN, and Q_RST1. This is not whole-board acceptance. The order verdict remains DO-NOT-ORDER because this is a pre-route review stage.

## Q_DUMP — AO3400A

VERDICT: PASS

Measured native pads: 3. Measured physical pin identities: 3. Declared aliases: 0. Exposed pads: 0.

Primary document: `AO3400A_Rev3.1.pdf`, SHA-256 `9c60d0b6c1ddc7609a4b788a91181468d8ffe6c3e9ba425c3d8ffc5ba88c5033`, PDF page 1, figures `SOT23 Top View`, `SOT23 Bottom View`, and device circuit.

Expected: SOT-23 has three separate leads and no exposed pad. In the manufacturer's top view, the pin-1 marker is adjacent to G; the other lead on the paired side is S; the single opposite lead is D. Thus pin 1 = G, pin 2 = S, pin 3 = D and numbering winds CCW in top view. Observed: front-mounted component-top coordinates are pad 1 G at (-0.9375,-0.9500), pad 2 S at (-0.9375,+0.9500), and pad 3 D at (+0.9375,0), matching the manufacturer top view by rotation only. Pads 1 and 2 form the paired physical side because they share x=-0.9375; the dossier's angular side labels N and S reflect their near-corner locations, while the coordinates preserve the required paired-side geometry.

Q_DUMP pin 1 (G): expected a gate-control net vs observed `DUMP_GATE`.

Q_DUMP pin 2 (S): expected the low-side N-MOS source on ground vs observed `GND`.

Q_DUMP pin 3 (D): expected the switched/sensed node vs observed `ADC_DUMP`.

## Q_PRE_EN — 2N7002K-7

VERDICT: PASS

Measured native pads: 3. Measured physical pin identities: 3. Declared aliases: 0. Exposed pads: 0.

Primary document: `2N7002K_DS30896_Rev20-2.pdf`, SHA-256 `669e5d68d6458e0879d7396416bdcdb3ef9966ea60f054773d4c891d735aa818`, PDF page 1, figures `SOT23 (Standard) Top View` and `Equivalent Circuit`; package geometry cross-checked on PDF page 7, figures `Package Outline Dimensions` and `Suggested Pad Layout`.

Expected: three separate SOT-23 leads, no exposed pad, pin 1 = G, pin 2 = S, pin 3 = D, CCW top-view winding, with G/S on the paired side and D opposite. Observed: front-mounted component-top coordinates place pad 1 G at (-1.0000,-0.9500), pad 2 S at (-1.0000,+0.9500), and pad 3 D at (+1.0000,0), matching the manufacturer's top view by rotation only and with the correct paired-side geometry.

Q_PRE_EN pin 1 (G): expected a logic/control net vs observed `PWR_EN`.

Q_PRE_EN pin 2 (S): expected the low-side N-MOS source on ground vs observed `GND`.

Q_PRE_EN pin 3 (D): expected the controlled open-drain destination vs observed `PRE_GATE`.

## Q_RST1 — 2N7002K-7

VERDICT: PASS

Measured native pads: 3. Measured physical pin identities: 3. Declared aliases: 0. Exposed pads: 0.

Primary document: `2N7002K_DS30896_Rev20-2.pdf`, SHA-256 `669e5d68d6458e0879d7396416bdcdb3ef9966ea60f054773d4c891d735aa818`, PDF page 1, figures `SOT23 (Standard) Top View` and `Equivalent Circuit`; package geometry cross-checked on PDF page 7, figures `Package Outline Dimensions` and `Suggested Pad Layout`.

Expected: three separate SOT-23 leads, no exposed pad, pin 1 = G, pin 2 = S, pin 3 = D, CCW top-view winding, with G/S on the paired side and D opposite. Observed: front-mounted component-top coordinates place pad 1 G at (-1.0000,-0.9500), pad 2 S at (-1.0000,+0.9500), and pad 3 D at (+1.0000,0), matching the manufacturer's top view by rotation only and with the correct paired-side geometry.

Q_RST1 pin 1 (G): expected a logic/control net vs observed `RESET_PULSE_H`.

Q_RST1 pin 2 (S): expected the low-side N-MOS source on ground vs observed `GND`.

Q_RST1 pin 3 (D): expected the controlled reset destination vs observed `ADC_RESET_N`.

## Instance symmetry

Q_PRE_EN and Q_RST1 use the same 2N7002K-7 physical pin mapping and the same structural net kinds: pin 1 is a control signal, pin 2 is GND, and pin 3 is a controlled open-drain destination. Q_DUMP has the same low-side N-MOS G/S/D topology. No instance diverges structurally.

No unresolved findings.
