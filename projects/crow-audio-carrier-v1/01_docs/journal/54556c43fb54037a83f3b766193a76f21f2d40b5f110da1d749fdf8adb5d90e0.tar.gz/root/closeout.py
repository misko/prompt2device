from pathlib import Path
import io,tarfile,hashlib,json,subprocess
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911')
items={}
for prefix in ['cat-final-contracts','cat-handoff']:
 for p in I.glob(prefix+'*'):
  if p.is_file():items['runtime/'+p.name]=p.read_bytes()
for rel in ['01_docs/evidence/pre-cat-brief-20260912.md','01_docs/findings.yaml','01_docs/STATUS.md','06_build/agent_handoff.yaml']:items['project/'+rel]=(P/rel).read_bytes()
for name in ['closeout.py','preservation.json','root-review-reopening.json']:items['root/'+name]=(D/name).read_bytes()
m={'files':[{'path':n,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(items.items())]};items['manifest.json']=json.dumps(m,indent=2).encode()+b'\n'
p=D/'closeout.tar.gz'
with tarfile.open(p,'w:gz') as t:
 for n,b in sorted(items.items()):x=tarfile.TarInfo(n);x.size=len(b);x.mtime=0;t.addfile(x,io.BytesIO(b))
with tarfile.open(p,'r:gz') as t:
 for x in t.getmembers():assert t.extractfile(x).read()==items[x.name]
h=hashlib.sha256(p.read_bytes()).hexdigest();dest=P/'01_docs/journal'/(h+'.tar.gz');dest.write_bytes(p.read_bytes())
with (P/'01_docs/journal/contracts.md').open('a') as f:f.write(f'''\n\n## Allowed Cat5e source closeout — 2026-09-12\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Exact failed/corrected membership and handoff validation, preserved historical requirement bytes, current ledger and compact handoff |\n\nAudit: SHA256 equals filename; size{p.stat().st_size}bytes, {len(items)-1}payload\nmembers verified against manifest.json. Reject extra, missing, duplicate or\nnon-regular members. This retains the original failures and does not confer\nphysical or release acceptance.\n''')
with (P/'01_docs/journal/schematic.md').open('a') as f:f.write(f'''\n- Closeout: membership17,449files,2,873existingdebt/26units held,zero strays;\n  compact schematic handoff6,415bytes generated and validated. Original\n  failure and corrected passes, exact historical requirement bytes and current\n  handoff preserved in `{h}.tar.gz` ({p.stat().st_size}bytes,\n  {len(items)-1}payloadmembers), all reopened. Source implementation is complete;\n  normal canonical renewal and physical/release gates remain owed.\n''')
files=json.loads((D/'commit-files.json').read_text());files.append(str(dest.relative_to(R)));files=list(dict.fromkeys(files));(D/'commit-files.json').write_text(json.dumps(files,indent=2)+'\n')
subprocess.run(['git','add','--',*files],cwd=R,check=True)
print(h,p.stat().st_size,len(items)-1)
