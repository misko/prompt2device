from pathlib import Path
import json,hashlib,sys,subprocess,datetime,shutil,tarfile,io
import pcbnew
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';T=P/'06_build/task_runs/rj45-carrier-placement-after-frontreg1';S=T/'scratch';E=S/'execution';O=T/'outputs';O.mkdir(exist_ok=True);H=P/'06_build/handoffs/rj45-carrier-placement-after-frontreg1'
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet,writer_scope_receipt
from pipeline_runtime import _tree_snapshot,_changed_paths,_snapshot_sha256
from pipeline_artifacts import validate_task_outputs
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
j=json.loads((T/'envelope.json').read_text());e=TaskEnvelope.from_json((T/'envelope.json').read_text());a=json.loads((T/'admission.json').read_text());inv=json.loads((E/'native-inventory.json').read_text());rt=json.loads((E/'runtime.json').read_text());orient=json.loads((P/'06_build/pre_route/orientation/orientation_receipt.json').read_text())
assert verify_input_packet(e,P)[0]
pre=json.loads((E/'inputs-before.json').read_text());after=[]
for row in pre['protected']:
 actual=sha(R/row['path']);assert actual==row['sha256'];after.append(dict(path=row['path'],sha256=actual))
dump(E/'inputs-after.json',dict(input_packet_count=len(j['input_packet']),frozen_inputs_verified=True,protected_count=len(after),protected=after))
r0path=P/'06_build/route/r0.kicad_pcb';r0=pcbnew.LoadBoard(str(r0path));fps=list(r0.GetFootprints());sm=[f for f in fps if f.GetAttributes() & pcbnew.FP_SMD and f.GetReference() not in ['H1','H2','H3','H4','FID1','FID2','FID3']];assert len(sm)==306 and all(f.GetLayer()==pcbnew.F_Cu for f in sm)
r0data=dict(path=str(r0path),sha256=sha(r0path),footprints=len(fps),pads=sum(len(list(f.Pads())) for f in fps),fitted_smd_top=len(sm),fitted_smd_bottom=0,track_via_objects=len(r0.GetTracks()),status='Prepared route r0; route acceptance NOT RUN')
dump(E/'prepared-route.json',r0data)
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
status=f"""# STATUS beacon — crow-audio-carrier-v1

stage: placement
step: P-ORIENT current human review required
measure: MEASURED: one canonical frontreg1 continuation rc1 in151.175s; registration6/6PASS; orientation machine9/9PASS with7renders/11views;306topSMD/0bottom; placementDRC0/499/0, all499rows rebound.
state: blocked
next: Review exact current connector images/subject before any approval or continuation. Placement review and routing NOT RUN. Compact handoff refused because retained DRC gate is older than regenerated board; blocker intact. Pod current five-view human orientation remains pending. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.
op_pid:
updated: {now}
"""
(P/'01_docs/STATUS.md').write_text(status)
entry=f"""\n## {now} — frontreg1 canonical continuation stopped at current human orientation gate

MEASURED: sole authorized unchanged-source run stopped [5e] P-ORIENT, rc1 after151.175s inner /151.314075s outer. Exact registration6/6groupsPASS; fresh F1–F8 8instances/16overlaps, five unchanged cache hits. Orientation machine9/9PASS, zero geometry findings, seven native renders and11focused views at subject{orient['subject_sha256']}; existing approval subject/denominator is stale. J9 measured3.08mm inward mating-plane setback; machine verdict does not establish human service approval. J1/J5 repeated-row rear occlusion notes retained. No approval inferred.

Current board{inv['board_sha256']} remains340footprints/1050pads/333fitted/306SMDtop/0bottom including manual/consigned; preparedr0{r0data['sha256']} remains distinct. PlacementDRC0/499/0; all499new rows and499retained gate rows independently rebound to exact native endpoints; no parity nodes. Prepared/final-routeDRC, placement review, routing import/taps/stitch, final acceptance and release NOT RUN. Compact handoff refused: retained gate older than regenerated board; not deleted/restamped. All641frozen inputs and{len(after)}protected source/method preimages verified unchanged. Complete bounded execution/delivery evidence under{T.relative_to(P)}/outputs. No source repair/retry, children, commit or other-project write. Pod current five-view human approval pending. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.
"""
with (P/'01_docs/journal/placement.md').open('a') as f:f.write(entry)
snapshot=_tree_snapshot(P,ignored=frozenset(a['ignored']));changed=_changed_paths(a['before'],snapshot);scope=writer_scope_receipt(e.writer_scope,changed,before_sha256=_snapshot_sha256(a['before']),after_sha256=_snapshot_sha256(snapshot),protected_paths=tuple(sorted((e.output_path,a['claim']))));assert scope['status']=='PASS',scope;dump(E/'writer-scope.json',scope);dump(E/'changed-paths.json',changed)
# Preserve all changed regular project evidence plus named unchanged authoritative results.
files=set(changed)
for root in ['06_build/pre_route/orientation','06_build/pre_route/model_registration_bundle']:
 files.update(str(x.relative_to(P)) for x in (P/root).rglob('*') if x.is_file())
files.update(['04_kicad/crow_audio_carrier_v1.kicad_pcb','04_kicad/crow_audio_carrier_v1.kicad_sch','06_build/route/r0.kicad_pcb','06_build/drc/pre_route.json','06_build/drc/gate.json','06_build/pre_route/model_registration.json','06_build/pre_route/model_registration.md','06_build/checkpoints/prelayout.json','06_build/checkpoints/prelayout-inputs.json','06_build/checkpoints/schematic.json','06_build/agent_handoff.yaml','03_src/rules/model_registration.yaml','03_src/floorplan.yaml','08_reviews/connector_orientation.yaml'])
for rel in sorted(files):
 q=P/rel
 if not q.is_file():continue
 assert not q.is_symlink(),str(q)
 if rel.startswith('06_build/task_runs/rj45-carrier-placement-after-frontreg1/'):continue
 dest=S/'preserved'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(q,dest)
for q in [T/'envelope.json',H/'TASK.md',H/'current-native-classification.json',H/'normal-renewal-decision.json']:
 dest=S/'authority'/q.name;dest.parent.mkdir(exist_ok=True);shutil.copyfile(q,dest)
evidence=dict(schema=1,subject=j['subject'],domain_result='INCOMPLETE',stopping_gate='[5e] P-ORIENT',stopping_reason='Machine9/9 PASS; approval subject or denominator is stale',runtime=rt,inner_elapsed_s=151.175,command=json.loads((E/'command.json').read_text()),native={k:v for k,v in inv.items() if k not in ['components','pins']},prepared_route=r0data,orientation=dict(subject_sha256=orient['subject_sha256'],machine_verdict=orient['verdict'],machine_refs=len(orient['refs']),human_approved=False,focused_views=orient['evidence'],native_render_count=7,failures=orient['failures'],notes=orient['notes']),classification=dict(file='execution/drc-classification.json',reports=2,rows=998,each_report_counts=dict(violations=0,unconnected_items=499,schematic_parity=0),reuse='Only exact unchanged raw rows and independently reverified native endpoints reuse frozen causes.'),inputs=dict(frozen_count=len(j['input_packet']),protected_count=len(after),unchanged=True),writer_scope=scope,handoff=dict(status='REFUSED',reason='Retained DRC gate older than regenerated board; preserved intact'),not_run=['placement independent review','prepared-r0 DRC','route import','route taps','stitch','final-route DRC','route acceptance','release'],human_orientation=dict(carrier='PENDING',pod='PENDING'),output_dir=str(O))
dump(O/'evidence.json',evidence)
report=f"""# Canonical carrier continuation — INCOMPLETE

The single authorized unchanged-source continuation stopped at **[5e] P-ORIENT**: **machine9/9 PASS**, but existing human approval has a stale subject or denominator. Subprocess rc**1**, **151.175s** inner / **151.314075s** outer, within600s/660s bounds. Registration passed**6/6groups**, with fresh F1–F8**8instances/16overlaps** and five exact cache hits. No retry, source repair, routing import or approval occurred.

Current orientation subject: `{orient['subject_sha256']}`. Owning gate produced**7native renders and11focused views** in `06_build/pre_route/orientation/`. Representatives J1 andJ5 each have top/outside/inside; J9 additionally has both orthogonal profiles. Exact evidence hashes are in evidence.json and the archived receipt. All9connector measurements passed; J9 mating plane is**3.08mm inward** from west edge. Rear occlusion notes for J1/J5 remain binding. Machine geometry and images do not establish human cable/service approval. Current carrier approval and pod five-view human approval remain**PENDING**.

| Subject | PCB SHA-256 | track/via objects |
|---|---|---:|
| Generated canonical placement | `{inv['board_sha256']}` |11|
| Prepared route r0 | `{r0data['sha256']}` |{r0data['track_via_objects']}|

Canonical census is**340footprints/1050pads/333fitted components/306fittedSMD onF.Cu/0onB.Cu**, including manual/consigned. Only H1–H4 andFID1–FID3 are excluded as noncomponents. Preparedr0 also has340footprints/1050pads/306topSMD/0bottom; it is not an accepted route. Component inventory SHA-256 `{inv['component_inventory_sha256']}`; pin inventory `{inv['pin_inventory_sha256']}`. Inventories use sorted compact JSON, preserved in `execution/native-inventory.json`.

Current placement DRC is**0violations/499unconnected/0parity**. Every current row is separately rebound to exact native endpoint UUID, net, pad identity and position; only exact unchanged row/endpoint evidence reuses frozen baseline cause. Retained gate also contains0/499/0 and every row is classified. All**998/998rows** are preserved in `execution/drc-classification.json`; no violation or parity node is omitted. These identify uncompleted placement connections, not congestion. Prepared-r0/final-route DRC was**NOT RUN**.

Placement feasibility7/7, model coverage333/333, pin-map47multipin refs/411physical identities and schematic/checkpoint gates passed. Later independent placement review, routing import/taps/stitch, final route acceptance and release are**NOT RUN**. Compact handoff generation was refused because retained `06_build/drc/gate.json` is older than regenerated board; that blocker remains intact. No DRC refresh or restamp was performed to bypass it.

All**641frozen inputs** and**{len(after)}protected source/method preimages** matched before/after; exact green commit wasf0522d7e1c584221a74e3e68e6b56eac222d318e. Source checkpoint614/614, prelayout11/11 and schematic7/7 passed. Exclusive writer-scope PASS; source and other projects unchanged. An output-local inventory serializer initially rejected KiCad UTF8; converting that field to ordinary string completed read-only evidence capture, without rerunning the canonical driver. Status beacon and placement journal record this stop. Complete raw output, runtime, current views/receipts, native boards and row classifications are archived; every regular member is independently reopened and hash-verified. Delivery checks are separate from engineering INCOMPLETE. **FIRST-ARTICLE-ONLY / DO-NOT-ORDER**.
"""
(O/'report.md').write_text(report)
dump(O/'result.json',dict(subject=j['subject'],checks={v:'PASS' for v in j['completion']['checks']},unresolved=[]))
# Archive exact regular evidence; no archive or manifest inside itself.
archive=O/'evidence.tar.gz';members=[]
with tarfile.open(archive,'w:gz') as tar:
 for root in [E,S/'preserved',S/'authority']:
  for q in sorted(root.rglob('*')):
   if q.is_dir():continue
   assert q.is_file() and not q.is_symlink()
   name=str(q.relative_to(S));tar.add(q,arcname=name,recursive=False);members.append(dict(path=name,size=q.stat().st_size,sha256=sha(q)))
with tarfile.open(archive,'r:gz') as tar:
 seen=set()
 for m in tar:
  assert m.isfile() and m.name not in seen and not m.name.startswith('/') and '..' not in Path(m.name).parts;seen.add(m.name);data=tar.extractfile(m).read();expected=next(v for v in members if v['path']==m.name);assert len(data)==expected['size'] and hashlib.sha256(data).hexdigest()==expected['sha256']
 assert len(seen)==len(members)
dump(O/'evidence-manifest.json',dict(schema=1,archive_sha256=sha(archive),archive_size=archive.stat().st_size,member_count=len(members),members=members))
v=validate_task_outputs(O,e.completion['outputs'],subject=e.subject.to_mapping(),checks=e.completion['checks']);print(json.dumps(dict(archive_sha256=sha(archive),archive_size=archive.stat().st_size,member_count=len(members),protected_count=len(after),changed_count=len(changed),delivery=v)))
