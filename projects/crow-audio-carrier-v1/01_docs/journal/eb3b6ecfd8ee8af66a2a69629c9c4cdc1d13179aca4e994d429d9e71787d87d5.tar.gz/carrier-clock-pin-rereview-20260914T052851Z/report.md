# Fresh corrected carrier clock PIN re-review

review_stage: pre-route
review_kind: pin
reviewer: /root/pod_r3_pin_review (fresh independent read-only reviewer)
review_context: FRESH
completed_at: 2026-09-14T05:32:00Z
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
release_scope: FIRST-ARTICLE-ONLY

board_sha256: 54adf8ef221ff32ad711c234cc25dc60b96c40f64ee981a4404099a57f94bc7d
r0_sha256: d0b28725833cc8c679138f6b98e13ba143eb299da74147903cfcd2059b3361fe
route_yaml_sha256: a1f09e6a54c9429f19461f8166086292651fe1ff718bb5f6e25097a27f5e113c
floorplan_sha256: ec65ec7cc8684b3d2d584063bcf2aec0dce372452ad98eb8e97ce4389080028c
nets_yaml_sha256: af2c146b9269e73435a174fca10924bd0503b1507f07a9bfb48d7a1b346bcfa9
netlist_sha256: 92b0e78a814516676babdb65da635f508808ec1020c0d18c154afef6df6c8a15
raw_netlist_sha256: 7d584ed53401128bce9e723ccf26676d7ac4624159e9d3200a2a6eba71935a18
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: 0e620140855c9c61444f52c02604c51c7feacf73c870d735eb9965a8cfd7ab70
source_test_sha256: 239832b20b3fdba35937941b51cf4258ebf41d5ee03292277840e514391b2543

## Scope

I freshly reviewed the corrected exact live carrier source and exact prepared `r0`, focusing on native completion, net/pad identity, complete-versus-partial ownership, and clock-wave membership for all ten prepared digital terminals. I did not reuse or restamp the rejected review. This is source/placement acceptance only; it is not completed route, final DRC, fabrication, assembly, release, or order approval.

## Result

The correction closes former PIN-01. KiCad native `BuildConnectivity()` on exact `r0` finds the complete digital prepared-net set is exactly:

- `FSYNC_BUF`: `U_CLK.2` reaches `U_CLK.2` and `R_FSYNC.1`.
- `BCLK_BUF`: `U_CLK.5` reaches `U_CLK.5` and `R_BCLK.1`.

Both exact two-pad nets now declare `route.ownership.nets.<net>.owner: prep.seed_stubs`, both are explicitly excluded from prepared generic waves, and neither occurs in the generated clock wave. There is one ownership model for each complete net.

The other eight prepared digital nets are exactly partial: native connectivity reaches only the declared source pad, none declares a complete `prep.seed_stubs` owner, and all eight remain in the generated clock wave. Every source pin exists and its exact `r0` pad net equals its declared source net. No foreign or invented pad connectivity was found.

| Terminal | Net | Native reached pads | Ownership result |
|---|---|---|---|
| `U_CLK.1` | `MCH_MCLK` | `U_CLK.1` | partial; clock wave |
| `U_CLK.2` | `FSYNC_BUF` | `U_CLK.2`, `R_FSYNC.1` | complete; local seed owner; excluded |
| `U_CLK.3` | `MCH_BCLK` | `U_CLK.3` | partial; clock wave |
| `U_CLK.5` | `BCLK_BUF` | `U_CLK.5`, `R_BCLK.1` | complete; local seed owner; excluded |
| `U_CLK.6` | `MCH_FSYNC` | `U_CLK.6` | partial; clock wave |
| `U_CLK.7` | `MCLK_BUF` | `U_CLK.7` | partial; clock wave |
| `U_ADC.24` | `ADC_FSYNC` | `U_ADC.24` | partial; clock wave |
| `U_ADC.25` | `TDM_RAW` | `U_ADC.25` | partial; clock wave |
| `U_ADC.29` | `ADC_BCLK` | `U_ADC.29` | partial; clock wave |
| `U_ADC.34` | `ADC_MCLK` | `U_ADC.34` | partial; clock wave |

The generated clock group contains exactly 11 ADC-clock nets: the 13-net class minus the two complete locally owned nets. This agrees with both native connectivity and the declarations.

## Independent checks

- Final stable `test_digital_launch_source.py`: PASS, 10 tests, 11.370 seconds. The bound final test includes an explicit known-bad canary that removes the `BCLK_BUF` owner and restores wave membership, then requires `completion_owner_errors` to report the exact `U_CLK.5 / BCLK_BUF` complete-owner defect.
- Independent native terminal audit: PASS; complete set exactly `{BCLK_BUF, FSYNC_BUF}`, eight exact partial nets, zero reconciliation errors.
- `route_ownership_preflight.py`: PASS; 0 findings, 221 board nets, 12 owners, 3 explicit net owners.
- `compile_source_prep_authority(...)`: PASS; zero findings across stack, route ownership, and migration checks.
- Stability check: PASS. Route, floorplan, net rules, live board, and prepared `r0` hashes were identical before and after the review checks.

## Verdict

**SOUND** for this exact pre-route PIN/source-placement gate. Former PIN-01 is resolved without changing the reviewed board or prepared copper geometry. Later route, physical, final DRC, fabrication, release, and order gates remain mandatory.

**FIRST-ARTICLE-ONLY / DO-NOT-ORDER.**
