from pathlib import Path
from datetime import datetime, timezone, timedelta
import sys, json, hashlib, shutil, tempfile
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
name='rj45-orientation-integrity-source'
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
review=json.loads((N/'rj45-orientation-scene-review-opened.json').read_text())
assert json.loads((Path(review['envelope']).parent/'attempt.json').read_text())['status']=='PASS'
assert (N/'rj45-orientation-scene-review-closeout-summary.json').is_file()
D=Path(tempfile.mkdtemp(prefix=name+'-'))
shutil.copytree(Path(review['project'])/'input',D/'input')
shutil.copytree(N/'orientation-source-candidate-review',D/'candidate-two')
shutil.copytree(Path(review['output_dir']),D/'independent-review')
shutil.copy2(Path(review['project'])/'preflight.py',D/'preflight.py')
now=datetime.now(timezone.utc);cut=now+timedelta(minutes=20);hard=now+timedelta(minutes=30)
(D/'TASK.md').write_text(f'''# Fresh source handoff: repair the demonstrated receipt-reuse integrity defect

Root owns both live boards and all live repository source. Fresh authoring successor after independent CORRECTION_REQUIRED D-BACK. Frozen input, candidate-two and independent-review are READ_ONLY; work only in allocated scratch. No children, commits, live edits, user approvals, source/model/PCB geometry changes or routing. Read CLAUDE, applicable policy and lifecycle/runtime, exact connector procedure, tests contract and completed independent report. Work cutoff {cut.isoformat()}, hard {hard.isoformat()}, zero replacement. One coherent integrity correction, with routine setup/unit repairs inside this owner/deadline; no alternate rendering/geometry method or search. Original TWO camera/scene production candidates, parser crash, invalid mutation fixtures, aggregate timeout and SWIG/setup spend remain retained. This is the review's newly demonstrated cache-integrity cause, not a reset or third camera/scene candidate.

candidate-two/source_candidate contains seven proposed files, not yet adopted. Overlay them into a working copy of frozen input to establish the exact base under review; candidate-two/beforeimages match live root. Independent review supports explicit native scene resolution, fixed J1/J5 elevated recipes, all11views and machine9/9 on carrier board9c30a147b2d94babd98bc2af4150d4e87270d2efb81a8bd39e88f1b9529a99f4. Native author43.918s and independent44.191s; maintained18/18 tests,6knownbad,1declaredmachinevisibilityblindspot. Complete carrier31primary models/20external files/284external instances verified, not333visiblebody proof. These supported parts MUST remain unchanged in purpose; no further angle, placement, model, tolerances, source part or schema2-policy revision.

Independent hostile-reuse/results.json in review archive reproduces one root cause. Generate real native USB fixture, approve exact existing pixels with renderer forbidden; adding real U_OCCLUDER correctly refuses. Changing ONLY old receipt.subject_sha256 to the newly computed current subject then falsely approves old pixels while retained scene lacks U_OCCLUDER. Mutating only tool_identity, scene, inside_recipes, render_size, measurements, failures or rendered_board_sha256 similarly falsely passes. Review includes13cases with valid exact schema1 reuse and routing-only origin distinction. Reopen/extract safely through manifest and independently understand this counterexample before fixing it.

Own the minimal correction in connector_orientation_gate.py existing_review/reuse and necessary receipt production, plus maintained t1_connector_orientation.py and affected existing procedure/contracts among the seven candidate files. Validate complete cached semantic, producer and measurement payloads against freshly derived expected state; headline subject SHA cannot authenticate contradictory fields. Bind retained scene/camera/tool payload to its claimed subject and producer origin. Verify full machine denominator/results, expected image keys and all hashes. Preserve verifiable rendered-board versus current observed-board distinction on routing-only byte changes. Reject contradictory/malformed/missing fields before approval; never repair them silently into approval or rerender unseen pixels under --approve-reviewer. Use existing native command/receipt evidence where sufficient; no general signing/approval/workflow framework. Reuse remains fast for current exact evidence. Fresh approval stays strict schema1; deliberate schema2 unchanged-semantic pixel compatibility stays intact. No user approval exists for product views.

Add the independent real native stale-scene/relabel counterexample as maintained regression. It MUST go RED against candidate-two and GREEN corrected. Preserve all18existing controls and actual prior-code RED evidence. Test valid exact reuse with renderer forbidden, all contradictory metadata/producer fields, missing/extra schema fields where owned, stale scene despite relabeled digest, material change and routing-only positive origin behavior. Tests should compare physical/input claims independently, not just a new helper's existence. One native product orientation invocation on exact frozen carrier may qualify corrected receipt/producer evidence, using the SAME fixed recipes and unchanged9/9/11denominators; this is validation, not another camera variant. No fresh angle search or broad routed-board parser optimization. Record unmeasured performance scope honestly. No changes to independent signed-Z/mating algorithms; preserve their supported controls.

Use shared pipeline_runtime.run_stage with explicit cwd/environment and /usr/bin/python3 -B, finite per-stage<=300s, full logs/status retained. Read-only missing source/model/test dependencies may be copied from live repo/local library with hashes. Do not write through absolute source paths. Preserve source-before-base, focused integrity delta and combined live-before/full-candidate diff; all seven full proposed postimages must be included so the correction cannot drop prior supported work. Reopen applicable authority/docs/contracts and template sync after changes. Keep all failed setups/results; no manufactured GREEN or retrospective deletion.

Deliver EXACTLY report.md,evidence.json,evidence-manifest.json,evidence.tar.gz,result.json. evidence.domain_result nonempty string describing exact supported/pending status, separate from delivery. Archive source_candidate/<all seven repo-relative files>, exact live beforeimages and candidate-two integrity beforeimages/diff, fresh methods/tests/logs/runtime/native evidence. Do not nest old author/review archives. Manifest archive_sha256/archive_size/member_count/members(path,size,sha256); reopen all regular members and reject traversal, symlinks, duplicates. Exact envelope subject in result plus checks evidence-complete,inputs-verified,review-complete; unresolved[] only complete honest handback. Provided preflight then actual FINAL promptly. Root will seek fresh independent acceptance of the combined candidate before adoption and normal shared-input renewal. FIRST-ARTICLE-ONLY/DO-NOT-ORDER; no source, human or release acceptance inferred.
''')
items=[]
for p in sorted(D.rglob('*')):
    if p.is_file():
        b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(D).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
s=subject_identity('orientation_receipt_integrity_correction',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
e=TaskEnvelope(schema=2,task_id=name,stage_id='KICAD-PLACEMENT',run_id=name,subject=s,executor='agent',execution_class='local',recommended_agent_role='authoring',agent_role='authoring',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']})
o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),agent_id='/root/carrier_rj45_orientation_integrity_source',work_cutoff=cut.isoformat())
(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n')
print(json.dumps(o,indent=2));print(len(items),'frozen inputs')
