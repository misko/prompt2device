from pathlib import Path
import json,hashlib,tarfile,gzip,io,sys,csv
from datetime import datetime,timezone
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
slug,reason=sys.argv[1:3];tag=sys.argv[3] if len(sys.argv)>3 else 'top-only';P=R/'projects'/slug;payload={}
guards=['06_build/checkpoints/prelayout-inputs.json','06_build/checkpoints/prelayout.json','06_build/checkpoints/schematic.json','06_build/sourcing/prelayout_request.json','06_build/sourcing/prelayout_response.csv']
assert not (P/'06_build/sourcing/prelayout_receipt.json').exists(),'Authenticated receipt requires owning review'
req=json.loads((P/guards[3]).read_text());rows=list(csv.DictReader((P/guards[4]).open()))
sys.path.insert(0,str(R/'projects/crow-roof-array-v1/03_src'))
from prelayout_resume_gate import blank_response_matches_request
assert blank_response_matches_request(P/guards[4],P/guards[3],'source-backtrack'), 'Preserve populated operator evidence, do not retire it' 
for rel in guards:
 assert (P/rel).is_file() and not (P/rel).is_symlink();payload[rel]=(P/rel).read_bytes()
for folder in ['03_tscircuit/src','03_tscircuit/build','06_build/netlists','06_build/sourcing']:
 for p in sorted((P/folder).glob('*')):
  if p.is_file() and not p.is_symlink():payload[p.relative_to(P).as_posix()]=p.read_bytes()
for p in (P/'04_kicad').iterdir():
 if p.is_file() and p.suffix in ['.kicad_sch','.kicad_pcb','.kicad_pro','.kicad_dru']:payload[p.relative_to(P).as_posix()]=p.read_bytes()
for kind in ['topology','schematic_render']:
 p=P/'08_reviews'/f'pre-route_{kind}.md';payload[p.relative_to(P).as_posix()]=p.read_bytes()
payload['06_build/build_provenance.json']=(P/'06_build/build_provenance.json').read_bytes()
record={'project':slug,'reason':reason,'created_at':datetime.now(timezone.utc).isoformat(),'guards':[{'path':x,'size':len(payload[x]),'sha256':hashlib.sha256(payload[x]).hexdigest()} for x in guards],'claim':'Preceding rejected top-only schematic/checkpoint subject, older adopted schematic reports and native snapshot preserved before ordinary renewal after exact locator-policy source acceptance. No older report accepts the rejected or corrected subject. Only five listed blank-response restart guards retired; no native or release acceptance.'}
payload['RESTART.json']=(json.dumps(record,indent=2)+'\n').encode();payload['MANIFEST.json']=(json.dumps({'files':[{'path':k,'size':len(v),'sha256':hashlib.sha256(v).hexdigest()} for k,v in sorted(payload.items())]},indent=2)+'\n').encode()
tmp=N/(slug+'-'+tag+'-restart.tmp')
with tmp.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for k,v in sorted(payload.items()):
    m=tarfile.TarInfo(k);m.size=len(v);m.mode=0o644;t.addfile(m,io.BytesIO(v))
with tarfile.open(tmp,'r:gz') as t:
 ms=t.getmembers();assert len(ms)==len(payload)==len({m.name for m in ms})
 for m in ms:assert m.isfile() and t.extractfile(m).read()==payload[m.name]
b=tmp.read_bytes();h=hashlib.sha256(b).hexdigest();home=P/'01_docs/journal';out=home/(h+'.tar.gz');assert not out.exists();out.write_bytes(b)
with (home/'contracts.md').open('a') as f:f.write(f'\n## Allowed {slug} source renewal checkpoint\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Exact preceding schematic/native subjects, accepted reviews and five frozen guards before ordinary source renewal; no acceptance extension |\n\nAudit: SHA-256 equals filename; {len(b)}bytes/{len(payload)}regular members including MANIFEST, all reopened; RESTART binds five retired guard preimages.\n')
for rel in guards:assert (P/rel).read_bytes()==payload[rel]
for rel in guards:(P/rel).unlink()
summary={'archive':str(out),'sha256':h,'size':len(b),'regular_members':len(payload),'retired':guards,**record};(N/(slug+'-'+tag+'-restart-summary.json')).write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
