from pathlib import Path
import json,hashlib,yaml,difflib,shutil
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;D=N/'locator-policy-fix';D.mkdir(exist_ok=False)
rel='projects/crow-audio-carrier-v1/03_src/rules/policy_waivers.yaml';before=(R/rel).read_text();after=before
for ref in ['R_ADC_PD1P','R_PWR_BOT']:
 assert after.count('  - '+ref+'\n')==1;after=after.replace('  - '+ref+'\n','')
assert after.count("    output: '25'\n    budget: == 25")==1
after=after.replace("    output: '25'\n    budget: == 25","    output: '23'\n    budget: == 23")
b=yaml.safe_load(before);a=yaml.safe_load(after);expect=json.loads(json.dumps(b));selected=[x for x in expect if x['id']=='P-SILK-REF'];assert len(selected)==1
selected[0]['refs']=[x for x in selected[0]['refs'] if x not in ['R_ADC_PD1P','R_PWR_BOT']];selected[0]['evidence'][0]['output']='23';selected[0]['evidence'][0]['budget']='== 23';assert a==expect
for name,text in [('before.yaml',before),('after.yaml',after)]: (D/name).write_text(text)
(D/'source.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
m={'path':rel,'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest(),'removed_refs':['R_ADC_PD1P','R_PWR_BOT'],'remaining_refs':selected[0]['refs'],'scope':'One source metadata file only; exact23ref waiver/locator set and strict ==23 expected evidence. No new exception, waiver effectiveness, renderer verdict, source geometry, generated output or threshold relaxation.'};(D/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
p=D/'work'/'project'
for rel2 in ['03_src/rules/assembly_locator.yaml','03_src/route.yaml','08_reviews/pre-route_render.md']:
 f=R/'projects/crow-audio-carrier-v1'/rel2;t=p/rel2;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,t)
(p/'03_src/rules/policy_waivers.yaml').write_text(after)
print(json.dumps(m,indent=2))
