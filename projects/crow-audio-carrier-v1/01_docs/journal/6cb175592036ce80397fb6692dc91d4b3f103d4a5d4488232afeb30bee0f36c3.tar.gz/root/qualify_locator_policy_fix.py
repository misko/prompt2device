from pathlib import Path
import sys,json,hashlib,yaml
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;D=N/'locator-policy-fix';P=D/'work/project'
sys.path.insert(0,str(R/'skills/jlcpcb-fab/scripts'))
import assembly_locator_check as g
S=Path('/tmp/rj45-coherent-top-only-source1-dz0edoky/06_build/task_runs/rj45-coherent-top-only-source1/scratch');board=S/'work/projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb';export=S/'nongeometry-followup/assembly-export';config=P/'03_src/rules/assembly_locator.yaml';target={x['ref'] for x in yaml.safe_load(config.read_text())['exceptions']};assert len(target)==23
results={}
for version in ['before','after']:
 src=D/(version+'.yaml');refs=g.waiver_refs(src);results[version]={'waiver_count':len(refs),'locator_count':len(target),'extra':sorted(refs-target),'missing':sorted(target-refs),'set_equal':refs==target}
assert results['before']['extra']==['R_ADC_PD1P','R_PWR_BOT'] and not results['before']['set_equal'];assert results['after']['set_equal']
results['identity']=g.check(board,export/'bom.csv',export/'cpl.csv',config,export);assert results['identity']['exceptions']==results['identity']['pages']==23
policy=P/'03_src/rules/policy_waivers.yaml';positive=policy.read_bytes()
try:
 policy.write_bytes((D/'before.yaml').read_bytes())
 try:g.project_check(P,board=board,out=export)
 except ValueError as exc:results['original_project_error']=str(exc)
 else:raise AssertionError('Original mismatched policy unexpectedly passed')
 assert results['original_project_error']=='policy waiver/locator exception sets differ'
finally:policy.write_bytes(positive)
try:g.project_check(P,board=board,out=export)
except ValueError as exc:results['corrected_project_error']=str(exc)
else:raise AssertionError('Old visual receipt unexpectedly accepted new candidate')
assert 'set' not in results['corrected_project_error'] and ('render' in results['corrected_project_error'] or 'stale' in results['corrected_project_error'] or 'visual' in results['corrected_project_error'])
results['board_sha256']=g.digest(board);assert results['board_sha256']=='01ed49549238189a80d64e24a61832d6e9ca8826fd5bf107137243d2ea9b4240'
results['scope']='Exact23 source/native/bundle identities pass; original policy rejects at equality. Corrected full project check still rejects stale independent visual review, as required. No waiver effectiveness or placement acceptance.'
(D/'qualification.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
