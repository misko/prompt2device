from pathlib import Path
import json,hashlib
from datetime import datetime,timezone
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;name='rj45-locator-policy-source-review1'
m=json.loads((N/(name+'-opened.json')).read_text());c=json.loads((N/(name+'-closeout-summary.json')).read_text());e=json.loads((Path(m['output_dir'])/'evidence.json').read_text());env=json.loads(Path(m['envelope']).read_text());assert c['delivery_status']=='PASS' and c['engineering_verdict']==e['verdict']=='SOUND' and e['subject']==env['subject'];assert hashlib.sha256(Path(c['archive']).read_bytes()).hexdigest()==c['sha256']
for x in env['input_packet']:
 p=Path(m['project'])/x['path'];b=p.read_bytes();assert not p.is_symlink() and len(b)==x['size'] and hashlib.sha256(b).hexdigest()==x['sha256']
accepted=e['accepted_hash_manifest'];assert accepted['file_count']==len(accepted['files'])==1;x=accepted['files'][0];proposal=json.loads((N/'locator-policy-fix/manifest.json').read_text());assert all(x[k]==proposal[k] for k in ['path','before_sha256','after_sha256']);assert x['path']=='projects/crow-audio-carrier-v1/03_src/rules/policy_waivers.yaml'
p=R/x['path'];before=p.read_bytes();after=(N/'locator-policy-fix/after.yaml').read_bytes();assert hashlib.sha256(before).hexdigest()==x['before_sha256'] and hashlib.sha256(after).hexdigest()==x['after_sha256'];p.write_bytes(after);assert p.read_bytes()==after
record={'created_at':datetime.now(timezone.utc).isoformat(),'review':c,'accepted':x,'scope':'Exactone-file independently accepted carrier metadata. No native/pod/shared source edits or waiver effectiveness; ordinarycarrier source/schematicrenewal owed.'};(N/'locator-policy-source-adoption.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
