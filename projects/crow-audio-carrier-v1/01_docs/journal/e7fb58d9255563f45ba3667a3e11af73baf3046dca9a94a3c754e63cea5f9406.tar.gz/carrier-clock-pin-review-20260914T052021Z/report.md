# Fresh carrier clock PIN / prepared-terminal review

review_stage: pre-route
review_kind: pin
reviewer: /root/pod_r3_pin_review (fresh independent read-only reviewer)
review_context: FRESH
completed_at: 2026-09-14T05:25:43Z
design_verdict: DEFECTIVE
order_verdict: DO-NOT-ORDER
release_scope: FIRST-ARTICLE-ONLY

board_sha256: 54adf8ef221ff32ad711c234cc25dc60b96c40f64ee981a4404099a57f94bc7d
r0_sha256: d0b28725833cc8c679138f6b98e13ba143eb299da74147903cfcd2059b3361fe
route_yaml_sha256: de4a642b465ac3f626ef8c41bd350ca9dcceb3a7028b82f652b7e9b305d577c3
floorplan_sha256: ec65ec7cc8684b3d2d584063bcf2aec0dce372452ad98eb8e97ce4389080028c
nets_yaml_sha256: af2c146b9269e73435a174fca10924bd0503b1507f07a9bfb48d7a1b346bcfa9
netlist_sha256: 92b0e78a814516676babdb65da635f508808ec1020c0d18c154afef6df6c8a15
raw_netlist_sha256: 7d584ed53401128bce9e723ccf26676d7ac4624159e9d3200a2a6eba71935a18
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: 63e01fb8049711cda8fa2b66234eec994b86bbf39271ceee28108d9798792c20

## Scope and boundary

I independently reviewed the current live carrier board, prepared `r0`, route/floor/rule sources, canonical netlist, parts, and exact current routing-policy digest. The focus was the ten declared digital prepared terminals, especially the newly added `MCH_MCLK` launch at `U_CLK.1` and `BCLK_BUF` launch at `U_CLK.5`, their physical pad/net attachment, source geometry, and the partition between locally completed nets and generic-wave nets.

This is a pre-route source/placement review only. It is not completed-route, final DRC, fabrication, assembly, release, or order approval.

## Blocking finding

### PIN-01 — `BCLK_BUF` is physically complete but declared as a partial clock-wave net

Severity: blocking

The prepared seed for `U_CLK.5 / BCLK_BUF` is:

- 0.18 mm F.Cu: `(148.4,59.75) -> (149.1,59.75)`
- 0.18 mm F.Cu: `(149.1,59.75) -> (149.55,60.0)`
- 0.36 mm F.Cu: `(149.55,60.0) -> (149.99,60.0)`

The exact canonical netlist contains only two `BCLK_BUF` nodes: `U_CLK.5` and `R_BCLK.1`. The last seed endpoint is exactly the `R_BCLK.1` pad center `(149.99,60.0)`. KiCad native connectivity on exact prepared `r0` reaches both `U_CLK.5` and `R_BCLK.1`; therefore this seed completes the whole net.

Despite that physical fact, `BCLK_BUF` has no explicit `prep.seed_stubs` complete-net owner and remains in `prep.waves.groups.clocks`. The source test labels all digital seeds except `FSYNC_BUF` as partial without checking which pads the realized prepared copper reaches. This leaves a complete local seed assigned to a later generic routing wave, violating the requested partial-versus-complete ownership partition.

No unintended electrical node was connected: the two reached pads are the exact intended two nodes of `BCLK_BUF`. The defect is conflicting/stale routing ownership, not invented electrical connectivity.

The clean correction is to declare `BCLK_BUF` a complete local `prep.seed_stubs` owner and exclude it from the clock wave, then strengthen the test to derive the exact completion set from native prepared-board connectivity (`FSYNC_BUF` and `BCLK_BUF`) and reject any complete two-pad seed that remains wave-owned. If the design intent is for `BCLK_BUF` to remain partial, shorten its last segment so it provably does not contact `R_BCLK.1`, retain a legal 0.36 mm continuation witness, and rerun this review.

## Ten-terminal audit

| Prepared terminal | Net | Native reached pads on exact `r0` | Classification | Clock wave |
|---|---|---|---|---|
| `U_CLK.1` | `MCH_MCLK` | `U_CLK.1` | partial, correct | included |
| `U_CLK.2` | `FSYNC_BUF` | `U_CLK.2`, `R_FSYNC.1` | complete, explicitly owned | excluded |
| `U_CLK.3` | `MCH_BCLK` | `U_CLK.3` | partial, correct | included |
| `U_CLK.5` | `BCLK_BUF` | `U_CLK.5`, `R_BCLK.1` | **complete, undeclared** | **included: defect** |
| `U_CLK.6` | `MCH_FSYNC` | `U_CLK.6` | partial, correct | included |
| `U_CLK.7` | `MCLK_BUF` | `U_CLK.7` | partial, correct | included |
| `U_ADC.24` | `ADC_FSYNC` | `U_ADC.24` | partial, correct | included |
| `U_ADC.25` | `TDM_RAW` | `U_ADC.25` | partial, correct | included |
| `U_ADC.29` | `ADC_BCLK` | `U_ADC.29` | partial, correct | included |
| `U_ADC.34` | `ADC_MCLK` | `U_ADC.34` | partial, correct | included |

All ten source pins exist on exact `r0`, and each pad carries the declared source net. The exact `MCH_MCLK` launch has two 0.18 mm escape edges followed by a 0.36 mm continuation. Its native full-capsule checks found no foreign-pad, other-seed, hole, via, keepout, or edge collision. Its nearest foreign-pad gaps for its three edges were 0.2350, 0.2659, and 0.5285 mm under their applicable scoped geometry.

The exact `BCLK_BUF` launch likewise has two 0.18 mm escape edges and one 0.36 mm edge. Its nearest foreign-pad gaps were 0.2350, 0.2659, and 0.5700 mm. Geometry is sound; the final segment deliberately lands on same-net `R_BCLK.1`, which establishes the ownership defect above.

Across all ten terminals, the independent geometry audit expanded the declared polylines to 24 physical segment edges and performed 38,799 native shape checks against 985 native copper pads, 159 holes, other seeds, keepouts, vias, and the board edge. It found zero geometric failures and zero source-budget errors. Every remaining ordinary ADC-clock endpoint had a native 0.36 mm width / 0.25 mm clearance launch witness.

All 309 footprints marked SMD are on `F.Cu` in both the exact source board and exact prepared board; neither board contains a back-side footprint. Source and prepared population are each 340 footprints.

## Independent checks and checker gap

- `test_digital_launch_source.py`: PASS, 10 tests, 8.693 s. This suite currently misses PIN-01 because `test_bulk_class_and_partial_owner_partition_stay_exact` computes the alleged partial set from source pin membership and subtracts only `FSYNC_BUF`; it does not derive completion from native connectivity.
- `route_ownership_preflight.py`: PASS, 0 findings, 221 board nets, 11 owners, 3 explicit net owners. It audits declarations and likewise does not reconcile declared ownership with realized seed reach.
- `compile_source_prep_authority(...)`: PASS with zero findings. Its source-only ownership model does not inspect prepared-board native connectivity, so it also cannot disprove PIN-01.
- Independent KiCad `BuildConnectivity()` terminal audit: `BCLK_BUF` reaches exactly `U_CLK.5`, all three seed tracks, and `R_BCLK.1`; `FSYNC_BUF` is the other completed digital seed. The other eight digital seeds reach only their declared source pad.

The passing automated checks are useful but are not sufficient evidence for this terminal-ownership question. Native connectivity is the controlling physical observation.

## Verdict

**DEFECTIVE.** Do not accept this PIN gate, continue to route release, fabricate, or order from these exact bytes until `BCLK_BUF` has one ownership model consistent with its realized copper and a fresh independent PIN review binds the correction.

**FIRST-ARTICLE-ONLY / DO-NOT-ORDER.**
