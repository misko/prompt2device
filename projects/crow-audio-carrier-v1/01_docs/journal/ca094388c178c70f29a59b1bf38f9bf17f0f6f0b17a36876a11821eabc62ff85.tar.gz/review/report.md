review_stage: pre-route
review_kind: layout
reviewer: fresh independent agent /root/rj45_carrier_layout_approved
context: FRESH
design_verdict: INCOMPLETE
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7
prepared_board_sha256: b75acca754b864d8c69df51b8343f21cf01ec9640325216c5e96f466f83861b1

This is an honest partial full-board pre-route review of the exact frozen native placement and deterministic r0. It is not full-board SOUND and grants no routing or release acceptance. No live source or board was edited. Both immutable board hashes and all565 packet inputs are verified; the exact envelope subject is in evidence.json.

The native placement has zero full-severity/refill/parity physical DRC violations,499 expected pre-route opens and zero parity findings. r0 has12 starved GND thermals,39 dangling tracks,5 dangling vias,469 opens and zero parity findings. The12 thermal findings need preparation/return disposition. No native placement move is demonstrated necessary. The dangling launches and ordinary opens are individually retained routing work, not automatically placement defects.

Coverage and native measurements

340 footprints reconcile to333 fitted (300 automatic,33 manual) and7 board-only (FID1–3,H1–4), with0 DNP. All333 fitted source anchors, rotations and sides match, including16 bottom parts.21 explicit source pad/net assertions pass.1050 physical pads reconcile to988 true copper,21 NPTH and41 noncopper paste apertures; the pad-separation tool's1009 candidates include NPTH and are not the copper denominator.

The independent expansion measures446 pin/pair budgets with0 unresolved rules. The frozen placement policy tool separately reports62 keep_short+353 adjacency=415 declared budgets,20/20 scoped layout/precedent dossiers and all5 phase-placement rows PASS. Its bounding-box metric differs from native effective-shape measurement at U_PWR.6→R_PWR_PU.2:2.472473mm source bbox versus2.511520mm actual shapes against2.500mm. The exact endpoints are U_PWR.6(33.6,56.2),R_PWR_PU.2(32.4,53.39). Severity:warning; next owner:source layout-rule owner. This0.011520mm excess is a metric discrepancy, not independently demonstrated electrical malfunction.

Native pad separation and foreign-paste checks pass. Placement gates find0 fitted courtyard collisions/foreign-pad intrusions, minimum pad-to-outline1.32mm at J11.11 against0.15mm, and the evaluated escape corridor demand/capacity17/257. The finite P-LAND procedure validates709/709 graded copper-pad launches, with42 floorless NC pads,234 nominal-pour eligible pads and3 no-net pads;0 unreached and0 failed witnesses. Its48 directions,1mm reach, <=37 native-admitted bbox starts and declared widths<=2mm prove finite individual pad launch witnesses, not simultaneous/global routability. Nominal pours alone prove no connectivity.

Native placement has0 tracks/11 thermal vias; r0 has267 tracks/29 vias. All269 declared segment rows match267 unique native tracks (two repeated source rows). RJ45 source coordinates quantize by at most0.000707mm at an endpoint; the32 bottom-layer segments form16 declared connector/clamp launches. All subnominal emitted track capsules fit at least one applicable source-owned floor area. Per-net widths,lengths,UUIDs and area matches are in copper-check-quantized.json. The five fully prep-owned local nets LDO_A_FILT,FSYNC_BUF,LDO_D_FILT,VMID1,VMID2 have no DRC opens. All other open-net owners resolve to source route waves or GND zones.

Mechanical placement: all333 fitted courtyards were compared with all4 mounting-head3.2mm radii (1332 comparisons); minimum nominal margin2.423704mm,F1→H1. All16 bottom fitted courtyards were checked against every THT pad/hole effective shape. U_ESD1–8 nearest opposite-side RJ45 land gap0.405mm;F1–8 minimum0.415mm. All9 edge service mouths have measured nominal exposure: J1–8=0.500mm,J9=0.920mm. RJ45 pitch32mm minus15mm nominal body width leaves17mm nominal body-to-body space. These are CAD dimensions, not tolerance, solder-fillet/tail, boot/latch, fingers or service-tool clearance qualification.333/333 fitted model files resolve; model registration and independent render acceptance are not inferred from file coverage.

Primary layout figures actually inspected: AP63205 datasheet p15 Fig25; LT3041 pp22,26 and DC3158A UG2059 pp5–6; Cirrus CS530x layout guide pp10–12; OPA2320 p28; TPD2E2U06 pp11–12; TMUX28xx p24; Wurth615008160221 drawing p1; Molex436501000 drawing p1. Exact PDF hashes,page numbers and all14 inspected page images are archived. The reference patterns support local VIN/buck loops, separate LT3041 Kelvin sense/quiet returns, ADC-local reference decoupling, local op-amp feedback/bypass, and connector-first clamp placement. The AP63205's2oz reference recommendation is not silently attributed to this4-layer35um-copper prototype; thermal/current qualification remains owed. No borrowed diagram proves this board's routed performance.

For LT3041 specifically, native shape contacts confirm all3 OUTS0.2mm segments touch only U_LDO.12,their neighboring sense segments and C_LDO_OUT.1. The5 source quiet GND stem segments and C_LDO_NR4.2/C_LDO_NR5.2/R_LDO_SET.2 have zero direct refilled F.Cu GND-polygon intersections; their native pad/track contacts form the intended tree ending at C_LDO_OUT.2. A complete connected-component list was also retained, explicitly not mistaken for direct contact or branch dominance. Four native GND zones occupy F.Cu,B.Cu,In1.Cu,In2.Cu respectively;In1.Cu has0 tracks. Native GetLayerName on a zone misreported F.Cu in the preliminary census; native-zone-layers.json using GetLayerSet is authoritative.

Current preparation findings

Each following error is GND,F.Cu,required2 thermal spokes but actual1. Next owner for each:carrier source/preparation owner. Author a return/thermal correction or justified source disposition, then repeat native refill DRC before preparation promotion. Coordinates are pad centers in mm.

| Ref.pad | X,Y | Pad UUID |
|---|---|---|
| C_ADC_CM4P.2 | 102.830000, 66.599999 | `1163da6d-c4e0-4655-905b-e513a6274aed` |
| C_ISO4.2 | 139.630000, 53.300000 | `ea24c583-3980-4bbf-9fe2-3be44e3061d0` |
| C_ISO7.2 | 101.370000, 86.700000 | `ea3a91e2-dd89-43a8-b8b8-49f3c1bab73f` |
| C_ISO6.2 | 69.370000, 86.700000 | `eb0f228f-9040-4318-8daf-e88453826f62` |
| U_LDO_EN.3 | 55.962500, 71.750000 | `603d2b76-3c13-4edc-b403-c9b6c6af1a58` |
| C_ADC_CM4N.2 | 102.830000, 65.300000 | `a4469d2f-8cc5-42f2-87b4-42b41ca21249` |
| C_ISO1.2 | 43.630000, 53.300000 | `ac101d87-06cf-4d32-8dc7-20cfb2576b1d` |
| C_ISO5.2 | 37.370000, 86.700000 | `03be0c19-3ac9-49c7-9dd9-9af17a1bed8c` |
| C_ISO8.2 | 133.370000, 86.700000 | `eb19f65e-f37e-401f-8dbf-c45de7f0dae1` |
| C_VDDA1_10N.2 | 90.520000, 68.500000 | `0aebe923-80d1-4bae-b48f-b1aaba2fb3ec` |
| C_ISO3.2 | 107.630000, 53.300000 | `71885917-c252-4006-9b2a-218184d1ca0c` |
| C_ISO2.2 | 75.630000, 53.300000 | `592f914e-d009-4af4-83c6-42b03a632ebd` |

The remaining r0 ground opens are R_PWR_BOT.2(29.175,56.7)→U_PWR.2(32.4,56.7), and U_AUDIO.2(32.4,61.1)→the F.Cu GND zone. Classification:pending ground return; next owner:route/GND-return owner. All44 dangling launches are severity-info pending route work with exact native item UUID,net,width,coordinate,source-seed match and next owner individually recorded. Native499+r0 469 opens and all56 violations total1024 individually classified current records in endpoint-classification-final.json/evidence.json;0 unmapped endpoints. No generalized congestion claim substitutes for these records.

Initial missing-library diagnostics are also retained:398 environment-only footprint-library rows resolve after installing the allocated fp-lib-table against frozen custom/installed standard libraries. Of the initial1422 rows,1005 link to identical final records,19 separately classified alternative ratsnest edges remain expected pre-route work. A changed DRC edge selection is not claimed to be a newly routed connection. No library warning, open or violation was silently dropped.

Label policy applicability

Severity:warning/policy-model discrepancy; next owner:root/source policy owner. Frozen design-policies.md P5/P-SILK-OWN requires a label nearer its member than any other in the J/F/TP family. Frozen policy_audit.py lines1356–1423 builds one family with no footprint-side/text-side filter. Thus all8 front CH labels fail that literal mixed-side anchor metric against their bottom fuse. No P-SILK-OWN waiver is present. The side-aware diagnostic below is not adopted as a substitute governing rule.

| Jack | Actual front label/XY mm | Literal rival | Mixed-side lead mm | Same-component-side lead mm |
|---|---|---|---|---|
| J1 | CH1 at [40.5, 34.5] | F1 | -0.881620 | 19.083687 |
| J2 | CH2 at [72.5, 34.5] | F2 | -0.881620 | 19.083687 |
| J3 | CH3 at [104.5, 34.5] | F3 | -0.881620 | 19.083687 |
| J4 | CH4 at [136.5, 34.5] | F4 | -0.881619 | 16.190962 |
| J5 | CH5 at [40.5, 105.5] | F5 | -0.881620 | 19.859878 |
| J6 | CH6 at [72.5, 105.5] | F6 | -0.881620 | 19.083687 |
| J7 | CH7 at [104.5, 105.5] | F7 | -0.881620 | 19.083687 |
| J8 | CH8 at [136.5, 105.5] | F8 | -0.881620 | 19.083687 |

Each CH label is9.741643mm from its own jack anchor and8.860023mm from the corresponding bottom fuse anchor. All same-side leads are positive. Native front Fab/silk whole-board and J1 detail were inspected: the channel label lies beneath its jack and the fuse is explicitly labeled F# BOT. Actual front-side identity ambiguity is not substantiated by this review. Resolve the authored policy's cross-side applicability explicitly; no automatic source move or waiver is adopted. All25 hidden fitted references exactly match the proposed P-SILK-REF set; their independent current locator/render effectiveness is not accepted here.

Exact uncovered scope causing INCOMPLETE

1. Primary application/layout applicability was completed for7/20 policy-scoped selected families.13 remain incompletely reviewed: AO3401A, AO3400A, 74LVC1G17GV,125, TPS389001DSER, DMP6023LFG-13, 74LVC1G14GV,125, SN74LVC1G125DBVR, SN74LVC1G123DCTR, 2N7002K-7, XGL4020-332MEC, TPS3839K33DBZR, TMM-106-01-L-D, SN74LVC3G34DCUR. Their encoded placement budgets were measured; that does not substitute for the independent primary read. Evidence records every affected native ref/coordinate/UUID.
2. Exhaustive filled ADC GND_A/GND_D/paddle isolation, FILT feed-after-bulk branch ordering and VMID nearest-return dominance were not independently proved. Cirrus primary figures and local budgets were checked, but connected net names and closed prep-owned nets do not prove those properties. Next owner:fresh carrier layout reviewer.
3. P-ESC/P-TIER package recomputation,P-MOD,P-PINMAP and P-FACT were not independently completed in this pass. Current locator/render waiver effectiveness and model registration remain separate exact-artifact gates. The phase-placement tool covers only5 rows and is not presented as a full policy pass.

These are review-coverage gaps, not newly invented physical measurement prerequisites. Existing first-article physical qualifications remain separate. Cat6A/RJ45 carries custom analog/DC, not Ethernet or PoE; use power-off mating. DO-NOT-ORDER persists. Final route/current/thermal/SI/assembly/release reviews are not granted by r0 preparation.

Evidence handling

All engineering commands were finite direct-argv subprocesses through run.py and shared pipeline_runtime.run_stage, with actual raw stdout/stderr and runtime records retained. Tool console truncation does not truncate archived raw logs. Earlier failed/refined scripts/results remain diagnostic history; named final measurement files govern. The missing release_index import was resolved using a root-authorized tool-only supplement SHA256 ec8e8294549984cc37efa48563244ffcf8e64b4289fd8aa84901915dd918e1dc,size10017; original packet bytes were unchanged. This supplement is separately hash-bound in evidence.json and retained in the archive. No historical review/locator/twin is physical authority.

The archive contains actual review methods,measurements,raw logs,runtime receipts and inspected primary figures, excluding unchanged board/project working copies and any nested archives. The manifest reopens and hashes every regular archive member. Delivery PASS means a complete honest INCOMPLETE handback, not design acceptance. Delivery-only packaging/preflight logs remain in allocated scratch to avoid recursively archiving the archive's own validation.
