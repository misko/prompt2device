import json,hashlib,tarfile,io
from pathlib import Path
s=Path(__file__).parent;o=s.parent/'outputs';e=json.loads((s.parent/'envelope.json').read_text())
doc=json.loads((o/'evidence.json').read_text());doc['frozen_verification']=json.loads((s/'frozen-after.json').read_text());(o/'evidence.json').write_text(json.dumps(doc,indent=2)+'\n')
archive=o/'evidence.tar.gz';members=[]
inputs=[(x,'scratch/'+x.relative_to(s).as_posix())for x in sorted(s.rglob('*'))if x.is_file() and x.name not in ['package.log','package.runtime.json','final-preflight.log','final-preflight.runtime.json']]+[(o/'report.md','report.md'),(o/'evidence.json','evidence.json')]
assert len({name for _,name in inputs})==len(inputs)
with tarfile.open(archive,'w:gz')as tar:
 for path,name in inputs:
  assert not path.is_symlink() and not name.startswith('/') and '..'not in Path(name).parts
  data=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data));members.append({'path':name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(archive,'r:gz')as tar:
 got=tar.getmembers();assert len(got)==len(members)
 for actual,expected in zip(got,members):
  assert actual.isfile()and actual.name==expected['path'];data=tar.extractfile(actual).read();assert len(data)==expected['size']and hashlib.sha256(data).hexdigest()==expected['sha256']
manifest={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_size':archive.stat().st_size,'member_count':len(members),'members':members};(o/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
result={'subject':e['subject'],'checks':{k:'PASS'for k in e['completion']['checks']},'unresolved':[]};(o/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items()if k!='members'}));print('Five output files complete; engineering verdict DEFECTIVE remains unchanged.')
