review_stage: pre-route
review_kind: schematic_render
reviewer: Codex independent agent /root/carrier_rj45_native_pod_readability
context: FRESH
date: 2026-09-12
design_verdict: DEFECTIVE
order_verdict: DO-NOT-ORDER
subject_raw_sha256: b86fe67be8d15068c2906e20ac95692163f93227209a23518004b50d0210a006
subject_semantic_sha256: fe756d7ee198124a96df58bd6e8bfbee7a0ae9b5c9e2827be63b5e22cd7b89f9
netlist_sha256: e62d945184878ab94bc3a88d887c14219f2d11c1f360d6b921364460c77f35ea
parts_sha256: e237c40548327870332db7b7abf874f0e8ab91b4e12db0c58592ba909dcf1b59
design_rules_sha256: a2d363563c93cf132d738bc9808f3cecad7b0c2e3f383623da3d1e533f261d10
schematic_pdf_sha256: 464086bce5e514c1c1804080475830fca1a074dcbd5be579ad1afb3f3a4fead4
exact_netlist_sha256: 5f77a5458cf7e519c5e8d969421a9f647cb719e51c9640d0f3616870e6d62a24
circuit_json_sha256: 508e15679ad4c2941f0e871ce9b0c375b6da71b800c3ac836652a6416229b8b7
kicad_schematic_sha256: b1137de6596731ac1a7b2defca32af2967dd6b14526a43a8a79644b1a51c02b1

P1 POD-RJ45-READ-001 — S11 wire-over-text violation at PDF page 4, U1 reference. The horizontal green GND wire crosses the U1 glyphs within x411.129–419.352, y285.555–294.150 pt. Reproducible close-up: scratch/u1-crop-4.png. Repair and fresh readability review are required before this artifact can receive SOUND.

Reviewed actual Poppler-rendered images of pages 1–4, then 300/360 dpi J1/U1 close-ups and 240 dpi U1/U2/U3 details. The extracted text and independent S-expression/CircuitJSON analysis supplement, rather than replace, visual review. No historical Micro-Fit review is used as acceptance of these bytes.

Page 1: 7/7 components; J1 pin numbers 1/3/7 on 12V_POD, 2/6/8 on GND, 5 on AUDIO_P, 4 on AUDIO_N, and shell 9/10 on POD_SHIELD are individually readable. The latter net contains only J1.9 and J1.10 in the native export. F1 IN/OUT and both D1/D2 K/A polarities are legible; the fused-to-D1-anode wire and protected-rail TVS/bleed loop can be followed. TP1/TP2 labels are clear. J1-to-F1 continuity uses an explicit matching net label.

Page 2: 11/11 components; all U2 9/9 pins are legible, including NC3, DNC7, EP_GND9 and the IN8/EN5 tie. C1/C2 sit adjacent to U2; C5/C6 show output bypass, R1/R2 and C3 show feedback, and C4 NR/SS plus TP7 ground are traceable. Crossings use jump arcs. The native four no-connect markers include U2.3/U2.7; the PDF uses visibly open, named NC/DNC pins.

Page 3: 10/10 components; the R3/C7 bias filter, R4 and MK1 capsule POS/NEG, R6/R7 half-rail divider, C9, C8 signal coupling, R5 bias and TP4 are readable. Signal net labels explicitly continue to the output page. These capacitors are ceramic; no electrolytic polarity mark is expected.

Page 4: 12/12 components; U1 14/14 and U3 5/5 pin numbers/functions are readable in the retained enlarged detail. U1A reference buffer and spare U1D local follower, U1B preamp and U1C polarity restoration, feedback resistor values, both 100-ohm output legs and U3 clamp nodes are identifiable. U3 NC1/NC2 are visibly open. C10/C11 sit beside U1, but their GND wire crosses the U1 reference. OPA1679IDR below the reference is clear. This single confirmed S11 collision is enough to reject the current readability artifact; source and native electrical agreement do not waive the rendering requirement.

The document has 4/4 landscape pages, each 900 × 607.5 pt, with 94/87/70/121 extracted words and 0/372 word boxes outside page bounds. Component totals are 7+11+10+12 = 40, and every native component reference appears exactly once in the PDF. All 20/20 named CircuitJSON nets appear in the PDF. Independent connectivity partitions agree over 103/103 pins and 24/24 net groups (20 named functional nets plus four explicit single-pin no-connect groups). A known-bad in-memory fixture moving J1.5 to AUDIO_N is detected. This is a representation fidelity check, not a substitute for the separately commissioned topology/ratings lens. Native geometry census is 121 wires, 49 global labels, 6 junctions, 64 symbols (including power symbols), and 4 no-connect markers; those counts are not a claim of exhaustive automated PDF occlusion detection.

Native-versus-PDF boundary: the native U1 reference is at (146.050,623.910) and its value at (143.510,662.600) in KiCad coordinates. The PDF places its U1/value rows above the body and the GND conductor crosses the reference. The project invokes render_schematic_pdf.mjs from rebuild_all.sh:249 on CircuitJSON. The generic renderer is absent from the frozen packet, so the exact algorithmic cause is not claimed. The corrective owner must change the source/presentation that feeds the PDF, not manually alter generated KiCad bytes.

Inherited authority and exclusions: source acceptance at 8a2d3620 and native startup/reviewer qualification are coordinator-provided context, not independently rerun here. The frozen source connector gate is PASS while the full connector gate is authentically INCOMPLETE with nine pod physical unknowns. FIRST-ARTICLE-ONLY / DO-NOT-ORDER prototype progression under ADR-0005 is preserved. Factory Cat6A carries custom analog audio and power, not Ethernet or PoE; power-off mating remains mandatory. No allocation or completed physical test is invented. Cable contact/current/loop testing, shield isolation measurement, UV qualification, assembled access and U3 underside DFM remain physical obligations. Carrier physical unknowns, sourcing, placement, routing, board render/DRC/fab/release are separate work, and this review does not reopen the already closed LAYOUT001 scope.

Runtime disclosure: the provided preflight checks input identity and writer scope before validating output membership; its initial invocation reached the expected missing-output error before outputs existed. The subsequent frozen-input receipt and final original preflight establish unchanged inputs. An abandoned helper named inspect.py shadowed Python's standard-library module during launcher import and also found PyMuPDF absent; no native tool launched in that failed setup. It was renamed, preserved as analyze_pdf.py, and replaced by the successfully bounded review_measurements.py using Poppler and standard-library XML. All actual native/PDF subprocesses use /usr/bin/python3 pipeline_runtime.run_stage with direct argv, explicit cwd/environment, 60-second deadlines and retained raw logs/runtime records. No live project files were edited.
