from pathlib import Path,PurePosixPath
import sys,json,hashlib,tarfile,stat
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';T=P/'06_build/task_runs/rj45-carrier-placement-after-model1';S=T/'scratch';O=T/'outputs';O.mkdir(exist_ok=True)
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet,writer_scope_receipt
from pipeline_runtime import _tree_snapshot,_changed_paths,_snapshot_sha256
E=TaskEnvelope.from_json((T/'envelope.json').read_text());A=json.loads((T/'admission.json').read_text());assert verify_input_packet(E,P)[0]
post=_tree_snapshot(P,ignored=frozenset(A['ignored']));changes=_changed_paths(A['before'],post)
scope=writer_scope_receipt(E.writer_scope,changes,before_sha256=_snapshot_sha256(A['before']),after_sha256=_snapshot_sha256(post),protected_paths=tuple(sorted((E.output_path,A['claim']))));assert scope['status']=='PASS';(S/'scope-before-package.json').write_text(json.dumps(scope,indent=2))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pre=json.loads((S/'protected-preimages.json').read_text());assert all(sha(R/r['path'])==r['sha256'] for r in pre)
allcontext=json.loads((S/'all-context-live-preimages.json').read_text());assert all(sha(R/r['path'])==r['packet_sha256'] for r in allcontext)
runtime=json.loads((S/'runtime.json').read_text());command=json.loads((S/'command.json').read_text());classification=json.loads((S/'drc-classification.json').read_text());census=json.loads((S/'component-pin-census.json').read_text());orient=json.loads((P/'06_build/pre_route/orientation/orientation_receipt.json').read_text())
subjects={}
for rel in ['03_tscircuit/build/circuit.json','03_tscircuit/build/schematic.pdf','04_kicad/crow_audio_carrier_v1.kicad_sch','03_tscircuit/kicad/crow_audio_carrier_v1.kicad_sch','04_kicad/crow_audio_carrier_v1.kicad_pcb','04_kicad/crow_audio_carrier_v1.kicad_pro','04_kicad/crow_audio_carrier_v1.kicad_dru','06_build/netlists/crow_audio_carrier_v1.net','06_build/drc/gate.json','06_build/drc/pre_route.json','06_build/pre_route/orientation/orientation_receipt.json','06_build/pre_route/orientation/orientation_review.md','06_build/pre_route/model_registration.md']:
 f=P/rel;subjects[rel]={'path':str(f),'sha256':sha(f),'size':f.stat().st_size}
assert subjects['06_build/drc/gate.json']['sha256']==sha(S/'before/06_build/drc/gate.json')
notrun=['TSX regeneration','placement human review PR-REVIEW/P-ROUTEBASE','route import','route taps','stitch','analog copper','final route acceptance','layout seal','fabrication/release','physical qualification','fourth LAYOUT001 diagnostic']
evidence={'schema':1,'task_id':E.task_id,'envelope_sha256':'7700d25eb2a8305b0e0fd7edea92589eb90f8b96b73139c2735567cf8f2977b4','subject':E.subject.to_mapping(),'input_packet_count':636,'input_packet_verified':True,'runtime':runtime,'command':command,'inner_runtime':json.loads((P/'06_build/pipeline_state/rj45_renewed_placement.json').read_text()),'domain_result':{'status':'INCOMPLETE','stopping_gate':'[5e] P-ORIENT','cause':'machine 9/9 PASS; approval subject or denominator is stale','orientation_subject_sha256':orient['subject_sha256'],'machine_graded':9,'machine_total':9,'human_approval':'NOT ACCEPTED','placement_feasibility':'7/7 PASS or N-A','model_coverage':'333/333 PASS','model_registration':'6/6 PASS','pinmap':'PASS; full conductor log retained','route_prep':'PASS; deterministic seed preparation only','not_run':notrun},'native_subjects':subjects,'component_census':{k:census[k] for k in ['component_count','pin_count','component_sha256','pin_sha256','source_sha256','method']},'drc':classification,'compact_handoff':{'status':'STALE','validation_rc':2,'causes':['source hash changed after permitted reviewed-schematic promotion','DRC gate is stale after generation'],'action':'NOT GENERATED; preserved old gate bytes and timestamp; no DRC retry/touch/delete or checkpoint restamp'},'source_preservation':{'protected_source_method_count':len(pre),'all_live_context_count':len(allcontext),'all_unchanged':True,'writer_scope':scope},'orientation_image_verification':json.loads((S/'orientation-evidence-verification.json').read_text()),'root_observation':json.loads((S/'root-observation.json').read_text()),'limitations':['FIRST-ARTICLE-ONLY / DO-NOT-ORDER','Public-catalog design-only admission; physical FULL23carrier/9pod remains deferred under accepted decisions','No physical service or route acceptance follows from generated pin map or machine geometry','LAYOUT001 closed investigation remains 3/3; no diagnostic reset'],'delivery_checks':'Domain result is separate from complete honest delivery. Final provided preflight runs after the exact five outputs are finalized; receipt preserved in scratch/preflight-final.log.'}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
report=f'''# Carrier placement continuation — orientation approval required

MEASURED: The one authorized normal continuation stopped at **[5e] P-ORIENT** because the human approval subject or denominator is stale. Machine orientation **9/9 PASS**. Subprocess **rc1**, inner **166.013 s**, outer **166.138463 s**, from **{runtime['started_at']}** to **{runtime['finished_at']}**. No retry.

Packet **636/636** verified; envelope SHA256 `7700d25eb2a8305b0e0fd7edea92589eb90f8b96b73139c2735567cf8f2977b4`. Initial live handoff and schematic checkpoint **7/7 PASS**. All **457** protected source/method preimages and all **631** frozen context origin files remain byte-identical. Reviewed schematic promoted normally.

Placement feasibility **7/7** passing or N-A; model coverage **333/333**; pad separation, placement policy, P-LAND and model registration **6/6 groups PASS**. Route preparation ran deterministic seed work only. Current orientation subject `{orient['subject_sha256']}`; all **11** image hashes reopened.

Native pre-route DRC **0 violations / 499 unconnected / 0 parity**. Every row of the current report and both prior preserved reports is individually classified in `evidence.json`, including raw rows and independent UUID/net/position endpoint checks. Board has **zero track segments and 11 seed GND vias**. Every row identifies its own still-disconnected endpoints; no route acceptance or congestion diagnosis is inferred.

Component census **333**, SHA256 `{census['component_sha256']}`. Source pin census **985**, SHA256 `{census['pin_sha256']}`. Complete rows and canonicalization are archived. PCB SHA256 `{subjects['04_kicad/crow_audio_carrier_v1.kicad_pcb']['sha256']}`. Circuit JSON SHA256 `{census['source_sha256']}`. Native schematic/netlist/rules/report hashes appear in `evidence.json`.

Compact handoff validation **rc2: source hash changed; DRC gate is stale**. Handoff was not regenerated. Old gate remains intact, SHA256 `{subjects['06_build/drc/gate.json']['sha256']}`. No gate deletion/touch, DRC rerun or checkpoint restamp manufactured freshness.

Root reported **ungraded view ambiguity**: J1_inside/J5_inside may show opposite-row RJ45 mouths instead of the named target rear shell. This successor did not independently visually grade that observation or rerender. Root should resolve focused visual evidence before seeking human approval. Machine PASS remains separate.

**NOT RUN:** {', '.join(notrun)}. No source/config/parts/shared-script edits, stale route import or gate bypass. LAYOUT001 unchanged at3/3. **FIRST-ARTICLE-ONLY / DO-NOT-ORDER**; physical FULL23carrier/9pod remains deferred. No connector-service, fabrication or release acceptance.

Exact output directory: `{O}`. Five outputs: `report.md`, `evidence.json`, `evidence-manifest.json`, `evidence.tar.gz`, `result.json`. Archive preserves exact command/stdout/runtime, native subjects, previous DRC/checkpoints, current receipts/images, classification and source checks. Final provided preflight receipt: `{S/'preflight-final.log'}`. Complete honest delivery is separate from incomplete engineering.
'''
(O/'report.md').write_text(report)
(O/'result.json').write_text(json.dumps({'subject':E.subject.to_mapping(),'checks':{c:'PASS' for c in E.completion['checks']},'unresolved':[]},indent=2)+'\n')
files={}
def add(f,arc=None):
 if not f.exists():return
 assert not f.is_symlink(),f
 if f.is_dir():
  for child in sorted(f.rglob('*')):
   if child.is_file():add(child)
  return
 assert stat.S_ISREG(f.stat().st_mode),f
 name=arc or 'project/'+f.relative_to(P).as_posix()
 assert name not in files or files[name]==f
 assert '..' not in PurePosixPath(name).parts and not name.startswith('/')
 assert not name.endswith(('.tar.gz','.tar','.tgz','.zip')),name
 files[name]=f
for rel in changes:
 f=P/rel
 if f.is_file() and not str(f).startswith(str(T)):add(f)
for rel in subjects:add(P/rel)
for rel in ['06_build/checkpoints','06_build/pre_route/orientation','06_build/pre_route/model_registration_bundle','06_build/verification/pipeline/bundles/placement_feasibility']:add(P/rel)
for name in ['placement_routability_receipt.json','model_coverage.json','crow_spoke_implementation.json','connector_assembly_contract.json','connector_assembly_source_gate.json','connector_assembly_prototype_gate.json','manufacturing_readiness_prelayout.json']:
 add(P/'06_build/verification'/name)
for dirname in ['wurth-615008160221-side-entry','molex-43650-0200-side-entry','samtec-tmm-106-01-l-d-top-entry','ti-dsg0008a-native-package','littelfuse-1812l035-native-package','yageo-rt0603-native-package']:add(P/'06_build/pre_route/native_registration'/dirname)
for f in S.rglob('*'):
 if f.is_file():add(f)
add(T/'envelope.json');add(P/'06_build/handoffs/rj45-carrier-placement-after-model1/TASK.md');add(P/'01_docs/STATUS.md');add(P/'01_docs/journal/placement.md');add(O/'report.md','delivery/report.md');add(O/'evidence.json','delivery/evidence.json');add(O/'result.json','delivery/result.json')
manifest=[]
with tarfile.open(O/'evidence.tar.gz','w:gz',compresslevel=6) as tf:
 for name,f in sorted(files.items()):
  manifest.append({'path':name,'size':f.stat().st_size,'sha256':sha(f)});tf.add(f,arcname=name,recursive=False)
with tarfile.open(O/'evidence.tar.gz','r:gz') as tf:
 members=tf.getmembers();assert len(members)==len(manifest);assert len({m.name for m in members})==len(members)
 for m,row in zip(members,manifest):
  assert m.isfile() and not m.issym() and not m.islnk() and m.name==row['path'] and m.size==row['size'];data=tf.extractfile(m).read();assert hashlib.sha256(data).hexdigest()==row['sha256']
manifest_doc={'schema':1,'archive_sha256':sha(O/'evidence.tar.gz'),'archive_size':(O/'evidence.tar.gz').stat().st_size,'member_count':len(manifest),'members':manifest,'verification':'Every regular member independently reopened and SHA256/size/path matched; no symlinks, duplicate paths, traversal, special members or recursive archive.'}
(O/'evidence-manifest.json').write_text(json.dumps(manifest_doc,indent=2)+'\n')
print(json.dumps({k:manifest_doc[k] for k in ['archive_sha256','archive_size','member_count']},indent=2))
