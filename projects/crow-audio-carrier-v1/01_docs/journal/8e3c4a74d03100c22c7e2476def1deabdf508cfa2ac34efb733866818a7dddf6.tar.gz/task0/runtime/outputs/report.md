# Recorded canonical attempt

- qualify: rc=0, 18.601998s; full raw output execution.log
- placement: rc=1, 21.49569s; full raw output execution.log
- Authored input hashes: 592/592
- All generated identities are in execution.json.
- Stop at the last actual recorded gate. No routing or release acceptance.
