review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_control_fets_clockground1 (fresh independent agent)
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: e85b1461a82f3d3853c19fae694693816e31570d23d37019ef187d6428bea4ae
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: e6d5b0b89efd79051b082f70b283ec7e85e1170ed11ddb94581744d26904c9c7

Coverage is limited to Q_DUMP, Q_PRE_EN, Q_RST1 and their native dossier instances. This is not whole-board acceptance or an order authorization. Immutable subject bindings above are metadata, not independently reviewed board conclusions.

Manufacturer-first method: exact SHA-selected PDFs were verified, rendered with pdftoppm and visually opened before reading dossiers. AO3400A Rev3.1 p1 unnumbered SOT23 Top View shows marked gate-side paired lead G, other paired lead S and lone opposite D. Normalize the top view with D upward: G lower-left, S lower-right. Its separately labeled Bottom View is mirrored and was not substituted for top view. Diodes DS30896 Rev20-2 p1 unnumbered Top View directly shows this same G/S/D geometry; p7 Package Outline Dimensions and Suggested Pad Layout confirm three separate leads and no EP. AO p5 test-circuit image was also inspected; it adds no package identities.

The source diagrams label G/S/D rather than numeric terminal IDs. Numeric 1/2/3 are the native artifact identifiers here; physical function and topology are independently established without accepting the author's verification notes. G/S/D traverses CCW. A 90-degree clockwise rotation puts G upper-left, S lower-left, D right-center, exactly matching each dossier. No mirror is needed. Gate-side pin 1 is upper-left in that rotated comparison; AO's top-view dot is adjacent to G. Both packages have three separate physical leads, no exposed pad and no fused aliases.

All three mounted-side declarations are front F.Cu; local COMPONENT-TOP axes are +x right/+y down, board translation and rotation undone. Native positions equal local positions plus each declared origin (rotations are zero); no back-side reflection applies. The Q_DUMP side labels N/S/E are a nearest-axis classification of its coordinates: the actual paired-lead side is left. Coordinate positions, not those abbreviated labels, establish matching topology.

Primary AO3400A PDF SHA256: 9c60d0b6c1ddc7609a4b788a91181468d8ffe6c3e9ba425c3d8ffc5ba88c5033 (p1 SOT23 top/bottom illustrations; p5 inspected).
Primary 2N7002K-7 PDF SHA256: 669e5d68d6458e0879d7396416bdcdb3ef9966ea60f054773d4c891d735aa818 (p1 Top View and Equivalent Circuit; p7 outline/layout).

Q_DUMP VERDICT: PASS
Measured: 3 native lands, 3 unique pad identifiers, 3 physical identities; 0 EP; 0 aliases. Top-view winding CCW; signed polygon area -1.78125 mm2 in y-down coordinates. Primary: AO hash above, p1.
Q_DUMP pin 1 (G): expected control at upper-left paired lead; observed (-0.9375,-0.95), DUMP_GATE.
Q_DUMP pin 2 (S): expected reference at lower-left paired lead; observed (-0.9375,+0.95), GND.
Q_DUMP pin 3 (D): expected switched terminal alone opposite; observed (+0.9375,0), ADC_DUMP.

Q_PRE_EN VERDICT: PASS
Measured: 3 native lands, 3 unique pad identifiers, 3 physical identities; 0 EP; 0 aliases. Top-view winding CCW; signed area -1.9 mm2. Primary: Diodes hash above, p1 and p7.
Q_PRE_EN pin 1 (G): expected control at upper-left paired lead; observed (-1,-0.95), PWR_EN.
Q_PRE_EN pin 2 (S): expected reference at lower-left paired lead; observed (-1,+0.95), GND.
Q_PRE_EN pin 3 (D): expected switched terminal alone opposite; observed (+1,0), PRE_GATE, consistent with a low-side gate pull-down control.

Q_RST1 VERDICT: PASS
Measured: 3 native lands, 3 unique pad identifiers, 3 physical identities; 0 EP; 0 aliases. Top-view winding CCW; signed area -1.9 mm2. Primary: Diodes hash above, p1 and p7.
Q_RST1 pin 1 (G): expected control at upper-left paired lead; observed (-1,-0.95), RESET_PULSE_H.
Q_RST1 pin 2 (S): expected reference at lower-left paired lead; observed (-1,+0.95), GND.
Q_RST1 pin 3 (D): expected switched terminal alone opposite; observed (+1,0), ADC_RESET_N, consistent with an active-low pull-down.

Pairwise symmetry: both 2N7002K instances have identical pad positions and function assignment, and all three parts connect G to a control net, S to GND, D to a switched net. No swapped gate/source/drain instance was found. Source-to-drain body-diode orientation agrees with the manufacturer equivalent circuits for these grounded-source assignments. Net-name sanity does not establish operating voltage, load current, timing, or remote connectivity, which are outside this supplied pin dossier review.

Unresolved findings: none within commissioned pin-review scope. Inputs verified before and after; evidence retains inspected figure images, dossier bytes, exact PDF hashes, commands, raw subprocess logs and bounded runtime telemetry. The repeated rendering captures complete runtime telemetry without changing the independent figure interpretation.
