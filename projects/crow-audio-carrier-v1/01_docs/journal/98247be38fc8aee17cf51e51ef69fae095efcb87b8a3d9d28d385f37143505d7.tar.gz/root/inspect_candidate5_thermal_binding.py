from pathlib import Path
import sys,json,hashlib,yaml,pcbnew as k
Q=Path('/tmp/crow-adc2-native5-preparation-8jf47vo0');P=Q/'work/projects/crow-audio-carrier-v1';bp=Q/'placement/crow_audio_carrier_v1.kicad_pcb';h=hashlib.sha256(bp.read_bytes()).hexdigest();b=k.LoadBoard(str(bp));f=yaml.safe_load((P/'03_src/floorplan.yaml').read_text());zones={z.GetZoneName():z for z in b.Zones() if z.GetIsRuleArea()};rows=[]
for name in ['ADC_VMID2_RETURN_POUR','ADC_WEST_LOCAL']:
 s=next(x for x in f['keepouts'] if x['name']==name);z=zones[name];p=z.Outline();c=p.Outline(0);pts=[[c.CPoint(i).x,c.CPoint(i).y] for i in range(c.PointCount())];rows.append(dict(name=name,source=s,native_points_nm=pts,native_layers=[b.GetLayerName(l) for l in z.GetLayerSet().CuStack()],deny_pours=z.GetDoNotAllowZoneFills(),deny_tracks=z.GetDoNotAllowTracks(),deny_vias=z.GetDoNotAllowVias(),uuid=z.m_Uuid.AsString()))
fp=next(x for x in b.GetFootprints() if x.GetReference()=='C_VDDA2_10N');pad=next(p for p in fp.Pads() if p.GetNumber()=='2');box=pad.GetEffectiveShape(k.F_Cu).BBox();settings={}
for name in ['GetLocalZoneConnection','GetZoneConnection','GetThermalGap','GetThermalSpokeWidth','GetLocalThermalGap','GetLocalThermalSpokeWidth']:
 if hasattr(pad,name):
  try:settings[name]=getattr(pad,name)()
  except TypeError:settings[name]='Requires additional arguments; not called'
result=dict(board_sha256=h,floorplan_sha256=hashlib.sha256((P/'03_src/floorplan.yaml').read_bytes()).hexdigest(),changed_areas=rows,pad=dict(uuid=pad.m_Uuid.AsString(),net=pad.GetNetname(),bbox_nm=[box.GetLeft(),box.GetTop(),box.GetRight(),box.GetBottom()],settings=settings),top_smd_refs=[fp.GetReference() for fp in b.GetFootprints() if bool(fp.GetAttributes()&k.FP_SMD) and fp.GetLayer()==k.F_Cu],scope='Read-only exact saved placement/source binding; no Fill, Save, prep, new candidate or thermal diagnosis inferred.')
assert hashlib.sha256(bp.read_bytes()).hexdigest()==h
out=Path(__file__).parent/'candidate5-thermal-source-native-binding.json';out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'sha256':h,'areas':[(x['name'],len(x['native_points_nm']),x['deny_pours']) for x in rows],'pad':result['pad']},indent=2))
