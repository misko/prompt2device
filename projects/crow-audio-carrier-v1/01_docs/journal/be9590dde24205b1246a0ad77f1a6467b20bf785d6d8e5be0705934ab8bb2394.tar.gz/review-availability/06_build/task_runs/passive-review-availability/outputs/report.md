# Passive review availability probe

Challenge content:

> Fresh delivery can be measured; geometry still needs independent judgment.

Measured verification:

- Byte size: `75` (expected `75`) — PASS
- SHA-256: `eef8657b4b9bfdd1330c0e7d54c335bb8e3cfb47b7082036e6b8e0f1dec6490c` (expected identical) — PASS
- `challenge-read`: PASS

