# Fresh logged canonical attempt

Agent-role mechanical, economy/low effort; fresh context, no children. Exclusive live project writer; root is READ_ONLY until actual FINAL and closure. Source 39d54efbe16a56f776969c4de8a60e49ac095750. Read CLAUDE.md, pcb-design skill and supplied runner. Execute exactly:

/usr/bin/python3 /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/handoffs/passive-logged-20260911T205115Z/runner.py

This prebuilt runner verifies frozen inputs and absence of the already-retired guards, runs native qualification, one normal conductor, and only the precise expected fresh J-PCBA-PRELAYOUT rc2 pause permits one public continuation. All subprocesses use bounded runtime and preserve complete raw stdout/stderr, actualargv/cwd/rc/times in allocated scratch AND required execution.log/execution.json. It stops at the first other gate. Do not edit the runner or source, repeat it, delete/restore guards, route, alter reviews, commit or substitute ad hoc commands.

Original canonical attempt used6.907s and stoppedG-ORPHAN beforecompiler; it remains preserved in242494760416463bbbe12d9185dbf727a65a3d4988b0f022763ea87e4d73a2d8.tar.gz. Root fixed actual reader-contract syntax; audit881/881776PROVEN and28testsPASS. This is one source-corrected new attempt, not erased prior spend. Existing connector human approval remains unchanged. Source projections333/333bodies6/6registration are diagnostic; canonical generation and fresh required reviews still owed.

After runner returns, inspect report, execution.json and tail of execution.log. Do not diagnose or fix unexpected engineering gates. Run mandatory delivery/writer preflight:
/usr/bin/python3 /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/handoffs/passive-logged-20260911T205115Z/preflight.py /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/task_runs/passive-logged-20260911T205115Z/envelope.json

Deliver actual FINAL with exact last gate, childrc/duration and outputpaths. Runner creates required report.md,evidence.json,execution.log,execution.json,result.json. If runner itself fails, retain actual outputs and report INCOMPLETE; never fabricate a log/check. You may correct packaging only if source/runtime facts are retained; no change to original runtime/runner evidence. Work/FINAL cutoff2026-09-11T21:09:15.060977+00:00, hardclose2026-09-11T21:11:15.060977+00:00; reserve2minutes for preflight. Finish promptly after the first real gate. Send progress when the real run starts or stops.
