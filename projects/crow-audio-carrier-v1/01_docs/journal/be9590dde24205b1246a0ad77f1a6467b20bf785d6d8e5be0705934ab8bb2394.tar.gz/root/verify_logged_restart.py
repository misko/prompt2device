from pathlib import Path
import sys,json,hashlib
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet
j=json.loads(Path('/tmp/carrier-logged-restart-opened.json').read_text());E=Path(j['envelope']);A=E.parent;O=A/'outputs';H=Path(j['task']).parent;e=TaskEnvelope.from_json(E.read_text());assert verify_input_packet(e,P)[0]
source=json.loads((H/'source-index.json').read_text());assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in source.items())
a=json.loads((A/'attempt.json').read_text());assert a['status']=='PASS'
for n,m in a['output']['completion']['outputs'].items():
 b=(O/n).read_bytes();assert len(b)==m['size'] and hashlib.sha256(b).hexdigest()==m['sha256'],n
v=json.loads((O/'evidence.json').read_text())
for n,m in v['artifacts'].items():
 b=(P/n).read_bytes();assert len(b)==m['size'] and hashlib.sha256(b).hexdigest()==m['sha256'],n
runs=[]
for label in ['qualify','normal','public-continuation']:
 r=json.loads((A/'scratch'/f'{label}-runtime.json').read_text());b=Path(r['runtime']['log_path']).read_bytes();assert len(b)==r['runtime']['output_bytes'];runs.append(r)
assert '--resume-after-public-prelayout' not in runs[1]['argv']
assert '--resume-after-public-prelayout' in runs[2]['argv']
assert [x['runtime']['returncode'] for x in runs]==[0,2,1]
assert 'GATE INCOMPLETE [1c] J-PCBA-PRELAYOUT' in (A/'scratch/normal.log').read_text()
assert 'PR-REVIEW' in (A/'scratch/public-continuation.log').read_text()
result={'source_verified':len(source),'envelope_inputs_verified':len(e.input_packet),'outputs_verified':len(a['output']['completion']['outputs']),'artifacts':v['artifacts'],'runs':runs,'disposition':'Combined execution/evidence JSON and COMMAND caption alias the mutated argv list, so normal is mislabeled public continuation there. Original immediately persisted scratch/normal-runtime.json retains exact correct normal argv, unchanged time/rc/raw log. Root independently verified it. Closed worker outputs preserved; no repeat generation needed. Future runners copy argv when constructing rec.'}
(D/'logged-restart-root-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['source_verified','envelope_inputs_verified','outputs_verified','disposition']},indent=2))
