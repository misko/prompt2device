from pathlib import Path
import json,hashlib,tarfile,io,shutil
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911');j=json.loads(Path('/tmp/carrier-logged-restart-opened.json').read_text());a=Path(j['attempt']).parent;H=Path(j['task']).parent
sha=lambda b:hashlib.sha256(b).hexdigest();payload={}
def tree(root,prefix):
 for p in root.rglob('*'):
  if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts:payload[prefix+'/'+p.relative_to(root).as_posix()]=p
for root,prefix in [(a,'attempt'),(H,'handoff')]:tree(root,prefix)
for n in ['pipeline_state','checkpoints','task_runs/qualify-44c374269429407aaa6cc5039f4efc40','task_runs/qualify-44c374269429407aaa6cc5039f4efc40-identify']:tree(P/'06_build'/n,'actual/'+n)
for n in ['03_tscircuit/build/circuit.json','03_tscircuit/build/schematic.pdf','04_kicad/crow_audio_carrier_v1.kicad_sch','06_build/build_provenance.json','06_build/netlists/crow_audio_carrier_v1.net','06_build/netlists/net_aliases.txt','06_build/performance.json','06_build/erc.rpt','06_build/erc_errors.rpt','06_build/sourcing/prelayout_request.json','06_build/sourcing/prelayout_response.csv']:
 if (P/n).is_file():payload['canonical/'+n]=P/n
for pattern in ['logged-restart-root-verification*','renewed-canonical-source-suite*']:
 for p in I.glob(pattern):
  if p.is_file():payload['root/'+p.name]=p
for n in ['preserve_logged_restart.py','verify_logged_restart.py','logged-restart-root-verification.json']:payload['root/'+n]=D/n
probe=json.loads(Path('/tmp/carrier-passive-review-availability-opened.json').read_text());tree(Path(probe['project']),'review-availability')
manifest={n:{'size':p.stat().st_size,'sha256':sha(p.read_bytes())} for n,p in payload.items()};out=D/'logged-restart.tar.gz'
with tarfile.open(out,'w:gz',compresslevel=3) as t:
 for n,p in payload.items():t.add(p,arcname=n,recursive=False)
 b=(json.dumps({'members':manifest},indent=2)+'\n').encode();x=tarfile.TarInfo('MANIFEST.json');x.size=len(b);t.addfile(x,io.BytesIO(b))
h=sha(out.read_bytes());dest=P/'01_docs/journal'/f'{h}.tar.gz';assert not dest.exists();shutil.copyfile(out,dest)
with tarfile.open(dest) as t:
 assert len(t.getmembers())==len(manifest)+1
 for n,row in manifest.items():b=t.extractfile(n).read();assert len(b)==row['size'] and sha(b)==row['sha256']
with (P/'01_docs/journal/contracts.md').open('a') as w:w.write(f'\n\n## Allowed logged passive canonical renewal\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Immutable logged canonical renewal, exact generated schematic/netlist/PDF/checkpoints, complete original per-stage raw logs and corrected root command interpretation, 574-input reopening, 328 source tests and fresh reviewer availability |\n')
result={'archive':str(dest),'sha256':h,'payload_members':len(manifest),'size':dest.stat().st_size};(D/'logged-restart-preservation-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
