# Recorded canonical attempt

- qualify: rc=0, 16.449356s; full raw output execution.log
- normal: rc=2, 95.494203s; full raw output execution.log
- public-continuation: rc=1, 4.003429s; full raw output execution.log
- Authored input hashes: 574/574
- All generated identities are in execution.json.
- Stop at the last actual recorded gate. No routing or release acceptance.
