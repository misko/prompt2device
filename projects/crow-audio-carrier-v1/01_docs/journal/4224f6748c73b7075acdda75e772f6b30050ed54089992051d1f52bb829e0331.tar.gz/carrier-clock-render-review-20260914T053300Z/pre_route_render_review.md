# Fresh carrier clock-escape render review

review_stage: pre-route
review_kind: render
reviewer: GPT-6 Codex /root/pod_r3_render_review (fresh independent read-only reviewer)
completed_at: 2026-09-13T22:33:00-07:00
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
a-render_verdict: PASS
board_sha256: 54adf8ef221ff32ad711c234cc25dc60b96c40f64ee981a4404099a57f94bc7d
prepared_board_sha256: d0b28725833cc8c679138f6b98e13ba143eb299da74147903cfcd2059b3361fe
route_yaml_sha256: a1f09e6a54c9429f19461f8166086292651fe1ff718bb5f6e25097a27f5e113c
floorplan_sha256: ec65ec7cc8684b3d2d584063bcf2aec0dce372452ad98eb8e97ce4389080028c
nets_rules_sha256: af2c146b9269e73435a174fca10924bd0503b1507f07a9bfb48d7a1b346bcfa9
design_rules_sha256: 0e620140855c9c61444f52c02604c51c7feacf73c870d735eb9965a8cfd7ab70
locator_manifest_sha256: ca076253d2abf9bcf0c69feab24aca2d9c2dc3ca0ef4d4278695ab1d897d5bd4
locator_reviewed_refs: ["C_AUDIO_CT2", "C_FILT1_10U", "C_FILT2_10U", "C_PWR_CT", "C_VDDA2_10N", "C_VMID1_470N", "C_VMID1_4U7", "C_VMID2_470N", "C_VMID2_4U7", "R_ADC_BOT", "R_ADC_PD6N", "R_ADC_TOP", "R_AUDIO_PD", "R_AUDIO_PU", "R_DUMP_TIME2", "R_FILT1P", "R_IN6N", "R_PRE_G", "R_PWR_TOP", "R_VMID1_BOT", "R_VMID1_TOP", "R_VMID2_BOT", "R_X6N"]
release_scope: FIRST-ARTICLE-ONLY

## Subject and method

This is a fresh, read-only visual review of the exact live carrier board and exact prepared `r0`. I copied the two subjects and their local model tree to this unique temporary evidence directory, rendered fresh top and bottom views, inspected a separately generated exact-geometry U_CLK detail, recomputed the native footprint/model census, compared connector placement and model transforms, and inspected all 23 current assembly-locator pages. I did not edit the repository.

The render environment resolved 333/333 declared model paths for both subjects. The native census is identical for the live board and `r0`: 340 footprints, all 340 on F.Cu and zero on B.Cu; 309 footprints whose pads are all SMD are all on F.Cu. The only seven footprints without 3D models are mechanical holes H1-H4 and fiducials FID1-FID3. Thus every fitted SMD remains top-side, and the bottom views show only through-board features, vias, and copper rather than fitted bodies.

## Clock-buffer region

U_CLK remains at (147.0, 59.0) mm on F.Cu. The two requested prepared chains are visually clean and have plausible outward handoffs:

- U_CLK.1 MCH_MCLK leaves pad (145.6, 58.25) leftward, then left/up through (144.9, 58.25) and (144.5, 57.85), ending at (144.1, 57.45). Its three F.Cu segments are 0.18, 0.18, and 0.36 mm wide and total about 1.831 mm.
- U_CLK.5 BCLK_BUF leaves pad (148.4, 59.75) rightward through (149.1, 59.75) and (149.55, 60.0), ending at R_BCLK.1 at (149.99, 60.0). Its widths are 0.18, 0.18, and 0.36 mm and total about 1.655 mm.

The chains separate immediately to opposite sides of the package, do not cross each other, and do not create a visible component-body collision. The MCH_MCLK handoff stays left of the visible U_CLK reference bounding box (x 145.243-148.757, y 56.145-57.455 mm); BCLK_BUF runs near y 59.75-60.0 mm and also does not obscure that marking. The focused drawing and full `r0` render keep U_CLK and its surrounding assembly context readable. This is a placement/readability judgment only; it does not certify signal integrity or final manufacturability.

The exact copied `r0`, checked with its matching `r0.kicad_pro` and `r0.kicad_dru`, reports only pre-route categories: 199 library-table notices, 40 dangling-track rows, 54 dangling-via rows, and 499 unconnected items. It has no clearance, shorting, track-width, drill-range, or courtyard category. Those remaining pre-route items are not waived here and must be resolved by the route/final gates.

## Connectors and assembly readability

Fresh top renders show J1-J4 facing outward along the north edge, J5-J8 outward along the south edge, J9 outward at the west edge, and J10/J11 retaining their top-entry orientation. A native comparison confirms all J1-J11 positions, rotations, layers, model filenames, and model transforms are byte-for-value identical between the live board and prepared `r0`, and also identical to the previously inspected orientation subject. The dense top assembly markings remain readable at working zoom; no new clock escape obscures a connector or assembly label.

The exact A-LOCATOR machine check passes with 333/333 assembled references, 23/23 exception pages, 26/26 manifest members, and 1043 pads. I visually inspected all pages named in `locator_reviewed_refs`. Each page clearly identifies its target by title, MPN/value, side/orientation, exact coordinate, whole-board marker, enlarged local pattern, circled numbered pads, pad nets, and board-hash footer. Targets remain distinguishable from neighbors; no title, target circle, pad number, instruction block, or locator footer is clipped or unreadable in the reviewed pages. The HTML/PDF/PNG/JSON member hashes and sizes all match the current manifest.

## Evidence

- `board-top.png`, `board-bottom.png`: fresh exact live-board renders.
- `r0-top.png`, `r0-bottom.png`: fresh exact prepared-board renders.
- `u_clk-focused.png` / `.svg` and `clock-escape-geometry.json`: exact prepared U_CLK neighborhood and extracted chain coordinates.
- `final-native-checks.json`: top-side census plus J1-J11 live/r0/orientation-subject comparison.
- `render-board-dry-run.txt`, `render-r0-dry-run.txt`: exact render environment and 333/333 model-path resolution.
- `r0-drc.rpt`: DRC of the exact copied `r0` with matching project/rules files.
- `locator-contact-01-06.png` through `locator-contact-19-23.png`: the 23 visually inspected locator pages.
- `assembly-locator-exact-check.txt`, `locator-member-verification.txt`: exact A-LOCATOR result and all member identity checks.
- `evidence_manifest.json`: file identities for this review packet.

This SOUND/PASS verdict adopts only the current pre-route visual, model, top-side assembly, connector, clock-escape readability, and locator usability evidence. It is FIRST-ARTICLE-ONLY and DO-NOT-ORDER; it is not route, fab, SI, release, or purchase acceptance.

SOUND
