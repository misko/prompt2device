import pcbnew,json,hashlib,sys
from pathlib import Path
EV=Path('/tmp/carrier-clock-render-review-20260914T053300Z')
ROOT=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
paths={'live':ROOT/'projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb','r0':ROOT/'projects/crow-audio-carrier-v1/06_build/route/r0.kicad_pcb','orientation_observed':ROOT/'projects/crow-audio-carrier-v1/06_build/pre_route/orientation/observed_board.kicad_pcb'}
def sig(f,b):
 p=f.GetPosition(); return {'x_mm':pcbnew.ToMM(p.x),'y_mm':pcbnew.ToMM(p.y),'orientation_deg':f.GetOrientationDegrees(),'layer':b.GetLayerName(f.GetLayer()),'models':[(m.m_Filename,list(m.m_Scale),list(m.m_Rotation),list(m.m_Offset)) for m in f.Models()]}
def board_data(path):
 b=pcbnew.LoadBoard(str(path)); fps=list(b.GetFootprints()); refs={f.GetReference():f for f in fps}; smd=[]
 for f in fps:
  pads=list(f.Pads())
  if pads and all(p.GetAttribute()==pcbnew.PAD_ATTRIB_SMD for p in pads): smd.append(f)
 return b,refs,{'footprints':len(fps),'f_cu':sum(f.GetLayer()==pcbnew.F_Cu for f in fps),'b_cu':sum(f.GetLayer()==pcbnew.B_Cu for f in fps),'all_smd_pad_footprints':len(smd),'all_smd_on_f_cu':sum(f.GetLayer()==pcbnew.F_Cu for f in smd),'model_bearing':sum(bool(list(f.Models())) for f in fps),'model_omissions':sorted(f.GetReference() for f in fps if not list(f.Models()))}
data={k:board_data(v) for k,v in paths.items()}
refs=[f'J{i}' for i in range(1,12)]
connectors={r:{k:sig(data[k][1][r],data[k][0]) for k in data} for r in refs}
for r,v in connectors.items(): v['live_equals_r0']=v['live']==v['r0']; v['live_equals_orientation_observed']=v['live']==v['orientation_observed']
checks={'path_hashes':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in paths.items()},'census':{k:v[2] for k,v in data.items() if k!='orientation_observed'},'connectors':connectors,'all_connector_live_r0_equal':all(v['live_equals_r0'] for v in connectors.values()),'all_connector_live_observed_equal':all(v['live_equals_orientation_observed'] for v in connectors.values())}
(EV/'final-native-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({k:checks[k] for k in ('path_hashes','census','all_connector_live_r0_equal','all_connector_live_observed_equal')},indent=2))
