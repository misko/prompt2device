import pcbnew,json,hashlib,math
from pathlib import Path
EV=Path('/tmp/carrier-clock-render-review-20260914T053300Z')
root=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
cur=root/'projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb'
old=root/'projects/crow-audio-carrier-v1/06_build/pre_route/orientation/observed_board.kicad_pcb'
r0=root/'projects/crow-audio-carrier-v1/06_build/route/r0.kicad_pcb'
def fp_sig(b,refs):
 d={}
 for f in b.GetFootprints():
  if f.GetReference() in refs:
   p=f.GetPosition(); models=[]
   for m in f.Models(): models.append((m.m_Filename,tuple(m.m_Scale),tuple(m.m_Rotation),tuple(m.m_Offset)))
   d[f.GetReference()]={'x_mm':pcbnew.ToMM(p.x),'y_mm':pcbnew.ToMM(p.y),'orientation_deg':f.GetOrientationDegrees(),'layer':b.GetLayerName(f.GetLayer()),'models':models}
 return d
refs=[f'J{i}' for i in range(1,12)]
bc=pcbnew.LoadBoard(str(cur)); bo=pcbnew.LoadBoard(str(old)); br=pcbnew.LoadBoard(str(r0))
c,o=fp_sig(bc,refs),fp_sig(bo,refs)
comparison={r:{'current':c.get(r),'previous':o.get(r),'identical':c.get(r)==o.get(r)} for r in refs}
(EV/'connector-comparison.json').write_text(json.dumps(comparison,indent=2))
# census
fps=list(bc.GetFootprints()); smd=[]
for f in fps:
 pads=list(f.Pads())
 if pads and all(p.GetAttribute()==pcbnew.PAD_ATTRIB_SMD for p in pads): smd.append(f)
models=[f for f in fps if len(list(f.Models()))]
missing=[f.GetReference() for f in fps if not len(list(f.Models()))]
census={'footprints':len(fps),'f_cu':sum(f.GetLayer()==pcbnew.F_Cu for f in fps),'b_cu':sum(f.GetLayer()==pcbnew.B_Cu for f in fps),'all_smd_pad_footprints':len(smd),'all_smd_on_f_cu':sum(f.GetLayer()==pcbnew.F_Cu for f in smd),'model_bearing':len(models),'model_omissions':missing}
(EV/'native-census.json').write_text(json.dumps(census,indent=2))
# clock geometry
want={'MCH_MCLK','BCLK_BUF'}
segments=[]
for t in br.GetTracks():
 if t.Type()==pcbnew.PCB_TRACE_T:
  net=t.GetNetname()
  if net in want:
   a,b=t.GetStart(),t.GetEnd(); segments.append({'net':net,'start':[pcbnew.ToMM(a.x),pcbnew.ToMM(a.y)],'end':[pcbnew.ToMM(b.x),pcbnew.ToMM(b.y)],'width_mm':pcbnew.ToMM(t.GetWidth()),'layer':br.GetLayerName(t.GetLayer())})
(EV/'clock-escape-geometry.json').write_text(json.dumps({'segments':segments},indent=2))
print(json.dumps({'connector_all_identical':all(v['identical'] for v in comparison.values()),'census':census,'segments':segments},indent=2))
