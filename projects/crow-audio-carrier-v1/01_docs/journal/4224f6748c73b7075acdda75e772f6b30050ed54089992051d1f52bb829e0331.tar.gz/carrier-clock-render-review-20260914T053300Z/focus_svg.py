import pcbnew,html,hashlib,json
from pathlib import Path
EV=Path('/tmp/carrier-clock-render-review-20260914T053300Z')
board=pcbnew.LoadBoard('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/route/r0.kicad_pcb')
x0,x1,y0,y1=140,154,54,63.5; S=100; M=70
X=lambda x:M+(x-x0)*S; Y=lambda y:M+(y-y0)*S
W=M*2+(x1-x0)*S; H=M*2+(y1-y0)*S
s=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
'<rect width="100%" height="100%" fill="#f7faf7"/>',
'<style>text{font-family:DejaVu Sans,Arial,sans-serif}.ref{font-size:14px;font-weight:bold;fill:#183b32}.small{font-size:12px;fill:#29453e}.axis{font-size:11px;fill:#536b64}</style>',
'<text x="70" y="35" class="ref" font-size="18">U_CLK prepared escape inspection — exact r0 geometry</text>']
# grid
for x in range(int(x0),int(x1)+1): s += [f'<line x1="{X(x)}" y1="{Y(y0)}" x2="{X(x)}" y2="{Y(y1)}" stroke="#dfe9e4"/>',f'<text x="{X(x)+3}" y="{Y(y0)+14}" class="axis">{x}</text>']
for y in range(int(y0),int(y1)+1): s += [f'<line x1="{X(x0)}" y1="{Y(y)}" x2="{X(x1)}" y2="{Y(y)}" stroke="#dfe9e4"/>',f'<text x="{X(x0)+3}" y="{Y(y)-4}" class="axis">{y}</text>']
# nearby footprint bodies using bbox
fps=[]
for f in board.GetFootprints():
 p=f.GetPosition(); x,y=pcbnew.ToMM(p.x),pcbnew.ToMM(p.y)
 if x0<=x<=x1 and y0<=y<=y1:
  bb=f.GetBoundingBox(); bx,by,bw,bh=map(pcbnew.ToMM,(bb.GetX(),bb.GetY(),bb.GetWidth(),bb.GetHeight()))
  ref=f.GetReference(); fps.append(ref)
  color='#8aa79c' if ref!='U_CLK' else '#285f50'
  s.append(f'<rect x="{X(bx)}" y="{Y(by)}" width="{bw*S}" height="{bh*S}" fill="none" stroke="{color}" stroke-width="{3 if ref=="U_CLK" else 1}" stroke-dasharray="7 4"/>')
  s.append(f'<text x="{X(x)+5}" y="{Y(y)-7}" class="ref">{html.escape(ref)}</text>')
  for pad in f.Pads():
   pp=pad.GetPosition(); px,py=pcbnew.ToMM(pp.x),pcbnew.ToMM(pp.y); sz=pad.GetSize(); pw,ph=pcbnew.ToMM(sz.x),pcbnew.ToMM(sz.y)
   s.append(f'<rect x="{X(px-pw/2)}" y="{Y(py-ph/2)}" width="{pw*S}" height="{ph*S}" rx="3" fill="#f4d58a" stroke="#8c6d2d" stroke-width="1"/>')
   if ref=='U_CLK': s.append(f'<text x="{X(px)-4}" y="{Y(py)+4}" class="small">{pad.GetNumber()}</text>')
# all F tracks crop gray then target colored
trs=[]
for t in board.GetTracks():
 if t.Type()!=pcbnew.PCB_TRACE_T or t.GetLayer()!=pcbnew.F_Cu: continue
 a,b=t.GetStart(),t.GetEnd(); ax,ay,bx,by=map(pcbnew.ToMM,(a.x,a.y,b.x,b.y))
 if max(ax,bx)<x0 or min(ax,bx)>x1 or max(ay,by)<y0 or min(ay,by)>y1: continue
 net=t.GetNetname(); color={'MCH_MCLK':'#0b67c2','BCLK_BUF':'#d34236'}.get(net,'#9ca9a4'); width=max(2,pcbnew.ToMM(t.GetWidth())*S)
 s.append(f'<line x1="{X(ax)}" y1="{Y(ay)}" x2="{X(bx)}" y2="{Y(by)}" stroke="{color}" stroke-width="{width}" stroke-linecap="round"/>')
 if net in ('MCH_MCLK','BCLK_BUF'): trs.append((net,ax,ay,bx,by,pcbnew.ToMM(t.GetWidth())))
# endpoint annotations
s += [f'<circle cx="{X(144.1)}" cy="{Y(57.45)}" r="7" fill="#0b67c2"/><text x="{X(140.3)}" y="{Y(57.2)}" class="ref" fill="#0b67c2">MCH_MCLK outward handoff</text>',
f'<circle cx="{X(149.99)}" cy="{Y(60)}" r="7" fill="#d34236"/><text x="{X(150.15)}" y="{Y(60.45)}" class="ref" fill="#d34236">BCLK_BUF → R_BCLK.1</text>',
f'<rect x="{X(145.243334)}" y="{Y(56.1448)}" width="{(148.756667-145.243334)*S}" height="{(57.4552-56.1448)*S}" fill="none" stroke="#7a3da8" stroke-width="2"/><text x="{X(145.25)}" y="{Y(55.95)}" class="small" fill="#7a3da8">U_CLK visible reference bbox</text>',
'<text x="70" y="1070" class="small">Blue/red: requested prepared chains. Gray: other prepared F.Cu traces. Dashed: nearby footprint bounding boxes. Units: mm.</text>', '</svg>']
(EV/'u_clk-focused.svg').write_text('\n'.join(s))
(EV/'u_clk-focused-data.json').write_text(json.dumps({'bounds_mm':[x0,x1,y0,y1],'nearby_refs':sorted(fps),'target_segments':trs},indent=2))
