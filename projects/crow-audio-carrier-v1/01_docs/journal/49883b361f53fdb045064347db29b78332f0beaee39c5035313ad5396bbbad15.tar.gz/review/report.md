review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_esd_mountedframe1 (same actual reviewer, continuation)
context: CONTINUED_REQUESTED_CONTEXT
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

Scope: resolution of the eight original audio-voltage questions for U_ESD1–U_ESD8 at the unchanged pre-route physical subject. All eight now PASS within the declared normal operating design. FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains. No whole-board, placement, physical qualification, release or order acceptance.

Context is continued, not fresh: the original independent review remains closed and INCOMPLETE, with QUESTION on all eight refs. This report adds specifically requested authored operating context and new independent TI checks. It does not edit or relabel the original review. Although the envelope transport field says FRESH, this is the same reviewer with retained prior findings.

Exact current envelope subject: raw_sha256=257d9d055dac0dd5059febf943d24c3a39465ad9e03097b262c1e6753e008f03; semantic_sha256=eb96cce9982633f24b020587bac65243bc913f61977142f432e86fe4c01e1095. Canonical envelope SHA-256=8b500893a035b5222fa7e9e65807c5657ab14bc30b6027bf84857f2cbe37590b. Physical board/parts/rules bindings above remain unchanged; the task-envelope subject binds the expanded context packet.

Original proof: previous-completed-report.md SHA-256=8a44dfbcbe8b5aa91eea6eac59780ec5622ee0a85c9e25ea8bc7a3414f534e93; closed archive SHA-256=1720aa2dc0dc215cae7a9505c1fd56f732fe78c043fc4686f828a3c775d94a97; underlying original reviewer archive SHA-256=c9989b95d11d5cbd0a53ee634c9a684f03b90073b6852eb792166cfa845e43d7. The frozen report and closeout receipt are retained; the live archive was not reread. Original five-pad DRL package, CCW winding, pin-1 corner, B.Cu mount conversion, no-EP/no-alias and eight-instance symmetry evidence is inherited by exact identity rather than rerun. The prior measured census is 5 physical identities per ref, 40 total, with 0 EP and 0 aliases.

New supplied facts: the accepted-for-first-article pod contract states a DC-coupled active-balanced output at nominal 2.5 V common mode with one 100 ohm resistor on each leg and a frozen 1.2 Vrms differential ceiling. These are authored design requirements and connections, not measured voltages. The exact supplied pod source has equal 22 kohm VREF-divider resistors (lines 226–228), buffered VREF and GND/5V_QUIET op-amp supplies (238–242), 22k/18k inverting preamplifier and 10k/10k polarity-restoring inverter (248–254), and direct 100 ohm source resistors to AUDIO_P/AUDIO_N (256–259).

Independent normal-operation derivation: VREF=5×22/(22+22)=2.5 V. For microphone AC deviation v, PRE_OUT=VREF−(9/11)v and OUTP_DRV=VREF+(9/11)v; differential gain is 18/11 V/V. At 1.2 Vrms differential the nominal complementary legs each carry 0.6 Vrms. The sine-equivalent peak excursion is sqrt(2)×0.6=0.848528 V, so each leg spans 1.651472–3.348528 V relative to GND. The lower and upper margins to TI’s 0–5.5 V supported range are 1.651472 V and 2.151472 V, respectively. The source resistors and passive receiver loading do not create a new DC bias source on the cable side in this nominal circuit model.

Recomputed authored gain arithmetic: −24 dBV/Pa at 110 dB SPL gives 0.399052 Vrms microphone level; gain 18/11 gives 0.652995 Vrms differential, +3 dB sensitivity gives 0.922380 Vrms, and independent 1% gain-resistor corners give 0.950519 Vrms, below 0.96 and the 1.2 Vrms ceiling. These calculations independently check the supplied arithmetic, not capsule or OPA1679 specifications. Illustrative 1% divider/inverter corners at exactly nominal 5 V give approximately 1.6180–3.3820 V; this is not a full tolerance or physical qualification.

Peak scope: Vrms alone does not bound arbitrary waveform peaks. The calculated 1.6515–3.3485 V range is explicitly the nominal sine-equivalent design-ceiling excursion, not a maximum for every crow waveform, startup pulse or fault. In the ideal complementary model at nominal 2.5 V common mode, both legs stay in TI’s range if |instantaneous differential voltage|≤5 V (crest factor≤4.1667 at 1.2 Vrms). The supplied topology is a healthy nominal 5 V, ground-referenced active driver, with no intended negative audio supply. This scoped pin PASS establishes compatibility of that intended operating design; it does not claim measured crest-factor, rail, ground-offset or transient bounds.

Clamp location and common-mode distinction: carrier source lines 334–350 connect Jn pin 5 and U_ESDn pin 3 to AUDIO_Pn, Jn pin 4 and U_ESDn pin 5 to AUDIO_Nn, and U_ESDn pin 4 to GND. Lines 370–373 put the two 1 uF capacitors BETWEEN those cable nets and BIAS_Pn/BIAS_Nn; only the BIAS nets connect through 100 kohm to VMIDn_EXT. Lines 537–538 derive the nominal 1.65 V receiver bias from 3V3_ADC. Therefore the ESD clamp sees the pod’s 2.5 V cable common mode; the post-capacitor 1.65 V receiver bias is not the clamp DC operating point. Both Port and AnalogChannel are instantiated for all eight channels, so the context applies uniformly.

New primary evidence: TI TPD2E2U06 SLLSEG9C PDF SHA-256=a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed. Actual rendered pages 4,8,9,11 were inspected. P.4 section 6.3 and p.11 section 8.2.2.1 support IO voltages 0–5.5 V. P.8 section 7.2 shows two equivalent channels and ground return. P.9 section 7.4 describes the passive lower diode at approximately −0.6 V and positive breakdown response. P.11 section 9 requires no power supply for this device. Those transient trigger thresholds do not expand its recommended normal signal range.

normal_powered: Design-level compatibility established for declared healthy nominal 5 V/GND pod, buffered nominal 2.5 V cable common mode and declared active-balanced signal envelope. Nominal ceiling sine-equivalent per-leg range is 1.6514719–3.3485281 V. Contract and source are authored evidence; real amplitude, bias, loading and tolerance qualification are not measured here.

carrier_unpowered_pod_powered: TPD2E2U06 itself needs no supply and has no carrier-rail pin. With GND retained and a pod driving the same supported cable range, losing carrier power does not invalidate this clamp pin mapping. No claim about the downstream unpowered AFE or startup/coupling transient is made.

pod_or_both_unpowered: The powered 2.5 V operating point is not assumed to persist. A settled 0 V cable line is within the clamp signal range and the passive clamp still has its ground path, but unpowered driver impedance, residual capacitor charge and exact startup/shutdown line waveforms are not established by this packet.

abnormal_and_physical_holds: Negative fault/ESD excursions activate the lower diode (p.9 approximately -0.6 V), and positive ESD excursions activate the TVS network; those transient thresholds are not the normal recommended signal range. This review does not prove hot-plug, 12 V crosswire, ground loss, ESD system survival, cable pickup, OPA output swing/stability, or physical power-sequence performance. Existing no-hot-plug/bench/first-article holds remain unchanged; no new physical prerequisite is imposed for this design-only pin resolution.

U_ESD1 — original VERDICT: QUESTION; continued VERDICT: PASS
Counts retained from original exact proof: native pads=5, physical identities=5, EP=0, aliases=0; original CCW/B.Cu/pin1/symmetry checks preserved, not rerun.
U_ESD1 pins 1/2 (NC): expected permitted unconnected NC terminals; observed distinct original unconnected nets, retained PASS.
U_ESD1 pin 3 (IO1): expected supported 0–5.5 V signal; observed AUDIO_P1, authored 2.5 V cable bias and nominal sine-equivalent range 1.651472–3.348528 V. Original operating-context question resolved for intended normal design.
U_ESD1 pin 4 (GND): expected ground; observed GND, retained PASS.
U_ESD1 pin 5 (IO2): expected supported 0–5.5 V signal; observed AUDIO_N1, same cable bias/envelope with complementary phase. Original operating-context question resolved for intended normal design.
U_ESD1 source cross-check: clamp is before C_A1P/N, which connect to separate BIAS_P1/BIAS_N1 receiver nets. Same kind of net on same pin as all seven peers.
Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; new pp.4/8/9/11 as described above; physical pp.3/17/18 retained via original digest-bound proof. Unresolved scoped pin findings: none.

U_ESD2 — original VERDICT: QUESTION; continued VERDICT: PASS
Counts retained from original exact proof: native pads=5, physical identities=5, EP=0, aliases=0; original CCW/B.Cu/pin1/symmetry checks preserved, not rerun.
U_ESD2 pins 1/2 (NC): expected permitted unconnected NC terminals; observed distinct original unconnected nets, retained PASS.
U_ESD2 pin 3 (IO1): expected supported 0–5.5 V signal; observed AUDIO_P2, authored 2.5 V cable bias and nominal sine-equivalent range 1.651472–3.348528 V. Original operating-context question resolved for intended normal design.
U_ESD2 pin 4 (GND): expected ground; observed GND, retained PASS.
U_ESD2 pin 5 (IO2): expected supported 0–5.5 V signal; observed AUDIO_N2, same cable bias/envelope with complementary phase. Original operating-context question resolved for intended normal design.
U_ESD2 source cross-check: clamp is before C_A2P/N, which connect to separate BIAS_P2/BIAS_N2 receiver nets. Same kind of net on same pin as all seven peers.
Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; new pp.4/8/9/11 as described above; physical pp.3/17/18 retained via original digest-bound proof. Unresolved scoped pin findings: none.

U_ESD3 — original VERDICT: QUESTION; continued VERDICT: PASS
Counts retained from original exact proof: native pads=5, physical identities=5, EP=0, aliases=0; original CCW/B.Cu/pin1/symmetry checks preserved, not rerun.
U_ESD3 pins 1/2 (NC): expected permitted unconnected NC terminals; observed distinct original unconnected nets, retained PASS.
U_ESD3 pin 3 (IO1): expected supported 0–5.5 V signal; observed AUDIO_P3, authored 2.5 V cable bias and nominal sine-equivalent range 1.651472–3.348528 V. Original operating-context question resolved for intended normal design.
U_ESD3 pin 4 (GND): expected ground; observed GND, retained PASS.
U_ESD3 pin 5 (IO2): expected supported 0–5.5 V signal; observed AUDIO_N3, same cable bias/envelope with complementary phase. Original operating-context question resolved for intended normal design.
U_ESD3 source cross-check: clamp is before C_A3P/N, which connect to separate BIAS_P3/BIAS_N3 receiver nets. Same kind of net on same pin as all seven peers.
Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; new pp.4/8/9/11 as described above; physical pp.3/17/18 retained via original digest-bound proof. Unresolved scoped pin findings: none.

U_ESD4 — original VERDICT: QUESTION; continued VERDICT: PASS
Counts retained from original exact proof: native pads=5, physical identities=5, EP=0, aliases=0; original CCW/B.Cu/pin1/symmetry checks preserved, not rerun.
U_ESD4 pins 1/2 (NC): expected permitted unconnected NC terminals; observed distinct original unconnected nets, retained PASS.
U_ESD4 pin 3 (IO1): expected supported 0–5.5 V signal; observed AUDIO_P4, authored 2.5 V cable bias and nominal sine-equivalent range 1.651472–3.348528 V. Original operating-context question resolved for intended normal design.
U_ESD4 pin 4 (GND): expected ground; observed GND, retained PASS.
U_ESD4 pin 5 (IO2): expected supported 0–5.5 V signal; observed AUDIO_N4, same cable bias/envelope with complementary phase. Original operating-context question resolved for intended normal design.
U_ESD4 source cross-check: clamp is before C_A4P/N, which connect to separate BIAS_P4/BIAS_N4 receiver nets. Same kind of net on same pin as all seven peers.
Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; new pp.4/8/9/11 as described above; physical pp.3/17/18 retained via original digest-bound proof. Unresolved scoped pin findings: none.

U_ESD5 — original VERDICT: QUESTION; continued VERDICT: PASS
Counts retained from original exact proof: native pads=5, physical identities=5, EP=0, aliases=0; original CCW/B.Cu/pin1/symmetry checks preserved, not rerun.
U_ESD5 pins 1/2 (NC): expected permitted unconnected NC terminals; observed distinct original unconnected nets, retained PASS.
U_ESD5 pin 3 (IO1): expected supported 0–5.5 V signal; observed AUDIO_P5, authored 2.5 V cable bias and nominal sine-equivalent range 1.651472–3.348528 V. Original operating-context question resolved for intended normal design.
U_ESD5 pin 4 (GND): expected ground; observed GND, retained PASS.
U_ESD5 pin 5 (IO2): expected supported 0–5.5 V signal; observed AUDIO_N5, same cable bias/envelope with complementary phase. Original operating-context question resolved for intended normal design.
U_ESD5 source cross-check: clamp is before C_A5P/N, which connect to separate BIAS_P5/BIAS_N5 receiver nets. Same kind of net on same pin as all seven peers.
Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; new pp.4/8/9/11 as described above; physical pp.3/17/18 retained via original digest-bound proof. Unresolved scoped pin findings: none.

U_ESD6 — original VERDICT: QUESTION; continued VERDICT: PASS
Counts retained from original exact proof: native pads=5, physical identities=5, EP=0, aliases=0; original CCW/B.Cu/pin1/symmetry checks preserved, not rerun.
U_ESD6 pins 1/2 (NC): expected permitted unconnected NC terminals; observed distinct original unconnected nets, retained PASS.
U_ESD6 pin 3 (IO1): expected supported 0–5.5 V signal; observed AUDIO_P6, authored 2.5 V cable bias and nominal sine-equivalent range 1.651472–3.348528 V. Original operating-context question resolved for intended normal design.
U_ESD6 pin 4 (GND): expected ground; observed GND, retained PASS.
U_ESD6 pin 5 (IO2): expected supported 0–5.5 V signal; observed AUDIO_N6, same cable bias/envelope with complementary phase. Original operating-context question resolved for intended normal design.
U_ESD6 source cross-check: clamp is before C_A6P/N, which connect to separate BIAS_P6/BIAS_N6 receiver nets. Same kind of net on same pin as all seven peers.
Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; new pp.4/8/9/11 as described above; physical pp.3/17/18 retained via original digest-bound proof. Unresolved scoped pin findings: none.

U_ESD7 — original VERDICT: QUESTION; continued VERDICT: PASS
Counts retained from original exact proof: native pads=5, physical identities=5, EP=0, aliases=0; original CCW/B.Cu/pin1/symmetry checks preserved, not rerun.
U_ESD7 pins 1/2 (NC): expected permitted unconnected NC terminals; observed distinct original unconnected nets, retained PASS.
U_ESD7 pin 3 (IO1): expected supported 0–5.5 V signal; observed AUDIO_P7, authored 2.5 V cable bias and nominal sine-equivalent range 1.651472–3.348528 V. Original operating-context question resolved for intended normal design.
U_ESD7 pin 4 (GND): expected ground; observed GND, retained PASS.
U_ESD7 pin 5 (IO2): expected supported 0–5.5 V signal; observed AUDIO_N7, same cable bias/envelope with complementary phase. Original operating-context question resolved for intended normal design.
U_ESD7 source cross-check: clamp is before C_A7P/N, which connect to separate BIAS_P7/BIAS_N7 receiver nets. Same kind of net on same pin as all seven peers.
Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; new pp.4/8/9/11 as described above; physical pp.3/17/18 retained via original digest-bound proof. Unresolved scoped pin findings: none.

U_ESD8 — original VERDICT: QUESTION; continued VERDICT: PASS
Counts retained from original exact proof: native pads=5, physical identities=5, EP=0, aliases=0; original CCW/B.Cu/pin1/symmetry checks preserved, not rerun.
U_ESD8 pins 1/2 (NC): expected permitted unconnected NC terminals; observed distinct original unconnected nets, retained PASS.
U_ESD8 pin 3 (IO1): expected supported 0–5.5 V signal; observed AUDIO_P8, authored 2.5 V cable bias and nominal sine-equivalent range 1.651472–3.348528 V. Original operating-context question resolved for intended normal design.
U_ESD8 pin 4 (GND): expected ground; observed GND, retained PASS.
U_ESD8 pin 5 (IO2): expected supported 0–5.5 V signal; observed AUDIO_N8, same cable bias/envelope with complementary phase. Original operating-context question resolved for intended normal design.
U_ESD8 source cross-check: clamp is before C_A8P/N, which connect to separate BIAS_P8/BIAS_N8 receiver nets. Same kind of net on same pin as all seven peers.
Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; new pp.4/8/9/11 as described above; physical pp.3/17/18 retained via original digest-bound proof. Unresolved scoped pin findings: none.

Methods:
- Continued the same reviewer only to resolve specifically requested interface context. This is not a fresh independent repeat review. The envelope transport says FRESH; actual reviewer context is CONTINUED_REQUESTED_CONTEXT and is reported honestly.
- Verified all 17 exact envelope inputs by size and SHA-256 before and after; verified canonical envelope SHA-256 8b500893a035b5222fa7e9e65807c5657ab14bc30b6027bf84857f2cbe37590b.
- Retained the original independent top-view/package/pad/mount proof through exact completed-report and closeout identities; did not rerun those successful checks. Counts are inherited measurements, not new board extraction.
- Read supplied operating contract and exact frozen pod/carrier authoring connections as authored facts, not as measurements or independent device specifications. Connection excerpts with source line numbers are retained.
- New independent primary check: rendered physical TI PDF pages 4,8,9,11 at 120 DPI using pdftoppm; viewed actual images. Pages 4 and 11 establish 0–5.5 V signal range; p.8 shows ground-referenced clamp; p.9 section 7.4 and p.11 section 9 establish passive operation without a supply.
- Derived VREF and complementary signal equations from supplied resistor values and output connections. Converted declared differential RMS ceiling to nominal sine-equivalent per-leg peak explicitly using sqrt(2), and separately stated limits of RMS as a peak bound. Recomputed supplied microphone/gain corner arithmetic without claiming independent capsule/OPA qualification.
- Finite engineering subprocesses used shared pipeline_runtime.run_stage with direct argv, explicit scratch cwd and PATH=/usr/bin:/bin, LANG=C.UTF-8, LC_ALL=C.UTF-8, 60 second timeout. Actual raw output/runtime and scripts retained. Bootstrap packet reads and packaging used /usr/bin/python3 -B file I/O without child shell commands.
- Retained full supplied authored context, exact original report/closeout, dossiers, new rendered figures, derivation, commands/logs/runtime and input receipts in archive. Reopened every regular archive member and verified manifest path/size/digest census, no links/traversal/duplicate/nested archive. Delivery preflight validates handback and unchanged frozen scope.

Conclusion within commissioned scope: all original requested-context pin questions are resolved, so the continued pin domain is SOUND. Existing first-article, bench, abnormal-state and order holds remain open at their existing scope. No physical qualification hold has been converted into acceptance.
