#!/usr/bin/env python3
"""Cross-board crow spoke pinout and contract regression tests."""

from __future__ import annotations

import sys
import copy
import importlib.util
from pathlib import Path
import tempfile

import yaml

from harness import check, eq, main, test


ROOT = Path(__file__).resolve().parents[1]
CHECKER = ROOT / "projects/crow-roof-array-v1/03_src/check_spoke_interface.py"

spec = importlib.util.spec_from_file_location("crow_spoke_interface", CHECKER)
check(spec is not None and spec.loader is not None, "load checker module")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def fixture() -> Path:
    root = Path(tempfile.mkdtemp(prefix="crow-spoke-interface-"))
    for rel in (
        "projects/crow-roof-array-v1/03_src/rules/spoke_interface.yaml",
        "projects/crow-audio-carrier-v1/03_src/rules/spoke_interface.yaml",
        "projects/crow-mic-pod-v3/03_src/rules/spoke_interface.yaml",
    ):
        path = root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(yaml.safe_dump(module.EXPECTED, sort_keys=False), encoding="utf-8")
    return root


@test("crow spoke checker closes parent/carrier/pod pin and assembly identity")
def t_real_tree():
    result = module.verify(ROOT)
    eq(result["status"], "PASS", "real contract status")
    eq(result["pins"], 4, "closed pin denominator")
    eq(len(result["contracts"]), 3, "closed contract denominator")
    eq(result["realized_connectors"], 9, "closed board connector denominator")
    eq(result["realized_straight_through_pin_paths"], 32,
       "closed cross-board pin denominator")


@test("crow spoke checker rejects the archived power/ground swap", kind="known_bad")
def t_power_ground_swap():
    root = fixture()
    path = root / "projects/crow-audio-carrier-v1/03_src/rules/spoke_interface.yaml"
    value = copy.deepcopy(module.EXPECTED)
    value["pins"][0], value["pins"][1] = value["pins"][1], value["pins"][0]
    path.write_text(yaml.safe_dump(value, sort_keys=False), encoding="utf-8")
    try:
        module.verify_contracts(root)
    except module.ContractError:
        return
    raise AssertionError("power/ground swap was accepted")


@test("crow spoke checker rejects a missing represented child", kind="known_bad")
def t_missing_child():
    root = fixture()
    (root / "projects/crow-mic-pod-v3/03_src/rules/spoke_interface.yaml").unlink()
    try:
        module.verify_contracts(root)
    except module.ContractError:
        return
    raise AssertionError("missing pod contract was accepted")


@test("crow spoke checker rejects formatting-only authority drift", kind="known_bad")
def t_byte_drift():
    root = fixture()
    path = root / "projects/crow-audio-carrier-v1/03_src/rules/spoke_interface.yaml"
    path.write_text("# divergent copy\n" + path.read_text(encoding="utf-8"), encoding="utf-8")
    try:
        module.verify_contracts(root)
    except module.ContractError:
        return
    raise AssertionError("byte-distinct child contract was accepted")


@test("crow spoke checker rejects duplicate YAML keys", kind="known_bad")
def t_duplicate_key():
    root = fixture()
    path = root / "projects/crow-mic-pod-v3/03_src/rules/spoke_interface.yaml"
    path.write_text(path.read_text(encoding="utf-8") + "schema: 1\n", encoding="utf-8")
    try:
        module.verify_contracts(root)
    except module.ContractError:
        return
    raise AssertionError("duplicate-key contract was accepted")


@test("Cat harness preserves one audio pair and three independently twisted power loops")
def t_cat_pair_map():
    value, _ = module.load_contract(ROOT / "projects/crow-roof-array-v1/03_src/rules/spoke_interface.yaml")
    rows = value["cable"]["conductor_map"]
    eq(len(rows), 8, "all eight conductors represented")
    eq(len({row["color"] for row in rows}), 8, "no duplicated conductor")
    pairs = {pair: {r["cavity"] for r in rows if r["pair"] == pair}
             for pair in {r["pair"] for r in rows}}
    eq(pairs, {"blue": {3, 4}, "orange": {1, 2}, "green": {1, 2}, "brown": {1, 2}},
       "audio and power remain within actual twisted pairs")
    budget = module.cable_power_budget(value)
    check(budget["design_hot_loop_ohm"] < 2.2, "hot loop meets original limit")
    check(budget["design_pod_min_v"] >= 10.5, "pod remains above minimum voltage")
    eq(budget["physical_qualification"], "OWED", "calculation is not bench qualification")


@test("Cat harness rejects consistently miswired audio on all three contracts", kind="known_bad")
def t_cat_split_audio_pair():
    root = fixture()
    for path in root.glob("projects/*/03_src/rules/spoke_interface.yaml"):
        value = yaml.safe_load(path.read_text())
        value["cable"]["conductor_map"][1]["color"] = "green"
        value["cable"]["conductor_map"][1]["pair"] = "green"
        path.write_text(yaml.safe_dump(value, sort_keys=False))
    try:
        module.verify_contracts(root)
    except module.ContractError:
        return
    raise AssertionError("all-three-copy miswire accepted")


@test("Cat harness hot-loop calculation rejects a single power pair", kind="known_bad")
def t_cat_single_power_pair():
    value = copy.deepcopy(module.EXPECTED)
    value["cable"]["conductor_map"] = [r for r in value["cable"]["conductor_map"]
                                         if r["pair"] in {"blue", "orange"}]
    try:
        module.cable_power_budget(value)
    except module.ContractError:
        return
    raise AssertionError("one power pair passed the original resistance limit")


@test("Cat harness budget includes joins, pigtails and contacts", kind="known_bad")
def t_cat_bad_contact_budget():
    value = copy.deepcopy(module.EXPECTED)
    value["cable"]["power_budget"]["pigtails_joins_contacts_loop_allowance_ohm"] = 1.5
    try:
        module.cable_power_budget(value)
    except module.ContractError:
        return
    raise AssertionError("excessive non-cable resistance was ignored")


if __name__ == "__main__":
    sys.exit(main())
