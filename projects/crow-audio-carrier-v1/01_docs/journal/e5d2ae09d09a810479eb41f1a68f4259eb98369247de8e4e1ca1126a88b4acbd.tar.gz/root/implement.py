from pathlib import Path
import yaml,hashlib,pprint,json,subprocess
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901'); D=Path(__file__).parent
slugs=['crow-roof-array-v1','crow-audio-carrier-v1','crow-mic-pod-v3']
old=(R/'projects'/slugs[0]/'03_src/rules/spoke_interface.yaml').read_bytes()
(D/'spoke-interface-before.yaml').write_bytes(old)
v=yaml.safe_load(old); c=v['cable']
c.update(mpn='7939A',topology='four_twisted_pairs_overall_foil_shield',outer_diameter_nominal_mm=7.49,minimum_bend_radius_mm=53.0)
c['pair_allocation']={'blue':['AUDIO+','AUDIO−'],'orange':['+12V_POD','GND'],'green':['+12V_POD','GND'],'brown':['+12V_POD','GND']}
c['conductor_map']=[{'cavity':3,'signal':'AUDIO+','pair':'blue','color':'white_blue'},{'cavity':4,'signal':'AUDIO−','pair':'blue','color':'blue'}]
for pair in ['orange','green','brown']:
 c['conductor_map'] += [{'cavity':1,'signal':'+12V_POD','pair':pair,'color':'white_'+pair},{'cavity':2,'signal':'GND','pair':pair,'color':pair}]
c['continuity_test']='1-1; 2-2; 3-3; 4-4; verify all six power conductors individually before joining; no cross-short; shield isolated from all cavities; finished loop resistance <=2.2 ohm at maximum service temperature'
c['construction']={'category':'Cat5e','conductor_awg':24,'conductor_stranding':'7x32','conductor_material':'bare_copper','shield':'overall_foil_with_drain','jacket':'PVC','order_variant':'7939A 0101000','outdoor_rating':'CMX-Outdoor','manufacturer_stationary_bend_radius_mm':15.0,'operating_temperature_min_c':-40.0,'operating_temperature_max_c':75.0,'installation_temperature_min_c':-25.0,'maximum_conductor_dcr_ohm_per_km':93.8,'copper_clad_aluminum_permitted':False}
c['power_fan_in']={'manufacturer':'WAGO','mpn':'221-415','quantity_per_end':2,'quantity_per_cable':4,'conductors_per_rail':3,'ports_per_join':5,'occupied_ports_per_join':4,'conductors_per_port':1,'unused_port':'lever_closed_no_conductor','pigtail_manufacturer':'Belden','pigtail_mpn':'8503','pigtail_awg':22,'pigtail_maximum_length_mm':150.0,'positive_pigtail_color':'red','return_pigtail_color':'black','location':'inside_dry_enclosure_after_gland','qualification_status':'OWED'}
c['termination_process']={'micro_fit_conductors_per_contact':1,'power':'one_22_awg_8503_pigtail_per_contact','audio':'one_24_awg_7939A_conductor_per_contact','audio_insulation_diameter_fit_status':'OWED','maximum_contact_insulation_diameter_mm':1.85,'crimp_tool_mpn':'63819-0000','extraction_tool_mpn':'11-03-0043','bonded_pair_separation_process_status':'OWED','multiple_wires_in_micro_fit_contact_permitted':False}
c['power_budget']={'reference_temperature_c':20.0,'maximum_service_temperature_c':75.0,'hot_resistance_multiplier':1.25,'pigtails_joins_contacts_loop_allowance_ohm':0.30,'allowance_status':'DESIGN_ALLOCATION_MEASUREMENT_OWED'}
new=yaml.safe_dump(v,sort_keys=False,allow_unicode=True).encode()
for slug in slugs:
 (R/'projects'/slug/'03_src/rules/spoke_interface.yaml').write_bytes(new)
h=hashlib.sha256(new).hexdigest()
checker=R/'projects/crow-roof-array-v1/03_src/check_spoke_interface.py'
s=checker.read_text();a=s.index('    "cable": {');b=s.index('    "electrical": {',a)
s=s[:a]+'    "cable": '+pprint.pformat(c,sort_dicts=False,width=95).replace('\n','\n    ')+',\n'+s[b:];checker.write_text(s)
for slug in slugs[1:]:
 path=R/'projects'/slug/'03_src/check_spoke_implementation.py';s=path.read_text();s=s.replace('eacc850df2f2c1375e182d921745c74a7fb9def3133109e7c2dda105f7f453e7',h);path.write_text(s)
# Before source editing, preserve the pending current-board checkpoint and old contract.
(D/'contract-sha256.txt').write_text(h+'\n')
print('Three identical contracts:',h)
