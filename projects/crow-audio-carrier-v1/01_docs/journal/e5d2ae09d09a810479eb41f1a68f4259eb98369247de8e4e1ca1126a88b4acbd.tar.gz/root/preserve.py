from pathlib import Path
import json,hashlib,tarfile,io,shutil
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;V=Path('/tmp/carrier-cat-harness-review-lwsspork');T=V/'06_build/task_runs/cat-harness-review';O=T/'outputs';I=Path('/tmp/carrier-connector-integration-20260911')
def sha(b):return hashlib.sha256(b).hexdigest()
def verify_file(p,row):
 b=p.read_bytes();assert len(b)==row['size'] and sha(b)==row['sha256'],str(p);return b
e=json.loads((T/'envelope.json').read_text())
for row in e['input_packet']:verify_file(V/row['path'],row)
m=json.loads((O/'evidence-manifest.json').read_text());verify_file(O/'evidence.tar.gz',m['archive'])
with tarfile.open(O/'evidence.tar.gz','r:gz') as t:
 files={x.name:x for x in t.getmembers() if x.isfile()};assert set(files)=={x['path'] for x in m['members']}
 for row in m['members']:
  b=t.extractfile(files[row['path']]).read();assert len(b)==row['size'] and sha(b)==row['sha256']
for row in json.loads((D/'supplement-manifest.json').read_text()):
 p=Path(row['path']);verify_file(p,row);live=R/p.relative_to(D/'review-supplement');assert live.read_bytes()==p.read_bytes()
report=P/'08_reviews/2026-09-12_827e7b96_independent_harness.md';shutil.copyfile(O/'report.md',report)
summary={'frozen_review_inputs':len(e['input_packet']),'review_archive_members':len(m['members']),'supplement_files_verified_live':4,'frozen_verdict':'DEFECTIVE','supplement':'reviewer found both defects repaired; owning source phase gates subsequently PASS for both children','contract_sha256':sha((P/'03_src/rules/spoke_interface.yaml').read_bytes()),'physical_qualification':'OWED','source_tests':330,'parent_tests':9,'pod_tests':8,'source_checkpoint':'STALE_RENEWAL_REQUIRED'}
(D/'root-review-reopening.json').write_text(json.dumps(summary,indent=2)+'\n')
payload={}
def add(p,n):
 assert p.is_file() and not p.is_symlink();assert n not in payload;n and payload.__setitem__(n,p.read_bytes())
for row in e['input_packet']:add(V/row['path'],'review/input/'+row['path'])
for p in T.rglob('*'):
 if p.is_file() and 'scratch' not in p.relative_to(T).parts:add(p,'review/runtime/'+p.relative_to(T).as_posix())
for p in D.rglob('*'):
 if p.is_file() and p.name not in ['bundle.tar.gz','preservation.json']:add(p,'root/'+p.relative_to(D).as_posix())
for p in sorted(I.glob('cat-*')):
 if p.is_file():add(p,'runtime/'+p.name)
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 for name in ['connector_assembly_contract.json','connector_assembly_source_gate.json','connector_assembly_full_gate.json','cat_connector_assembly_contract.json']:
  p=R/'projects'/slug/'06_build/verification'/name
  if p.is_file():add(p,'current-receipts/'+slug+'/'+name)
for rel in json.loads((D/'source-files.json').read_text()):add(R/rel,'adopted-source/'+rel)
manifest={'schema':1,'files':[{'path':n,'size':len(b),'sha256':sha(b)} for n,b in sorted(payload.items())]}
raw=json.dumps(manifest,indent=2,sort_keys=True).encode()+b'\n';payload['manifest.json']=raw
out=D/'bundle.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for n,b in sorted(payload.items()):
  info=tarfile.TarInfo(n);info.size=len(b);info.mtime=0;t.addfile(info,io.BytesIO(b))
with tarfile.open(out,'r:gz') as t:
 members=t.getmembers();assert {x.name for x in members}==set(payload)
 for item in members:assert t.extractfile(item).read()==payload[item.name]
h=sha(out.read_bytes());dest=P/'01_docs/journal'/(h+'.tar.gz');shutil.copyfile(out,dest)
result={**summary,'archive':str(dest),'archive_sha256':h,'archive_bytes':out.stat().st_size,'payload_members':len(payload)-1,'review_path':str(report)}
(D/'preservation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
