from pathlib import Path
import hashlib,yaml,json
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');D=Path(__file__).parent
slugs=['crow-roof-array-v1','crow-audio-carrier-v1','crow-mic-pod-v3']
cat_record='''# Belden 7939A primary-source fact record

Accessed: 2026-09-12. Selected black ordering variant: `7939A 0101000`.
[Manufacturer product](https://www.belden.com/products/cable/ethernet-cable/category-5e-cable/7939a), active at retrieval; [technical data](https://catalog.belden.com/techdata/EN/7939A_techdata.pdf), revision 0.564, 2026-02-20.

Specified: Cat5e, four bonded twisted pairs, 24 AWG 7x32 bare copper,
overall foil shield and drain, PVC jacket, nominal OD 7.49 mm; maximum
conductor DCR 93.8 ohm/km; stationary bend radius 15 mm; operating
-40 to +75 C, installation -25 to +75 C; CMX-Outdoor, sunlight resistance.
The separate UL temperature row is 60 C: this record does not equate the
75 C operating specification with a 75 C UL listing.

Project retains a conservative 53 mm bend/straight-run planning allowance.
Actual conductor insulation diameter after bonded-pair separation must be
measured against the Molex 1.85 mm maximum before crimp qualification. The
published capacitance-unbalance row is not pair capacitance; no capacitance
or analog phase acceptance is inferred. Outdoor classification does not prove
our gland, enclosure, bond, or fault-energy qualification.

The server returned a gzip body. The vendored file is the decoded real PDF;
its SHA256 is `{sha}`. Failed raw-body PDF parsing was retained in scratch.
'''
pigtail_record='''# Belden 8503 internal pigtail source record

Accessed 2026-09-12. [Manufacturer technical data](https://catalog.belden.com/techdata/EN/8503_techdata.pdf).
22 AWG 7x30 tinned copper, PVC insulation, nominal OD1.3mm, nominal DCR
16.2ohm/1000ft, minimum stationary/installation bend13mm, operating
-40 to105C. Use red positive and black return, each at most150mm; one wire
per Molex43030-0007 contact. The1.3mm nominal insulation is below the1.85mm
contact limit. Nominal resistance is not an acceptance maximum; all pigtails,
joins and contacts share a measured-at-qualification0.30ohm loop allocation.
PDF SHA256: `{sha}`.
'''
join_record='''# WAGO 221-415 internal power join source record

Accessed 2026-09-12. [Exact five-conductor product](https://www.wago.com/us/wire-splicing-connectors/compact-splicing-connector/p/221-415);
[manufacturer conductor-range explanation](https://www.wago.com/us/splicing-connectors-221).
The221-412/413/415 family accepts stranded conductors from0.2to4mm2
(24–12AWG), and fine-stranded from0.14to4mm2. Selected221-415 has five
lever-operated positions electrically joined. At each end use separate joins
for positive and return, with three individual24AWG cable wires and one22AWG
pigtail, one conductor per port. Leave the fifth port empty with lever closed.
The joins live inside the dry enclosure; they are not weatherproof bulkheads.
Retain the product's strip-length instruction and inspect every insertion;
join restraint, installed service space, contact resistance, thermal/fault
performance and pull qualification remain OWED. No connector-resistance
maximum is inferred from the manufacturer's current rating. This retained
page-fact record replaces neither physical tests nor a missing raw datasheet.
'''
for slug in slugs:
 p=R/'projects'/slug
 for mpn,record,source in [('7939A',cat_record,'7939A_techdata.pdf'),('8503',pigtail_record,'8503_techdata.pdf'),('221-415',join_record,None)]:
  folder=p/'02_parts'/mpn;folder.mkdir(exist_ok=True)
  digest=None
  if source:
   raw=(D/source).read_bytes();assert raw.startswith(b'%PDF-');digest=hashlib.sha256(raw).hexdigest();(folder/source).write_bytes(raw)
  (folder/'primary-source-record.md').write_text(record.replace('{sha}',digest or 'not-vendored'))
  part={'mpn':mpn,'manufacturer':'WAGO' if mpn=='221-415' else 'Belden','type':{'7939A':'shielded_cat5e_cable','8503':'internal_pigtail_wire','221-415':'internal_wire_splice'}[mpn],'status':'active','datasheet':{'doc_id':mpn,'local':source,'sha256':digest,'fetched':'2026-09-12'},'package':'off-board harness component','footprint':'none_off_board','limits':{},'gotchas':['Physical harness qualification remains OWED; see primary-source-record.md and shared spoke contract.'],'verified':'Manufacturer facts inspected 2026-09-12; first article not measured.','sourcing':{'lcsc':None,'alternates':[]}}
  (folder/'part.yaml').write_text(yaml.safe_dump(part,sort_keys=False))
 brief=p/'01_docs/BRIEF.md'
 with brief.open('a') as f:f.write('''\n\n### 2026-09-12 — user-directed Cat cable change\n\nUser: “can we use cat cable instead of custom cable to run to pods?”\nAfter the two termination options were explained, user: “Great! lets do it!”\nImplementation assumption announced: outdoor shielded Cat5e bulk cable with\nthe existing Micro-Fit PCB connectors. The approval does not specifically\nselect RJ45; no RJ45, Ethernet or PoE conversion is inferred. See parent\nADR0012. All8 audio/power pairs and board pin identities remain unchanged;\nonly the prospective harness and its qualification contract change.\n''')
# Keep old decision facts; explicitly supersede cable choice.
adr=R/'projects/crow-roof-array-v1/01_docs/decisions/0011-internal-microfit-cable-gland-spokes.md'
s=adr.read_text();s=s.replace('status: accepted','status: superseded');s=s.replace('## Context','> Cable selection superseded by ADR0012 on2026-09-12. Internal Micro-Fit,\n> sealed glands and the non-Ethernet pinout remain in force.\n\n## Context',1);adr.write_text(s)
for slug in slugs[1:]:
 p=R/'projects'/slug
 path=p/'03_src/rules/connector_assemblies.yaml';s=path.read_text()
 s=s.replace('02_parts/6541PA/primary-source-record.md','02_parts/7939A/primary-source-record.md').replace('02_parts/6541PA/6541PA_techdata.pdf','02_parts/7939A/7939A_techdata.pdf')
 s=s.replace('mpn: 6541PA','mpn: 7939A').replace('two_individually_shielded_twisted_pairs','four_twisted_pairs_overall_foil_shield').replace('outer_diameter_mm: 5.44','outer_diameter_mm: 7.49')
 s=s.replace('published 53 mm bend radius','conservative project 53 mm bend allowance (manufacturer minimum 15 mm)')
 s=s.replace('The exact nominal OD and published bend radius are used, and one\n          full bend radius is reserved as straight service run outside J1.','The exact 7.49 mm nominal OD and conservative 53 mm project bend allowance\n          (manufacturer stationary minimum15 mm) are used. Internal WAGO power\n          joins and pigtails require a new installed service-space qualification.')
 s=s.replace('One full published minimum bend radius contains the planned cable service turn.','The retained conservative53mm project allowance bounds the planned cable turn; it is not the manufacturer minimum.')
 # Evidence must bind fan-in/pigtail facts without asserting an installed layout.
 marker='assemblies:\n'
 # insert additional source records before assemblies, in the same top-level list
 before,after=s.split(marker,1)
 before=before.rstrip()+'\n  - {id: cat-power-join, kind: manufacturer-assembly-process, path: 02_parts/221-415/primary-source-record.md}\n  - {id: cat-power-pigtail, kind: manufacturer-datasheet-record, path: 02_parts/8503/primary-source-record.md}\n\n'
 s=before+marker+after
 if slug=='crow-audio-carrier-v1':
  s=s.replace('source_ids: [shared-spoke-contract, spoke-cable-record]','source_ids: [shared-spoke-contract, spoke-cable-record, cat-power-join, cat-power-pigtail]')
  s=s.replace('actual harness routing remains an operation hold.','internal WAGO joins/pigtails and actual harness routing remain an installed service-space and operation hold.')
 else:s=s.replace('source_ids: [cable-datasheet, mate-drawing-record]','source_ids: [cable-datasheet, mate-drawing-record, cat-power-join, cat-power-pigtail]')
 path.write_text(s)
# Replace current live prose, preserving append-only reports and original decisions.
p=R/'projects/crow-roof-array-v1/01_docs/ARCHITECTURE.md';s=p.read_text().replace('Belden 6541PA assembly','Belden7939A shielded Cat5e assembly (ADR0012)');p.write_text(s)
p=R/'projects/crow-audio-carrier-v1/01_docs/DETAIL_DESIGN.md';s=p.read_text();old=next(x for x in s.splitlines() if x.startswith('Belden 6541PA is specified'))
s=s.replace(old,'The prospective harness uses Belden7939A shielded Cat5e per parent ADR0012: blue pair for balanced audio, orange/green/brown pairs each carrying positive and return in parallel. The old6541PA90.2pF/m calculation is superseded. The new datasheet does not supply a reliable pair-capacitance value; its capacitance-unbalance row must not be substituted. Measure pair capacitance, gain, noise/crosstalk and relative phase on representative4m and worst-case15m harnesses under concurrent power load. Installed port lengths and analog qualification remain OWED. The calculated hot power loop including0.30ohm pigtail/join/contact allocation is1.4725ohm; at0.10A and10.8V input the pod receives10.65275V. The allocation requires physical verification.')
p.write_text(s)
for slug in slugs[1:]:
 with (R/'projects'/slug/'01_docs/ARCHITECTURE.md').open('a') as f:f.write('''\n\n## Prospective Cat5e harness — 2026-09-12\n\nParent ADR0012 and `03_src/rules/spoke_interface.yaml` now select Belden7939A\nwith the unchanged Micro-Fit four-pin board map. Three twisted power loops\njoin through separate WAGO221-415 positive/return splices at each enclosure\nand one22AWG8503 pigtail per power contact. Blue carries audio directly.\nThis source change invalidates previous whole-contract/connector-service\nreceipts; it does not retroactively qualify the new harness or change a sealed\nrelease. Current native PCB connectivity is checked separately.\n''')
print('Dossiers, shared service contracts and live design documentation updated.')
