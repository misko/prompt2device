from pathlib import Path
import sys,shutil,tempfile,json
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901'); C=Path('/tmp/carrier-placement-review-20260911'); D=Path(tempfile.mkdtemp(prefix='carrier-cat-harness-review-'))
sys.path.insert(0,str(C));from open_review import open_review
files=['CLAUDE.md','tests/t1_crow_spoke_interface.py','tests/harness.py','projects/crow-roof-array-v1/03_src/check_spoke_interface.py','projects/crow-roof-array-v1/01_docs/decisions/0012-cat5e-pod-harness.md','projects/crow-roof-array-v1/01_docs/decisions/0011-internal-microfit-cable-gland-spokes.md']
for slug in ['crow-roof-array-v1','crow-audio-carrier-v1','crow-mic-pod-v3']:
 base='projects/'+slug
 files += [base+'/03_src/rules/spoke_interface.yaml']
 for mpn in ['7939A','8503','221-415']:
  files += [str(x.relative_to(R)) for x in (R/base/'02_parts'/mpn).iterdir() if x.is_file()]
 if slug!='crow-roof-array-v1':
  files += [base+'/03_src/rules/connector_assemblies.yaml',base+'/03_src/check_spoke_implementation.py',base+'/02_parts/43030-0007/primary-source-record.md']
for n in files:
 q=D/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/n,q)
task='''Independent fresh Cat5e harness source/electrical/termination review. agent-role: judgment. Read exact supplied source and manufacturer facts/PDFs. User authorized Cat cable; root selected bulk outdoor shielded7939A preserving PCB4-pin MicroFit, no RJ45 conversion. Check actual eight conductor pair map (blue audio, three independentpowerloops), 15m/100mA/hot resistance calculation including0.30ohm noncableallocation, shielding change and analog qualification,24AWGcontactfit and22AWGpigtails/WAGO221-415 fan-in, conductor count/onewirepercontact, weather/diameter/service impact and explicit outstanding qualification. Check prospective threecopysharedcontract and childsha pins, no sealedreleaseedits. Grade source engineering SOUND/DEFECTIVE/INCOMPLETE with exactfindings; physicalqualificationOWED alone is not falseifexplicitlycarried. No claimthatourharnessisalreadyassembledorqualified. Root has source9/9regressionsPASS inclsevenhostiles; independentlyinspecttestscope and sourcecheckconsumption. You may run bounded purePython/readPDF checks; no native regeneration or reviewotherPCBplacement/routing. No need new tools/framework. Subject copiedfilesfrozen; originalrepo read-onlyifneededmustexplicitlyhashanyextraauthority. Report findings with file/line/reason and minimal repair. Do not change source. No networkrequired; exactPDFs provided. Completeindependentreviewin8minutes thenhandoff; overallbudget12minuteswith2minpackagingreserve. Runtimepreflightfullarchive requiredasbelow.'''
o=open_review(D,'cat-harness-review',task,12)
Path('/tmp/carrier-cat-cable-20260912/review-root.txt').write_text(str(D)+'\n')
