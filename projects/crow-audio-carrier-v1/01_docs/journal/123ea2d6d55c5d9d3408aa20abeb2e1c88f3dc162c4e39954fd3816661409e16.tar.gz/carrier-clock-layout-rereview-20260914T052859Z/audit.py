#!/usr/bin/python3
import pcbnew,json,math,hashlib,runpy
from pathlib import Path
root=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
project=root/'projects/crow-audio-carrier-v1'
board_path=project/'06_build/route/r0.kicad_pcb'
b=pcbnew.LoadBoard(str(board_path))
regions={
 'CLK_WEST_DIGITAL': {'rect':[144.1,57.65,145.8,60.1], 'old_rect':[144.1,58.4,145.8,60.1], 'nets':['MCH_MCLK','FSYNC_BUF','MCH_BCLK']},
 'CLK_EAST_DIGITAL': {'rect':[148.2,58.3,150.2,60.2], 'old_rect':[148.2,58.3,149.65,59.65], 'nets':['BCLK_BUF','MCH_FSYNC','MCLK_BUF']},
}
clocknets=set(sum((v['nets'] for v in regions.values()),[]))
tracks=list(b.GetTracks())
def mm(v): return v/1e6
def ends(t): return [mm(t.GetStart().x),mm(t.GetStart().y),mm(t.GetEnd().x),mm(t.GetEnd().y)]
def capsule_bbox(t):
 x1,y1,x2,y2=ends(t); r=mm(t.GetWidth())/2
 return [min(x1,x2)-r,min(y1,y2)-r,max(x1,x2)+r,max(y1,y2)+r]
def contained(bb,r): return bb[0]>=r[0]-1e-9 and bb[1]>=r[1]-1e-9 and bb[2]<=r[2]+1e-9 and bb[3]<=r[3]+1e-9
def intersects(bb,r): return bb[2]>=r[0] and bb[0]<=r[2] and bb[3]>=r[1] and bb[1]<=r[3]
def desc(o):
 if isinstance(o,pcbnew.PAD): return f'{o.GetParentFootprint().GetReference()}.{o.GetNumber()} pad/{o.GetNetname()}'
 if isinstance(o,pcbnew.PCB_VIA): return f'via {mm(o.GetPosition().x):.3f},{mm(o.GetPosition().y):.3f}/{o.GetNetname()}'
 if isinstance(o,pcbnew.PCB_TRACK):
  e=ends(o); return f'track {e[0]:.3f},{e[1]:.3f}->{e[2]:.3f},{e[3]:.3f}/{o.GetNetname()}/{mm(o.GetWidth()):.3f}'
 return type(o).__name__
# Native copper obstacle list on F.Cu. Zones excluded from distance sweep because unfilled source zones have no stable effective fill;
# native refill DRC is the controlling zone/keepout test.
obs=[]
for fp in b.GetFootprints():
 for p in fp.Pads():
  if p.IsOnLayer(pcbnew.F_Cu): obs.append(p)
for t in tracks:
 if t.IsOnLayer(pcbnew.F_Cu): obs.append(t)

def nearest_foreign(t):
 s=t.GetEffectiveShape(pcbnew.F_Cu); best=None
 for o in obs:
  if o is t or o.GetNetCode()==t.GetNetCode(): continue
  try: d=mm(s.GetClearance(o.GetEffectiveShape(pcbnew.F_Cu)))
  except Exception: continue
  if best is None or d<best[0]: best=(d,desc(o))
 return {'clearance_mm':round(best[0],6),'obstacle':best[1]}
rows=[]
for t in tracks:
 if t.GetNetname() not in clocknets or not t.IsOnLayer(pcbnew.F_Cu): continue
 w=round(mm(t.GetWidth()),6)
 if w not in (0.18,0.36): continue
 e=ends(t); L=math.hypot(e[2]-e[0],e[3]-e[1]); bb=capsule_bbox(t)
 reg=next((name for name,v in regions.items() if t.GetNetname() in v['nets']),None)
 rows.append({'net':t.GetNetname(),'width_mm':w,'start':e[:2],'end':e[2:],'length_mm':round(L,6),
              'capsule_bbox_mm':[round(x,6) for x in bb], 'region':reg,
              'full_capsule_in_current_region':contained(bb,regions[reg]['rect']),
              'full_capsule_in_old_region':contained(bb,regions[reg]['old_rect']),
              'intersects_current_region':intersects(bb,regions[reg]['rect']),
              'nearest_foreign_fcu':nearest_foreign(t)})
# Eligibility/blast radius: tracks whose whole capsule satisfies region and net/width scoped rule.
elig=[]
for name,v in regions.items():
 for state,key in [('old','old_rect'),('current','rect')]:
  a=[]
  for row in rows:
   if row['region']==name and row['width_mm']==.18 and contained(row['capsule_bbox_mm'],v[key]):
    a.append(f"{row['net']}:{row['start']}->{row['end']}")
  elig.append({'region':name,'state':state,'eligible_0p18_tracks':sorted(a)})
# Any physical objects in expansion strips, irrespective of rules membership, to document blast radius.
exp=[]
for name,v in regions.items():
 current=v['rect']; old=v['old_rect']
 hits=[]
 for t in tracks:
  if not t.IsOnLayer(pcbnew.F_Cu): continue
  bb=capsule_bbox(t)
  if intersects(bb,current) and not intersects(bb,old): hits.append(desc(t))
 for fp in b.GetFootprints():
  for p in fp.Pads():
   if not p.IsOnLayer(pcbnew.F_Cu): continue
   box=p.GetEffectiveShape(pcbnew.F_Cu).BBox(); bb=[mm(box.GetX()),mm(box.GetY()),mm(box.GetRight()),mm(box.GetBottom())]
   if intersects(bb,current) and not intersects(bb,old): hits.append(desc(p))
 exp.append({'region':name,'objects_intersecting_added_area_only':sorted(hits)})
# assembly and dimensions
attrs={}
for fp in b.GetFootprints(): attrs[(fp.GetLayerName(),fp.GetAttributes())]=attrs.get((fp.GetLayerName(),fp.GetAttributes()),0)+1
edge=b.GetBoardEdgesBoundingBox()
# deterministic hashes used by project gate
mod=runpy.run_path(str(root/'skills/kicad-pcb/scripts/pre_route_review_check.py'))
parts=sorted((project/'02_parts').glob('*/part.yaml'))
parts_hash=hashlib.sha256(b''.join(p.relative_to(project).as_posix().encode()+b'\0'+p.read_bytes()+b'\0' for p in parts)).hexdigest()
net=project/'06_build/netlists/crow_audio_carrier_v1.net'
out={
 'pcbnew_version':pcbnew.GetBuildVersion(),
 'hashes':{
  'board':hashlib.sha256((project/'04_kicad/crow_audio_carrier_v1.kicad_pcb').read_bytes()).hexdigest(),
  'prepared_board':hashlib.sha256(board_path.read_bytes()).hexdigest(),
  'route_yaml':hashlib.sha256((project/'03_src/route.yaml').read_bytes()).hexdigest(),
  'floorplan_yaml':hashlib.sha256((project/'03_src/floorplan.yaml').read_bytes()).hexdigest(),
  'nets_yaml':hashlib.sha256((project/'03_src/rules/nets.yaml').read_bytes()).hexdigest(),
  'netlist_normalized':mod['netlist_digest'](net), 'parts':parts_hash,
  'design_rules':mod['design_rules_digest'](project)},
 'board_counts':{'footprints':len(list(b.GetFootprints())),'tracks_and_vias':len(tracks),'zones':len(list(b.Zones()))},
 'assembly':{'all_footprints_front':all(f.GetLayer()==pcbnew.F_Cu for f in b.GetFootprints()),
             'smd_front':sum(1 for f in b.GetFootprints() if f.GetAttributes() & 2 and f.GetLayer()==pcbnew.F_Cu),
             'smd_back':sum(1 for f in b.GetFootprints() if f.GetAttributes() & 2 and f.GetLayer()==pcbnew.B_Cu),
             'footprint_layer_attribute_counts':{f'{k[0]} attr={k[1]}':v for k,v in attrs.items()}},
 'board_edge_bbox_mm':[mm(edge.GetX()),mm(edge.GetY()),mm(edge.GetRight()),mm(edge.GetBottom())],
 'regions':regions,'clock_tracks':sorted(rows,key=lambda x:(x['region'],x['net'],x['start'])),
 'scoped_eligibility':elig,'expansion_strip_objects':exp}
Path('/tmp/carrier-clock-layout-rereview-20260914T052859Z/geometry-audit.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out['hashes'],indent=2)); print(json.dumps(out['assembly'],indent=2));
