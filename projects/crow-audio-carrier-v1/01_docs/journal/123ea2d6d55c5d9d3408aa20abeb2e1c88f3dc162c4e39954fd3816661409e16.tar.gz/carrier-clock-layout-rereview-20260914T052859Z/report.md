review_stage: pre-route
review_kind: layout
reviewer: Codex /root/pod_r3_layout_review carrier-clock ownership correction
context: FRESH
completed_at: 2026-09-14T05:31:40Z
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 54adf8ef221ff32ad711c234cc25dc60b96c40f64ee981a4404099a57f94bc7d
prepared_board_sha256: d0b28725833cc8c679138f6b98e13ba143eb299da74147903cfcd2059b3361fe
route_yaml_sha256: a1f09e6a54c9429f19461f8166086292651fe1ff718bb5f6e25097a27f5e113c
floorplan_sha256: ec65ec7cc8684b3d2d584063bcf2aec0dce372452ad98eb8e97ce4389080028c
nets_rules_sha256: af2c146b9269e73435a174fca10924bd0503b1507f07a9bfb48d7a1b346bcfa9
netlist_sha256: 92b0e78a814516676babdb65da635f508808ec1020c0d18c154afef6df6c8a15
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: 0e620140855c9c61444f52c02604c51c7feacf73c870d735eb9965a8cfd7ab70
digital_launch_test_sha256: 239832b20b3fdba35937941b51cf4258ebf41d5ee03292277840e514391b2543

# Fresh carrier PIN-01 ownership-correction layout re-review

## Verdict

SOUND. The exact current route source makes one coherent declarative correction: physically complete two-pad net BCLK_BUF is removed from the generic clock routing wave, added to the prep exclusion set, and assigned to `prep.seed_stubs` as its sole complete-net owner. The clock group now contains 11 partial/unrouted nets. No authored seed geometry, floorplan area, net rule, placement board or prepared r0 copper changed.

The physical clock launch remains sound under a newly executed geometry audit and a newly executed native DRC. This report is a new review of route SHA-256 `a1f09e...`; it does not copy or restamp the earlier report. Routing completion, post-route acceptance, release and ordering remain gated. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.

## Exact delta proof

Reversing exactly three current textual operations reconstructs the immediately preceding route source byte for byte at SHA-256 `de4a642b465ac3f626ef8c41bd350ca9dcceb3a7028b82f652b7e9b305d577c3`:

1. remove BCLK_BUF from `prep.waves.exclude`;
2. restore BCLK_BUF to `prep.waves.groups.clocks` after MCLK_BUF;
3. remove the BCLK_BUF `route.ownership.nets` record.

The complete generated diff is preserved as `ownership-correction.diff`. It contains only those three declarative changes. The 48 lines defining the MCH_MCLK and BCLK_BUF seed segments are identical; no coordinate, width, layer, rule region or clearance value appears in the delta. The changed semantic design-rule digest, `0e620140855c9c61444f52c02604c51c7feacf73c870d735eb9965a8cfd7ab70`, is therefore expected: ownership and wave membership are routing semantics even though physical geometry is unchanged.

The current physical files independently retain their dispatched hashes: floorplan `ec65ec7c...`, net rules `af2c146b...`, placement board `54adf8ef...`, and prepared r0 `d0b28725...`.

## Ownership correctness

BCLK_BUF has exactly two native pads: U_CLK.5 at `(148.4,59.75)` and R_BCLK.1 at `(149.99,60.0)` mm. Its authored seed is a continuous three-segment F.Cu chain whose endpoints are those pad centers:

- 0.18 mm from `(148.4,59.75)` to `(149.1,59.75)`;
- 0.18 mm from `(149.1,59.75)` to `(149.55,60.0)`;
- 0.36 mm from `(149.55,60.0)` to `(149.99,60.0)`.

It is consequently a complete source-owned local net and must not also be offered to the generic clock wave. Current `exclude`, 11-net `clocks`, and `route.ownership.nets.BCLK_BUF.owner: prep.seed_stubs` agree on that partition. This removes duplicate ownership without removing copper or leaving an endpoint for the router.

The current regression file SHA-256 is `239832b20b3fdba35937941b51cf4258ebf41d5ee03292277840e514391b2543`. Its new native-completion canary checks all ten digital source banks, proves BCLK_BUF reaches both native pads, requires both complete buffer outputs to be excluded and source-owned, and injects the old BCLK_BUF configuration to require a `complete-owner` failure. A fresh direct execution ran 10 tests in 11.013 seconds: all passed. The file hash was rebound at final report generation so no earlier frozen test image is relied upon.

## Fresh physical remeasurement

The new pcbnew audit loaded current r0 directly. BCLK_BUF's round-ended 0.18 mm capsules remain wholly inside `CLK_EAST_DIGITAL`: `[148.31,59.66]-[149.19,59.84]` and `[149.01,59.66]-[149.64,60.09]` mm. Their centerline length remains 1.214782 mm. Minimum native foreign F.Cu clearance remains 0.235000 mm at the U_CLK pad row, satisfying the scoped 0.20 mm rule. The 0.36 mm continuation retains 0.400549 mm foreign clearance, exceeding the ordinary 0.25 mm rule.

MCH_MCLK's two 0.18 mm capsules also remain wholly contained and total 1.265685 mm. Across all clock-region 0.36 mm continuations, the minimum ordinary foreign clearance remains 0.260000 mm. The scope expansion still introduces no unrelated full F.Cu pad, track or via. All 340 footprints remain on F.Cu; all 300 ordinary fitted SMD footprints are front-side and there are zero B.Cu SMD footprints.

## Fresh native r0 DRC

KiCad 10.0.4 reran all severities with zone refill and schematic parity on a newly copied, hash-identical r0 board. Results are unchanged because the physical subject is unchanged:

- 199 environment-only `lib_footprint_issues` warnings;
- 40 expected pre-route `track_dangling` warnings;
- 21 expected pre-route `via_dangling` warnings;
- 444 expected pre-route unconnected items;
- zero schematic-parity issues;
- zero clearance, collision, keepout, edge, width, drill, short, or other hard physical findings.

The dangling and unconnected rows are obligations for the completed-route gates and are not waived here.

FIRST-ARTICLE-ONLY / DO-NOT-ORDER.
