from pathlib import Path
import sys,tempfile,shutil,json,subprocess,hashlib
D=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';old=Path('/tmp/carrier-channel-authority-ax__1y39');root=Path(tempfile.mkdtemp(prefix='carrier-channel-source-correction-'));sys.dont_write_bytecode=True;sys.path.insert(0,str(D));from open_review import open_review
for n in ['project','authority']:shutil.copytree(old/n,root/n)
# Current source overrides every file already in the packet; complete native
# history stays the accepted pre-change generated subject, explicitly stale.
for p in (root/'project').rglob('*'):
 if p.is_file():
  live=P/p.relative_to(root/'project')
  if live.is_file():shutil.copyfile(live,p)
changed=[]
for n in subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R,text=True).splitlines():
 if n.endswith('.tar.gz'):continue
 p=R/n;target=root/'current'/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
 before=subprocess.run(['git','show','HEAD:'+n],cwd=R,capture_output=True)
 if before.returncode==0:
  q=root/'previous'/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(before.stdout)
 changed.append({'path':n,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size,'previous_exists':before.returncode==0})
 if p.is_relative_to(P):
  q=root/'project'/p.relative_to(P);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
(root/'changed.json').write_text(json.dumps(changed,indent=2)+'\n')
shutil.copytree(old/'06_build/task_runs/channel-authority/outputs',root/'electrical-authority')
for n in ['placement-proposal-native-check.json','channel-decision-preservation-result.json']:
 shutil.copyfile(D/n,root/n)
V=root/'validation';V.mkdir()
for prefix in ['channel-map-corrected-focused','channel-producer-original-red','channel-map-corrected-full','channel-corrected-contracts','channel-corrected-schema','channel-map-handoff-corrected']:
 for p in Path('/tmp/carrier-connector-integration-20260911').glob(prefix+'*'):
  if p.is_file():shutil.copyfile(p,V/p.name)
prior=Path('/tmp/carrier-channel-source-review-65wvio93/06_build/task_runs/channel-source-review')
shutil.copytree(prior,root/'original-review-runtime',ignore=shutil.ignore_patterns('scratch'))
for n in ['channel-source-review-provenance-note.json','channel-ledger-preservation-proof.json']:
 shutil.copyfile(D/n,root/n)
open_review(root,'channel-source-correction','''Agent-role judgment standard/full effort, FRESH. Independent review of the actual north channel association implementation. Root is sole implementation writer and freezes the current source while you review. Electrical proposal accepted independently in electrical-authority/report.md. This is source review, NOT canonical native schematic/layout acceptance; generated board/schematic in project remain explicitly old/stale. Exact current delta is current/ vs previous/, changed.json binds files; project/ contains complete current counterparts and prior generated source artifacts. Parent architecture delta included. Full corrected source336/336 PASS135.943s, focused6/6, contracts ratchet held; original logs in validation. Do not redundantly rerun336tests; independently inspect specific electrical/source semantics and use bounded targeted checks where needed.

Read original-review-runtime/outputs/report.md first. Original verdict NEEDS-CORRECTION is retained verbatim and closed, not silently upgraded. Two corrections now need fresh independent judgment: (1) actual TSX header rejects missing/blank ID, unknown keys, malformed mapping and south reordering; regression evaluated actual frozen old producer RED (1 failure/6 tests), current producer GREEN6/6. (2) adc_channel_map.json carries closed typed capture_requirements consumed by normal check_analog_paths, which emits actual map ID/raw source SHA, slot-to-pod, required serialized pods/cables/coordinates/epoch/impulse obligations, capture_identity_status OWED. The first_article.yaml owning reader is staged first-power rails, so adding post-power capture keys there would be unconsumed. The equivalent typed capture contract instead lives in the mapping JSON and normal source checker, linked from first_article.yaml comment and first-article plan. Assess whether this satisfies actual source/capture binding or identify a concrete remaining gap; no physical record is claimed measured. Source check runs after schematic generation, before routing; do not inherit original review's inaccurate before-generation claim. Root preserved exact historical nets requirement bytes and changed ONLY its ledger path, original hash/attempts/history untouched; proof included. Do not conflate that with resetting exhausted diagnostic history.

Use actual clock when writing completed_at; original report claimed future completion02:36 despite actual closure02:30:28. Its timestamp is explicitly non-authoritative, original preserved. No guessed or future timestamps.

Determine whether implementation coherently realizes pod1..8→ADC4,3,2,1,5,6,7,8, with fixed hardware slots0..7→pods4,3,2,1,5,6,7,8, while preserving physical assembly footprint/value/pose set, all external connectors/AFE/ISO/power/reference/clock/reset/south connectivity and polarity. Exact signal changes are eight north ADC input net memberships and eight CM logical-ref/pose associations. R_ADC_PD stays at ISO. Analog seed geometry is unchanged with8netlabel updates; path endpoints and part ADC adjacency/keep_short authority follow the same physical terminal pairs without wider budgets. North ordering shouldbe0inversions andsouth0. JSON is new committed source authority, consumedbyTSXandpathchecker; unknown/duplicate/wrong-domain/missing identity issues must fail; sourcecheckpointcensus mustbindimported JSON. Check sourceinventory/producer mapping and independent geometry tests do not hide mismatches by sharing method. Reopen allconstraints, typedmap source consumers, adjacency/keep_short and complete 24groups/48nets/192endpoints/144paths (northADCsubset8/32/24/4). Inspect/report any schema/contract/recording-identity or no-custom-firmware gaps. New ADR0027 and current parent architecture govern prospective capture map; historical research/report and immutable releases are not edited.

Root rejected local ten-cap proposal: exact native shape check records22directed courtyard violations and112 mixed body/pad/old-seed failures; no geometry from that plan adopted. Do not inherit its spurious minimum-clearance claim. Root retains3/3 exhausted route history; no new source routing/candidate/attempt is part of this implementation. Old layout review remainsopen/staleonnewsubject. A SOUND sourceverdict permits normal regeneration and fresh independent schematic/pin/render/layout gates, never directrouting or release.

Deliver complete noncanonical source-review report with exact changed-file coverage, before/after node/part/physical mapping proof, source tests/contract controls actually inspected vs carried, legitimate regeneration/remaininggates. If a defect exists, name minimal corrective source delta, no root edits/no self-repair. All new outputs onlyallocatedscratch/outputs. Do not touch READ_ONLY inputs with native tools. Where packet-relative imports need tools, use supplied authority or hash-verify exact live shared files before using them, explicitlybindextras; no unrecorded source inputs. No networkneeded; manufacturer fact authorityalreadyretained. Oneboundedreview, nochildren.''',16)
