subject: crow-audio-carrier-v1 north ADC channel-map corrected source implementation
date: 2026-09-11
reviewer: Codex judgment agent /root/carrier_channel_source_correction
context-given: FRESH; immutable 454-input correction packet
source_commit: f2675b431c4372a1a81d0fdfa0ca81f0a27ecd68 (packet delta is uncommitted relative to this base)
review_stage: pre-route source correction
review_kind: noncanonical source review; generated native schematic/layout artifacts remain stale
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 9aa1c2c821a31129176a8b519b9a211d78dfc011adb997a64470c03d0726891f (stale before-state only)
design_rules_sha256: 5891d8028d9864ea0503dc3f63c7520efca45ece640c9db65423680f85b88712
task_identity: task_id=channel-source-correction; run_id=channel-source-correction; input_handoff_id=channel-source-correction; stage_id=KICAD-PLACEMENT
envelope_subject_raw_sha256: 6c246bfcc6af0b0b66561104013d6032e1020e71aad10c44eadbef642cda72f9
envelope_subject_semantic_sha256: fe312b14254dfd1e220f7bb42855d97480edff39fc724d0ad7428a0bae56bc4d
reviewer_provenance: independent corrected-source judgment; no implementation, regeneration, routing, or native acceptance
supersedes_review_verdict: none; original NEEDS-CORRECTION report remains immutable and closed
correction_disposition: both original source-contract defects closed
layout_finding: LAYOUT-001
layout_finding_state: OPEN
layout_finding_class: missing_simultaneous_corridor_evidence
diagnostic_request: simultaneous_source_corridor_reservation
diagnostic_nets: ADC1P,ADC1N,ADC2P,ADC2N,ADC3P,ADC3N,ADC4P,ADC4N
diagnostic_pad_denominator: 32
diagnostic_path_denominator: 24
diagnostic_pn_groups: ANALOG_CH1_ADC,ANALOG_CH2_ADC,ANALOG_CH3_ADC,ANALOG_CH4_ADC
diagnostic_max_spread_mm: 1.0
diagnostic_layers: F.Cu,B.Cu
diagnostic_track_width_mm: 0.20
diagnostic_clearance_mm: 0.20
diagnostic_via_mm: 0.50/0.20
diagnostic_reference_plane_proof: OWED
diagnostic_promotion: FORBIDDEN
north_before_channel_inversions: 6
north_after_channel_inversions: 0
south_before_channel_inversions: 0
south_after_channel_inversions: 0
completed_at_utc: 2026-09-12T02:44:45.094057Z

# Corrected north ADC channel-map source review

## Verdict

**SOUND for normal regeneration.** The corrected source coherently realizes `pod_to_adc=[4,3,2,1,5,6,7,8]`, hence fixed hardware slots 0–7 identify pods `[4,3,2,1,5,6,7,8]`. The two defects in the closed original review are resolved. This is a source verdict only: it does not accept the stale generated schematic, netlist, board, r0, DRC, locator, routing, planes, first article, or ordering.

The producer header now requires the exact top-level keys `capture_requirements,id,pod_to_adc,schema`, schema integer 1, a trimmed nonempty ID, and an array before dereference. Its mapping check requires eight unique integer channels 1–8, keeps pods 1–4 inside ADC1–4, and fixes pods 5–8 to ADC5–8 in order. The focused regression exercised the actual corrected TSX producer and passed 6/6. The same test against the packet's frozen original producer failed 1/6 exactly at the hostile-header test: it accepted extra, missing, blank-ID, or malformed cases. This is a meaningful red/green closure of defect 1.

The capture binding is also substantive. `adc_channel_map.json` is the committed typed authority and `check_analog_paths.py` reads its raw bytes, rejects duplicate JSON keys, requires the exact capture object, computes the raw SHA-256, derives the inverse slot table, and emits source path, map ID, digest, pod table, slot table, all capture obligations, and `capture_identity_status=OWED`. The closed record contract requires `map_id`, `map_sha256`, `slot_to_pod`, pod and cable serials, surveyed pod coordinates, stream epoch, and impulse evidence; it requires 8/8 channels and rejects missing, duplicate, swapped, inverted, or unstable identity. The hostile test mutates each obligation and verifies rejection, then independently recomputes the raw digest. The first-article plan requires the same prospective record and the first-power YAML points to the owning post-power contract without claiming measurement. Keeping those post-power fields out of the staged rail card avoids an unconsumed parallel schema. This closes defect 2.

## Mapping and preservation proof

| Pod | Before physical ADC / pins P,N / slot | After physical ADC / pins P,N / slot | Result |
|---:|---|---|---|
| 1 | ADC1 / 40,39 / 0 | ADC4 / 48,47 / 3 | north association only; P/N retained |
| 2 | ADC2 / 42,41 / 1 | ADC3 / 46,45 / 2 | north association only; P/N retained |
| 3 | ADC3 / 46,45 / 2 | ADC2 / 42,41 / 1 | north association only; P/N retained |
| 4 | ADC4 / 48,47 / 3 | ADC1 / 40,39 / 0 | north association only; P/N retained |
| 5 | ADC5 / 14,13 / 4 | unchanged | south control |
| 6 | ADC6 / 16,15 / 5 | unchanged | south control |
| 7 | ADC7 / 20,19 / 6 | unchanged | south control |
| 8 | ADC8 / 22,21 / 7 | unchanged | south control |

The TSX inverse lookup produces the table above from the one JSON authority. The independent test instead starts from the fixed physical pin table and native source geometry, pairs P/N, and compares the observed slot order with the checker result. North ISO endpoints and ADC endpoints are both left-to-right logical `[1,2,3,4]`, reducing 6 channel and 24 cross-conductor inversions to zero; south remains zero.

The electrical delta is exactly eight north U_ADC input-net memberships. Eight north `C_ADC_CM` logical refs exchange their existing poses so each stays at its physical ADC terminal. The multiset of those eight `(x,y,rotation)` poses is unchanged; all 325 other poses compare exactly; the source inventory remains 333 components with a common value/footprint across the exchanged capacitors. All eight north seed stubs retain pin, layer, width, and points and change only net label. `R_ADC_PD1..4` remain at the corresponding U_ISO logical pods. No external connector, AFE, ISO, power, VMID/reference, clock, reset, south path, polarity, fitted value, footprint, or hardware-mode definition changes.

The ADC common-mode adjacency records migrate with the physical locations and keep the original per-location ceilings: P/N channel positions retain 5/5, 3.5/4.5, 2.5/2.0, and 4/4 mm. `keep_short` remains 5 mm while pins follow 48/47, 46/45, 42/41, and 40/39. The four north main endpoints in `rules/nets.yaml` follow those pins; all shunt and bias endpoints stay on their logical pod nets. The complete checker covers 24 groups, 48 nets, 192 distinct endpoints, and 144 paths; the north ADC subset is 4 groups, 8 nets, 32 endpoints, and 24 paths. The 1.0 mm group ceiling, 0.5 mm routing match tolerance, stack, ordinary 0.50/0.20 mm via, and 0.20 mm track requirements are not widened.

## Changed-file coverage

I inspected all 23 entries in `changed.json`. The implementation-bearing set is the TSX producer; new JSON authority; analog checker; ADC dossier; floorplan, route, nets and first-power rules; fanout and channel-map tests; and the `03_src` contract. Documentation/governance changes are the child architecture, brief, first-article plan, status, docs contract, ADR0027, retained pre-map nets evidence, findings ledger pointer, journal contract and journal entry, handoff, and parent architecture. The retained net requirement file is byte-identical to the historical SHA `34dd314e...d411bb`; only the ledger path moves to that preserved preimage, with attempt history and 3/3 cap unchanged. The rejected ten-cap placement is not present in source.

The live status/journal lines retain the earlier 334/334 result as a time-stamped implementation event; the correction packet separately and unambiguously records the later 336/336 run. This provenance lag does not alter executable source or the current validation evidence.

## Inspected controls and carried evidence

I directly inspected the corrected and previous TSX headers, map JSON, checker validation/emission, all six focused tests, first-article pointer and plan, source contracts, exact changed-file census, ADC pins, nets, floorplan, seed routes, part adjacency/keep-short, ledger preservation proof, ADR0027, child/parent architecture, handoff, original review, and electrical authority. I also viewed the stale native top locator at original detail to corroborate the physical north/south rows and central ADC only; it provides no connectivity or clearance acceptance.

Carried, not rerun: corrected focused 6/6 PASS in 3.619 s; frozen-original producer RED with one failed test out of six; corrected full source 336/336 PASS in 135.943 s as summarized by the packet (runtime record 136.279 s); schema and contract ratchets; handoff generation; and the independent electrical-authority SOUND verdict. The full suite was deliberately not rerun. All 454 envelope inputs passed exact size/SHA-256 verification before and after this review.

## Legitimate next step and remaining gates

This verdict admits the ordinary regeneration path only. Regenerate circuit JSON, schematic PDF, native schematic and netlist, PCB/r0, DRC and locator from the accepted source. Then obtain fresh independent topology, pin-map, schematic-render, placement/layout, render, and canonical pre-route reviews against the new exact hashes. The source checker correctly runs after schematic generation/netlist export and before board generation/routing.

`LAYOUT-001` remains open with 3/3 diagnostic attempts spent and no pending or fourth attempt. Simultaneous legal north routing, all 32 pads/24 paths, <=1 mm P/N spread, filled In1.Cu/In2.Cu reference continuity, DRC 0/0/0, parity, physical ADC-to-USB slot enumeration, serialized capture identity, 8/8 impulse proof, first article, release, and ordering remain owed. No custom firmware or runtime reorder is required by this implementation; every capture must use the frozen slot-to-pod/coordinate contract.

No source, generated artifact, board, route candidate, release, or live repository file was written in this review. No native/PDF process, router, network operation, or install ran.
