#!/usr/bin/env python3
import hashlib, json, sys
from pathlib import Path

root = Path('/tmp/carrier-channel-source-correction-xwwcji9x')
env = json.loads((root/'06_build/task_runs/channel-source-correction/envelope.json').read_text())
rows=[]
for item in env['input_packet']:
    p=root/item['path']
    exists=p.is_file()
    size=p.stat().st_size if exists else None
    sha=hashlib.sha256(p.read_bytes()).hexdigest() if exists else None
    rows.append({'path':item['path'],'expected_size':item['size'],'actual_size':size,
                 'expected_sha256':item['sha256'],'actual_sha256':sha,
                 'status':'PASS' if exists and size==item['size'] and sha==item['sha256'] else 'FAIL'})
out={'checked_at_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat().replace('+00:00','Z'),
     'count':len(rows),'pass':sum(r['status']=='PASS' for r in rows),
     'fail':sum(r['status']!='PASS' for r in rows),'rows':rows}
Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n')
if out['fail']: raise SystemExit(1)
