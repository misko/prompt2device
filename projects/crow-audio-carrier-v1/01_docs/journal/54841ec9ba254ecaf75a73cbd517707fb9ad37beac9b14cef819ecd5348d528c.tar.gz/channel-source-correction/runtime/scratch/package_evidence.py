#!/usr/bin/env python3
import gzip, hashlib, io, json, tarfile
from pathlib import Path

run=Path('/tmp/carrier-channel-source-correction-xwwcji9x/06_build/task_runs/channel-source-correction')
scratch=run/'scratch'; outputs=run/'outputs'
members=['verify_inputs.py','input-verification-before.json','input-verification-after.json','review-observations.json']
rows=[]
raw=io.BytesIO()
with tarfile.open(fileobj=raw,mode='w',format=tarfile.PAX_FORMAT) as tf:
    for name in members:
        p=scratch/name; data=p.read_bytes()
        info=tarfile.TarInfo('scratch/'+name); info.size=len(data); info.mtime=0; info.uid=0; info.gid=0; info.uname=''; info.gname=''; info.mode=0o644
        tf.addfile(info,io.BytesIO(data))
        rows.append({'path':'scratch/'+name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
archive=outputs/'evidence.tar.gz'
with archive.open('wb') as f:
    with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as gz: gz.write(raw.getvalue())
manifest={'schema':1,'members':rows,'archive':{'path':'evidence.tar.gz','size':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(outputs/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
