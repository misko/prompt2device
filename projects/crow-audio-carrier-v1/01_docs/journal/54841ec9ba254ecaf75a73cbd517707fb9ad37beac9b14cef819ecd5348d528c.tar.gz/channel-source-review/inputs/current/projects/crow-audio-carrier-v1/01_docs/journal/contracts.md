# contract: 01_docs/journal/

**Purpose** — the per-stage diary (canon M9). The knowledge-evaporation
failure: a run's hardest analysis lived only in an agent's chat report and
died with the session. Journals capture it AS IT HAPPENS, per stage.

**Mutability** — APPEND-ONLY. An entry is a record of what happened, not a
document to polish. Never rewrite history; a wrong entry gets a correcting
entry.

## Allowed

| Pattern | What |
|---|---|
| `<stage>.md` | one journal per pipeline stage (`02_parts.md`, `03_schematic.md`, `placement.md`, `routing.md`, `verify.md`, ...) |
| `contracts.md` | this file |

## Entry structure (every stage start / iteration / finish / stuck)

    ## <YYYY-MM-DD HH:MM> — <start|iterate N|finish|stuck|iterate N (post-back)|handoff>
    - did: <the action, one line>
    - result: <MEASURED outcome — gate output, counts; never hope>
    - next: <what this implies>

A `stuck` entry is MANDATORY before backtracking (SKILL.md D-BACK): it
records the stagnation trigger (3 no-improvement iterations, or an
inexpressible finding class), the measured plateau, and the causal
hypothesis being carried upstream. The learnings block for the issue is
written at that moment, not at stage end.

## Audit

- `policy_audit` M-JRNL: once the design produces artifacts (a board or a
  promoted route), at least one journal with `## ` entries must exist.
- Entries reference measured numbers; an entry whose `result:` is a claim
  without a command output behind it is a defect in review.

## Allowed exact retained execution bundles — 2026-09-11

These closed forensic records are append-only and confer no review acceptance. They live with the stage diary; no source-evidence census or gate input is excluded or reclassified.

| Pattern | What |
|---|---|
| `65e1f7530a5060c221d4f2b486ef01b524e34f5e2488a5fa1d3369a73558e9a8.tar.gz` | Closed INCOMPLETE readability attempt, original five outputs, raw export archive, packet metadata and independent diagnosis |
| `5a6fe2908e1e9b545c5002b12d4234888eb7c4c50eb2fada6bba10c547fd461d.tar.gz` | Exact immutable 236-member review subject archive |
| `schematic-current-delivery-20260911-manifest.json` | Whole-archive and member size/SHA-256 inventory; independent reopen audit |

Audit: verify both whole-archive SHA-256/size records; reopen every regular member against its named manifest, reject duplicate/link/traversal entries. The delivery archive embeds the unchanged subject manifest for the second archive. Retain the failed terminal status and original result.json.

## Allowed exact closeout validation — 2026-09-11

| Pattern | What |
|---|---|
| `02ffea45528b752ad044bde59d2fe6fc1f2f4a4249669b99cc5f458d6966dd7c.tar.gz` | Root preservation/checkpoint/contracts commands and full logs, including original contract-heading failure and corrected pass; exact inner MANIFEST.json |

Audit: whole archive SHA-256 equals filename; reopen all ten payload members against inner MANIFEST.json, reject extra/link/duplicate/traversal members. Archive size 53869 bytes.

## Allowed connector prerequisite evidence — 2026-09-11

| Pattern | What |
|---|---|
| `328528f2116759df2aba282c7bb45d497b0e88ebc6738c3e5b2e32595aca4dd9.tar.gz` | Isolated Samtec model candidate, source drawings/encoder, native qualification and clean/inverted registration coupons, exact public retrieval failures and all setup logs; no live-design acceptance |

Audit: SHA-256 equals archive filename; size 1102111 bytes. Reopen all 115 payload members against inner MANIFEST.json; reject links, duplicates, traversal and undeclared members. Candidate adoption requires separate source review and regeneration.

## Allowed source-to-native connectivity diagnostic — 2026-09-11

| Pattern | What |
|---|---|
| `36b9bb5bd36e2148c77812f567288081f7a1fee4db89b4c80249b47cbbd8ebd3.tar.gz` | Frozen source/native endpoint comparison, exact inputs, three serialized negative controls, predecessor bindings and successful isolated replay; no accepted review |

Audit: archive SHA-256 equals filename; size 621607 bytes. Reopen all 35 payload members against MANIFEST.json; reject extra, duplicate, link and traversal entries. Replay uses the retained original delivery archive.

## Allowed accepted schematic correction evidence — 2026-09-11

| Pattern | What |
|---|---|
| `66a4714eeef41cc6a64603fe16fca8a86c3ead9cecd302083df722f189de1380.tar.gz` | Original-subject continuation correction, exact new handback, timely terminal PASS, availability proof, native qualification, independent reopen and owning gate receipts |

Audit: outer SHA-256 equals filename; size 28546990 bytes. Reopen all 70 payload members against MANIFEST.json; reject extra, duplicate, link and traversal entries. Prior failure and subject archives remain immutable; acceptance scope is schematic only.

## Allowed placement orientation stop — 2026-09-11

| Pattern | What |
|---|---|
| `47dcdd3f24035d7d1c3ba27b86d290f252b9ab56a2216581f52f9c6724994508.tar.gz` | Fresh placement runtime/handback, exact packet, raw DRC and deterministic route-prep seed, independent source verification; domain stopP-ORIENT, no layout acceptance |

Audit: filename equals outer SHA-256; size 2989635 bytes. Verify all 36 payload members against MANIFEST.json; reject extra/duplicate/link/traversal entries. Retain distinction between complete execution and failed domain gate.

## Allowed connector model source diagnosis — 2026-09-11

| Pattern | What |
|---|---|
| `42d7b629273e2ac5f04c0be0b829e5c407f80a759243c3f0dff5568570bc1d86.tar.gz` | Closed INCOMPLETE source-author attempt, exact immutable packet, 13-file unadopted source candidate, native model-registration evidence and truthful orientation-frame failure, primary KiCad renderer source and root forensic reopening; no promotion or human approval |

## Allowed connector source and frame integration — 2026-09-11

| Pattern | What |
|---|---|
| `91d704fbbdd6ebf529e29e52a66186d85d5b1685c1ef4fe7bc69d5db112def60.tar.gz` | Independently reviewed model proposal, checker native qualification and RED/GREEN evidence, timely closed attempts, failed/corrected availability probes, root verification and preserved prior checkpoints/generated/review bytes; no human approval |

## Allowed connector integration validation — 2026-09-11

| Pattern | What |
|---|---|
| `151373a3de0ec6f6e34d6a018f4aab669795b8138cbcaf56fc17f4e83f657eb1.tar.gz` | Root integration tests and raw failure/correction receipts, exact adopted source verification, preserved bundle identity and measured stale-checkpoint diagnosis |

## Allowed connector-integrated canonical restart — 2026-09-11

| Pattern | What |
|---|---|
| `ae0599ccdfc50e5952efb655a6d3039640b83ab8e37e646bf6a7600a3b1627e9.tar.gz` | Timely closed mechanical restart, exact old and regenerated subjects/checkpoints, fresh availability, full process logs and root unchanged-geometry/date/hash-caption comparison; review acceptance remains owed |


## Allowed integrated schematic delta review evidence

| Pattern | What |
|---|---|
| `6096a20189a8e26f61716f5aafdb276eb2e60c8ec9ec4d4d37036d9631d82c17.tar.gz` | Immutable fresh delta-review packet, timely terminal attempt, exact witnesses, independently reopened evidence and root adoption proof; not physical/order acceptance |


## Allowed schematic delta adoption validation

| Pattern | What |
|---|---|
| `9d515098b304e7ff7a86a48001029065aeddee40eab51fc4796c56b639f39ee7.tar.gz` | Immutable raw adoption, owning-review, source-checkpoint, contract/template tests, full membership and handoff-validation logs; prior failures retained |


## Allowed live connector human-review boundary evidence

| Pattern | What |
|---|---|
| `2fe3d6466a783543b7d58f25553c8d279007f92d8fc0c5006ddd0a88fd74ba42.tar.gz` | Immutable completed mechanical handoff, current native gate receipts, exact board/model/orientation bundles, supplemental native views and explicit raw-log limitation |


## Allowed connector human packet final validation

| Pattern | What |
|---|---|
| `56d13de3f5864533729ca315dfceae8868c557e3f4bf35353c5714c5dcd9ced6.tar.gz` | Immutable exact image-report audit, full membership, unchanged-source checkpoint, preservation and handoff validation raw logs and receipts |


## Allowed exact pin-review preparation evidence

| Pattern | What |
|---|---|
| `95931c7c83611c78260b8bbc31b3bdc0ddc7de2e9c88e97cea8dc174d72f14a9.tar.gz` | Immutable 333 conclusion-free pin dossiers, exact58part authority index, current board/source identities, maintained extractor and complete runtime logs; preparation only, no review verdict |


## Allowed connector approval and placement review admission evidence

| Pattern | What |
|---|---|
| `79a752442e67f0531ebadc1b11e19c59163b4ffff3391709c12c44a7612c07fa.tar.gz` | Exact user orientation approval, unchanged semantic-subject proof, original image binding, native regrade and regression logs, fresh availability receipt, grouped review commissions and preliminary rotation worklist provenance |


## Allowed first complete placement pin-review evidence

| Pattern | What |
|---|---|
| `756d5a83152a65d884c0c595749246352e270ded163e4eec7a2a715e9af6dad1.tar.gz` | Seventeen immutable fresh grouped pin reviews, all333refs/58MPNs, original FAIL/QUESTION judgments, exact inputs and evidence archives, root complete-member reopening, generated-winding RED/GREEN correction and full333dossier delta proof |


## Allowed independent placement rotation authority evidence

| Pattern | What |
|---|---|
| `cf21e0f44ebe114614ebf7060cc7bea500c5202648d47399021cccfdb72f9218.tar.gz` | Four immutable independent rotation/polarity reviews, exact13code proposals, native/manufacturer/catalog evidence, actual delivery closure, original authority table and root input/member reopening; geometry/model holds remain explicit |


## Allowed focused placement resolutions

| Pattern | What |
|---|---|
| `3dd9480740d3cc3930965533c8c31c050effc50244c4e6a2fc4ed671ef15c2e1.tar.gz` | Immutable corrected pin, connector application/physical-numbering, and incomplete layout reviews; complete input/delivery/archive reopening; rotation evidence-date correction and preliminary export raw outcomes |


## Allowed preliminary assembly recovery evidence

| Pattern | What |
|---|---|
| `5595edc7d5430a2d87247dad35c289e484bb164f6a8648b7ea45c0baf3c2ba36.tar.gz` | Immutable four independent assembly/layout-method reviews, exact input and output verification, manual-body portability RED/GREEN and relocated bundle, unchanged-geometry population projection; diagnostic only |


## Allowed SOT23 source resolution

| Pattern | What |
|---|---|
| `d2ae8a6316df79e4ed257efc6212c9de35dcec8cc303e04c93951e8f8a17eddc.tar.gz` | Immutable independent exact Diodes land correction and AOS native-land acceptance, primary authority chain, figures and full packet/delivery reopening |


## Allowed native representation and exact land recovery

| Pattern | What |
|---|---|
| `5122cd87132f39095b0a4a7f4ed6a51409a95ca6ac2452b618131dd7b0d8f5d9.tar.gz` | Immutable strict native representation implementation/tests, signed package registration, actual twin/overlay/relocation and hostile refusal, exact Diodes source projection, corner-aware land dispositions, primary CAD-absence responses and closed corridor-method D-BACK |


## Allowed catalog absence source review

| Pattern | What |
|---|---|
| `df2f98a2383b8f2729b092668414dc3138f6165573b85c070eb57a9212d85afe.tar.gz` | Immutable independent nine-reference catalog absence source review, unresolved copper authority, primary figures and full packet/delivery reopening |


## Allowed Yageo mounting authority

| Pattern | What |
|---|---|
| `35fb5e4d6ae4cbb024232e072c16d7c6f55b8cd28da34ce7393d39e80ccb4132.tar.gz` | Immutable independent primary Yageo mounting specification and existing resistor land compatibility judgment; full packet/delivery reopening |


## Allowed exact fuse land and pin review

| Pattern | What |
|---|---|
| `eeb525961ef086b18a6283164190e03877a4d4ee8eb78dec2b7b36c7bbb297a3.tar.gz` | Immutable independent exact eight-fuse manufacturer land, all sixteen pins and all-neighbor placement clearance review of isolated source projection |


## Allowed source test migration review

| Pattern | What |
|---|---|
| `525abf7960820751be935c6abf99a7d1475a1ea2cf5e8d8a5d74a2fe37011ea1.tar.gz` | Immutable independent source-only test geometry migration review, proposed patch and bounded partial replay; canonical identity failures retained |


## Allowed exact small component delta review

| Pattern | What |
|---|---|
| `2db657e7ad7b7943151f1345ca1591b8adcb23bb71588307b5772e4bb20bc000.tar.gz` | Immutable independent two-FET and resistor eight-pin, native body, land compatibility and all-neighbor clearance review |


## Allowed CAD absence integration checkpoint

| Pattern | What |
|---|---|
| `a07c6023a358f1d1b19ede343990e21673f7ee19d0e8c81723b2e059b8c96617.tar.gz` | Immutable catalog absence/raw receipts, full native twin and registration outputs, source delta proofs, clean/hostile tests and failed attempts, plus prior guards/generated source companions for verified canonical restart; review and release acceptance remain separate |


## Allowed native CAD retention code and visual review

| Pattern | What |
|---|---|
| `f7453944901ae2f835d33c2bc9a015fc093cc865aa543afd28eca1d11b87a581.tar.gz` | Immutable independent strict native CAD absence code and nine-ref image review; original Fab text contamination FAIL retained with full output verification |


## Allowed final corrected native twin proof

| Pattern | What |
|---|---|
| `dd7baa8a54038c596044b3adf309518adf0151c86b9f008245b7a8a173713615.tar.gz` | Immutable corrected and relocated333-body twin, six current native registration groups,13reviewed images unchanged, Fab-label regression RED/GREEN and final method tests; no canonical or release acceptance |


## Allowed native source checkpoint validation

| Pattern | What |
|---|---|
| `cd4563d1694c243cd7c45948cdbf4fedbebb19f7424dcb845deacd5be9059052.tar.gz` | Immutable final contract/disclosure checks, corrected typed schematic handoff with original invalid-stage invocation retained, validation and archive receipts |


## Allowed passive canonical source-gate stop

| Pattern | What |
|---|---|
| `242494760416463bbbe12d9185dbf727a65a3d4988b0f022763ea87e4d73a2d8.tar.gz` | Immutable first passive canonical restart: actual closed delivery, source/ownership packet, qualification, stage timing and explicit missing raw stdout limitation; root guard/archive verification and independent schema failure/correction |


## Allowed logged passive canonical renewal

| Pattern | What |
|---|---|
| `be9590dde24205b1246a0ad77f1a6467b20bf785d6d8e5be0705934ab8bb2394.tar.gz` | Immutable logged canonical renewal, exact generated schematic/netlist/PDF/checkpoints, complete original per-stage raw logs and corrected root command interpretation, 574-input reopening, 328 source tests and fresh reviewer availability |


## Allowed accepted passive schematic delta review

| Pattern | What |
|---|---|
| `03425bd69a3d46d1151ccfac4688122020b25114bea3030d4fae0980ffd0d6d4.tar.gz` | Immutable complete fresh passive topology/readability delta review packet, exact two witnesses, raw native/PDF comparison and visual evidence, timely delivery and root reopening |


## Allowed passive schematic acceptance validation

| Pattern | What |
|---|---|
| `92bc0c9fe3dc1f4c07120c54761ba27b5efd9e39fb91cc8fdc66b2151f15b5c0.tar.gz` | Exact schematic acceptance and handoff checks, root typed-packet access correction with original failure, preserved artifact receipts and unexecuted next placement runner/commission drafts |


## Allowed current placement and failed visual review evidence

| Pattern | What |
|---|---|
| `62c6af4c5ae768eda0f15c047405ab81c30a36c55870b09dba4cc32fdc58e884.tar.gz` | Exact logged placement, failed and corrected reviewer availability, pin continuity proof, fresh visual DEFECTIVE judgment, unexecuted pilot proposal, immutable packets/raw logs and root reopening |


## Allowed current placement closeout and label diagnosis

| Pattern | What |
|---|---|
| `432a608944dbff8eee97b3cf3e62d3731147e891ea5c36e2fef125a3b20ff1af.tar.gz` | Root current placement audit/closure raw failures and corrections, two bounded scratch-only label arrangements, exact scripts/results and input checkpoint; no layout or source repair acceptance |


## Allowed caption repair and locator proposal evidence

| Pattern | What |
|---|---|
| `2b632c378e100bf4c284d2120531856d4b7fc4ff258412886a16d35e86c9a5a8.tar.gz` | Complete rejected silk experiment review, new source caption/signed-side diagnostics, all333 offline locator/25-page atlas proposal and immutable fresh review input packet, source regression logs and failures; no canonical review or waiver adoption |

## Allowed locator implementation evidence

| Pattern | What |
|---|---|
| `d9c827a625af3b04be80a2df43c04b7dfd108b645a0e2c618e2bb179574e0f7b.tar.gz` | Closed independent locator proposal review and fresh availability, shared implementation and hostile controls, current source/export snapshots, and immutable fresh implementation-review inputs; no canonical placement or release acceptance |

## Allowed pre-locator-renewal canonical preservation

| Pattern | What |
|---|---|
| `8e73749f81ce3605f5275f2d5077e01fb009662019720596dbed4d86a4339cb9.tar.gz` | Exact outgoing canonical board/schematic, checkpoint-bound generated companions, all present prelayout guards and native prepared sidecars plus current independent reviews. Preservation only; no guard retirement or renewal claimed |

## Allowed accepted locator implementation and original failures

| Pattern | What |
|---|---|
| `d4712f90432ba674928f4abd0650e66b437aacfb6a702fa274aa49acb492136e.tar.gz` | Closed frozen implementation review INCOMPLETE plus independently accepted correction supplement, all original false-positive evidence, exact adopted correction, actual RED/GREEN controls, harness/library-inventory repairs and scoped root reopening. No canonical render acceptance |

## Allowed locator canonical renewal evidence

| Pattern | What |
|---|---|
| `561e2fc9a282153058a0020034d72e6cc6c287f1e1ae0ea9183bc714b8277a15.tar.gz` | Closed canonical renewal, complete raw commands and qualification, source/checkpoint reopening, archive-bound guard retirement, generated schematic artifacts, preceding final source checks and fresh live reviewer availability |


## Allowed accepted locator schematic delta review

| Pattern | What |
|---|---|
| `d7b8b8b63574e331473104b6703a873febb03958d298ff3b4a2b2eae818f8d9a.tar.gz` | Immutable complete fresh locator topology/readability delta review packet, exact two witnesses, raw native/PDF comparison and visual evidence, timely delivery and root reopening |


## Allowed Cat5e source review — 2026-09-12

| Pattern | What |
|---|---|
| `e5d2ae09d09a810479eb41f1a68f4259eb98369247de8e4e1ca1126a88b4acbd.tar.gz` | Closed independent Cat5e source review, original findings and verified supplement, adopted source and exact manufacturer PDFs, owning interface/source/full-phase gates and raw regressions |

Audit: archive SHA256 equals filename; size3832087bytes. Reopen all180
payload members against manifest.json; reject missing, extra, duplicate, link
or traversal entries. Full physical gates remain INCOMPLETE; no route or
release acceptance is conferred.


## Allowed Cat5e source closeout — 2026-09-12

| Pattern | What |
|---|---|
| `54556c43fb54037a83f3b766193a76f21f2d40b5f110da1d749fdf8adb5d90e0.tar.gz` | Exact failed/corrected membership and handoff validation, preserved historical requirement bytes, current ledger and compact handoff |

Audit: SHA256 equals filename; size69009bytes, 25payload
members verified against manifest.json. Reject extra, missing, duplicate or
non-regular members. This retains the original failures and does not confer
physical or release acceptance.

## Allowed pre-Cat placement and render preservation

| Pattern | What |
|---|---|
| `fac1c1d8d65d4e74cde722cf173dbae2e790057277e128886074a59ad8c51d42.tar.gz` | Closed placement, exact current assembly/twin/locator/native images, fresh render and diagnostic-method review, availability and failed layout launch. Cat changes invalidate current whole-contract acceptance; historical records are retained unchanged |

Audit: filename equals SHA256; 390558155bytes, 2218payload members independently reopened against MANIFEST.json; reject extras, duplicates, links or traversal. Source preimages recovered from f7fd347e only when their original envelope hash matched. No routing acceptance.

## Allowed pre-cat-renewal canonical preservation

| Pattern | What |
|---|---|
| `25b058ed2c5dc337024624ae8928641c99f3cac61d200aa8c7ff56fd733b3d4d.tar.gz` | Exact outgoing canonical board/schematic, checkpoint-bound generated companions, all present prelayout guards and native prepared sidecars plus current independent reviews. Preservation only; no guard retirement or renewal claimed |

## Allowed Cat canonical generation evidence

| Pattern | What |
|---|---|
| `0160c84b6d8bba68d9ab72ee1881acaad0b9283d3b2c0a04c818c88c47dc8842.tar.gz` | Closed Cat canonical generation and fresh reviewer availability, immutable source inputs, full runtime commands and qualification, exact generated companions and retained stale-review stop; reopen every MANIFEST member |


## Allowed accepted Cat schematic delta review

| Pattern | What |
|---|---|
| `eea96e126c7d3bc720d2b3f3dd0eaa7cc935da493c4b37f001b07d2bd002f698.tar.gz` | Immutable complete fresh Cat topology/readability delta review packet, exact two witnesses, raw native/PDF comparison and visual evidence, timely delivery and root reopening |

## Allowed Cat schematic acceptance closeout

| Pattern | What |
|---|---|
| `252ee63636f9a3702c2b6d34ccc5517895d3b0992010a3552de0e88f43207135.tar.gz` | Exact owning schematic gate and compact handoff, fresh physical reviewer availability, root input/artifact reopening and deduplicated evidence provenance; reopen every MANIFEST member |

## Allowed Cat placement generation evidence

| Pattern | What |
|---|---|
| `a87557a0d0323ac6a10833dbb19aaf603b41edeea321dae01af4127a8c90b132.tar.gz` | Closed Cat placement generation, immutable source inputs, full runtime qualification and commands, regenerated board/prep/native gates and exact pin/render-input continuity; fresh visual/layout verdicts separately owed; reopen every MANIFEST member |

## Allowed Cat physical review and diagnostic admission evidence

| Pattern | What |
|---|---|
| `a7d64b91c00c69614a37042716db25ed49f113d856a82dfea17fa0debd183e8a.tar.gz` | Four completed independent review packets, original binding/census defects preserved verbatim, complete corrected owning reports, raw admission controls and exact historical attempt reopening; all MANIFEST members and referenced preimages verified; no routed acceptance |

## Allowed Cat physical checkpoint closeout

| Pattern | What |
|---|---|
| `4733661cbf3ff88f4e2969b782503e5db12ba5e1a6dad0771cf2e0eb4884281a.tar.gz` | Owning handoff/contract validation logs, cumulative two-attempt ledger, preparation-only current KRT config and syntax-parsed runner; no diagnostic dispatched; reopen MANIFEST members |

## Allowed exhausted Cat corridor diagnostic evidence

| Pattern | What |
|---|---|
| `81cb18e6e073e88bbc35b6bc6a9081abe988fc73d1f2b77ce858432039a927a1.tar.gz` | Closed third guarded diagnostic, exact durable reservation, qualification/prep/admission logs, config ancestry failure before KRT, current KRT tracked-input snapshot, exact Git preimage references; no route credit; reopen MANIFEST members |

## Allowed corridor method reassessment and root-interface repair evidence

| Pattern | What |
|---|---|
| `67c4960225e741f2bb6d0cb8ca2a157c7f69aab996ee0931be6d141d7f96c3a5.tar.gz` | Closed independent D-BACK and shared-tool review, exact original/fixed code and positive/hostile checks, spent-attempt assessment, raw closeout logs; no renewed corridor attempt or routed acceptance; reopen MANIFEST members and deduplicated references |

## Allowed fixed-pose source corridor comparison evidence

| Pattern | What |
|---|---|
| `0349b0404c8bf216705f36f55f3811e0ce8e7def4141825be1eb971746bc5cb9.tar.gz` | Closed source hypothesis: 87 clearance failures and 8 pair-spread failures, full native geometry and measurements, exact Git preimages, no source adoption or routed acceptance; reopen MANIFEST and references |

## Allowed north channel decision evidence

| Pattern | What |
|---|---|
| `158027b89b6482e8ce17201d8f8043dcd8bb7ea24abc8a47b752e5fe0f62121e.tar.gz` | Closed local-placement proposal and independent electrical mapping authority; native source rejection of proposed moves, original SWIG call failure and corrected measurement, five system authority supplements, exact verified Git references; no routing credit; reopen MANIFEST and references |
