"""ADR0027 source association, independently checked through native pad poses.

No BOARD or route is emitted. Monotone endpoint order and unchanged physical
population do not prove routed matching, clearance, or reference continuity.
"""
import copy
from collections import Counter
import json
from pathlib import Path
import re
import subprocess
import unittest
import yaml
from test_digital_launch_source import native_geometry, load_source
from test_local_placement_source import source_builder
from source_inventory import inventory
import check_analog_paths as checker

PROJECT = Path(__file__).resolve().parents[2]
REPO = PROJECT.parents[1]
BASE = 'f2675b43'


def inversions(values):
    return sum(a > b for i, a in enumerate(values) for b in values[i+1:])


class ChannelMapTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.floor, cls.route, cls.nets, *_ = load_source()
        cls.geometry = native_geometry(cls.floor)
        cls.before = yaml.safe_load(subprocess.check_output(
            ['git', 'show', BASE+':projects/crow-audio-carrier-v1/03_src/floorplan.yaml'],
            cwd=REPO, timeout=15))

    def test_native_north_and_south_endpoints_are_monotone_for_both_legs(self):
        for channels in (range(1, 5), range(5, 9)):
            for leg, iso_pin in [('P', '2'), ('N', '6')]:
                targets = {f'ADC{n}{leg}' for n in channels}
                source = sorted((p['at'][0], p['net']) for p in self.geometry['pads']
                                if p['id'].startswith('U_ISO') and p['id'].endswith('.'+iso_pin)
                                and p['net'] in targets)
                dest = sorted((p['at'][0], p['net']) for p in self.geometry['pads']
                              if p['id'].startswith('U_ADC.') and p['net'] in targets)
                self.assertEqual(len(source), 4)
                self.assertEqual(len(dest), 4)
                ranks = {net: i for i, (_, net) in enumerate(source)}
                self.assertEqual(inversions([ranks[net] for _, net in dest]), 0)
        # Reconstruct the former association on the same native pad poses.
        # The very same spatial-order predicate must reject that input.
        bad = copy.deepcopy([{k:v for k,v in p.items() if k != 'shape'}
                             for p in self.geometry['pads']])
        for p in bad:
            if p['id'].startswith('U_ADC.') and re.fullmatch(r'ADC[1-4][PN]', p['net']):
                p['net'] = 'ADC'+str(5-int(p['net'][3]))+p['net'][4]
        for leg, iso_pin in [('P','2'),('N','6')]:
            targets = {f'ADC{n}{leg}' for n in range(1,5)}
            source = sorted((p['at'][0],p['net']) for p in bad
                            if p['id'].startswith('U_ISO') and p['id'].endswith('.'+iso_pin)
                            and p['net'] in targets)
            dest = sorted((p['at'][0],p['net']) for p in bad
                          if p['id'].startswith('U_ADC.') and p['net'] in targets)
            self.assertEqual((len(source),len(dest)), (4,4))
            ranks = {net:i for i,(_,net) in enumerate(source)}
            self.assertEqual(inversions([ranks[net] for _,net in dest]),6)

    def test_physical_population_and_every_unexchanged_pose_remain_exact(self):
        old = source_builder(self.before)
        new = source_builder(self.floor)
        refs = set(inventory()[0])
        moved = {f'C_ADC_CM{n}{leg}' for n in range(1, 5) for leg in 'PN'}
        self.assertEqual(len(refs), 333)
        self.assertEqual(Counter(old.initial_pose(r)[:3] for r in moved),
                         Counter(new.initial_pose(r)[:3] for r in moved))
        for r in refs-moved:
            self.assertEqual(old.initial_pose(r), new.initial_pose(r), r)
        comp = inventory()[0]
        self.assertEqual(len({comp[r] for r in moved}), 1)
        self.assertEqual(self.floor['placement']['repeat'], self.before['placement']['repeat'])

    def test_actual_pin_association_and_capture_slot_table_agree(self):
        # Manufacturer physical identity is fixed independently of map parsing.
        physical = [(40,39),(42,41),(46,45),(48,47),(14,13),(16,15),(20,19),(22,21)]
        pins = self.geometry['pins']
        observed = []
        for p,n in physical:
            pn = pins['U_ADC',str(p)]
            nn = pins['U_ADC',str(n)]
            self.assertRegex(pn, r'^ADC[1-8]P$')
            pod = int(re.fullmatch(r'ADC([1-8])P', pn)[1])
            self.assertEqual(nn, f'ADC{pod}N')
            observed.append(pod)
        result = checker.validate_source(self.nets['length_match'], self.route, pins)
        self.assertEqual(observed, result['slot_to_pod'])
        self.assertEqual(set(observed), set(range(1,9)))
        self.assertEqual(observed[4:], [5,6,7,8])
        self.assertEqual(result['paths'], 144)
        self.assertEqual(result['endpoints'], 192)

    def test_malformed_duplicate_and_cross_domain_maps_are_rejected(self):
        good = checker.CHANNEL_MAP
        bads = [dict(good, extra=True), dict(good, schema=True), dict(good, id=''),
                dict(good, pod_to_adc=[]), dict(good, pod_to_adc=[4,3,2,2,5,6,7,8]),
                dict(good, pod_to_adc=[4,3,2,5,1,6,7,8]),
                dict(good, pod_to_adc=[4,3,2,1,6,5,7,8]),
                dict(good, pod_to_adc=[4,3,2,True,5,6,7,8])]
        self.assertEqual(len(bads), 8)
        for bad in bads:
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                checker.validate_channel_map(bad)
        # Incorrect physical membership must fail even if the declared table
        # still looks complete and every logical net is named in the source.
        badpins = dict(self.geometry['pins'])
        badpins['U_ADC','48'],badpins['U_ADC','40'] = badpins['U_ADC','40'],badpins['U_ADC','48']
        with self.assertRaises(checker.PathError):
            checker.validate_source(self.nets['length_match'], self.route, badpins)


if __name__ == '__main__':
    unittest.main()
