# Crow audio carrier v1 — first-article test plan

status: PLANNED — NO HARDWARE RESULT
order_status: DO-NOT-ORDER

## Amplifier/reference revision — 2026-09-09

ADR0023 changes all nine packages to OPA2320AIDR, adds both10k reference
input limiters and changes both output isolators to1k. Current population is
325; older dated counts below are historical. Keep the1.2Vrms differential
envelope and1.60..1.70V VMID_BUF acceptance window unchanged. Measure both
banks' DC error, leakage/loading, settling and recovery; record full-level
eight-channel gain, phase, noise, THD and oscillation/ringing across the
admitted cable/load/temperature conditions. Cirrus performance equivalence
is not claimed. Capture raw/OPA/held/ADC/reference rails, CT/NR, enables and
feed current together on startup/removal/brownout/rapid restart. Independent
ADC pin-voltage/current limits and amplifier output-backdrive behavior must
not be inferred from input current limits alone. These are planned physical
tests, not substitutes for the remaining source-state/filter arguments.

## Power-source revision hold — 2026-09-07

ADR-0009 revises the source to 299 installed components and a 0.30 A local
5 V steady allocation (0.2673 A modeled all-channel load). The corrected
upstream steady bound is approximately 0.964 A with eight 0.10 A spokes;
the 1.0 A trunk and 10.896 V delivery screen are unchanged.
The first-power card's conservative 0.20 A bench limit below is NOT a
demonstration that the new startup transient will avoid supply foldback.
Before physical power, qualify the isolated supply's current-limit transient,
declare an instrumented startup procedure and reconcile that limit/card.
Do not increase a current limit during an unexplained failed run.

Power-source-specific obligations, with exact modeled assumptions and
acceptance boundaries in ADR-0009 and check_power_source.py:

- POWER-COLD: behavior in the LDO 1.4 V versus Schmitt 1.65 V operating gap;
- POWER-START: AP63205 actual ramp/inrush, delayed precharge bypass, NR ramp
  and repeated restart at capacitor and temperature corners;
- POWER-FALL: detection/open delay, OPA hold, dump timing and ADC/FILT decay;
- POWER-LOOP: the complete distributed capacitor/ESR bank and LDO stability;
- POWER-REVERSE: held-input/output relation, reverse current and diode leakage;
- POWER-AUDIO: unpowered/partial-rail feedthrough, charge injection, both
  independent power orders, full-level eight-channel distortion and pop;
- POWER-DRIFT: resistor long-life/solder drift; prototype 0.05% allowance is
  not the Yageo 0.5% plus 0.05 ohm rated-life envelope;
- POWER-THERMAL: final copper/EP layout at 85 C, no reference-board thetaJA
  substitution for an actual hot-board result.

All eight are OWED. No bench energization or source approval occurred.

## Authority and scope

This is the controlled procedure for one serialized, fully populated carrier.
It is source-side planning, not evidence that a board was fabricated or passed.
The executable first-power population and rail limits remain
[`03_src/rules/first_article.yaml`](../03_src/rules/first_article.yaml); the
spoke, power, protection and digital-interface rule files remain the design
authority. A result may be called `FIRST_ARTICLE_TESTED` only after every
applicable row below passes on the same identified article and the findings
ledger is deliberately updated.

The plan covers carrier electronics and its immediate COTS interfaces. It does
not establish weatherproofing, lightning or building-entry safety, a production
process, or biological crow identity.

## Evidence record

Before measuring, assign the PCB a serial number and record board revision,
assembled BOM digest, operator, UTC timestamps, calibrated instrument IDs,
probe configuration, ambient temperature and the exact MCHStreamer/cable/Pi
identities. Put the structured first-power record at
`01_docs/journal/first_article.json`, in the schema consumed by
`first_article_check.py`. Store raw waveforms, logic captures, audio files,
thermal images and photographs under `06_build/first_article/<serial>/`; write
a SHA-256 manifest and reference it from the journal record. A release copies
the record, manifest and reviewed evidence into its verification directory.

Never copy a reading from another board, combine partial-population evidence
with the fully populated stage, or convert a missing result into a pass.

## Preconditions

- [ ] Live JLCPCB pre-layout and final allocation holds are closed for the exact
      assembled identities, or this is an explicitly hand-assembled engineering
      article whose deviations are recorded.
- [ ] The exact schematic, netlist, PCB, BOM and CPL are immutable and have
      passed their required machine and human reviews.
- [ ] `first_article.yaml` exactly matches the installed reference-designator
      set; substitutions and rework are recorded before power.
- [ ] The purchased MCHStreamer, two exact `TCSD-06-D-04.50-01` cables and the
      miniDSP-authorized TDM8 image have recorded identities and provenance.
- [ ] The isolated bench supply has overvoltage protection and a known
      prospective-short-current envelope. The installed harness is never used
      for an 8 A trip-time experiment.
- [ ] DMM, oscilloscope, differential probes, logic analyzer, audio
      generator/analyzer, eight electronic loads, thermal camera and cable
      fixtures are in calibration and share a deliberate grounding plan.

## Immediate abort rules

De-energize and mark the run `ABORT` for unexpected polarity, wrong or unstable
resistance, visible assembly damage, smoke/odor, oscillation, any rail outside
its card limit, bench current above 0.120 A after startup with spokes unloaded,
current-limit operation that was not part of the declared step, excessive part
temperature, MCH/carrier back-power, or loss of protective earth/isolation.
Investigate and revise the design or plan; do not raise a limit to make a board
pass.

## 1. Identity, inspection and unpowered checks

- [ ] Photograph both sides, serial label, pin-1 marks and all manual/THT work.
- [ ] Confirm J1–J8/J9/J10/J11 orientation, every polarized diode/capacitor,
      Q_IN orientation, ADC/reset/clock IC orientation and intended no-connects.
- [ ] Confirm exposed-pad soldering for Q_IN and U_ADC using the approved
      inspection method; record the method and images.
- [ ] Reconcile the literal population to `fully-populated-first-power` with no
      missing or extra refdes.
- [ ] With all external modules and loads disconnected, wait for capacitors to
      settle and measure every resistance probe/range in `first_article.yaml`.
- [ ] Verify J9 and all eight spoke pin identities end to end before mating any
      cable. Confirm chassis/shield obligations are outside the PCB conductors.

## 2. Controlled first power and rails

1. Set the isolated supply to 0 V and a 0.20 A current limit. Connect only J9,
   observing polarity; leave all spokes and both MCH cables disconnected.
2. Raise to 11.4 V while capturing input voltage/current and startup inrush.
   Inrush is a waveform result, not the steady-state `no_load_current` value.
3. After startup settles, record the same bench-supply current observation for
   every card rail. It must be no more than 0.120 A; the repeated card rows do
   not represent separate per-rail currents.
4. Measure `12V_PROTECTED`, `5V_OPA`, `3V3_ADC`, `VMID1_BUF` and `VMID2_BUF` at
   the exact probes and limits in `first_article.yaml`. The protected rail floor
   is 11.16 V at the 11.4 V admitted input.
5. Repeat the steady-state rail/current observations at 12.0 V and 13.2 V,
   removing power and rechecking resistance after any abnormal result.
6. Run `first_article_check.py` against the complete structured record. Only
   `FIRST-ARTICLE AUTHORIZED` permits the powered functional tests below.

## 3. ADC reset and clocks

- [ ] Capture `3V3_ADC`, supervisor clear, monostable output and
      `ADC_RESET_N` from power application through steady operation at each
      admitted input corner.
- [ ] Confirm reset begins high, remains high for at least 2 ms after the ADC
      supply is valid, pulses low for at least 1 ms, then returns high without
      a second pulse or firmware action. Record measured extrema, not only a
      representative screenshot.
- [ ] Repeat cold-start and brownout/recovery cases sufficient to expose the
      supervisor and timing-capacitor corners. Any ambiguous reset is a hold.
- [ ] With the authorized MCH configuration connected, measure 24.576 MHz
      MCLK, 12.288 MHz BCLK, 48 kHz one-BCLK FSYNC and eight 32-bit TDM slots.
      Decode DOUT as 24-bit samples in the declared slot order.
- [ ] Retain at least one continuous 120-second eight-channel capture with no
      framing discontinuity, missing channel, repeated slot or clock-domain
      change. Network arrival time is not a sampling-time measurement.

## 4. MCHStreamer independent-power matrix

2026-09-08 source amendment: fitted census is302, including U_TDM_SCH,
R_TDM_PD and C_TDM_SCH. Before acceptance, capture TDM_RAW and TDM_CLEAN
with reset asserted, clocks stopped and after a transmitted high releases.
Verify ADC-plus-PCB Hi-Z leakage allocation20uA, raw total capacitance20pF
allocation, raw settled low0.4V/high2.8V targets and the added0.4mA DC-load
budget at the actual ADC supply/temperature. Cirrus input leakage and drive
register are not output guarantees. No total-capacitance maximum follows
from the Nexperia5pF or TI4pF typical inputs.

Capture U_TDM.2 edges against the TI10ns/V requirement; Nexperia tpd is not
an output-slew bound. Measure the complete MCH-BCLK-to-returned-TDM path,
including both cables, U_CLK, ADC launch/Hi-Z enable, both data buffers,
series resistors, receiver thresholds, actual BCLK duty and remote setup/hold.
ADR0005's6ns path,5ns setup and45% phase allocations are not vendor limits.
Record the minimum real setup/hold margins, including the last transmitted
bit and post-reset first bit; a correct short digital capture alone is not
timing closure. Reserve5mA inside—not in addition to—the existing150mA
3V3_ADC total budget, and capture slow-input/dynamic conditioner current.
Any failed allocation stops qualification and reopens source design.

Exercise every row with both exact cables, then repeat the split-cable cases.
Record carrier 3.3 V, J3 sense, USB current and all four TDM lines.

| Carrier | MCHStreamer | Required observation |
|---|---|---|
| off | off | All interface lines unpowered. |
| on | off | Clock inputs remain low and DOUT buffer remains disabled. |
| off | on | Ioff boundary prevents carrier-rail back-power; no carrier logic becomes powered. |
| on | on | J3 sense enables DOUT and the MCHStreamer remains the sole clock master. |

- [ ] J10 without J11 leaves DOUT disabled.
- [ ] J11 without J10 creates no false clocks or driven remote load.
- [ ] Across the admitted temperature and 3.0–3.6 V interface-rail screen,
      measure each loaded clock low below 0.4 V and high above 2.4 V, with
      the TI maximum input-transition rate of 10 ns/V respected. Confirm
      the 0.4 mA per-clock DC load budget and total additional unpowered
      module/cable/PCB leakage allocation of 20 µA. Retain actual module
      hardware identity; the miniDSP manual does not guarantee those limits.
- [ ] Measure `TDM_SENSE_G` below 0.4 V absent and above 2.8 V present;
      measure `TDM_OE_N` above 2.4 V disabled and below 0.4 V enabled.
      Verify the retained20 µA Schmitt-input/module/cable allowance and
     25 µA total OE load budget under actual test conditions. U_OE is now
      a genuine Schmitt inverter, not the former protected MOSFET plus RC
      pull-up. Check actual U_TDM OE edges meet10 ns/V; no propagation-delay
      number has been substituted for a guaranteed output-slew maximum.
- [ ] Capture all power and cable transitions separately from settled-state
      tests. The DC bias calculation does not authorize glitch-free live
      insertion. Keep power off while changing cables until qualified.
- [ ] Continuity, pin 1, cable rotation, retention, labels and hot-plug/power
      ordering agree with the signed physical-qualification record.

## 5. Analog channel and slot qualification

- [ ] Confirm both buffered VMID nodes remain 1.60–1.70 V over input corners,
      representative signal loading and the thermal screen.
- [ ] Inject a calibrated balanced signal into one spoke at a time. Verify
      connector polarity, ADC channel 1–8 and TDM slot 0–7 with an 8/8
      denominator; unstimulated channels must not be silently remapped.
      Use ADR0027 / `03_src/adc_channel_map.json`: slots0..7 must identify
      pods4,3,2,1,5,6,7,8. Retain map ID/digest and actual USB-channel/ADC-slot/
      pod-coordinate table with each stream epoch and120-second capture.
      Reject missing, duplicate, swapped, inverted or unstable channel identity.
      Do not silently apply the former pod-number-equals-slot-plus-one map.
- [ ] At low and mid frequencies, record gain, phase and leg symmetry for all
      eight AN0556 receiver cells and both VMID domains.
- [ ] Sweep amplitude through 1.2 Vrms differential at the carrier connector.
      Record THD+N, clipping margin and common-mode behavior. A numeric
      distortion/noise acceptance bound must be signed before the run; absent
      that system-level bound, data may be retained but this section is HOLD.
- [ ] With terminated inputs, record input-referred noise and the complete
      8-by-8 crosstalk matrix. Retain raw spectra and acquisition settings.

## 6. Exact cable and pod integration

- [ ] Repeat gain, phase, polarity, common mode, noise, stability and crosstalk
      with exact 4 m installed-length and 15 m boundary harnesses.
- [ ] Use serialized pods and record which pod/cable occupies each carrier
      port. Verify a 120-second all-channel file can be reopened with its
      channel/slot identity intact.
- [ ] Freeze quantitative phase/noise/crosstalk acceptance limits from the
      localization/DSP budget before declaring this step passed. The 15 m
      design boundary is not a qualified maximum until these results pass.

## 7. Spoke-power load, fault and recovery

- [ ] Apply 0.100 A to all eight spoke outputs simultaneously. At 11.4, 12.0
      and 13.2 V input, four-wire measure J9, `12V_PROTECTED` and every J1–J8
      header. Each carrier output must remain at least 10.8 V.
- [ ] Record cold and hot branch/common-path resistance, input/PPTC/PFET loss,
      copper/header drop and temperature. Do not average eight ports to hide a
      failed port.
- [ ] In a separately risk-reviewed, current-bounded fixture, fault one branch
      at a time and prove the other seven remain powered and recover cleanly.
      Record source foldback, branch/common-PPTC selectivity, trip energy and
      recovery. Prospective fault current must not exceed the selected part's
      10 A rating, and no 8 A installed-harness trip test is authorized.
- [ ] Repeat the one-fault/seven-healthy observation for all eight branch
      positions, with no damaged cable, connector or protection device.

## 8. Thermal and closeout

- [ ] Soak unloaded and all-eight-loaded configurations at each admitted input
      corner and the approved first-article ambient points. Record equilibrium
      temperatures for F_IN, Q_IN, U_BUCK, U_LDO, U_ADC, all branch PPTCs,
      connectors and representative analog channels.
- [ ] Confirm rail, reset, clock and analog limits remain valid during and after
      thermal soak. Component temperatures must remain below their cited
      ratings with the declared measurement uncertainty.
- [ ] Power-cycle and reinspect the article; record permanent resistance,
      polarity, connector or solder-joint changes.
- [ ] Review every row as PASS, FAIL, BLOCKED or NOT-APPLICABLE with rationale.
      Hash the record and raw-evidence manifest. Open failures in
      `findings.yaml`; never edit a raw result into compliance.

Passing this plan permits only a `FIRST_ARTICLE_TESTED` carrier claim. Outdoor
deployment and production release remain separate system/environmental gates.

## ADR0022 — local buck input reverse isolation

On the generated/assembled candidate, capture12V_PROTECTED,12V_BUCK_IN,
BUCK_SW,5V_BUCK,5V_OPA,5V_LDO_HOLD,PWR_EN,AUDIO_EN and feed/diode
current for ordinary J9 removal, slow brownout through dropout, removal after
a low-input dwell, and rapid restart with partial CT/ADC discharge. Verify no
sustained shared-spoke backfeed through D_BUCK_IN. Check100uA leakage,
100nC integrated reverse-recovery charge,1mA equivalent local reverse-port
control budget and320us isolation against the4.501285V conditional screen.
These are application budgets, not guarantees inferred from50ns trr. Preserve
exact recovery waveform, temperature, current and probe bandwidth in evidence.

Measure D_BUCK_IN cold/hot forward drop<=1.3V engineering allowance,
terminal temperature and repetitive startup current. The3x10uF input bank
upper initial37.95uF stores500.94uC/3.306204mJ at13.2V, not a bounded
inrush peak. Compare actual waveform with the exact US1B ratings; no arbitrary
pulse qualification from30A8.3ms half-sine. Verify the unchanged spoke floor,
1A common allocation and full ADC/OPA startup under minimum source input.
