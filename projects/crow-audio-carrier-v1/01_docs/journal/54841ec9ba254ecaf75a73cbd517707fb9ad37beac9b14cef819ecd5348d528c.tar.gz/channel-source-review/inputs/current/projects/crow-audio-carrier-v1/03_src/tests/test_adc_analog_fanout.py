"""ADC analog fanout source geometry, not a generated/routed-board verdict.

Independent native shapes grade the sixteen simultaneous source launches.
Known-bad controls restore the actual old filter/reset banks, remove a launch,
or cross a neighboring input. Full routing, matched paths and DCR remain owed.
"""
import copy
import math
import subprocess
import unittest
from collections import Counter
from pathlib import Path

import pcbnew
import yaml
from test_adc_source import load_source,native_geometry
from test_digital_launch_source import primitive,rect_shape,segment_rows,overlaps
from test_regulator_source import via_rows,connected_reach
from test_thermal_source import thermal_rows
from rules_audit import parse_mm

PROJECT=Path(__file__).resolve().parents[2];REPO=PROJECT.parents[1]
BASE='28571836bd194c6444240f0d12b7beccae8c2542'
INPUTS={f'U_ADC.{n}' for n in [13,14,15,16,19,20,21,22,39,40,41,42,45,46,47,48]}
REOPENED={f'U_ADC.{n}' for n in [17,18,23,43,44]}


def frozen(name, revision=BASE):
    return yaml.safe_load(subprocess.check_output(['git','show',revision+
        ':projects/crow-audio-carrier-v1/03_src/'+name],cwd=REPO,timeout=15))


def inspect_launches(floor,route,nets,geometry):
    rows=segment_rows(route);subjects=[r for r in rows if r['id'] in INPUTS]
    pads={p['id']:p for p in geometry['pads']}
    classes={n:c for c in nets['classes'].values() for n in c['nets']}
    areas={a['name']:a for a in floor['keepouts']};counts=Counter();failures=[]
    if Counter(r['id'] for r in subjects)!=Counter({p:1 for p in INPUTS}):
        failures.append(dict(kind='coverage',pin='ADC-inputs'))
    def check(row,other,kind,gap):
        counts[kind]+=1
        if pcbnew.SHAPE.Collide(row['shape'],other['shape'],max(0,round(gap*1e6)-2)):
            failures.append(dict(kind=kind,pin=row['id'],other=other['id']))
    def clearance(a,b):
        gap=max(parse_mm(classes.get(p['net'],{}).get('clearance',nets['default_clearance'])) for p in (a,b))
        for rule in nets['scoped_clearances']:
            # Every call includes a seed segment; pad-only scopes cannot apply.
            if rule.get('pads_only'):continue
            area=areas[rule['zone']]
            if 'F.Cu' not in area['layers'] or not overlaps(a['shape'],area) or not overlaps(b['shape'],area):continue
            if 'nets' in rule:match=bool({a['net'],b['net']}&set(rule['nets']))
            else:match=((a['net'] in rule['nets_a'] and b['net'] in rule['nets_b']) or (b['net'] in rule['nets_a'] and a['net'] in rule['nets_b']))
            if match:gap=parse_mm(rule['clearance'])
        return gap
    vias=via_rows(route)+thermal_rows(floor,geometry)
    for row in subjects:
        pad=pads[row['id']];x,y=pad['at'];outward=-1 if y<70 else 1
        if row['net']!=pad['net'] or row['width']!=.2 or row['layer']!='F.Cu':
            failures.append(dict(kind='identity-width-layer',pin=row['id']))
        if (not row['shape'].Collide(pad['shape'],0) or
            math.dist(row['a'],pad['at'])>1e-6 or
            math.dist(row['b'],[x,y+outward])>1e-6):
            failures.append(dict(kind='launch-reach',pin=row['id']))
        outline=floor['board']['outline'];radius=row['width']/2
        if not all(outline['x0']+.8+radius<=px<=outline['x1']-.8-radius and
                   outline['y0']+.8+radius<=py<=outline['y1']-.8-radius
                   for px,py in [row['a'],row['b']]):
            failures.append(dict(kind='edge',pin=row['id']))
        for other in geometry['pads']:
            if row['net']!=other['net']:check(row,other,'pad',clearance(row,other))
        for other in rows:
            if row['net']!=other['net'] and row['layer']==other['layer']:
                check(row,other,'seed',clearance(row,other))
        for via in vias:
            if row['net']!=via['net']:check(row,via,'via',.25)
            check(row,dict(id=via['id'],shape=via['hole']),'via-drill',.255)
        for hole in geometry['holes']:check(row,hole,'physical-hole',.255)
        for area in floor['keepouts']:
            if 'F.Cu' in area['layers'] and 'tracks' in area['deny']:
                check(row,dict(id=area['name'],shape=rect_shape(area['rect'])),'physical-keepout',0.)
        for i,area in enumerate(route['prep']['keepouts']['rects']):
            if area['layer']=='User.3':
                check(row,dict(id='User.3:'+str(i),shape=rect_shape([area[k] for k in ['x0','y0','x1','y1']])),'virtual-mask',0.)
    return dict(launches=len(subjects),checks=dict(counts),failures=failures)


def filter_resistance_model(route):
    """ADR0015 nominal 35um copper / rho85 model; no temperature-rise claim."""
    result={}
    for net in ['FILT1P','FILT2P']:
        rows=[r for r in segment_rows(route) if r['net']==net]
        resistance=sum(2.1643958e-8*math.dist(r['a'],r['b'])/(r['width']*35e-6) for r in rows)
        result[net]=dict(length_mm=sum(math.dist(r['a'],r['b']) for r in rows),
                         segments=len(rows),resistance_ohm_at85C_nominal_copper=resistance,
                         conditional_loss_w_at2_5A=resistance*2.5**2)
    return result


class AdcAnalogFanoutTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.floor,cls.route,cls.nets,*_=load_source();cls.geometry=native_geometry(cls.floor)

    def test_all_sixteen_simultaneous_launches_clear_full_geometry(self):
        result=inspect_launches(self.floor,self.route,self.nets,self.geometry)
        self.assertEqual(result['launches'],16);self.assertEqual(result['failures'],[])
        self.assertGreater(sum(result['checks'].values()),20000)

    def test_actual_old_filter_reset_geometry_blocks_seven_launches(self):
        old={r['pin']:r for r in frozen('route.yaml')['prep']['seed_stubs']['stubs']}
        bad=copy.deepcopy(self.route)
        bad['prep']['seed_stubs']['stubs']=[old[r['pin']] if r['pin'] in REOPENED else r for r in bad['prep']['seed_stubs']['stubs']]
        result=inspect_launches(self.floor,bad,self.nets,self.geometry)
        self.assertEqual({f['pin'] for f in result['failures']},
                         {f'U_ADC.{n}' for n in [15,16,19,22,42,45,46]})

    def test_missing_and_crossed_launches_fail(self):
        bad=copy.deepcopy(self.route)
        bad['prep']['seed_stubs']['stubs']=[r for r in bad['prep']['seed_stubs']['stubs'] if r['pin']!='U_ADC.42']
        self.assertIn('coverage',{f['kind'] for f in inspect_launches(self.floor,bad,self.nets,self.geometry)['failures']})
        bad=copy.deepcopy(self.route)
        row=next(r for r in bad['prep']['seed_stubs']['stubs'] if r['pin']=='U_ADC.40')
        row['segments'][0]['pts'][-1]=[97.4,66.05]
        kinds={f['kind'] for f in inspect_launches(self.floor,bad,self.nets,self.geometry)['failures']}
        self.assertTrue({'launch-reach','seed'}<=kinds)

    def test_adc_launches_and_filter_reset_banks_preserve_accepted_source(self):
        before={r['pin']:r for r in frozen('route.yaml')['prep']['seed_stubs']['stubs']}
        accepted={r['pin']:r for r in frozen('route.yaml','1b725986')['prep']['seed_stubs']['stubs']}
        live={r['pin']:r for r in self.route['prep']['seed_stubs']['stubs']}
        selected=INPUTS|REOPENED
        self.assertEqual(len(selected),21)
        north = {f'U_ADC.{n}' for n in (39,40,41,42,45,46,47,48)}
        physical = lambda row: ({k:v for k,v in row.items() if k != 'net'}
                                if row['pin'] in north else row)
        self.assertEqual({p:physical(live[p]) for p in selected},
                         {p:physical(accepted[p]) for p in selected})
        for pin in selected:
            self.assertEqual(live[pin]['net'], self.geometry['pins'][tuple(pin.rsplit('.', 1))])
        self.assertTrue(INPUTS.isdisjoint(before))
        self.assertEqual({p for p in REOPENED if before[p]!=live[p]},REOPENED)
        self.assertEqual((len(live),len(segment_rows(self.route)),len(via_rows(self.route))),(105,237,18))

    def test_partial_owners_and_separate_ground_drops_are_preserved(self):
        groups=self.route['prep']['waves']['groups'];excluded=set(self.route['prep']['waves']['exclude'])
        for pin in INPUTS:
            net=self.geometry['pins'][tuple(pin.rsplit('.',1))]
            self.assertIn(net,groups['analog']);self.assertNotIn(net,excluded)
            row=next(r for r in self.route['prep']['seed_stubs']['stubs'] if r['pin']==pin)
            self.assertFalse(row.get('vias'))
        for pin in ['U_ADC.17','U_ADC.44']:
            reached=set(connected_reach(self.route,self.geometry,pin))
            self.assertIn(pin+':via0',reached);self.assertNotIn('U_ADC.49',reached)

    def test_filter_width_lengths_and_conditional_current_are_explicit(self):
        model=filter_resistance_model(self.route);old=filter_resistance_model(frozen('route.yaml'))
        for net,row in model.items():
            self.assertEqual(row['segments'],3)
            self.assertAlmostEqual(row['length_mm'],4.500464884544218,places=8)
            self.assertGreater(row['resistance_ohm_at85C_nominal_copper'],old[net]['resistance_ohm_at85C_nominal_copper'])
            self.assertAlmostEqual(row['conditional_loss_w_at2_5A'],row['resistance_ohm_at85C_nominal_copper']*6.25)
        self.assertEqual(model['FILT1P'],model['FILT2P'])


if __name__=='__main__':unittest.main()
