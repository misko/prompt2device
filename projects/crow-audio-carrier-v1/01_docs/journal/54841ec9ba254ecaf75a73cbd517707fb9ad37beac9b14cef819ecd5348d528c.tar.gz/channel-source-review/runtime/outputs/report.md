subject: crow-audio-carrier-v1 north ADC channel-map source implementation
date: 2026-09-11
reviewer: Codex judgment agent /root/carrier_channel_source_review
context-given: FRESH; immutable 420-input packet plus two hash-bound owning checkpoint helpers
source_commit: f2675b431c4372a1a81d0fdfa0ca81f0a27ecd68 (packet delta is uncommitted relative to this base)
review_stage: pre-route source implementation
review_kind: noncanonical source review; generated native schematic/layout artifacts are stale
design_verdict: NEEDS-CORRECTION
order_verdict: DO-NOT-ORDER
board_sha256: 9aa1c2c821a31129176a8b519b9a211d78dfc011adb997a64470c03d0726891f (stale before-state only)
design_rules_sha256: 5891d8028d9864ea0503dc3f63c7520efca45ece640c9db65423680f85b88712
task_identity: task_id=channel-source-review; run_id=channel-source-review; input_handoff_id=channel-source-review; stage_id=KICAD-PLACEMENT
envelope_subject_raw_sha256: 81be828bc859276dd1fa6aecfdbf8bb3149408eb18f7928eee38b70163632846
envelope_subject_semantic_sha256: 25cd52b09c051f43e1e28594df20ca412443acacd06dd157439f66f10b1306cb
reviewer_provenance: independent source-delta judgment; no implementation, routing, regeneration, or native acceptance
layout_finding: LAYOUT-001
layout_finding_state: OPEN
layout_finding_class: missing_simultaneous_corridor_evidence
diagnostic_request: simultaneous_source_corridor_reservation
diagnostic_nets: ADC1P,ADC1N,ADC2P,ADC2N,ADC3P,ADC3N,ADC4P,ADC4N
diagnostic_pad_denominator: 32
diagnostic_path_denominator: 24
diagnostic_pn_groups: ANALOG_CH1_ADC,ANALOG_CH2_ADC,ANALOG_CH3_ADC,ANALOG_CH4_ADC
diagnostic_max_spread_mm: 1.0
diagnostic_layers: F.Cu,B.Cu
diagnostic_track_width_mm: 0.20
diagnostic_clearance_mm: 0.20
diagnostic_via_mm: 0.50/0.20
diagnostic_reference_plane_proof: OWED
diagnostic_promotion: FORBIDDEN
north_current_channel_inversions: 6
north_implemented_channel_inversions: 0
south_current_channel_inversions: 0
south_implemented_channel_inversions: 0
completed_at_utc: 2026-09-12T02:36:00Z

# North ADC channel-map source review

## Verdict and findings

**NEEDS-CORRECTION.** The electrical, geometric, and constraint migration coherently implements `pod_to_adc=[4,3,2,1,5,6,7,8]`, and the corresponding hardware slot order is `[4,3,2,1,5,6,7,8]`. Two contract gaps prevent a SOUND source verdict.

1. `03_tscircuit/src/crow_audio_carrier_v1.tsx` consumes the authoritative JSON but does not enforce the contract it advertises. It checks schema, length, uniqueness, integer/range, and north/south domain membership, but accepts unknown top-level keys and a missing or blank `id`. The Python path checker rejects both, so the full driver fails closed before generation, but direct TSX producer use does not. Minimal correction: add an exact-key check for `schema,id,pod_to_adc`, require `pod_to_adc` to be an array before dereference, and require a trimmed nonempty `id`; add a producer-level hostile test that evaluates the TSX consumer against extra-key and missing/blank-ID fixtures.

2. The machine-readable first-article authority `03_src/rules/first_article.yaml` contains no map ID, source digest field, pod-to-ADC table, or slot-to-pod table. The prose test plan and both architectures state the correct prospective record, but the requested capture identity remains outside the graded source contract. Minimal correction: add a typed channel-identity record to `rules/first_article.yaml` containing map ID, map-source path/digest binding, `pod_to_adc`, `slot_to_pod`, surveyed pod/cable identities, stream epoch, and the exact 8/8 impulse rejection rules; add its owning reader/hostile tests. This does not require firmware or runtime reordering.

## Mapping and preservation proof

The JSON maps pods 1–8 to physical ADC channels `4,3,2,1,5,6,7,8`. The TSX inverse lookup therefore assigns physical pins `48/47,46/45,42/41,40/39,14/13,16/15,20/19,22/21` to logical pods 1–8 with P/N preserved. The resulting hardware slots 0–7 identify pods `4,3,2,1,5,6,7,8`. North source and ADC endpoint order are both logical `[1,2,3,4]`, giving zero channel inversions; south remains `[5,6,7,8]`, also zero.

Across all 16 changed files, only the eight north U_ADC net memberships and eight north common-mode logical-reference/pose associations change electrical/physical identity. The multiset of those eight capacitor `(x,y,rotation)` poses is exact before/after, all other fixed poses compare equal, and the source inventory remains 333 components with one common value/footprint across the exchanged capacitors. All eight north seed stubs retain layer, width, and points and change only net labels. `R_ADC_PD1..4` endpoints remain at the same U_ISO logical pods. Connector, AFE, ISO, power, VMID/reference, clock, reset, south-channel, P/N, component value, and footprint definitions have no delta.

The part dossier moves each north ADC adjacency record with its physical capacitor location and preserves each original per-location ceiling (5/5, 3.5/4.5, 2.5/2.0, 4/4 mm); keep-short remains 5 mm while pins follow 48/47,46/45,42/41,40/39. `rules/nets.yaml` changes only the four north ADC main endpoints. The complete checker reports 24 groups, 48 nets, 192 unique endpoints, and 144 paths; the north ADC subset remains 4 groups, 8 nets, 32 endpoints, and 24 paths, with 1.0 mm group spread, 0.5 mm routing match tolerance, unchanged stack, and no via/cap relaxation.

The complete prelayout input checkpoint recursively binds all non-test `03_src` files, so the imported `adc_channel_map.json` is included without a brittle explicit list. I inspected and hash-bound the owning helper (`0462d90a…c08466`) and resume gate (`ec57992a…6f1fdc`) as two supplemental inputs. No cap bypass or scope widening appears. ADR0027 correctly preserves the rejected ten-cap plan and the exhausted 3/3 route history; no proposed geometry or new attempt was adopted.

## Coverage and remaining gates

I inspected every changed-file diff, the JSON and both consumers, the independent geometry/source inventory adapter, hostile mapping tests, fanout seed test, route/nets declarations, floorplan poses, part adjacency/keep-short, first-article rules and prose, ADR0027, child/parent architecture, carried focused 4/4 and full 334/334 logs, and the semantic contracts/schema logs. The full suite was not rerun. The stale locator image was actually viewed only to corroborate the physical north/south cell arrangement and central ADC; it does not prove new connectivity.

After the two source corrections, rerun focused hostile tests and the ordinary source suite, regenerate circuit JSON/PDF/native schematic/netlist/PCB/r0/DRC/locator, and obtain fresh independent topology, pin, schematic-render, placement/layout, render, and canonical pre-route reviews. `LAYOUT-001`, simultaneous legal routing, <=1 mm P/N spread, filled In1.Cu/In2.Cu reference continuity, DRC/parity, physical ADC-to-USB slot enumeration, first article, and ordering all remain open. Regeneration is not yet admitted by this verdict.

All 420 packet inputs passed exact size/SHA-256 verification before and after review. No native CLI/PDF process, router, board writer, network operation, or live-source write ran.
