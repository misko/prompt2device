import hashlib, json, re
from pathlib import Path
import yaml

R=Path('/tmp/carrier-channel-source-review-65wvio93')
env=json.loads((R/'06_build/task_runs/channel-source-review/envelope.json').read_text())
def sig(p):
 b=p.read_bytes(); return len(b),hashlib.sha256(b).hexdigest()
bad=[]
for x in env['input_packet']:
 p=R/x['path']; s,h=sig(p)
 if (s,h)!=(x['size'],x['sha256']): bad.append([x['path'],s,h])

C=R/'project'; P=R/'previous/projects/crow-audio-carrier-v1'
mp=json.loads((C/'03_src/adc_channel_map.json').read_text())
pod=mp['pod_to_adc']; slot=[pod.index(x)+1 for x in range(1,9)]
floor=yaml.safe_load((C/'03_src/floorplan.yaml').read_text())
oldfloor=yaml.safe_load((P/'03_src/floorplan.yaml').read_text())
route=yaml.safe_load((C/'03_src/route.yaml').read_text())
nets=yaml.safe_load((C/'03_src/rules/nets.yaml').read_text())
oldroute=yaml.safe_load((P/'03_src/route.yaml').read_text())

poses=floor['placement']['anchors']; oldposes=oldfloor['placement']['anchors']
moved={f'C_ADC_CM{n}{leg}' for n in range(1,5) for leg in 'PN'}
pose_multiset=sorted(tuple(poses[r]) for r in moved)==sorted(tuple(oldposes[r]) for r in moved)
unchanged_poses=all(poses[r]==oldposes[r] for r in set(poses)-moved)

stubs=route['prep']['seed_stubs']['stubs']; oldstubs=oldroute['prep']['seed_stubs']['stubs']
northpins={f'U_ADC.{p}' for p in (39,40,41,42,45,46,47,48)}
def stripnet(rows): return {r['pin']:{k:v for k,v in r.items() if k!='net'} for r in rows}
seed_geometry_unchanged=stripnet([r for r in stubs if r['pin'] in northpins])==stripnet([r for r in oldstubs if r['pin'] in northpins])
seed_net_changes=sum(1 for a,b in zip(oldstubs,stubs) if a!=b and a['pin'] in northpins and {k:v for k,v in a.items() if k!='net'}=={k:v for k,v in b.items() if k!='net'})

groups=nets['length_match']; paths=0; endpointset=set(); netset=set(); north_paths=0; northendpointset=set(); north_groups=0
for name,g in groups.items():
 if not name.startswith('ANALOG_CH'): continue
 for leg in 'PN':
  for path in g['paths'][leg]:
   paths+=1
   for s in path['segments']:
    netset.add(s['net']); endpointset.update((s['from'],s['to']))
    if name.startswith(tuple(f'ANALOG_CH{i}_' for i in range(1,5))) and name.endswith('_ADC'):
     north_paths+=1; northendpointset.update((s['from'],s['to']))
 if name.endswith('_ADC') and name.startswith(tuple(f'ANALOG_CH{i}_' for i in range(1,5))): north_groups+=1

tsx=(C/'03_tscircuit/src/crow_audio_carrier_v1.tsx').read_text()
first=(C/'03_src/rules/first_article.yaml').read_text()
out={
 'input_count':len(env['input_packet']),'input_mismatches':bad,
 'map':mp,'slot_to_pod':slot,
 'pose_multiset_unchanged':pose_multiset,'all_other_fixed_poses_unchanged':unchanged_poses,
 'north_seed_geometry_unchanged':seed_geometry_unchanged,'north_seed_net_changes':seed_net_changes,
 'analog_census':{'groups':sum(1 for n in groups if n.startswith('ANALOG_CH')),'nets':len(netset),'endpoints':len(endpointset),'paths':paths,'north_adc_groups':north_groups,'north_adc_endpoints':len(northendpointset),'north_adc_paths':north_paths},
 'tsx_imports_json':'import channelMap from "../../03_src/adc_channel_map.json"' in tsx,
 'tsx_checks_exact_keys':('Object.keys(channelMap)' in tsx or 'set(channelMap)' in tsx),
 'tsx_checks_nonempty_id':bool(re.search(r'channelMap\.id[^\n]*(trim|length)',tsx)),
 'first_article_rule_mentions_map':bool(re.search(r'adc_channel_map|crow-carrier-channel-map|slot_to_pod|pod_to_adc',first,re.I)),
 'changed_files':json.loads((R/'changed.json').read_text())
}
print(json.dumps(out,indent=2))
