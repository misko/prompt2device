from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import json, hashlib, sys
sys.dont_write_bytecode = True
R = Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
N = Path(__file__).parent
sys.path.insert(0, str(R/'skills/kicad-pcb/scripts'))
import model_coverage_check as coverage
import pcbnew
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
result = {'created_at': datetime.now(timezone.utc).isoformat(), 'scope': 'Read-only native scene declarations and stable renewal dependency preparation; no claim of actual visible model rendering or checkpoint acceptance.', 'projects': {}}
for slug in ['crow-audio-carrier-v1', 'crow-mic-pod-v3']:
    project = R/'projects'/slug
    board_path, = (project/'04_kicad').glob('*.kicad_pcb')
    before = sha(board_path)
    board = pcbnew.LoadBoard(str(board_path))
    env = coverage.kicad_env(board_path)
    rows = []
    for fp in sorted(board.GetFootprints(), key=lambda fp: fp.GetReference()):
        models = []
        for model in fp.Models():
            resolved = coverage.resolve_model(model.m_Filename, env, board_path.parent)
            models.append({'declared': model.m_Filename, 'resolved': resolved, 'sha256': sha(Path(resolved)) if resolved else None,
                           'show': bool(model.m_Show) if hasattr(model, 'm_Show') else 'UNKNOWN',
                           'offset': [model.m_Offset.x, model.m_Offset.y, model.m_Offset.z],
                           'rotation': [model.m_Rotation.x, model.m_Rotation.y, model.m_Rotation.z],
                           'scale': [model.m_Scale.x, model.m_Scale.y, model.m_Scale.z]})
        rows.append({'ref': fp.GetReference(), 'fitted_by_coverage': coverage.fitted(fp), 'attributes': fp.GetAttributes(),
                     'position_mm': [pcbnew.ToMM(fp.GetPosition().x), pcbnew.ToMM(fp.GetPosition().y)],
                     'orientation_deg': fp.GetOrientationDegrees(), 'layer': fp.GetLayerName(), 'models': models})
    inputs = json.loads((project/'06_build/checkpoints/prelayout-inputs.json').read_text())
    dependencies = {k: v for k,v in inputs['files'].items() if any(x in k for x in ['connector_orientation_gate.py','model_coverage_check.py','skills/jlcpcb-fab/scripts/contracts.md'])}
    for key, expected in dependencies.items():
        path = R/key.removeprefix('repo:')
        assert path.stat().st_size == expected['size'] and sha(path) == expected['sha256']
    guards = {}
    for rel in ['06_build/checkpoints/prelayout-inputs.json','06_build/checkpoints/prelayout.json','06_build/checkpoints/schematic.json',
                '06_build/sourcing/prelayout_request.json','06_build/sourcing/prelayout_response.csv','06_build/sourcing/prelayout_receipt.json']:
        p = project/rel
        guards[rel] = {'sha256': sha(p), 'size': p.stat().st_size} if p.is_file() else None
    assert sha(board_path) == before
    counts = {'footprints': len(rows), 'fitted': sum(r['fitted_by_coverage'] for r in rows),
              'model_entries': sum(len(r['models']) for r in rows),
              'explicit_hidden_models': sum(m['show'] is False for r in rows for m in r['models']),
              'unresolved_entries': sum(m['resolved'] is None for r in rows for m in r['models']),
              'external_variable_entries': sum('${KICAD' in m['declared'] for r in rows for m in r['models']),
              'source_input_count': len(inputs['files'])}
    result['projects'][slug] = {'board_path': str(board_path), 'board_sha256': before, 'counts': counts,
                               'rows': rows, 'guards': guards, 'shared_dependencies': dependencies}
    print(slug, json.dumps(counts, sort_keys=True))
(N/'orientation-source-preparation.json').write_text(json.dumps(result, indent=2)+'\n')
