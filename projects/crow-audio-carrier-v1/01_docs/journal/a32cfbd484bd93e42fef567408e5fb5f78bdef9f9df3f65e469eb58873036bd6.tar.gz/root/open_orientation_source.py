from pathlib import Path
from datetime import datetime, timezone, timedelta
import sys, json, hashlib, shutil, tempfile
sys.dont_write_bytecode = True
R = Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
N = Path(__file__).parent
name = 'rj45-orientation-scene-source'
D = Path(tempfile.mkdtemp(prefix=name + '-'))
sys.path.insert(0, str(R / 'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput, subject_identity
from pipeline_runtime import open_agent_attempt
prev = json.loads((N/'rj45-orientation-visibility-review-opened.json').read_text())
assert json.loads((Path(prev['envelope']).parent/'attempt.json').read_text())['status'] == 'PASS'
prior = Path(prev['project'])
shutil.copytree(prior/'input', D/'input')
shutil.copytree(prior/'orientation', D/'prior-orientation')
shutil.copytree(Path(prev['output_dir']), D/'diagnosis')
# Keep the diagnosed packet current and include the owning test/contract readers.
paths = set()
for folder in ['skills/jlcpcb-fab/scripts', 'skills/kicad-pcb/scripts', 'skills/pcb-design/scripts']:
    paths.update((R/folder).glob('*.py'))
    paths.add(R/folder/'contracts.md')
for rel in ['CLAUDE.md', 'contracts.md', 'tests/README.md', 'tests/contracts.md',
            'tests/harness.py', 'tests/t1_connector_orientation.py',
            'skills/pcb-design/references/execution-runtime.md',
            'skills/pcb-design/references/lifecycle-and-backtrack.md',
            'skills/kicad-pcb/references/design-policies.md',
            'skills/jlcpcb-fab/references/connector-orientation.md']:
    paths.add(R/rel)
for p in paths:
    if p.is_file():
        q = D/'input'/p.relative_to(R)
        q.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, q)
shutil.copy2(prior/'preflight.py', D/'preflight.py')
now = datetime.now(timezone.utc)
cut = now + timedelta(minutes=30)
hard = now + timedelta(minutes=40)
(D/'TASK.md').write_text(f'''# Connector orientation: one coherent scene and camera correction

Fresh authoring successor after completed independent D-BACK. Root owns both live boards and repository source. READ_ONLY frozen input, prior-orientation, diagnosis. Edit only a working copy under allocated scratch. No children, commits, live edits, board/model edits, gate bypass or approval. Read CLAUDE, applicable policy canon, lifecycle/runtime, connector-orientation procedure and tests/README before implementation. Work cutoff {cut.isoformat()}, hard {hard.isoformat()}; at most TWO coherent implementation candidates, no replacement or angle-search campaign. Preserve every failed setup/test/variant. Existing layout/model/route campaign spend is unchanged.

The exact normal carrier board SHA9c30a147b2d94babd98bc2af4150d4e87270d2efb81a8bd39e88f1b9529a99f4 passes machine9/9 and model-registration6/6. Independent diagnosis found J1_inside actually shows J5mouth and J5_inside shows J1mouth due opposing-row occlusion, despite correct camera labels/calibration. Two prior read-only native diagnostics exposed upper rears at --side top --rotate 300,0,0 (J1 rear) and 60,0,0 (J5 rear); lower rears partly hidden by adjacent filmcaps. J9 current profiles are small/dark but identifiable. Read retained report and inspect actual source/images; do not inherit unverified visual acceptance.

Second linked cause: model_coverage_check.kicad_env synthesizes KICAD10_3DMODEL_DIR fallback under ~/.local/share/kicad/10.0/3dmodels. Twenty carrier external references resolve there but orientation render invokes CLI without explicit substitutions. It is UNKNOWN whether old CLI loaded those models. J1-J9/filmcap models resolve. Do not claim proved omission. This correction must bind and explicitly pass the same actual resolved native scene dependencies into CLI, fail missing required models, and preserve full populated scene. Inspect --help for exact native flags/environment precedence. Reuse existing resolver, no new general CAD parser. Bind active model transforms/positions/side and all relevant bodies/scene dependencies so nearby occluder changes invalidate approval, not just connector changes. Identify DNP/visibility behavior honestly; no claiming all333bodies solely from Python resolution.

Own minimal candidate files: skills/jlcpcb-fab/scripts/connector_orientation_gate.py; skills/jlcpcb-fab/references/connector-orientation.md; tests/t1_connector_orientation.py; necessary owning contracts/templates and tests/README for changed semantics. No new policy IDs or weaker limits/denominators. If a further production dependency must change, report why before editing it. Read-only source/model/test dependencies may be copied from live repo and local KiCad library with exact SHA binding. Frozen inputs remain unchanged; all working source under scratch.

Implement deterministic elevated inside evidence for opposing rows while preserving top/outside/inside for every unique tuple and all9machine refs. Prefer full-frame oblique view with clear target identification and board context; DO NOT feed oblique into cardinal strip crop or infer bbox from populated-minus-hidden image. Keep exact native models/PCB/positions unchanged. No hidden/removed bodies, fake labels, AI-generated/edited images or inside waiver. Burn in true camera, rotation, projection, target refs, subject and renderer identity. Current measured rotations supply the intended recipe; avoid speculative angle trials. Confirm actual target rear judgeable with explicit complete model environment. Native renders through current owning gate must retain actual command/environment dependency evidence and unchanged board SHA. Human approval remains owed even for valid machine evidence.

Update semantic engine identity for scene/camera behavior. IMPORTANT: schema2 deliberately permits regenerated pixels on unchanged semantic subject and maintained t_semantic_subject_approval_carry_forward expects this. Do NOT silently change that positive control or retire schema2. Bind new camera/scene semantics so both old schemas stale on material change; fresh user approval later via existing --approve-reviewer writes strict schema1. Preserve strict schema1 all-image hashes and exact key census; no existing schema2 can approve this new subject. This root scope decision is recorded in current placement journal/finding.

Tests: RED against exact prior code then GREEN corrected for new bug regressions. Test missing dependency refusal and explicit resolver propagation; changed scene body geometry/transform/model hash/camera invalidates both schemas; schema1 changed image key/hash fails; existing schema2 unchanged-semantic pixel regeneration remains supported. Preserve signed-Z/mating/axis controls. Opposing-row evidence must show valid machine labels alone do not prove target rear; native positive elevated/full-scene evidence identifies target and preserves denominator. Do not claim an automated occlusion oracle from camera choice alone. Preserve any remaining blind spot explicitly through existing maintained mechanisms if applicable, with no false PASS. Run applicable docs/authority/contracts checks for changed files. Root independently reviews exact candidate before adoption; author cannot accept own source or release.

All native/tests bounded through pipeline_runtime.run_stage, explicit cwd/env and /usr/bin/python3 -B, per-stage <=300s, logs/runtime retained. Reuse qualified native tool evidence when exact tool/cache identity valid. No normal live regeneration/checkpoint manipulation or KRT. Deliver EXACTLY report.md,evidence.json,evidence-manifest.json,evidence.tar.gz,result.json. evidence.domain_result nonempty string separates engineering verdict from delivery. Archive source_candidate/<repo-relative files>, beforeimages, diff, fresh methods/logs/runtime/actual rendered evidence and regression results. No recursive earlier archives in new archive. Manifest archive_sha256/archive_size/member_count/members(path,size,sha256); reopen all regular members, no traversal/symlinks/duplicates. result exact envelope subject with checks evidence-complete,inputs-verified,review-complete; unresolved[] only for complete honest handback. Run provided preflight then actual FINAL promptly. FIRST-ARTICLE-ONLY / DO-NOT-ORDER; no release or human approval.
''')
items = []
for p in sorted(D.rglob('*')):
    if p.is_file():
        b = p.read_bytes()
        items.append({'name': f'input_{len(items):04d}', 'path': p.relative_to(D).as_posix(), 'size': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
s = subject_identity('orientation_scene_correction', 1, [TypedIdentityInput('packet', 'sequence', items, json.dumps(items, sort_keys=True).encode())])
e = TaskEnvelope(schema=2, task_id=name, stage_id='KICAD-PLACEMENT', run_id=name, subject=s, executor='agent', execution_class='local', recommended_agent_role='authoring', agent_role='authoring', role_escalation_reason=None, context_mode='FRESH', input_handoff_id=name, input_packet=items, deadline_at=hard.isoformat().replace('+00:00','Z'), max_nonimproving_attempts=2, replacement_limit=0, writer_scope={'mode':'READ_ONLY','paths':[]}, output_path=f'06_build/task_runs/{name}/attempt.json', completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'], 'checks':['evidence-complete','inputs-verified','review-complete']})
o = open_agent_attempt(e, cwd=D)
o.update(project=str(D), envelope=str(D/e.output_path).replace('attempt.json','envelope.json'), task=str(D/'TASK.md'), agent_id='/root/carrier_rj45_orientation_scene_source', work_cutoff=cut.isoformat())
(N/(name+'-opened.json')).write_text(json.dumps(o, indent=2)+'\n')
print(json.dumps(o, indent=2))
print(len(items), 'frozen inputs')
