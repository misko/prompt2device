from pathlib import Path
import sys,json,hashlib,tarfile,io,shutil,subprocess
from datetime import datetime,timezone
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent
sys.path.insert(0,str(R/'skills/pcb-design/scripts'));from pipeline_execution import TaskEnvelope,verify_input_packet
sha=lambda b:hashlib.sha256(b).hexdigest();files={};references={};seen={};rows=[]
# Every duplicate stays reconstructible by immutable member hash; old journal
# archives are referenced only after verifying the committed exact preimage.
def add(n,f):
 b=f.read_bytes();h=sha(b)
 if f.name.endswith('.tar.gz') and len(f.stem.split('.')[0])==64:
  rel='projects/crow-audio-carrier-v1/01_docs/journal/'+f.name
  old=subprocess.check_output(['git','show','4793527e:'+rel],cwd=R);assert sha(old)==h
  references[n]={'git_commit':'4793527e','path':rel,'sha256':h,'size':len(b)}
 elif h in seen: references[n]={'archive_member':seen[h],'size':len(b),'sha256':h}
 else: files[n]=f;seen[h]=n
for name in ['cat-render-review','cat-layout-review','cat-render-binding-review','cat-review-consolidation']:
 j=json.loads((D/(name+'-opened.json')).read_text())[0];root=Path(j['project']);e=TaskEnvelope.from_json(Path(j['envelope']).read_text());a=json.loads(Path(j['attempt']).read_text());assert a['status']=='PASS' and verify_input_packet(e,root)[0]
 for x in e.input_packet:add(name+'/inputs/'+x.path,root/x.path)
 for f in Path(j['attempt']).parent.rglob('*'):
  if f.is_file() and f.name!='.closing':add(name+'/runtime/'+f.relative_to(Path(j['attempt']).parent).as_posix(),f)
 rows.append({'name':name,'inputs':len(e.input_packet),'status':a['status']})
for n in ['reopen_physical_reviews.py','physical-reviews-reopening.json','commission_consolidation.py','adopt_physical_reviews.py','physical-adoption.json','corridor_admission.py','check_corridor_admission.py','historical-corridor-reopening.json','proposed-current-corridor-finding.yaml']:
 add('root/'+n,D/n)
controls=json.loads((D/'corridor-admission-controls.json').read_text());add('root/corridor-admission-controls.json',D/'corridor-admission-controls.json')
for f in Path(controls['fixture_root']).glob('*'):
 if f.is_file():add('controls/'+f.name,f)
for prefix in ['cat-physical-owning','cat-corridor-admission']:
 for f in Path('/tmp/carrier-connector-integration-20260911').glob(prefix+'*'):
  if f.is_file():add('root/'+f.name,f)
for n in ['08_reviews/pre-route_pin.md','08_reviews/pre-route_render.md','08_reviews/pre-route_layout.md']:
 add('adopted/'+n,P/n)
(D/'physical-input-references.json').write_text(json.dumps(references,indent=2)+'\n');files['root/physical-input-references.json']=D/'physical-input-references.json'
(D/'physical-preservation-reopening.json').write_text(json.dumps({'time':datetime.now(timezone.utc).isoformat(),'tasks':rows,'verified_references':len(references)},indent=2)+'\n');files['root/physical-preservation-reopening.json']=D/'physical-preservation-reopening.json'
members={n:{'size':f.stat().st_size,'sha256':sha(f.read_bytes())} for n,f in sorted(files.items())}
tmp=D/'physical-preserved.tar.gz'
with tarfile.open(tmp,'w:gz',compresslevel=3) as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 b=(json.dumps({'members':members},indent=2)+'\n').encode();m=tarfile.TarInfo('MANIFEST.json');m.size=len(b);t.addfile(m,io.BytesIO(b))
h=sha(tmp.read_bytes());out=P/'01_docs/journal'/(h+'.tar.gz');assert not out.exists();shutil.copyfile(tmp,out)
with tarfile.open(out) as t:
 assert set(t.getnames())==set(members)|{'MANIFEST.json'}
 for n,x in members.items():b=t.extractfile(n).read();assert len(b)==x['size'] and sha(b)==x['sha256']
result={'archive':str(out),'sha256':h,'size':out.stat().st_size,'members':len(members),'references':len(references),'tasks':rows};(D/'physical-preservation-result.json').write_text(json.dumps(result,indent=2)+'\n')
with (P/'01_docs/journal/contracts.md').open('a') as f:f.write(f'\n## Allowed Cat physical review and diagnostic admission evidence\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Four completed independent review packets, original binding/census defects preserved verbatim, complete corrected owning reports, raw admission controls and exact historical attempt reopening; all MANIFEST members and referenced preimages verified; no routed acceptance |\n')
print(json.dumps(result,indent=2))
