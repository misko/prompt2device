from pathlib import Path
import yaml,copy,json,hashlib
D=Path(__file__).parent;P=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1')
source=P/'03_src/route.yaml';original=yaml.safe_load(source.read_text());cfg=copy.deepcopy(original)
old=yaml.safe_load(Path('/tmp/carrier-corridor-admission-repair-5uem837z/old-proposal/route-north-adc-pilot.yaml').read_text())
wave=old['route']['waves'][0];assert wave['name']=='north_adc_pilot'
cfg['project']['build_dir']='06_build/route/north_adc_pilot'
cfg['prep']['waves']['groups']={'north_adc_pilot':wave['nets']}
cfg['route']['waves']=[wave]
# Preserve source-owned copper, current ownership/floors and every other option.
expected=copy.deepcopy(cfg);expected['project']['build_dir']=original['project']['build_dir'];expected['prep']['waves']['groups']=original['prep']['waves']['groups'];expected['route']['waves']=original['route']['waves'];assert expected==original
assert all(cfg['route'][k]['mode']=='enforce' for k in ['ownership_preflight','candidate_grade','exploration_guard'])
p=D/'current-pilot-config.yaml';p.write_text(yaml.safe_dump(cfg,sort_keys=False))
proof={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'pilot_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'only_overrides':['project.build_dir','prep.waves.groups','route.waves'],'waves':cfg['route']['waves'],'source_copper_and_other_fields_equal':True,'route_invoked':False}
(D/'current-pilot-config-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
