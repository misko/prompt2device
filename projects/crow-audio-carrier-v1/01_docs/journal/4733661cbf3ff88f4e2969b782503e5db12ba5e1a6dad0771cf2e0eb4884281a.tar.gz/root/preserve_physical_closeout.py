from pathlib import Path
import json,hashlib,tarfile,io,shutil
D=Path(__file__).parent;P=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1');I=Path('/tmp/carrier-connector-integration-20260911');sha=lambda b:hashlib.sha256(b).hexdigest();files={}
for pre in ['cat-physical-handoff','cat-physical-contracts','cat-physical-validation']:
 for f in I.glob(pre+'*'):
  if f.is_file():files['root/'+f.name]=f
for n in ['record_physical_boundary.py','preserve_physical_closeout.py','preserve_physical_reviews.py','physical-preservation-result.json','placement-preservation-result.json','corridor-ledger-adoption.json','build_current_pilot_config.py','current-pilot-config.yaml','current-pilot-config-proof.json','current_pilot_runner.py']:
 files['root/'+n]=D/n
for n in ['06_build/agent_handoff.yaml','01_docs/STATUS.md','01_docs/findings.yaml']:files['checkpoint/'+n]=P/n
m={n:{'size':p.stat().st_size,'sha256':sha(p.read_bytes())} for n,p in files.items()};tmp=D/'physical-closeout.tar.gz'
with tarfile.open(tmp,'w:gz') as t:
 for n,p in files.items():t.add(p,arcname=n,recursive=False)
 b=(json.dumps({'members':m},indent=2)+'\n').encode();x=tarfile.TarInfo('MANIFEST.json');x.size=len(b);t.addfile(x,io.BytesIO(b))
h=sha(tmp.read_bytes());out=P/'01_docs/journal'/(h+'.tar.gz');assert not out.exists();shutil.copyfile(tmp,out)
with tarfile.open(out) as t:
 assert set(t.getnames())==set(m)|{'MANIFEST.json'}
 for n,x in m.items():b=t.extractfile(n).read();assert len(b)==x['size'] and sha(b)==x['sha256']
with (P/'01_docs/journal/contracts.md').open('a') as f:f.write(f'\n## Allowed Cat physical checkpoint closeout\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Owning handoff/contract validation logs, cumulative two-attempt ledger, preparation-only current KRT config and syntax-parsed runner; no diagnostic dispatched; reopen MANIFEST members |\n')
with (P/'01_docs/journal/schematic.md').open('a') as f:f.write(f'\n- Closeout: handoff7950bytesvalid; contracts17464files,2873existingdebt/26unitsheld,0strays. Closeoutarchive`{h}.tar.gz`,{out.stat().st_size}bytes/{len(m)}members,allreopened. Pilotconfiguration inherits exactcurrentroute.yaml and changes onlybuilddir/prepgroup/singlewave; runner syntaxparsedonly, noexecutionclaim. Current source remainsfrozen.\n')
print(json.dumps({'sha256':h,'size':out.stat().st_size,'members':len(m)}))
