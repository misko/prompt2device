import sys,os,json,dataclasses
sys.dont_write_bytecode=True
from pathlib import Path
sys.path.insert(0,'/home/mouse9911/gits/circuits/skills/pcb-design/scripts')
from pipeline_runtime import run_stage
W=Path(__file__).parent
r=run_stage({'id':'readability-preflight','work_class':'local','timeout_s':60},['/usr/bin/python3',str(W.parents[3]/'preflight.py'),str(W.parent/'envelope.json')],cwd=W,env={'PATH':os.environ['PATH'],'HOME':os.environ['HOME'],'PYTHONDONTWRITEBYTECODE':'1'},log_path=W/'preflight.log')
(W/'preflight-runtime.json').write_text(json.dumps(dataclasses.asdict(r),indent=2,default=str))
