from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,io,datetime
S=Path(__file__).parent;R=S.parents[3];O=S.parent/'outputs';P=R/'project';H=lambda b:hashlib.sha256(b).hexdigest()
e=json.loads((S.parent/'envelope.json').read_text());m=json.loads((S/'measurements.json').read_text());x=json.loads((S/'supplement.json').read_text());pages=json.loads((S/'page-equivalence.json').read_text())
verified=[]
for row in e['input_packet']:
 b=(R/row['path']).read_bytes();assert H(b)==row['sha256'] and len(b)==row['size'];verified.append(row['path'])
(S/'inputs-after.json').write_text(json.dumps({'verified':len(verified),'canonical_envelope_sha256':H(json.dumps(e,sort_keys=True,separators=(',',':')).encode()),'paths':verified},indent=2))
report='''review_stage: pre-route
review_kind: schematic_render
reviewer_identity: Codex /root/carrier_rj45_native_carrier_readability_mixedside1
context: FRESH
date: 2026-09-13
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
'''+''.join(f'{k}: {v}\n' for k,v in m['current_hashes'].items())+f'''
Fresh current-subject readability review is complete. No actionable schematic readability defect was found.

MEASURED: all 748 frozen input files verified before and after review. Canonical envelope SHA-256 6497e39637dc5504b7a872b04e72d75ad1ee73335913cb58ddd5d6bb4b2a7f6d verified. All seven subject hashes independently recomputed using the frozen owning algorithm, including 89 part dossiers. Current schematic checkpoint entries verify 7/7; prelayout checkpoint entries verify 11/11. The full prelayout-input checkpoint itself is exact-bound and contains 612 entries: all 318 whose bytes exist in this packet independently verify; the other 294 are outside this frozen packet and are not claimed independently verified here. Coordinator reports full-source verification separately. This scope does not accept prelayout.

MEASURED: independent Poppler rendering and Pillow RGB-byte comparison proves 19/19 current PDF drawing bodies equal to the immediately accepted fabfeatures1 delivered PDF at 120 dpi. Only y<100 pixels is excluded from body comparison; actual full-page difference boxes are entirely y=83..97 inclusive, in generated identity captions. Body comparison covers {pages['total_body_pixels']:,} pixels per subject, zero changed drawing bodies. All current/accepted page body hashes, dimensions and full difference boxes are archived.

I opened and inspected all 19 full current page images and a current header contact sheet. Current headers correctly identify CircuitJSON prefix 87c642a90c97da05, pages 1..19 and component counts summing to 333. Current page coverage: input/protection 1; buck 2; held LDO 3; supervision 4; delayed LDO/dump 5; all eight analog channels 6..13; ADC/configuration 14; passive external bias 15; VMID/reference banks 16; MCH clock interface 17; TDM return 18; reset 19. The ten contact labels on each of eight RJ45 symbols are distinguishable. Wires and junctions, power and shield names, capacitor and diode polarity, filter shunts, and NC stubs remain readable. This judgment is based on actual rendered images, not text extraction.

MEASURED: complete independent native S-expression parsing gives 333 current and 333 accepted components, 985 pin/net rows and 221 nets including 42 NC nets. Components, values, footprints, non-sheet properties and pin/net rows have zero additions, removals or changed rows. Current CircuitJSON source-trace unioning independently agrees with 943/943 connected native ports and 42/42 intentional NC ports, with only the authored N() prefix transformation for digit-leading net names. The first-power card has 333 unique installed references and matches native components exactly. All 80 RJ45 pin/net assertions pass: power 1/3/7, return 2/6/8, audio+ 5, audio- 4, shell 9/10. CHASSIS contains 16 shell contacts and is distinct from GND.

MEASURED source delta: 314 files have accepted counterparts; five differ. Among 310 common source/dossier files, 309 are byte-identical, and the sole change is route.krt from ~/gits/KiCadRoutingTools to /home/mouse9911/gits/KiCadRoutingTools-worktrees/cccv-5a1bdc4. This is a raw execution-path change expressly excluded by the owning design-v1 rule projection. The engineering-rule digest remains ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7. Router commit equality is commission provenance, not a fresh Git checkout inspection by this frozen-input reviewer. All electrical TSX, presentation TSX, part dossiers, libraries/models/footprints, floorplan and rule rows—including ratings and first-power limits—are unchanged. Accepted fabfeatures1 therefore already contains the current carrier RJ45 geometry. No voltage/current ceiling rose.

The four changed generated artifacts are CircuitJSON, PDF, native schematic and netlist. All electrical, schematic, PCB and CAD record groups in CircuitJSON are equal. Its changed groups are source filesystem MD5 metadata and supplier diagnostics: part-not-found warnings 67 current versus 46 accepted; footprint-mismatch warnings 149 versus 152. The full native schematic differs only by UUIDs and title date 2026-09-12 to 2026-09-13; full netlist equality follows replacement of UUID/date metadata. The frozen canonical netlist hash intentionally still changes with title-date metadata, so the exact newly generated bytes receive this fresh judgment. No generated netlist is accepted by a part/route-only source verdict.

MEASURED frozen ERC: zero errors and 2637 warnings, classified as 569 lib_symbol_issues and 2068 endpoint_off_grid. Four ignored classes remain preserved: singleton global labels, four-way connections, SPICE issues and footprint-filter mismatch. Zero errors is not all-severity clean.

INHERITED provenance: immediately accepted fabfeatures1 readability report SHA-256 f48620afd3ef795d83d81089ce60620b7de8c9c26e3dcd11cb572268edc01d3a is pinned by its successful delivery receipt; all seven accepted subject hashes independently match the accepted-subject bytes. It states no unresolved readability findings. Its unchanged-body historical visual coverage is preserved by the fresh all-page pixel measurement, alongside fresh actual current-page inspection. Previous reports are immutable receipts, not current acceptance. Prior maintained E-INV 205/205 is inherited unchanged-source context; fresh maintained E-INV execution belongs to the separately commissioned topology review and is not claimed as this review's execution. The coordinator confirmed that lens separation during this review.

Boundaries: current carrier connector SOURCE PASS and authentic FULL INCOMPLETE with 23 physical obligations were reopened. Pod population/schematic and its 9 physical obligations are outside this carrier-only lens; no historical pod denominator is adopted. Preserve factory Cat6A custom analog/power RJ45, NOT Ethernet/PoE, power-off mating, carrier CHASSIS and pod POD_SHIELD isolated from GND, FIRST-ARTICLE-ONLY / DO-NOT-ORDER. Public catalog design-only admission with blank operator response is not allocated stock or an order. No additional physical-measurement prerequisite is imposed before prototype fabrication. LAYOUT001 closed 3/3 remains unchanged commission context. No placement, routing, orientation, physical qualification, release or order acceptance is granted.

Limitations: equality is measured at 120 dpi; arbitrary print-scale/resolution equivalence is not claimed. An exploratory UUID-only native equality assertion failed because the title date also advanced; the exact diff was inspected and date-only metadata classified. That failed diagnostic and its log are preserved, and the completed measurements explicitly retain the raw change. It was not ignored or passed by restamping. No unrelated checker suite was repeated. Methods, bounded runtime receipts and raw logs, all 38 rendered pages, pixel comparisons and independent graph data are archived. Packaging/preflight execution receipts remain in scratch to avoid self-reference. Delivery completeness is separate from domain acceptance.
'''
(O/'report.md').write_text(report)
observations={'all_current_pages_opened':list(range(1,20)),'header_sheet_opened':True,'page_component_counts':[6,13,13,14,10]+[27]*8+[12,8,12,9,11,9],'findings':[],'judgment':'SOUND','method':'Host view_image on each current Poppler-rendered page and header contact sheet; inspect named wires, ports, labels, polarity, NC and margins.'}
assert sum(observations['page_component_counts'])==333
(S/'visual-observations.json').write_text(json.dumps(observations,indent=2))
evidence={'schema':1,'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','subject':e['subject'],'subject_hashes':m['current_hashes'],'canonical_envelope_sha256':m['canonical_envelope_sha256'],'methods':['Frozen owning seven-hash algorithm','Independent complete S-expression graph parser','CircuitJSON source-trace disjoint-set graph comparison','Poppler 120 dpi render of both delivered PDFs and exact Pillow RGB body comparison','Actual host view_image inspection of all 19 current pages','Frozen input SHA256 and checkpoint reopen','Independent tar member reopening'], 'counts':{'input_files_before':748,'input_files_after':748,'part_dossiers':89,'current_pages_inspected':19,'pages_body_equal':19,'pixels_per_subject':pages['total_body_pixels'],'native_components':333,'native_pin_rows':985,'native_nets':221,'connected_port_parity':943,'nc_port_parity':42,'rj45_pin_assertions':80,'common_source_files':310,'source_changed':1,'schematic_checkpoint':7,'prelayout_checkpoint':11,'full_checkpoint_entries':612,'full_checkpoint_bytes_in_packet_verified':318},'findings':[],'inherited':{'accepted_report_sha256':'f48620afd3ef795d83d81089ce60620b7de8c9c26e3dcd11cb572268edc01d3a','accepted_subject_hashes':m['accepted_hashes'],'maintained_einv':'205/205 prior accepted; fresh execution in separate topology lens','physical_and_order_boundaries':'Carrier SOURCE PASS/FULL INCOMPLETE23; pod9 context; FIRST-ARTICLE-ONLY/DO-NOT-ORDER'},'limitations':['Body equality at120dpi only','294 checkpoint entries outside frozen packet are not independently byte-verified by this reviewer','No pod/layout/route/release/ordering acceptance','UUID-only exploratory assertion failed and was classified as title-date metadata change'],'evidence_files':['measurements.json','supplement.json','page-equivalence.json','visual-observations.json','native-graph.json','source-diffs.txt','native-normalized.diff','netlist-metadata.diff','inputs-after.json']}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
# Stable exact archive source census, excluding this active producer's telemetry and packaging/preflight sidecars.
items={p.relative_to(S).as_posix():p.read_bytes() for p in sorted(S.rglob('*')) if p.is_file() and p.name not in ['packaging.log','packaging.runtime.json']}
for rel in ['accepted-receipts/readability/report.md','accepted-receipts/readability/delivery-attempt.json','accepted-receipts/readability/evidence-manifest.json','expected-subject.json']:
 items['provenance/'+rel]=(R/rel).read_bytes()
items['provenance/envelope.json']=(S.parent/'envelope.json').read_bytes()
items['runtime-source/pipeline_runtime.py']=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts/pipeline_runtime.py').read_bytes()
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,b in sorted(items.items()):
  assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
  t=tarfile.TarInfo(name);t.size=len(b);t.mtime=0;tar.addfile(t,io.BytesIO(b))
member_rows=[];seen=set()
with tarfile.open(archive,'r:gz') as tar:
 for member in tar.getmembers():
  assert member.isfile() and not member.issym() and not member.islnk()
  assert member.name not in seen and '..' not in PurePosixPath(member.name).parts and not PurePosixPath(member.name).is_absolute()
  assert not member.name.endswith(('.tar','.tar.gz'));seen.add(member.name)
  b=tar.extractfile(member).read();assert b==items[member.name] and len(b)==member.size
  member_rows.append({'path':member.name,'size':len(b),'sha256':H(b)})
assert seen==set(items)
(O/'evidence-manifest.json').write_text(json.dumps({'archive_sha256':H(archive.read_bytes()),'archive_size':archive.stat().st_size,'member_count':len(member_rows),'members':member_rows},indent=2)+'\n')
(O/'result.json').write_text(json.dumps({'subject':e['subject'],'checks':{k:'PASS' for k in e['completion']['checks']},'unresolved':[]},indent=2)+'\n')
assert sorted(p.name for p in O.iterdir())==['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md','result.json']
print(json.dumps({'outputs':sorted(p.name for p in O.iterdir()),'archive_members_reopened':len(member_rows),'archive_sha256':H(archive.read_bytes()),'archive_size':archive.stat().st_size,'design_verdict':'SOUND'}))
