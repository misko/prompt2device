import json,hashlib,tarfile,io,shutil
from pathlib import Path
from datetime import datetime,timezone
R=Path.cwd();S=Path(__file__).parent;O=S.parent/'outputs';E=json.loads((S.parent/'envelope.json').read_text())
def read(n):return json.loads((S/n).read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
after=[]
for row in E['input_packet']:
 p=R/row['path'];data=p.read_bytes();after.append(dict(path=row['path'],ok=len(data)==row['size'] and hashlib.sha256(data).hexdigest()==row['sha256']))
assert len(after)==980 and all(r['ok'] for r in after)
write(S/'inputs-after.json',after)
b=read('native-binding-independent.json');g=read('independent-ground-graph.json');raw=read('all-1004-rows-final.json');supp=read('source-native-supplement-quantized.json');loc=read('locator-full-identities.json');cons=read('remaining-consumer-complete-native-census.json');diag=read('diagnostics.json')
findings=[
 {'id':'NATIVE-ELECTRICAL','verdict':'SOUND','detail':'Exact reviewed NONE composition is realized. All234 GND modes,306fittedSMD top,434seed primitives,83regions, all designated prepared return/cut queries and full-disk closure bind. No supported electrical source/native repair is identified.'},
 {'id':'PROOF-VISIBILITY','verdict':'DEFECTIVE','detail':'Original custom native_source_binding visible_refs assertion is overbroad relative to P4/A-LOCATOR: it has no checked-locator alternative. Original driver FAIL remains immutable; it cannot be changed to PASS by this review.'},
 {'id':'LOCATOR-CURRENT','verdict':'INCOMPLETE','detail':'All23 native hidden references equal policy, source locator and generated omission list; body/value/MPN/LCSC/side/position/rotation and exact pad-net identities bind23/23. Frozen packet lacks current_assembly/assembly_locator_manifest.json and exact current independent render acceptance. This says nothing about unexamined live directories. No waiver or native label usability acceptance is granted.'},
 {'id':'ROUTING','verdict':'INCOMPLETE','detail':'Ordinary499opens; prepared445opens and60 source-owned dangling warnings. GND singles U_PWR.2 and U_AUDIO.2 require routing to broad ground. All other556GND graph nodes share component0; all45filled islands are in that component. No unintended shortcut in the protected return queries.'},
 {'id':'REMAINING-CONSUMERS','verdict':'INCOMPLETE','detail':'READ_ONLY original-command analog rc2 and critical rc1 refuse C_A1P.1 lacking copper contact. Complete supplementary native census finds16/16 surface entry-clamp prefixes connected,0/16 downstream coupling endpoints connected, and0/144 post-buffer analog paths connected (24groups/48nets/192unique endpoint identities). Routed lengths, spread, resistance and full branch dominance remain ungraded, not failed measured budgets. Spoke8/8 and rules29checks/9classes/84rules pass as diagnostics only.'},
 {'id':'NEXT-OWNER','verdict':'SOUND','detail':'Normal coherent accepted-source/checkpoint/schematic/placement renewal is supported without a design change. Continue through owning gates using current exact artifacts. Correct the custom proof only by explicit checked A-LOCATOR exception handling composed with current independent render acceptance; still block while that evidence is absent/stale. The original driver FAIL and ordered graph/analog/critical/spoke/rules NOT_RUN remain unchanged. Six candidates spent,0pending; this review admits no seventh construction.'}
]
measured=dict(frozen_inputs=980,adopted_source_postimages=9,ground_pads_each=234,source_full=32,native_full=33,native_none=1,inherited=200,fitted_smd_top_each=306,source_anchors=141,source_seed_primitives=434,source_regions=83,changed_regions_exact=2,hidden_locator_identities=23,ground_layer_island_nodes=558,ground_edges=850,ground_components=3,ground_main_component_nodes=556,filled_islands=45,ordinary_rows=499,prepared_rows=505,total_rows=1004,endpoint_records=1948,endpoint_identity_errors=0,prepared_dangling_tracks=39,prepared_dangling_vias=21,prepared_opens=445,remaining_ground_opens=2,analog_paths=144,analog_connected=0,critical_prefixes_connected=16,critical_downstream_connected=0,spoke_connectors=8,rules_checks=29,rules_current_classes=9,rules_fireable=84,min_resolved_spokes=2)
evidence=dict(verdict='INCOMPLETE',native_electrical_realization='SOUND',delivery_verdict='PASS',subject=E['subject'],review_scope='Fresh independent exact saved native candidate6 and bounded D-BACK; read-only frozen packet only',completed_at=datetime.now(timezone.utc).isoformat(),methods=[
 '980 envelope hashes verified before and after; independently rebound9 adopted source postimages. Native input manifest has889entries;888still match, with generated04_kicad project settings naturally changed by recorded generation/rules stages. This historical pre-generation manifest is not a current-output manifest.',
 'review_native.py: independently authored extraction of both saved boards; all GND pad shapes/positions/layers/local properties; separate filled islands including holes; native effective-shape x-sweep collision graph; plated barrels only interlayer links; DFS deletion cuts; analytical full-disk-to-boundary distance.',
 'supplement.py: full native source override/region/floor checks, corrected explicit0.001mm prep rounding for via inventory; all144analog/32critical relationships enumerated independently without substituting a consumer PASS.',
 'Frozen original consumers executed separately as READ_ONLY diagnostics with explicit relocated packet paths, frozen project cwd and scratch outputs/TMPDIR; no changed checker code, native writes, driver rerun or gate reordering.',
 'Root methods/native_returns.py was inspected as an unexecuted intended checker and never executed/imported. Root classification and intended graph are not independent evidence here.'
 ],findings=findings,measured=measured,artifacts={ 'native_binding':'scratch/native-binding-independent.json','source_binding':'scratch/source-native-supplement-quantized.json','source_primitives':'scratch/seed-bindings-quantized.json','all_rows':'scratch/all-1004-rows-final.json','ground_graph':'scratch/independent-ground-graph.json','locator_full_identities':'scratch/locator-full-identities.json','remaining_consumer_census':'scratch/remaining-consumer-complete-native-census.json','consumer_runtimes':'scratch/diagnostics.json'},limitations=['Current locator atlas/pixels were not included; no exact-artifact render usability verdict.', 'Prepared seed-only board is not routed/final-DRC/layout/fab/release accepted.', 'Native effective copper contact establishes topology, not impedance/current distribution or physical DCR.', 'Original diagnostic consumers abort on their first whole-net endpoint contact error; supplementary complete native census supplies the missing denominator without rewriting their verdicts.', 'Initial runtime-bootstrap file reads occurred before the shared runtime adapter was configured; all engineering subprocesses are bounded and their complete combined stdout/stderr and actual durations are retained.'],original_statuses_immutable=True,new_native_candidates=0)
write(O/'evidence.json',evidence)
report='''# Candidate6 exact native / D-BACK review

**Overall verdict: INCOMPLETE. Native electrical realization: SOUND. Delivery: PASS.**

The exact saved sixth candidate realizes the independently accepted source composition. No electrical design repair is supported by this review. Normal coherent source/checkpoint/schematic/placement renewal is justified; all owning current-artifact gates still apply. This review admits no seventh native construction. The original custom driver FAIL and subsequent ordered graph/analog/critical/spoke/rules NOT_RUN remain immutable.

## Subject and method

Raw subject: `{raw}`. Semantic subject: `{semantic}`. All980 frozen envelope inputs verified before and after, and all9 adopted source postimages independently rebound. The native pre-generation input manifest still matches888/889entries; its single changed generated `.kicad_pro` is an output of the recorded generation/rules stages, not changed source. The frozen findings snapshot intentionally records five spent candidates while current-handoff records six spent; this controlled metadata distinction is not electrical source staleness.

No BOARD was constructed, saved, regenerated, prepared, edited or property-mutated. Existing saved boards were loaded. An unchanged in-memory fill reproduced all45stored filled outlines exactly, including polygon/hole coordinates. Independently authored methods and all engineering logs/runtime receipts are archived. Root's intended `native_returns.py` was inspected but neither imported nor executed. Its original stage remains NOT_RUN.

## Exact electrical binding

Both unprepared and prepared boards contain234GND pads:33FULL (32source overrides plus existing U_ADC.49), one NONE,200inherited;306/306fittedSMD remain F.Cu. All234pad UUIDs, positions, dimensions, shape codes, rotations, copper layers and local settings are identical between saved stages. The full population is recorded, including25circular/18rectangular/1oval/190roundrect shapes. All33source pad overrides bind directly, all141explicit source anchors bind, and434/434authored seed primitives match actual UUID/net/layer/width/drill/geometry. Sixteen via coordinates require the producer's documented0.001mm prep rounding, which the independent initial probe exposed and the final explicit quantized binding records.

Only C_VDDA2_10N.2 is NONE: UUID `1d0d56e9-17dd-44d2-8ed2-cd3041e3433b`, GND, F.Cu, centre90.52,71.50mm,0.56×0.62mm roundrect,180°. U_ADC.49 remains FULL,4.6×4.6mm at96,70mm. All83source regions match the native conversion of their source geometry/layers/denial flags;80match mathematical nanometre rounding directly and3pre-existing non-denial rectangles differ by exactly1nm because KiCad's VECTOR2I_MM conversion truncates. Both changed areas ADC_VMID2_RETURN_POUR and ADC_WEST_LOCAL match exactly even under mathematical rounding. This is a measured conversion distinction, not permission to move geometry.

All8checked numerical design floors remain equal to source: track0.15,clearance0.127,via annulus0.13,hole clearance0.25,hole-to-hole0.5,copper-edge0.3,via diameter0.45,through drill0.2mm. All4GND zones retain thermal connection,0.25mmclearance/min thickness and0.5mmthermal gap/spoke width. Project minimum resolved spokes remains2. Actual ordinary DRC has0violations/499opens/0parity; prepared fullDRC has60dangling warnings/445opens/0parity and no starved thermal. Thus the prior thermal refusal has disappeared on the exact target without lowering its floor.

## Complete prepared return graph

The independent graph contains558layer/island nodes and850copper/barrel edges. Each filled polygon outline is a separate node with its holes; a zone UUID is never collapsed to its anchor. The45filled islands and all but2GND pads form one556node component. The other two components are isolated U_AUDIO.2 and U_PWR.2.

All4VMID capacitors reach their designated U_ADC.6/.8 owners on F.Cu without zone nodes; each reaches broad ground through its designated91.6,69.5 or89.8,71.5mm drop. C_VDDA2_10N.2 reaches U_ADC.8 and both VMID2caps on surface, with no direct ambient-zone contact; removing the designated drop (and the combined owner/drop cut) disconnects broad ground. Removing only the owner's pad node does not cut the co-located connected tracks; that stronger, different assertion is neither required nor claimed.

All3LT quiet returns reach C_LDO_OUT.2; deleting that output node disconnects broad ground, and no quiet pad directly contacts a zone. All5ADC ground pins6/8/30/17/44 reach the paddle through the multilayer ground network and do not reach it on F.Cu alone. ADC1supply reaches its90,67.5mm drop and broad plane. Its0.50mmdisk is contained on all4layers: minimum F.Cu boundary margin0.009500mm; other three layers0.315892mm. Full graph, cut memberships and actual polygons remain available for independent replay.

Root's intended checker uses effective shapes and separate islands but selects broad planes by an area>100mm² heuristic, counts4layer representations of one via as four drop nodes, and deletes object nodes for its cuts. This review explicitly checks those meanings: four broad-plane islands exist, the designated drops are one physical through via each, and owner-only deletion differs from removal of the owning drop. It does not elevate a source-side declaration to a native return proof.

## Every raw DRC row

All499ordinary rows plus505prepared rows are retained verbatim with index, collection, UUID/net/position binding and causal disposition:1,004rows and1,948endpoint records, zero unresolved identity/position discrepancies. Prepared39track_dangling and21via_dangling rows all bind to exact authored source banks. They are seed terminations waiting for normal remaining routing, not waived DRC. Every open is a same-net routing obligation; counts alone grant no acceptance.

Prepared GND open row33 connects broad-ground R_PWR_BOT.2 at29.175,56.7 to isolated U_PWR.2 at32.4,56.7. Row34 names the F.Cu zone UUID and isolated U_AUDIO.2 at32.4,61.1. That zone has15separate F.Cu islands, but the actual component graph proves all15join the same broad component through other copper. No choice of its16,20anchor was used as an island identity. These two pads require ordinary ground routing; protected-return topology reveals no unintended ambient shortcut or designated-return disconnect.

## Locator proof diagnosis

The custom `visible_refs = not invisible` assertion has no canonical exception path and is overbroad relative to P4/A-LOCATOR. But exact23set equality alone is insufficient to waive it. The source policy explicitly says the exception becomes effective only with a current checked bundle and independent exact-artifact render acceptance. A read-only canonical A-LOCATOR invocation fails in this frozen packet because `06_build/pre_route/current_assembly/assembly_locator_manifest.json` is absent. No atlas/pixels/current render review are in this packet. This does **not** infer absence in unexamined live folders.

All23body/value/MPN/LCSC/side/position/rotation/ref-text/pad-net identities bind23/23. Their complete UUID/shape/field records are in `locator-full-identities.json`. Their reference omission set equals source policy, source locator, and generated omission list. No evidence establishes a native label defect; usability acceptance is still owed. The smallest supported proof correction is an explicit canonical exception path: every omitted ref must belong to the exact checked A-LOCATOR set **and** carry current independent render acceptance. It must still fail if either is absent/stale. Do not globally force labels visible, drop the assertion, or retroactively relabel the original failure.

| Hidden ref | Body centre mm | Rotation | Pad1 net | Pad2 net |
|---|---|---:|---|---|
'''.format(raw=E['subject']['raw_sha256'],semantic=E['subject']['semantic_sha256'])
for row in loc:
 e=row['source'];pads={p['number']:p['net'] for p in e['pads']};report+=f"| {e['ref']} | {e['x']}, {e['y']} | {e['rotation']} | {pads.get('1','')} | {pads.get('2','')} |\n"
report+='''
## READ_ONLY remaining-consumer diagnostics

The exact frozen analog,critical,spoke and rules consumers ran separately with paths relocated from the live worktree to this packet and outputs/TMPDIR under allocated scratch. The algorithms were not edited. Source/board hashes were guarded. These are diagnostics, not a resumed driver or a new ordering of its gates.

Analog exits2(INCOMPLETE), critical exits1(FAIL), both at `endpoint C_A1P.1 does not touch this net's copper`. Their entire original stdout/stderr is preserved. Their graph preflight considers whole-net endpoint contact, so this first error prevents a complete consumer report. Independent supplementary native geometry resolves the full affected population:16/16entry-to-clamp prefixes are connected on F.Cu; all16C_A1P/N through C_A8P/N downstream endpoints lack track contact. All144declared post-buffer analog paths in24groups/48nets/192unique endpoint identities are unconnected on this prepared board. Every individual endpoint pair is archived. These are unfinished routes, not measured length/spread/resistance budget exceedances. Full branch dominance,144routed path lengths, matching budgets and conditional resistance remain owed after routing. No protection PASS is inferred merely from the16prefixes being present.

Spoke diagnostic passes8/8exact generated board/schematic connector identities. Rules diagnostic passes29checks,9/9current declarations and84/84fireable rules, including rules-last ordering. Original ordered stages remain NOT_RUN despite these separately labelled results.

## Supported next owning decision

Continue normal coherent renewal from the accepted9file source composition through source/checkpoint/schematic/placement owners. Preserve all historical failures and the six-spent/zero-pending ledger. No electrical source redesign or seventh native construction is supported/admitted by this review. The stopped custom proof needs the bounded canonical A-LOCATOR path above; actual current atlas/BOM/CPL/tool/PCB/member binding,23/23independent render usability and normal placement reviews must be renewed before current placement acceptance. Root's ongoing source/schematic renewal is outside this frozen subject and has not been independently adopted here.

Remaining routing includes both isolated ground pads, all ordinary open endpoints,60dangling source terminations,16protection downstream branches and144analog paths. Preserve every numerical floor and test the final routed artifact through its normal DRC/parity/protection/analog/rules gates. Pod five-view human orientation remains owed. FIRST-ARTICLE-ONLY / DO-NOT-ORDER; no final routed,layout,fabrication,release or ordering acceptance is granted.

Delivery completeness means the requested bounded judgment, measured evidence and honest limitations are all handed back. It does not turn engineering INCOMPLETE into acceptance. Initial read-only runtime-bootstrap reads preceded the shared adapter; every engineering subprocess used finite pipeline_runtime execution with full combined logs and actual durations. No source requalification tests, children, live writes, native mutations or construction were performed.
'''
(O/'report.md').write_text(report)
write(O/'result.json',dict(subject=E['subject'],checks={k:'PASS' for k in E['completion']['checks']},unresolved=[]))
originals=['TASK.md','canon/CLAUDE.md','canon/SKILL.md','canon/design-policies.md','canon/lifecycle-and-backtrack.md','current-handoff/STATUS.md','current-handoff/candidate6-stopped-outcome.json','current-handoff/candidate6-completed-assessment.json','current-handoff/none-reviewed-source-adoption.json','native/methods/native_driver6.py','native/methods/native_returns.py','native/methods/native_source_binding.py','native/native-stage-results.json','native/placement-drc.json','native/prepared-drc.json','native/carrier-source-native-binding.json','native/logs/prepared-source-binding.log','root-runtime/candidate6-guarded-native-runtime.json','root-runtime/candidate6-guarded-native.log']
entries=[]
for p in sorted(S.rglob('*')):
 if p.is_file() and not p.is_symlink() and not p.name.startswith(('packaging','preflight-final')):entries.append(('scratch/'+p.relative_to(S).as_posix(),p))
for name in originals:entries.append(('original/'+name,R/name))
entries.extend([('review/report.md',O/'report.md'),('review/evidence.json',O/'evidence.json'),('review/envelope.json',S.parent/'envelope.json')])
assert len({n for n,p in entries})==len(entries)
archive=O/'evidence.tar.gz';members=[]
with tarfile.open(archive,'w:gz') as tf:
 for name,p in entries:
  assert not p.is_symlink() and '..' not in Path(name).parts and not Path(name).is_absolute();data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tf.addfile(info,io.BytesIO(data));members.append(dict(path=name,size=len(data),sha256=hashlib.sha256(data).hexdigest()))
with tarfile.open(archive,'r:gz') as tf:
 got=tf.getmembers();assert len(got)==len(members) and len({m.name for m in got})==len(got)
 for actual,expected in zip(got,members):
  assert actual.isfile() and not actual.issym() and not actual.islnk() and actual.name==expected['path'];data=tf.extractfile(actual).read();assert len(data)==expected['size'] and hashlib.sha256(data).hexdigest()==expected['sha256']
write(O/'evidence-manifest.json',dict(archive_sha256=digest(archive),archive_size=archive.stat().st_size,member_count=len(members),members=members))
print(json.dumps(dict(verdict='INCOMPLETE',native_electrical='SOUND',inputs=len(after),members=len(members),archive_sha256=digest(archive),archive_size=archive.stat().st_size)))
