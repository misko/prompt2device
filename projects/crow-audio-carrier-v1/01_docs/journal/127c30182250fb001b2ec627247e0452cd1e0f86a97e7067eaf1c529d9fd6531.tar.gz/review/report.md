# Candidate6 exact native / D-BACK review

**Overall verdict: INCOMPLETE. Native electrical realization: SOUND. Delivery: PASS.**

The exact saved sixth candidate realizes the independently accepted source composition. No electrical design repair is supported by this review. Normal coherent source/checkpoint/schematic/placement renewal is justified; all owning current-artifact gates still apply. This review admits no seventh native construction. The original custom driver FAIL and subsequent ordered graph/analog/critical/spoke/rules NOT_RUN remain immutable.

## Subject and method

Raw subject: `15a88336ac605cdbe7be02a5654305ae206f30d9caa855bae87f0273281f06b0`. Semantic subject: `5060147ab77a59696067f1f8215618ec57da8f5598171639ee9b6babf0310352`. All980 frozen envelope inputs verified before and after, and all9 adopted source postimages independently rebound. The native pre-generation input manifest still matches888/889entries; its single changed generated `.kicad_pro` is an output of the recorded generation/rules stages, not changed source. The frozen findings snapshot intentionally records five spent candidates while current-handoff records six spent; this controlled metadata distinction is not electrical source staleness.

No BOARD was constructed, saved, regenerated, prepared, edited or property-mutated. Existing saved boards were loaded. An unchanged in-memory fill reproduced all45stored filled outlines exactly, including polygon/hole coordinates. Independently authored methods and all engineering logs/runtime receipts are archived. Root's intended `native_returns.py` was inspected but neither imported nor executed. Its original stage remains NOT_RUN.

## Exact electrical binding

Both unprepared and prepared boards contain234GND pads:33FULL (32source overrides plus existing U_ADC.49), one NONE,200inherited;306/306fittedSMD remain F.Cu. All234pad UUIDs, positions, dimensions, shape codes, rotations, copper layers and local settings are identical between saved stages. The full population is recorded, including25circular/18rectangular/1oval/190roundrect shapes. All33source pad overrides bind directly, all141explicit source anchors bind, and434/434authored seed primitives match actual UUID/net/layer/width/drill/geometry. Sixteen via coordinates require the producer's documented0.001mm prep rounding, which the independent initial probe exposed and the final explicit quantized binding records.

Only C_VDDA2_10N.2 is NONE: UUID `1d0d56e9-17dd-44d2-8ed2-cd3041e3433b`, GND, F.Cu, centre90.52,71.50mm,0.56×0.62mm roundrect,180°. U_ADC.49 remains FULL,4.6×4.6mm at96,70mm. All83source regions match the native conversion of their source geometry/layers/denial flags;80match mathematical nanometre rounding directly and3pre-existing non-denial rectangles differ by exactly1nm because KiCad's VECTOR2I_MM conversion truncates. Both changed areas ADC_VMID2_RETURN_POUR and ADC_WEST_LOCAL match exactly even under mathematical rounding. This is a measured conversion distinction, not permission to move geometry.

All8checked numerical design floors remain equal to source: track0.15,clearance0.127,via annulus0.13,hole clearance0.25,hole-to-hole0.5,copper-edge0.3,via diameter0.45,through drill0.2mm. All4GND zones retain thermal connection,0.25mmclearance/min thickness and0.5mmthermal gap/spoke width. Project minimum resolved spokes remains2. Actual ordinary DRC has0violations/499opens/0parity; prepared fullDRC has60dangling warnings/445opens/0parity and no starved thermal. Thus the prior thermal refusal has disappeared on the exact target without lowering its floor.

## Complete prepared return graph

The independent graph contains558layer/island nodes and850copper/barrel edges. Each filled polygon outline is a separate node with its holes; a zone UUID is never collapsed to its anchor. The45filled islands and all but2GND pads form one556node component. The other two components are isolated U_AUDIO.2 and U_PWR.2.

All4VMID capacitors reach their designated U_ADC.6/.8 owners on F.Cu without zone nodes; each reaches broad ground through its designated91.6,69.5 or89.8,71.5mm drop. C_VDDA2_10N.2 reaches U_ADC.8 and both VMID2caps on surface, with no direct ambient-zone contact; removing the designated drop (and the combined owner/drop cut) disconnects broad ground. Removing only the owner's pad node does not cut the co-located connected tracks; that stronger, different assertion is neither required nor claimed.

All3LT quiet returns reach C_LDO_OUT.2; deleting that output node disconnects broad ground, and no quiet pad directly contacts a zone. All5ADC ground pins6/8/30/17/44 reach the paddle through the multilayer ground network and do not reach it on F.Cu alone. ADC1supply reaches its90,67.5mm drop and broad plane. Its0.50mmdisk is contained on all4layers: minimum F.Cu boundary margin0.009500mm; other three layers0.315892mm. Full graph, cut memberships and actual polygons remain available for independent replay.

Root's intended checker uses effective shapes and separate islands but selects broad planes by an area>100mm² heuristic, counts4layer representations of one via as four drop nodes, and deletes object nodes for its cuts. This review explicitly checks those meanings: four broad-plane islands exist, the designated drops are one physical through via each, and owner-only deletion differs from removal of the owning drop. It does not elevate a source-side declaration to a native return proof.

## Every raw DRC row

All499ordinary rows plus505prepared rows are retained verbatim with index, collection, UUID/net/position binding and causal disposition:1,004rows and1,948endpoint records, zero unresolved identity/position discrepancies. Prepared39track_dangling and21via_dangling rows all bind to exact authored source banks. They are seed terminations waiting for normal remaining routing, not waived DRC. Every open is a same-net routing obligation; counts alone grant no acceptance.

Prepared GND open row33 connects broad-ground R_PWR_BOT.2 at29.175,56.7 to isolated U_PWR.2 at32.4,56.7. Row34 names the F.Cu zone UUID and isolated U_AUDIO.2 at32.4,61.1. That zone has15separate F.Cu islands, but the actual component graph proves all15join the same broad component through other copper. No choice of its16,20anchor was used as an island identity. These two pads require ordinary ground routing; protected-return topology reveals no unintended ambient shortcut or designated-return disconnect.

## Locator proof diagnosis

The custom `visible_refs = not invisible` assertion has no canonical exception path and is overbroad relative to P4/A-LOCATOR. But exact23set equality alone is insufficient to waive it. The source policy explicitly says the exception becomes effective only with a current checked bundle and independent exact-artifact render acceptance. A read-only canonical A-LOCATOR invocation fails in this frozen packet because `06_build/pre_route/current_assembly/assembly_locator_manifest.json` is absent. No atlas/pixels/current render review are in this packet. This does **not** infer absence in unexamined live folders.

All23body/value/MPN/LCSC/side/position/rotation/ref-text/pad-net identities bind23/23. Their complete UUID/shape/field records are in `locator-full-identities.json`. Their reference omission set equals source policy, source locator, and generated omission list. No evidence establishes a native label defect; usability acceptance is still owed. The smallest supported proof correction is an explicit canonical exception path: every omitted ref must belong to the exact checked A-LOCATOR set **and** carry current independent render acceptance. It must still fail if either is absent/stale. Do not globally force labels visible, drop the assertion, or retroactively relabel the original failure.

| Hidden ref | Body centre mm | Rotation | Pad1 net | Pad2 net |
|---|---|---:|---|---|
| C_AUDIO_CT2 | 30.0, 61.1 | 180.0 | AUDIO_CT | GND |
| C_FILT1_10U | 96.75, 62.55 | 0.0 | FILT1P | GND |
| C_FILT2_10U | 96.75, 77.45 | 0.0 | FILT2P | GND |
| C_PWR_CT | 36.0, 55.3 | 0.0 | PWR_CT | GND |
| C_VDDA2_10N | 91.0, 71.5 | 180.0 | 3V3_ADC | GND |
| C_VMID1_470N | 90.6, 65.7 | 180.0 | VMID1 | GND |
| C_VMID1_4U7 | 90.7, 63.9 | 180.0 | VMID1 | GND |
| C_VMID2_470N | 90.6, 74.3 | 180.0 | VMID2 | GND |
| C_VMID2_4U7 | 90.7, 76.1 | 180.0 | VMID2 | GND |
| R_ADC_BOT | 30.9, 64.5 | 90.0 | ADC_SENSE | GND |
| R_ADC_PD6N | 69.75, 85.1 | 180.0 | ADC6N | GND |
| R_ADC_TOP | 32.7, 64.5 | 90.0 | 3V3_ADC | ADC_SENSE |
| R_AUDIO_PD | 37.17, 59.65 | 90.0 | AUDIO_EN | GND |
| R_AUDIO_PU | 34.2, 63.4 | 90.0 | 5V_LDO_HOLD | AUDIO_EN |
| R_DUMP_TIME2 | 58.65, 78.2 | 0.0 | PWR_EN | DUMP_RC |
| R_FILT1P | 88.0, 61.3 | 0.0 | 3V3_ADC | FILT1P |
| R_IN6N | 67.55, 91.0 | 0.0 | BIAS_N6 | AIN_N6 |
| R_PRE_G | 43.6, 61.0 | 0.0 | PRE_GATE | 5V_LDO_FEED |
| R_PWR_TOP | 30.0, 54.9 | 180.0 | 5V_BUCK | PWR_SENSE |
| R_VMID1_BOT | 73.8, 74.6 | 90.0 | VMID1_EXT | GND |
| R_VMID1_TOP | 72.0, 74.6 | 90.0 | 3V3_ADC | VMID1_EXT |
| R_VMID2_BOT | 78.2, 75.7 | 90.0 | VMID2_EXT | GND |
| R_X6N | 65.9, 92.35 | 180.0 | FB_N6 | FILTER6N |

## READ_ONLY remaining-consumer diagnostics

The exact frozen analog,critical,spoke and rules consumers ran separately with paths relocated from the live worktree to this packet and outputs/TMPDIR under allocated scratch. The algorithms were not edited. Source/board hashes were guarded. These are diagnostics, not a resumed driver or a new ordering of its gates.

Analog exits2(INCOMPLETE), critical exits1(FAIL), both at `endpoint C_A1P.1 does not touch this net's copper`. Their entire original stdout/stderr is preserved. Their graph preflight considers whole-net endpoint contact, so this first error prevents a complete consumer report. Independent supplementary native geometry resolves the full affected population:16/16entry-to-clamp prefixes are connected on F.Cu; all16C_A1P/N through C_A8P/N downstream endpoints lack track contact. All144declared post-buffer analog paths in24groups/48nets/192unique endpoint identities are unconnected on this prepared board. Every individual endpoint pair is archived. These are unfinished routes, not measured length/spread/resistance budget exceedances. Full branch dominance,144routed path lengths, matching budgets and conditional resistance remain owed after routing. No protection PASS is inferred merely from the16prefixes being present.

Spoke diagnostic passes8/8exact generated board/schematic connector identities. Rules diagnostic passes29checks,9/9current declarations and84/84fireable rules, including rules-last ordering. Original ordered stages remain NOT_RUN despite these separately labelled results.

## Supported next owning decision

Continue normal coherent renewal from the accepted9file source composition through source/checkpoint/schematic/placement owners. Preserve all historical failures and the six-spent/zero-pending ledger. No electrical source redesign or seventh native construction is supported/admitted by this review. The stopped custom proof needs the bounded canonical A-LOCATOR path above; actual current atlas/BOM/CPL/tool/PCB/member binding,23/23independent render usability and normal placement reviews must be renewed before current placement acceptance. Root's ongoing source/schematic renewal is outside this frozen subject and has not been independently adopted here.

Remaining routing includes both isolated ground pads, all ordinary open endpoints,60dangling source terminations,16protection downstream branches and144analog paths. Preserve every numerical floor and test the final routed artifact through its normal DRC/parity/protection/analog/rules gates. Pod five-view human orientation remains owed. FIRST-ARTICLE-ONLY / DO-NOT-ORDER; no final routed,layout,fabrication,release or ordering acceptance is granted.

Delivery completeness means the requested bounded judgment, measured evidence and honest limitations are all handed back. It does not turn engineering INCOMPLETE into acceptance. Initial read-only runtime-bootstrap reads preceded the shared adapter; every engineering subprocess used finite pipeline_runtime execution with full combined logs and actual durations. No source requalification tests, children, live writes, native mutations or construction were performed.
