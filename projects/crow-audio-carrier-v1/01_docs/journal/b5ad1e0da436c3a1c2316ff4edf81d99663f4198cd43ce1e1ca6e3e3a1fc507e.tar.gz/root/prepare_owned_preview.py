from pathlib import Path
import shutil,json,hashlib,sys
sys.dont_write_bytecode=True
import pcbnew
D=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';Q=D/'silk-owned-candidate';B=D/'silk-owned-preview';assert not B.exists();shutil.copytree(Q,B)
b=pcbnew.LoadBoard(str(B/'04_kicad/crow_audio_carrier_v1.kicad_pcb'))
path=B/'03_src/rules/assembly_locator.yaml';old=json.loads(path.read_text());new=json.loads(path.read_text());assert len(old['exceptions'])==25
actual={f.GetReference() for f in b.GetFootprints() if not f.GetAttributes()&pcbnew.FP_BOARD_ONLY and not f.Reference().IsVisible()}
prior={x['ref'] for x in old['exceptions']};removed=[x for x in old['exceptions'] if x['ref'] not in actual];added=[]
assert prior-actual=={'R_FILT2P','R_DUMP_TIME1','R_VMID2_TOP'}
assert actual-prior=={'C_VDDA2_10N','R_FILT1P','R_VMID2_BOT'}
for name in sorted(actual-prior):
 f=b.FindFootprintByReference(name);fields={x.GetName():x.GetText() for x in f.GetFields()};supplier=json.loads(fields['Supplier Part Numbers']);assert len(supplier['jlcpcb'])==1
 added.append({'ref':name,'value':f.GetValue(),'mpn':fields['Manufacturer Part Number'],'lcsc':supplier['jlcpcb'][0],'x':f.GetPosition().x/1e6,'y':f.GetPosition().y/1e6,'rotation':f.GetOrientationDegrees(),'side':'top','pads':sorted([{'number':p.GetNumber(),'net':p.GetNetname()} for p in f.Pads()],key=lambda x:x['number'])})
new['exceptions']=[x for x in old['exceptions'] if x['ref'] in actual]+added;new['exceptions'].sort(key=lambda x:x['ref']);assert len(new['exceptions'])==25 and actual=={x['ref'] for x in new['exceptions']}
path.write_text(json.dumps(new,indent=2)+'\n');shutil.copyfile(P/'03_src/contracts.md',B/'03_src/contracts.md')
proposal=D/'silk-owned-source-proposal';proposal.mkdir()
for n in ['03_src/floorplan.yaml','03_src/rules/assembly_locator.yaml','03_src/contracts.md']:
 p=proposal/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(B/n,p)
record={'native_candidate_sha256':hashlib.sha256((B/'04_kicad/crow_audio_carrier_v1.kicad_pcb').read_bytes()).hexdigest(),'native_generation_count':1,'preview_is_exact_copy_of_generated_candidate':(B/'04_kicad/crow_audio_carrier_v1.kicad_pcb').read_bytes()==(Q/'04_kicad/crow_audio_carrier_v1.kicad_pcb').read_bytes(),'removed_exceptions':removed,'added_exceptions':added,'unchanged_exception_count':22,'count':25,'source_proposal_files':{str(p.relative_to(proposal)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size} for p in proposal.rglob('*') if p.is_file()},'scope':'Source proposal and assembly preview only, no live source changes or canonical replacement.'};(D/'silk-owned-source-proposal.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
