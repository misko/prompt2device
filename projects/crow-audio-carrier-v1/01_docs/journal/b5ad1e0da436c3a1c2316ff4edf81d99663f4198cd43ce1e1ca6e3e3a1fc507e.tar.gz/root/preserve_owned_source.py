from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess,tarfile,io,sys
sys.dont_write_bytecode=True
D=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';I=Path('/tmp/carrier-connector-integration-20260911');Q=D/'silk-owned-candidate';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();sha=lambda b:hashlib.sha256(b).hexdigest()
sys.path.insert(0,str(R/'skills/pcb-design/scripts'));from pipeline_execution import TaskEnvelope,verify_input_packet
files={};roots=[];tasks=[]
for name in ['owned-source-review','owned-label-availability']:
 j=json.loads((D/(name+'-opened.json')).read_text())[0];root=Path(j['project']);roots.append(root);e=TaskEnvelope.from_json(Path(j['envelope']).read_text());a=json.loads(Path(j['attempt']).read_text());assert a['status']=='PASS' and verify_input_packet(e,root)[0]
 for n,m in a['output']['completion']['outputs'].items():b=(Path(j['output_dir'])/n).read_bytes();assert sha(b)==m['sha256'] and len(b)==m['size']
 for item in e.input_packet:files[name+'/inputs/'+item.path]=root/item.path
 for f in Path(j['attempt']).parent.rglob('*'):
  if f.is_file():files[name+'/runtime/'+f.relative_to(Path(j['attempt']).parent).as_posix()]=f
 for suffix in ['-opened.json','-reopening.json']:
  if (D/(name+suffix)).is_file(): files['root/'+name+suffix]=D/(name+suffix)
 tasks.append({'name':name,'inputs':len(e.input_packet),'outputs':len(a['output']['completion']['outputs']),'status':a['status']})
for n in ['skills/kicad-pcb/scripts/generate_board_generic.py','skills/pcb-design/templates/contracts/03_src/contracts.md','tests/t1_generate_board.py']:
 assert (R/n).read_bytes()==(roots[0]/'authority'/n).read_bytes(),n
 files['accepted-code/'+n]=R/n
# The project copy carries the same new row, keeping its contract in sync.
f=P/'03_src/contracts.md';assert '`silk.refdes.preferred_offsets.<REF>`' in f.read_text();files['accepted-code/project-contract.md']=f
for prefix in ['silk-owned-', 'silk-all-hidden-owned-slots', 'preferred-rejection-contracts', 'preferred-rejection-handoff']:
 for f in I.glob(prefix+'*'):
  if f.is_file():files['root/validation/'+f.name]=f
idx=json.loads((D/'silk-owned-candidate-inputs.json').read_text())
for n,m in idx.items():
 f=Path(n);b=f.read_bytes();assert sha(b)==m['sha256'] and len(b)==m['size'];rel=f.relative_to(Q).as_posix() if f.is_relative_to(Q) else f.relative_to(R).as_posix();files['source-candidate/inputs/'+rel]=f
for n in ['04_kicad/crow_audio_carrier_v1.kicad_pcb','04_kicad/crow_audio_carrier_v1.kicad_pro','04_kicad/crow_audio_carrier_v1.kicad_dru','04_kicad/refdes_waiver.json']:
 files['source-candidate/generated/'+n]=Q/n
for base,label in [(D/'silk-owned-preview','candidate-preview'),(D/'silk-owned-source-proposal','candidate-source')]:
 for f in base.rglob('*'):
  if f.is_file():files[label+'/'+f.relative_to(base).as_posix()]=f
for n in ['preserve_owned_source.py','prepare_silk_owned_candidate.py','measure_silk_owned_candidate.py','silk-owned-candidate-inputs.json','silk-owned-candidate-measurement.json','commission_owned_source_review.py','silk-owned-source-proposal.json','measure_all_hidden_owned_slots.py','measure_all_hidden_owned_slots_executed.py','silk-all-hidden-owned-slots.json','all-hidden-output-recovery.json','open_owned_label_availability.py','prepare_owned_preview.py','owned-root-native-visual.json']:
 files['root/'+n]=D/n
# Exact committed references plus in-archive deduplication keep packets small.
def git_location(f):
 if f.is_relative_to(R):return head,f.relative_to(R).as_posix()
 if f.is_relative_to(Q):return head,'projects/crow-audio-carrier-v1/'+f.relative_to(Q).as_posix()
 for root in roots:
  for label in ['current','candidate','previous']:
   base=root/label
   if f.is_relative_to(base):return ('f2675b43' if label=='previous' else head),'projects/crow-audio-carrier-v1/'+f.relative_to(base).as_posix()
  for label in ['authority','before-code']:
   base=root/label
   if f.is_relative_to(base):return head,f.relative_to(base).as_posix()
 return None
cache={};git_by_hash={}
for n,f in files.items():
 pair=git_location(f)
 if pair:
  if pair not in cache:
   p=subprocess.run(['git','show',pair[0]+':'+pair[1]],cwd=R,capture_output=True);cache[pair]=p.stdout if p.returncode==0 else None
  b=f.read_bytes()
  if cache[pair]==b:git_by_hash[sha(b)]={'git_commit':pair[0],'path':pair[1],'size':len(b),'sha256':sha(b)}
refs={};seen={}
for n,f in list(sorted(files.items())):
 b=f.read_bytes();h=sha(b)
 if h in git_by_hash:refs[n]=git_by_hash[h];del files[n]
 elif h in seen:refs[n]={'archive_member':seen[h],'size':len(b),'sha256':h};del files[n]
 else:seen[h]=n
members={n:{'size':f.stat().st_size,'sha256':sha(f.read_bytes())} for n,f in files.items()};tmp=D/'owned-source.tar.gz'
with tarfile.open(tmp,'w:gz',compresslevel=3) as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 b=(json.dumps({'members':members,'references':refs,'tasks':tasks},indent=2)+'\n').encode();m=tarfile.TarInfo('MANIFEST.json');m.size=len(b);t.addfile(m,io.BytesIO(b))
h=sha(tmp.read_bytes());dest=D/(h+'.tar.gz');assert not dest.exists();tmp.rename(dest)
with tarfile.open(dest) as t:
 assert set(t.getnames())==set(members)|{'MANIFEST.json'} and len(t.getnames())==len(set(t.getnames()))
 assert all(x.isfile() and not Path(x.name).is_absolute() and '..' not in Path(x.name).parts for x in t.getmembers())
 for n,m in members.items():b=t.extractfile(n).read();assert sha(b)==m['sha256'] and len(b)==m['size']
 for n,m in refs.items():
  b=subprocess.check_output(['git','show',m['git_commit']+':'+m['path']],cwd=R) if 'git_commit' in m else t.extractfile(m['archive_member']).read()
  assert sha(b)==m['sha256'] and len(b)==m['size']
result={'time':datetime.now(timezone.utc).isoformat(),'archive':str(dest),'sha256':h,'size':dest.stat().st_size,'members':len(members),'references':len(refs),'tasks':tasks,'source_feature':'SOUND optional preferred_offsets capability; no project use adopted','physical_proposal':'See verbatim fresh owned-source-review engineering verdict; archive delivery is not acceptance.'};(D/'owned-source-preservation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
