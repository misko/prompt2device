from pathlib import Path
import shutil,json,tempfile,sys,subprocess
sys.dont_write_bytecode=True
D=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';Q=D/'silk-owned-preview';root=Path(tempfile.mkdtemp(prefix='carrier-owned-source-review-'));sys.path.insert(0,str(D));from open_review import open_review
for folder in ['skills/kicad-pcb/scripts','skills/jlcpcb-fab/scripts','skills/pcb-design/scripts']:
 shutil.copytree(R/folder,root/'authority'/folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for n in ['tests/t1_generate_board.py','tests/harness.py','tests/README.md','skills/pcb-design/templates/contracts/03_src/contracts.md','skills/kicad-pcb/references/design-policies.md']:
 q=root/'authority'/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/n,q)
for label,base in [('current',P),('proposed',Q)]:
 for n in ['03_src/floorplan.yaml','03_src/rules/assembly_locator.yaml','03_src/contracts.md','04_kicad/crow_audio_carrier_v1.kicad_pcb','04_kicad/crow_audio_carrier_v1.kicad_pro','04_kicad/crow_audio_carrier_v1.kicad_dru']:
  q=root/label/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(base/n,q)
 for n in ['03_src/rules/nets.yaml','03_src/rules/requirements.yaml']:
  q=root/label/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(base/n,q)
shutil.copytree(Q/'06_build/owned_assembly',root/'proposed/assembly')
for name in ['CL05B103KB5NNNC','CRCW12061R00FKEAHP']:
 q=root/'parts'/name;q.mkdir(parents=True);shutil.copyfile(P/'02_parts'/name/'part.yaml',q/'part.yaml')
for n in ['silk-owned-candidate-measurement.json','silk-owned-source-proposal.json','silk-all-hidden-owned-slots.json','measure_all_hidden_owned_slots.py','all-hidden-output-recovery.json']:
 shutil.copyfile(D/n,root/n)
shutil.copyfile(D/'silk-owned-candidate/06_build/drc/owned.json',root/'proposed/owned-drc.json')
shutil.copyfile(P/'08_reviews/2026-09-12_23bd1009_preferred_source_review.md',root/'rejected-prior-physical-report.md')
for prefix in ['silk-owned-','silk-all-hidden-owned-slots']:
 for f in Path('/tmp/carrier-connector-integration-20260911').glob(prefix+'*'):
  if f.is_file():q=root/'root-runs'/f.name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,q)
shutil.copyfile(P/'08_reviews/2026-09-12_0ab5b6da_silk_slot_review.md',root/'prior-slot-report.md')
open_review(root,'owned-source-review',"""Agent-role judgment. Fresh independent focused physical-label/source/locator review. The already committed shared preferred_offsets capability is SOUND (57df15a2; prior report supplied); no new code extension or code verdict is needed. Root solelivewriter, live floorplan/locator source unchanged. This is source candidate review before canonical regeneration, not full-placement acceptance.

Exact current native0ab5b6dae425074f2515dc3c3d737e56f2292d83140590dca592b7b964e73090 has27hidden/306visible. Proposed nativeef72e6d2f5400b481f397532a58784644b82bc88d5fa527f4c46b7a3356c822b generated ONCE7.276s with preferred_offsets R_DUMP_TIME1(+1.1,-1.6),R_VMID2_TOP(+1.5,+4.1). No priority_refs. Only those twoReferencefields changed; all306previousvisiblefields identical,340footprints/1002pads exact includingzoneconnection modes,380inputs unchanged. Both0.55mm/0.1125stroke, first90deg, second0deg. DRC0violations/499cappedunrouted/0parity. OwningplacementDRCPASS. No part/pad/net/zone geometry change.

Previous two source candidates REJECTED: priority reordered to28hidden; phase2R_FILT1P/R_VMID2_BOT reached25 but visuallyambiguous. Currentnewhypothesis instead recovers two different previouslyhiddenrefs with OWNEDclear slots; retainoriginalfailurejudgments. Root boundedall27hidden0.1mmradius11grid search preserving306visible found40ownedslots forR_DUMP_TIME1 (chosenowner1.94165mm/nearestotherR_DUMP_TIME2 3.42527mm) and13forR_VMID2_TOP(owner4.36578mm/nearestotherC_VMID2_EXT_10U4.87032mm). Remaining25had0sampledownedslots; noimpossibilityclaim. Searchruntime116.864s. Initialscratchoutputpathmiss overwrotepriorphase2JSON; originalthree-refJSONrestoredbyteexactfrompreexistingarchive, new27result preserved, scriptpathcorrectedprospectively. This isdisclosedtoolsurfaceissue, not source/boardmutation; don'tinferfreshmeasurementrerun. Actualgeneratedcandidateisultimategeometrysubject.

YOU must independently inspect native physical association of BOTH labels with actualF.Silk/F.Fab/pads neighborhood and fullcontext. Nearestcentroid inequalityalone is not visualacceptance. Legibility, crowdedlabels, wrongidenticalbody association, assemblyaccess and any newambiguity matter. Can exportSVG/nativePDF and actualviewcrops fromhashverifiedscratchcopies, no AI rendering. Exacttextual/nativecomparison must classifyall residuals, no blindprojectioninheritance. If bothunambiguousandclear, sourceSOUND; otherwise concreteDEFECTIVE and no furthercandidate generation withinthisreview.

Locator source proposal keepsceiling25,22oldexceptions byteidentical; remove nowvisibleR_FILT2P,R_DUMP_TIME1,R_VMID2_TOP; addcurrenthiddenC_VDDA2_10N,R_FILT1P,R_VMID2_BOT exact identities. Native candidatehidden set/config/page refs mustbeexactsame25. Independentcheckall333refs/995assembledpads, fullMPN/LCSC/value/XY/rotation/side/padnetidentityfor25omissions,51BOMrows/300CPLsamefittedset, expected33nonBOM. Viewall25pagecontactsheet and fullthreeaddedlocatorpages, verifyarrows/targets unambiguous. Manifestboundexactnativebytes andeverypage. Old306visiblelabels/allunchangedregions inherit priorinspection onlyafterexactnativeproof; no expandedfullrenderclaim. Suppliedparts include newlyadded cap/filterresistor; otheridentities native/config pluscanonical circuitmanifest. Do notguess unavailableowningrulesdigestforpartialnoncanonicalpacket.

No nativeboardgeneration, newoffsetsearch, codefeature, liveedit, canonicalrenewal, routing, network, children or fabricationorder. Oneboundedfreshreview. DeliverNONCANONICALreport with separate source/physical-label/locatorcandidate verdicts and exactscope. Actualcompletiontime, sourcecommit57df15a2 informationalbase. No currentplacement or release acceptance. LAYOUT0013/3spent unchanged. Normalcanonicalrenewal/full337sourcechecks/currentpin/render/layout/route/releasegates remainowed evenifthiscandidatepasses.""",15)
