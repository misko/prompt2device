from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
import pcbnew
D=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';Q=D/'silk-owned-candidate';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=(D/'verify_channel_pin_transfer.py').read_text();ns={'pcbnew':pcbnew};exec(s[s.index('def row(f):'):s.index("assert sha(current)")],ns)
a=pcbnew.LoadBoard(str(P/'04_kicad/crow_audio_carrier_v1.kicad_pcb'));b=pcbnew.LoadBoard(str(Q/'04_kicad/crow_audio_carrier_v1.kicad_pcb'));rows=lambda board:{f.GetReference():ns['row'](f) for f in board.GetFootprints()};ra,rb=rows(a),rows(b);assert ra==rb
hidden=lambda board: sorted(f.GetReference() for f in board.GetFootprints() if not f.Reference().IsVisible() and not f.GetAttributes()&pcbnew.FP_BOARD_ONLY)
x,y=hidden(a),hidden(b);inputs=json.loads((D/'silk-owned-candidate-inputs.json').read_text());assert all(sha(Path(n))==v['sha256'] and Path(n).stat().st_size==v['size'] for n,v in inputs.items())
def fields(board):
 return {f.GetReference():(f.Reference().IsVisible(),f.Reference().GetPosition().x,f.Reference().GetPosition().y,f.Reference().GetTextAngleDegrees(),f.Reference().GetTextSize().x,f.Reference().GetTextThickness()) for f in board.GetFootprints()}
fa,fb=fields(a),fields(b);changed=sorted(r for r in fa if fa[r]!=fb[r]);assert changed==['R_DUMP_TIME1','R_VMID2_TOP'],changed
assert len(y)==25 and set(y).issubset(x),y
record={'board_sha256':sha(P/'04_kicad/crow_audio_carrier_v1.kicad_pcb'),'candidate_sha256':sha(Q/'04_kicad/crow_audio_carrier_v1.kicad_pcb'),'footprints':len(ra),'pad_objects':sum(len(x['pads']) for x in ra.values()),'native_physical_pin_projection_equal':ra==rb,'inputs_verified':len(inputs),'previous_hidden':x,'candidate_hidden':y,'changed_reference_fields':changed,'all_other_reference_fields_exact':True,'newly_visible':sorted(set(x)-set(y)),'newly_hidden':sorted(set(y)-set(x)),'candidate_fields':{r:fb[r] for r in changed},'candidate_status':'SOURCE HYPOTHESIS ONLY; DRC, exact locator identities and independent ownership/visual review remain separate.'}
(D/'silk-owned-candidate-measurement.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
