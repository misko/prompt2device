from pathlib import Path
import json,hashlib,shutil,yaml
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent
Q=D/'silk-owned-candidate';assert not Q.exists();shutil.copytree(D/'silk-priority-candidate',Q)
p=Q/'03_src/floorplan.yaml';s=(P/'03_src/floorplan.yaml').read_text();old='priority_prefixes: "JUQF"';assert s.count(old)==1
p.write_text(s.replace(old,old+', preferred_offsets: {R_DUMP_TIME1: [[1.1, -1.6]], R_VMID2_TOP: [[1.5, 4.1]]}'))
inputs={str(f):{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'size':f.stat().st_size} for base in [Q/'03_src',Q/'02_parts'] for f in base.rglob('*') if f.is_file()}
for f in [Q/'06_build/netlists/crow_audio_carrier_v1.net',*list((R/'skills/kicad-pcb/scripts').glob('*.py'))]:inputs[str(f)]={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'size':f.stat().st_size}
(D/'silk-owned-candidate-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
print('Prepared isolated preferred-offset candidate',len(inputs),'inputs;',yaml.safe_load(p.read_text())['silk']['refdes'])
