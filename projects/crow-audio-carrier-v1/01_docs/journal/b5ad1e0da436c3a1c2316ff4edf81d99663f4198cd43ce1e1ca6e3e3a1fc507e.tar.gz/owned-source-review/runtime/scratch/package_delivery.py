from pathlib import Path
import csv,difflib,hashlib,json,sys,tarfile
from datetime import datetime,timezone
import yaml
sys.dont_write_bytecode=True
R=Path('/tmp/carrier-owned-source-review-qbyj34yf'); RUN=R/'06_build/task_runs/owned-source-review'; S=RUN/'scratch'; O=RUN/'outputs'
sys.path.insert(0,str(R/'authority/skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet
e=TaskEnvelope.from_json((RUN/'envelope.json').read_text())
ok,detail=verify_input_packet(e,R); assert ok,(ok,detail)
(S/'input-verification-after.json').write_text(json.dumps({'ok':ok,'detail':detail},indent=2,sort_keys=True,default=str)+'\n')

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
cur=R/'current/04_kicad/crow_audio_carrier_v1.kicad_pcb'; new=R/'proposed/04_kicad/crow_audio_carrier_v1.kicad_pcb'
cd=cur.read_text().splitlines(); nd=new.read_text().splitlines()
diff='\n'.join(difflib.unified_diff(cd,nd,fromfile='current',tofile='proposed',lineterm=''))+'\n'
(S/'native-board-diff.txt').write_text(diff)
floor_diff='\n'.join(difflib.unified_diff((R/'current/03_src/floorplan.yaml').read_text().splitlines(),(R/'proposed/03_src/floorplan.yaml').read_text().splitlines(),fromfile='current-floorplan',tofile='proposed-floorplan',lineterm=''))+'\n'
(S/'source-floorplan-diff.txt').write_text(floor_diff)
cc=yaml.safe_load((R/'current/03_src/rules/assembly_locator.yaml').read_text()); pc=yaml.safe_load((R/'proposed/03_src/rules/assembly_locator.yaml').read_text())
cm={x['ref']:x for x in cc['exceptions']}; pm={x['ref']:x for x in pc['exceptions']}
assert len(cm)==len(pm)==25 and len(set(cm)&set(pm))==22
assert all(cm[k]==pm[k] for k in set(cm)&set(pm))
loc=json.loads((R/'proposed/assembly/assembly_locator.json').read_text()); man=json.loads((R/'proposed/assembly/assembly_locator_manifest.json').read_text())
refs=[x['ref'] for x in man['page_refs']]
assert refs==loc['hidden'] and set(refs)==set(pm)
assert len(loc['parts'])==333 and sum(len(x['pads']) for x in loc['parts'])==995
assert sha(new)==loc['board_sha256']==man['board_sha256']
assert all(sha(R/'proposed/assembly'/m['path'])==m['sha256'] and (R/'proposed/assembly'/m['path']).stat().st_size==m['size'] for m in man['members'])
for ref in refs:
    part=next(x for x in loc['parts'] if x['ref']==ref); cfg=pm[ref]
    for k in ('ref','value','mpn','lcsc','x','y','rotation','side'): assert part[k]==cfg[k],(ref,k,part[k],cfg[k])
    assert [{k:p[k] for k in ('number','net')} for p in part['pads']]==cfg['pads']
with (R/'proposed/assembly/bom.csv').open(encoding='utf-8-sig',newline='') as f: bom=list(csv.DictReader(f))
with (R/'proposed/assembly/cpl.csv').open(encoding='utf-8-sig',newline='') as f: cpl=list(csv.DictReader(f))
bomrefs=[]
for row in bom: bomrefs += [x.strip() for x in row['Designator'].split(',') if x.strip()]
cplrefs=[x['Designator'] for x in cpl]
assert len(bom)==51 and len(set(bomrefs))==300 and len(cplrefs)==300 and set(bomrefs)==set(cplrefs)
assert set(bomrefs)<=set(x['ref'] for x in loc['parts']) and len(set(x['ref'] for x in loc['parts'])-set(bomrefs))==33
(S/'independent-exact-summary.json').write_text(json.dumps({'current_exceptions':25,'proposed_exceptions':25,'unchanged_exceptions':22,'removed':sorted(set(cm)-set(pm)),'added':sorted(set(pm)-set(cm)),'locator_refs':333,'locator_pads':995,'hidden_config_page_exact':True,'manifest_members':len(man['members']),'bom_rows':51,'bom_fitted_refs':300,'cpl_fitted_refs':300,'expected_non_bom':33,'board_manifest_binding':True,'native_diff_lines':len(diff.splitlines())},indent=2,sort_keys=True)+'\n')

outcomes=[]
argvs={
'native-svg-export':['/usr/bin/kicad-cli','pcb','export','svg','--output',str(S/'native-front.svg'),'--layers','F.Silkscreen,F.Fab,F.Cu,Edge.Cuts','--mode-single','--fit-page-to-board','--exclude-drawing-sheet','--sketch-pads-on-fab-layers',str(S/'native-copy/crow_audio_carrier_v1.kicad_pcb')],
'native-svg-raster':['/usr/bin/rsvg-convert','-w','3000','-o',str(S/'native-front.png'),str(S/'native-front.svg')],
'locator-exact-check':['/usr/bin/python3','-B',str(R/'authority/skills/jlcpcb-fab/scripts/assembly_locator_check.py'),'exact',str(S/'native-copy/crow_audio_carrier_v1.kicad_pcb'),str(R/'proposed/assembly/bom.csv'),str(R/'proposed/assembly/cpl.csv'),str(R/'proposed/03_src/rules/assembly_locator.yaml'),str(R/'proposed/assembly')]}
for n in argvs:
    d=json.loads((S/f'{n}-outcome.json').read_text()); outcomes.append({'name':n,'argv':argvs[n],'cwd':str(S/'native-copy' if n.startswith('native-svg') else S),'returncode':d['returncode'],'status':d['status'],'started_at':d['started_at'],'finished_at':d['finished_at'],'elapsed_s':d['elapsed_s'],'log':str(S/f'{n}.log')})

completed=datetime.now(timezone.utc).isoformat()
report=f'''subject: crow-audio-carrier-v1 owned physical-label/source/locator candidate review
date: 2026-09-11
reviewer: Codex independent judgment agent /root/carrier_owned_source_review
completed_at: {completed}
context-given: FRESH; immutable 278-input packet; READ_ONLY source; scratch-only exports and checks
source_commit: 57df15a2
board_sha256: {sha(new)}
current_board_sha256: {sha(cur)}
review_kind: noncanonical D-BACK focused source/physical-label/locator-candidate review
source_candidate_verdict: SOUND
physical_label_verdict: SOUND
locator_candidate_verdict: SOUND
engineering_verdict: SOUND-FOR-FOCUSED-CANDIDATE-SCOPE
order_verdict: DO-NOT-ORDER
design_rules_sha256: unavailable for this partial noncanonical packet; no digest guessed

# Focused judgment

## Scope

This noncanonical review judges only the proposed preferred-offset source entries, the exact generated native candidate, the two newly visible physical labels, and the proposed 25-exception locator candidate. It does not generate a board, edit live source, accept current placement, assess routing, or authorize release or ordering. The 306 unchanged visible labels and unchanged native regions inherit prior inspection only because exact native comparison established their identity; this review makes no expanded full-render claim.

## Source candidate — SOUND

The floorplan change adds exactly `R_DUMP_TIME1: [[1.1, -1.6]]` and `R_VMID2_TOP: [[1.5, 4.1]]` to the existing refdes policy and adds no priority list. The locator source retains the 25 ceiling and 22 exceptions byte-for-byte, removes `R_DUMP_TIME1`, `R_FILT2P`, and `R_VMID2_TOP`, and adds exact identities for `C_VDDA2_10N`, `R_FILT1P`, and `R_VMID2_BOT`.

Independent native comparison found only the two expected `Reference` field changes. The candidate has the supplied 340 footprints and 1002 native pads; its 25-ref hidden set removes exactly `R_DUMP_TIME1` and `R_VMID2_TOP` from the current 27. The supplied exact projection establishes unchanged footprints, pads, pad-net identity, zone connection modes, and the 380 unchanged inputs. Supplied owning evidence reports 0 DRC violations, 499 capped unrouted connections, 0 parity findings, and placement DRC PASS. No part, pad, net, zone, or other reference-field change is claimed.

## Physical labels — SOUND

`R_DUMP_TIME1` is legible at 0.55 mm / 0.1125 mm stroke, rotated 90 degrees. In the native F.Silk/F.Fab/pad crop, the label occupies a distinct gap immediately above-left of its own vertical 0402 and remains well separated from the adjacent identical `R_DUMP_TIME2`. Its owner distance is 1.94165 mm versus 3.42527 mm to the nearest other part. The local orientation and spacing make the physical association unambiguous and accessible for assembly lookup.

`R_VMID2_TOP` is legible at 0.55 mm / 0.1125 mm stroke, at 0 degrees. The native crop shows it below and to the right of the correct member of the adjacent VMID2 resistor pair, with the complete `_TOP` suffix readable. Its owner distance is 4.36578 mm, less than 4.87032 mm to `C_VMID2_EXT_10U`; it is also visibly displaced toward its own right-hand resistor rather than the left-hand `R_VMID2_BOT`. The combination of text identity, lateral alignment, and clear whitespace resolves the otherwise similar bodies. No collision, crowded-glyph, or wrong-body ambiguity is visible.

The rejected priority and phase-2 candidates remain rejected; this judgment applies only to board `{sha(new)}`.

## Locator candidate — SOUND

The independent exact checker passes 333/333 unique locator references, 995 assembled pad objects, 25 configured exceptions, and 25/25 page refs. Hidden, configured, and page-ref sets are the same 25 identities. Every omission matches ref, value, MPN, LCSC, X/Y, rotation, side, and all pad-number/net pairs. The 51 BOM rows expand to 300 unique fitted refs; the CPL contains the same 300 refs; the other 33 locator refs are the expected non-BOM set. The manifest binds the exact candidate board and all 28 unique locator members.

I visually inspected the full 25-page contact sheet and the full pages for all three additions: page 5 `C_VDDA2_10N`, page 17 `R_FILT1P`, and page 24 `R_VMID2_BOT`. Each has a readable title and identity, whole-board marker, enlarged exact body, unambiguous arrow/circle target, numbered pads, nets, coordinates, rotation, LCSC/MPN, board hash, and page denominator. No target ambiguity was found.

## Remaining work

Normal canonical renewal, full 337-source checks, current-pin validation, full render review, layout and route gates, and release gates remain owed. LAYOUT001 remains 3/3 spent. This report does not accept the current live placement and does not authorize fabrication.
'''
O.mkdir(exist_ok=True)
(O/'report.md').write_text(report)
evidence={'subject':e.subject.to_mapping(),'engineering_verdict':'SOUND-FOR-FOCUSED-CANDIDATE-SCOPE','delivery_verdict':'COMPLETE','completed_at':completed,'input_verification':{'denominator':len(e.input_packet),'before_pass':len(e.input_packet),'after_pass':len(e.input_packet),'failures':detail},'native_comparison':{'current_sha256':sha(cur),'candidate_sha256':sha(new),'changed_reference_fields':['R_DUMP_TIME1','R_VMID2_TOP'],'all_other_reference_fields_exact':True,'footprints':340,'native_pads':1002,'physical_projection_equal':True,'inputs_unchanged':380,'hidden_before':27,'hidden_after':25},'source_review':{'verdict':'SOUND','offsets':{'R_DUMP_TIME1':[1.1,-1.6],'R_VMID2_TOP':[1.5,4.1]},'priority_refs':None,'locator_unchanged':22,'locator_removed':['R_DUMP_TIME1','R_FILT2P','R_VMID2_TOP'],'locator_added':['C_VDDA2_10N','R_FILT1P','R_VMID2_BOT']},'physical_label_review':{'verdict':'SOUND','actual_view_images':['scratch/native-front.png','scratch/native-crop-dump.png','scratch/native-crop-vmid2.png'],'R_DUMP_TIME1':{'verdict':'SOUND','owner_distance_mm':1.94165,'nearest_other_ref':'R_DUMP_TIME2','nearest_other_distance_mm':3.42527,'judgment':'legible, adjacent to own vertical 0402, distinct from identical neighbor'},'R_VMID2_TOP':{'verdict':'SOUND','owner_distance_mm':4.36578,'nearest_other_ref':'C_VMID2_EXT_10U','nearest_other_distance_mm':4.87032,'judgment':'complete text, lower-right alignment to correct member of adjacent pair, no wrong-body ambiguity'}},'locator_review':{'verdict':'SOUND','assembled_refs':333,'assembled_pads':995,'exceptions':25,'pages_viewed':25,'contact_sheet':'scratch/locator-contact-sheet.png','full_added_pages_viewed':['C_VDDA2_10N','R_FILT1P','R_VMID2_BOT'],'full_page_images':['scratch/locator-page-05.png','scratch/locator-page-17.png','scratch/locator-page-24.png'],'exact_identity_fields':['ref','value','mpn','lcsc','x','y','rotation','side','pad.number','pad.net'],'bom_rows':51,'bom_refs':300,'cpl_refs':300,'non_bom_refs':33,'manifest_members':28},'commands':outcomes,'scope_limits':['noncanonical candidate review','no board generation','no live edits','no routing or release acceptance']}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2,sort_keys=True)+'\n')
(O/'result.json').write_text(json.dumps({'subject':e.subject.to_mapping(),'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]},separators=(',',':'))+'\n')
members=[]
with tarfile.open(O/'evidence.tar.gz','w:gz') as tf:
    for p in sorted(S.rglob('*')):
        if p.is_file() and not p.name.endswith('.pyc'):
            arc='scratch/'+p.relative_to(S).as_posix(); tf.add(p,arcname=arc)
            members.append({'path':arc,'size':p.stat().st_size,'sha256':sha(p)})
(O/'evidence-manifest.json').write_text(json.dumps({'archive':{'path':'evidence.tar.gz','size':(O/'evidence.tar.gz').stat().st_size,'sha256':sha(O/'evidence.tar.gz')},'members':members},indent=2,sort_keys=True)+'\n')
print(json.dumps({'completed_at':completed,'members':len(members),'outputs':sorted(x.name for x in O.iterdir())}))
