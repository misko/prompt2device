from pathlib import Path
import hashlib, json, shutil, sys
from PIL import Image, ImageDraw

sys.dont_write_bytecode=True
ROOT=Path('/tmp/carrier-owned-source-review-qbyj34yf')
RUN=ROOT/'06_build/task_runs/owned-source-review'
S=RUN/'scratch'
S.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'authority/skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope, verify_input_packet
from pipeline_runtime import run_stage

env=TaskEnvelope.from_json((RUN/'envelope.json').read_text())
ok, detail=verify_input_packet(env,ROOT)
(S/'input-verification-before.json').write_text(json.dumps({'ok':ok,'detail':detail},indent=2,sort_keys=True,default=str)+'\n')
assert ok

copy=S/'native-copy'; copy.mkdir(exist_ok=True)
for ext in ('kicad_pcb','kicad_pro','kicad_dru'):
    src=ROOT/f'proposed/04_kicad/crow_audio_carrier_v1.{ext}'
    dst=copy/src.name
    shutil.copyfile(src,dst)
    assert hashlib.sha256(dst.read_bytes()).digest()==hashlib.sha256(src.read_bytes()).digest()

def stage(name,cmd,timeout=60):
    out=run_stage({'id':'KICAD-PLACEMENT','work_class':'local','timeout_s':timeout},cmd,log_path=S/f'{name}.log',cwd=copy,console=None)
    (S/f'{name}-outcome.json').write_text(json.dumps(out.to_mapping(),indent=2,sort_keys=True)+'\n')
    assert out.status=='PASS',out.to_mapping()

svg=S/'native-front.svg'
stage('native-svg-export',['/usr/bin/kicad-cli','pcb','export','svg','--output',str(svg),'--layers','F.Silkscreen,F.Fab,F.Cu,Edge.Cuts','--mode-single','--fit-page-to-board','--exclude-drawing-sheet','--sketch-pads-on-fab-layers',str(copy/'crow_audio_carrier_v1.kicad_pcb')])
png=S/'native-front.png'
stage('native-svg-raster',['/usr/bin/rsvg-convert','-w','3000','-o',str(png),str(svg)])

pages=[]
for i in range(1,26):
    p=ROOT/f'proposed/assembly/assembly_locator_{i:03d}.png'
    im=Image.open(p).convert('RGB'); im.thumbnail((360,240))
    pages.append((i,im.copy()))
sheet=Image.new('RGB',(1800,1200),'white'); d=ImageDraw.Draw(sheet)
for n,im in pages:
    x=((n-1)%5)*360; y=((n-1)//5)*240
    sheet.paste(im,(x,y)); d.rectangle((x,y,x+359,y+239),outline='black',width=2); d.text((x+5,y+5),str(n),fill='black')
sheet.save(S/'locator-contact-sheet.png')
for n in (5,17,24): shutil.copyfile(ROOT/f'proposed/assembly/assembly_locator_{n:03d}.png',S/f'locator-page-{n:02d}.png')
print(json.dumps({'verified':len(env.input_packet),'svg':str(svg),'contact_pages':25}))
