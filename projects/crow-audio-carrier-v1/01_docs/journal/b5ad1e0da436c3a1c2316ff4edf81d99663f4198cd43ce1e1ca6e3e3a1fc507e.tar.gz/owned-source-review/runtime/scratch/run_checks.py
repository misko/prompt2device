from pathlib import Path
import json,sys
from PIL import Image
sys.dont_write_bytecode=True
R=Path('/tmp/carrier-owned-source-review-qbyj34yf'); S=R/'06_build/task_runs/owned-source-review/scratch'
sys.path.insert(0,str(R/'authority/skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
cmd=['/usr/bin/python3','-B',str(R/'authority/skills/jlcpcb-fab/scripts/assembly_locator_check.py'),'exact',str(S/'native-copy/crow_audio_carrier_v1.kicad_pcb'),str(R/'proposed/assembly/bom.csv'),str(R/'proposed/assembly/cpl.csv'),str(R/'proposed/03_src/rules/assembly_locator.yaml'),str(R/'proposed/assembly')]
o=run_stage({'id':'KICAD-PLACEMENT','work_class':'local','timeout_s':60},cmd,log_path=S/'locator-exact-check.log',cwd=S,console=None)
(S/'locator-exact-check-outcome.json').write_text(json.dumps(o.to_mapping(),indent=2,sort_keys=True)+'\n')
assert o.status=='PASS',o.to_mapping()
im=Image.open(S/'native-front.png')
for name,box in {'dump':(560,850,1100,1390),'vmid2':(980,900,1510,1430)}.items():
    im.crop(box).save(S/f'native-crop-{name}.png')
print('PASS')
