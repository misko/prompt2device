from pathlib import Path
import hashlib, json, math, sys
sys.dont_write_bytecode = True
import pcbnew, yaml

ROOT = Path('/tmp/carrier-silk-slot-review-jamzq72_')
AUTH = ROOT / 'authority/skills/kicad-pcb/scripts'
sys.path.insert(0, str(AUTH))
from generate_board_generic import BoardBuilder, MM, box_of, hit, silk_stroke, REFDES_STROKE_MIN, REFDES_STROKE_OVER_SIZE, rect_of

board_path = ROOT / 'current/04_kicad/crow_audio_carrier_v1.kicad_pcb'
board = pcbnew.LoadBoard(str(board_path))
cfg = yaml.safe_load((ROOT / 'current/03_src/floorplan.yaml').read_text())
rc = cfg['silk']['refdes']
clearance = float(rc['clearance'])
size = float(rc['size']); small = float(rc['min_size'])
targets = sorted(f.GetReference() for f in board.GetFootprints() if not f.Reference().IsVisible() and not (f.GetAttributes() & pcbnew.FP_BOARD_ONLY))
assert len(targets) == 27

b = BoardBuilder.__new__(BoardBuilder)
b.board = board
b.hole_refs = {f.GetReference() for f in board.GetFootprints() if f.GetAttributes() & pcbnew.FP_BOARD_ONLY}
b.fps = {f.GetReference(): f for f in board.GetFootprints()}
b._own_cent = [(r, MM(f.GetPosition().x), MM(f.GetPosition().y)) for r, f in b.fps.items() if r not in b.hole_refs]
b.X0, b.Y0, b.X1, b.Y1 = rect_of(cfg["board"])

pad_obst, silk_obst = b._obstacles(clearance)
# Include board-level front-silk drawings/captions and every currently visible
# reference except the targets (which are currently hidden). This proves a
# proposed new slot does not consume a current visible label's slot.
for g in board.GetDrawings():
    if g.IsOnLayer(pcbnew.F_SilkS):
        silk_obst.append(box_of(g.GetBoundingBox(), clearance * 0.5))
for f in board.GetFootprints():
    if f.GetReference() not in targets and f.Reference().IsVisible() and f.Reference().IsOnLayer(pcbnew.F_SilkS):
        silk_obst.append(box_of(f.Reference().GetBoundingBox()))

rows = {}
chosen_boxes = []
for name in targets:
    fp = b.fps[name]; ref = fp.Reference(); ax, ay = MM(fp.GetPosition().x), MM(fp.GetPosition().y)
    candidates = []
    free_count = owned_count = 0
    for sz in (size, small):
        for rot in (0, 90):
            ref.SetTextAngleDegrees(rot)
            ref.SetTextSize(pcbnew.VECTOR2I_MM(sz, sz))
            ref.SetTextThickness(int(silk_stroke(sz, 0.1125, REFDES_STROKE_OVER_SIZE, REFDES_STROKE_MIN) * 1e6))
            for ix in range(-110, 111):
                dx = ix / 10.0
                for iy in range(-110, 111):
                    dy = iy / 10.0
                    if dx == 0 and dy == 0 or math.hypot(dx, dy) > 11.0: continue
                    ref.SetPosition(pcbnew.VECTOR2I_MM(ax + dx, ay + dy))
                    cand = box_of(ref.GetBoundingBox())
                    if not b._in_frame(cand, 0.2): continue
                    if any(hit(cand, o) for o in pad_obst) or any(hit(cand, o) for o in silk_obst + chosen_boxes): continue
                    owned, d_own, d_other, other = b._ownership(cand, name)
                    free_count += 1
                    owned_count += int(owned)
                    if not owned: continue
                    # Prefer short, genuinely two-axis slots not represented by OFF.
                    ordinary = (dx == 0 or dy == 0 or abs(abs(dx)-abs(dy)) < 1e-9)
                    candidates.append((ordinary, math.hypot(dx,dy), sz != size, rot != 0, dx, dy, sz, rot, cand, d_own, d_other, other))
    candidates.sort(key=lambda x: (max(0,x[9]-x[10]), x[1], x[2], x[3]))
    pick = candidates[0] if candidates else None
    print(name, "clear", free_count, "owned", owned_count, flush=True)
    if pick:
        chosen_boxes.append(pick[8])
        rows[name] = {'offset_mm':[pick[4],pick[5]], 'size_mm':pick[6], 'rotation_deg':pick[7],
                      'bbox_mm':list(pick[8]), 'distance_mm':pick[1], 'owned_distance_mm':pick[9],
                      'nearest_other_distance_mm':pick[10], 'nearest_other_ref':pick[11],
                      'ordinary_OFF_shape':pick[0], 'collision_free_count':free_count, 'owned_count':owned_count, 'ownership_deficit_mm':pick[9]-pick[10], 'nearby_choices': [{'offset':[v[4],v[5]],'size':v[6],'rot':v[7],'ownership_deficit_mm':v[9]-v[10]} for v in candidates[:5]]}
    else:
        rows[name] = {'collision_free_count':free_count, 'owned_count':owned_count}

out = {'board_sha256':hashlib.sha256(board_path.read_bytes()).hexdigest(),
       'bounds_mm':[b.X0,b.Y0,b.X1,b.Y1], 'size_mm':size, 'min_size_mm':small,
       'clearance_mm':clearance, 'grid_step_mm':0.1, 'radius_mm':11.0,
       'static_pad_body_obstacles':len(pad_obst), 'static_silk_obstacles':len(silk_obst),
       'preserved_visible_reference_count':sum(1 for f in board.GetFootprints() if f.GetReference() not in targets and f.Reference().IsVisible()),
       'targets':rows}
out['scope']='Bounded 0.1mm native grid measurement over all 27 hidden refs. Preserves all 306 visible references and sequentially reserves only owned clear slots. Sampled no-slot result is not an impossibility proof. No native or live source writes.'
Path('/tmp/carrier-cat-renewal-20260912/silk-all-hidden-owned-slots.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out, indent=2))
