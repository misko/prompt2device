review_stage: pre-route
review_kind: pin
reviewer: rj45-pin-carrier-conversion-toponly1 fresh agent
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 92a4e2fc0fecde845f2dfa0d9e2f5bfbd943372962fb449d699a98d957fc5633
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: 7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c

Coverage is explicitly limited to groups U_ADC and U_LDO: one supplied instance of each was checked (2/2 commissioned instances). This is not whole-board acceptance. Order remains blocked because the commission mandates DO-NOT-ORDER and does not cover the rest of the board.

U_ADC VERDICT: PASS
measured_native_pad_identity_count: 49
measured_required_physical_identity_count: 49 (48 perimeter leads plus one exposed paddle)
measured_declared_alias_count: 0
primary_document: CS5308P_DS1314F1.pdf, SHA-256 6ca42cc09ac47ebdacacaee435f05e3f9c34b83d5692e52a2d8a26533e810e57; PDF pages 4, 5, 6, 7, 93; Figure 1-1, Table 1-1, Table 1-2, Figure 2-1, Figure 10-1
expected_vs_observed: Manufacturer Figure 1-1 is explicitly TOP VIEW through-package: pin 1 is the upper-left lead, pins 1-12 descend the left side, 13-24 run left-to-right along the bottom, 25-36 ascend the right, and 37-48 run right-to-left along the top, 12 pins per side. The front-mounted component-top dossier has exactly that side sequence, pin-1 corner, and CCW winding without reflection.
expected_vs_observed: Figure 10-1 specifies a 6 mm square, 0.4 mm-pitch 48-lead QFN with nominal 4.6 mm square exposed die-attach pad. The dossier shows the corresponding 48 perimeter identities at 0.4 mm pitch and one 4.6 x 4.6 mm center identity.
expected_vs_observed: Table 1-1 requires GND_A pins 6 and 8 and the paddle on common ground; dossier pads 6, 8, and 49 are GND. VDD_A1/2 and VDD_IO are on 3V3_ADC; VDD_D is tied to LDO_D_FILT as required; LDO filter outputs remain filter nets; VMID and analog inputs remain signal/reference nets.
expected_vs_observed: Figure 2-1 shows ADC_FILT1N/2N grounded and ADC_FILT1P/2P supplied through 1 ohm with local capacitors between P and N; dossier has N on GND and distinct P filter nets. Table 1-2 permits unused ASP_DOUT2-4 to float and requires unused SPI_SDO/SCK/SDI to GND and SPI_CS to VDD_IO; the dossier matches those terminations. CONFIG strap nets and active clocks/reset/ASP signals are electrically plausible for their functions.
instance_symmetry: Not applicable; the supplied group contains one U_ADC instance, and it was checked.

U_LDO VERDICT: PASS
measured_native_pad_identity_count: 15
measured_required_physical_identity_count: 15 (14 perimeter leads plus exposed pad 15)
measured_declared_alias_count: 0
primary_document: LT3041_RevA.pdf, SHA-256 35dda1deb2ffc9e20545ebe2aefd2fbd690cf9b04e8772290fd4991a4b8ef584; PDF pages 7 and 36; Figure 3, Table 3, Figure 98 package 05-08-1708
expected_vs_observed: Figure 3 is explicitly TOP VIEW: pins 1-7 descend the left side and pins 8-14 ascend the right, with pin 1 upper-left. The front-mounted component-top dossier matches this pin-1 corner and CCW sequence without reflection.
expected_vs_observed: Figure 98 is the 14-lead 4 mm x 3 mm DFN package. Its BOTTOM VIEW converts once to top view and rotates 90 degrees to the dossier orientation. The converted identities, 0.50 mm pitch, 0.70 x 0.25 mm recommended lands, and 3.30 x 1.70 mm exposed-pad dimensions match the dossier's rotated 3 x 4 mm geometry, 0.7 x 0.25 mm lands, and 1.7 x 3.3 mm center pad.
expected_vs_observed: IN pins 1-3 are on the 5V_LDO_HOLD input rail; OUT/OUTS pins 12-14 are on 3V3_ADC; GND pins 10-11 and EP15 are GND. Table 3 explicitly permits ILIM pin 7 to connect to GND when programmable limiting is unused and PGFB pin 8 to connect to IN when power-good/fast-start are unused; dossier matches both. VIOC and PG are unconnected as allowed for unused functions, EN/UV is on an enable net, and SET is on the dedicated LDO_NR programming/noise-reduction net.
instance_symmetry: Not applicable; the supplied group contains one U_LDO instance, and it was checked.

Unresolved findings: none within the commissioned groups.
