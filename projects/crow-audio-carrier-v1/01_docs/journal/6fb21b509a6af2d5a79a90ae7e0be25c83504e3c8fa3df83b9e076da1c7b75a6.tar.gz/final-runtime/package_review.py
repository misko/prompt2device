from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,datetime,stat
S=Path(__file__).parent;R=S.parents[3];O=S.parent/'outputs'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(n):return json.loads((S/n).read_text())
def save(p,o):p.write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n')
e=json.loads((S.parent/'envelope.json').read_text());h=read('hashes.json')['computed']
bad=[]
for x in e['input_packet']:
 p=R/x['path'];b=p.read_bytes()
 if p.is_symlink() or len(b)!=x['size'] or sha(b)!=x['sha256']:bad.append(x['path'])
assert not bad
save(S/'input-after.json',{'count':len(e['input_packet']),'mismatches':bad,'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
render=read('render-equivalence.json');graph=read('graph-equivalence.json');parity=read('authored-native-parity.json');population=read('population.json');text=read('pdf-legibility-measurements.json');native=read('native-equivalence.json')
assert len(render)==19 and all(x['body_equal'] for x in render)
assert graph['component_values_footprints_equal'] and graph['pin_net_maps_equal']
assert not parity['pin_differences'] and parity['connected_pinset_equal'] and population['all_sets_equal']
assert not text['font_floor_violations'] and not text['missing_component_refs'] and native['equal_after_uuid_only']
notes={
 'reviewer_identity':'Codex /root/carrier_rj45_native_carrier_readability_model1',
 'context':'FRESH',
 'inspection':'Actual host view_image inspection of current-01 through current-19.png and all-headers.png. Page06 inspected first; all other pages subsequently inspected individually. No prior review reasoning used.',
 'page_observations':[
  {'pages':[1,2,3],'observation':'Input fuse, reverse-polarity MOSFET and clamps are wired and labelled. Buck and precharge/held-energy/LDO sequence is legible. C_HOLD polarity is visible. PG_NC and VIOC_NC remain distinct from bottom ground/ILIM/EP labels.'},
  {'pages':[4,5],'observation':'Rail supervision, AUDIO_EN, timed dump and LDO enable are visibly wired; inverting Schmitt titles, pins and explicit NC stubs are legible.'},
  {'pages':list(range(6,14)),'observation':'All eight channel bodies inspected. Each RJ45 exposes ten legible numbered contacts: power1/3/7, GND2/6/8, audio+5/audio-4, shell9/10. CHASSIS stays a distinct labelled conductor. Both ESD NC stubs, AC-coupling legs, bias, amplifier feedback, grounded shunts and AUDIO_EN-controlled isolation are legible. All32 filter-shunt references are distinct.'},
  {'pages':[14,15,16],'observation':'ADC input channel mapping, NC outputs, strap values, local decoupling and reference nets are readable. External passive bias is distinct from ADC internal VMID. Both reference filter bank polarities and values remain visible.'},
  {'pages':[17,18,19],'observation':'MCH clock pins and individual buffers/source resistors are wired. TDM return, OE sense and explicit NC pins are legible. Reset timing circuit, pullup/pulldown and distinct RESET_C/RESET_RC conductors are readable.'},
 ],
 'setup_observations':[
  'A scratch helper initially named inspect.py shadowed Python stdlib inspect while the runtime wrapper imported dataclasses. Its top-level read-only measurement ran during that failed bootstrap import, before bounded launch. The helper was renamed measure_subject.py and the entire measurement was repeated through pipeline_runtime.run_stage; only the bounded initial.log and initial.runtime.json support the accepted calculations. This earlier bootstrap observation is disclosed, not represented as bounded execution.',
  'The initial bounded child completed PASS; the wrapper then accessed the nonexistent RuntimeOutcome.exit_code attribute. The durable runtime record already existed. The wrapper was corrected to use returncode for subsequent distinct stages; the successful child was not retried.',
  'The native parser import emitted three KiCad PROPERTY_ENUM diagnostic assertions. Parsing completed with a nonzero985-pin denominator and explicit333-component identity. They are preserved in graph-review.log and are not silently called absent.'
 ]}
save(S/'visual-inspection-and-method-notes.json',notes)
counts={'frozen_inputs_before':463,'frozen_inputs_after':463,'independently_recomputed_subject_hashes':7,'part_dossiers_hashed':89,'current_pdf_pages_visually_inspected':19,'current_pdf_headers_visually_inspected':19,'page_pairs_raster_compared':19,'pixel_equal_bodies':19,'changed_drawing_bodies':0,'body_pixels_compared':sum(x['width']*(x['height']-100) for x in render),'pdf_component_references':333,'pdf_non_caption_text_objects':2238,'native_components':333,'native_pins':985,'native_nets_including_nc':221,'authored_native_connected_pins':943,'native_nc_pins':42,'rj45_connectors':8,'rj45_pin_net_assertions':80,'first_power_card_refs':333,'native_invariants_passed':205,'native_invariants_total':205,'native_occlusion_objects_graded':3090,'native_occlusion_objects_total':3090,'native_occlusions':0,'native_wires':2186,'native_junctions':320,'erc_errors':0,'erc_warnings':2637}
methods=[
 'Verified every frozen packet path, byte length and SHA256 before and after review; canonical envelope SHA256 independently matched9966590331c2601be1ee96f50a4c607bab2312e3999d61ec426628c871437b0f.',
 'Recomputed all seven hashes using the copied frozen pre_route_review_check.py algorithms, including89 part.yaml files and semantic rule projection; compared to expected-subject only after calculation.',
 'Byte-compared every file supplied in accepted-subject against its current counterpart. Independently evaluated current TSX component declarations with a minimal JSX walker, compared all943 connected pin/net declarations and333 refs with parsed current native netlist, and compared current/accepted985-pin221-net graphs and all333 values/footprints.',
 'Compared CircuitJSON records by type and exact structured data; all source connectivity and schematic/PCB/CAD records equal. Only supplier diagnostic records and source filesystem metadata differ. Native schematic compares equal after replacing5243 UUID-format occurrences only.',
 'Rendered both actual19-page PDFs with Poppler pdftoppm at120dpi. RGB byte equality measured below y100px on every page. Full-page difference bounds lie entirely at y83..97px within provenance captions. Viewed all19 integrated current pages plus all current headers; no changed body needed further adjudication.',
 'Inspected actual current connector, power, protection, polarity, NC, reference and digital drawings. Independently extracted2238 noncaption text objects via Poppler; no integer font-floor violations, all333 refs present. Caption component counts sum333 and all19 captions bind the current CircuitJSON digest prefix.',
 'Ran bounded read-only native E-INV and S-OCCL/S-WNET against the exact current netlist/schematic. Retained all logs and runtime records; no geometry, routing, live input or historical receipt edits.'
]
limitations=[
 'SOUND is scoped to this completed schematic_render review. It is not placement, routing, native model acceptance, physical qualification, release or order authority.',
 'Native occlusion checker explicitly does not place pin-name/number text; actual current PDF visual inspection supplies that readability coverage. Raster equality is measured at120dpi and cannot claim every conceivable render scale.',
 'Frozen ERC reports contain2637 warnings:569 lib_symbol_issues and2068 endpoint_off_grid; four ignored check classes remain listed. Zero errors is not all-severity clean.',
 'Current carrier SOURCE PASS and FULL INCOMPLETE with23 physical obligations are retained. The task-declared pod9 obligations and pod40=33 first-power population+7 testpoints are boundary context, not independently measured pod artifacts in this carrier packet.',
 'Custom analog/power RJ45 is NOT Ethernet/PoE; factory15m Cat6A cord, power-off mating, CHASSIS/POD_SHIELD isolation and existing electrical limits remain required. No current/voltage limit increased; electrical and first-article rule bytes supplied in accepted-subject are unchanged.',
 'Public catalog design-only admission and blank operator response do not establish allocated stock or ordering. FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains; physical tests remain owed under the accepted prototype boundary, not a new pre-fabrication prerequisite. LAYOUT001 remains closed3/3.',
 *notes['setup_observations']
]
evidence={'schema':1,'review_stage':'pre-route','review_kind':'schematic_render','reviewer_identity':notes['reviewer_identity'],'context':'FRESH','date':'2026-09-13','design_verdict':'SOUND','verdict':'SOUND','order_verdict':'DO-NOT-ORDER','subject':e['subject'],'envelope_sha256':read('input-before.json')['canonical_envelope_sha256'],'exact_hashes':h,'counts':counts,'methods':methods,'findings':[],'limitations':limitations,'source_changes':{'authored_tsx':'Both supplied authored TSX files byte-identical.','rules':'Only model_registration.yaml mount_side front -> back plus mounted-side terminology in rules/contracts.md differ in supplied authored source comparison. Floorplan and remaining accepted rule files equal.','circuit_json':'Supplier diagnostic refresh and source filesystem MD5 only; underlying source, schematic, PCB and CAD records byte-equivalent by type.','native_schematic':'UUID-only churn,5243 occurrences; all other characters equal.','native_netlist':'Export/instance metadata changes;985 pin/net mappings and333 value/footprint records equal.','pdf':'All19 bodies pixel-identical; provenance hash caption changes only.','findings_annotations':'Commission states three progress annotations were relocated into governed finding description; this report does not claim an unavailable accepted findings.yaml diff.'},'visual_observations':notes['page_observations']}
save(O/'evidence.json',evidence)
report='\n'.join([
 'review_stage: pre-route','review_kind: schematic_render','reviewer_identity: '+notes['reviewer_identity'],'context: FRESH','date: 2026-09-13','design_verdict: SOUND','order_verdict: DO-NOT-ORDER',*[f'{k}: {v}' for k,v in h.items()],
 '',
 'Fresh independent review of the exact frozen carrier subject is complete. No schematic readability defect was found. This is a current-byte judgment, not adoption of a historical signature.',
 '',
 'Measured coverage: 463/463 frozen inputs verified before and after; 7/7 subject hashes independently recomputed, including 89 part dossiers. All 19/19 actual current PDF pages and headers were visually inspected. Both PDFs were rendered at 120 dpi: 19/19 drawing bodies are RGB-byte-identical below y=100 px. Every full-page difference is confined to y=83..97 px in the provenance caption. No changed drawing body exists. Current headers consistently show the current CircuitJSON hash prefix, correct page numbering and component counts summing to 333.',
 '',
 'Actual current images show readable story-critical wired paths: input fuse/reverse-polarity/clamp, buck, precharge/held supply/LDO, supervision and dump; eight audio chains with connector-first clamps, AC coupling, feedback/filter stages and audio isolation; ADC straps/bypass, separate internal/external references, clocks/TDM and reset. All eight ten-contact RJ45 symbols retain legible power 1/3/7, return 2/6/8, audio+ 5, audio− 4 and shield 9/10 labels. CHASSIS is visibly separate from GND. Polarity, NC stubs and all 32 filter-shunt references are distinct. Poppler independently found all 333/333 component refs and 2,238 noncaption text objects with zero violations of the integer 6 pt red-pin / 7 pt other-text floors.',
 '',
 'Source/native equivalence: both authored TSX files are byte-identical to the immediately accepted subject. Independent JSX evaluation supplies 333/333 component refs and 943/943 connected pin/net declarations, all equal to current native data. Accepted/current graphs contain the same 333 values/footprints, 985 pin/net mappings and 221 nets including 42 NC nets, with zero differences. All 80/80 RJ45 pin/net assertions pass. Manifest, authored, native and first-power card refsets are exactly equal at 333, with no omissions or ghosts.',
 '',
 'The supplied authored rule delta is the fuse model mount_side front-to-back declaration and mounted-side terminology in the rules contract. All other supplied accepted rule files and the floorplan are byte-identical, including electrical limits and first-article card. CircuitJSON electrical, schematic, PCB and CAD record groups are exactly equal; only supplier diagnostics and source filesystem metadata differ. The native schematic is character-identical after replacing 5,243 UUID-format strings only. The current netlist has export/instance metadata churn while normalized hash and independently parsed graph remain equal. The commission-declared annotation move is acknowledged without claiming an unavailable accepted findings.yaml comparison.',
 '',
 'Fresh native checks: E-INV 205/205; S-OCCL 3,090/3,090 drawable objects, zero text occlusions; S-WNET zero misleading conductor locations across 2,186 wires and 320 junctions. The occlusion model declares pin-name/number text as a blind spot, covered here by actual PDF images. Frozen ERC remains 0 errors / 2,637 warnings (569 lib_symbol_issues, 2,068 endpoint_off_grid), with the existing four ignored classes retained. No all-severity-clean claim is made.',
 '',
 'Findings: none within the reviewed readability/equivalence scope. The actual carrier phase receipts retain SOURCE PASS and FULL INCOMPLETE with 23 physical obligations. Pod 9 obligations and its 40 = 33 first-power refs + 7 testpoints are task-supplied boundary context, not a fresh pod measurement. Keep custom analog/power factory Cat6A RJ45, NOT Ethernet/PoE, power-off mating and separate CHASSIS/POD_SHIELD versus GND. Existing voltage/current limits are unchanged. Public catalog design-only admission with blank operator response is not allocated stock. FIRST-ARTICLE-ONLY / DO-NOT-ORDER persists, without adding a physical-measurement prerequisite before prototype fabrication. LAYOUT001 remains closed 3/3. No placement, routing, physical-test, release or order acceptance follows.',
 '',
 'Method limitations: pixel equality is measured at 120 dpi. A scratch bootstrap helper initially shadowed stdlib inspect and ran read-only identity measurement during a failed runtime import; it was renamed and the full measurement repeated under the shared bounded runtime. The first bounded child passed, after which a wrapper return-field typo was corrected; its original PASS runtime receipt remains preserved. Native parser import emitted three PROPERTY_ENUM diagnostics, preserved in its raw log, and completed with full measured counts. These setup facts are disclosed rather than represented as absent. All accepted engineering calculations and image-production subprocesses have bounded runtime records; actual host image viewing is separately documented.',
 '',
 'Evidence: evidence.json, evidence-manifest.json and evidence.tar.gz bind methods, raw logs, runtime records, exact comparisons and all current/accepted page images. result.json addresses delivery completeness separately from this domain verdict. The provided preflight is required after packaging.'
 ])+'\n'
(O/'report.md').write_text(report)
save(O/'result.json',{'subject':e['subject'],'checks':{k:'PASS' for k in e['completion']['checks']},'unresolved':[]})
# Archive only stable regular scratch evidence, never this archive or outputs.
exclude={'package.log','package.runtime.json','preflight.log','preflight.runtime.json','packaging-check.json'}
members=[]
for p in sorted(S.rglob('*')):
 if not p.is_file() or p.name in exclude:continue
 assert not p.is_symlink()
 rel=p.relative_to(S).as_posix();b=p.read_bytes();members.append({'path':rel,'size':len(b),'sha256':sha(b)})
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for member in members:t.add(S/member['path'],arcname=member['path'],recursive=False)
# Independently reopen every archive member and validate safe path, type, census and bytes.
seen=set();lookup={m['path']:m for m in members}
with tarfile.open(archive,'r:gz') as t:
 for m in t.getmembers():
  path=PurePosixPath(m.name)
  assert m.isfile() and not m.issym() and not m.islnk() and not path.is_absolute() and '..' not in path.parts and m.name not in seen and m.name in lookup
  assert not m.name.endswith(('.tar','.tar.gz','.tgz'))
  seen.add(m.name);b=t.extractfile(m).read();want=lookup[m.name]
  assert len(b)==m.size==want['size'] and sha(b)==want['sha256']
assert seen==set(lookup)
manifest={'archive_sha256':sha(archive.read_bytes()),'archive_size':archive.stat().st_size,'member_count':len(members),'members':members}
save(O/'evidence-manifest.json',manifest)
save(S/'packaging-check.json',{'status':'PASS','regular_members_reopened':len(seen),'archive_sha256':manifest['archive_sha256'],'outputs':sorted(p.name for p in O.iterdir())})
assert sorted(p.name for p in O.iterdir())==['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md','result.json']
print(json.dumps({'verdict':'SOUND','outputs':str(O),'member_count':len(members),'archive_size':manifest['archive_size'],'archive_sha256':manifest['archive_sha256'],'inputs_verified':len(e['input_packet'])},indent=2))
