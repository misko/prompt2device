from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,tarfile,io,sys,subprocess
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet
sha=lambda b:hashlib.sha256(b).hexdigest()
files={};proof=[]
jobs=[json.loads(Path('/tmp/carrier-thermal-placement-opened.json').read_text()),*json.loads((D/'thermal-physical-availability-opened.json').read_text())]
for i,j in enumerate(jobs):
 root=Path(j['project']);A=Path(j['attempt']).parent;e=TaskEnvelope.from_json(Path(j['envelope']).read_text());a=json.loads(Path(j['attempt']).read_text())
 assert a['status']=='PASS' and verify_input_packet(e,root)[0]
 for n,m in a['output']['completion']['outputs'].items():
  b=(A/'outputs'/n).read_bytes();assert len(b)==m['size'] and sha(b)==m['sha256']
 for item in e.input_packet:files[f'task{i}/inputs/'+item.path]=root/item.path
 for f in A.rglob('*'):
  if f.is_file():files[f'task{i}/runtime/'+f.relative_to(A).as_posix()]=f
 for n in a['output']['writer_scope'].get('changed_paths',[]):
  f=root/n
  if f.is_file():files[f'task{i}/changed/'+n]=f
 proof.append({'root':str(root),'inputs':len(e.input_packet),'outputs':len(a['output']['completion']['outputs']),'status':a['status']})
j=jobs[0];idx=json.loads((Path(j['task']).parent/'source-index.json').read_text())
for n,h in idx.items():
 f=Path(n);assert sha(f.read_bytes())==h;files['source/'+f.relative_to(R).as_posix()]=f
for n,m in json.loads((Path(j['output_dir'])/'evidence.json').read_text())['artifacts'].items():
 f=P/n;b=f.read_bytes();assert len(b)==m['size'] and sha(b)==m['sha256'];files['generated/'+n]=f
checkpoint=json.loads((P/'06_build/checkpoints/prelayout-inputs.json').read_text())
for n in checkpoint['explicit']:
 f=R/n.removeprefix('repo:');assert sha(f.read_bytes())==checkpoint['files'][n]['sha256'];files['generated/'+f.relative_to(P).as_posix()]=f
for n in ['06_build/checkpoints/prelayout-inputs.json','06_build/checkpoints/prelayout.json','06_build/checkpoints/schematic.json','06_build/sourcing/prelayout_request.json','06_build/sourcing/prelayout_response.csv','04_kicad/crow_audio_carrier_v1.kicad_pro','04_kicad/crow_audio_carrier_v1.kicad_dru']:
 files['generated/'+n]=P/n
for group in ['current_assembly','orientation','model_registration_bundle']:
 for f in (P/'06_build/pre_route'/group).rglob('*'):
  if f.is_file():files['physical-partial-or-registration/'+f.relative_to(P).as_posix()]=f
index=json.loads((P/'06_build/pre_route/model_registration_bundle/model_registration_index.json').read_text())
for group in index['groups']:
 for f in (P/Path(group['manifest']).parent).rglob('*'):
  if f.is_file():files['current-registration/'+f.relative_to(P).as_posix()]=f
for n in ['06_build/pre_route/model_registration.md','06_build/pre_route/model_registration.stage.json','06_build/verification/model_coverage.json','06_build/route/r0.kicad_pcb','06_build/route/r0.kicad_pro','06_build/route/r0.kicad_dru']:
 files['generated/'+n]=P/n
for n in ['preserve_thermal_locator_failure.py','thermal_placement_runner.py','thermal-placement-preview-commands.json','commission_thermal_placement.py','channel-pin-transfer-proof.json','verify_channel_pin_transfer.py']:
 files['root/'+n]=D/n
for prefix in ['thermal-schematic-final-contracts','thermal-pin-transfer']:
 for f in Path('/tmp/carrier-connector-integration-20260911').glob(prefix+'*'):
  if f.is_file():files['root/validation/'+f.name]=f
absent=['bom.csv','cpl.csv','crow_audio_carrier_v1_gerbers.zip','artifact_index.json']
for n in absent:assert not (P/'06_build/pre_route/current_assembly'/n).exists()
result={'time':datetime.now(timezone.utc).isoformat(),'tasks':proof,'source_index_verified':len(idx),'checkpoint_companions':len(checkpoint['explicit']),'removed_failed_assembly_artifacts':absent,'scope':'Placement zero DRC violations/zero parity with 499 capped unrouted items, exact human-review stop. First assembly producer rc4 native omission-set mismatch. Assembly directory is mixed partial/previous evidence, NOT accepted current locator. No twin/overlay/native-render producers ran; old images are stale. Separate successful fresh physical availability.'}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();tracked=set(subprocess.check_output(['git','ls-tree','-r','--name-only',head],cwd=R,text=True).splitlines());refs={};seen={};cache={}
for n,f in list(sorted(files.items())):
 b=f.read_bytes();h=sha(b);rel=f.relative_to(R).as_posix() if f.is_relative_to(R) else None
 if rel in tracked:
  if rel not in cache:
   old=subprocess.check_output(['git','show',head+':'+rel],cwd=R);cache[rel]=(len(old),sha(old))
  if cache[rel]==(len(b),h):refs[n]={'git_commit':head,'path':rel,'size':len(b),'sha256':h};del files[n];continue
 if h in seen:refs[n]={'archive_member':seen[h],'size':len(b),'sha256':h};del files[n]
 else:seen[h]=n
members={n:{'size':f.stat().st_size,'sha256':sha(f.read_bytes())} for n,f in sorted(files.items())}
out=D/'thermal-locator-failure.tar.gz'
with tarfile.open(out,'w:gz',compresslevel=3) as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 b=(json.dumps({'members':members,'references':refs,'reopening':result},indent=2)+'\n').encode();m=tarfile.TarInfo('MANIFEST.json');m.size=len(b);t.addfile(m,io.BytesIO(b))
h=sha(out.read_bytes());dest=D/(h+'.tar.gz');assert not dest.exists();out.rename(dest)
with tarfile.open(dest) as t:
 assert set(t.getnames())==set(members)|{'MANIFEST.json'}
 for n,m in members.items():b=t.extractfile(n).read();assert len(b)==m['size'] and sha(b)==m['sha256']
result.update(archive=str(dest),sha256=h,size=dest.stat().st_size,payload_members=len(members),verified_references=len(refs));(D/'thermal-locator-failure-preservation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
