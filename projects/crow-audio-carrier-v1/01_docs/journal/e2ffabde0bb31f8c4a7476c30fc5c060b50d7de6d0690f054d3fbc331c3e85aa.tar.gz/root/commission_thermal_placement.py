from pathlib import Path
from datetime import datetime,timezone,timedelta
import json,sys,hashlib,shutil,subprocess
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent
sys.path.insert(0,str(R/'skills/pcb-design/scripts'));sys.path.insert(0,str(R/'projects/crow-roof-array-v1/03_src'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
from prelayout_input_checkpoint import authored_census
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip(),'Commit accepted green checkpoint before commissioning'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();now=datetime.now(timezone.utc);cut=now+timedelta(minutes=18);hard=now+timedelta(minutes=20);rid='thermal-placement-'+now.strftime('%Y%m%dT%H%M%SZ');H=P/'06_build/handoffs'/rid;H.mkdir(parents=True);ep=P/'06_build/task_runs'/rid/'envelope.json'
shutil.copyfile(D/'thermal_placement_runner.py',H/'runner.py');shutil.copyfile(D/'thermal-placement-preview-commands.json',H/'preview-commands.json');shutil.copyfile('/tmp/carrier-keying-source-review-27x1olqz/preflight.py',H/'preflight.py')
(H/'runner-config.json').write_text(json.dumps({'envelope':str(ep),'work_cutoff':cut.isoformat()},indent=2)+'\n')
(H/'TASK.md').write_text(f'''# Fresh logged placement continuation

Agent-role mechanical, economy/low effort; fresh context, no children. Exclusive live project writer; root is READ_ONLY until actual FINAL and closure. Source/checkpoint {head}. Read CLAUDE.md, pcb-design skill and supplied runner. Execute exactly:

/usr/bin/python3 {H}/runner.py

The runner verifies frozen source/accepted reviews/canonical schematic inputs and existing guards; native qualification then one existing normal --resume-after-schematic-review conductor, stopping at its first actual gate. Only the exact expected human placement-review boundary then permits the supplied normal assembly/locator, twin, overlay and native full-top producers once each to prepare reviewable artifacts; no rerouting or review acceptance. Each producer must leave native board bytes unchanged, and first producer failure stops this sequence. Never rerun TSX or delete/restore guards. All subprocesses use bounded runtime; immutable argv snapshots and complete raw stdout/stderr in per-stage scratch plus execution.log/execution.json. No source, model, review, approval or routing changes, retries, commits or substitute ad hoc commands. If normal driver unexpectedly advances into routing, its existing review/ownership gates still must be respected; no independent route search authorized.

Root accepted fresh thermal-source-renewal topology/readability and owning PR-REVIEW2/2 before commissioning. Full source337/337. ADR0027 map is unchanged. The only producer source correction moved the pre-existing full-zone pad2 override from CM3N/P to CM2N/P at the original physical locations. The current board25287 is the failed before-state with two starved thermals; this run must regenerate and fill from corrected source. Source changes include meaningful old-RED/new-GREEN pad-setting preservation test and correct target-list migration. Do not assume DRC fixed until actual gate passes. Expected nine changed logical footprint/pad projections against premap9aa; enhanced native comparison including local zone modes is owed after generation. Existing human connector orientation semantic approval must remain unchanged; no new human/order approval implied. Existing LAYOUT-001 all three diagnostics remain spent; no additional candidate route authorized. Machine silk waiver ceiling cannot increase. Release and DO-NOT-ORDER physical holds remain.

After runner returns, inspect report.md/execution.json and execution.log tail, state exactlastgate. Mandatory delivery/writer preflight:
/usr/bin/python3 {H}/preflight.py {ep}

Actual FINAL promptly after first gate, cutoff{cut.isoformat()}, hardclose{hard.isoformat()}; reserve2minutespackaging. No fabricated complete delivery; routine packaging correction allowed only while facts/source remain unchanged. Runner creates report.md,evidence.json,execution.log,execution.json,result.json. No diagnostics or repairs of engineering gates by this worker. If preview producers run, report every actual outcome and preserve raw logs; old locator/twin/render assets are stale unless these exact producers complete successfully.
''')
sources={R/key.removeprefix('repo:') for key in authored_census(P,R,[])}
for n in ['CLAUDE.md','skills/pcb-design/SKILL.md','skills/pcb-design/references/execution-runtime.md','skills/pcb-design/references/compute-tiers.md']:sources.add(R/n)
index={};inputs=[]
for p in sorted(sources):
 b=p.read_bytes();index[str(p)]=hashlib.sha256(b).hexdigest()
 if p.is_relative_to(P):inputs.append(p)
 else:
  target=H/'shared-source'/p.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
for n in ['08_reviews/pre-route_topology.md','08_reviews/pre-route_schematic_render.md','08_reviews/connector_orientation.yaml','03_tscircuit/build/circuit.json','03_tscircuit/build/schematic.pdf','04_kicad/crow_audio_carrier_v1.kicad_sch','06_build/netlists/crow_audio_carrier_v1.net','06_build/checkpoints/prelayout-inputs.json','06_build/checkpoints/prelayout.json','06_build/checkpoints/schematic.json','06_build/sourcing/prelayout_request.json','06_build/sourcing/prelayout_response.csv']:inputs.append(P/n)
(H/'source-index.json').write_text(json.dumps(index,indent=2)+'\n');inputs.extend(p for p in H.rglob('*') if p.is_file());items=[]
for p in sorted(set(inputs)):
 b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(P).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
subject=subject_identity('logged_placement',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())]);scope=sorted(['01_docs/STATUS.md','01_docs/journal/placement.md','03_tscircuit/build','03_tscircuit/dist','03_tscircuit/kicad','03_tscircuit/node_modules','03_tscircuit/verification','04_kicad','06_build'])
e=TaskEnvelope(schema=2,task_id=rid,stage_id='KICAD-PLACEMENT',run_id=rid,subject=subject,executor='agent',execution_class='local',recommended_agent_role='mechanical',agent_role='mechanical',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=rid,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'EXCLUSIVE','paths':scope},output_path=f'06_build/task_runs/{rid}/attempt.json',completion={'outputs':sorted(['report.md','evidence.json','execution.log','execution.json']),'checks':sorted(['inputs-verified','raw-run-recorded','processes-closed'])})
o=open_agent_attempt(e,cwd=P);o.update(project=str(P),envelope=str(ep),task=str(H/'TASK.md'),preflight=str(H/'preflight.py'),work_cutoff=cut.isoformat(),agent_id='/root/carrier_thermal_placement');Path('/tmp/carrier-thermal-placement-opened.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2))
