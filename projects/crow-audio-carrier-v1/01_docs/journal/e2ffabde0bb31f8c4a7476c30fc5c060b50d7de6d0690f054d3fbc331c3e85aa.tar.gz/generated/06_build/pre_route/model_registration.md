# Project native model physical registration

board_sha256: 0ab5b6dae425074f2515dc3c3d737e56f2292d83140590dca592b7b964e73090
a-render_verdict: PASS
registration_kind: P-MODEL-REG
config_sha256: e4894091cfc340de8eebf9e5d49bbd5807adc0b6eb417bd9f0d23b818dc837f6
stage_receipt: 06_build/pre_route/model_registration.stage.json
accepted_bundle: 06_build/pre_route/model_registration_bundle/bundle.json

This aggregate is independent physical-registration evidence. Each group uses an origin-centred coupon and compares native-model pixels with F.Fab, F.CrtYd, and each group's declared drilled-centre or all-pad-centre datum. Catalog-twin renderer fidelity is a separate gate.

| group | refs | tuple cache key | group report | result |
|---|---|---|---|---|
| molex-43650-0400-side-entry | J1,J2,J3,J4,J5,J6,J7,J8 | `a5a591100836147de35bc1810df1928b685944c6e65ee438171ea03eb5dd8f38` | `06_build/pre_route/native_registration/molex-43650-0400-side-entry/native_model_registration.md` | CACHE-HIT |
| molex-43650-0200-side-entry | J9 | `756c10270497fc4021fbf1a52fbae0c8d258fcdfb185993522705689ed3e4a6d` | `06_build/pre_route/native_registration/molex-43650-0200-side-entry/native_model_registration.md` | CACHE-HIT |
| samtec-tmm-106-01-l-d-top-entry | J10,J11 | `0462434f7ce5e18a378986c5b279dc44c19e7b4606b74c8c678476c5427d6c91` | `06_build/pre_route/native_registration/samtec-tmm-106-01-l-d-top-entry/native_model_registration.md` | CACHE-HIT |
| ti-dsg0008a-native-package | U_ISO1,U_ISO2,U_ISO3,U_ISO4,U_ISO5,U_ISO6,U_ISO7,U_ISO8 | `a1e686df1bff0aee7ea8f0baf0644582d617b57e689b58ee58f8647d9d3a3f9d` | `06_build/pre_route/native_registration/ti-dsg0008a-native-package/native_model_registration.md` | CACHE-HIT |
| littelfuse-1812l035-native-package | F1,F2,F3,F4,F5,F6,F7,F8 | `380a08a78db59f7ad9ac7e2dc28507dd8227e0e4d8d8be065963c5412d78e66e` | `06_build/pre_route/native_registration/littelfuse-1812l035-native-package/native_model_registration.md` | CACHE-HIT |
| yageo-rt0603-native-package | R_PWR_TOP | `4bdb52f36bb514314a349d6124217f88a488b1390c0c98a0e0cc0aa072651251` | `06_build/pre_route/native_registration/yageo-rt0603-native-package/native_model_registration.md` | CACHE-HIT |
