# Native model physical registration — `native_top.png`

board_sha256: 0d80ee923dbbae34995fa892e5fc2224b489e5d4afc1a03dc2a7836c44a31058
coupon_sha256: d9527adbbf65b195199793d5a597674b1339788fc8a1e81f6556c414aaaac17f
a-render_verdict: PASS
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 301488732bd715060f80583e9cc8936bbbbd584dbe14055705d89d0d37442ffb
footprint_registration_datum_sha256: 6a5bf2c9f358f7f1fcdbf41f0880f537919665e7370490df5af969cd68431aa3
model_transform_sha256: 6cf53f0e2e5e9c07c31120b0a7392007f28e50daeb9d9b4fabcff69a71234dd2
registration_contract_sha256: b7c94d70d41f27db0a5b2ba21ffcffbac2d4378d5d6db72bbc07041e5414d740
tuple_cache_key: 756c10270497fc4021fbf1a52fbae0c8d258fcdfb185993522705689ed3e4a6d
calibration_px_per_mm: 58.5526 x, 58.5683 y
anisotropy: 0.9997
fit_tolerance_mm: 0.350
courtyard_containment_tolerance_mm: 0.350
registration_datum: drilled_centres
mount_side: front
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 0.967920
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected drilled_centres field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | registration centres inside | min pad margin mm |
|---|---:|---:|---:|---:|---:|
| J9 | 0.009 | 0.000 | 0.000 | 3/3 | 0.986 |

## Failures

- none
