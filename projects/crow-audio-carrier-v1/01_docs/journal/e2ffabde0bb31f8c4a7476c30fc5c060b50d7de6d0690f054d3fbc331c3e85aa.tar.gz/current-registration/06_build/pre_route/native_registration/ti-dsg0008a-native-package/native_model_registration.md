# Native model physical registration — `native_top.png`

board_sha256: 0d80ee923dbbae34995fa892e5fc2224b489e5d4afc1a03dc2a7836c44a31058
coupon_sha256: c44029aae3df0a4ad3ccb0abeb018538baebd396b3a7a1f56731fd1738ae5ecd
a-render_verdict: PASS
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 0efc4d267f4b25c433f509251759baab99611db311ca31b3f60ae180c3beb1fe
footprint_registration_datum_sha256: 19bd1cdbe77c21c7635bc9916e1ea5b3970515efc917cb8d25711f7a0facf662
model_transform_sha256: 6cf53f0e2e5e9c07c31120b0a7392007f28e50daeb9d9b4fabcff69a71234dd2
registration_contract_sha256: 6a2f6dc949a87a52219ee24c136e9a57886be6ca52fa2a6b83b82772abf5938e
tuple_cache_key: a1e686df1bff0aee7ea8f0baf0644582d617b57e689b58ee58f8647d9d3a3f9d
calibration_px_per_mm: 48.1886 x, 48.1830 y
anisotropy: 1.0001
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_pad_centres
mount_side: front
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 1.000000
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_pad_centres field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | registration centres inside | min pad margin mm |
|---|---:|---:|---:|---:|---:|
| U_ISO1 | 0.037 | 0.000 | 0.000 | 11/11 | 0.023 |
| U_ISO2 | 0.031 | 0.000 | 0.000 | 11/11 | 0.036 |
| U_ISO3 | 0.030 | 0.000 | 0.000 | 11/11 | 0.044 |
| U_ISO4 | 0.025 | 0.000 | 0.000 | 11/11 | 0.023 |
| U_ISO5 | 0.015 | 0.000 | 0.000 | 11/11 | 0.036 |
| U_ISO6 | 0.011 | 0.000 | 0.000 | 11/11 | 0.044 |
| U_ISO7 | 0.024 | 0.000 | 0.000 | 11/11 | 0.023 |
| U_ISO8 | 0.014 | 0.000 | 0.000 | 11/11 | 0.036 |

## Failures

- none
