# Native model physical registration — `native_top.png`

board_sha256: 0d80ee923dbbae34995fa892e5fc2224b489e5d4afc1a03dc2a7836c44a31058
coupon_sha256: 107c438f989c3de89ca859798549a06115db5e034ba7b826ef91674b54a24958
a-render_verdict: PASS
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: edd6c3054b944bb9436d3943f1b5da78396621e59065dde98e828219fa62cde9
footprint_registration_datum_sha256: b4641c39c321dba70fbf2888b4f7eef7809c6655b644c03fb2c73a1e2328cb8f
model_transform_sha256: 6cf53f0e2e5e9c07c31120b0a7392007f28e50daeb9d9b4fabcff69a71234dd2
registration_contract_sha256: d2243fbbed732f05d8aad5f7a5110eef51cf837841e929defc67a6c975bcd9ea
tuple_cache_key: 380a08a78db59f7ad9ac7e2dc28507dd8227e0e4d8d8be065963c5412d78e66e
calibration_px_per_mm: 33.6530 x, 33.6374 y
anisotropy: 1.0005
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_smd_pad_overlap
mount_side: front
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 1.000000
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_smd_pad_overlap field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | SMD pads overlapping model plan | minimum overlap mm2 |
|---|---:|---:|---:|---:|---:|
| F1 | 0.031 | 0.000 | 0.000 | 2/2 | 1.930 |
| F2 | 0.024 | 0.000 | 0.000 | 2/2 | 1.961 |
| F3 | 0.020 | 0.000 | 0.000 | 2/2 | 1.992 |
| F4 | 0.025 | 0.000 | 0.000 | 2/2 | 1.930 |
| F5 | 0.015 | 0.000 | 0.000 | 2/2 | 1.961 |
| F6 | 0.005 | 0.000 | 0.000 | 2/2 | 1.992 |
| F7 | 0.025 | 0.000 | 0.000 | 2/2 | 1.930 |
| F8 | 0.016 | 0.000 | 0.000 | 2/2 | 1.961 |

## Failures

- none
