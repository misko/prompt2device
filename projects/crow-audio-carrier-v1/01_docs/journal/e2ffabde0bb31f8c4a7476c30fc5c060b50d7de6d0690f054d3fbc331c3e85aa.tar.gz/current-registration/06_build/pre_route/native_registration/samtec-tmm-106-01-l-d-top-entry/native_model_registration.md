# Native model physical registration — `native_top.png`

board_sha256: 9aa1c2c821a31129176a8b519b9a211d78dfc011adb997a64470c03d0726891f
coupon_sha256: 6956a57c84513027e4ba9a2935dcd271f803ebf614a13ec6a1312057b5c34ecc
a-render_verdict: PASS
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 3a9f0dd56986b0a8b9fa5229f8fcd12451cb9b857a472bb36f87992f8f086737
footprint_registration_datum_sha256: e94002f06e208e0d26e6dba6fab90fe1be1b8ce399e837ff3575288a64ab6247
model_transform_sha256: 6cf53f0e2e5e9c07c31120b0a7392007f28e50daeb9d9b4fabcff69a71234dd2
registration_contract_sha256: 78d18b887daf9b894594d4e7354ea76686b641ca4bf0ea421064ed3c6095578e
tuple_cache_key: 0462434f7ce5e18a378986c5b279dc44c19e7b4606b74c8c678476c5427d6c91
calibration_px_per_mm: 47.8215 x, 47.7960 y
anisotropy: 1.0005
fit_tolerance_mm: 0.150
courtyard_containment_tolerance_mm: 0.250
registration_datum: drilled_centres
mount_side: front
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 0.830808
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected drilled_centres field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | registration centres inside | min pad margin mm |
|---|---:|---:|---:|---:|---:|
| J10 | 0.021 | 0.000 | 0.000 | 12/12 | 0.945 |
| J11 | 0.000 | 0.000 | 0.000 | 12/12 | 0.965 |

## Failures

- none
