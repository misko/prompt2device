# Recorded canonical attempt

- qualify: rc=0, 18.736999s; full raw output execution.log
- placement: rc=1, 102.322033s; full raw output execution.log
- locator-current-assembly: rc=4, 0.709571s; full raw output execution.log
- Authored input hashes: 592/592
- All generated identities are in execution.json.
- Stop at the last actual recorded gate. No routing or release acceptance.
