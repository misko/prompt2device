# Connector orientation review

machine_verdict: PASS
subject_sha256: 57c3e2ab12381014391dd1258ba6762681e0e460e5826b92604649a1547a5715
board_sha256: 0ab5b6dae425074f2515dc3c3d737e56f2292d83140590dca592b7b964e73090

| ref | board access axis | edge | edge distance mm | mating-plane edge offset mm | model/footprint alignment | verdict |
|---|---|---|---:|---:|---:|---|
| J1 | [0.0, -1.0, 0.0] | north | 11.0 | -2.08 | 1.000000 | PASS |
| J2 | [0.0, -1.0, 0.0] | north | 11.0 | -2.08 | 1.000000 | PASS |
| J3 | [0.0, -1.0, 0.0] | north | 11.0 | -2.08 | 1.000000 | PASS |
| J4 | [0.0, -1.0, 0.0] | north | 11.0 | -2.08 | 1.000000 | PASS |
| J5 | [-0.0, 1.0, 0.0] | south | 11.0 | -2.08 | 1.000000 | PASS |
| J6 | [-0.0, 1.0, 0.0] | south | 11.0 | -2.08 | 1.000000 | PASS |
| J7 | [-0.0, 1.0, 0.0] | south | 11.0 | -2.08 | 1.000000 | PASS |
| J8 | [-0.0, 1.0, 0.0] | south | 11.0 | -2.08 | 1.000000 | PASS |
| J9 | [-1.0, -0.0, 0.0] | west | 8.0 | 0.92 | 1.000000 | PASS |

## Human-review representatives

| representative | machine-graded refs | tuple |
|---|---|---|
| J1 | J1, J2, J3, J4 | `d54a42edca499de0` |
| J5 | J5, J6, J7, J8 | `eafe1d7c4f05e685` |
| J9 | J9 | `bb237809fca86e08` |

## Machine findings

- none

## Machine notes

- J1: orthogonal profiles omitted for repeated tuple ['J1', 'J2', 'J3', 'J4'] because edge-row instances can occlude one another
- J5: orthogonal profiles omitted for repeated tuple ['J5', 'J6', 'J7', 'J8'] because edge-row instances can occlude one another

## Human confirmation

Review every present image. Each ref requires `top`, `outside`, and `inside`; orthogonal profiles are included when the target is not occluded by another connector. Approve only when the visible mouth/access direction, mounting side, keying, and cable approach agree with the intended physical use.
