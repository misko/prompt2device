import sys,json,hashlib,tarfile,io
from pathlib import Path,PurePosixPath
S=Path(__file__).parent;R=S.parents[3];OUT=S.parent/'outputs'
e=json.loads((S.parent/'envelope.json').read_text())
def read(name):return json.loads((S/name).read_text())
def h(data):return hashlib.sha256(data).hexdigest()
evidence={'schema':1,'review_kind':'topology','review_stage':'pre-route','reviewer_identity':'Codex /root/carrier_rj45_native_carrier_topology_policy23','context':'FRESH','design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','subject':e['subject'],'hashes':read('hashes.json'),'inputs_before':read('inputs-before.json'),'inputs_after':read('inputs-after.json'),'methods':['frozen owning seven-hash algorithm','all preceding/current source-file set and byte comparison','evaluated hand-authored JSX component/value/connection census','native S-expression pin and component census','fresh KiCad schematic netlist export and complete normalized identity comparison','independent CircuitJSON union-find including named-net joins and singleton NC pins','maintained E-INV and E-ADR current native evaluation','integrated native power, analog and clock/TDM screens with frozen manufacturer evidence','Poppler rasterization of both PDFs and per-page RGB body equality','current integrated rendered page inspection','independent archive reopen and full member digest census'],'counts':{'frozen_files':750,'all_part_dossiers':89,'used_part_dossiers':58,'part_files_compared':193,'source_files_compared':115,'tsx_files_compared':2,'native_components':333,'native_pins':985,'authored_connected_terminals':943,'no_connect_terminals':42,'functional_nets':179,'native_partitions':221,'source_traces':1475,'first_power_installed_refs':333,'rj45_connectors':8,'rj45_contacts':80,'isolated_chassis_contacts':16,'policy_locator_refs':23,'invariants_passed':205,'invariants_total':205,'adr_coverage_passed':7,'adr_coverage_total':7,'rendered_current_pages':19,'rendered_preceding_pages':19,'equal_drawing_bodies':19},'native_census':read('native-census.json')['delta'],'integrated':read('integrated.json'),'closure_checks':read('closure-checks.json'),'final_domain':read('domain-final.json'),'visual_equivalence':read('image-equivalence.json'),'findings':[],'resolved_previous_findings':[{'id':'CARRIER-TOPONLY-RULE-001','status':'RESOLVED_IN_CURRENT_SUBJECT','evidence':'exact two membership removals plus 25->23 output/budget; policy and locator equality23/23; all native pad/net tuples verified; conditional effectiveness unchanged'}],'limitations':['logical schematic terminal census does not replace physical PCB-pad/layout review','pod population and pod native shield isolation outside carrier packet','23 carrier and commissioned9pod physical qualification obligations retained','FIRST-ARTICLE-ONLY/DO-NOT-ORDER; no added measurement prerequisite before prototype fabrication','no active locator waiver, route, release, layout or sourcing-allocation acceptance','ERC0errors/2637classifiedwarnings; native export annotation warning retained','bounded engineering power and timing screens are not physical qualification','raster body equality only at recorded scale; prior readability receipt used solely as unchanged-body provenance'],'diagnostic_failures':[{'stage':'integrated','cause':'exploratory graph omitted named-source-net joins','resolution':'integrated2 includes named-net union and matches all221partitions'},{'stage':'closurechecks','cause':'dossier directory spelling was used instead of declared slash-containing MPN','resolution':'closurechecks2 uses declared MPN and closes all58useddossiers'}]}
(OUT/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(OUT/'result.json').write_text(json.dumps({'subject':e['subject'],'checks':{k:'PASS' for k in e['completion']['checks']},'unresolved':[]},indent=2)+'\n')
files={}
for p in sorted(S.iterdir()):
 if p.is_file() and p.name not in ('package.log','package.runtime.json') and not p.name.startswith('preflight'):files['scratch/'+p.name]=p.read_bytes()
for rel in ['TASK.md','expected-subject.json','context/CLAUDE.md','context/skills/kicad-pcb/scripts/pre_route_review_check.py','decision-context/locator-policy-source-adoption.json','preceding-receipts/topology/report.md','preceding-receipts/readability/report.md','project/03_src/rules/policy_waivers.yaml','project/03_src/rules/assembly_locator.yaml','project/03_src/rules/spoke_interface.yaml','project/03_src/rules/first_article.yaml','project/03_src/rules/electrical_invariants.yaml']:
 files['frozen/'+rel]=(R/rel).read_bytes()
files['frozen/envelope.json']=(S.parent/'envelope.json').read_bytes()
repo=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
for rel in ['skills/pcb-design/scripts/pipeline_runtime.py','skills/pcb-design/scripts/pipeline_execution.py','skills/pcb-design/scripts/pipeline_artifacts.py','skills/kicad-pcb/scripts/electrical_invariants.py','skills/kicad-pcb/scripts/kicad_sch_parity.py','skills/kicad-pcb/scripts/generate_board_generic.py']:
 files['shared-methods/'+rel]=(repo/rel).read_bytes()
for rel in ['check_analog_filter_topology.py','check_power_source.py','check_protection_architecture.py','check_clock_defaults.py']:files['frozen/project/03_src/'+rel]=(R/'project/03_src'/rel).read_bytes()
for name in ['report.md','evidence.json','result.json']:files['delivery/'+name]=(OUT/name).read_bytes()
archive=OUT/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for name,data in sorted(files.items()):
  ti=tarfile.TarInfo(name);ti.size=len(data);ti.mtime=0;ti.mode=0o644;tf.addfile(ti,io.BytesIO(data))
members=[];names=set()
with tarfile.open(archive,'r:gz') as tf:
 for m in tf.getmembers():
  p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts and m.name not in names and not m.name.endswith('.tar.gz');names.add(m.name)
  data=tf.extractfile(m).read();assert data==files[m.name] and len(data)==m.size
  members.append({'path':m.name,'size':len(data),'sha256':h(data)})
assert names==set(files)
manifest={'schema':1,'archive_sha256':h(archive.read_bytes()),'archive_size':archive.stat().st_size,'member_count':len(members),'members':members}
(OUT/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'member_count':len(members),'all_members_independently_reopened':True}))
