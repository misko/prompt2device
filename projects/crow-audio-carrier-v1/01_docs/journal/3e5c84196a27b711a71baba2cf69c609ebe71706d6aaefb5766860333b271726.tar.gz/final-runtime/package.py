#!/usr/bin/python3
import gzip
import hashlib
import json
import shutil
import stat
import tarfile
from pathlib import Path, PurePosixPath

root = Path('/tmp/rj45-pin-carrier-jacks-toponly1-5ftbd717')
run = root / '06_build/task_runs/rj45-pin-carrier-jacks-toponly1'
scratch = run / 'scratch'
out = run / 'outputs'
stage = scratch / 'evidence-stage'
out.mkdir(parents=True, exist_ok=True)
stage.mkdir(parents=True, exist_ok=True)

for path in stage.rglob('*'):
    if path.is_symlink() or not (path.is_file() or path.is_dir()):
        raise RuntimeError(f'unsafe pre-existing staging member: {path}')

copies = {
    scratch / 'wurth-1.png': stage / 'figures/wurth-page-1-160dpi.png',
    scratch / 'wurth-2.png': stage / 'figures/wurth-page-2-160dpi.png',
    scratch / 'datasheet.txt': stage / 'raw/datasheet-pdftotext-layout.txt',
    scratch / 'report.md': stage / 'review/report.md',
    scratch / 'evidence.json': stage / 'review/evidence.json',
    scratch / 'run_cmd.py': stage / 'methods/run_cmd.py',
    Path(__file__): stage / 'methods/package.py',
    root / 'TASK.md': stage / 'frozen/TASK.md',
    root / 'pin-review-protocol.md': stage / 'frozen/pin-review-protocol.md',
}
for ref in range(1, 9):
    copies[root / f'dossiers/J{ref}.md'] = stage / f'frozen/dossiers/J{ref}.md'
for src, dst in copies.items():
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)

for src in sorted((scratch / 'runtime').glob('*')):
    if not src.is_file() or src.is_symlink():
        raise RuntimeError(f'unsafe runtime member: {src}')
    dst = stage / 'runtime' / src.name
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)

hash_lines = []
for item in json.loads((run / 'envelope.json').read_text())['input_packet']:
    hash_lines.append(f"{item['sha256']}  {item['path']}")
(stage / 'raw/input-envelope-sha256.txt').write_text('\n'.join(hash_lines) + '\n')
(stage / 'review/inspection-notes.txt').write_text(
    'Visual inspection of page 1 at 160 dpi: recommended component-side/top PCB hole pattern; '\
    'contacts read 8,6,4,2 on the upper image row and 7,5,3,1 on the lower image row. '\
    'A 180-degree rotation, without reflection, gives dossier local pin 1 upper-left; odd pins '\
    'on y=0 and even pins on y=4. Shell slots and the two large locator holes were separately '\
    'counted. Page 2 visually confirms 8P8C.\n')

regular = []
for path in sorted(stage.rglob('*')):
    if path.is_symlink():
        raise RuntimeError(f'symlink prohibited: {path}')
    if path.is_file():
        mode = path.stat().st_mode
        if not stat.S_ISREG(mode):
            raise RuntimeError(f'non-regular member: {path}')
        rel = path.relative_to(stage).as_posix()
        pure = PurePosixPath(rel)
        if pure.is_absolute() or '..' in pure.parts or rel.startswith('/'):
            raise RuntimeError(f'traversal member: {rel}')
        regular.append((path, f'evidence/{rel}'))

archive = out / 'evidence.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tf:
            for path, arcname in regular:
                data = path.read_bytes()
                info = tarfile.TarInfo(arcname)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                import io
                tf.addfile(info, io.BytesIO(data))

members = []
seen = set()
with tarfile.open(archive, 'r:gz') as tf:
    for info in tf.getmembers():
        if info.name in seen:
            raise RuntimeError(f'duplicate archive member: {info.name}')
        seen.add(info.name)
        pure = PurePosixPath(info.name)
        if pure.is_absolute() or '..' in pure.parts or not info.isfile():
            raise RuntimeError(f'unsafe archive member: {info.name}')
        stream = tf.extractfile(info)
        if stream is None:
            raise RuntimeError(f'cannot reopen archive member: {info.name}')
        data = stream.read()
        if len(data) != info.size:
            raise RuntimeError(f'archive size mismatch: {info.name}')
        members.append({'path': info.name, 'size': info.size,
                        'sha256': hashlib.sha256(data).hexdigest()})

manifest = {
    'schema': 1,
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'archive_size': archive.stat().st_size,
    'member_count': len(members),
    'members': members,
}
(out / 'evidence-manifest.json').write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
shutil.copyfile(scratch / 'report.md', out / 'report.md')
shutil.copyfile(scratch / 'evidence.json', out / 'evidence.json')
result = {
    'subject': {
        'raw_sha256': '17a268f1fee6bfd360710fb549b16ebbecfbb40b8f150c33d79dd8ed8d83bbcd',
        'semantic_sha256': 'd74ed68693d77dec96164593437252b1d75037c0d2d4d3142c97ef989c737a0b',
    },
    'checks': {
        'inputs-verified': 'PASS',
        'review-complete': 'PASS',
        'evidence-complete': 'PASS',
    },
    'unresolved': [],
}
(out / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps({'archive': str(archive), 'manifest': manifest}, sort_keys=True))
