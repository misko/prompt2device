review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 92a4e2fc0fecde845f2dfa0d9e2f5bfbd943372962fb449d699a98d957fc5633
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: 7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c

# Fresh pin review — carrier-jacks

Coverage is limited to commissioned group J1,J2,J3,J4,J5,J6,J7,J8, part 615008160221. This is not whole-board acceptance. The immutable SHA bindings above are commission metadata and were not reviewed conclusions.

Primary document: `Wurth_615008160221_rev001003.pdf`, SHA-256 `6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048`, page 1, figure **Recommended Hole Pattern: [mm]** (rendered image inspected first at 160 dpi); page 2, **Article Properties / Number of Pins (xPxC): 8P8C**. Page 1’s hole pattern is the PCB component-side/top pattern: it shows the component outline, eight contact holes, two shell-tab slots, and two locator holes. Rotating it 180 degrees, without reflection, places contact 1 at local upper-left and produces the dossier sequence exactly: odd contacts 1/3/5/7 on local y=0, even contacts 2/4/6/8 on local y=4, 1.02 mm pitch, 7.14 mm end-to-end. The two shell-tab slots also map without reflection to local (-3.83,-2.35) and (+10.97,-2.35) relative to contact 1.

Connector-numbering interpretation: the eight contacts form two staggered rows, so a perimeter winding label is not independently meaningful. The acceptance basis is the individual physical identity map in the manufacturer hole-pattern image. The dossier’s computed `CCW (top view)` is consistent with its extractor convention, but it was not used as proof.

Measured identity census, each of J1–J8: native pad count 12; numbered conductive-pad identities 10; distinct board copper lands 10; manufacturer conductive identities 10 (8 contact pins plus 2 distinct shell solder tabs); unnumbered mechanical-only identities 2; exposed pads 0; fused/collapsed copper identities 0; declared aliases required 0. Dossier pads 9 and 10 are one-to-one local identifiers for the two distinct shell tabs, not collapsed aliases. Both go to CHASSIS, consistent with their shell function and their isolation from the eight contacts in the datasheet’s shielding-to-pin specification.

J1 VERDICT: PASS
J1 pins 1–8 (CONTACT_1–CONTACT_8): expected the page-1 top/component-side hole pattern after rotation only, with pin 1 at local upper-left, odd pins on y=0 and even pins on y=4, versus the dossier’s exact same physical identities and coordinates; observed nets are respectively 12V_POD1, GND, 12V_POD1, AUDIO_N1, AUDIO_P1, GND, 12V_POD1, GND, which are electrically permissible contact nets and preserve contact identity.
J1 pins 9–10 (SHIELD_S1/SHIELD_S2): expected two separate shell-tab lands at the page-1 slot positions and a chassis-class net, versus two separate pads at (+10.97,-2.35) and (-3.83,-2.35), both CHASSIS. Native/physical counts: 12/10 conductive plus 2 mechanical; expected 10 conductive plus 2 mechanical; no EP.

J2 VERDICT: PASS
J2 pins 1–8 (CONTACT_1–CONTACT_8): expected the same manufacturer identity pattern, versus exact dossier coordinates; observed nets 12V_POD2, GND, 12V_POD2, AUDIO_N2, AUDIO_P2, GND, 12V_POD2, GND preserve the same structural roles as J1.
J2 pins 9–10 (SHIELD_S1/SHIELD_S2): expected two separate shell lands on CHASSIS, versus two separate CHASSIS pads at the expected positions. Native/physical counts: 12/10 conductive plus 2 mechanical; expected 10 conductive plus 2 mechanical; no EP.

J3 VERDICT: PASS
J3 pins 1–8 (CONTACT_1–CONTACT_8): expected the same manufacturer identity pattern, versus exact dossier coordinates; observed nets 12V_POD3, GND, 12V_POD3, AUDIO_N3, AUDIO_P3, GND, 12V_POD3, GND preserve the same structural roles as J1.
J3 pins 9–10 (SHIELD_S1/SHIELD_S2): expected two separate shell lands on CHASSIS, versus two separate CHASSIS pads at the expected positions. Native/physical counts: 12/10 conductive plus 2 mechanical; expected 10 conductive plus 2 mechanical; no EP.

J4 VERDICT: PASS
J4 pins 1–8 (CONTACT_1–CONTACT_8): expected the same manufacturer identity pattern, versus exact dossier coordinates; observed nets 12V_POD4, GND, 12V_POD4, AUDIO_N4, AUDIO_P4, GND, 12V_POD4, GND preserve the same structural roles as J1.
J4 pins 9–10 (SHIELD_S1/SHIELD_S2): expected two separate shell lands on CHASSIS, versus two separate CHASSIS pads at the expected positions. Native/physical counts: 12/10 conductive plus 2 mechanical; expected 10 conductive plus 2 mechanical; no EP.

J5 VERDICT: PASS
J5 pins 1–8 (CONTACT_1–CONTACT_8): expected the same component-top manufacturer identity pattern, versus exact dossier local coordinates; the native board coordinates are rotated 180 degrees as declared. Observed nets 12V_POD5, GND, 12V_POD5, AUDIO_N5, AUDIO_P5, GND, 12V_POD5, GND preserve the same structural roles as J1.
J5 pins 9–10 (SHIELD_S1/SHIELD_S2): expected two separate shell lands on CHASSIS, versus two separate CHASSIS pads at the expected component-top positions and 180-degree native placement. Native/physical counts: 12/10 conductive plus 2 mechanical; expected 10 conductive plus 2 mechanical; no EP.

J6 VERDICT: PASS
J6 pins 1–8 (CONTACT_1–CONTACT_8): expected the same component-top manufacturer identity pattern, versus exact dossier local coordinates and declared 180-degree native placement; observed nets 12V_POD6, GND, 12V_POD6, AUDIO_N6, AUDIO_P6, GND, 12V_POD6, GND preserve the same structural roles as J1.
J6 pins 9–10 (SHIELD_S1/SHIELD_S2): expected two separate shell lands on CHASSIS, versus two separate CHASSIS pads at the expected positions. Native/physical counts: 12/10 conductive plus 2 mechanical; expected 10 conductive plus 2 mechanical; no EP.

J7 VERDICT: PASS
J7 pins 1–8 (CONTACT_1–CONTACT_8): expected the same component-top manufacturer identity pattern, versus exact dossier local coordinates and declared 180-degree native placement; observed nets 12V_POD7, GND, 12V_POD7, AUDIO_N7, AUDIO_P7, GND, 12V_POD7, GND preserve the same structural roles as J1.
J7 pins 9–10 (SHIELD_S1/SHIELD_S2): expected two separate shell lands on CHASSIS, versus two separate CHASSIS pads at the expected positions. Native/physical counts: 12/10 conductive plus 2 mechanical; expected 10 conductive plus 2 mechanical; no EP.

J8 VERDICT: PASS
J8 pins 1–8 (CONTACT_1–CONTACT_8): expected the same component-top manufacturer identity pattern, versus exact dossier local coordinates and declared 180-degree native placement; observed nets 12V_POD8, GND, 12V_POD8, AUDIO_N8, AUDIO_P8, GND, 12V_POD8, GND preserve the same structural roles as J1.
J8 pins 9–10 (SHIELD_S1/SHIELD_S2): expected two separate shell lands on CHASSIS, versus two separate CHASSIS pads at the expected positions. Native/physical counts: 12/10 conductive plus 2 mechanical; expected 10 conductive plus 2 mechanical; no EP.

Instance symmetry: PASS. Across J1–J8, pins 1/3/7 are the instance-local `12V_PODn` rail, pins 2/6/8 are GND, pin 4 is `AUDIO_Nn`, pin 5 is `AUDIO_Pn`, and pins 9/10 are CHASSIS. J1–J4 use 0-degree native placement and J5–J8 use 180-degree native placement, while all component-top coordinates and physical identities remain identical.

No unresolved findings within the commissioned group.
