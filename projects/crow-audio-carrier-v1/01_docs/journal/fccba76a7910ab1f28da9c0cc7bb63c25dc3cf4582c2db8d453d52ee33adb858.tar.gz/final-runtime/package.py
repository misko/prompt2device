from pathlib import Path
import sys,json,hashlib,tarfile,collections,datetime
R=Path(__file__).resolve().parents[6];P=R/'projects/crow-audio-carrier-v1';T=Path(__file__).resolve().parent.parent;S=T/'scratch';O=T/'outputs';sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet,envelope_sha256
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
E=TaskEnvelope.from_json((T/'envelope.json').read_text());ok,errors=verify_input_packet(E,P);assert ok,errors
iv=json.loads((S/'input-verification.json').read_text())
for x in iv['protected']:assert sha(R/x['path'])==x['sha256'],x['path']
protected={'status':'PASS','input_packet_count':len(E.input_packet),'protected_source_method_count':len(iv['protected']),'envelope_sha256':envelope_sha256(E),'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'full_preimages':'evidence/input-verification.json'}
(S/'final-input-verification.json').write_text(json.dumps(protected,indent=2)+'\n')
runtime=json.loads((S/'runtime.json').read_text());classification=json.loads((S/'drc-classification.json').read_text());census=json.loads((S/'component-pin-census.json').read_text());stop=json.loads((S/'stopping-gate-facts.json').read_text());fresh=json.loads((S/'gate-freshness.json').read_text())
changes=json.loads((S/'changed-paths.json').read_text());selected=set(changes)
selected.update(['03_src/rebuild_all.sh','03_src/floorplan.yaml','03_src/route.yaml','03_src/rules/model_registration.yaml','03_src/lib/crow_audio_carrier.pretty/Littelfuse_1812L035_60_Exact.kicad_mod','03_src/lib/3dmodels/derived/Littelfuse_1812L035_60_max-envelope.wrl','03_tscircuit/build/circuit.json','03_tscircuit/build/schematic.pdf','03_tscircuit/manifest.yaml','04_kicad/crow_audio_carrier_v1.kicad_sch','04_kicad/fp-lib-table','06_build/netlists/crow_audio_carrier_v1.net','06_build/checkpoints/schematic.json','06_build/checkpoints/prelayout.json','06_build/checkpoints/prelayout-inputs.json','06_build/drc/gate.json','06_build/agent_handoff.yaml','06_build/verification/model_coverage.json','06_build/verification/connector_assembly_contract.json','06_build/verification/connector_assembly_source_gate.json','06_build/pre_route/model_registration.md','06_build/pre_route/model_registration.stage.json'])
# Preserve exact freshly produced and historical-blocker subjects; never include another archive.
files={}
for rel in sorted(selected):
 f=P/rel
 if f.is_file():assert not f.is_symlink();files['project/'+rel]=f
methods=['skills/kicad-pcb/scripts/pcb_flow.py','skills/pcb-design/scripts/pipeline_runtime.py','skills/pcb-design/scripts/pipeline_execution.py','skills/jlcpcb-fab/scripts/model_registration_gate.py','skills/jlcpcb-fab/scripts/native_model_registration.py']
for rel in methods:files['method/'+rel]=R/rel
for f in S.iterdir():
 if f.is_file() and f.name not in ['after-snapshot.json','archive-reopen.json','packaging-final-validation.json'] and not f.name.endswith('.tar.gz'):files['evidence/'+f.name]=f
files['task/envelope.json']=T/'envelope.json';files['task/TASK.md']=P/'06_build/handoffs/rj45-carrier-placement-after-source1/TASK.md';files['task/preflight.py']=P/'06_build/handoffs/rj45-carrier-placement-after-source1/preflight.py'
artifacts=[{'path':str(f.relative_to(P)) if f.is_relative_to(P) else str(f),'archive_path':k,'size':f.stat().st_size,'sha256':sha(f)} for k,f in sorted(files.items())]
component_blob=json.dumps(census['components'],sort_keys=True,separators=(',',':')).encode();pin_blob=json.dumps(census['pins'],sort_keys=True,separators=(',',':')).encode()
evidence={'schema':1,'subject':E.subject.to_mapping(),'envelope_sha256':envelope_sha256(E),'domain_result':'FAIL / D-BACK REQUIRED','delivery_intent':'Complete honest delivery; engineering FAIL remains separate from task delivery checks.','command':json.loads((S/'command.json').read_text()),'runtime':runtime,'inner_runtime':json.loads((P/'06_build/pipeline_state/rj45_renewed_placement.json').read_text()),'stopping_gate':stop,'gate_freshness':fresh,'source_preservation':protected,'component_pin_counts':census['counts'],'component_census_sha256':hashlib.sha256(component_blob).hexdigest(),'pin_census_sha256':hashlib.sha256(pin_blob).hexdigest(),'census_hash_method':'SHA256 of UTF-8 json.dumps respective array, sort_keys=True,separators=(comma,colon).','board_sha256':sha(P/'04_kicad/crow_audio_carrier_v1.kicad_pcb'),'classification':classification,'artifacts':artifacts,'not_run':['P-ORIENT','independent placement review admission','route import','route taps','route stitch','post-route DRC','layout seal','fabrication','physical qualification'],'archive_validation':'All regular members independently reopened after creation; exact size/hash census in evidence-manifest.json. No symlinks/duplicates/traversal/recursive archive.','limits':['FIRST-ARTICLE-ONLY / DO-NOT-ORDER','FULL23carrier/9pod physical qualification remains owed','LAYOUT-001 closed3/3 unchanged; no fourth diagnostic','Historical gate.json and previous model registration receipts are preserved stale evidence, not this run acceptance.'],'evidence_serialization_error':json.loads((S/'classification-setup-error.json').read_text())}
if (S/'preflight.json').exists():evidence['provided_preflight']=json.loads((S/'preflight.json').read_text())
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
report=f'''# Renewed RJ45 carrier placement — measured stop

The single authorized normal continuation stopped at **[5d] P-MODEL-REG** with rc1 after **95.297s** (outer shared runtime FAIL rc1, **95.459369s**, ended2026-09-12T23:24:34.448758Z). Native error: `F1: F.Fab body and F.CrtYd are both required`. No source edit or engineering retry occurred.

MEASURED: F1–F8 are B.Cu with B.Fab and B.Courtyard present, as floorplan.sides requests. The fuse registration group still declares `mount_side: front`; native `fab_bbox`/`courtyard_bbox` collect only front datums. Tuple preparation aborts before group rendering or a new registration stage receipt. Root D-BACK must reconcile the source declaration and checker method. This is not evidence that the physical body is absent.

| Boundary | Measured result |
|---|---|
| Frozen inputs / live protected source and methods |636/636 and611/611 match|
| Initial canonical handoff / checkpoints |valid schematic; schematic7/7, prelayout11/11|
| Driver full input checkpoint |612/612 PASS|
| Current schematic review gate |PR-REVIEW SOUND/current PASS|
| Generated component / pin / RJ45 census |333components,985source pins,80RJ45 terminals|
| Physical pin map |47multi-pin refs,411declared pin identities PASS|
| Model coverage |333/333 fitted footprints PASS|
| Native placement DRC |0violations /499unconnected /0parity; P-DRC PASS|
| Route preparation |rc0,1.658s; seed preparation only|
| Model registration |FAIL at first F1 datum lookup|
| P-ORIENT / placement review admission / route import,taps,stitch |NOT RUN|
| Post-route DRC / layout seal / fab / physical acceptance |NOT RUN|

MEASURED: every current native DRC row is retained and individually classified in `evidence.json` and archive `evidence/drc-classification.json`. All998endpoint UUID/net/position tuples were reopened in the exact saved PCB. There are455unrouted ordinary-net rows,15spoke-supply rows,15shield rows,8ground pad-component gaps and6ground pad-plane gaps. The PCB contains0track segments and11GND thermal seed vias. Zero violations and zero parity nodes leave no omitted rows in those categories. The native report owns the open-component result; these rows do not establish congestion or route infeasibility.

The existing canonical `06_build/drc/gate.json` is unchanged at1f75e37bce04695583cb8af22be14ac50b0ca4a2486bc210c7bf3cbdd6064108 and older than current PCB/project/rules. It is historical104/499/0 evidence, distinct from current `pre_route.json`0/499/0. Exact gate freshness therefore blocks a new compact handoff; it was not deleted, copied, touched, restamped or regraded. Prior registration reports also remain stale; the current invocation did not emit a replacement receipt. Normal failed pipeline progress and all24 changed paths are preserved.

Current PCB SHA256: `{evidence['board_sha256']}`. Component census SHA256: `{evidence['component_census_sha256']}`. Pin census SHA256: `{evidence['pin_census_sha256']}`. Exact source/netlist/PCB/log/output paths and hashes are recorded in evidence inventory. Raw output is75,335bytes/1,130lines, with every suppressed console line retained in archive `evidence/resume.log`.

MEASURED task delivery is separate from engineering FAIL: the five declared outputs are this report, `evidence.json`, `evidence-manifest.json`, `evidence.tar.gz`, and `result.json`. The archive is reopened member-by-member and checked for exact bytes and safe regular paths. The provided preflight verifies final exclusive writer scope and output delivery. One evidence serializer failed on pcbnew UTF8 JSON conversion after writing DRC rows; only that serializer was corrected, with its failed script/error preserved. No native stage was retried.

INHERITED authority: FIRST-ARTICLE-ONLY / DO-NOT-ORDER; public catalog design-only admission; FULL23carrier/9pod physical obligations remain. LAYOUT-001closed3/3 is unchanged. Root owns durable archiving, commits and the next fresh author after actual FINAL. This task grants no routing, physical service or release acceptance.
'''
(O/'report.md').write_text(report)
(O/'result.json').write_text(json.dumps({'subject':E.subject.to_mapping(),'checks':{k:'PASS' for k in E.completion['checks']},'unresolved':[]},indent=2)+'\n')
files['delivery/evidence.json']=O/'evidence.json';files['delivery/report.md']=O/'report.md';files['delivery/result.json']=O/'result.json'
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for name,f in sorted(files.items()):assert '..' not in Path(name).parts and not Path(name).is_absolute() and not f.is_symlink();t.add(f,arcname=name,recursive=False)
# Independent read of archive bytes, with comparison to source inventory.
members=[];seen=set()
with tarfile.open(archive,'r:gz') as t:
 for m in t.getmembers():
  assert m.isfile() and not m.issym() and not m.islnk() and m.name not in seen and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and not m.name.endswith(('.tar','.tar.gz','.tgz'))
  seen.add(m.name);data=t.extractfile(m).read();h=hashlib.sha256(data).hexdigest();assert len(data)==m.size and h==sha(files[m.name]);members.append({'path':m.name,'size':m.size,'sha256':h})
assert seen==set(files)
manifest={'schema':1,'archive_sha256':sha(archive),'archive_size':archive.stat().st_size,'member_count':len(members),'members':members,'independent_reopen':'PASS','regular_members_only':True,'duplicate_paths':0,'unsafe_paths':0,'recursive_archives':0}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'member_count':len(members),'independent_reopen':'PASS','source_preservation':protected},indent=2))
