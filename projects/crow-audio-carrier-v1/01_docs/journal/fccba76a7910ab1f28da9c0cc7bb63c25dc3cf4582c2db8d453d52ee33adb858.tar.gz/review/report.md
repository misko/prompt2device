# Renewed RJ45 carrier placement — measured stop

The single authorized normal continuation stopped at **[5d] P-MODEL-REG** with rc1 after **95.297s** (outer shared runtime FAIL rc1, **95.459369s**, ended2026-09-12T23:24:34.448758Z). Native error: `F1: F.Fab body and F.CrtYd are both required`. No source edit or engineering retry occurred.

MEASURED: F1–F8 are B.Cu with B.Fab and B.Courtyard present, as floorplan.sides requests. The fuse registration group still declares `mount_side: front`; native `fab_bbox`/`courtyard_bbox` collect only front datums. Tuple preparation aborts before group rendering or a new registration stage receipt. Root D-BACK must reconcile the source declaration and checker method. This is not evidence that the physical body is absent.

| Boundary | Measured result |
|---|---|
| Frozen inputs / live protected source and methods |636/636 and611/611 match|
| Initial canonical handoff / checkpoints |valid schematic; schematic7/7, prelayout11/11|
| Driver full input checkpoint |612/612 PASS|
| Current schematic review gate |PR-REVIEW SOUND/current PASS|
| Generated component / pin / RJ45 census |333components,985source pins,80RJ45 terminals|
| Physical pin map |47multi-pin refs,411declared pin identities PASS|
| Model coverage |333/333 fitted footprints PASS|
| Native placement DRC |0violations /499unconnected /0parity; P-DRC PASS|
| Route preparation |rc0,1.658s; seed preparation only|
| Model registration |FAIL at first F1 datum lookup|
| P-ORIENT / placement review admission / route import,taps,stitch |NOT RUN|
| Post-route DRC / layout seal / fab / physical acceptance |NOT RUN|

MEASURED: every current native DRC row is retained and individually classified in `evidence.json` and archive `evidence/drc-classification.json`. All998endpoint UUID/net/position tuples were reopened in the exact saved PCB. There are455unrouted ordinary-net rows,15spoke-supply rows,15shield rows,8ground pad-component gaps and6ground pad-plane gaps. The PCB contains0track segments and11GND thermal seed vias. Zero violations and zero parity nodes leave no omitted rows in those categories. The native report owns the open-component result; these rows do not establish congestion or route infeasibility.

The existing canonical `06_build/drc/gate.json` is unchanged at1f75e37bce04695583cb8af22be14ac50b0ca4a2486bc210c7bf3cbdd6064108 and older than current PCB/project/rules. It is historical104/499/0 evidence, distinct from current `pre_route.json`0/499/0. Exact gate freshness therefore blocks a new compact handoff; it was not deleted, copied, touched, restamped or regraded. Prior registration reports also remain stale; the current invocation did not emit a replacement receipt. Normal failed pipeline progress and all24 changed paths are preserved.

Current PCB SHA256: `9c30a147b2d94babd98bc2af4150d4e87270d2efb81a8bd39e88f1b9529a99f4`. Component census SHA256: `fbec39aa5c62c5135c2b205e86400ca84bdeaa7edd4660aa556bd4b0d3061acd`. Pin census SHA256: `92e840edfcf68eaf5c07802075ff142ebf3f9aa247bc04e2e084e866f3594cfc`. Exact source/netlist/PCB/log/output paths and hashes are recorded in evidence inventory. Raw output is75,335bytes/1,130lines, with every suppressed console line retained in archive `evidence/resume.log`.

MEASURED task delivery is separate from engineering FAIL: the five declared outputs are this report, `evidence.json`, `evidence-manifest.json`, `evidence.tar.gz`, and `result.json`. The archive is reopened member-by-member and checked for exact bytes and safe regular paths. The provided preflight verifies final exclusive writer scope and output delivery. One evidence serializer failed on pcbnew UTF8 JSON conversion after writing DRC rows; only that serializer was corrected, with its failed script/error preserved. No native stage was retried.

INHERITED authority: FIRST-ARTICLE-ONLY / DO-NOT-ORDER; public catalog design-only admission; FULL23carrier/9pod physical obligations remain. LAYOUT-001closed3/3 is unchanged. Root owns durable archiving, commits and the next fresh author after actual FINAL. This task grants no routing, physical service or release acceptance.
