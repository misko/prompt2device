from pathlib import Path,PurePosixPath
import tarfile,hashlib,json,shutil
S=Path(__file__).parent;O=S.parent/'outputs'
# Include complete engineering evidence plus exact reviewed scratch inputs. Packaging's live log is excluded to avoid self-changing archive inputs.
exclude={'package.log','package.runtime.json','final-preflight.log','final-preflight.runtime.json'}
snap=S/'delivery-snapshot';snap.mkdir(exist_ok=True)
for name in ['report.md','evidence.json','result.json']:shutil.copyfile(O/name,snap/name)
files=[]
for p in sorted(S.rglob('*')):
 if p.is_symlink():raise AssertionError(('symlink',str(p)))
 if not p.is_file() or p.name in exclude:continue
 assert not p.name.endswith(('.tar.gz','.zip')),('nested archive',str(p))
 files.append(p)
archive=O/'evidence.tar.gz';members=[]
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tf:
 for p in files:
  name='evidence/'+p.relative_to(S).as_posix();data=p.read_bytes();info=tf.gettarinfo(str(p),arcname=name);assert info.isfile();tf.addfile(info,__import__('io').BytesIO(data));members.append(dict(path=name,size=len(data),sha256=hashlib.sha256(data).hexdigest()))
seen=set();expected={m['path']:m for m in members}
with tarfile.open(archive,'r:gz') as tf:
 for m in tf.getmembers():
  assert m.isfile() and not m.issym() and not m.islnk();path=PurePosixPath(m.name);assert not path.is_absolute() and '..' not in path.parts and m.name not in seen;seen.add(m.name)
  b=tf.extractfile(m).read();assert len(b)==expected[m.name]['size'] and hashlib.sha256(b).hexdigest()==expected[m.name]['sha256']
assert seen==set(expected)
manifest=dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_size=archive.stat().st_size,member_count=len(members),members=members)
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps({k:v for k,v in manifest.items() if k!='members'}));print('Every regular archive member reopened and hash checked; no links,traversal,duplicates,nested archives')
