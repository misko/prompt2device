# DEFECTIVE current source; supported bounded source repair

Fresh independent D-BACK of the exact envelope subject. The current source has two real authored width-scope mismatches. The exact two-file partial proposal remains **INCOMPLETE**, with 19 of 20 normal methods passing and two failed subtests in the remaining method. Its CHASSIS shadow/census correction is independently SOUND within that limited scope. Neither the existing prepared DRC nor the later sensitivity run changes that verdict.

I support ROOT reconciling ADC_WEST_LOCAL to **rect:[89.35,67.7,93.6,72.35]**, preserving F.Cu, deny:[], its exact three authorized nets and both existing numeric width/clearance limits. This is an engineering recommendation for the owning source boundary, not adoption or native admission. The complete affected population supports it; the recommendation was not inferred from the proposed coordinate in the task.

## Binding and independent methods

Envelope canonical SHA-256: `edee8bb41d8a822162e1b6179ae3bc28090ee5382d3d6b6c2b5e58c14ec38b58`. Exact subject is in evidence.json and result.json. All 502 frozen files were SHA-256/size checked before work and again at delivery. ROOT remains sole live writer. No frozen/live source changed; the scratch project differs from its inputs in exactly the two supplied partial postimages. All hypothetical boundary changes were in memory. No PCB was constructed, saved, generated, filled, DRC-graded, prepared, or routed.

The census independently walks every route declaration and expands each point specification into straight primitives. Capsule bounding boxes are derived from both endpoint extrema plus the full width radius. All applicable exact-net/layer/minimum scopes are checked, with no centerline substitution. Isolated KiCad SHAPE_SEGMENT bounds and footprint effective shapes independently cross-check the geometry. KiCad 10.0.4 native polygon intersection/subtraction supplies area/population comparisons. Source pin identity comes from the frozen netlist and isolated library footprints, not saved-board net names alone; exact library file hashes are retained.

Two existing boards were loaded read-only. Both bind all 63 reviewed ADC1/ADC support pads by source pin net and complete native shape bounding box. The current placement board has zero source tracks and cannot prove the return segments. The historical candidate4 prepared board binds all 20 narrow GND primitives by endpoints, layer, net and width within an explicitly recorded 1 nm coordinate tolerance. Eighteen are exact integer matches; the two U_ADC.44 primitives have the existing y65.849999 native serialization versus source65.85, not a missing/refused bank. The two subject VMID segments bind exactly. These are local identity facts, not acceptance of the current ADC2 polygon or the whole old board.

## Defect and actual KiCad semantics

C_VMID1_470N.2 specification1 is F.Cu/GND/0.18mm. Its first two primitives are (89.45,68.7)→(89.45,69.17), length0.47mm, and (89.45,69.17)→(91.2,69.17), length1.75mm. Their exact full-capsule boxes are [89.36,68.61,89.54,69.26] and [89.36,69.08,91.29,69.26]. Each exceeds ADC_WEST_LOCAL xmin89.5 by0.14mm. The third primitive, to(91.6,69.5), is fully covered. GND's ordinary0.30mm floor remains binding outside authorized local exceptions.

The actual width emitter at generate_rules_generic.py:382–390 uses A.insideArea and exact net clauses. The [official KiCad 10.0 manual](https://docs.kicad.org/10.0/en/pcbnew/pcbnew.html#custom_design_rules), independently opened for this review, distinguishes overlap (`insideArea`, deprecated alias) from complete object enclosure (`enclosedByArea`). The first capsule overlaps the old area by0.04mm in x. That overlap explains why its emitted rule can apply despite its centerline being west of the area. No native DRC width failure is claimed. The retained whole-capsule requirement in nets.yaml/ADR0015 and the test is stronger than this consumer predicate: this is an **authored source-scope mismatch**, not a test error. Weakening the test to overlap, removing its radius, or treating ADC_FEED or pour/via reservations as width authority is rejected. Shared emitters remain frozen; changing them globally would need a separate owner and is unnecessary for this local correction.

Cirrus July2025 layout guidance, section3.4/p10, requires VMID capacitor returns through the nearest analog-ground pin and independent ground-plane connections for those pins, avoiding direct paddle connections. Its retained section3.7 wording is not resolved by this review. The source geometry follows the existing engineering choice of F-only barriers and continuous inner reference planes; no new claim of literal all-layer vendor conformity is made. Cirrus supplies topology authority, not a numeric0.18mm current/thermal guarantee. ADR0030 owns the north return-column placement, which this repair preserves.

## Complete narrow-GND population

The complete declared population is154 seed banks /216 point specifications /391 straight primitives /43 instantiated seed vias, with zero arcs. GND occupies35 banks and67 primitives. Every sub0.30mm GND primitive is listed below:10 banks/10 specifications/20 primitives, total length15.509834613921mm;17 at0.18mm and3 at0.20mm. Eighteen currently have full coverage; exactly two do not. Spec/primitive indices are zero based. Full endpoint, capsule, length, eligible-scope and covering-scope data for every one of391 primitives are in census.json.

| Owner | Spec/primitive | Width mm | Endpoints mm | Current complete coverage |
|---|---:|---:|---|---|
| U_LDO.7 | 0/0 | 0.20 | (63.05,71.5) → (63.75,71.5) | LT3041_GROUND_NECKS |
| U_LDO.10 | 0/0 | 0.20 | (65.95,70.5) → (65.15,70.5) | LT3041_GROUND_NECKS |
| U_LDO.11 | 0/0 | 0.20 | (65.95,70) → (65.15,70) | LT3041_GROUND_NECKS |
| U_ADC.6 | 0/0 | 0.18 | (93.05,69.8) → (92.15,69.8) | ADC_WEST_LOCAL |
| U_ADC.6 | 0/1 | 0.18 | (92.15,69.8) → (91.6,69.5) | ADC_WEST_LOCAL |
| U_ADC.8 | 0/0 | 0.18 | (93.05,70.6) → (92.15,70.6) | ADC_WEST_LOCAL |
| U_ADC.8 | 0/1 | 0.18 | (92.15,70.6) → (91.6,70.68) | ADC_WEST_LOCAL |
| U_ADC.8 | 0/2 | 0.18 | (91.6,70.68) → (90.55,71) | ADC_WEST_LOCAL |
| C_VMID1_470N.2 | 1/0 | 0.18 | (89.45,68.7) → (89.45,69.17) | **UNCOVERED** |
| C_VMID1_470N.2 | 1/1 | 0.18 | (89.45,69.17) → (91.2,69.17) | **UNCOVERED** |
| C_VMID1_470N.2 | 1/2 | 0.18 | (91.2,69.17) → (91.6,69.5) | ADC_WEST_LOCAL |
| U_ADC.30 | 0/0 | 0.18 | (98.95,70.2) → (99.48,70.2) | ADC_EAST_SUPPLY_LOCAL |
| U_ADC.30 | 0/1 | 0.18 | (99.48,70.2) → (99.73,70.075) | ADC_EAST_SUPPLY_LOCAL |
| U_ADC.30 | 0/2 | 0.18 | (99.73,70.075) → (100.55,70.075) | ADC_EAST_SUPPLY_LOCAL |
| U_ADC.30 | 0/3 | 0.18 | (100.55,70.075) → (100.85,70.55) | ADC_EAST_SUPPLY_LOCAL |
| U_ADC.44 | 0/0 | 0.18 | (95.4,67.05) → (95.4,65.85) | ADC_FILT_NORTH_LOCAL |
| U_ADC.44 | 0/1 | 0.18 | (95.4,65.85) → (95.1,65.45) | ADC_FILT_NORTH_LOCAL |
| U_ADC.17 | 0/0 | 0.18 | (95.4,72.95) → (95.4,74.15) | ADC_FILT_SOUTH_LOCAL |
| U_ADC.17 | 0/1 | 0.18 | (95.4,74.15) → (95.1,74.55) | ADC_FILT_SOUTH_LOCAL |
| U_ADC.4 | 0/0 | 0.18 | (93.05,69) → (93.85,69) | ADC_CFG3_GND_LOCAL |

All six GND scoped floors were evaluated: LT3041_GROUND_NECKS0.20mm; ADC_WEST_LOCAL, ADC_EAST_SUPPLY_LOCAL, ADC_FILT_NORTH_LOCAL, ADC_FILT_SOUTH_LOCAL and ADC_CFG3_GND_LOCAL0.18mm. The LT scope cannot authorize a0.18mm item. The north/south ADC_FEED scopes authorize3V3_ADC only. Every eligible scope is F.Cu/deny:[]. No other residual appears. All explicit point geometry lives in prep.seed_stubs; there are no taps, stitch seed banks or arcs. GND pad_rescue, stub_fallback and astar_fallback declare0.30mm and do not add a declared subfloor primitive. Generated future stochastic copper is outside this source census and must be graded when it exists.

## Boundary alternatives and complete affected population

The old rectangle has area19.065mm². Moving only xmin to89.35 adds0.6975mm², yielding19.7625mm² and10µm west slack beyond the measured capsule. This is the smallest source-representation change among the compared remedies; it is not the minimum possible area change or a fabrication-yield claim.

The complete source population scanned comprises333 fitted footprints/985 electrical F.Cu pads,391 source tracks,43 seed vias and83 F.Cu areas. Source thermal fields add11 vias (9 ADC paddle,2 LT3041), all outside the old/new west scope. Independently, the actual native board population supplies988 F.Cu pads including3 generated fiducials,159 physical drilled pad shapes, and11 placement/54 prepared vias. All54 prepared vias and all159 drills were checked; no newly intersecting vias/drills or delta-strip contacts occur. No generated mechanical copper was silently omitted.

| Population | Old rectangle | Proposed rectangle | Contacts with added strip |
|---|---:|---:|---:|
| Source electrical pads |18|18|1|
| Source straight tracks |38|38|3|
| Seed vias |5|5|0|
| Source named areas, inclusive boundary contact |17|17|4|

The one pad is C_LDO_A.2/GND, bbox[88.705,69.575,89.605,70.525], which already overlaps the old rectangle. The three tracks are the existing0.30mm north return column and the two offending0.18mm primitives; all already overlap the old rectangle. The region contacts are the west scope's shared boundary itself, ADC_VMID1_RETURN_POUR, ADC_VMID1_RETURN_VIAS_1 and ADC_VMID2_RETURN_POUR. None of those reservation shapes or deny flags changes. No new net, track, via, pad, or other named-region object becomes overlapping. geometry.json contains complete old/new/delta identities, not merely counts.

ADC_WEST_LOCAL also owns the existing **0.20mm scoped clearance** for the same three nets, so this is explicitly a change to both rules' geography. The actual clearance emitter requires both objects to overlap and **either** object's net to be in the authorized set; it does not require both nets to match. All current item memberships remain identical:26 eligible source tracks for the width rule and1290 distinct-net source copper pairs eligible for that clearance predicate before/after. These are predicate population counts, not nearest-neighbor violations or fresh clearance acceptance. The initial470 pair count used a too-restrictive both-net diagnostic; its correction and raw method are retained. No numerical current, width, clearance, fabrication or thermal floor is lowered.

A supported smaller alternative is the orthogonal union of the old rectangle with x89.35..89.5/y68.60..69.27. Its explicit polygon is [(89.5,67.7),(93.6,67.7),(93.6,72.35),(89.5,72.35),(89.5,69.27),(89.35,69.27),(89.35,68.60),(89.5,68.60)]. It adds0.1005mm², has no added-strip pad/via contact and the same three track contacts; only the two ADC1 reservations have positive overlap. It also covers all20 narrow GND primitives. It requires changing the existing rectangle-specific source regression to complete polygon containment and proving that new checker. Prefer the one-coordinate rectangle correction for the existing representation and unchanged actual permission membership, while documenting its larger future geometric permission. Both options preserve the return copper. A separate GND-only scope could avoid expanding mixed-net/clearance geography but introduces another region/rule and new census ownership; it is not required by the current population.

Moving the0.18mm return centerline east would require x≥89.59 to fit the old boundary, a0.14mm displacement, conflicting with the instruction to preserve the accepted column and its reservation/clearance geometry. Widening the branch to ordinary0.30mm changes copper by60µm per side and needs new full physical/return screening. Neither is justified as a minimal correction here. Deleting the strong scope obligation is rejected.

## Exact partial postimage review and maintained controls

Only stackup.yaml adds CHASSIS_SHIELD. Removing that one added mapping makes the complete parsed old/new stack identical. The class declares F.Cu/B.Cu, references:{}, reference_required:false. Its resolver's adjacent-role In1.Cu/In2.Cu GND metadata is not a CHASSIS-to-GND electrical bond or inner-layer route permission. The new regression independently confirms16 shell pads, J1..J8 pins9/10, exact CHASSIS class/wave ownership,0.60mm width and0.25mm clearance, and refuses absent class/inner-plane routing. The original duplicate-owner and damaged-reference-plane hostile controls remain.

The netlist reconciles333 refs/985pins/221nets,42 NCs,178 non-GND non-NC nets,179 connected nets and173 generic-wave members. The49 added seed owner identities are16 jack signal banks,24 ESD banks,8 fuse output banks and C_VDDA1_10N.2;154 unique banks equals105 retained+49. Every bank pin/net is checked. The20 via specifications are15 explicit overrides and5 default/common specifications, distinct from43 seed vias and11 thermal vias. The exact15 overrides are U_ADC pins2,3,6,8,10,11,17,23,30,35,44; C_VDDIO.2; C_FILT1_1U.2; C_FILT2_1U.2; C_VDDA1_10N.2. All original19 test methods remain, one CHASSIS method is added, and original geometric hostility is retained.

Independent finite normal runs reproduced:

- Original exact suite:19 methods,13 PASS/6 FAIL.
- Exact partial postimage:20 methods,19 PASS/1 FAIL containing2 failed capsule subtests. This remains FAIL.
- New CHASSIS method against old stack:RED,1 failing method; the same method passes in the exact partial run.
- In-memory rectangle sensitivity only:20/20 PASS. No source file was changed for this test; it is evidence about the boundary hypothesis, **not final exact-source preflight**.
- Independent complete-population scope controls:9/9 expected outcomes, including original failure, proposed full coverage, centerline-only escape, radius escape, wrong net/layer/deny/floor and a remote ADC30 escape. Maintained regressions must additionally pin complete population membership so removal of a primitive cannot disappear from the census.

The source-native test suite used isolated footprints only. A first geometry-inspection setup failed because Clone returned the base SHAPE wrapper; it was corrected with SHAPE_POLY_SET's copy constructor. Both raw attempts are retained; this was not a PCB candidate. All process output, including ordinary KiCad startup diagnostics, remains unfiltered in runtime logs.

## Coherent owning-source handoff and conditional candidate5

The supported handoff has these owners, composed with the already adopted exact ADC2 union:

1. Adopt the exact reviewed partial stackup mapping and census/CHASSIS test corrections, preserving all original methods and failed-case controls.
2. In floorplan.yaml, change only keepouts[name=ADC_WEST_LOCAL].rect[0] from89.5 to89.35; retain the other bounds, F.Cu and deny:[]. Keep the accepted ADC2 polygon and all other82 areas exact.
3. In nets.yaml, update the two ADC_WEST_LOCAL `why` rationales to bind the accepted ADR0030 north return column, full-radius measured extent,10µm scope slack and explicitly unchanged paired-clearance membership. Preserve the exact width net set[3V3_ADC,LDO_A_FILT,GND],0.18mm width,0.20mm scoped clearance and all other42 width/33 clearance population totals.
4. Amend ADR0030 with this measured scope reconciliation and the unchanged return-column/reservation authority. Keep ADR0015's whole-capsule obligation, historical measurements and accepted ADC2 amendment intact.
5. Extend test_route_source_contract.py with exact west rectangle/layer/deny/net/floor assertions, the complete10-bank/10-spec/20-primitive narrow-GND population and full-capsule coverage against proper scopes, plus retained original19 methods, new CHASSIS checks and the meaningful scope hostiles above. Preserve the exact source bank/width/length/via and electrical/current ceilings rather than deriving expectations from whatever remains.

This is five owning files in the ADC1/baseline handoff, not an adopted five-file patch. Exact composed postimages, rationale text and new maintained tests still need ROOT's complete source preflight and source binding. No change to route.yaml is necessary. Its entire graph and all existing source geometry remain exact:four VMID owner/drop cuts,three LT quiet-cell cuts,five ADC paddle exclusions,independent GND_A6/GND_A8/GND_D30 drops,all54 instantiated source vias,32 source full-zone pad overrides,minimum resolved spokes2,0.50mm thermal settings and all ordinary floors stay binding. This preserves declarations; future filled graphs must independently prove their effects.

The changed return-reservation premise (independently adopted ADC2 pad-clearance union) plus this complete ADC1 scope reconciliation **supports ROOT considering at most ONE cumulative candidate5**, only after all exact composed source preflight succeeds and ROOT explicitly records the changed premise. This review does not admit it. Preserve all four prior candidates, their outcomes and the closed4/4 history; no reset, replacement, candidate6 or routing pilot is supported.

The old ordinary placement refusal remains binding: C_VDDA2_10N.2 had one thermal spoke against minimum2. Candidate4 prepared results do not accept that earlier ungraded placement subject. Future order is ordinary placement P-DRC **before prep**, then prepared/filled DRC and all full return-cut/control/source-binding proofs. Retain all prior courtyard/critical-path/native-arc/source/prep refusals; classify every earlier dangling/open/parity finding rather than inheriting a prepared-count summary. Physical assembly, human pod orientation, thermal/current qualification, route readiness, order and release remain outside this source review. If the one future candidate fails, hand the actual result upstream; no local sixth trial.

Delivery PASS means an honest complete review package. Engineering findings remain open until the exact owning source and later native gates close them.
