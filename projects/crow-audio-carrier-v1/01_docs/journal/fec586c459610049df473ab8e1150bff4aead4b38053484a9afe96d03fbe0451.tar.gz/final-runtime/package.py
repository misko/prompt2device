import sys,json,hashlib,tarfile,datetime,shutil
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
S=Path(__file__).parent;B=S.parent;R=S.parents[3];O=B/'outputs'
def h(b):return hashlib.sha256(b).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,default=str)+'\n')
e=json.loads((B/'envelope.json').read_text());hashes=json.loads((S/'hashes.json').read_text())
rows=[]
for x in e['input_packet']:
 b=(R/x['path']).read_bytes();rows.append({'path':x['path'],'sha256':h(b),'size':len(b),'pass':h(b)==x['sha256'] and len(b)==x['size']})
assert len(rows)==170 and all(x['pass'] for x in rows);write(S/'inputs-after.json',rows)
metadata={'review_stage':'pre-route','review_kind':'topology','reviewer':'carrier_rj45_native_pod_topology_methodrenewal1','context':'FRESH','completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER',**hashes}
(O/'report.md').write_text('\n'.join(k+': '+v for k,v in metadata.items())+'\n\n'+(S/'report-body.md').read_text())
write(O/'evidence.json',{'subject':e['subject'],**metadata,'coverage':json.loads((S/'summary.json').read_text()),'primary_coverage':json.loads((S/'primary-coverage.json').read_text()),'inspected_images':sorted(x.name for x in S.glob('*.png')),'findings':[{'severity':'nonblocking','description':'D1 rationale still names historical 1N4007; executable pins are correct.'}],'delivery_unresolved':[]})
write(O/'result.json',{'subject':e['subject'],'checks':{x:'PASS' for x in e['completion']['checks']},'unresolved':[]})
# Archive a completed engineering evidence snapshot; packaging does not archive itself recursively.
items=[(x,'engineering/'+x.name) for x in sorted(S.iterdir()) if x.is_file() and x.name not in {'preflight.log','preflight.runtime.json'}]
items += [(B/'envelope.json','commission/envelope.json'),(R/'TASK.md','commission/TASK.md'),(R/'expected-subject.json','commission/expected-subject.json'),(O/'report.md','review/report.md'),(O/'evidence.json','review/evidence.json')]
with tarfile.open(O/'evidence.tar.gz','w:gz') as t:
 for p,n in items:assert not p.is_symlink();t.add(p,arcname=n,recursive=False)
members=[]
with tarfile.open(O/'evidence.tar.gz','r:gz') as t:
 names=set()
 for m in t.getmembers():
  assert m.isfile() and not m.issym() and not m.islnk();p=PurePosixPath(m.name);assert not p.is_absolute() and '..' not in p.parts and m.name not in names;names.add(m.name);assert not m.name.endswith(('.tar','.tar.gz','.tgz','.zip'))
  b=t.extractfile(m).read();assert len(b)==m.size;members.append({'path':m.name,'size':len(b),'sha256':h(b)})
b=(O/'evidence.tar.gz').read_bytes();write(O/'evidence-manifest.json',{'subject':e['subject'],'archive_sha256':h(b),'archive_size':len(b),'member_count':len(members),'members':members})
print('Packaged',len(members),'safe regular members;',len(b),'archive bytes')
