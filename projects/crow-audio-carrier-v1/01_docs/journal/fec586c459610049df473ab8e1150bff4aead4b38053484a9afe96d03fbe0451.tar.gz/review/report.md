review_stage: pre-route
review_kind: topology
reviewer: carrier_rj45_native_pod_topology_methodrenewal1
context: FRESH
completed_at: 2026-09-15T23:16:46.744057+00:00
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
netlist_sha256: 053099dca0eeb01fb27dc29ab3f93a17e0edacff68df2b741f7dcd426853b239
parts_sha256: d0d0026dd67cbfaa98176799ea34ea3bfde384675d74d58d8cf8f0c88e41fd89
design_rules_sha256: 8224767829768bcdb9193037489f6ae931c60cb4b0e25c1e1744ff1e2198512d
schematic_pdf_sha256: 0f562f19a55eb85779e49b276845c17b282b8e8264593a08723de00ffc779f06
exact_netlist_sha256: 9604b34207e4a42fc41a0681d44318c278a758d21aa1bcdb497401760c6ba5e1
circuit_json_sha256: 1594b95c376bc1d9fb7b988b4ab9c15b67ec8ddd149924c9d5e809ecba9360e7
kicad_schematic_sha256: c3fd56e6a07fd5ecee17da1a01a0851c44787982da1f4847d5099eb55c1ed4bf

Fresh independent verdict: SOUND for pre-route schematic topology as a non-orderable first-article candidate. No electrical topology defect was found. This does not accept the current routed board, placement, fabrication, assembly, physical qualification or ordering. ADR0005 remains applicable.

Coverage and method

All 170 frozen inputs were independently checked by size and SHA-256. All seven subject hashes were recomputed using the supplied frozen pre_route_review_check.py and agree with expected-subject.json. The native schematic was freshly exported using kicad-cli; its canonical netlist hash exactly matches the frozen netlist. An independently written S-expression parser compares the native net inventory with CircuitJSON traces/ports and direct TSX connections, rather than using the generating converter as the connectivity checker.

The census is 40/40 references, 103/103 physical pins, 99/99 connected endpoints, 20 connected source nets, and four explicit open pins: U2.3/U2.7/U3.1/U3.2. The native netlist has 24 nets because each open pin occupies its own unconnected net. The 40 refs comprise C1–C11, R1–R14, U1–U3, D1/D2, F1, J1, MK1 and TP1–TP7. Inventory.json records every pin, net, value and native footprint. The 33 named-part refs have matching source/native MPNs, dossier pin sets and supplier identities where declared; seven testpads have no bought-part identity. All 39/39 electrical assertions pass, including the 12/12 part-value tolerance declarations, checked separately against the exact dossiers.

Electrical judgment

J1 contacts 1/3/7 are 12V_POD; 2/6/8 are GND; 5 is AUDIO_P; 4 is AUDIO_N. Contacts 9/10 alone form POD_SHIELD. No GND endpoint occurs on that shield net. This is a custom analog/DC interface on factory Cat6A, with power-off mating, not an Ethernet/PoE protocol.

Power flows through F1 then D1 anode pin 2, exiting cathode pin 1 onto VIN_PROTECTED. D1 is exactly Vishay S1M-E3/61T/C144860, not the unused historical M7 dossier. The primary Vishay PDF confirms the cathode band, 1000 V reverse rating, 1 A average rating and 50 uA maximum leakage at 125 C. R14's worst 4.747 kohm gives -0.23735 V under that leakage bound, inside TPS7A49's -0.3 V absolute input minimum by 62.65 mV. R14 dissipates at most 37.45 mW at 13.2 V and 127.95 mW at the admitted 24.4 V clamp level, below its 250 mW rating at 70 C.

F1's exact Bel row gives 0.10 A hold/0.25 A trip at 23 C, 60 V and 10 A maximum fault current. At 70 C the table derates hold to 48 mA, still above the declared 20 mA pod load. This does not prove source-fault coordination. D2 is unidirectional SMBJ15A: cathode on VIN_PROTECTED, anode on GND, 15 V standoff and 24.4 V clamp at the specified 24.6 A test point. The project admits at most 10 A and leaves source qualification owed. U2's 35 V operating/36 V absolute maximum and dossier-declared C1/C2 50 V ratings exceed the admitted clamp boundary. No lightning or enclosure-level immunity claim follows.

U2's primary DGN pin table agrees with pins 8 IN/5 EN protected, 1 OUT quiet rail, 2 feedback, 6 NR/SS, 4/9 ground, 3 NC and 7 DNC open. R1/R2 = 324k/100k with C3 feedback feed-forward and C4 NR bypass. Recomputed tolerance/feedback-current corners are 4.792587–5.229513 V. At 20 mA, the conservative (13.2−4.79)V load term dissipates 168.2 mW, below the 300 mW project target before board thermal qualification. C1/C2 provide nominal 10.1 uF input capacitance. C5 nominal 10 uF exceeds the 2.2 uF minimum; the declared derating assumption gives 3.825 uF, but exact effective capacitance remains unmeasured.

The microphone uses R3 3.9k/C7 100uF filtering then R4 2.2k, matching the PUI characterized load. At 500 uA, the nominal bias plane is 3.05 V and capsule terminal is 1.95 V, within its 1–10 V operating range. C8 AC couples into the VREF-biased signal path. R6/R7 and C9 generate filtered half-rail, buffered by U1A. U1B is an inverting 18k/22k stage; U1C restores polarity with equal 10k resistors. AUDIO_P therefore has positive signal polarity and AUDIO_N the complementary polarity, nominal differential gain 18/11. R12/R13 each isolate the cable by 100 ohms. At maximum nominal half-rail and -1% resistance the static output-short resistor dissipation is about 69.1 mW, below 125 mW. U1D is a private VREF follower, with pins 13/14 on SPARE_BUF and no paralleled output. The primary OPA1679 SOIC pin map matches all 14 pins; its 4.5 V minimum supply and Vminus+0.5 to Vplus−2 common-mode range accommodate the calculated quiet rail and half-rail inputs. U3's DRL primary map matches 3/5 AUDIO_P/AUDIO_N, 4 GND and 1/2 open; its 5.5 V working range is appropriate for the intended signal. Cable stability, startup, output swing under actual loading and ESD performance require measurement.

Actual image inspection

Viewed all 4/4 current PDF pages rendered at 1800-pixel maximum dimension: page 1 covers 7 refs, page 2 covers 11, page 3 covers 10 and page 4 covers 12. All ten connector contacts, diode K/A polarity, regulator NC/DNC/ground pad, capsule polarity, amplifier labels and U3 NCs are visible and consistent with the inventory. The VIN_PROTECTED label at U2 makes its input/enable supply explicit. Ground bars and green wires do not obscure the relevant glyphs. The large wire loops are readable at this scale. Also viewed six primary pages: Vishay 1/2, TI TPS7A49 4/5, OPA1679 5 and TPD2E2U06 3. Ten actually inspected PNGs are archived. This corroborates topology; the independent readability reviewer owns the separate render verdict.

Historical reconciliation and limitations

Only prior reports, not prior native/source snapshots, were supplied. Therefore no historical byte-by-byte or pixel-equality claim is made. Of the seven reported historical hashes, only parts_sha256 is unchanged. Current native/source facts independently agree with the prior report's functional inventory, exact S1M identity, connector map, LDO network and analog signal roles. The source's explicit quiet-power VIN_PROTECTED label is present and electrically redundant with U2.8's existing source net. Renewed method/rule bindings are treated as current inputs; historical SOUND is not inherited.

Selected-part primary-PDF coverage is 21/33 refs; 12 refs lack bound manufacturer PDF bytes in this packet: C1, C2, R1, R2, R3, C7, R4, R5, R6, R7, R8, R9. Their identities/ratings/tolerances were checked against frozen dossiers, not independently proven by unavailable PDFs. These existing sourcing/qualification gaps remain order holds under ADR0005, not waived evidence. The current ERC artifact contains 0 errors and 158 warnings: 94 endpoint_off_grid and 64 lib_symbol_issues. ERC was read and classified, not rerun as an unrelated suite.

One nonblocking documentation issue persists: D1 invariant rationale still says “1N4007”; rename it to S1M in a later authorized source update. The executable pin assertions are correct. No source edits were made. Missing exact capacitor curves/PDFs, thermal/cable/EMC tests, physical connector operations and carrier fault bounds remain owned by their existing gates. No board or production acceptance is asserted.

Evidence handling

All engineering subprocesses used finite direct-argv pipeline_runtime.run_stage calls, explicit cwd/environment and retained raw logs/receipts. Initial scratch analysis encountered an ohm-symbol parser assumption, unavailable PyMuPDF, and YAML date JSON serialization; their failed logs and original methods remain archived. Corrected complete analysis and the available Poppler renderer passed. These were scratch-method corrections, not replacement reviewer commissions. Input integrity is checked again at packaging. The archive contains actual methods, raw engineering logs, runtime receipts, all inspected images, inventories and primary hashes, and every safe regular member is reopened and hashed. Delivery PASS is distinct from domain acceptance and orderability.
