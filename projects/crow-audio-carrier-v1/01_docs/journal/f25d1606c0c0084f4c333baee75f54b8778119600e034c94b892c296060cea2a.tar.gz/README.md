# Weidmüller 8909650150 alternative research — 2026-09-12

Research only. Baseline f7c868fb. No live design adoption or SOURCE admission.

Exact product: IE-C6ES8UG0150A40A40-E, factory 15 m shielded RJ45/IP20 male-to-male PUR Cat6A cord.
Manufacturer product: https://eshop.weidmueller.com/en/ie-c6es8ug0150a40a40-e/p/8909650150
Manufacturer downloads: https://eshop.weidmueller.com/en/ie-c6es8ug0150a40a40-e/p/8909650150/downloads
Datasheet viewed through browser: https://datasheet.weidmueller.com/pdf/en/8909650150/scope/2/
Datasheet generation date 2026-02-18. Local PDF and HTML retrieval returned HTTP403; no downloaded PDF is claimed. The browser successfully extracted five pages. Page2 gives -40..80C operating, -15..60C installation, AWG26/7, 6.1..6.5mm sheath, 290ohm/km pair-loop. Page3 gives 5D single/10D repetitive bend, oil resistance, shielded straight IP20 plugs. UV and explicit T568B color mapping remain unconfirmed from primary evidence.

STEP and six DXF views downloaded successfully from the exact product links. STEP SHA256 2fa7f4e4927997e2473fd8627d8a2baeb2050a451b88797f61f4bfd016ddfe1a; original header CATIA 2025-11-19, internal family 8909650000. The product link binds this family model to 8909650150. Its cable is shortened to 200mm; do not treat model length as real cord length. DXFs are CAD views, not a verified toleranced manufacturing drawing.

OCCT STEP transfer imported one solid. BRepBndLib.AddOptimal(shape, box, False, False) returned total model bounds approximately X0..13.70, Y0..18.456687, Z0..279.96mm. For the first end, select complete faces with Zmax<100mm to exclude the central cable cylinder crossing the cutoff: envelope Z0..57.98mm. Plug/boot section ends at Z39.98mm; rear sleeve occupies Z39.98..57.98mm. Both section and complete bounds retained as JSON. Figure is native STEP edge projection: BRepAdaptor_Curve sampled31points per edge, side Y/Z and top X/Z, axes in mm; not a hand-drawn manufacturer dimension sheet. OCCT tolerances near 1e-6mm do not establish manufacturing tolerances. Figure includes hidden edges.

Project inference: 290 * .015 / 3 * 1.25 + .300 = 2.1125ohm, including the existing unmeasured combined contact allocation. At0.100A and10.8V gives10.58875V, above10.5V floor. Does not qualify assembled contacts or hot-plug operation. Installation bend radius with6.5mm OD is32.5mm single,65mm repetitive.

Next: inspect full mated sleeve/latch access and grip envelope against exact Würth615008160221 and both enclosures, classify tolerances honestly, resolve UV and straight-through pair mapping from primary evidence, then independent source review and owning gates. ADR0007 already permits represented physical FULL INCOMPLETE after SOURCE success for carrier prototype work. No mandatory coupon or renewed user authorization is introduced.
