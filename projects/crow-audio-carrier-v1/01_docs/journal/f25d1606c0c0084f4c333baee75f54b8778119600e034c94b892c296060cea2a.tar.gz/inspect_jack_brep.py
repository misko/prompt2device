from pathlib import Path
import sys, json, hashlib
sys.path.insert(0, '/tmp/carrier-rj45-20260912/cad-libs')
import OCP
from OCP.STEPControl import STEPControl_Reader
from OCP.IFSelect import IFSelect_RetDone
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE
from OCP.TopoDS import TopoDS
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.GeomAbs import GeomAbs_Cylinder

D = Path('/tmp/carrier-rj45-20260912')
path = Path('/tmp/carrier-rj45-jack-selection-pntbys98/06_build/task_runs/rj45-jack-selection/scratch/wurth_615008160221.step')
if len(sys.argv) > 1:
 path = Path(sys.argv[1])
output_name = sys.argv[2] if len(sys.argv) > 2 else 'jack-brep-geometry.json'
reader = STEPControl_Reader()
assert reader.ReadFile(str(path)) == IFSelect_RetDone
assert reader.TransferRoots() > 0
shape = reader.OneShape()
def bounds(s):
 b = Bnd_Box(); BRepBndLib.AddOptimal_s(s, b, False, False)
 return [round(v, 6) for v in b.Get()]

rows=[]
it = TopExp_Explorer(shape, TopAbs_SOLID)
while it.More():
 solid=it.Current(); cylinders=[]
 faces=TopExp_Explorer(solid,TopAbs_FACE)
 while faces.More():
  face=TopoDS.Face_s(faces.Current()); s=BRepAdaptor_Surface(face,True)
  if s.GetType()==GeomAbs_Cylinder:
   cy=s.Cylinder(); ax=cy.Axis(); loc=ax.Location(); direction=ax.Direction()
   cylinders.append({'radius':round(cy.Radius(),6),'point':[round(loc.X(),6),round(loc.Y(),6),round(loc.Z(),6)],'axis':[round(direction.X(),6),round(direction.Y(),6),round(direction.Z(),6)],'face_bounds':bounds(face)})
  faces.Next()
 rows.append({'solid':len(rows),'bounds':bounds(solid),'cylinders':cylinders})
 it.Next()
out={'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'ocp_version':OCP.__version__,'bounds':bounds(shape),'solids':rows,'method':'OCCT STEP transfer including assembly transforms; exact BREP bounding boxes and cylinder axes'}
(D/output_name).write_text(json.dumps(out,indent=2)+'\n')
print('bounds',out['bounds'],'solids',len(rows))
for row in rows:
 print(row['solid'],row['bounds'])
 for cy in row['cylinders']:
  if abs(cy['radius']-.23)<1e-5 and abs(cy['axis'][2])>.999:
   print(' tail',cy)
