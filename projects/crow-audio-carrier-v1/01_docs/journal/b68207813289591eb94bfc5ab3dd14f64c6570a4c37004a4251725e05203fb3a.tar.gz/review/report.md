# Carrier placement handback

MEASURED: the single authorized normal schematic resume stopped at **[5e] P-ORIENT**. Machine orientation **9/9 PASS**; explicit approval subject/denominator is stale. Driver rc **1**, **180.529 s**; outer bounded runtime rc **1**, **180.656951 s**, finished **2026-09-13T05:23:08.599705Z**. No conductor retry or source edit occurred.

MEASURED: 636/636 frozen inputs and 618 protected live source/method preimages verified before and after. Current initial handoff validated; 612/612 prelayout inputs, 11/11 prelayout checkpoint files and 7/7 schematic checkpoint files passed normally. Components agree 333/333 across source/native domains; circuit has985 source ports and179 source nets. Selective P-PINMAP grades47 multi-pin references/411 physical pin identities. P-MODEL-REG6/6 groups PASS; all333 fitted model bodies covered.

MEASURED: exact pre-route and final-current native DRC each report **0 violations / 499 unconnected / 0 parity**. Final full severity/refill/parity/exit-code measurement returned **rc5 in2.082150s** because the connections are open. The final board remained byte-identical before/after native DRC. Both saved subjects happen to share PCB hash `d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de`; their exact reports remain separately preserved. Every report row is classified independently in evidence.json:493 pad-to-pad open connections and6 pad-to-zone connections. Each of998 endpoints matches native UUID/net identity;992 pad positions checked,6 zone anchors distinguished from filled-zone points. The saved native board has340 footprint objects/1050 total pad objects,11 vias,0 track segments and81 zones;333 are fitted circuit components. Unconnected rows express individual unfinished connections, not a congestion hypothesis or routing acceptance.

The previous native gate remains archived against frozen preceding PCB9c30a147:8 old embedded Fab/library mismatches,493 pad-to-pad and6 pad-to-zone opens,0 parity. All507 prior rows retain exact descriptions and endpoint identity; the8 old mismatches are absent in both newly measured reports. J1–J8 embedded Fab primitive census also remains in each classification.

MEASURED: current orientation subject `3388c531a98d6babf6a144e24849dd78224f6a86054d98d71c7dddc5172555f8` has11 individually hash-verified review images over3 human representatives (J1,J5,J9), covering9 machine-graded instances. The current review is `06_build/pre_route/orientation/orientation_review.md`; receipt, complete render sources and views are preserved. No current user approval was fabricated or inferred. Ordinary raster registration6/6 is nominal CAD evidence. INHERITED from coordinator: accepted supplemental source review626c3bae covers all9 instances/99 exported solids; coordinator subsequently reports current-instance binding PASS9/9 at05:27:31Z (worker did not open unfrozen proof). This worker did not open prior review reasoning or claim new supplemental acceptance.

MEASURED: placement beacon and journal updated; normal compact handoff generated and validated against fresh final native gate. Handoff validity does not imply routing or release acceptance. Placement independent review, route import/taps/stitch, route acceptance, layout seal, fabrication, release and physical qualification: **NOT RUN**. Physical FULL23 findings remain explicitly deferred by accepted prototype policy. **FIRST-ARTICLE-ONLY / DO-NOT-ORDER**.

Exact component/pin/native subject hashes:

- `03_tscircuit/build/circuit.json`: `a3fdcd5dbad16cbbd8873cee3c501e5a855f06268ca9628bc999daf9c8f20e37`
- `03_tscircuit/build/schematic.pdf`: `b0e91e857ed7b273153491ecc1ec28298e87ecfbc3276726c8085cae9f4c2256`
- `03_tscircuit/manifest.yaml`: `3af1dbfa7630f329bfed20ee4b8965fecd99617cbdb58eb199c0cac1ef379ba2`
- `03_tscircuit/kicad/crow_audio_carrier_v1.kicad_sch`: `40e6ed86008973bd1c584c33eb6c01a1cf67314ecae6569ef1d64fdd866a6fe5`
- `04_kicad/crow_audio_carrier_v1.kicad_pcb`: `d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de`
- `04_kicad/crow_audio_carrier_v1.kicad_sch`: `40e6ed86008973bd1c584c33eb6c01a1cf67314ecae6569ef1d64fdd866a6fe5`
- `04_kicad/crow_audio_carrier_v1.kicad_pro`: `ad4d0bff8b710f0de505e0c341ae74bdf502993e03b791a7224192f32a015076`
- `04_kicad/crow_audio_carrier_v1.kicad_dru`: `c86b53ca8630718200667bc19a6633971f0967b2a546a8fb1b63c7b544d314f5`
- `06_build/netlists/crow_audio_carrier_v1.net`: `e3a547b1d14d91765e3f62f13c7ac9b343a10e693eaa17964cef1b55dcee23bf`
- `06_build/checkpoints/schematic.json`: `fe81ab82dd85b8b592c4e97beb988f5f6e9122184c9df2fd49207e79df1c36d7`
- `06_build/drc/pre_route.json`: `91ded3bf41a32a5467b18099b553f4d56f6970bc5fe3dc372523fcb85f3b13a8`
- `06_build/drc/gate.json`: `aa6d077396397319d2947a4ddd2577e6321032c64ca9082444cca87a6a69902b`
- `06_build/pre_route/orientation/orientation_receipt.json`: `345bd0c2fbeb78c7f462ea22248f3dbf1389e1ce4176661d7a9e2e7444d82065`
- `06_build/pre_route/model_registration.stage.json`: `a197a8501e4b044f90afc15b81db969777966ebffb2c2f41258bdc33a9eec214`
- `06_build/agent_handoff.yaml`: `492bf61790b6ac541e51a2309c11c5589bcb4e5e43db19156ce20542f7a78edc`

Exact evidence lives under `06_build/task_runs/rj45-carrier-placement-after-fabfeatures1/outputs`: report.md, evidence.json, evidence-manifest.json, evidence.tar.gz and result.json. Raw command logs and bounded runtime receipts, initial/final native boards and all classifications are regular archive members; manifest binds each member size/hash and archive size/hash. The package delivery checks are separate from the non-passing engineering state. Root owns host closure, durable archive and commits.

MEASURED: provided preflight.py PASS for EXCLUSIVE writer scope and all declared delivery outputs; protected618 live preimages and636 frozen inputs remain unchanged.
