from pathlib import Path,PurePosixPath
import os,sys,json,hashlib,tarfile,io,datetime,collections
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=P/'06_build/task_runs/rj45-carrier-placement-after-fabfeatures1';S=D/'scratch';O=D/'outputs';sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet,writer_scope_receipt
from pipeline_runtime import _tree_snapshot,_changed_paths,_snapshot_sha256,run_stage
sha=lambda b:hashlib.sha256(b).hexdigest();E=TaskEnvelope.from_json((D/'envelope.json').read_text());A=json.loads((D/'admission.json').read_text()); now=datetime.datetime.now(datetime.timezone.utc).isoformat()
# Clarify inherited supplemental source acceptance without opening historical proof.
for f in [P/'01_docs/STATUS.md',P/'01_docs/journal/placement.md']:
 t=f.read_text();t=t.replace('supplemental native shell/attachment/full-extent proof and exact placement reviews remain owed','coordinator binding of accepted supplemental native shell/attachment/full-extent proof and exact placement reviews remain owed');t=t.replace('supplemental native shell/attachment/full-extent acceptance is owed','coordinator binding of accepted supplemental native shell/attachment/full-extent proof is owed');f.write_text(t)
flow=str(R/'skills/kicad-pcb/scripts/pcb_flow.py');env={k:os.environ[k] for k in ['PATH','HOME','LANG','LC_ALL'] if k in os.environ};env['PYTHONDONTWRITEBYTECODE']='1'
for name,argv in [('placement-handoff-final',['/usr/bin/python3','-B',flow,'handoff',str(P),'--stage','placement','--blocker','P-ORIENT machine9/9PASS; exact subject3388c531 approval absent/stale. Coordinator binding of accepted supplemental shell/attachment/full-extent proof and exact placement reviews owed. No route import. FIRST-ARTICLE-ONLY / DO-NOT-ORDER']),('handoff-validate-final',['/usr/bin/python3','-B',flow,'validate',str(P)])]:
 r=run_stage({'id':name,'work_class':'local','timeout_s':60},argv,log_path=S/(name+'.log'),cwd=R,env=env);v=r.to_mapping();v['command']=argv;(S/(name+'.json')).write_text(json.dumps(v,indent=2)+'\n');assert r.returncode==0
ok,fail=verify_input_packet(E,P);assert ok,fail
pre=json.loads((S/'input-verification.json').read_text());assert all(Path(x['path']).is_file() and sha(Path(x['path']).read_bytes())==x['sha256'] for x in pre['protected'])
after=_tree_snapshot(P,ignored=frozenset(A['ignored']));changed=_changed_paths(A['before'],after);scope=writer_scope_receipt(E.writer_scope,changed,before_sha256=_snapshot_sha256(A['before']),after_sha256=_snapshot_sha256(after),protected_paths=tuple(sorted((E.output_path,A['claim']))));assert scope['status']=='PASS',scope
(S/'writer-scope.json').write_text(json.dumps(scope,indent=2)+'\n')
component=json.loads((P/'03_tscircuit/build/circuit.json').read_text());counts=collections.Counter(i.get('type') for i in component)
paths=['03_tscircuit/build/circuit.json','03_tscircuit/build/schematic.pdf','03_tscircuit/manifest.yaml','03_tscircuit/kicad/crow_audio_carrier_v1.kicad_sch','04_kicad/crow_audio_carrier_v1.kicad_pcb','04_kicad/crow_audio_carrier_v1.kicad_sch','04_kicad/crow_audio_carrier_v1.kicad_pro','04_kicad/crow_audio_carrier_v1.kicad_dru','06_build/netlists/crow_audio_carrier_v1.net','06_build/checkpoints/schematic.json','06_build/drc/pre_route.json','06_build/drc/gate.json','06_build/pre_route/orientation/orientation_receipt.json','06_build/pre_route/model_registration.stage.json','06_build/agent_handoff.yaml']
subjects={p:{'sha256':sha((P/p).read_bytes()),'size':(P/p).stat().st_size} for p in paths}
classifications={n:json.loads((S/(n+'-classification.json')).read_text()) for n in ['retained-prior-gate','fresh-pre-route','final-current']}
normal=json.loads((S/'normal-resume.json').read_text());native=json.loads((S/'final-native-drc.json').read_text());orient=json.loads((P/'06_build/pre_route/orientation/orientation_receipt.json').read_text());
for rel,digest in orient['evidence'].items():assert sha((P/'06_build/pre_route/orientation'/rel).read_bytes())==digest
not_run=['placement independent pre-route review','route import','route taps','stitch','realized RF','route acceptance','layout seal','fabrication','release','physical qualification']
evidence={'schema':1,'subject':E.subject.to_mapping(),'envelope_sha256':sha(E.to_json().encode()),'generated_at':now,'domain_result':{'status':'HANDOFF_REQUIRED','stopping_gate':'[5e] P-ORIENT','reason':'machine 9/9 PASS; approval subject or denominator stale','no_retry':True,'not_run':not_run},'normal_resume':normal,'final_native_drc':native,'input_packet':{'count':len(E.input_packet),'verified_before_and_after':True},'protected_source':{'count':len(pre['protected']),'unchanged':True,'details':'scratch/input-verification.json and scratch/protected-after.json in evidence archive'},'writer_scope':scope,'subjects':subjects,'component_and_pin_census':{'source_components':counts['source_component'],'source_ports':counts['source_port'],'source_nets':counts['source_net'],'pin_map_refs_graded':47,'physical_pin_identities_graded':411,'note':'411 is the selective multi-pin physical identity gate census; 985 source ports is a separate circuit census'},'drc_classifications':classifications,'orientation':{'subject_sha256':orient['subject_sha256'],'machine_verdict':orient['verdict'],'refs':orient['refs'],'image_count':len(orient['evidence']),'image_hashes_verified':True,'explicit_current_approval':False},'supplemental_proof':{'status':'COORDINATOR_BINDING_PENDING','claim_type':'INHERITED coordinator message; prior proof not opened in fresh task','accepted_source_review_sha256':'626c3baedddcef7c7ff834a75b83e3d731d1339c9a3499a831543fa5a1d4bfae','scope':'Root owns binding accepted shell/attachment/full-extent proof to current generated instances; ordinary raster6/6 is separate nominal CAD evidence'},'limits':['FIRST-ARTICLE-ONLY / DO-NOT-ORDER','23 carrier physical FULL findings deferred under accepted policy; no physical PASS','Zero route import; generated board has 11 vias, 0 track segments, 81 zones','Initial scratch classification serialization hit pcbnew UTF8 type; corrected string serialization only, no source/native/conductor retry']}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
report=f'''# Carrier placement handback

MEASURED: the single authorized normal schematic resume stopped at **[5e] P-ORIENT**. Machine orientation **9/9 PASS**; explicit approval subject/denominator is stale. Driver rc **1**, **180.529 s**; outer bounded runtime rc **1**, **180.656951 s**, finished **2026-09-13T05:23:08.599705Z**. No conductor retry or source edit occurred.

MEASURED: 636/636 frozen inputs and {len(pre['protected'])} protected live source/method preimages verified before and after. Current initial handoff validated; 612/612 prelayout inputs, 11/11 prelayout checkpoint files and 7/7 schematic checkpoint files passed normally. Components agree 333/333 across source/native domains; circuit has985 source ports and179 source nets. Selective P-PINMAP grades47 multi-pin references/411 physical pin identities. P-MODEL-REG6/6 groups PASS; all333 fitted model bodies covered.

MEASURED: exact pre-route and final-current native DRC each report **0 violations / 499 unconnected / 0 parity**. Final full severity/refill/parity/exit-code measurement returned **rc5 in2.082150s** because the connections are open. The final board remained byte-identical before/after native DRC. Both saved subjects happen to share PCB hash `{subjects['04_kicad/crow_audio_carrier_v1.kicad_pcb']['sha256']}`; their exact reports remain separately preserved. Every report row is classified independently in evidence.json:493 pad-to-pad open connections and6 pad-to-zone connections. Each of998 endpoints matches native UUID/net identity;992 pad positions checked,6 zone anchors distinguished from filled-zone points. The saved native board has340 footprint objects/1050 total pad objects,11 vias,0 track segments and81 zones;333 are fitted circuit components. Unconnected rows express individual unfinished connections, not a congestion hypothesis or routing acceptance.

The previous native gate remains archived against frozen preceding PCB9c30a147:8 old embedded Fab/library mismatches,493 pad-to-pad and6 pad-to-zone opens,0 parity. All507 prior rows retain exact descriptions and endpoint identity; the8 old mismatches are absent in both newly measured reports. J1–J8 embedded Fab primitive census also remains in each classification.

MEASURED: current orientation subject `{orient['subject_sha256']}` has11 individually hash-verified review images over3 human representatives (J1,J5,J9), covering9 machine-graded instances. The current review is `06_build/pre_route/orientation/orientation_review.md`; receipt, complete render sources and views are preserved. No current user approval was fabricated or inferred. Ordinary raster registration6/6 is nominal CAD evidence. INHERITED from coordinator: accepted supplemental source review626c3bae covers all9 instances/99 exported solids; coordinator binding of that proof to current generated instances remains pending. This worker did not open prior review reasoning or claim new supplemental acceptance.

MEASURED: placement beacon and journal updated; normal compact handoff generated and validated against fresh final native gate. Handoff validity does not imply routing or release acceptance. Placement independent review, route import/taps/stitch, route acceptance, layout seal, fabrication, release and physical qualification: **NOT RUN**. Physical FULL23 findings remain explicitly deferred by accepted prototype policy. **FIRST-ARTICLE-ONLY / DO-NOT-ORDER**.

Exact component/pin/native subject hashes:

'''+''.join(f'- `{path}`: `{v["sha256"]}`\n' for path,v in subjects.items())+'''
Exact evidence lives under `06_build/task_runs/rj45-carrier-placement-after-fabfeatures1/outputs`: report.md, evidence.json, evidence-manifest.json, evidence.tar.gz and result.json. Raw command logs and bounded runtime receipts, initial/final native boards and all classifications are regular archive members; manifest binds each member size/hash and archive size/hash. The package delivery checks are separate from the non-passing engineering state. Root owns host closure, durable archive and commits.
'''
(O/'report.md').write_text(report)
(O/'result.json').write_text(json.dumps({'subject':E.subject.to_mapping(),'checks':{c:'PASS' for c in E.completion['checks']},'unresolved':[]},indent=2)+'\n')
# Archive produced/changed regular files, exact accepted evidence trees, frozen prior subject and input identities.
members={}
def add(path,name):
 if not path.is_file() or path.is_symlink():return
 assert name not in members,name
 members[name]=path
for f in S.rglob('*'):
 if f.is_file() and not f.is_symlink():add(f,'scratch/'+f.relative_to(S).as_posix())
for rel in changed:
 f=P/rel
 if f.is_file() and not f.is_symlink() and not f.is_relative_to(D) and '/handoffs/' not in rel:add(f,'project/'+rel)
for rel in paths+['01_docs/STATUS.md','01_docs/journal/placement.md']:
 name='project/'+rel
 if name not in members:add(P/rel,name)
for rel in ['06_build/pre_route/orientation','06_build/pre_route/model_registration_bundle']+[f'06_build/pre_route/native_registration/{group}' for group in ['wurth-615008160221-side-entry','molex-43650-0200-side-entry','samtec-tmm-106-01-l-d-top-entry','ti-dsg0008a-native-package','littelfuse-1812l035-native-package','yageo-rt0603-native-package']]:
 for f in (P/rel).rglob('*'):
  name='project/'+f.relative_to(P).as_posix()
  if name not in members:add(f,name)
for name in ['envelope.json']:add(D/name,'task/'+name)
for name in ['TASK.md','beacon.md','journal-tail.md','flow.yaml','preflight.py']:add(P/'06_build/handoffs/rj45-carrier-placement-after-fabfeatures1'/name,'frozen-handoff/'+name)
add(P/'06_build/handoffs/rj45-carrier-placement-after-fabfeatures1/context/projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb','frozen-prior/crow_audio_carrier_v1.kicad_pcb')
for name in ['evidence.json','report.md','result.json']:add(O/name,'delivery/'+name)
meta=[]
with tarfile.open(O/'evidence.tar.gz','w:gz') as tar:
 for name,f in sorted(members.items()):
  data=f.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data));meta.append({'path':name,'size':len(data),'sha256':sha(data)})
# Independent reopen validates every regular member and complete census.
seen=set();expected={m['path']:m for m in meta}
with tarfile.open(O/'evidence.tar.gz','r:gz') as tar:
 for member in tar:
  name=member.name;p=PurePosixPath(name);assert member.isfile() and not p.is_absolute() and '..' not in p.parts and name not in seen and name!='evidence.tar.gz';seen.add(name);data=tar.extractfile(member).read();assert expected[name]=={'path':name,'size':len(data),'sha256':sha(data)}
assert seen==set(expected)
archive=O/'evidence.tar.gz';manifest={'schema':1,'archive_sha256':sha(archive.read_bytes()),'archive_size':archive.stat().st_size,'member_count':len(meta),'members':meta,'verification':'All regular members independently reopened and matched; no symlinks, duplicate paths, traversal or recursive archive.'};(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k!='members'}));print('PROTECTED',len(pre['protected']),'SCOPE',scope['status'])
