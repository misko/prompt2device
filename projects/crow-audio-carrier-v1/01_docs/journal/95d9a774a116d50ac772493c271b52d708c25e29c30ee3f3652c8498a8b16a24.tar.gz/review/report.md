# Locator policy source review — SOUND

Acceptance is limited to **one exact source file**: `projects/crow-audio-carrier-v1/03_src/rules/policy_waivers.yaml`.

Before SHA-256: `28d4bf36efee10b32a13ab79e87316984318994c2569397098108145b9421ecc`  
After SHA-256: `1708ef388779c2dad5896eb5806f66529bbe3787248bf010637c1fbab5c105b7`

The full diff only removes `R_ADC_PD1P` and `R_PWR_BOT`, changes evidence output `'25'` to `'23'`, and changes the strict budget `== 25` to `== 23`. The frozen original equals the frozen live-before file. Rationale, evidence command, applicability condition, other source and checker bytes remain unchanged.

Independent native inspection of board SHA-256 `01ed49549238189a80d64e24a61832d6e9ca8826fd5bf107137243d2ea9b4240` found 340 footprints, 333 non-board-only assembled references, 1043 pads, 23 omitted fitted references and zero fitted bottom-side footprints. `R_ADC_PD1P` at (37.75, 53.7) mm and `R_PWR_BOT` at (30.0, 56.7) mm are visible on front silkscreen. All 23 native/source/policy/bundle/atlas references match exactly, with no duplicates. All per-part source identities, positions, rotations, side and pad/net tuples pass the actual owning checker along with CSV datums, tool hashes and 26 shipped locator members. The atlas has 23 PNG pages and 23 bound PDF pages.

The unchanged owning `check()` returns 333 references / 1043 pads / 23 exceptions / 23 pages / 26 members. Its actual exact CLI emits final numeric line `23`, establishing that the strict budget matches the measured consumer count, not merely the policy list length. The project evidence command still cannot complete successfully until its independent visual prerequisite is renewed.

The original policy and each known-bad case re-adding either removed reference independently fail `project_check()` with `policy waiver/locator exception sets differ`. The corrected policy passes through identity checking but fails with `independent locator review manifest is stale`. The standalone visual checker returns the same error. No review receipt was fabricated or modified, and no visual usability judgment was performed.

This is source-composition acceptance only. It does not activate a waiver, pass the whole project check or grant placement, rendering, assembly, release or ordering acceptance. The existing conditional language requiring the current checked bundle and independent exact-artifact render verdict is preserved. Root must adopt the source-only correction before ordinary full conductor/source checkpoint and schematic renewal; fresh schematic reports cannot be restamped for changed rules. Placement/render/assembly review, current visual acceptance and release obligations remain separate. Native investigation remains at 4/4, unchanged. **FIRST-ARTICLE-ONLY / DO-NOT-ORDER.**

No unresolved defect was found within the one-file scope. All 78 frozen inputs were verified before and after review. Setup path and unavailable-rg errors and nonfatal pcbnew diagnostics are retained in scratch and the evidence archive. Review methods, raw stdout/stderr, command/environment records, finite runtime receipts, native measurements, negative cases and accepted one-file hash manifest are archived. Final delivery validation follows packaging and is retained separately in scratch.
