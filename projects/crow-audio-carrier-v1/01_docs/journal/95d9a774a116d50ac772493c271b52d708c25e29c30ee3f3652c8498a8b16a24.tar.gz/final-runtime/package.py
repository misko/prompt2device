from pathlib import Path
import json, hashlib, tarfile, io
P=Path("/tmp/rj45-locator-policy-source-review1-6q16q3zb")
S=Path(__file__).parent; O=S.parent/"outputs"; O.mkdir(exist_ok=True)
e=json.loads((S.parent/"envelope.json").read_text()); m=json.loads((S/"measurements.json").read_text())
accepted=m["accepted_files"]
(S/"accepted-hash-manifest.json").write_text(json.dumps({"files":accepted,"file_count":1},indent=2)+"\n")
findings=[
{"id":"source-composition","status":"SOUND","detail":"The complete byte and parsed YAML diff removes only R_ADC_PD1P and R_PWR_BOT and changes evidence output 25 to 23 and budget == 25 to == 23. Before equals frozen live-before. No other waiver, rationale, command, requirement or limit changes."},
{"id":"native-set-and-identities","status":"SOUND","detail":"Independently measured 340 native footprints, 333 non-board-only references and 1043 pads. The native omitted set, source exceptions, corrected waiver, bundle hidden list and 23 atlas pages are exactly equal with unique refs. Both removed refs are visible on F.Silkscreen and top-side. Actual unchanged owning check() passes all native/source/CSV/HTML/JSON/PNG/PDF/tool/member identity checks; 26 manifest members."},
{"id":"strict-count","status":"SOUND","detail":"Actual owning check returns exceptions=23 and actual exact CLI emits final numeric line 23; corrected output and strict == 23 budget equal that measured count. The project command remains blocked pending current independent visual acceptance; this is not a claim its evidence command currently succeeds."},
{"id":"negative-discrimination","status":"SOUND","detail":"Actual project_check rejects original policy and separately each known-bad re-added visible ref with policy waiver/locator exception sets differ. Corrected project_check and standalone visual check still reject independent locator review manifest is stale."},
{"id":"scope-boundary","status":"SOUND","detail":"Acceptance is solely the exact one-file metadata source composition. No adoption, native generation, prep, fill, save, routing, geometry edits, checker edits, waiver effectiveness, visual acceptance or placement PASS occurred. Cumulative native investigation remains 4/4 unchanged."}
]
obligations=["Root source-only adoption must precede ordinary full conductor/source checkpoint and schematic renewal.","Fresh schematic reviews cannot be restamped for changed rules; renew against the resulting exact source checkpoint.","Independent exact-artifact placement/render/assembly review and current visual acceptance remain owed; the copied visual receipt is stale and rejected.","Full project/waiver/release obligations remain separate and unpassed. FIRST-ARTICLE-ONLY / DO-NOT-ORDER."]
evidence={"verdict":"SOUND","subject":e["subject"],"scope":"Exact one-file source composition only","accepted_hash_manifest":{"file_count":1,"files":accepted},"methods":["78 frozen envelope inputs hashed and sized before and after engineering review.","Full literal diff and parsed YAML semantic comparison against frozen current source.","Independent pcbnew LoadBoard census of native fitted references, pads, visibility and layer.","Unmodified frozen owning checker check(..., tool_source=frozen tools) and actual exact CLI.","Actual project_check on four scratch-only project copies: original, corrected, and each separately re-added visible ref. Standalone stale visual check.","Closed archive member census with traversal, duplicate, symlink and recursive-archive refusal; reopen and hash every regular member; exact-envelope preflight after packaging."],"findings":findings,"measured_counts":m,"obligations":obligations,"engineering_unresolved":[],"execution_notes":["Malformed initial relative envelope lookup preserved in initial-setup.txt; corrected absolute path used.","Two attempted /usr/bin/rg lookups could not launch; raw error and runtime retained. Python read-only search used thereafter.","Nonfatal pcbnew enum assertions and duplicate image-handler diagnostics retained losslessly in independent-review.log; engineering runtime completed normally."]}
(O/"evidence.json").write_text(json.dumps(evidence,indent=2)+"\n")
report=f"""# Locator policy source review — SOUND

Acceptance is limited to **one exact source file**: `projects/crow-audio-carrier-v1/03_src/rules/policy_waivers.yaml`.

Before SHA-256: `{accepted[0]['before_sha256']}`  
After SHA-256: `{accepted[0]['after_sha256']}`

The full diff only removes `R_ADC_PD1P` and `R_PWR_BOT`, changes evidence output `'25'` to `'23'`, and changes the strict budget `== 25` to `== 23`. The frozen original equals the frozen live-before file. Rationale, evidence command, applicability condition, other source and checker bytes remain unchanged.

Independent native inspection of board SHA-256 `{m['board_sha256']}` found 340 footprints, 333 non-board-only assembled references, 1043 pads, 23 omitted fitted references and zero fitted bottom-side footprints. `R_ADC_PD1P` at (37.75, 53.7) mm and `R_PWR_BOT` at (30.0, 56.7) mm are visible on front silkscreen. All 23 native/source/policy/bundle/atlas references match exactly, with no duplicates. All per-part source identities, positions, rotations, side and pad/net tuples pass the actual owning checker along with CSV datums, tool hashes and 26 shipped locator members. The atlas has 23 PNG pages and 23 bound PDF pages.

The unchanged owning `check()` returns 333 references / 1043 pads / 23 exceptions / 23 pages / 26 members. Its actual exact CLI emits final numeric line `23`, establishing that the strict budget matches the measured consumer count, not merely the policy list length. The project evidence command still cannot complete successfully until its independent visual prerequisite is renewed.

The original policy and each known-bad case re-adding either removed reference independently fail `project_check()` with `policy waiver/locator exception sets differ`. The corrected policy passes through identity checking but fails with `independent locator review manifest is stale`. The standalone visual checker returns the same error. No review receipt was fabricated or modified, and no visual usability judgment was performed.

This is source-composition acceptance only. It does not activate a waiver, pass the whole project check or grant placement, rendering, assembly, release or ordering acceptance. The existing conditional language requiring the current checked bundle and independent exact-artifact render verdict is preserved. Root must adopt the source-only correction before ordinary full conductor/source checkpoint and schematic renewal; fresh schematic reports cannot be restamped for changed rules. Placement/render/assembly review, current visual acceptance and release obligations remain separate. Native investigation remains at 4/4, unchanged. **FIRST-ARTICLE-ONLY / DO-NOT-ORDER.**

No unresolved defect was found within the one-file scope. All 78 frozen inputs were verified before and after review. Setup path and unavailable-rg errors and nonfatal pcbnew diagnostics are retained in scratch and the evidence archive. Review methods, raw stdout/stderr, command/environment records, finite runtime receipts, native measurements, negative cases and accepted one-file hash manifest are archived. Final delivery validation follows packaging and is retained separately in scratch.
"""
(O/"report.md").write_text(report)
(O/"result.json").write_text(json.dumps({"subject":e["subject"],"checks":{k:"PASS" for k in e["completion"]["checks"]},"unresolved":[]},indent=2)+"\n")
# Seal all engineering evidence and method source. Current packaging and later
# preflight telemetry are delivery receipts retained separately in scratch.
excluded={"packaging.log","packaging-runtime.json","preflight.log","preflight-runtime.json","preflight-command.json"}
paths=[p for p in S.rglob("*") if p.is_file() and p.name not in excluded]
paths += [O/"report.md",O/"evidence.json",O/"result.json"]
records=[]; seen=set()
with tarfile.open(O/"evidence.tar.gz","w:gz") as tar:
    for p in sorted(paths):
        assert not p.is_symlink()
        name=("scratch/"+p.relative_to(S).as_posix()) if p.is_relative_to(S) else ("outputs/"+p.name)
        assert name not in seen and not name.startswith("/") and ".." not in Path(name).parts and not name.endswith((".tar.gz",".tar"))
        seen.add(name); data=p.read_bytes(); h=hashlib.sha256(data).hexdigest()
        info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644; info.mtime=0; tar.addfile(info,io.BytesIO(data))
        records.append({"path":name,"size":len(data),"sha256":h})
with tarfile.open(O/"evidence.tar.gz","r:gz") as tar:
    members=tar.getmembers(); assert len(members)==len(records)
    assert len({x.name for x in members})==len(members)
    for item,record in zip(members,records):
        assert item.isfile() and item.name==record["path"] and item.size==record["size"]
        data=tar.extractfile(item).read(); assert hashlib.sha256(data).hexdigest()==record["sha256"]
a=O/"evidence.tar.gz"
(O/"evidence-manifest.json").write_text(json.dumps({"archive_sha256":hashlib.sha256(a.read_bytes()).hexdigest(),"archive_size":a.stat().st_size,"member_count":len(records),"members":records},indent=2)+"\n")
# Reopen every frozen input once more after packaging.
for row in e["input_packet"]:
    p=P/row["path"]; assert p.stat().st_size==row["size"] and hashlib.sha256(p.read_bytes()).hexdigest()==row["sha256"]
print(json.dumps({"verdict":"SOUND","input_count":len(e["input_packet"]),"member_count":len(records),"archive_sha256":hashlib.sha256(a.read_bytes()).hexdigest()}))
