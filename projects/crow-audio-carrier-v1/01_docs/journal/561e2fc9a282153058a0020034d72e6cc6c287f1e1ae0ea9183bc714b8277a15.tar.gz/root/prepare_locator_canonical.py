from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,tarfile,subprocess
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
preserved=json.loads((D/'before-locator-renewal-preservation-result.json').read_text());archive=Path(preserved['archive']);assert sha(archive.read_bytes())==preserved['sha256']
with tarfile.open(archive) as t:
 m=json.loads(t.extractfile('MANIFEST.json').read());rows=m['members']
 for n in m['guard_paths']:
  p=P/n
  if n in m['absent_guard_paths']:assert not p.exists() and not p.is_symlink(),n
  else:
   b=p.read_bytes();saved=t.extractfile(n).read();assert b==saved and sha(b)==rows[n]['sha256'],n
 # Every outgoing generated companion remains exact before the normal producer.
 checkpoint=json.loads(t.extractfile('06_build/checkpoints/prelayout-inputs.json').read())
 for key in checkpoint['explicit']:
  p=R/key.removeprefix('repo:');assert sha(p.read_bytes())==checkpoint['files'][key]['sha256'],key
 retired=[]
 for n in m['guard_paths']:
  if n in m['absent_guard_paths']:continue
  (P/n).unlink();retired.append({'path':n,**rows[n]})
record={'time':datetime.now(timezone.utc).isoformat(),'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'archive_sha256':preserved['sha256'],'retired':retired,'absent':m['absent_guard_paths'],'companion_count':len(checkpoint['explicit']),'authorization':'User goal plus explicit archive-and-restart conductor boundary; no generated checkpoint restamped.'};(D/'locator-canonical-guard-retirement.json').write_text(json.dumps(record,indent=2)+'\n')
# Reuse the already executed mechanical runner, with immutable argv snapshots.
s=(D/'canonical_logged_runner.py').read_text().replace("'argv':argv", "'argv':list(argv)")
s=s.replace('passive_canonical_after_reader_fix','locator_canonical_renewal').replace('passive_public_after_reader_fix','locator_public_renewal')
(D/'locator_canonical_runner.py').write_text(s)
s=(D/'commission_logged_canonical.py').read_text().replace("'canonical_logged_runner.py'", "'locator_canonical_runner.py'")
s=s.replace("rid='passive-logged-'", "rid='locator-canonical-'")
s=s.replace("'passive_logged_canonical'", "'locator_canonical_renewal'")
s=s.replace("'/root/carrier_logged_canonical_restart'", "'/root/carrier_locator_canonical_renewal'")
s=s.replace("'/tmp/carrier-logged-restart-opened.json'", "'/tmp/carrier-locator-canonical-opened.json'")
start=s.index("Original canonical attempt used6.907s");end=s.index("After runner returns",start)
s=s[:start]+'''Locator implementation and the seven channel-caption/front-side source repairs are committed and independently scoped-reviewed. The original locator implementation review remains INCOMPLETE; its separately hashed correction supplement PASS is preserved. Full source330 tests passed before the focused checker correction; locator25, release101, PR-review14, native-land13 and gate-contract37 tests pass. Exact canonical render/layout acceptance is still owed. All five stale generated guards were root-retired only after reopening committed archive8e73749f81ce3605f5275f2d5077e01fb009662019720596dbed4d86a4339cb9 and all six pinned companions. No provider receipt exists. Existing connector human approval remains unchanged. This is one bundled canonical renewal, no router experiment.\n\n'''+s[end:]
(D/'commission_locator_canonical.py').write_text(s)
print(json.dumps({'retired_guard_count':len(retired),'companions_verified':len(checkpoint['explicit']),'prepared_factory':str(D/'commission_locator_canonical.py')}))
