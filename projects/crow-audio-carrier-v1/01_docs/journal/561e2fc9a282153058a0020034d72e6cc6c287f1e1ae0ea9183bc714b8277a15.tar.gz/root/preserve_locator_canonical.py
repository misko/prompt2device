from pathlib import Path
import json,hashlib,tarfile,io,shutil
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';C=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911');j=json.loads(Path('/tmp/carrier-locator-canonical-opened.json').read_text());A=Path(j['attempt']).parent;H=Path(j['task']).parent;payload={};sha=lambda b:hashlib.sha256(b).hexdigest()
def tree(root,prefix):
 for p in root.rglob('*'):
  if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts:payload[prefix+'/'+p.relative_to(root).as_posix()]=p
for root,prefix in [(A,'attempt'),(H,'handoff'),(P/'06_build/task_runs/qualify-dbcd3da5e5ad4f68915b240c8347b08f','qualification'),(P/'06_build/task_runs/qualify-dbcd3da5e5ad4f68915b240c8347b08f-identify','qualification-identify'),(P/'06_build/checkpoints','checkpoints')]:tree(root,prefix)
for n in ['03_tscircuit/build/circuit.json','03_tscircuit/build/schematic.pdf','04_kicad/crow_audio_carrier_v1.kicad_sch','06_build/build_provenance.json','06_build/netlists/crow_audio_carrier_v1.net','06_build/performance.json','06_build/erc.rpt','06_build/erc_errors.rpt','06_build/sourcing/prelayout_request.json','06_build/sourcing/prelayout_response.csv']:
 if (P/n).is_file():payload['canonical/'+n]=P/n
for pat in ['locator-final-*','locator-canonical-*']:
 for p in I.glob(pat):
  if p.is_file():payload['root/logs/'+p.name]=p
for n in ['prepare_locator_canonical.py','commission_locator_canonical.py','locator_canonical_runner.py','verify_locator_canonical.py','locator-canonical-reopening.json','locator-canonical-guard-retirement.json','prepare_locator_schematic_delta.py','locator-schematic-delta-prepared.json','commission_locator_delta.py','open_locator_schematic_availability.py','preserve_locator_canonical.py']:
 payload['root/'+n]=C/n
probe=json.loads((C/'locator-schematic-availability-opened.json').read_text())[0];tree(Path(probe['project']),'closed-review-availability')
notes='Factory initial clean-worktree assertion rejected the five intentionally retired tracked guard paths before TaskEnvelope/native child; corrected assertion requires exactly those five D statuses. Initial schematic-packet preparation assumed optional net_aliases.txt existed; it is absent from both accepted/current packets; conditional copy corrected before review commission. Original native runs remain unchanged. These setup errors did not execute routing or consume engineering attempts.\n';note=C/'locator-canonical-setup-failures.txt';note.write_text(notes);payload['root/'+note.name]=note
manifest={n:{'size':p.stat().st_size,'sha256':sha(p.read_bytes())} for n,p in payload.items()};out=C/'locator-canonical.tar.gz'
with tarfile.open(out,'w:gz',compresslevel=3) as t:
 for n,p in payload.items():t.add(p,arcname=n,recursive=False)
 b=(json.dumps({'members':manifest},indent=2)+'\n').encode();m=tarfile.TarInfo('MANIFEST.json');m.size=len(b);t.addfile(m,io.BytesIO(b))
h=sha(out.read_bytes());dest=P/'01_docs/journal'/f'{h}.tar.gz';assert not dest.exists();shutil.copyfile(out,dest)
with tarfile.open(dest) as t:
 assert len(t.getmembers())==len(manifest)+1
 for n,row in manifest.items():b=t.extractfile(n).read();assert len(b)==row['size'] and sha(b)==row['sha256'],n
result={'archive':str(dest),'sha256':h,'size':dest.stat().st_size,'payload_members':len(manifest)};(C/'locator-canonical-preservation-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
with (P/'01_docs/journal/contracts.md').open('a') as f:f.write(f'\n## Allowed locator canonical renewal evidence\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Closed canonical renewal, complete raw commands and qualification, source/checkpoint reopening, archive-bound guard retirement, generated schematic artifacts, preceding final source checks and fresh live reviewer availability |\n')
