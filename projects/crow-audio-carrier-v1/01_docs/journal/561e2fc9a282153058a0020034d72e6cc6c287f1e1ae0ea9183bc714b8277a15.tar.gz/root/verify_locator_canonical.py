from pathlib import Path
import json,sys,hashlib
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';C=Path(__file__).parent;j=json.loads(Path('/tmp/carrier-locator-canonical-opened.json').read_text());A=Path(j['attempt']).parent;H=Path(j['task']).parent
sys.path.insert(0,str(R/'skills/pcb-design/scripts'));from pipeline_execution import TaskEnvelope,verify_input_packet
sha=lambda b:hashlib.sha256(b).hexdigest();e=TaskEnvelope.from_json(Path(j['envelope']).read_text());assert json.loads((A/'attempt.json').read_text())['status']=='PASS';assert verify_input_packet(e,P)[0]
index=json.loads((H/'source-index.json').read_text())
for n,h in index.items():assert sha(Path(n).read_bytes())==h,n
x=json.loads((A/'outputs/execution.json').read_text());assert x['complete'] and x['error'] is None
for n,row in x['artifacts'].items():b=(P/n).read_bytes();assert len(b)==row['size'] and sha(b)==row['sha256'],n
for row in x['runs']:
 raw=json.loads((A/'scratch'/(row['stage']+'-runtime.json')).read_text());assert row==raw
 assert Path(row['runtime']['log_path']).is_file()
assert [r['runtime']['returncode'] for r in x['runs']]==[0,2,1]
assert '--resume-after-public-prelayout' not in x['runs'][1]['argv'] and '--resume-after-public-prelayout' in x['runs'][2]['argv']
proof={'input_packet_verified':len(e.input_packet),'authored_inputs_verified':len(index),'generated_artifacts_verified':len(x['artifacts']),'full_command_records_verified':len(x['runs']),'closed_status':'PASS','source_commit':json.loads((C/'locator-canonical-guard-retirement.json').read_text())['source_commit'] if 'source_commit' in json.loads((C/'locator-canonical-guard-retirement.json').read_text()) else '99b5bd56','limits':'Delivery is closed. Owning PR-REVIEW remains FAIL with3 stale fields; no placement/route/release acceptance.'};(C/'locator-canonical-reopening.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
