from pathlib import Path
import sys,json,hashlib,subprocess,tempfile,shutil,tarfile,io
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';C=Path(__file__).parent;OLD=Path('/tmp/carrier-passive-schematic-delta-658ajmzl');D=Path(tempfile.mkdtemp(prefix='carrier-locator-schematic-delta-'));prev='7bfb3a9e';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();prefix=P.relative_to(R).as_posix()+'/'
def selected(n):return n.startswith(('02_parts/','03_src/')) or (n.startswith('03_tscircuit/') and not n.startswith(('03_tscircuit/build/','03_tscircuit/dist/','03_tscircuit/node_modules/','03_tscircuit/kicad/','03_tscircuit/verification/')))
def put(side,n,b):p=D/side/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
for side,rev in [('previous',prev),('current',head)]:
 payload=subprocess.check_output(['git','archive','--format=tar',rev,'--',prefix+'02_parts',prefix+'03_src',prefix+'03_tscircuit'],cwd=R,timeout=60)
 with tarfile.open(fileobj=io.BytesIO(payload)) as tar:
  for m in tar:
   if m.isfile() and m.name.startswith(prefix):
    n=m.name[len(prefix):]
    if selected(n):put(side,n,tar.extractfile(m).read())
archive=P/'01_docs/journal/8e73749f81ce3605f5275f2d5077e01fb009662019720596dbed4d86a4339cb9.tar.gz'
raw=['03_tscircuit/build/circuit.json','03_tscircuit/build/schematic.pdf','04_kicad/crow_audio_carrier_v1.kicad_sch','06_build/netlists/crow_audio_carrier_v1.net']
with tarfile.open(archive) as t:
 manifest=json.loads(t.extractfile('MANIFEST.json').read())['members']
 for n in raw:
  b=t.extractfile(n).read();assert hashlib.sha256(b).hexdigest()==manifest[n]['sha256'];put('previous',n,b);put('current',n,(P/n).read_bytes())
 for n in ['08_reviews/pre-route_topology.md','08_reviews/pre-route_schematic_render.md']:put('prior-accepted',Path(n).name,t.extractfile(n).read())
for side,root in [('previous',OLD/'current'),('current',P)]:
 n='06_build/netlists/net_aliases.txt'
 if (root/n).is_file():put(side,n,(root/n).read_bytes())
for folder in ['authority','external_hardware','method']:
 shutil.copytree(OLD/folder,D/folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
shutil.copyfile(OLD/'preflight.py',D/'preflight.py')
for n in ['CLAUDE.md','skills/kicad-pcb/scripts/pre_route_review_check.py','skills/jlcpcb-fab/scripts/assembly_locator_check.py','skills/jlcpcb-fab/references/assembly-and-order.md']:
 put('authority',n,(R/n).read_bytes())
put('source-witnesses','locator-implementation-review.md',Path('/tmp/carrier-locator-implementation-review-3q8eb88j/06_build/task_runs/locator-implementation-review/outputs/report.md').read_bytes())
put('source-witnesses','caption-locator-side-review.md',Path('/tmp/carrier-locator-engineering-review-9dzo4mat/06_build/task_runs/locator-engineering-review/outputs/report.md').read_bytes())
def inventory(side):return {p.relative_to(D/side).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (D/side).rglob('*') if p.is_file()}
a,b=inventory('previous'),inventory('current');changes=[{'path':n,'previous_sha256':a.get(n),'current_sha256':b.get(n)} for n in sorted(a.keys()|b.keys()) if a.get(n)!=b.get(n)];(D/'changes.json').write_text(json.dumps(changes,indent=2)+'\n')
sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'));import pre_route_review_check as g
parts=sorted((P/'02_parts').glob('*/part.yaml'));bindings={'source_commit':head,'previous_source_commit':prev,'netlist_sha256':g.netlist_digest(P/raw[-1]),'parts_sha256':hashlib.sha256(b''.join(p.relative_to(P).as_posix().encode()+b'\0'+p.read_bytes()+b'\0' for p in parts)).hexdigest(),'design_rules_sha256':g.design_rules_digest(P),'packet_counts':{'previous':len(a),'current':len(b),'changed':len(changes)}};(D/'bindings.json').write_text(json.dumps(bindings,indent=2)+'\n');(C/'locator-schematic-delta-prepared.json').write_text(json.dumps({'root':str(D),'bindings':bindings},indent=2)+'\n');print(json.dumps({'root':str(D),'bindings':bindings},indent=2))
