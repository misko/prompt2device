# Recorded canonical attempt

- qualify: rc=0, 17.073569s; full raw output execution.log
- normal: rc=2, 95.227132s; full raw output execution.log
- public-continuation: rc=1, 4.042502s; full raw output execution.log
- Authored input hashes: 581/581
- All generated identities are in execution.json.
- Stop at the last actual recorded gate. No routing or release acceptance.
