from pathlib import Path
from datetime import datetime,timezone
import sys,json,hashlib,re,os
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
from pipeline_artifacts import validate_task_outputs
E=json.loads(Path(sys.argv[1]).read_text());packet=Path(__file__).parent;O=Path(sys.argv[1]).parent/'outputs';S=Path(sys.argv[1]).parent/'scratch';source=json.loads((packet/'source-manifest.json').read_text());checked=0
for row in E['input_packet']:
 p=P/row['path'];b=p.read_bytes();assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256'],str(p);checked+=1
for rel,row in source.items():
 p=R/rel;b=p.read_bytes();assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256'],rel
start={'verified_at':datetime.now(timezone.utc).isoformat(),'packet_files':checked,'source_files':len(source),'source_manifest_sha256':hashlib.sha256((packet/'source-manifest.json').read_bytes()).hexdigest()};(S/'input-verification.json').write_text(json.dumps(start,indent=2)+'\n')
records=[];logs=[]
for stage,resume,limit in [('placement_after_current_readability','--resume-after-schematic-review',600)]:
 if resume and records:
  previous=logs[-1]
  if records[-1]['returncode']!=2 or 'GATE INCOMPLETE [1c] J-PCBA-PRELAYOUT:' not in previous:break
 argv=['/usr/bin/python3',str(R/'skills/kicad-pcb/scripts/pcb_flow.py'),'run',str(P),'--stage',stage,'--budget-s',str(limit),'--timeout-s',str(limit),'--','bash',str(P/'03_src/rebuild_all.sh')]+([resume] if resume else [])
 end=datetime.fromisoformat(E['deadline_at'].replace('Z','+00:00'));remaining=(end-datetime.now(timezone.utc)).total_seconds()-120
 assert remaining>limit+15,'Insufficient time for next admitted command and close buffer'
 print('START',stage,flush=True)
 v=run_stage({'id':stage+'_outer','work_class':'local','timeout_s':limit+15},argv,cwd=R,log_path=S/(stage+'.log'),console_line_limit=4,console_tail_lines=2,env={'PATH':os.environ['PATH'],'HOME':os.environ['HOME'],'LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'}).to_mapping();records.append(v|{'argv':argv});logs.append((S/(stage+'.log')).read_text());print('FINISHED',stage,v['returncode'],flush=True)
changes=[];source_changes=[]
for rel,row in source.items():
 p=R/rel;after={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size} if p.is_file() else None
 if after!=row:
  change={'path':rel,'before':row,'after':after};changes.append(change)
  if not any(rel.startswith('projects/crow-audio-carrier-v1/'+prefix) for prefix in ('03_tscircuit/build/','03_tscircuit/dist/','03_tscircuit/kicad/','04_kicad/')):source_changes.append(change)
assert not source_changes,source_changes
(O/'changes.json').write_text(json.dumps({'source_unchanged':True,'source_files_verified':len(source),'changed_files':changes},indent=2)+'\n')
(O/'process.json').write_text(json.dumps({'input_verification':start,'commands':records},indent=2)+'\n')
(O/'conductor.log').write_text(''.join('\n=== '+r['stage_id']+' ===\n'+log for r,log in zip(records,logs)))
gates=[line for log in logs for line in log.splitlines() if line.startswith(('GATE FAILED','GATE INCOMPLETE','PRELAYOUT-RESUME PASS','PRELAYOUT-INPUT PASS','CHECKPOINT PASS'))]
(O/'report.md').write_text('# Post-review mechanical placement execution\n\nMEASURED packet '+str(checked)+'/'+str(checked)+', source '+str(len(source))+'/'+str(len(source))+' exact before execution. Authored source unchanged.\n\n'+ '\n'.join('- '+r['stage_id']+': rc'+str(r['returncode'])+', '+str(r['elapsed_s'])+' seconds.' for r in records)+'\n\n```text\n'+'\n'.join(gates)+'\n```\n\nDomain stop remains as printed; mechanical execution does not adopt placement, routing, release or order acceptance. Child processes returned through bounded cleanup.\n')
(O/'result.json').write_text(json.dumps({'subject':E['subject'],'checks':{'execution-recorded':'PASS','inputs-verified':'PASS','processes-closed':'PASS'},'unresolved':[]},indent=2)+'\n')
v=validate_task_outputs(O,E['completion']['outputs'],subject=E['subject'],checks=E['completion']['checks'])
(S/'delivery-preflight.json').write_text(json.dumps(v,indent=2)+'\n')
print('DELIVERED',str(O),flush=True)
