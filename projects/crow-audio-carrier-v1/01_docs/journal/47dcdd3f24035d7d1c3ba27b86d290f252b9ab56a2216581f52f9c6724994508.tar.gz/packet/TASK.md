# Fresh mechanical placement continuation

Agent-role mechanical, economy/low effort. Fresh context; no child agents. Source 5cf0db3e118ba4d188e38edebb2f565ad1445024.
Root transfers exclusive live project writing for this one run and remains READ_ONLY.
Read this task, allocated envelope, copied beacon and compact handoff, schematic
handoff tail, CLAUDE and execution runtime. Verify packet/source manifest through
the frozen driver. The current schematic review is accepted; do not re-review it.
Native startup qualification4/4PASS is included, separate from review authority.

Execute exactly once:
/usr/bin/python3 /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/tmp/placement-after-correction-20260911T154233Z/driver.py <allocated-envelope>

The driver runs normal rebuild_all.sh --resume-after-schematic-review with a
600-second inner bound and 615-second outer bound, preserving full logs and
checking authored sources unchanged. Stop at the first missing/failed gate.
No retries, repairs, fresh source edits, models, routing, approvals, review
adoption, commits, or journal/status changes. Do not bypass a check. Generated
03_tscircuit/build,dist,kicad,node_modules,04_kicad,06_build are the only normal
conductor write scope. Do not hand-edit any generated artifact.

Work/final cutoff 2026-09-11T15:55:33.434729+00:00, hard rootclose 2026-09-11T15:57:33.434729+00:00.
The driver reserves closure time and validates ACTUAL final outputs before
return. If it fails, return the real error and partial artifacts; do not invent
a second attempt. Exactly conductor.log, process.json, changes.json, report.md,
result.json are required in allocated outputs. Domain FAIL can be a complete
measurement, but is never placement or release acceptance. Processes must be
closed before actual FINAL. Return immediately when the driver ends.
