from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib, json, shutil, subprocess, sys
R = Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
P = R / 'projects/crow-audio-carrier-v1'
sys.path.insert(0, str(R / 'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import subject_identity, TypedIdentityInput
from pipeline_runtime import open_agent_attempt
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True, timeout=30).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=R, text=True, timeout=30).strip()
now = datetime.now(timezone.utc)
rid = 'placement-after-correction-' + now.strftime('%Y%m%dT%H%M%SZ')
D = P / '06_build/tmp' / rid
D.mkdir(parents=True, exist_ok=False)
for rel in ['CLAUDE.md', 'skills/pcb-design/SKILL.md', 'skills/pcb-design/references/execution-runtime.md', 'skills/pcb-design/references/compute-tiers.md', 'skills/pcb-design/references/lifecycle-and-backtrack.md', 'skills/pcb-design/references/execution-graph.md']:
    q = D / rel
    q.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(R / rel, q)
for rel in ['01_docs/STATUS.md', '06_build/agent_handoff.yaml', '03_src/rebuild_all.sh', '08_reviews/pre-route_schematic_render.md', '06_build/task_runs/qualify-98da241ced304529ae35696df1dd9208/qualification.json']:
    q = D / rel
    q.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(P / rel, q)
# A bounded journal tail, never the multi-megabyte canonical journal.
(D / 'schematic-handoff.md').write_text('\n'.join((P / '01_docs/journal/schematic.md').read_text().splitlines()[-45:]) + '\n')
shutil.copyfile('/tmp/carrier_placement_driver_ready.py', D / 'driver.py')
source = {}
paths = subprocess.check_output(['git', 'ls-files', 'skills', 'external_hardware', *['projects/crow-audio-carrier-v1/' + top for top in ['03_src', '02_parts', '03_tscircuit', '01_docs', '04_kicad', '08_reviews']]], cwd=R, text=True, timeout=30).splitlines()
for rel in paths:
    b = (R / rel).read_bytes()
    source[rel] = {'sha256': hashlib.sha256(b).hexdigest(), 'size': len(b)}
(D / 'source-manifest.json').write_text(json.dumps(source, indent=2) + '\n')
cutoff, deadline = now + timedelta(minutes=13), now + timedelta(minutes=15)
(D / 'TASK.md').write_text(f'''# Fresh mechanical placement continuation

Agent-role mechanical, economy/low effort. Fresh context; no child agents. Source {head}.
Root transfers exclusive live project writing for this one run and remains READ_ONLY.
Read this task, allocated envelope, copied beacon and compact handoff, schematic
handoff tail, CLAUDE and execution runtime. Verify packet/source manifest through
the frozen driver. The current schematic review is accepted; do not re-review it.
Native startup qualification4/4PASS is included, separate from review authority.

Execute exactly once:
/usr/bin/python3 {D}/driver.py <allocated-envelope>

The driver runs normal rebuild_all.sh --resume-after-schematic-review with a
600-second inner bound and 615-second outer bound, preserving full logs and
checking authored sources unchanged. Stop at the first missing/failed gate.
No retries, repairs, fresh source edits, models, routing, approvals, review
adoption, commits, or journal/status changes. Do not bypass a check. Generated
03_tscircuit/build,dist,kicad,node_modules,04_kicad,06_build are the only normal
conductor write scope. Do not hand-edit any generated artifact.

Work/final cutoff {cutoff.isoformat()}, hard rootclose {deadline.isoformat()}.
The driver reserves closure time and validates ACTUAL final outputs before
return. If it fails, return the real error and partial artifacts; do not invent
a second attempt. Exactly conductor.log, process.json, changes.json, report.md,
result.json are required in allocated outputs. Domain FAIL can be a complete
measurement, but is never placement or release acceptance. Processes must be
closed before actual FINAL. Return immediately when the driver ends.
''')
items = []
for i, p in enumerate(sorted(x for x in D.rglob('*') if x.is_file())):
    b = p.read_bytes()
    items.append({'name': f'input_{i:04d}', 'path': str(p.relative_to(P)), 'size': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
subject = subject_identity('placement_continuation', 1, [TypedIdentityInput('packet', 'sequence', items, json.dumps(items, sort_keys=True).encode())])
e = TaskEnvelope(schema=2, task_id=rid, stage_id='KICAD-PLACEMENT', run_id=rid,
    subject=subject, executor='agent', execution_class='local',
    recommended_agent_role='mechanical', agent_role='mechanical', role_escalation_reason=None,
    context_mode='FRESH', input_handoff_id=rid, input_packet=items,
    deadline_at=deadline.isoformat().replace('+00:00', 'Z'),
    max_nonimproving_attempts=1, replacement_limit=0,
    writer_scope={'mode':'EXCLUSIVE','paths':['03_tscircuit/build','03_tscircuit/dist','03_tscircuit/kicad','03_tscircuit/node_modules','04_kicad','06_build']},
    output_path=f'06_build/task_runs/{rid}/attempt.json',
    completion={'checks':['execution-recorded','inputs-verified','processes-closed'], 'outputs':['changes.json','conductor.log','process.json','report.md']})
o = open_agent_attempt(e, cwd=P)
o.update(project=str(P), envelope=str((P / e.output_path).parent / 'envelope.json'), packet=str(D), work_cutoff=cutoff.isoformat())
Path('/tmp/carrier-placement-ready-opened.json').write_text(json.dumps(o, indent=2) + '\n')
print(json.dumps(o, indent=2))
