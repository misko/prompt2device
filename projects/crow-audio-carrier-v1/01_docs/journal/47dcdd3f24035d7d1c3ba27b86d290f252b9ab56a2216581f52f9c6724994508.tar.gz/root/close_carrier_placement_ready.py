from pathlib import Path
import sys,json
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_runtime import close_agent_attempt
j=json.loads(Path('/tmp/carrier-placement-ready-opened.json').read_text());P=Path(j['project']);e=TaskEnvelope.from_json(Path(j['envelope']).read_text());state=sys.argv[1];assert state in ('completed','error','unknown')
r=close_agent_attempt(e,cwd=P,event={'host':'collaboration','agent_id':'/root/carrier_placement_after_correction','state':state,'envelope_sha256':j['envelope_sha256'],'cleanup':'confirmed' if state=='completed' else 'unknown','detail':'Root observed real host final and completed bounded review handback; engineering adoption separate.' if state=='completed' else 'Review did not deliver within its original boundary.'});print(r.status,r.unresolved)
