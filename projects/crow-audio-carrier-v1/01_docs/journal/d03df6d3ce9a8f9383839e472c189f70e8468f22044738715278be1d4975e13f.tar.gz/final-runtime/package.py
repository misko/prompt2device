from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,io
S=Path(__file__).parent;O=S.parent/'outputs';R=S.parents[3]
h=lambda b:hashlib.sha256(b).hexdigest()
e=json.loads((S.parent/'envelope.json').read_text());hashes=json.loads((S/'hashes.json').read_text());audit=json.loads((S/'finalaudit.json').read_text())
report='''review_stage: pre-route
review_kind: schematic_render
reviewer_identity: Codex /root/carrier_rj45_native_carrier_readability_orientation1
context: FRESH
date: 2026-09-13
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
'''+''.join(f'{k}: {v}\n' for k,v in hashes.items())+'''
Fresh independent readability review is complete for these exact frozen carrier bytes. No actionable schematic readability defect was found.

MEASURED: 748/748 frozen inputs verified before and after; canonical envelope cce09ebb06970fb433bab3203cb81f950735c22d2c636875024daf9c11f2421a verified; seven subject hashes recomputed with the frozen owning algorithm, including 89 part dossiers. Independent Poppler rendering at 120 dpi proves 19/19 current PDF bodies are RGB-byte-identical to the immediately accepted model1 PDF below y=100 pixels. Every full-page difference is confined to the generated identity-caption band y=83..97; there are zero changed drawing bodies. Current and accepted per-page body hashes and difference bounding boxes are archived.

I opened and visually inspected all 19 current full-resolution page images, including all headers and the integrated power, eight-channel analog, ADC/reference, clock/TDM and reset paths. All headers have the current CircuitJSON prefix c445cd23af2f1edb, correct page numbers and counts summing to333. Independent PDF text extraction also finds333/333 native component references; extraction supplements the actual image inspection. All eight ten-contact RJ45 symbols have distinguishable pin numbers and labels: power1/3/7, return2/6/8, audio+5, audio-4, shell9/10. Green conductors, junctions, power labels, CHASSIS versus GND, capacitor/diode polarity, filter-shunt labels and NC stubs remain readable. Current input fuse, PFET and clamp, held-supply/LDO, inverting enable/dump, channel isolation, independent VMID/reference banks and noninverting TDM conditioning are traceable.

Native/source coverage: independent complete S-expression parsing finds accepted/current333 components with identical values/footprints,985 pin mappings and221 nets including42 NC nets. Each census has zero additions, removals and changed rows. The entire native schematic is identical after UUID-string substitution only. All80 RJ45 pin/net assertions pass; CHASSIS contains the16 shell contacts and is distinct from GND. Independent CircuitJSON trace unioning matches943/943 connected source ports to native nets after the explicit authored N() prefix transform for names beginning in a digit. The hand-authored manifest, CircuitJSON, native graph and first-power card all contain exactly333 component references.

Source renewal: all310 common supplied part/source files are byte-identical to accepted-subject, including both authored TSX files, floorplan, route/rules and electrical/rating/first-article policy. The current manifest is additionally supplied without an accepted counterpart; this packet difference is not evidence of a design addition. CircuitJSON electrical, schematic, PCB and CAD record groups remain exactly equal. Changes are confined to source filesystem metadata and supplier diagnostics: source_part_not_found_warning55 versus43; supplier_footprint_mismatch_warning145 versus152. Exact netlist export metadata and schematic UUIDs changed, while normalized topology and seven current subject identities are freshly verified. The shared orientation checker/source renewal is identified by the supplied accepted seven-file adoption receipt; it is not an electrical or placement acceptance from this lens. No voltage/current limit increases: supplied policy and dossier bytes are unchanged.

Fresh maintained E-INV is205/205. Frozen ERC is0 errors/2637 warnings:569 lib_symbol_issues and2068 endpoint_off_grid; all four ignored check classes remain preserved in the archived census. Zero errors is not all-severity clean. Prior unchanged native S-OCCL/S-WNET evidence is available in the exact accepted model1 readability receipt; it was not rerun or restamped here. There were no unresolved readability findings in that accepted receipt; current all-page inspection and measured equivalence independently support this verdict.

Boundaries retained: carrier SOURCE PASS and authentic FULL INCOMPLETE with23 physical obligations were reopened. Pod9 obligations are commission context only; no pod population or schematic is graded by this carrier lens. Keep factory Cat6A custom analog/power RJ45, NOT Ethernet/PoE, power-off mating, and carrierCHASSIS/podPOD_SHIELD separate fromGND. FIRST-ARTICLE-ONLY / DO-NOT-ORDER persists. Catalog design-only admission and a blank operator response are not allocated stock or an order. No new physical-measurement prerequisite is imposed before prototype fabrication. LAYOUT001 closed3/3 remains commission context. No placement, routing, user orientation, physical testing, release or ordering acceptance follows.

Method limitations and resolved tooling diagnostics: pixel equality is measured at120 dpi, alongside actual visual inspection. An initial literal CircuitJSON/native name comparison rejected157 author-prefixed numeric net labels; the authored N() function explains every difference, and the narrowly corrected independent comparison passes943/943. Its failed log and unaccepted diagnostic output are retained explicitly; the diagnostic output's unconditional empty summary is not accepted evidence. A supplementary font read initially assumed page-local definitions; Poppler shares definitions across pages, and the complete-table read resolved it. Both original failures and corrected PASS runtime records are retained; neither failure altered an input or exposed a design defect. No font-floor claim relies on the exploratory integer font-size census.

The five-file handback binds methods, raw logs, completed bounded-runtime records, all38 current/accepted page images, independent graph and source comparisons, current/accepted provenance and input verification. Delivery completeness is separate from the design verdict. The provided preflight follows packaging.
'''
(O/'report.md').write_text(report)
methods=['Poppler pdftoppm direct argv under pipeline_runtime.run_stage, 120dpi current and immediately accepted PDF; RGB all-page comparison excludes only identified identity-header rows y<100.','Host view_image inspection of each current page1 through19 at native saved resolution.','Frozen pre_route_review_check.py netlist, parts and design-rule hashing plus exact artifact SHA256.','Independent complete native S-expression parser; components/values/footprints, pins and nets compared without UUID/export metadata.','CircuitJSON complete record-type equality and independent trace-union source/native port mapping, with explicit inverse of authored numeric-net N() prefix.','Current manifest, native, CircuitJSON and first-power reference-set equality; PDF text reference and caption census.','Maintained electrical_invariants.py run read-only under shared bounded runtime; source identity retained.','Reopen immutable phase/ERC receipts; retain design/order boundary and exact accepted provenance.']
ev={'schema':1,'review_stage':'pre-route','review_kind':'schematic_render','reviewer_identity':'Codex /root/carrier_rj45_native_carrier_readability_orientation1','context':'FRESH','design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','subject':e['subject'],'envelope_sha256':audit['canonical_envelope_sha256'],'subject_hashes':hashes,'methods':methods,'counts':{'inputs_before':748,'inputs_after':748,'subject_hashes':7,'part_dossiers':89,'common_source_files_equal':310,'pdf_pages':19,'body_equal_pages':19,'changed_body_pages':0,'current_pages_visually_opened':19,'native_components':333,'native_pins':985,'native_nets':221,'nc_nets':42,'source_native_connected_pin_matches':943,'rj45_pin_matches':80,'first_power_refs':333,'manifest_refs':333,'pdf_component_refs':333,'electrical_invariants_passed':205,'erc_errors':0,'erc_warnings':2637},'findings':[],'limitations':['120dpi pixel equality; actual full-page image review also completed.','No pod, placement, routing, orientation-user-approval, physical, release or order acceptance.','23 carrier physical obligations remain; pod9 is supplied context only.','Exploratory literal alias and font-table diagnostics corrected with original logs retained; unaccepted diagnostic JSON is explicitly non-authoritative.'],'evidence_files':['pixel-equivalence.json','graph-comparison.json','source-comparison.json','circuitjson-comparison.json','fidelity.json','supplement.json','finalaudit.json','inputs-before.json','inputs-after.json'],'accepted_provenance':{'pdf_path':'accepted-subject/03_tscircuit/build/schematic.pdf','pdf_sha256':'196ed44ad2656142ab311470434ddc6b672da5f8a70bf50d0216660f62b96b81','readability_report_sha256':h((R/'accepted-receipts/readability/report.md').read_bytes())}}
(O/'evidence.json').write_text(json.dumps(ev,indent=2)+'\n')
# Freeze only completed engineering runtime logs; this packaging stage is not an engineering measurement.
files={f'evidence/{p.name}':p.read_bytes() for p in sorted(S.iterdir()) if p.is_file() and p.name not in ['package.log','package.runtime.json']}
for p in [R/'TASK.md',R/'expected-subject.json',S.parent/'envelope.json',R/'accepted-receipts/readability/report.md',R/'accepted-receipts/readability/evidence-manifest.json',R/'decision-context/orientation-integrity-source-adoption.json']:
 files['provenance/'+str(p.relative_to(R))]=p.read_bytes()
files['review/report.md']=(O/'report.md').read_bytes();files['review/evidence.json']=(O/'evidence.json').read_bytes()
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,data in sorted(files.items()):
  ti=tarfile.TarInfo(name);ti.size=len(data);ti.mode=0o644;ti.mtime=0;t.addfile(ti,io.BytesIO(data))
manifest=[]
with tarfile.open(archive,'r:gz') as t:
 seen=set()
 for m in t.getmembers():
  assert m.isfile() and m.name not in seen and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts and not m.name.endswith('.tar.gz')
  seen.add(m.name);f=t.extractfile(m);data=f.read();assert data==files[m.name] and len(data)==m.size
  manifest.append({'path':m.name,'size':m.size,'sha256':h(data)})
 assert seen==set(files)
(O/'evidence-manifest.json').write_text(json.dumps({'archive_sha256':h(archive.read_bytes()),'archive_size':archive.stat().st_size,'member_count':len(manifest),'members':manifest},indent=2)+'\n')
(O/'result.json').write_text(json.dumps({'subject':e['subject'],'checks':{k:'PASS' for k in e['completion']['checks']},'unresolved':[]},indent=2)+'\n')
print('packaged',len(manifest),'members',archive.stat().st_size,'bytes','archive sha256',h(archive.read_bytes()))
assert sorted(p.name for p in O.iterdir())==['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md','result.json']
