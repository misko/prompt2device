review_stage: pre-route
review_kind: pin
reviewer: Independent part-group reviewers listed below; root compiles exact completed reports
context: Thirteen original independent pin contexts; five explicitly continued with requested facts
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

# Current carrier pin-review collection

All61 commissioned critical references across13 part groups PASS. Native dossiers contain441 numbered pad identities plus3 explicit fused physical aliases. This collection is limited to independent pin/package and function/net sanity; it does not accept full-board layout, routed performance, physical qualification or ordering. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.

Five original QUESTION reports remain immutable. The same independent reviewers resolved only their requested context in new reports: ADC straps, reset timing endpoints, FET clamp polarity, header locating/mating assignments, and declared ESD normal signal limits. Continued contexts and inherited physical proofs are explicit; authored operating facts are not physical measurements. The ESD RMS conversion is explicitly sine-equivalent, not an arbitrary waveform peak bound. Cable continuity/fit, transient survival and existing first-article obligations remain held. No source or native PCB changed to resolve these pin questions.

- rj45-pin-carrier-amplifiers-mountedframe1: refs U_AFE1,U_AFE2,U_AFE3,U_AFE4,U_AFE5,U_AFE6,U_AFE7,U_AFE8; report SHA256 1d9e1785ba99ef0799de0a4a2b6cc22291ac41e310fc3d5041d80576659809c7; durable archive ../01_docs/journal/c3c12c9b8f16e8bb66db4b3470dab47680789cae6e0204ac12364d2b4ca5703e.tar.gz
- rj45-pin-carrier-clock-reset-context1: refs U_CLK,U_RST1,U_RST2; report SHA256 c9c52ffed8422a92a99f5c5e152e6f5d003bd5043a8efc0529f6a06f0476820a; durable archive ../01_docs/journal/c6cb1f32110b5327168a03f24f5fde9295f6b698528e8a844fc309e5af2f9fb0.tar.gz
- rj45-pin-carrier-control-fets-mountedframe1: refs Q_DUMP,Q_PRE_EN,Q_RST1; report SHA256 9275e17197355a6430f37b3290d86a803eb4bb20538087d4a288074b64290dd3; durable archive ../01_docs/journal/87f93990a4807796feb2981f950dde29e9e78b7382f2904e141bde57261b41ac.tar.gz
- rj45-pin-carrier-conversion-context1: refs U_ADC,U_LDO; report SHA256 b35a5085affd2e5abc177b7e62056296f7faa5a6dcd2a91327ff4b5518c3b749; durable archive ../01_docs/journal/cff944b5fc36ca7d343b659febf97d21d4c8860c63938e557eddadda34962b0a.tar.gz
- rj45-pin-carrier-esd-context1: refs U_ESD1,U_ESD2,U_ESD3,U_ESD4,U_ESD5,U_ESD6,U_ESD7,U_ESD8; report SHA256 7c49d4ffd42b00502cb0fdad41ed57994224ce1b8e360a387cc4a89b56e53429; durable archive ../01_docs/journal/49883b361f53fdb045064347db29b78332f0beaee39c5035313ad5396bbbad15.tar.gz
- rj45-pin-carrier-headers-context1: refs J10,J11,J9; report SHA256 09778de6274bedd7f9faab872f5ab84d4e47727e6b6161aabfa06eed1549f874; durable archive ../01_docs/journal/6c0f013c33191d169a5a192e4fb3ee4f674b12788e2e5e6a5be5f25b5c9c1964.tar.gz
- rj45-pin-carrier-jacks-mountedframe1: refs J1,J2,J3,J4,J5,J6,J7,J8; report SHA256 e6524baed622d41100d1ded15440bdbc61f7b952bad0af4826cab4730f67dd76; durable archive ../01_docs/journal/32cafe429f370bbdf29bd2884601d09442ad15204972797b0b2da0c67adc9d07.tar.gz
- rj45-pin-carrier-logic-mountedframe1: refs U_DUMP,U_LDO_EN,U_OE,U_TDM,U_TDM_SCH; report SHA256 c456234c3cd1c0438b1046e2f2a05caa0aa0b891f1d14cd563e4ff9ef22de4e9; durable archive ../01_docs/journal/399dc5a49dd8d673f293a930af4de0fd23b9966db6346115f256b5445ba9e6c1.tar.gz
- rj45-pin-carrier-power-fets-mountedframe1: refs Q_IN,Q_PRE; report SHA256 90734e431c92def5ab5d4b1097eb7313c8680aec0032b7ffe9ce8a7491030402; durable archive ../01_docs/journal/042a170caa95c02883534fc81f7ff4102cecdab56b17769b64847a2c428da9c3.tar.gz
- rj45-pin-carrier-rectifiers-mountedframe1: refs C_FILT1_470U,C_FILT2_470U,C_HOLD1,C_HOLD2,D_BUCK_IN,D_HOLD; report SHA256 0de8c968238a94e6435faafd1cd6b3d2780fd4b6dfaa6786710d87ff1a6680f2; durable archive ../01_docs/journal/5c790822f51f01c9e0646841e2e732234831e075809cefd8170c78b74ec162d5.tar.gz
- rj45-pin-carrier-supply-mountedframe1: refs U_AUDIO,U_BUCK,U_PWR; report SHA256 99d408a9e8bab25536b0b8b34dd4725ef2f49d5cba0856e49d321ef0818e5b31; durable archive ../01_docs/journal/b78cb9d83a8c015e2c169678d26deefa37715a22c465c55b057ded3dba5afccc.tar.gz
- rj45-pin-carrier-switches-mountedframe1: refs U_ISO1,U_ISO2,U_ISO3,U_ISO4,U_ISO5,U_ISO6,U_ISO7,U_ISO8; report SHA256 5e09c96ffac391f5e5d8131ab69533fc3f3c95564da55f82396f858518bfff54; durable archive ../01_docs/journal/1ef464a8c480732ab26f4e81fdb6cd40d9a15a7cb8cb1c431cafc44a8b7c59ee.tar.gz
- rj45-pin-carrier-tvs-context1: refs D_IN,D_QIN_GS; report SHA256 c0ce4f24a16743dbee915695e4708ba8f1cc3ed7ae0d2ab64550d09f92c014b8; durable archive ../01_docs/journal/fb4613f80f17f2b91f256cb768cab7cfbe6de3aa786f9ba5425cc494ce962cf8.tar.gz

## Verbatim independent report — rj45-pin-carrier-amplifiers-mountedframe1

review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_amplifiers_mountedframe1 (fresh independent agent)
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

# Independent amplifier pin review

Coverage is limited to U_AFE1 through U_AFE8 (OPA2320AIDR). All eight refs PASS; no whole-board acceptance or order authorization is given. The three binding hashes above are immutable commission metadata, not independently reviewed board/parts/rules conclusions.

Envelope subject: `{"raw_sha256": "fb2946f834b451f07cad1ceed6ee590be0a92f9c37eb793e4afb7148291458fa", "semantic_sha256": "2bd2c04a450be50b9c14664e33a27821dd6d65a52fa909410cc7daabdb604957"}`.

## Primary source and independently derived expectations

Exact primary PDF: `projects/crow-audio-carrier-v1/02_parts/OPA2320AIDR/OPA2320_SBOS513F.pdf`; SHA-256 `1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc`; 2852198 bytes. Pages refer to one-based PDF pages.

Visually inspected p4, section 5, “OPA2320 D and DGK Packages / 8-Pin SOIC and VSSOP / Top View” and its pin-functions table before dossier comparison. The upper-left dot marks pin 1; left pins 1–4 descend and right pins 5–8 ascend, giving CCW top-view numbering, four pins per side. Pin functions are 1 OUTA, 2 −INA, 3 +INA, 4 V−, 5 +INB, 6 −INB, 7 OUTB, 8 V+. No NC or exposed pad applies to this D/SOIC package. The adjacent SON thermal-pad requirement does not apply.

Visually inspected p47 D0008A package outline and p48 example board layout (drawing 4214825/C, 02/2019). They agree on upper-left pin 1 and the 8-lead perimeter, with 1.27 mm pitch. The p32 package-option addendum explicitly identifies OPA2320AIDR as SOIC (D), 8 pins. P6 section 6.3 gives a 1.8–5.5 V recommended supply span, consistent with the nominal 3.3 V rail designation.

All dossiers explicitly say front (F.Cu), COMPONENT-TOP, +x right/+y down. They need no mounted-side reflection; manufacturer top view compares at zero relative rotation. U_AFE1–4 use native rotation 0° and U_AFE5–8 use 180°. Reconstructed native positions match every supplied coordinate exactly at displayed precision. Signed component-top perimeter area is −18.8595 mm² (CCW in a y-down frame).

The dossiers use 1.95 × 0.60 mm lands at x = ±2.475 mm and y = ±1.905, ±0.635 mm. These are eight separate lands with 1.27 mm lead pitch. TI p48 gives an example (1.55 × 0.60 mm lands at x = ±2.7 mm), not a mandatory identical land pattern; the dossier pad-size difference does not alter pin identity, winding or side. This review does not qualify solder-joint manufacturing performance.

## Per-ref verdicts and expected versus observed facts

### U_AFE1

VERDICT: PASS

Measured native dossier census: 8 pad records, 8 unique pad numbers, 8 unique native centers, 8 physical pin identities; expected 8. EP count 0; collapsed identities 0; no alias mapping is needed. Source: SHA-256 `1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc`, PDF p4 top-view pinout/functions, p47 D0008A outline, p48 layout; p32 exact orderable package and p6 supply span.

U_AFE1 pins 1–8 (package geometry): expected pin 1 upper-left, CCW, four pins on each side, no EP; observed pin 1 (−2.475, −1.905), CCW, pins 1–4 W and 5–8 E, no extra center pad. Front mount and 0° native rotation reconcile all coordinates without reflection.

U_AFE1 pin 1 (OUTA): expected output A; observed function `OUTA` on `OPA_P1` — PASS.
U_AFE1 pin 2 (-INA): expected inverting feedback A; observed function `-INA` on `FB_P1` — PASS.
U_AFE1 pin 3 (+INA): expected noninverting input A; observed function `+INA` on `AIN_P1` — PASS.
U_AFE1 pin 4 (V-): expected negative supply / ground; observed function `V-` on `GND` — PASS.
U_AFE1 pin 5 (+INB): expected noninverting input B; observed function `+INB` on `AIN_N1` — PASS.
U_AFE1 pin 6 (-INB): expected inverting feedback B; observed function `-INB` on `FB_N1` — PASS.
U_AFE1 pin 7 (OUTB): expected output B; observed function `OUTB` on `OPA_N1` — PASS.
U_AFE1 pin 8 (V+): expected positive supply; observed function `V+` on `3V3_ADC` — PASS.

### U_AFE2

VERDICT: PASS

Measured native dossier census: 8 pad records, 8 unique pad numbers, 8 unique native centers, 8 physical pin identities; expected 8. EP count 0; collapsed identities 0; no alias mapping is needed. Source: SHA-256 `1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc`, PDF p4 top-view pinout/functions, p47 D0008A outline, p48 layout; p32 exact orderable package and p6 supply span.

U_AFE2 pins 1–8 (package geometry): expected pin 1 upper-left, CCW, four pins on each side, no EP; observed pin 1 (−2.475, −1.905), CCW, pins 1–4 W and 5–8 E, no extra center pad. Front mount and 0° native rotation reconcile all coordinates without reflection.

U_AFE2 pin 1 (OUTA): expected output A; observed function `OUTA` on `OPA_P2` — PASS.
U_AFE2 pin 2 (-INA): expected inverting feedback A; observed function `-INA` on `FB_P2` — PASS.
U_AFE2 pin 3 (+INA): expected noninverting input A; observed function `+INA` on `AIN_P2` — PASS.
U_AFE2 pin 4 (V-): expected negative supply / ground; observed function `V-` on `GND` — PASS.
U_AFE2 pin 5 (+INB): expected noninverting input B; observed function `+INB` on `AIN_N2` — PASS.
U_AFE2 pin 6 (-INB): expected inverting feedback B; observed function `-INB` on `FB_N2` — PASS.
U_AFE2 pin 7 (OUTB): expected output B; observed function `OUTB` on `OPA_N2` — PASS.
U_AFE2 pin 8 (V+): expected positive supply; observed function `V+` on `3V3_ADC` — PASS.

### U_AFE3

VERDICT: PASS

Measured native dossier census: 8 pad records, 8 unique pad numbers, 8 unique native centers, 8 physical pin identities; expected 8. EP count 0; collapsed identities 0; no alias mapping is needed. Source: SHA-256 `1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc`, PDF p4 top-view pinout/functions, p47 D0008A outline, p48 layout; p32 exact orderable package and p6 supply span.

U_AFE3 pins 1–8 (package geometry): expected pin 1 upper-left, CCW, four pins on each side, no EP; observed pin 1 (−2.475, −1.905), CCW, pins 1–4 W and 5–8 E, no extra center pad. Front mount and 0° native rotation reconcile all coordinates without reflection.

U_AFE3 pin 1 (OUTA): expected output A; observed function `OUTA` on `OPA_P3` — PASS.
U_AFE3 pin 2 (-INA): expected inverting feedback A; observed function `-INA` on `FB_P3` — PASS.
U_AFE3 pin 3 (+INA): expected noninverting input A; observed function `+INA` on `AIN_P3` — PASS.
U_AFE3 pin 4 (V-): expected negative supply / ground; observed function `V-` on `GND` — PASS.
U_AFE3 pin 5 (+INB): expected noninverting input B; observed function `+INB` on `AIN_N3` — PASS.
U_AFE3 pin 6 (-INB): expected inverting feedback B; observed function `-INB` on `FB_N3` — PASS.
U_AFE3 pin 7 (OUTB): expected output B; observed function `OUTB` on `OPA_N3` — PASS.
U_AFE3 pin 8 (V+): expected positive supply; observed function `V+` on `3V3_ADC` — PASS.

### U_AFE4

VERDICT: PASS

Measured native dossier census: 8 pad records, 8 unique pad numbers, 8 unique native centers, 8 physical pin identities; expected 8. EP count 0; collapsed identities 0; no alias mapping is needed. Source: SHA-256 `1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc`, PDF p4 top-view pinout/functions, p47 D0008A outline, p48 layout; p32 exact orderable package and p6 supply span.

U_AFE4 pins 1–8 (package geometry): expected pin 1 upper-left, CCW, four pins on each side, no EP; observed pin 1 (−2.475, −1.905), CCW, pins 1–4 W and 5–8 E, no extra center pad. Front mount and 0° native rotation reconcile all coordinates without reflection.

U_AFE4 pin 1 (OUTA): expected output A; observed function `OUTA` on `OPA_P4` — PASS.
U_AFE4 pin 2 (-INA): expected inverting feedback A; observed function `-INA` on `FB_P4` — PASS.
U_AFE4 pin 3 (+INA): expected noninverting input A; observed function `+INA` on `AIN_P4` — PASS.
U_AFE4 pin 4 (V-): expected negative supply / ground; observed function `V-` on `GND` — PASS.
U_AFE4 pin 5 (+INB): expected noninverting input B; observed function `+INB` on `AIN_N4` — PASS.
U_AFE4 pin 6 (-INB): expected inverting feedback B; observed function `-INB` on `FB_N4` — PASS.
U_AFE4 pin 7 (OUTB): expected output B; observed function `OUTB` on `OPA_N4` — PASS.
U_AFE4 pin 8 (V+): expected positive supply; observed function `V+` on `3V3_ADC` — PASS.

### U_AFE5

VERDICT: PASS

Measured native dossier census: 8 pad records, 8 unique pad numbers, 8 unique native centers, 8 physical pin identities; expected 8. EP count 0; collapsed identities 0; no alias mapping is needed. Source: SHA-256 `1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc`, PDF p4 top-view pinout/functions, p47 D0008A outline, p48 layout; p32 exact orderable package and p6 supply span.

U_AFE5 pins 1–8 (package geometry): expected pin 1 upper-left, CCW, four pins on each side, no EP; observed pin 1 (−2.475, −1.905), CCW, pins 1–4 W and 5–8 E, no extra center pad. Front mount and 180° native rotation reconcile all coordinates without reflection.

U_AFE5 pin 1 (OUTA): expected output A; observed function `OUTA` on `OPA_P5` — PASS.
U_AFE5 pin 2 (-INA): expected inverting feedback A; observed function `-INA` on `FB_P5` — PASS.
U_AFE5 pin 3 (+INA): expected noninverting input A; observed function `+INA` on `AIN_P5` — PASS.
U_AFE5 pin 4 (V-): expected negative supply / ground; observed function `V-` on `GND` — PASS.
U_AFE5 pin 5 (+INB): expected noninverting input B; observed function `+INB` on `AIN_N5` — PASS.
U_AFE5 pin 6 (-INB): expected inverting feedback B; observed function `-INB` on `FB_N5` — PASS.
U_AFE5 pin 7 (OUTB): expected output B; observed function `OUTB` on `OPA_N5` — PASS.
U_AFE5 pin 8 (V+): expected positive supply; observed function `V+` on `3V3_ADC` — PASS.

### U_AFE6

VERDICT: PASS

Measured native dossier census: 8 pad records, 8 unique pad numbers, 8 unique native centers, 8 physical pin identities; expected 8. EP count 0; collapsed identities 0; no alias mapping is needed. Source: SHA-256 `1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc`, PDF p4 top-view pinout/functions, p47 D0008A outline, p48 layout; p32 exact orderable package and p6 supply span.

U_AFE6 pins 1–8 (package geometry): expected pin 1 upper-left, CCW, four pins on each side, no EP; observed pin 1 (−2.475, −1.905), CCW, pins 1–4 W and 5–8 E, no extra center pad. Front mount and 180° native rotation reconcile all coordinates without reflection.

U_AFE6 pin 1 (OUTA): expected output A; observed function `OUTA` on `OPA_P6` — PASS.
U_AFE6 pin 2 (-INA): expected inverting feedback A; observed function `-INA` on `FB_P6` — PASS.
U_AFE6 pin 3 (+INA): expected noninverting input A; observed function `+INA` on `AIN_P6` — PASS.
U_AFE6 pin 4 (V-): expected negative supply / ground; observed function `V-` on `GND` — PASS.
U_AFE6 pin 5 (+INB): expected noninverting input B; observed function `+INB` on `AIN_N6` — PASS.
U_AFE6 pin 6 (-INB): expected inverting feedback B; observed function `-INB` on `FB_N6` — PASS.
U_AFE6 pin 7 (OUTB): expected output B; observed function `OUTB` on `OPA_N6` — PASS.
U_AFE6 pin 8 (V+): expected positive supply; observed function `V+` on `3V3_ADC` — PASS.

### U_AFE7

VERDICT: PASS

Measured native dossier census: 8 pad records, 8 unique pad numbers, 8 unique native centers, 8 physical pin identities; expected 8. EP count 0; collapsed identities 0; no alias mapping is needed. Source: SHA-256 `1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc`, PDF p4 top-view pinout/functions, p47 D0008A outline, p48 layout; p32 exact orderable package and p6 supply span.

U_AFE7 pins 1–8 (package geometry): expected pin 1 upper-left, CCW, four pins on each side, no EP; observed pin 1 (−2.475, −1.905), CCW, pins 1–4 W and 5–8 E, no extra center pad. Front mount and 180° native rotation reconcile all coordinates without reflection.

U_AFE7 pin 1 (OUTA): expected output A; observed function `OUTA` on `OPA_P7` — PASS.
U_AFE7 pin 2 (-INA): expected inverting feedback A; observed function `-INA` on `FB_P7` — PASS.
U_AFE7 pin 3 (+INA): expected noninverting input A; observed function `+INA` on `AIN_P7` — PASS.
U_AFE7 pin 4 (V-): expected negative supply / ground; observed function `V-` on `GND` — PASS.
U_AFE7 pin 5 (+INB): expected noninverting input B; observed function `+INB` on `AIN_N7` — PASS.
U_AFE7 pin 6 (-INB): expected inverting feedback B; observed function `-INB` on `FB_N7` — PASS.
U_AFE7 pin 7 (OUTB): expected output B; observed function `OUTB` on `OPA_N7` — PASS.
U_AFE7 pin 8 (V+): expected positive supply; observed function `V+` on `3V3_ADC` — PASS.

### U_AFE8

VERDICT: PASS

Measured native dossier census: 8 pad records, 8 unique pad numbers, 8 unique native centers, 8 physical pin identities; expected 8. EP count 0; collapsed identities 0; no alias mapping is needed. Source: SHA-256 `1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc`, PDF p4 top-view pinout/functions, p47 D0008A outline, p48 layout; p32 exact orderable package and p6 supply span.

U_AFE8 pins 1–8 (package geometry): expected pin 1 upper-left, CCW, four pins on each side, no EP; observed pin 1 (−2.475, −1.905), CCW, pins 1–4 W and 5–8 E, no extra center pad. Front mount and 180° native rotation reconcile all coordinates without reflection.

U_AFE8 pin 1 (OUTA): expected output A; observed function `OUTA` on `OPA_P8` — PASS.
U_AFE8 pin 2 (-INA): expected inverting feedback A; observed function `-INA` on `FB_P8` — PASS.
U_AFE8 pin 3 (+INA): expected noninverting input A; observed function `+INA` on `AIN_P8` — PASS.
U_AFE8 pin 4 (V-): expected negative supply / ground; observed function `V-` on `GND` — PASS.
U_AFE8 pin 5 (+INB): expected noninverting input B; observed function `+INB` on `AIN_N8` — PASS.
U_AFE8 pin 6 (-INB): expected inverting feedback B; observed function `-INB` on `FB_N8` — PASS.
U_AFE8 pin 7 (OUTB): expected output B; observed function `OUTB` on `OPA_N8` — PASS.
U_AFE8 pin 8 (V+): expected positive supply; observed function `V+` on `3V3_ADC` — PASS.

## Symmetry and limits

All 8 instances have identical physical function mapping and net classes, differing only by channel index; refs 5..8 rotate 180 degrees without reflection.

Aggregate measured census: 8 refs, 64 native pad records and 64 distinct per-instance physical pin identities, 0 exposed pads, 0 collapsed identities; 8 PASS / 0 FAIL / 0 QUESTION. There are no unresolved pin-review findings. Net classification uses the supplied board net names; it establishes pin-level electrical sanity, not unprovided circuit topology, measured voltages, signal range or whole-board behavior.

## Methods and evidence

1. Verified SHA-256 and byte size of every envelope input before and after review using verify_input_packet.
2. Extracted exact PDF text only to locate relevant pages and supplement figure readings. Rendered PDF pages 4, 47 and 48 with pdftoppm at 110 DPI, inspected each with view_image, and saved independent-expectations.json before opening any dossier. Subsequently rendered and visually inspected pages 6 and 32 at 130 DPI for supply range and exact ordering/package selection.
3. Compared manufacturer top view directly against each COMPONENT-TOP dossier frame. All parts front-mounted; no reflection required or applied. Checked every native coordinate against board position and 0/180 degree rotation.
4. Manually checked all 64 per-pin function/net entries, then used measure.py to census rows, unique pad numbers and native centers, compute signed polygon area, and verify all coordinate transforms. Measurements are from supplied native dossiers, not a separate extraction of a live board.
5. Compared all eight instances for function/net-class symmetry. Evaluated basic pin-level net sanity; rail 3V3_ADC denotes nominal 3.3 V and GND denotes low supply. Dossiers do not establish actual rail voltage, circuit gain, feedback resistor topology, loading, signal amplitude or complete board behavior; these are outside this pin review.
6. Used finite direct-argv subprocess stages with explicit cwd/environment and pipeline_runtime.run_stage for review commands; retained commands/runtime and combined raw stdout/stderr, including failed rg launch and successful Python fallback. Initial task/runtime bootstrap reads used direct exec_command.
7. Packaged actual rendered pages, native dossiers, independent expectations, measurement source/results, review method source and runtime logs. Full primary PDF stays in digest-bound frozen packet.

The evidence archive includes the actual five inspected raster pages, all eight native dossiers, primary PDF digest binding, protocol, measurement script/results, command/runtime records and raw review logs. Packaging and final preflight receipts remain in allocated scratch because the archive cannot contain its own final digest or post-archive validation. Delivery checks signify complete honest handback, not permission to order.


## Verbatim independent report — rj45-pin-carrier-clock-reset-context1

review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_clock_reset_mountedframe1
context: CONTINUED-INDEPENDENT — original fresh pin reviewer plus narrowly requested native timing facts
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
release_scope: FIRST-ARTICLE-ONLY
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7
raw_sha256: b5390e268fbe6aae1c6473f5b3751257fccf22500ef5ae8c8447e1fe8535368c
semantic_sha256: e76082a564e654d65c2a0d2467dd0f112671cce2605be796ca8fa3121df6282e

All commissioned references U_CLK, U_RST1 and U_RST2 PASS the limited pre-route pin review. The new native timing endpoints resolve original Q1. This is not whole-board, route, manufacture, timing-performance or order acceptance. R_RST_T and C_RST_T are supporting facts, not an expansion of the commissioned group.

Continuation provenance: original task rj45-pin-carrier-clock-reset-mountedframe1 completed an independent fresh review with INCOMPLETE only for timing-network context. Its immutable report SHA-256 is 3f1c045fbe63df645d6c2d33a6dff1cfa60843b4b68a766e8d63e27781e059c2. Original evidence archive SHA-256 is 41da62400bcc59e2114d92cc92e0f22bc2af71276ffe0b8187e1c82b71bbb702; the supplied previous-closeout.json binds the later coordinator closeout archive b606a80f07722b6993e01ccc14be3e6c36eac3becf046e3baeb88627e208ca40. Original subject raw=47fabbbe2be37cf731bb0d35722ea44927020eaeca0471bf6e3f1f88e70e6820, semantic=d43e737695c86bd2850abd52fc7e0a30628ec85c28092ca217d62332819f0b32. The new envelope subject above binds the augmented review packet; the board/parts/rules bindings remain unchanged.

Inherited proof, explicitly not repeated: all original IC package figure observations, native physical identity counts, CCW winding, pin-1 positions, function assignments and symmetry checks. Original dossier hashes remain U_CLK=a83dc75f6f008611ee89ada8435e11938fea99d89e633442192ee611d5085a1a, U_RST1=5b4367a4fd57d59270f2babd4e832c1a475187c418be55f27f75f413252d3493, U_RST2=ab41a044054ea6e1c408c30addd3de59d24972b5f3a13a81b6819ecfb8d46e2c. Exact original IC primary PDF hashes also remain unchanged. Prior inspected PNGs, measurements and original findings are retained as clearly labeled inherited evidence. No old output was edited, and no live design source was read. Context is continued independent review, not a newly fresh agent, notwithstanding the envelope's generic context_mode field.

| Ref | Verdict | Native pads / physical identities | Expected versus observed package |
|---|---|---|---|
| U_CLK | PASS | 8 / 8 | DCU VSSOP, 4 leads per side, pin 1 upper-left, 1..4 down left and 5..8 up right, CCW, 0.5 mm pitch; matches |
| U_RST1 | PASS | 3 / 3 | DBZ SOT23-3, pins 1 upper-left/2 lower-left/3 center-right, CCW, 1.9 mm 1-to-2 spacing; matches |
| U_RST2 | PASS | 8 / 8 | DCT SSOP, 4 leads per side, pin 1 upper-left, 1..4 down left and 5..8 up right, CCW, 0.65 mm pitch; matches |

All three original ICs are front-mounted at native rotation 0, with component-top +x right/+y down; only translation was needed. Expected and observed EP counts are zero for each. No fused identities, aliases, missing pads or duplicate pad identities were found. Signed native component-top polygon areas are respectively -4.2, -1.78125 and -6.63 mm2, with zero coordinate conversion residual. Comparison used the selected manufacturer's TOP views without any mirror. U_RST1 dossier N/S side labels for pins 1/2 do not change their actual left-side coordinates.

U_CLK VERDICT: PASS
Primary TI SCES366L SHA-256 d541afbccf6270522f5ba33b86ca31da0ec6bbf497c0d1f8ba265e9ac2e1faec: inherited PDF p.3 DCU Top View/Pin Functions, p.19 DCU0008A outline.
Expected/observed pin functions and net kinds: 1=1A input/MCH_MCLK; 2=3Y output/FSYNC_BUF; 3=2A input/MCH_BCLK; 4=GND/GND; 5=2Y output/BCLK_BUF; 6=3A input/MCH_FSYNC; 7=1Y output/MCLK_BUF; 8=VCC/3V3_ADC. All PASS. Channel symmetry is preserved: 1->7 MCLK, 3->5 BCLK, 6->2 FSYNC.

U_RST1 VERDICT: PASS
Primary TI SBVS193D SHA-256 5f9a9581d1b8df7f0b2a480a71dac6993c9aba3b05767ad22641d151434f5dd3: inherited PDF p.5 TPS3839 DBZ Top View/Pin Functions, p.28 DBZ0003A outline.
Expected/observed: 1=ground/GND; 2=active-low push-pull RESET output/POR_N; 3=positive monitored VDD/3V3_ADC. All PASS.

U_RST2 VERDICT: PASS
Primary TI SCES586E SHA-256 7248ef0ff62af4d2da172bb2900f0f1f136a6ae90109a6485228e01269fa1c1d: inherited PDF p.3 Figure 4-1/Table 4-1, p.23 DCT0008A outline, p.13 Table 7-1; newly viewed PDF p.1 Description/Logic Diagram and p.14 Figure 8-1.
Expected/observed: 1=A held low/GND; 2=B held high/3V3_ADC; 3=active-low CLR/POR_N; 4=ground/GND; 5=positive Q pulse/RESET_PULSE_H; 6=Cext/RESET_C; 7=Rext/Cext/RESET_RC; 8=VCC/3V3_ADC. All PASS. Original proof established that rising CLR triggers the pulse with A low and B high. U_RST1.2 and U_RST2.3 share POR_N and the same power domain. There are no duplicate same-part instances within this group; all three buffer channels and reset-chain polarity were checked.

New Q1 resolution: C_RST_T.1=RESET_C=U_RST2.6; C_RST_T.2=RESET_RC=U_RST2.7=R_RST_T.2; R_RST_T.1=3V3_ADC=U_RST2.8. Thus the actual supplied passive endpoints implement Cext-to-Rext/Cext capacitance and Rext/Cext-to-VCC resistance. No conflicting attachment is present in the supplied timing network.
The primary requires the capacitor between IC pins 6 and 7, with pin 6 going only to the external capacitor, and the resistor from pin 7 to VCC. The supplied C_RST_T and R_RST_T endpoints establish these functional connections. This closes the original requested connection question, without making a pulse-duration or global net-census claim.

New supporting physical checks:
R_RST_T: 2 native pads / 2 distinct terminal identities, 0 EP, 0 fused aliases. Native front mount rotation 90 degrees maps local (-0.51,0)/(+0.51,0) mm to board (122.6,76.51)/(122.6,75.49) mm with zero residual. Pad 1 on 3V3_ADC, pad 2 on RESET_RC. Yageo exact RC0402FR-07100KL primary SHA-256 e42aa2b39be7476fef25efbe4656acbbc246d2b9b625d64db6b46e0f5e34d7af, PDF p.1 dimensional image and specifications: 0402 1.0 x 0.5 mm two-terminal 100 kohm resistor, 1%, nonpolar; mapping PASS.
C_RST_T: 2 native pads / 2 distinct terminal identities, 0 EP, 0 fused aliases. Native front mount rotation 90 degrees maps local (-0.775,0)/(+0.775,0) mm to board (122.6,73.975)/(122.6,72.425) mm with zero residual. Pad 1 on RESET_C, pad 2 on RESET_RC. Samsung exact CL10B224KA8NNNC primary SHA-256 00c61e295f03297000302fb2c7b2e5d5557edba7ca3dd0989e872718e9aa89c2, PDF p.1 Structure & Dimension: 0603 1.6 x 0.8 mm 220 nF/25 V X7R nonpolar MLCC, opposing end terminations; mapping PASS.
For these two-terminal, collinear passives, winding is not applicable. Their primary figures provide no polarity or unique pin-1 end; terminal interchange is valid, without collapsing either physical identity. No unsupported CW/CCW finding is applied. Author verification notes and capacitor derating assumptions in dossiers were not used as evidence.

Measured coverage: 19 original commissioned IC pads/19 identities inherited; 4 supporting passive pads/4 identities newly checked. Every augmented envelope input was verified before and after review. All four newly inspected primary PNGs and the inherited physical proof are archived. Archive regular members were reopened and SHA-256/size checked; final supplied preflight validates exact outputs, subject and unchanged writer scope. Delivery PASS means complete handback. The original INCOMPLETE remains immutable; this report resolves it only for the exact unchanged original inputs plus supplied new facts.


## Verbatim independent report — rj45-pin-carrier-control-fets-mountedframe1

review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_control_fets_mountedframe1 (actual fresh agent)
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

Limited coverage: Q_DUMP, Q_PRE_EN, Q_RST1 only. All commissioned instances PASS. This is a pre-route pin review, not whole-board acceptance or permission to order. The three immutable board/parts/rules hashes above are supplied metadata, not independent whole-board conclusions. Exact envelope subject: raw_sha256 baf61fd144636e9501c421cf98df3320e4b654477ac5dd8dbe9f662a9b1eeda8; semantic_sha256 9d07cd194850ea56dcf7a03831c97dbf6dab374b7a97cee52d6cbe83d158e05a.

Method and independent physical expectation

The actual primary PDF page images were rendered with pdftoppm and visually inspected with view_image before opening the native dossiers. The physical expectations were recorded in independent-before-dossiers.txt first. The dossiers' historical verification notes were not used as engineering evidence. Only the supplied protocol, exact primary PDFs, and native dossiers informed judgment; no schematic, live board, project history, or external source was consulted.

AO3400A Rev3.1 page 1, unnumbered SOT23 Top View/Bottom View and equivalent-circuit figures: the top-view white-dot corner is adjacent to G; S is the other paired lead, D the lone opposite lead. The bottom view is explicitly a different view and was not used for direct footprint comparison. 2N7002K DS30896 Rev20-2 page 1, unnumbered Top View and Equivalent Circuit: G is lower left, S lower right, D upper centre. Rotate this top-view drawing 90 degrees clockwise to obtain G upper left, S lower left, D middle right. The AO top view has the same functional handedness after planar rotation. Both devices have three discrete terminals; no EP and no fused physical identities. Diodes page 7 Package Outline Dimensions and Suggested Pad Layout independently show three lands and no EP.

The inspected figures label terminals G/S/D rather than printing numeric pin IDs. Consequently 1/2/3 below are dossier pad identifiers checked against independently derived physical G/S/D locations; no manufacturer numeric labels were invented. The physically relevant pin-1 position is the dossier's G pad at upper left (AO's marked G corner). The G->S->D cycle is CCW. No mirrored top-view comparison or extra mounting reflection was applied.

All three dossiers explicitly state front F.Cu mount and component-top +x right/+y down, translation/rotation undone. Rotation is zero; native positions minus each origin reproduce the component-top coordinates to 0.000001 mm. The three surviving positions are noncollinear, so winding is determinate. Numeric 1->2->3 signed areas in x-right/y-down coordinates are -1.781250 mm² for Q_DUMP and -1.900000 mm² for each Diodes device, consistent with CCW.

Q_DUMP — VERDICT: PASS

Primary: AO3400A_Rev3.1.pdf, SHA-256 9c60d0b6c1ddc7609a4b788a91181468d8ffe6c3e9ba425c3d8ffc5ba88c5033, PDF page 1 SOT23 Top View/Bottom View and equivalent-circuit figures.
Measured native dossier census: 3 pad rows, 3 unique pad numbers, 3 distinct native positions, 3 physical G/S/D identities, 0 EPs, 0 fused aliases. Each identity maps one-to-one.
Q_DUMP pin 1 (G): expected upper-left paired control terminal, at the marked G corner, vs observed (-0.937500,-0.950000), function G, DUMP_GATE. PASS.
Q_DUMP pin 2 (S): expected other paired terminal and grounded reference for a low-side switch, vs observed (-0.937500,+0.950000), function S, GND. PASS.
Q_DUMP pin 3 (D): expected lone opposite switched terminal, vs observed (+0.937500,0), function D, ADC_DUMP. PASS.
The table's N/S labels for pads 1/2 correspond to their small numerical predominance in |y|; both coordinates are on the left paired-lead side. The coordinate geometry, not a compass label alone, establishes the package comparison. No winding or pin-1 mismatch.

Q_PRE_EN — VERDICT: PASS

Primary: 2N7002K_DS30896_Rev20-2.pdf, SHA-256 669e5d68d6458e0879d7396416bdcdb3ef9966ea60f054773d4c891d735aa818, PDF page 1 Top View/Equivalent Circuit; page 7 Package Outline Dimensions/Suggested Pad Layout.
Measured native dossier census: 3 pad rows, 3 unique pad numbers, 3 distinct native positions, 3 physical G/S/D identities, 0 EPs, 0 fused aliases. Each identity maps one-to-one.
Q_PRE_EN pin 1 (G): expected upper-left paired control terminal, vs observed (-1.000000,-0.950000), W, G, PWR_EN. PASS.
Q_PRE_EN pin 2 (S): expected lower-left paired reference terminal, vs observed (-1.000000,+0.950000), W, S, GND. PASS.
Q_PRE_EN pin 3 (D): expected lone right-side switched terminal, vs observed (+1.000000,0), E, D, PRE_GATE. A grounded-source N-channel drain can pull down another gate net; the net name does not require this terminal itself to be G. PASS.

Q_RST1 — VERDICT: PASS

Primary: 2N7002K_DS30896_Rev20-2.pdf, SHA-256 669e5d68d6458e0879d7396416bdcdb3ef9966ea60f054773d4c891d735aa818, PDF page 1 Top View/Equivalent Circuit; page 7 Package Outline Dimensions/Suggested Pad Layout.
Measured native dossier census: 3 pad rows, 3 unique pad numbers, 3 distinct native positions, 3 physical G/S/D identities, 0 EPs, 0 fused aliases. Each identity maps one-to-one.
Q_RST1 pin 1 (G): expected upper-left paired control terminal, vs observed (-1.000000,-0.950000), W, G, RESET_PULSE_H. PASS.
Q_RST1 pin 2 (S): expected lower-left paired reference terminal, vs observed (-1.000000,+0.950000), W, S, GND. PASS.
Q_RST1 pin 3 (D): expected lone right-side switched terminal, vs observed (+1.000000,0), E, D, ADC_RESET_N. A grounded-source N-channel device can assert an active-low reset by sinking its drain. PASS.

Instance symmetry and limits

Q_PRE_EN and Q_RST1 have identical package geometry, functions, and electrical roles: pin 1 control; pin 2 GND; pin 3 controlled sink node. Q_DUMP uses a different N-channel part but preserves the same structural roles. The body-diode direction is S to D in each manufacturer's circuit, consistent with grounded sources and switched drains. Aggregate census is 9 native pads, 9 physical terminal identities, no missing or collapsed identities, no EP, no fused aliases.

No FAIL or QUESTION remains in the commissioned pin scope. Net-role sanity is assessed from the supplied names and physical transistor functions; this review does not validate circuit timing, downstream fanout, voltage/current margins, land-pattern manufacture, routing, or operation of the whole design. Evidence retains actual rendered figures, dossiers, methods, calculations, raw tool logs, runtime receipts, and before/after input digests. The missing /usr/bin/rg launch is retained as a tooling incident; the same document-location operation completed through a bounded Python read. This did not substitute a reviewer or primary source.


## Verbatim independent report — rj45-pin-carrier-conversion-context1

review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_conversion_mountedframe1 (same independent original reviewer)
context: CONTINUATION of independent original pin review with requested native ADC strap facts; not a new fresh agent
review_disposition: FIRST-ARTICLE-ONLY
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7
subject_raw_sha256: e208b779ab4c1f5efb4c3f438ae34f2e16a3f21444ecf9539183028af744329d
subject_semantic_sha256: d59c9dfb39ff827029a8e486a65c79e5ea3262fbb07ffab19cd03d8907b9b70e

The sole original question Q1 is resolved by the added native strap dossiers and exact primary resistor PDFs. Both commissioned refs U_ADC and U_LDO now PASS within the original pin/net review scope. This is a bounded continuation of my own original review, not a new fresh review or a replacement of the closed INCOMPLETE delivery. No whole-board, clock-source/timing, channel-order system, routing, assembly-file or production acceptance follows. FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains in force.

## Exact continuation provenance

Original task: rj45-pin-carrier-conversion-mountedframe1. Original report bytes are included unchanged as previous-completed-report.md, SHA-256 c503197ab32c1baf101dfec1a36f465cf2561448c240da4bf3f5c63dc97f5578, 11623 bytes. Original subject raw SHA-256 084c8feea47a96890190eb4e165a289213c3182484692775ad05c2995190f84f; semantic SHA-256 cff15c2597f85a783ec9ab7a5133740a27b050694cac0be01dcb54c166b510c2. The supplied previous-closeout.json binds the archived original delivery to SHA-256 361bb86619da71a7f1c64182238461e4154d6f1126d1f076044216686a1a30cb, 2754188 bytes; it records the original 76-member evidence archive was reopened. That original archive is inherited evidence, not reopened from the live project during this continuation.

The unchanged U_ADC dossier is SHA-256 804a07d935a6dbe2c1f2366b3ee3aee3d3bc0b53260bb19c9b0995417d40acde; U_LDO is cd67b0631b413bfd67e54be79032816924d24d92494f20ac916159ab78247b2f. All original primary PDF digests are unchanged and reverified. The new envelope canonical SHA-256 is 6b964100f479f94dff5e2212bdfd6420e508beb162fd48ed3fefde7c2df46f14. This report uses its new exact subject above, while preserving the original commissioned board/parts/rules bindings as metadata.

Inherited proof: original primary figure inspection, package winding, pin-1 positions, separate terminal/EP identities, all function identities, static net classes and instance symmetry. The original method disclosure, including the bootstrap dossier-read sequence, remains in the unchanged original report. Newly verified proof: the values, geometry and native net endpoints of R_CFG1, R_CFG2, R_CFG4 and R_CFG5; the corresponding actual ADC hardware mode and applicability of grounded/unused ADC pins. Successful whole-group physical inspection was not repeated.

## Newly verified supporting resistor facts

Actual primary PDF p.1 images show a two-terminal 0402/1005 resistor, nominal 1.0 × 0.5 × 0.35 mm, with end metallization and no EP, polarity mark, or manufacturer terminal numbering. Two collinear nonpolar contacts establish no winding or privileged pin-1 corner. Pads 1 and 2 are distinct interchangeable physical end terminals; no fusion or alias is asserted. Each dossier is front F.Cu, native rotation 180°, with component-top pad 1 (-0.51,0), pad 2 (+0.51,0), both 0.54 × 0.64 mm. Native-to-local conversion is rotation only after translation, never a mirror. Each has two measured numbered native rows, two unique centers and two represented physical terminals; zero missing/duplicate identities, zero EPs. The same-MPN R_CFG1/R_CFG4 instances retain the same terminal types; opposite pull direction is a legitimate configuration choice.

| Supporting ref | Exact primary PDF hash (p.1 drawing and Specifications) | Primary value | Native pad 1 → pad 2 nets | Result |
|---|---|---|---|---|
| R_CFG1 | b894ff1ce27e9567b396a6cb9c16750970e4145c03bf64367db0cc8ca107459f | RC0402FR-074K7L, 4.7 kΩ, 1% | CFG1 → GND | PASS |
| R_CFG2 | 86e35763f809c9aa780f4e8ad0d3d6f71b57a3d3afdeb5f523837e5a29da9813 | RC0402FR-070RL, zero-ohm jumper | CFG2 → 3V3_ADC | PASS |
| R_CFG4 | b894ff1ce27e9567b396a6cb9c16750970e4145c03bf64367db0cc8ca107459f | RC0402FR-074K7L, 4.7 kΩ, 1% | CFG4 → 3V3_ADC | PASS |
| R_CFG5 | e42aa2b39be7476fef25efbe4656acbbc246d2b9b625d64db6b46e0f5e34d7af | RC0402FR-07100KL, 100 kΩ, 1% | CFG5 → GND | PASS |

R_CFG1 native pads are (87.91,63.90)/(86.89,63.90); R_CFG2 (85.01,70.40)/(83.99,70.40); R_CFG4 (87.91,76.10)/(86.89,76.10); R_CFG5 (87.91,74.30)/(86.89,74.30). Measured transform residuals are below 1e-13 mm. The eight new pad rows are recorded in support-measurements.json. These four refs are supporting context; the commissioned group remains U_ADC/U_LDO.

## U_ADC — VERDICT: PASS

Primary CS5308P DS1314F1 SHA-256 6ca42cc09ac47ebdacacaee435f05e3f9c34b83d5692e52a2d8a26533e810e57. Inherited actual figure evidence: PDF p.4 Figure 1-1 (explicit TOP VIEW), p.5 Table 1-1, p.8 Figure 2-2, p.93 Figure 10-1. Newly rendered and inspected: pp.19–20 Tables 4-1–4-4; p.6 Table 1-2; p.35 Table 4-13; pp.36–37, especially Figure 4-15 and accompanying DOUT usage text.

Inherited physical findings remain PASS: 49 measured numbered native rows, 49 unique pad numbers/centers, 49 physical identities (48 perimeter terminals and one PAD mapped to artifact 49), no missing or duplicate identities. Pin 1 is upper-left west, pins 1–12 run down west, 13–24 across south, 25–36 up east, 37–48 back across north: CCW. Front mounting, zero rotation and no mirror match the manufacturer TOP VIEW. Inherited signed twice-area is -67.37 mm² in y-down coordinates. EP49 is 4.6 × 4.6 mm at (0,0), GND; pitch is 0.4 mm with 12 terminals on each edge. No fused pins/aliases. Nine unnumbered paste/mechanical pads are reported in the dossier footer, not independently measured from its omitted rows.

Q1 resolution, derived from the actual connections without assuming a desired mode:

U_ADC pin 2 (CONFIG1): expected 4.7 kΩ pull-down to GND_A to select hardware ASP Secondary Mode at 44.1/48 kHz per Table 4-1; observed CFG1 through R_CFG1=4.7 kΩ to GND — PASS. This excludes software-control selection and sample-rate autodetect.
U_ADC pin 3 (CONFIG2/HGC_SCK): expected zero-ohm pull-up to VDD_A for TDM minimum time slots per Table 4-1; observed CFG2 through R_CFG2=0 Ω to 3V3_ADC, the same rail as ADC VDD_A pins 5 and 9 — PASS.
U_ADC pin 4 (CONFIG3/HGC_SDO): expected default slots 0–7 in eight-slot mode per p.36; observed GND, which Table 4-2 identifies as the lower slot group — PASS.
U_ADC pin 10 (CONFIG4/HGC_CS): expected 4.7 kΩ pull-up for default channel order per Table 4-3; observed CFG4 through R_CFG4=4.7 kΩ to 3V3_ADC — PASS. It does not select reversed ASP channel order.
U_ADC pin 11 (CONFIG5): expected 100 kΩ pull-down for linear-phase, fast-roll-off filtering with HPF enabled per Table 4-4; observed CFG5 through R_CFG5=100 kΩ to GND — PASS.
U_ADC pin 25 (ASP_DOUT1): Table 4-13 at 44.1/48 kHz and minimum-slot TDM selects one output with eight slots per frame; p.37 Figure 4-15 explicitly assigns it to DOUT1. Observed TDM_RAW on pad 25 — PASS.
U_ADC pins 26,27,28 (ASP_DOUT2–4): expected unused in eight-slot mode per p.37, floating per Table 1-2; observed the three distinct unconnected-(U_ADC-ASP_DOUTx_NC-Padn) nets — PASS.
U_ADC pins 35,36,37 (SPI_SDO/I2C_SCL,SPI_SCK,SPI_SDI/I2C_SDA): expected unused control-port pins grounded per Table 1-2 because CONFIG1 establishes hardware control; observed GND on all three — PASS.
U_ADC pin 38 (SPI_CS): expected unused pin connected to VDD_IO per Table 1-2; observed 3V3_ADC, identical to VDD_IO pin 31 — PASS.

The derived mode requires external secondary-mode clocks. Table 4-13 requires BCLK ≥256 fs and a constant integer multiple of fs; this corresponds to at least 11.2896 MHz for 44.1 kHz or 12.288 MHz for 48 kHz. ADC_FSYNC, ADC_BCLK and ADC_MCLK remain signal-net-class passes inherited from the original review. Actual external clock generation and timing are not part of this requested missing-strap completion and are not asserted as verified.

All other ADC findings remain inherited PASS: pins 5/9/31 share 3V3_ADC; 6/8/30 and EP49 are GND; 32/33 share LDO_D_FILT as required; 7,1,12 have dedicated LDO/reference nodes; 17/44 are ground-side filter connections; 18/43 are dedicated filter-positive nodes; the eight differential pairs preserve N/P; 23/24/29/34 use reset/synchronization/clock signal nets. All 49 primary function identities matched the original native rows. One instance is supplied, so inter-instance symmetry is not applicable.

The inherited channel-label permutation remains explicit: manufacturer IN1/2/3/4 connect to ADC4/3/2/1 net pairs, while IN5–8 connect to ADC5–8. With newly established default ASP order, TDM slots 0–7 therefore carry the input pairs named ADC4,ADC3,ADC2,ADC1,ADC5,ADC6,ADC7,ADC8. This is an observed mapping, not an assertion that an external system's channel naming convention is correct.

## U_LDO — VERDICT: PASS (inherited, unchanged)

Primary LT3041 Rev.A SHA-256 35dda1deb2ffc9e20545ebe2aefd2fbd690cf9b04e8772290fd4991a4b8ef584; original actual images pp.7–8 Figure 3/Table 3, p.31 Figures 87–89, p.36 Figure 98 package 05-08-1708. The exact ADE#TRPBF ordering entry is bound to that DFN package.

Inherited measured counts: 15 numbered native rows, 15 unique numbers/centers and 15 physical identities (14 terminals plus EP15), no missing/duplicate identities, no fusion or aliases. Two seven-terminal side rows at 0.5 mm pitch; upper-left pin 1; CCW numbering; signed twice-area -17.4 mm² in y-down coordinates. Front-mounted, zero rotation against Figure 3 TOP VIEW. Figure 98 bottom-view conversion was explicitly mirror-x to top view then clockwise 90° rotation; this did not mirror the dossier. EP15 is 1.7 × 3.3 mm on GND. Eight unnumbered paste/mechanical pads are footer-reported only.

U_LDO pins 1/2/3 (IN): expected common input rail; observed 5V_LDO_HOLD — PASS.
U_LDO pins 4/6 (VIOC/PG): expected float when unused; observed distinct unconnected nets — PASS.
U_LDO pin 5 (EN/UV): expected enable/UVLO node; observed LDO_EN — PASS for net class.
U_LDO pin 7 (ILIM): expected ground when external current limit is unused; observed GND — PASS.
U_LDO pin 8 (PGFB): expected IN tie when PG/fast start are unused; observed 5V_LDO_HOLD — PASS.
U_LDO pin 9 (SET): expected dedicated setpoint/bypass node; observed LDO_NR — PASS for net class.
U_LDO pins 10/11/15 (GND/GND/EP): expected GND; observed GND — PASS.
U_LDO pins 12/13/14 (OUTS/OUT/OUT): expected output sense and common output rail; observed 3V3_ADC — PASS for net connectivity.

All 15 function identities matched. One instance was supplied; IN/OUT/GND same-function groups are internally symmetric. External setpoint/capacitor values, Kelvin routing and thermal implementation remain outside the original pin-table scope.

## Delivery and remaining scope

No unresolved engineering finding remains within this bounded group pin review. The previous report remains historically INCOMPLETE; this new SOUND continuation applies only with the added native facts and its exact envelope subject. All 16 envelope inputs were verified before/after by size and SHA-256. Actual new PDF images, native supporting dossiers, original report/closeout, measurements, scripts and stage logs are archived. Finite direct-argv subprocesses used /usr/bin/python3 -B and shared pipeline_runtime.run_stage with explicit cwd/environment and retained raw stdout/stderr/runtime. Only allocated scratch/output paths were written. The evidence archive is reopened member-by-member and hashed; the exact-envelope preflight validates the final delivery. Delivery PASS does not authorize order or expand the scope beyond U_ADC/U_LDO.


## Verbatim independent report — rj45-pin-carrier-esd-context1

review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_esd_mountedframe1 (same actual reviewer, continuation)
context: CONTINUED_REQUESTED_CONTEXT
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

Scope: resolution of the eight original audio-voltage questions for U_ESD1–U_ESD8 at the unchanged pre-route physical subject. All eight now PASS within the declared normal operating design. FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains. No whole-board, placement, physical qualification, release or order acceptance.

Context is continued, not fresh: the original independent review remains closed and INCOMPLETE, with QUESTION on all eight refs. This report adds specifically requested authored operating context and new independent TI checks. It does not edit or relabel the original review. Although the envelope transport field says FRESH, this is the same reviewer with retained prior findings.

Exact current envelope subject: raw_sha256=257d9d055dac0dd5059febf943d24c3a39465ad9e03097b262c1e6753e008f03; semantic_sha256=eb96cce9982633f24b020587bac65243bc913f61977142f432e86fe4c01e1095. Canonical envelope SHA-256=8b500893a035b5222fa7e9e65807c5657ab14bc30b6027bf84857f2cbe37590b. Physical board/parts/rules bindings above remain unchanged; the task-envelope subject binds the expanded context packet.

Original proof: previous-completed-report.md SHA-256=8a44dfbcbe8b5aa91eea6eac59780ec5622ee0a85c9e25ea8bc7a3414f534e93; closed archive SHA-256=1720aa2dc0dc215cae7a9505c1fd56f732fe78c043fc4686f828a3c775d94a97; underlying original reviewer archive SHA-256=c9989b95d11d5cbd0a53ee634c9a684f03b90073b6852eb792166cfa845e43d7. The frozen report and closeout receipt are retained; the live archive was not reread. Original five-pad DRL package, CCW winding, pin-1 corner, B.Cu mount conversion, no-EP/no-alias and eight-instance symmetry evidence is inherited by exact identity rather than rerun. The prior measured census is 5 physical identities per ref, 40 total, with 0 EP and 0 aliases.

New supplied facts: the accepted-for-first-article pod contract states a DC-coupled active-balanced output at nominal 2.5 V common mode with one 100 ohm resistor on each leg and a frozen 1.2 Vrms differential ceiling. These are authored design requirements and connections, not measured voltages. The exact supplied pod source has equal 22 kohm VREF-divider resistors (lines 226–228), buffered VREF and GND/5V_QUIET op-amp supplies (238–242), 22k/18k inverting preamplifier and 10k/10k polarity-restoring inverter (248–254), and direct 100 ohm source resistors to AUDIO_P/AUDIO_N (256–259).

Independent normal-operation derivation: VREF=5×22/(22+22)=2.5 V. For microphone AC deviation v, PRE_OUT=VREF−(9/11)v and OUTP_DRV=VREF+(9/11)v; differential gain is 18/11 V/V. At 1.2 Vrms differential the nominal complementary legs each carry 0.6 Vrms. The sine-equivalent peak excursion is sqrt(2)×0.6=0.848528 V, so each leg spans 1.651472–3.348528 V relative to GND. The lower and upper margins to TI’s 0–5.5 V supported range are 1.651472 V and 2.151472 V, respectively. The source resistors and passive receiver loading do not create a new DC bias source on the cable side in this nominal circuit model.

Recomputed authored gain arithmetic: −24 dBV/Pa at 110 dB SPL gives 0.399052 Vrms microphone level; gain 18/11 gives 0.652995 Vrms differential, +3 dB sensitivity gives 0.922380 Vrms, and independent 1% gain-resistor corners give 0.950519 Vrms, below 0.96 and the 1.2 Vrms ceiling. These calculations independently check the supplied arithmetic, not capsule or OPA1679 specifications. Illustrative 1% divider/inverter corners at exactly nominal 5 V give approximately 1.6180–3.3820 V; this is not a full tolerance or physical qualification.

Peak scope: Vrms alone does not bound arbitrary waveform peaks. The calculated 1.6515–3.3485 V range is explicitly the nominal sine-equivalent design-ceiling excursion, not a maximum for every crow waveform, startup pulse or fault. In the ideal complementary model at nominal 2.5 V common mode, both legs stay in TI’s range if |instantaneous differential voltage|≤5 V (crest factor≤4.1667 at 1.2 Vrms). The supplied topology is a healthy nominal 5 V, ground-referenced active driver, with no intended negative audio supply. This scoped pin PASS establishes compatibility of that intended operating design; it does not claim measured crest-factor, rail, ground-offset or transient bounds.

Clamp location and common-mode distinction: carrier source lines 334–350 connect Jn pin 5 and U_ESDn pin 3 to AUDIO_Pn, Jn pin 4 and U_ESDn pin 5 to AUDIO_Nn, and U_ESDn pin 4 to GND. Lines 370–373 put the two 1 uF capacitors BETWEEN those cable nets and BIAS_Pn/BIAS_Nn; only the BIAS nets connect through 100 kohm to VMIDn_EXT. Lines 537–538 derive the nominal 1.65 V receiver bias from 3V3_ADC. Therefore the ESD clamp sees the pod’s 2.5 V cable common mode; the post-capacitor 1.65 V receiver bias is not the clamp DC operating point. Both Port and AnalogChannel are instantiated for all eight channels, so the context applies uniformly.

New primary evidence: TI TPD2E2U06 SLLSEG9C PDF SHA-256=a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed. Actual rendered pages 4,8,9,11 were inspected. P.4 section 6.3 and p.11 section 8.2.2.1 support IO voltages 0–5.5 V. P.8 section 7.2 shows two equivalent channels and ground return. P.9 section 7.4 describes the passive lower diode at approximately −0.6 V and positive breakdown response. P.11 section 9 requires no power supply for this device. Those transient trigger thresholds do not expand its recommended normal signal range.

normal_powered: Design-level compatibility established for declared healthy nominal 5 V/GND pod, buffered nominal 2.5 V cable common mode and declared active-balanced signal envelope. Nominal ceiling sine-equivalent per-leg range is 1.6514719–3.3485281 V. Contract and source are authored evidence; real amplitude, bias, loading and tolerance qualification are not measured here.

carrier_unpowered_pod_powered: TPD2E2U06 itself needs no supply and has no carrier-rail pin. With GND retained and a pod driving the same supported cable range, losing carrier power does not invalidate this clamp pin mapping. No claim about the downstream unpowered AFE or startup/coupling transient is made.

pod_or_both_unpowered: The powered 2.5 V operating point is not assumed to persist. A settled 0 V cable line is within the clamp signal range and the passive clamp still has its ground path, but unpowered driver impedance, residual capacitor charge and exact startup/shutdown line waveforms are not established by this packet.

abnormal_and_physical_holds: Negative fault/ESD excursions activate the lower diode (p.9 approximately -0.6 V), and positive ESD excursions activate the TVS network; those transient thresholds are not the normal recommended signal range. This review does not prove hot-plug, 12 V crosswire, ground loss, ESD system survival, cable pickup, OPA output swing/stability, or physical power-sequence performance. Existing no-hot-plug/bench/first-article holds remain unchanged; no new physical prerequisite is imposed for this design-only pin resolution.

U_ESD1 — original VERDICT: QUESTION; continued VERDICT: PASS
Counts retained from original exact proof: native pads=5, physical identities=5, EP=0, aliases=0; original CCW/B.Cu/pin1/symmetry checks preserved, not rerun.
U_ESD1 pins 1/2 (NC): expected permitted unconnected NC terminals; observed distinct original unconnected nets, retained PASS.
U_ESD1 pin 3 (IO1): expected supported 0–5.5 V signal; observed AUDIO_P1, authored 2.5 V cable bias and nominal sine-equivalent range 1.651472–3.348528 V. Original operating-context question resolved for intended normal design.
U_ESD1 pin 4 (GND): expected ground; observed GND, retained PASS.
U_ESD1 pin 5 (IO2): expected supported 0–5.5 V signal; observed AUDIO_N1, same cable bias/envelope with complementary phase. Original operating-context question resolved for intended normal design.
U_ESD1 source cross-check: clamp is before C_A1P/N, which connect to separate BIAS_P1/BIAS_N1 receiver nets. Same kind of net on same pin as all seven peers.
Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; new pp.4/8/9/11 as described above; physical pp.3/17/18 retained via original digest-bound proof. Unresolved scoped pin findings: none.

U_ESD2 — original VERDICT: QUESTION; continued VERDICT: PASS
Counts retained from original exact proof: native pads=5, physical identities=5, EP=0, aliases=0; original CCW/B.Cu/pin1/symmetry checks preserved, not rerun.
U_ESD2 pins 1/2 (NC): expected permitted unconnected NC terminals; observed distinct original unconnected nets, retained PASS.
U_ESD2 pin 3 (IO1): expected supported 0–5.5 V signal; observed AUDIO_P2, authored 2.5 V cable bias and nominal sine-equivalent range 1.651472–3.348528 V. Original operating-context question resolved for intended normal design.
U_ESD2 pin 4 (GND): expected ground; observed GND, retained PASS.
U_ESD2 pin 5 (IO2): expected supported 0–5.5 V signal; observed AUDIO_N2, same cable bias/envelope with complementary phase. Original operating-context question resolved for intended normal design.
U_ESD2 source cross-check: clamp is before C_A2P/N, which connect to separate BIAS_P2/BIAS_N2 receiver nets. Same kind of net on same pin as all seven peers.
Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; new pp.4/8/9/11 as described above; physical pp.3/17/18 retained via original digest-bound proof. Unresolved scoped pin findings: none.

U_ESD3 — original VERDICT: QUESTION; continued VERDICT: PASS
Counts retained from original exact proof: native pads=5, physical identities=5, EP=0, aliases=0; original CCW/B.Cu/pin1/symmetry checks preserved, not rerun.
U_ESD3 pins 1/2 (NC): expected permitted unconnected NC terminals; observed distinct original unconnected nets, retained PASS.
U_ESD3 pin 3 (IO1): expected supported 0–5.5 V signal; observed AUDIO_P3, authored 2.5 V cable bias and nominal sine-equivalent range 1.651472–3.348528 V. Original operating-context question resolved for intended normal design.
U_ESD3 pin 4 (GND): expected ground; observed GND, retained PASS.
U_ESD3 pin 5 (IO2): expected supported 0–5.5 V signal; observed AUDIO_N3, same cable bias/envelope with complementary phase. Original operating-context question resolved for intended normal design.
U_ESD3 source cross-check: clamp is before C_A3P/N, which connect to separate BIAS_P3/BIAS_N3 receiver nets. Same kind of net on same pin as all seven peers.
Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; new pp.4/8/9/11 as described above; physical pp.3/17/18 retained via original digest-bound proof. Unresolved scoped pin findings: none.

U_ESD4 — original VERDICT: QUESTION; continued VERDICT: PASS
Counts retained from original exact proof: native pads=5, physical identities=5, EP=0, aliases=0; original CCW/B.Cu/pin1/symmetry checks preserved, not rerun.
U_ESD4 pins 1/2 (NC): expected permitted unconnected NC terminals; observed distinct original unconnected nets, retained PASS.
U_ESD4 pin 3 (IO1): expected supported 0–5.5 V signal; observed AUDIO_P4, authored 2.5 V cable bias and nominal sine-equivalent range 1.651472–3.348528 V. Original operating-context question resolved for intended normal design.
U_ESD4 pin 4 (GND): expected ground; observed GND, retained PASS.
U_ESD4 pin 5 (IO2): expected supported 0–5.5 V signal; observed AUDIO_N4, same cable bias/envelope with complementary phase. Original operating-context question resolved for intended normal design.
U_ESD4 source cross-check: clamp is before C_A4P/N, which connect to separate BIAS_P4/BIAS_N4 receiver nets. Same kind of net on same pin as all seven peers.
Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; new pp.4/8/9/11 as described above; physical pp.3/17/18 retained via original digest-bound proof. Unresolved scoped pin findings: none.

U_ESD5 — original VERDICT: QUESTION; continued VERDICT: PASS
Counts retained from original exact proof: native pads=5, physical identities=5, EP=0, aliases=0; original CCW/B.Cu/pin1/symmetry checks preserved, not rerun.
U_ESD5 pins 1/2 (NC): expected permitted unconnected NC terminals; observed distinct original unconnected nets, retained PASS.
U_ESD5 pin 3 (IO1): expected supported 0–5.5 V signal; observed AUDIO_P5, authored 2.5 V cable bias and nominal sine-equivalent range 1.651472–3.348528 V. Original operating-context question resolved for intended normal design.
U_ESD5 pin 4 (GND): expected ground; observed GND, retained PASS.
U_ESD5 pin 5 (IO2): expected supported 0–5.5 V signal; observed AUDIO_N5, same cable bias/envelope with complementary phase. Original operating-context question resolved for intended normal design.
U_ESD5 source cross-check: clamp is before C_A5P/N, which connect to separate BIAS_P5/BIAS_N5 receiver nets. Same kind of net on same pin as all seven peers.
Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; new pp.4/8/9/11 as described above; physical pp.3/17/18 retained via original digest-bound proof. Unresolved scoped pin findings: none.

U_ESD6 — original VERDICT: QUESTION; continued VERDICT: PASS
Counts retained from original exact proof: native pads=5, physical identities=5, EP=0, aliases=0; original CCW/B.Cu/pin1/symmetry checks preserved, not rerun.
U_ESD6 pins 1/2 (NC): expected permitted unconnected NC terminals; observed distinct original unconnected nets, retained PASS.
U_ESD6 pin 3 (IO1): expected supported 0–5.5 V signal; observed AUDIO_P6, authored 2.5 V cable bias and nominal sine-equivalent range 1.651472–3.348528 V. Original operating-context question resolved for intended normal design.
U_ESD6 pin 4 (GND): expected ground; observed GND, retained PASS.
U_ESD6 pin 5 (IO2): expected supported 0–5.5 V signal; observed AUDIO_N6, same cable bias/envelope with complementary phase. Original operating-context question resolved for intended normal design.
U_ESD6 source cross-check: clamp is before C_A6P/N, which connect to separate BIAS_P6/BIAS_N6 receiver nets. Same kind of net on same pin as all seven peers.
Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; new pp.4/8/9/11 as described above; physical pp.3/17/18 retained via original digest-bound proof. Unresolved scoped pin findings: none.

U_ESD7 — original VERDICT: QUESTION; continued VERDICT: PASS
Counts retained from original exact proof: native pads=5, physical identities=5, EP=0, aliases=0; original CCW/B.Cu/pin1/symmetry checks preserved, not rerun.
U_ESD7 pins 1/2 (NC): expected permitted unconnected NC terminals; observed distinct original unconnected nets, retained PASS.
U_ESD7 pin 3 (IO1): expected supported 0–5.5 V signal; observed AUDIO_P7, authored 2.5 V cable bias and nominal sine-equivalent range 1.651472–3.348528 V. Original operating-context question resolved for intended normal design.
U_ESD7 pin 4 (GND): expected ground; observed GND, retained PASS.
U_ESD7 pin 5 (IO2): expected supported 0–5.5 V signal; observed AUDIO_N7, same cable bias/envelope with complementary phase. Original operating-context question resolved for intended normal design.
U_ESD7 source cross-check: clamp is before C_A7P/N, which connect to separate BIAS_P7/BIAS_N7 receiver nets. Same kind of net on same pin as all seven peers.
Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; new pp.4/8/9/11 as described above; physical pp.3/17/18 retained via original digest-bound proof. Unresolved scoped pin findings: none.

U_ESD8 — original VERDICT: QUESTION; continued VERDICT: PASS
Counts retained from original exact proof: native pads=5, physical identities=5, EP=0, aliases=0; original CCW/B.Cu/pin1/symmetry checks preserved, not rerun.
U_ESD8 pins 1/2 (NC): expected permitted unconnected NC terminals; observed distinct original unconnected nets, retained PASS.
U_ESD8 pin 3 (IO1): expected supported 0–5.5 V signal; observed AUDIO_P8, authored 2.5 V cable bias and nominal sine-equivalent range 1.651472–3.348528 V. Original operating-context question resolved for intended normal design.
U_ESD8 pin 4 (GND): expected ground; observed GND, retained PASS.
U_ESD8 pin 5 (IO2): expected supported 0–5.5 V signal; observed AUDIO_N8, same cable bias/envelope with complementary phase. Original operating-context question resolved for intended normal design.
U_ESD8 source cross-check: clamp is before C_A8P/N, which connect to separate BIAS_P8/BIAS_N8 receiver nets. Same kind of net on same pin as all seven peers.
Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; new pp.4/8/9/11 as described above; physical pp.3/17/18 retained via original digest-bound proof. Unresolved scoped pin findings: none.

Methods:
- Continued the same reviewer only to resolve specifically requested interface context. This is not a fresh independent repeat review. The envelope transport says FRESH; actual reviewer context is CONTINUED_REQUESTED_CONTEXT and is reported honestly.
- Verified all 17 exact envelope inputs by size and SHA-256 before and after; verified canonical envelope SHA-256 8b500893a035b5222fa7e9e65807c5657ab14bc30b6027bf84857f2cbe37590b.
- Retained the original independent top-view/package/pad/mount proof through exact completed-report and closeout identities; did not rerun those successful checks. Counts are inherited measurements, not new board extraction.
- Read supplied operating contract and exact frozen pod/carrier authoring connections as authored facts, not as measurements or independent device specifications. Connection excerpts with source line numbers are retained.
- New independent primary check: rendered physical TI PDF pages 4,8,9,11 at 120 DPI using pdftoppm; viewed actual images. Pages 4 and 11 establish 0–5.5 V signal range; p.8 shows ground-referenced clamp; p.9 section 7.4 and p.11 section 9 establish passive operation without a supply.
- Derived VREF and complementary signal equations from supplied resistor values and output connections. Converted declared differential RMS ceiling to nominal sine-equivalent per-leg peak explicitly using sqrt(2), and separately stated limits of RMS as a peak bound. Recomputed supplied microphone/gain corner arithmetic without claiming independent capsule/OPA qualification.
- Finite engineering subprocesses used shared pipeline_runtime.run_stage with direct argv, explicit scratch cwd and PATH=/usr/bin:/bin, LANG=C.UTF-8, LC_ALL=C.UTF-8, 60 second timeout. Actual raw output/runtime and scripts retained. Bootstrap packet reads and packaging used /usr/bin/python3 -B file I/O without child shell commands.
- Retained full supplied authored context, exact original report/closeout, dossiers, new rendered figures, derivation, commands/logs/runtime and input receipts in archive. Reopened every regular archive member and verified manifest path/size/digest census, no links/traversal/duplicate/nested archive. Delivery preflight validates handback and unchanged frozen scope.

Conclusion within commissioned scope: all original requested-context pin questions are resolved, so the continued pin domain is SOUND. Existing first-article, bench, abnormal-state and order holds remain open at their existing scope. No physical qualification hold has been converted into acceptance.


## Verbatim independent report — rj45-pin-carrier-headers-context1

review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_headers_mountedframe1 (same actual reviewer, requested-context continuation)
context: CONTINUATION
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
qualification_status: FIRST-ARTICLE-ONLY
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

Scope: J10, J11 and J9 intrinsic physical pin identities and declared board-level interface allocations only. SOUND does not accept the assembled cables, harness, installed fit, whole-board placement, routing, manufacturing release, or an order. All existing first-article interface holds remain.

Provenance and context

The original completed review remains INCOMPLETE, with original verdicts J10 QUESTION, J11 QUESTION, J9 QUESTION. It has not been edited or retrospectively relabeled. Its exact report is supplied as previous-completed-report.md, SHA-256 2f17b2c60f8e078bb83fc6125cd480796186fa8d36a2194d8362ad2b9d4e3f2c. Supplied previous-closeout.json identifies immutable journal archive ae31466f4a547acf3c2e4c2baf0ea5f1c4ee87e84ff14f7ff0a3c3fa002d6d53; that live archive was not opened in this continuation. The original TMM rotation proof and electrical identity counts are retained by this provenance rather than rerunning the previously successful physical review.

This is explicitly CONTINUATION despite the generic envelope context_mode field saying FRESH. New architecture text is authored design context, not independent manufacturer evidence. New primary MCHStreamer and TCSD figures were independently inspected. J9-all-native-pads.json is supplied native extraction, checked against the exact original board hash; it is not treated as a manufacturer expectation. All 14 envelope inputs verified before and after work. Only supplied frozen inputs and the permitted execution framework were read.

Primary sources and actual figure inspections

- Original Samtec TMM-Series_RevAS.pdf: 66d9ffaa15ef8ff9b1614640d81fd2d1c2c6629b522df0cddc64acac3e73efc3, page 1 FIG.1. Retained original top-view proof: double-row 12 contacts match each TMM dossier by clockwise 90-degree rotation. Zigzag numbering is not perimeter winding; no mirror was permitted. Original images remain in the closed original evidence archive.
- Original Molex SD-43650-001 D8 PDF: b8942b95bc3fe4c02171de9e714d99b2688055e249ba1524e3c2a8c3cf78eaa3, page 1 PCB LAYOUT: COMPONENT SIDE and PCB LAYOUT: 2 CKT. Retained manufacturer-derived expectation is used for the newly supplied asymmetric point.
- MCHStreamer_User_Manual.pdf: 2cf36d628df68607d007b971a13a3a578916d74629d6660571daf218cfbc6edd. Newly rendered/inspected page 10 Figure 1 (explicit top of board) and Table 1, page 24 Figure 12/Table 12 (TDM firmware), page 8 section 2.4 and power-header figure.
- TCSD-Series_RevBE.pdf: fa4643ec2ea321bf7bc186d20bf8c1b31a7fb0b3d335662c2ba8eba9007b108b. Newly rendered/inspected all four sheets; sheets 1-2 establish first-position indicators, ordinary double-end arrangement, reverse-wiring and reverse-connector distinctions. Sheets 3-4 contain assembly/strain-relief details, not additional proof of an installed cable.
- Newly authored architecture: 79bab8c4b8c4b74d9fc6e909b2891b0501a6b90eca1f89a54cc5e10eeb939978, ADC and clocks section and J9 custom power-entry description.
- New native J9 extraction: 63d9eca7268e8bd300fbe8072db87c8b6802861eaa85b6cceec295c650a7ea48.

J10 VERDICT: PASS (original QUESTION resolved at declared board-interface level)

Counts: 12 numbered native dossier rows, 12 unique physical electrical identities, 12 distinct locations; no exposed pad, physical identity collapse, or fused alias. The original package proof is retained unchanged.

MCHStreamer Figure 1 explicitly shows top-of-board J1 with pin 1 lower left, pin 2 above, odd numbers along the lower row and even numbers above. This independently agrees with the original Samtec TMM figure. A clockwise 90-degree rotation maps those physical identities to J10's component-top sequence: 1=(0,0), 2=(2,0), 3=(0,2), through 11=(0,10), 12=(2,10). This is a comparison between board-top header identities, not an assertion that looking into a female cable socket uses the same unreflected visual frame.

Pin | Expected from MCH TDM8 Table 12 and declared capture-only use | Native J10 net
---|---|---
1 | MCH data OUT Ch1-8, intentionally unused by carrier | unconnected-(J10-NC1-Pad1)
2 | MCH data IN Ch1-8, carrier ADC stream | ADC_TDM
3-8 | TDM8 unused | six individual unconnected J10 pad nets
9 | MCH MCLK output | MCH_MCLK
10 | MCH BCLK output | MCH_BCLK
11 | Ground | GND
12 | MCH FSYNC output | MCH_FSYNC

All 12 identities/allocations agree. Page 24's TDM8 column, rather than page 10's sample I2S pin descriptions, establishes the data and FSYNC use. An unused module output at pin 1 is properly left disconnected. The declaration that MCH is clock master agrees with the primary output directions. This does not validate loaded firmware, edge timing or actual USB channel behavior.

J11 VERDICT: PASS (original QUESTION resolved at declared board-interface level)

Counts: 12 numbered native dossier rows, 12 unique physical identities, 12 distinct locations; no EP, fused alias or collapsed identity. Original TMM package proof retained. MCH Figure 1 J3 top-of-board drawing places pin 1 upper left, pin 2 upper right and odd/even pairs progressing downward, directly matching J11 component-top identities.

J11 pin 1: expected official J3 ground from Table 1; observed GND. PASS.
J11 pin 2: expected official J3 3.3 V output from Table 1 and section 2.4; observed MCH_3V3_SENSE. Authored architecture declares approximately 0.320 mA sensing, not carrier-rail power; this is the correct kind of connection to that output. The primary permits external loading up to 200 mA. No independent check of the downstream sense circuitry is claimed here. PASS.
J11 pins 3-12: expected unused in this declared two-wire sensing connection; observed ten individual unconnected pad nets. In particular TDM Table 12 identifies J3 pin 11 as inverted BCLK output, which may remain unused. PASS.

The original J10/J11 asymmetries at pins 1,2,9,10,11,12 resolve: they serve different official module ports, J1 and J3. Identical passive terminal-strip part numbers do not require identical signal roles across different ports. Primary tables independently confirm those declared differences.

J9 VERDICT: PASS (original orientation QUESTION resolved; custom allocation distinguished from physical harness proof)

Counts: 2 numbered native electrical identities plus 1 separate unnumbered mechanical point, total 3 native pad objects. All three positions are now available. The added point has component-top (1.50,-4.32), size 3.00x3.00, tht=true, no net; native board coordinate (23.68,67.50). The extraction does not encode drill diameter or plating, so its 3.00 mm size is not falsely reported as a measured drill.

The original manufacturer component-side derivation, referenced to circuit 1, is circuit 1=(0,0), circuit 2=(-3,0), locating peg=(-1.50,+4.32). A permitted 180-degree rotation predicts (0,0), (+3,0), (+1.50,-4.32). All three measured native component-top points match. The previously indistinguishable x-mirror would put the peg at (+1.50,+4.32), which the new extraction disproves. The signed two-vector determinant remains -12.96 mm² under the actual match and would reverse sign under the mirror. This resolves rotation-versus-mirror and numbered contact identity, without assigning a winding to two collinear electrical pins.

All three points also obey the front-mounted 90-degree native transform (X,Y)=(28+localY,69-localX). The mechanical point establishes the housing side relative to the contact row; no additional mounting reflection is introduced.

J9 pin 1: expected a passive circuit 1 contact; the custom board allocation names it +12V_IN. Observed 12V_IN. PASS.
J9 pin 2: expected a passive circuit 2 contact; the custom board allocation names it GND. Observed GND. PASS.

The Molex manufacturer drawing defines contact identity, not the voltage of a custom harness. Requiring it to declare this project's 12 V allocation was not an intrinsic pin-review requirement. Authored architecture establishes the selected power-entry role and custom pigtail construction, while the native dossier states the actual contact allocation. Board-level polarity is therefore unambiguous: deliver positive to physical circuit 1 and return to circuit 2. This is a harness requirement, not a claim that the supplied packet independently demonstrates an assembled red/black pigtail's continuity or insertion.

Retained physical interface holds, not waived

The declared J10-to-MCH-J1 and J11-to-MCH-J3 connections require like-numbered contact continuity, with each end correctly oriented to its own physical pin 1. TCSD RevBE sheet 1 ties the colored conductor to the first-position indicator in the standard arrangement and shows a distinct -RW reverse-wiring option; sheet 2 distinguishes reversed connector/notch configurations. These are evidence that cable orientation must be specified and checked, not evidence that every TCSD variant or an unobserved cable is interchangeable. This packet does not establish the exact installed cable option, female-face orientation, or measured continuity. No such orientation has been invented; connector marking alignment, pin-to-pin continuity, engagement depth, retention, split-cable behavior and fit remain physical interface holds. The board's intended numbered assignments themselves are established above.

J9 assembled harness polarity/continuity, cavity insertion, restraint and first-article mechanical fit remain holds. Drill diameter/plating is absent from the new extraction and is not qualified by this pin-mapping result. No current, thermal, protection, signal-integrity or power-sequencing qualification is conferred.

Final scoped pin verdict: SOUND. Current J10 PASS, J11 PASS, J9 PASS. Original per-ref QUESTION verdicts and INCOMPLETE closeout remain historical immutable results. There are no remaining intrinsic numbered-contact or declared board-net allocation questions in this commissioned group. FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains in force.


## Verbatim independent report — rj45-pin-carrier-jacks-mountedframe1

review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent /root/rj45_pin_carrier_jacks_mountedframe1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

Subject (exact envelope):
{"raw_sha256": "b9a3e763c4e522fa2453377aa96a2350b105cbefb43c1d0cb3ca6580da806c9e", "semantic_sha256": "63c1c9cc96c5a65f34d385ec2da4e46f4acd29258bccb38781c332da2620f776"}

Coverage: J1–J8 only. This is a pre-route pin review, not whole-board acceptance or an order authorization.

Primary for every ref: projects/crow-audio-carrier-v1/02_parts/615008160221/Wurth_615008160221_rev001003.pdf; SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048; revision 001.003; page 1, Dimensions and Recommended Hole Pattern; page 2, Article Properties and Electrical Properties. Actual inspected page images are in the archive.

# Independent pin review methods and figure observations

Reviewer: actual fresh agent /root/rj45_pin_carrier_jacks_mountedframe1. Engineering sources were only the supplied protocol, J1–J8 dossiers, and the exact primary PDF. The dossier author verification note was not used as evidence. No schematic, live design, historical review, manufacturer CAD, web material, or other project sources were consulted. Runtime/validator infrastructure was read only to implement the handback.

Primary: Wurth 615008160221, revision 001.003, 2025-07-09. SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048.

Actual figure inspections: page 1 complete at 120 dpi, page 2 complete at 120 dpi, page 1 complete at 240 dpi, all rendered using pdftoppm and opened with view_image. These actual PNGs are retained. Text extraction only supplements the images; it is not winding evidence.

Page 1 has unnumbered figures titled Dimensions and Recommended Hole Pattern. Page 2 Article Properties specifies 8P8C. The part is a horizontal shielded passive jack, with eight individual contact tails, two separate shield mounting terminals, and two non-electrical locating pegs. No EP, IC power pin, NC pin, internal magnetics, or polarity marking is present in these figures.

View derivation from page 1 images: the center-left view is the mating face, latch opening up; the solid metal roof with two spring tabs is the lower-left projection and is confirmed by the isometric view. The exposed underside/contact-tail projection is above the mating face. The mouth faces upward on that underside projection and downward on the roof projection. The leftmost terminal end in the underside projection is in the row farther from the mouth; its rightmost terminal end is in the row nearer the mouth. In the recommended board-hole pattern, the mouth side is downward (the shield slots and peg positions correspond to the side/roof geometry); the leftmost contact is likewise farther from the mouth and the rightmost nearer. Thus the board-hole drawing corresponds to the component-top projection. This conclusion uses the asymmetric staggering and the three-dimensional body, not an assumed generic 'hole pattern means top' rule. The underside projection and board-hole pattern have the expected y reversal. No mirror is applied to the board-hole drawing when comparing it to the component-top dossier.

Read directly in the manufacturer's recommended pattern, with +x right and +y down: upper/back row is 8,6,4,2 from left to right; lower/front row is 7,5,3,1 from left to right. Pin 1 is the rightmost contact in the near-mouth row. The x increment between consecutive contact identities is -1.02 mm; adjacent same-row contacts are 2.04 mm apart; rows are 4.00 mm apart; the full contact x span is 7.14 mm. Center the drawing on pin 1 and rotate it 180 degrees: expected dossier coordinates are pin n = (1.02*(n-1), 0 for odd n or 4 for even n). The mouth then faces negative local y. This is a proper rotation with determinant +1, not a mirror.

The eight contacts zigzag across two staggered rows; they do not number around a perimeter. The signed polygon area of contact identities 1–8 is zero. A package winding label is therefore not applicable. Including artifact shield numbers 9 and 10 can generate a numerical 'CCW' label, but the manufacturer does not number those tabs and the result does not establish correct contact handedness. Individual positions provide the relevant evidence. The computed W/N/S/E labels are centroid sectors, not manufacturer package-side names.

The shield mounting slot centers are separated by 14.8 mm. Their horizontal center is 3.57 mm left of pin 1 in the manufacturer drawing, giving offsets -10.97 and +3.83 mm. Their y offset from the near-mouth contact row is 3.30+3.05-4.00=2.35 mm toward the mouth. Following the same 180-degree rotation, they are at (+10.97,-2.35) and (-3.83,-2.35). The dossier calls these separate physical terminals pads 9/SHIELD_S1 and 10/SHIELD_S2. These are artifact names, not manufacturer contact numbers. Both physical terminals survive as distinct pads on CHASSIS; no fused alias or identity collapse is used.

Counts measured from each native dossier: 10 numbered coordinate rows, 10 distinct pad identities, 8 contacts, 2 shields. Each dossier separately reports 2 unnumbered mechanical/paste pads that it omits from its coordinate table, so the reported total is 12 native pad objects. Their geometry and drill dimensions are not measured by this pin dossier. The primary figure has two locating pegs; full mechanical/drill footprint validation is outside this pin-identity review. No exposed copper pad is required.

Electrical interpretation: manufacturer CONTACT_1 through CONTACT_8 are passive insulated contacts, not prescribed Ethernet/POD power or audio signals. No prescribed application net assignment exists in this PDF. The dossiers retain each contact independently: 1/3/7 to the same instance's 12V_PODn; 2/6/8 to GND; 4 to AUDIO_Nn; 5 to AUDIO_Pn; both shields to CHASSIS. These are compatible net kinds for the device's actual contact and shield functions. This pin review does not establish the external cable or remote equipment assignment, delivered current, audio polarity end-to-end, or permission to connect Ethernet equipment. Those are separate system-interface checks, not facts established by this passive-jack datasheet.

All eight full native coordinate tables were read and parsed. The independent expected coordinate map above was compared to every numbered native pad. Front mounting requires no reflection. For J1–J4 the native coordinate is origin plus local coordinate at 0 degrees. For J5–J8 the native coordinate is origin minus local coordinate at 180 degrees. All 80 numbered pads satisfy their declared frame conversion, all 80 preserve the expected physical identity, and all eight instances have the same function/net-kind pattern with their own instance suffix. The mechanical omission described above is retained explicitly, not counted as a measured geometry check.

Engineering conclusion: all commissioned refs PASS for the defined pin-review domain. No electrical/package pin error or required pin-context question was found. This is limited group coverage only and gives no whole-board or order acceptance. Order verdict remains DO-NOT-ORDER because this is a pre-route pin review.

Execution record: initial task/protocol/J1/envelope and runtime signature bootstrap reads used exec_command read-only shell commands; subsequent engineering rendering, extraction, full-dossier read, and measurement used finite direct argv under shared pipeline_runtime.run_stage, with explicit cwd/environment and retained raw combined stdout/stderr plus runtime JSON. Bootstrap did not run an engineering validator or mutate an input. Shared task inputs are digest-verified before rendering, after rendering, after measurement, and at packaging/preflight. Only the allocated scratch and outputs directories were written.


## J1

VERDICT: PASS

Measured: 10 numbered native pads / 10 distinct physical electrical identities = 8 contacts + 2 shield terminals; 0 EP. Dossier reports 2 additional unnumbered mechanical pads, omitted from its coordinate table; reported native total 12, measured electrical total 10. Mounted front, rotation 0 degrees. Primary: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Recommended Hole Pattern / Dimensions and page 2 Article Properties.

| Pin / function | Expected from primary physical map (mm) | Observed local / native (mm) | Observed net / result |
|---|---|---|---|
| 1 / CONTACT_1 | [0.0, 0.0]; passive contact; no manufacturer-prescribed application net | [0.0, 0.0] / [36.0, 25.86] | 12V_POD1; PASS |
| 2 / CONTACT_2 | [1.02, 4.0]; passive contact; no manufacturer-prescribed application net | [1.02, 4.0] / [37.02, 29.86] | GND; PASS |
| 3 / CONTACT_3 | [2.04, 0.0]; passive contact; no manufacturer-prescribed application net | [2.04, 0.0] / [38.04, 25.86] | 12V_POD1; PASS |
| 4 / CONTACT_4 | [3.06, 4.0]; passive contact; no manufacturer-prescribed application net | [3.06, 4.0] / [39.06, 29.86] | AUDIO_N1; PASS |
| 5 / CONTACT_5 | [4.08, 0.0]; passive contact; no manufacturer-prescribed application net | [4.08, 0.0] / [40.08, 25.86] | AUDIO_P1; PASS |
| 6 / CONTACT_6 | [5.1, 4.0]; passive contact; no manufacturer-prescribed application net | [5.1, 4.0] / [41.1, 29.86] | GND; PASS |
| 7 / CONTACT_7 | [6.12, 0.0]; passive contact; no manufacturer-prescribed application net | [6.12, 0.0] / [42.12, 25.86] | 12V_POD1; PASS |
| 8 / CONTACT_8 | [7.14, 4.0]; passive contact; no manufacturer-prescribed application net | [7.14, 4.0] / [43.14, 29.86] | GND; PASS |
| 9 / SHIELD_S1 | [10.97, -2.35]; separate shell terminal; chassis-type net | [10.97, -2.35] / [46.97, 23.51] | CHASSIS; PASS |
| 10 / SHIELD_S2 | [-3.83, -2.35]; separate shell terminal; chassis-type net | [-3.83, -2.35] / [32.17, 23.51] | CHASSIS; PASS |

Pin 1, all eight individual contact positions, both separate shield identities, native/component-top conversion, and instance net-kind symmetry match. No fused alias is used. Perimeter winding is inapplicable to the staggered contact rows; the dossier CCW label is not an acceptance criterion.

## J2

VERDICT: PASS

Measured: 10 numbered native pads / 10 distinct physical electrical identities = 8 contacts + 2 shield terminals; 0 EP. Dossier reports 2 additional unnumbered mechanical pads, omitted from its coordinate table; reported native total 12, measured electrical total 10. Mounted front, rotation 0 degrees. Primary: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Recommended Hole Pattern / Dimensions and page 2 Article Properties.

| Pin / function | Expected from primary physical map (mm) | Observed local / native (mm) | Observed net / result |
|---|---|---|---|
| 1 / CONTACT_1 | [0.0, 0.0]; passive contact; no manufacturer-prescribed application net | [0.0, 0.0] / [68.0, 25.86] | 12V_POD2; PASS |
| 2 / CONTACT_2 | [1.02, 4.0]; passive contact; no manufacturer-prescribed application net | [1.02, 4.0] / [69.02, 29.86] | GND; PASS |
| 3 / CONTACT_3 | [2.04, 0.0]; passive contact; no manufacturer-prescribed application net | [2.04, 0.0] / [70.04, 25.86] | 12V_POD2; PASS |
| 4 / CONTACT_4 | [3.06, 4.0]; passive contact; no manufacturer-prescribed application net | [3.06, 4.0] / [71.06, 29.86] | AUDIO_N2; PASS |
| 5 / CONTACT_5 | [4.08, 0.0]; passive contact; no manufacturer-prescribed application net | [4.08, 0.0] / [72.08, 25.86] | AUDIO_P2; PASS |
| 6 / CONTACT_6 | [5.1, 4.0]; passive contact; no manufacturer-prescribed application net | [5.1, 4.0] / [73.1, 29.86] | GND; PASS |
| 7 / CONTACT_7 | [6.12, 0.0]; passive contact; no manufacturer-prescribed application net | [6.12, 0.0] / [74.12, 25.86] | 12V_POD2; PASS |
| 8 / CONTACT_8 | [7.14, 4.0]; passive contact; no manufacturer-prescribed application net | [7.14, 4.0] / [75.14, 29.86] | GND; PASS |
| 9 / SHIELD_S1 | [10.97, -2.35]; separate shell terminal; chassis-type net | [10.97, -2.35] / [78.97, 23.51] | CHASSIS; PASS |
| 10 / SHIELD_S2 | [-3.83, -2.35]; separate shell terminal; chassis-type net | [-3.83, -2.35] / [64.17, 23.51] | CHASSIS; PASS |

Pin 1, all eight individual contact positions, both separate shield identities, native/component-top conversion, and instance net-kind symmetry match. No fused alias is used. Perimeter winding is inapplicable to the staggered contact rows; the dossier CCW label is not an acceptance criterion.

## J3

VERDICT: PASS

Measured: 10 numbered native pads / 10 distinct physical electrical identities = 8 contacts + 2 shield terminals; 0 EP. Dossier reports 2 additional unnumbered mechanical pads, omitted from its coordinate table; reported native total 12, measured electrical total 10. Mounted front, rotation 0 degrees. Primary: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Recommended Hole Pattern / Dimensions and page 2 Article Properties.

| Pin / function | Expected from primary physical map (mm) | Observed local / native (mm) | Observed net / result |
|---|---|---|---|
| 1 / CONTACT_1 | [0.0, 0.0]; passive contact; no manufacturer-prescribed application net | [0.0, 0.0] / [100.0, 25.86] | 12V_POD3; PASS |
| 2 / CONTACT_2 | [1.02, 4.0]; passive contact; no manufacturer-prescribed application net | [1.02, 4.0] / [101.02, 29.86] | GND; PASS |
| 3 / CONTACT_3 | [2.04, 0.0]; passive contact; no manufacturer-prescribed application net | [2.04, 0.0] / [102.04, 25.86] | 12V_POD3; PASS |
| 4 / CONTACT_4 | [3.06, 4.0]; passive contact; no manufacturer-prescribed application net | [3.06, 4.0] / [103.06, 29.86] | AUDIO_N3; PASS |
| 5 / CONTACT_5 | [4.08, 0.0]; passive contact; no manufacturer-prescribed application net | [4.08, 0.0] / [104.08, 25.86] | AUDIO_P3; PASS |
| 6 / CONTACT_6 | [5.1, 4.0]; passive contact; no manufacturer-prescribed application net | [5.1, 4.0] / [105.1, 29.86] | GND; PASS |
| 7 / CONTACT_7 | [6.12, 0.0]; passive contact; no manufacturer-prescribed application net | [6.12, 0.0] / [106.12, 25.86] | 12V_POD3; PASS |
| 8 / CONTACT_8 | [7.14, 4.0]; passive contact; no manufacturer-prescribed application net | [7.14, 4.0] / [107.14, 29.86] | GND; PASS |
| 9 / SHIELD_S1 | [10.97, -2.35]; separate shell terminal; chassis-type net | [10.97, -2.35] / [110.97, 23.51] | CHASSIS; PASS |
| 10 / SHIELD_S2 | [-3.83, -2.35]; separate shell terminal; chassis-type net | [-3.83, -2.35] / [96.17, 23.51] | CHASSIS; PASS |

Pin 1, all eight individual contact positions, both separate shield identities, native/component-top conversion, and instance net-kind symmetry match. No fused alias is used. Perimeter winding is inapplicable to the staggered contact rows; the dossier CCW label is not an acceptance criterion.

## J4

VERDICT: PASS

Measured: 10 numbered native pads / 10 distinct physical electrical identities = 8 contacts + 2 shield terminals; 0 EP. Dossier reports 2 additional unnumbered mechanical pads, omitted from its coordinate table; reported native total 12, measured electrical total 10. Mounted front, rotation 0 degrees. Primary: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Recommended Hole Pattern / Dimensions and page 2 Article Properties.

| Pin / function | Expected from primary physical map (mm) | Observed local / native (mm) | Observed net / result |
|---|---|---|---|
| 1 / CONTACT_1 | [0.0, 0.0]; passive contact; no manufacturer-prescribed application net | [0.0, 0.0] / [132.0, 25.86] | 12V_POD4; PASS |
| 2 / CONTACT_2 | [1.02, 4.0]; passive contact; no manufacturer-prescribed application net | [1.02, 4.0] / [133.02, 29.86] | GND; PASS |
| 3 / CONTACT_3 | [2.04, 0.0]; passive contact; no manufacturer-prescribed application net | [2.04, 0.0] / [134.04, 25.86] | 12V_POD4; PASS |
| 4 / CONTACT_4 | [3.06, 4.0]; passive contact; no manufacturer-prescribed application net | [3.06, 4.0] / [135.06, 29.86] | AUDIO_N4; PASS |
| 5 / CONTACT_5 | [4.08, 0.0]; passive contact; no manufacturer-prescribed application net | [4.08, 0.0] / [136.08, 25.86] | AUDIO_P4; PASS |
| 6 / CONTACT_6 | [5.1, 4.0]; passive contact; no manufacturer-prescribed application net | [5.1, 4.0] / [137.1, 29.86] | GND; PASS |
| 7 / CONTACT_7 | [6.12, 0.0]; passive contact; no manufacturer-prescribed application net | [6.12, 0.0] / [138.12, 25.86] | 12V_POD4; PASS |
| 8 / CONTACT_8 | [7.14, 4.0]; passive contact; no manufacturer-prescribed application net | [7.14, 4.0] / [139.14, 29.86] | GND; PASS |
| 9 / SHIELD_S1 | [10.97, -2.35]; separate shell terminal; chassis-type net | [10.97, -2.35] / [142.97, 23.51] | CHASSIS; PASS |
| 10 / SHIELD_S2 | [-3.83, -2.35]; separate shell terminal; chassis-type net | [-3.83, -2.35] / [128.17, 23.51] | CHASSIS; PASS |

Pin 1, all eight individual contact positions, both separate shield identities, native/component-top conversion, and instance net-kind symmetry match. No fused alias is used. Perimeter winding is inapplicable to the staggered contact rows; the dossier CCW label is not an acceptance criterion.

## J5

VERDICT: PASS

Measured: 10 numbered native pads / 10 distinct physical electrical identities = 8 contacts + 2 shield terminals; 0 EP. Dossier reports 2 additional unnumbered mechanical pads, omitted from its coordinate table; reported native total 12, measured electrical total 10. Mounted front, rotation 180 degrees. Primary: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Recommended Hole Pattern / Dimensions and page 2 Article Properties.

| Pin / function | Expected from primary physical map (mm) | Observed local / native (mm) | Observed net / result |
|---|---|---|---|
| 1 / CONTACT_1 | [0.0, 0.0]; passive contact; no manufacturer-prescribed application net | [0.0, 0.0] / [45.0, 114.14] | 12V_POD5; PASS |
| 2 / CONTACT_2 | [1.02, 4.0]; passive contact; no manufacturer-prescribed application net | [1.02, 4.0] / [43.98, 110.14] | GND; PASS |
| 3 / CONTACT_3 | [2.04, 0.0]; passive contact; no manufacturer-prescribed application net | [2.04, 0.0] / [42.96, 114.14] | 12V_POD5; PASS |
| 4 / CONTACT_4 | [3.06, 4.0]; passive contact; no manufacturer-prescribed application net | [3.06, 4.0] / [41.94, 110.14] | AUDIO_N5; PASS |
| 5 / CONTACT_5 | [4.08, 0.0]; passive contact; no manufacturer-prescribed application net | [4.08, 0.0] / [40.92, 114.14] | AUDIO_P5; PASS |
| 6 / CONTACT_6 | [5.1, 4.0]; passive contact; no manufacturer-prescribed application net | [5.1, 4.0] / [39.9, 110.14] | GND; PASS |
| 7 / CONTACT_7 | [6.12, 0.0]; passive contact; no manufacturer-prescribed application net | [6.12, 0.0] / [38.88, 114.14] | 12V_POD5; PASS |
| 8 / CONTACT_8 | [7.14, 4.0]; passive contact; no manufacturer-prescribed application net | [7.14, 4.0] / [37.86, 110.14] | GND; PASS |
| 9 / SHIELD_S1 | [10.97, -2.35]; separate shell terminal; chassis-type net | [10.97, -2.35] / [34.03, 116.49] | CHASSIS; PASS |
| 10 / SHIELD_S2 | [-3.83, -2.35]; separate shell terminal; chassis-type net | [-3.83, -2.35] / [48.83, 116.49] | CHASSIS; PASS |

Pin 1, all eight individual contact positions, both separate shield identities, native/component-top conversion, and instance net-kind symmetry match. No fused alias is used. Perimeter winding is inapplicable to the staggered contact rows; the dossier CCW label is not an acceptance criterion.

## J6

VERDICT: PASS

Measured: 10 numbered native pads / 10 distinct physical electrical identities = 8 contacts + 2 shield terminals; 0 EP. Dossier reports 2 additional unnumbered mechanical pads, omitted from its coordinate table; reported native total 12, measured electrical total 10. Mounted front, rotation 180 degrees. Primary: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Recommended Hole Pattern / Dimensions and page 2 Article Properties.

| Pin / function | Expected from primary physical map (mm) | Observed local / native (mm) | Observed net / result |
|---|---|---|---|
| 1 / CONTACT_1 | [0.0, 0.0]; passive contact; no manufacturer-prescribed application net | [0.0, 0.0] / [77.0, 114.14] | 12V_POD6; PASS |
| 2 / CONTACT_2 | [1.02, 4.0]; passive contact; no manufacturer-prescribed application net | [1.02, 4.0] / [75.98, 110.14] | GND; PASS |
| 3 / CONTACT_3 | [2.04, 0.0]; passive contact; no manufacturer-prescribed application net | [2.04, 0.0] / [74.96, 114.14] | 12V_POD6; PASS |
| 4 / CONTACT_4 | [3.06, 4.0]; passive contact; no manufacturer-prescribed application net | [3.06, 4.0] / [73.94, 110.14] | AUDIO_N6; PASS |
| 5 / CONTACT_5 | [4.08, 0.0]; passive contact; no manufacturer-prescribed application net | [4.08, 0.0] / [72.92, 114.14] | AUDIO_P6; PASS |
| 6 / CONTACT_6 | [5.1, 4.0]; passive contact; no manufacturer-prescribed application net | [5.1, 4.0] / [71.9, 110.14] | GND; PASS |
| 7 / CONTACT_7 | [6.12, 0.0]; passive contact; no manufacturer-prescribed application net | [6.12, 0.0] / [70.88, 114.14] | 12V_POD6; PASS |
| 8 / CONTACT_8 | [7.14, 4.0]; passive contact; no manufacturer-prescribed application net | [7.14, 4.0] / [69.86, 110.14] | GND; PASS |
| 9 / SHIELD_S1 | [10.97, -2.35]; separate shell terminal; chassis-type net | [10.97, -2.35] / [66.03, 116.49] | CHASSIS; PASS |
| 10 / SHIELD_S2 | [-3.83, -2.35]; separate shell terminal; chassis-type net | [-3.83, -2.35] / [80.83, 116.49] | CHASSIS; PASS |

Pin 1, all eight individual contact positions, both separate shield identities, native/component-top conversion, and instance net-kind symmetry match. No fused alias is used. Perimeter winding is inapplicable to the staggered contact rows; the dossier CCW label is not an acceptance criterion.

## J7

VERDICT: PASS

Measured: 10 numbered native pads / 10 distinct physical electrical identities = 8 contacts + 2 shield terminals; 0 EP. Dossier reports 2 additional unnumbered mechanical pads, omitted from its coordinate table; reported native total 12, measured electrical total 10. Mounted front, rotation 180 degrees. Primary: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Recommended Hole Pattern / Dimensions and page 2 Article Properties.

| Pin / function | Expected from primary physical map (mm) | Observed local / native (mm) | Observed net / result |
|---|---|---|---|
| 1 / CONTACT_1 | [0.0, 0.0]; passive contact; no manufacturer-prescribed application net | [0.0, 0.0] / [109.0, 114.14] | 12V_POD7; PASS |
| 2 / CONTACT_2 | [1.02, 4.0]; passive contact; no manufacturer-prescribed application net | [1.02, 4.0] / [107.98, 110.14] | GND; PASS |
| 3 / CONTACT_3 | [2.04, 0.0]; passive contact; no manufacturer-prescribed application net | [2.04, 0.0] / [106.96, 114.14] | 12V_POD7; PASS |
| 4 / CONTACT_4 | [3.06, 4.0]; passive contact; no manufacturer-prescribed application net | [3.06, 4.0] / [105.94, 110.14] | AUDIO_N7; PASS |
| 5 / CONTACT_5 | [4.08, 0.0]; passive contact; no manufacturer-prescribed application net | [4.08, 0.0] / [104.92, 114.14] | AUDIO_P7; PASS |
| 6 / CONTACT_6 | [5.1, 4.0]; passive contact; no manufacturer-prescribed application net | [5.1, 4.0] / [103.9, 110.14] | GND; PASS |
| 7 / CONTACT_7 | [6.12, 0.0]; passive contact; no manufacturer-prescribed application net | [6.12, 0.0] / [102.88, 114.14] | 12V_POD7; PASS |
| 8 / CONTACT_8 | [7.14, 4.0]; passive contact; no manufacturer-prescribed application net | [7.14, 4.0] / [101.86, 110.14] | GND; PASS |
| 9 / SHIELD_S1 | [10.97, -2.35]; separate shell terminal; chassis-type net | [10.97, -2.35] / [98.03, 116.49] | CHASSIS; PASS |
| 10 / SHIELD_S2 | [-3.83, -2.35]; separate shell terminal; chassis-type net | [-3.83, -2.35] / [112.83, 116.49] | CHASSIS; PASS |

Pin 1, all eight individual contact positions, both separate shield identities, native/component-top conversion, and instance net-kind symmetry match. No fused alias is used. Perimeter winding is inapplicable to the staggered contact rows; the dossier CCW label is not an acceptance criterion.

## J8

VERDICT: PASS

Measured: 10 numbered native pads / 10 distinct physical electrical identities = 8 contacts + 2 shield terminals; 0 EP. Dossier reports 2 additional unnumbered mechanical pads, omitted from its coordinate table; reported native total 12, measured electrical total 10. Mounted front, rotation 180 degrees. Primary: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Recommended Hole Pattern / Dimensions and page 2 Article Properties.

| Pin / function | Expected from primary physical map (mm) | Observed local / native (mm) | Observed net / result |
|---|---|---|---|
| 1 / CONTACT_1 | [0.0, 0.0]; passive contact; no manufacturer-prescribed application net | [0.0, 0.0] / [141.0, 114.14] | 12V_POD8; PASS |
| 2 / CONTACT_2 | [1.02, 4.0]; passive contact; no manufacturer-prescribed application net | [1.02, 4.0] / [139.98, 110.14] | GND; PASS |
| 3 / CONTACT_3 | [2.04, 0.0]; passive contact; no manufacturer-prescribed application net | [2.04, 0.0] / [138.96, 114.14] | 12V_POD8; PASS |
| 4 / CONTACT_4 | [3.06, 4.0]; passive contact; no manufacturer-prescribed application net | [3.06, 4.0] / [137.94, 110.14] | AUDIO_N8; PASS |
| 5 / CONTACT_5 | [4.08, 0.0]; passive contact; no manufacturer-prescribed application net | [4.08, 0.0] / [136.92, 114.14] | AUDIO_P8; PASS |
| 6 / CONTACT_6 | [5.1, 4.0]; passive contact; no manufacturer-prescribed application net | [5.1, 4.0] / [135.9, 110.14] | GND; PASS |
| 7 / CONTACT_7 | [6.12, 0.0]; passive contact; no manufacturer-prescribed application net | [6.12, 0.0] / [134.88, 114.14] | 12V_POD8; PASS |
| 8 / CONTACT_8 | [7.14, 4.0]; passive contact; no manufacturer-prescribed application net | [7.14, 4.0] / [133.86, 110.14] | GND; PASS |
| 9 / SHIELD_S1 | [10.97, -2.35]; separate shell terminal; chassis-type net | [10.97, -2.35] / [130.03, 116.49] | CHASSIS; PASS |
| 10 / SHIELD_S2 | [-3.83, -2.35]; separate shell terminal; chassis-type net | [-3.83, -2.35] / [144.83, 116.49] | CHASSIS; PASS |

Pin 1, all eight individual contact positions, both separate shield identities, native/component-top conversion, and instance net-kind symmetry match. No fused alias is used. Perimeter winding is inapplicable to the staggered contact rows; the dossier CCW label is not an acceptance criterion.

Unresolved pin-review findings: none. All eight refs PASS. No claim is made about external cable assignment, remote equipment compatibility, full drill/peg geometry, load current, or whole-board acceptance.


## Verbatim independent report — rj45-pin-carrier-logic-mountedframe1

review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent /root/rj45_pin_carrier_logic_mountedframe1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

Subject (immutable envelope metadata):
{"raw_sha256": "5035a4d897f169e70096073dfe221a95a45b494846553f7ca37e4bc23044e9b2", "semantic_sha256": "f2ce897f9a1f65c14eaa0443a94b89f74134c0cb364ab000bf5a330284f5670f"}

Only U_DUMP,U_LDO_EN,U_OE,U_TDM,U_TDM_SCH. No whole-board acceptance. Pin/package review does not certify timing, drive strength, power-state system behavior, placement or routing.

All five commissioned references PASS. No unresolved pin findings. Total measured native pads:25; physical identities:25; EP:0; alias collapses:0. The three SHA fields above are immutable subject bindings, not reviewed whole-board conclusions.

## Independent method

- Fresh independent agent /root/rj45_pin_carrier_logic_mountedframe1. Only frozen protocol, native dossiers and exact envelope-selected primary PDFs used for engineering judgment. No live project, schematic, history, or children inspected. Embedded dossier verification notes were not used as authority.
- Verified all 11 input size and SHA256 bindings before review and again after engineering. Exact envelope subject is metadata, not a whole-board reviewed conclusion.
- Rendered PDF figures with pdftoppm and opened actual PNGs with view_image before reading native pad dossiers. Datasheet-first derivation retained in independent-expectations.md. Text extraction supplemented electrical tables; it was not used to establish winding.
- Viewed Nexperia 14/17 pages2,3,11 and TI125 pages3,26. Pinout coordinate convention is component top +x right/+y down. Nexperia mechanical top plans use a 90-degree rotation from the pin diagrams; no bottom-view mirror is needed. TI DBV drawing explicitly TOP VIEW; other-package bottom views excluded.
- Recomputed native row count, unique pin numbers, side counts, shoelace winding, and native-coordinate residuals from the dossiers using measure.py. Five separate manufacturer lead identities match five individual dossier pads per instance; no alias declarations or fused lands are required.
- Checked every pin function/net class, 1.65..5.5 V supply compatibility (Nexperia page5 Table6; TI page5 section5.3), inverter versus buffer behavior (Nexperia page4 Table4), and active-low enable (TI page11 Table7-1).
- Checked pairwise symmetry among all three 74LVC1G14 instances and same-package 74LVC1G17. Checked observed shared nets U_DUMP.Y -> U_LDO_EN.A, U_OE.Y -> U_TDM./OE, and U_TDM_SCH.Y -> U_TDM.A.
- Finite direct-argv subprocesses executed under shared pipeline_runtime.run_stage with explicit cwd/environment; raw merged stdout/stderr and runtime receipts retained. One failed /usr/bin/rg launch is retained; successful Python-only package locator replaced that unavailable executable, without replacement of review agent.
- Evidence archive reopens every regular member and verifies path, size and SHA256; no symlinks, traversal, duplicate paths or nested archives. Final delivery preflight is run against the exact envelope.

## U_DUMP

VERDICT: PASS
Part: 74LVC1G14GV,125. Native pad count:5; physical identity count:5; unique pin numbers:5; EP count:0; aliased identities:0.
Primary: projects/crow-audio-carrier-v1/02_parts/74LVC1G14GV,125/74LVC1G14_Rev19.pdf
SHA256: b8f37c700d0fc8374de6d14f0e2caf310c34b480ffab9d63c69bb3b6defbebbf
PDF page 3, GV package SOT753, drawing aaa-035749, and Table 3; PDF page 11, Fig. 13 SOT753.

Expected five distinct leads, no EP, no fused aliases; observed five native pads numbered 1..5, five distinct physical identities, zero EP and zero alias collapses. Expected CCW top-view winding with pin1 upper-left, pins1/2/3 west and 4/5 east; observed precisely that geometry. All instances are front-mounted F.Cu at 0 degrees. Manufacturer pinout and component-top dossier agree at zero rotation, with no mirror. Native coordinates minus board position reproduce local coordinates within floating-point roundoff (<2e-14 mm). Row pitch is 0.95 mm and end span is 1.9 mm, matching mechanical drawings.

U_DUMP pin 1 (NC): expected NC with no functional net vs observed NC on unconnected-(U_DUMP-NC-Pad1) (native isolated unconnected marker); PASS.
U_DUMP pin 2 (A): expected A logic input on a signal net vs observed A on DUMP_RC; PASS.
U_DUMP pin 3 (GND): expected GND on ground vs observed GND on GND; PASS.
U_DUMP pin 4 (Y): expected Y buffer/logic output on a signal net vs observed Y on DUMP_GATE; PASS.
U_DUMP pin 5 (VCC): expected VCC power supply within 1.65..5.5 V vs observed VCC on 5V_LDO_HOLD (nominal 5 V rail); PASS.

## U_LDO_EN

VERDICT: PASS
Part: 74LVC1G14GV,125. Native pad count:5; physical identity count:5; unique pin numbers:5; EP count:0; aliased identities:0.
Primary: projects/crow-audio-carrier-v1/02_parts/74LVC1G14GV,125/74LVC1G14_Rev19.pdf
SHA256: b8f37c700d0fc8374de6d14f0e2caf310c34b480ffab9d63c69bb3b6defbebbf
PDF page 3, GV package SOT753, drawing aaa-035749, and Table 3; PDF page 11, Fig. 13 SOT753.

Expected five distinct leads, no EP, no fused aliases; observed five native pads numbered 1..5, five distinct physical identities, zero EP and zero alias collapses. Expected CCW top-view winding with pin1 upper-left, pins1/2/3 west and 4/5 east; observed precisely that geometry. All instances are front-mounted F.Cu at 0 degrees. Manufacturer pinout and component-top dossier agree at zero rotation, with no mirror. Native coordinates minus board position reproduce local coordinates within floating-point roundoff (<2e-14 mm). Row pitch is 0.95 mm and end span is 1.9 mm, matching mechanical drawings.

U_LDO_EN pin 1 (NC): expected NC with no functional net vs observed NC on unconnected-(U_LDO_EN-NC-Pad1) (native isolated unconnected marker); PASS.
U_LDO_EN pin 2 (A): expected A logic input on a signal net vs observed A on DUMP_GATE; PASS.
U_LDO_EN pin 3 (GND): expected GND on ground vs observed GND on GND; PASS.
U_LDO_EN pin 4 (Y): expected Y buffer/logic output on a signal net vs observed Y on LDO_EN; PASS.
U_LDO_EN pin 5 (VCC): expected VCC power supply within 1.65..5.5 V vs observed VCC on 5V_LDO_HOLD (nominal 5 V rail); PASS.

## U_OE

VERDICT: PASS
Part: 74LVC1G14GV,125. Native pad count:5; physical identity count:5; unique pin numbers:5; EP count:0; aliased identities:0.
Primary: projects/crow-audio-carrier-v1/02_parts/74LVC1G14GV,125/74LVC1G14_Rev19.pdf
SHA256: b8f37c700d0fc8374de6d14f0e2caf310c34b480ffab9d63c69bb3b6defbebbf
PDF page 3, GV package SOT753, drawing aaa-035749, and Table 3; PDF page 11, Fig. 13 SOT753.

Expected five distinct leads, no EP, no fused aliases; observed five native pads numbered 1..5, five distinct physical identities, zero EP and zero alias collapses. Expected CCW top-view winding with pin1 upper-left, pins1/2/3 west and 4/5 east; observed precisely that geometry. All instances are front-mounted F.Cu at 0 degrees. Manufacturer pinout and component-top dossier agree at zero rotation, with no mirror. Native coordinates minus board position reproduce local coordinates within floating-point roundoff (<2e-14 mm). Row pitch is 0.95 mm and end span is 1.9 mm, matching mechanical drawings.

U_OE pin 1 (NC): expected NC with no functional net vs observed NC on unconnected-(U_OE-NC-Pad1) (native isolated unconnected marker); PASS.
U_OE pin 2 (A): expected A logic input on a signal net vs observed A on TDM_SENSE_G; PASS.
U_OE pin 3 (GND): expected GND on ground vs observed GND on GND; PASS.
U_OE pin 4 (Y): expected Y buffer/logic output on a signal net vs observed Y on TDM_OE_N; PASS.
U_OE pin 5 (VCC): expected VCC power supply within 1.65..5.5 V vs observed VCC on 3V3_ADC (nominal 3.3 V rail); PASS.

## U_TDM

VERDICT: PASS
Part: SN74LVC1G125DBVR. Native pad count:5; physical identity count:5; unique pin numbers:5; EP count:0; aliased identities:0.
Primary: projects/crow-audio-carrier-v1/02_parts/SN74LVC1G125DBVR/SN74LVC1G125_SCES223U.pdf
SHA256: 65afa3f9d879b37cb8be507caf84804b24bceeb2e0782ba449fff72160994e4c
PDF page 3, DBV PACKAGE (TOP VIEW), section 4; PDF page 26, DBV0005A / 4214839/K.

Expected five distinct leads, no EP, no fused aliases; observed five native pads numbered 1..5, five distinct physical identities, zero EP and zero alias collapses. Expected CCW top-view winding with pin1 upper-left, pins1/2/3 west and 4/5 east; observed precisely that geometry. All instances are front-mounted F.Cu at 0 degrees. Manufacturer pinout and component-top dossier agree at zero rotation, with no mirror. Native coordinates minus board position reproduce local coordinates within floating-point roundoff (<2e-14 mm). Row pitch is 0.95 mm and end span is 1.9 mm, matching mechanical drawings.

U_TDM pin 1 (OE_N): expected active-low output-enable input on an enable/control net vs observed OE_N on TDM_OE_N; PASS.
U_TDM pin 2 (A): expected A logic input on a signal net vs observed A on TDM_CLEAN; PASS.
U_TDM pin 3 (GND): expected GND on ground vs observed GND on GND; PASS.
U_TDM pin 4 (Y): expected Y buffer/logic output on a signal net vs observed Y on TDM_BUFFERED; PASS.
U_TDM pin 5 (VCC): expected VCC power supply within 1.65..5.5 V vs observed VCC on 3V3_ADC (nominal 3.3 V rail); PASS.

## U_TDM_SCH

VERDICT: PASS
Part: 74LVC1G17GV,125. Native pad count:5; physical identity count:5; unique pin numbers:5; EP count:0; aliased identities:0.
Primary: projects/crow-audio-carrier-v1/02_parts/74LVC1G17GV,125/74LVC1G17.pdf
SHA256: 3db133d57486306950ba1140ac13a8a0ea95509dcefb88db36c08423a819b163
PDF page 3, GV package SOT753, drawing aaa-035749, and Table 3; PDF page 11, Fig. 11 SOT753.

Expected five distinct leads, no EP, no fused aliases; observed five native pads numbered 1..5, five distinct physical identities, zero EP and zero alias collapses. Expected CCW top-view winding with pin1 upper-left, pins1/2/3 west and 4/5 east; observed precisely that geometry. All instances are front-mounted F.Cu at 0 degrees. Manufacturer pinout and component-top dossier agree at zero rotation, with no mirror. Native coordinates minus board position reproduce local coordinates within floating-point roundoff (<2e-14 mm). Row pitch is 0.95 mm and end span is 1.9 mm, matching mechanical drawings.

U_TDM_SCH pin 1 (NC): expected NC with no functional net vs observed NC on unconnected-(U_TDM_SCH-NC-Pad1) (native isolated unconnected marker); PASS.
U_TDM_SCH pin 2 (A): expected A logic input on a signal net vs observed A on TDM_RAW; PASS.
U_TDM_SCH pin 3 (GND): expected GND on ground vs observed GND on GND; PASS.
U_TDM_SCH pin 4 (Y): expected Y buffer/logic output on a signal net vs observed Y on TDM_CLEAN; PASS.
U_TDM_SCH pin 5 (VCC): expected VCC power supply within 1.65..5.5 V vs observed VCC on 3V3_ADC (nominal 3.3 V rail); PASS.

## Instance symmetry

VERDICT: PASS
U_DUMP, U_LDO_EN and U_OE all preserve NC/A/GND/Y/VCC identities. Their 5V_LDO_HOLD versus 3V3_ADC supplies are both valid rail classes and within recommended operating supply range. U_TDM_SCH uses identical package/pin geometry but non-inverting logic. The shared-net dossier evidence connects DUMP_GATE from inverter Y to inverter A, TDM_OE_N from inverter Y to active-low enable pin1, and TDM_CLEAN from Schmitt-buffer Y to U_TDM input2. There is no structural power/input/output swap across the commissioned instances.

NC interpretation: all four NC pads use their own native unconnected-(ref-NC-Pad1) marker rather than a functional rail or signal net. They remain distinct physical pads; no same-net collapsing was assumed.

Geometry: measured signed component-top polygon area is -4.3225 mm² for each ref (CCW with y down). Individual pad centers are pin1(-1.1375,-0.95), pin2(-1.1375,0), pin3(-1.1375,+0.95), pin4(+1.1375,+0.95), pin5(+1.1375,-0.95) mm. All pad sizes are 1.32x0.6 mm. Package numbering, 0.95 mm pitch and five-lead identity census match the primary drawings; this is not a solder-joint process review.

Unresolved findings: none. Limited carrier-logic group verdict: SOUND. Order verdict remains DO-NOT-ORDER at pre-route.


## Verbatim independent report — rj45-pin-carrier-power-fets-mountedframe1

review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_power_fets_mountedframe1 (actual fresh agent)
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

Limited coverage: Q_IN and Q_PRE only, all commissioned instances. This is a pin-domain judgment from the supplied frozen dossiers and exact primary PDFs, not whole-board acceptance or authorization to order. The three SHA bindings above are immutable supplied subject metadata, not independently reviewed board-wide conclusions.

Q_IN — VERDICT: PASS

Primary: DMP6023LFG, DS37204 Rev. 2-2, January 2015, SHA-256 1ea244be5e0fe4195ad20cb2da0960ac622b6efc19cf9e579c9eb8ef5777fa27. Inspected images: PDF p.1 POWERDI3333-8 Bottom View/Top View/Equivalent Circuit, and p.5 Package Outline Dimensions and Suggested Pad Layout (unnumbered package figures).

Expected package: eight physical terminal identities, source 1–3, gate 4, and fused drain 5–8. The exposed drain paddle is electrically drain; no separate ninth ground/EP identity exists. The underside outline has 1 upper left, 4 upper right, 5 lower right, 8 lower left. Reflect that BOTTOM VIEW vertically once to obtain TOP VIEW: 1 lower left, 4 lower right, 5 upper right, 8 upper left. Then a clockwise 90-degree rotation in the screen frame (+x right, +y down) gives 1 upper left through 4 lower left, with drain 5–8 on the right, matching the dossier. Manufacturer top physical ordering is CCW. The p.5 suggested land pattern independently corroborates that conversion.

Observed: explicitly front-mounted at native rotation 0; local coordinates are COMPONENT-TOP, requiring no mounting reflection. The dossier's reported n/a winding for the collinear surviving perimeter row is appropriate: neither that row nor one fused drain centroid is a measurement of the full eight-pin winding. Individual source/gate identities and the drain side resolve the orientation without a further mirror. Native-to-local coordinate checks agree within 1.5e-14 mm numerical residual.

Measured census from the native dossier table: 5 numbered records / 5 distinct native identities (1–5), plus 3 explicitly declared physical aliases (6,7,8 -> schematic 5 and footprint 5), preserving all 8 physical identities. The dossier separately reports 8 unnumbered paste/mechanical pads, excluded from terminal identity counts; their individual geometry is not present in the supplied table. The manufacturer p.1 copper image and p.5 connected drain land establish actual fusion, not merely equal nets. Each alias declares fused:true, a reason, and primary figure evidence. Central exposed drain copper is represented by pad 5, 1.71 x 2.37 mm, at local (+0.455,0).

Q_IN pin 1 (SOURCE): expected first marked source on the three-source row; observed (-1.5,-0.975), SOURCE, 12V_PROTECTED — agrees.
Q_IN pin 2 (SOURCE): expected next source on the same row; observed (-1.5,-0.325), SOURCE, 12V_PROTECTED — agrees.
Q_IN pin 3 (SOURCE): expected third source adjacent to gate; observed (-1.5,+0.325), SOURCE, 12V_PROTECTED — agrees.
Q_IN pin 4 (GATE): expected terminal at the opposite end of the source/gate row from pin 1; observed (-1.5,+0.975), GATE, Q_IN_GATE — agrees.
Q_IN pin 5 (DRAIN): expected the opposite-side common drain/exposed paddle; observed pad 5, DRAIN_COMMON, 12V_FUSED — agrees.
Q_IN pin 6 (DRAIN): expected the same manufacturer-fused drain; observed declared physical identity 6 aliased to pad 5, 12V_FUSED — agrees.
Q_IN pin 7 (DRAIN): expected the same manufacturer-fused drain; observed declared physical identity 7 aliased to pad 5, 12V_FUSED — agrees.
Q_IN pin 8 (DRAIN): expected the same manufacturer-fused drain; observed declared physical identity 8 aliased to pad 5, 12V_FUSED — agrees.

The p.1 P-channel equivalent circuit shows body-diode conduction D -> S, hence the observed mapping permits 12V_FUSED -> 12V_PROTECTED. This is electrically consistent with input protection net roles; the gate is on its named control net and both current terminals are rail nets. This pin check does not establish gate-bias values, switching timing, or voltage/transient adequacy.

Q_PRE — VERDICT: PASS

Primary: AO3401A Rev 3.1, December 2023, SHA-256 0d8e3261ae280e007b5837fff60c55142f2d92af71edc4d02aee6f7a760a785c. Inspected image: PDF p.1 SOT23 Top View/Bottom View and adjacent MOSFET equivalent circuit (unnumbered figures).

Expected package: three terminals and no exposed pad. In the manufacturer TOP VIEW the marked gate lead and source lead occupy the same two-lead edge; drain is the sole opposite lead. Physical G -> S -> D order is CCW when flattened into the top frame. The PDF identifies the terminals by G/S/D rather than printed numeric labels; the gate-adjacent dot establishes the marked corner. Acceptance is based on those directly pictured physical function positions, not on importing a different part's numeric pinout. A rotation aligns G at the upper-left paired position, S at lower left, and D on the right, as the dossier assigns 1,2,3. No top/bottom or mounting mirror is needed.

Observed: front mount, native rotation 180 degrees, with explicit COMPONENT-TOP coordinates. Measured census is 3 numbered native table records / 3 distinct identities / 3 physical terminals, no aliases, no EP. No unnumbered pads are reported. The 1 -> 2 -> 3 polygon has signed screen-coordinate area -1.78125 mm^2, confirming CCW, and the native 180-degree transform matches within 7.2e-15 mm. Cardinal N/S tags reflect the coordinate classifier; actual coordinates establish that 1 and 2 form the left pair.

Q_PRE pin 1 (G): expected the dot-adjacent paired gate lead; observed (-0.9375,-0.95), G, PRE_GATE — agrees.
Q_PRE pin 2 (S): expected the other paired source lead; observed (-0.9375,+0.95), S, 5V_LDO_FEED — agrees.
Q_PRE pin 3 (D): expected the sole opposite drain lead; observed (+0.9375,0), D, 5V_LDO_HOLD — agrees.

The pictured P-channel diode conducts D -> S, hence the mapping gives 5V_LDO_HOLD -> 5V_LDO_FEED diode direction. Source on the feed rail and drain on the held rail are consistent with a controlled high-side P-channel switch; the gate is on PRE_GATE. The dossier does not establish rail timing or control voltage, and no such claim is made.

Instance symmetry: both commissioned FETs were individually checked. They are different packages, so literal pin numbers are not comparable across the pair. In both cases every gate goes to a named gate-control net, source/drain identities go to rail nets, and common-terminal identities are consistent. The different body-diode direction relative to the named input/output rails follows the observed input-protection versus feed-switch connection; there is no physical function/net-class swap. No additional instances of either device are supplied or claimed reviewed.

Methods and integrity: all envelope inputs hash/size verified before and after review. Primary figures were rendered using bounded direct-argv pdftoppm calls through shared pipeline_runtime.run_stage, then visually inspected with view_image before dossier comparison. pdftotext assisted page navigation only. Independent figure expectations were recorded before opening dossiers. A retained Python method counted table identities/aliases and checked mounted-frame arithmetic. The archive preserves the inspected images, native dossier copies, exact input hash receipts, methods and subprocess raw logs/runtime. No live design source was inspected, and no children were delegated.

Unresolved findings: none within this commissioned pin domain. Both refs PASS; therefore the limited design verdict is SOUND. Order verdict remains DO-NOT-ORDER for this pre-route group-only review.


## Verbatim independent report — rj45-pin-carrier-rectifiers-mountedframe1

review_stage: pre-route
review_kind: pin
reviewer: fresh agent /root/rj45_pin_carrier_rectifiers_mountedframe1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

subject.raw_sha256: 8ca61cdfa828d55e100a2622527d3167977e7b08eee28bb75fc2b61cde88ca4d
subject.semantic_sha256: ab79b176f9b3a15f62813cb7237d8a96e3882477eab719519d36bbb2b9a1ae4f

All six commissioned references PASS. This is limited group coverage only, not whole-board acceptance. Order remains DO-NOT-ORDER. The three board/parts/rules bindings above are immutable supplied metadata, not independently reviewed whole-artifact conclusions.

Independent figure-derived expectations and coordinate method

For all front-mounted parts, component-top uses x-right/y-down and no reflection of native relative coordinates; inverse native KiCad rotation and translation checked explicitly. All coordinate errors are 0 mm at dossier precision.
Two collinear terminals establish no winding. No manufacturer numeric pin labels exist for these parts; project pad numbers were checked as positive/negative or cathode/anode physical identities, not claimed as manufacturer numbering.
Panasonic underside drawing: negative up, positive down at chamfered end. Reflect y to form top view, then rotate counterclockwise 90 degrees to positive-left/negative-right. Top negative-semicircle marking independently reaches the same result by 180-degree rotation. Diode top marking and outline: cathode band left, anode right; no mirror used. Bottom diode photographs were distinguished and not substituted for top views.

Native census: 12 pads / 12 unique artifact identities / 12 physical terminal identities across six references; zero EPs and zero fused aliases. All six explicitly front mounted. No missing or collapsed identity. No CW/CCW conclusion is possible or required for these two-terminal collinear packages.

C_FILT1_470U — VERDICT: PASS
Measured: native pads 2; unique pad identities 2; physical terminals 2; EP 0; fused aliases 0.
Primary: projects/crow-audio-carrier-v1/02_parts/EEEFK1A471P/Panasonic_FK_ABA0000C1181_20260210.pdf; SHA-256 b36857d089adaddf3042b33bf11d0f7d83bf70734e983f33b7827152e11854e3; figures: p1 Marking and Dimensions; p2 Land / Pad pattern, Standard products size F; p3 Characteristics list EEEFK1A471P.
C_FILT1_470U pin 1 (POSITIVE): expected Positive terminal on positive rail vs observed POSITIVE on FILT1P, component-top W at [-3.55, 0.0] mm; native [91.55, 55.3] mm. PASS.
C_FILT1_470U pin 2 (NEGATIVE): expected Negative marked terminal on ground vs observed NEGATIVE on GND, component-top E at [3.55, 0.0] mm; native [84.45, 55.3] mm. PASS.
Expected 4.0 x 2.0 mm lands, 3.1 mm gap and 7.1 mm pitch; observed exact match.
Package/polarity: two opposed terminals, no EP and no collapsed identities. The datasheet assigns physical polarity rather than numeric pins; pad 1 is an artifact convention, with no manufacturer pin-1 corner. Mounted-frame check and physical polarity mapping PASS.

C_FILT2_470U — VERDICT: PASS
Measured: native pads 2; unique pad identities 2; physical terminals 2; EP 0; fused aliases 0.
Primary: projects/crow-audio-carrier-v1/02_parts/EEEFK1A471P/Panasonic_FK_ABA0000C1181_20260210.pdf; SHA-256 b36857d089adaddf3042b33bf11d0f7d83bf70734e983f33b7827152e11854e3; figures: p1 Marking and Dimensions; p2 Land / Pad pattern, Standard products size F; p3 Characteristics list EEEFK1A471P.
C_FILT2_470U pin 1 (POSITIVE): expected Positive terminal on positive rail vs observed POSITIVE on FILT2P, component-top W at [-3.55, 0.0] mm; native [91.55, 84.7] mm. PASS.
C_FILT2_470U pin 2 (NEGATIVE): expected Negative marked terminal on ground vs observed NEGATIVE on GND, component-top E at [3.55, 0.0] mm; native [84.45, 84.7] mm. PASS.
Expected 4.0 x 2.0 mm lands, 3.1 mm gap and 7.1 mm pitch; observed exact match.
Package/polarity: two opposed terminals, no EP and no collapsed identities. The datasheet assigns physical polarity rather than numeric pins; pad 1 is an artifact convention, with no manufacturer pin-1 corner. Mounted-frame check and physical polarity mapping PASS.

C_HOLD1 — VERDICT: PASS
Measured: native pads 2; unique pad identities 2; physical terminals 2; EP 0; fused aliases 0.
Primary: projects/crow-audio-carrier-v1/02_parts/EEEFK1A471P/Panasonic_FK_ABA0000C1181_20260210.pdf; SHA-256 b36857d089adaddf3042b33bf11d0f7d83bf70734e983f33b7827152e11854e3; figures: p1 Marking and Dimensions; p2 Land / Pad pattern, Standard products size F; p3 Characteristics list EEEFK1A471P.
C_HOLD1 pin 1 (POSITIVE): expected Positive terminal on positive rail vs observed POSITIVE on 5V_LDO_HOLD, component-top W at [-3.55, 0.0] mm; native [55.45, 83.9] mm. PASS.
C_HOLD1 pin 2 (NEGATIVE): expected Negative marked terminal on ground vs observed NEGATIVE on GND, component-top E at [3.55, 0.0] mm; native [62.55, 83.9] mm. PASS.
Expected 4.0 x 2.0 mm lands, 3.1 mm gap and 7.1 mm pitch; observed exact match.
Package/polarity: two opposed terminals, no EP and no collapsed identities. The datasheet assigns physical polarity rather than numeric pins; pad 1 is an artifact convention, with no manufacturer pin-1 corner. Mounted-frame check and physical polarity mapping PASS.

C_HOLD2 — VERDICT: PASS
Measured: native pads 2; unique pad identities 2; physical terminals 2; EP 0; fused aliases 0.
Primary: projects/crow-audio-carrier-v1/02_parts/EEEFK1A471P/Panasonic_FK_ABA0000C1181_20260210.pdf; SHA-256 b36857d089adaddf3042b33bf11d0f7d83bf70734e983f33b7827152e11854e3; figures: p1 Marking and Dimensions; p2 Land / Pad pattern, Standard products size F; p3 Characteristics list EEEFK1A471P.
C_HOLD2 pin 1 (POSITIVE): expected Positive terminal on positive rail vs observed POSITIVE on 5V_LDO_HOLD, component-top W at [-3.55, 0.0] mm; native [59.55, 95.0] mm. PASS.
C_HOLD2 pin 2 (NEGATIVE): expected Negative marked terminal on ground vs observed NEGATIVE on GND, component-top E at [3.55, 0.0] mm; native [52.45, 95.0] mm. PASS.
Expected 4.0 x 2.0 mm lands, 3.1 mm gap and 7.1 mm pitch; observed exact match.
Package/polarity: two opposed terminals, no EP and no collapsed identities. The datasheet assigns physical polarity rather than numeric pins; pad 1 is an artifact convention, with no manufacturer pin-1 corner. Mounted-frame check and physical polarity mapping PASS.

D_BUCK_IN — VERDICT: PASS
Measured: native pads 2; unique pad identities 2; physical terminals 2; EP 0; fused aliases 0.
Primary: projects/crow-audio-carrier-v1/02_parts/US1B-13-F/Diodes_US1A_US1M_DS16008_Rev11-2.pdf; SHA-256 d50b2773c0300d97a77f5125419098c8130ecaf967202a44be2b182de8a15c1f; figures: p1 Top View / Bottom View and Marking Information; p4 Package Outline Dimensions and Suggested Pad Layout.
D_BUCK_IN pin 1 (K): expected Cathode at marked band on downstream feed rail vs observed K on 12V_BUCK_IN, component-top W at [-2.0, 0.0] mm; native [26.0, 60.0] mm. PASS.
D_BUCK_IN pin 2 (A): expected Anode opposite the band on upstream supply rail vs observed A on 12V_PROTECTED, component-top E at [2.0, 0.0] mm; native [26.0, 56.0] mm. PASS.
Expected suggested 2.5 x 1.7 mm lands, 1.5 mm gap and 4.0 mm pitch; observed 2.5 x 1.8 mm lands with exact gap and pitch. Additional 0.1 mm transverse width preserves terminal identity, separation and contact; no pin/package defect.
Package/polarity: two opposed terminals, no EP and no collapsed identities. The datasheet assigns physical polarity rather than numeric pins; pad 1 is an artifact convention, with no manufacturer pin-1 corner. Mounted-frame check and physical polarity mapping PASS.

D_HOLD — VERDICT: PASS
Measured: native pads 2; unique pad identities 2; physical terminals 2; EP 0; fused aliases 0.
Primary: projects/crow-audio-carrier-v1/02_parts/B340A-13-F/B340A_DS30891_Rev19-2.pdf; SHA-256 453cbd34d996482abd07ac694c4e2d812d26b1d679d05ee325acc5c3eeb79917; figures: p1 Top View / Bottom View and Marking Information; p6 Package Outline Dimensions and Suggested Pad Layout.
D_HOLD pin 1 (K): expected Cathode at marked band on downstream feed rail vs observed K on 5V_LDO_FEED, component-top W at [-2.0, 0.0] mm; native [48.4, 58.1] mm. PASS.
D_HOLD pin 2 (A): expected Anode opposite the band on upstream supply rail vs observed A on 5V_BUCK, component-top E at [2.0, 0.0] mm; native [52.4, 58.1] mm. PASS.
Expected suggested 2.5 x 1.7 mm lands, 1.5 mm gap and 4.0 mm pitch; observed 2.5 x 1.8 mm lands with exact gap and pitch. Additional 0.1 mm transverse width preserves terminal identity, separation and contact; no pin/package defect.
Package/polarity: two opposed terminals, no EP and no collapsed identities. The datasheet assigns physical polarity rather than numeric pins; pad 1 is an artifact convention, with no manufacturer pin-1 corner. Mounted-frame check and physical polarity mapping PASS.

Instance symmetry: All four capacitors preserve pad 1 POSITIVE to a positive rail and pad 2 NEGATIVE to GND. FILT1P and FILT2P form structurally identical filter instances; C_HOLD1 and C_HOLD2 both connect to 5V_LDO_HOLD/GND despite different rotations. Both SMA rectifiers use pad 1 K on downstream feed and pad 2 A on upstream supply.

Electrical sanity uses the supplied net roles: FILT1P/FILT2P and 5V_LDO_HOLD are positive-rail names relative to GND; D_BUCK_IN conducts from 12V_PROTECTED (A) to 12V_BUCK_IN (K); D_HOLD conducts from 5V_BUCK (A) to 5V_LDO_FEED (K). The map does not place either cathode on its upstream source, and all capacitor negative terminals are grounded. Circuit operating limits and provenance of rail names are outside this pin-review scope.

No unresolved findings. No electrical or package defect found in this commissioned group. No live engineering source was read or modified. Native dossier counts are measured from the supplied frozen dossiers, not from a live board.

Evidence retention: all eight inspected figure images, native dossiers, exact primary PDF digests, independent derivation, measurements, scripts and raw/runtime records are in evidence.tar.gz. Full PDFs remain bound in the frozen input packet. Input hashes verified before and after review; artifact archive reopened member by member. Delivery-check PASS denotes an honest complete handback, not permission to order.


## Verbatim independent report — rj45-pin-carrier-supply-mountedframe1

review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_supply_mountedframe1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

Limited group coverage: U_AUDIO, U_BUCK, U_PWR only. All commissioned instances PASS. No whole-board acceptance; immutable hashes above are supplied metadata, not independently reviewed whole-board conclusions.

Scope and method

Fresh agent /root/rj45_pin_carrier_supply_mountedframe1. Engineering inputs restricted to supplied protocol, dossiers, exact selected primary PDFs. No live design, schematic, project history or external datasheets read. Dossier embedded verification notes were not used as evidence.
All three front-mounted at 0 degrees: native board minus component center equals component-top (+x right,+y down). No reflection or rotation needed when comparing explicit manufacturer TOP VIEW. TPS mechanical underside drawing converted to top by y reflection only as crosscheck; never mirror the dossier.
Pin-to-net category sanity from native dossier net labels and the visible inter-instance PWR_EN connection. Component values, whole-net endpoint census, decoupling, pullup values, threshold math, timing, routing and assembly process are not verified by this pin-only commission. No whole-board acceptance.

Primary documents (exact frozen bytes)
- projects/crow-audio-carrier-v1/02_parts/AP63205WU-7/AP63205_DS41326_Rev3-2.pdf; SHA256 ef99daa3789d835bc025dfcb4c605c5c2e6d3e7223e86d40b33e6b497ea5a722; 1226090 bytes.
- projects/crow-audio-carrier-v1/02_parts/TPS389001DSER/TPS3890_SLVSD65A.pdf; SHA256 ee79599730e7606ba9718d9820b411020e3dcd9ff7d44572f8ee63fead15b9d0; 1203677 bytes.

U_AUDIO — VERDICT: PASS

Measured native pads: 6; unique numbered pads: 6; independently expected and observed physical identities: 6; exposed pads: expected 0, observed 0; fused lands: 0; aliases: 0.
Primary: TPS3890 SLVSD65A SHA256 ee79599730e7606ba9718d9820b411020e3dcd9ff7d44572f8ee63fead15b9d0, PDF p3 DSE Top View/Pin Functions, p24 DSE0006A Package Outline and p25 Example Board Layout (4220552/B), p12 Figure23 and p13 Figure24; supporting p4 operating range and p19 exact TPS389001DSER package entry.
Expected pin1 upper left, left 1/2/3 downward, right 6/5/4 downward, CCW, three terminals per side, no EP. Observed exact order and pin1=(-0.55,-0.5). Six isolated lands match example: pin1 0.8x0.25mm, others 0.7x0.25mm; left outside edges align at -0.95mm, other centers x=±0.6mm and y pitch=0.5mm. The longer pin1 land is an identity feature, not an exposed pad or fused alias.
Measured signed double area in x-right/y-down frame: -2.375 mm² (negative means CCW). Maximum native-to-component-top translation residual 2.89e-15 mm. Expected versus observed pin rows:
- U_AUDIO pin 1 (SENSE): expected Monitored-voltage sense node (adjustable 1.15V threshold); observed ADC_SENSE — PASS at pin/net-kind scope.
- U_AUDIO pin 2 (GND): expected Ground; observed GND — PASS at pin/net-kind scope.
- U_AUDIO pin 3 (MR_N): expected Active-low manual reset control, or VDD when unused; observed PWR_EN — PASS at pin/net-kind scope.
- U_AUDIO pin 4 (VDD): expected Supply rail 1.5 to 5.5V; observed 5V_LDO_HOLD — PASS at pin/net-kind scope.
- U_AUDIO pin 5 (CT): expected Dedicated timing-capacitor node; observed AUDIO_CT — PASS at pin/net-kind scope.
- U_AUDIO pin 6 (RESET_N): expected Active-low open-drain reset/control output; observed AUDIO_EN — PASS at pin/net-kind scope.

U_BUCK — VERDICT: PASS

Measured native pads: 6; unique numbered pads: 6; independently expected and observed physical identities: 6; exposed pads: expected 0, observed 0; fused lands: 0; aliases: 0.
Primary: DS41326 Rev.3-2 SHA256 ef99daa3789d835bc025dfcb4c605c5c2e6d3e7223e86d40b33e6b497ea5a722, PDF p1 Pin Assignments, p2 Figure1 and Pin Descriptions, p17 TSOT26 outline/land figures; supporting p12 section9 and p16 ordering table.
Expected pin1 upper left, left 1/2/3 downward, right 6/5/4 downward, CCW, three pins per side, 0.95mm pitch and no EP. Observed component-top pin1=(-1.1375,-0.95), W 1/2/3 and E 6/5/4 with exactly that pitch and CCW. The native land pattern uses 1.32x0.6mm lands at x=±1.1375; manufacturer suggested lands (rotated) are 1.0x0.7mm at x=±1.1. These are not identical recommendations, but preserve isolated physical terminal identity and lead landing, with no pin-map defect.
Measured signed double area in x-right/y-down frame: -8.645 mm² (negative means CCW). Maximum native-to-component-top translation residual 2.89e-15 mm. Expected versus observed pin rows:
- U_BUCK pin 1 (FB): expected Fixed AP63205 5V output sense, direct connection to regulated output per Figure 1; observed 5V_BUCK — PASS at pin/net-kind scope.
- U_BUCK pin 2 (EN): expected Enable may connect to VIN for automatic startup; observed 12V_BUCK_IN — PASS at pin/net-kind scope.
- U_BUCK pin 3 (VIN): expected Power input 3.8 to 32V; observed 12V_BUCK_IN — PASS at pin/net-kind scope.
- U_BUCK pin 4 (GND): expected Power ground; observed GND — PASS at pin/net-kind scope.
- U_BUCK pin 5 (SW): expected Switch-node net feeding output filter; observed BUCK_SW — PASS at pin/net-kind scope.
- U_BUCK pin 6 (BST): expected Bootstrap supply node, capacitor referenced to SW; observed BUCK_BST — PASS at pin/net-kind scope.

U_PWR — VERDICT: PASS

Measured native pads: 6; unique numbered pads: 6; independently expected and observed physical identities: 6; exposed pads: expected 0, observed 0; fused lands: 0; aliases: 0.
Primary: TPS3890 SLVSD65A SHA256 ee79599730e7606ba9718d9820b411020e3dcd9ff7d44572f8ee63fead15b9d0, PDF p3 DSE Top View/Pin Functions, p24 DSE0006A Package Outline and p25 Example Board Layout (4220552/B), p12 Figure23 and p13 Figure24; supporting p4 operating range and p19 exact TPS389001DSER package entry.
Expected pin1 upper left, left 1/2/3 downward, right 6/5/4 downward, CCW, three terminals per side, no EP. Observed exact order and pin1=(-0.55,-0.5). Six isolated lands match example: pin1 0.8x0.25mm, others 0.7x0.25mm; left outside edges align at -0.95mm, other centers x=±0.6mm and y pitch=0.5mm. The longer pin1 land is an identity feature, not an exposed pad or fused alias.
Measured signed double area in x-right/y-down frame: -2.375 mm² (negative means CCW). Maximum native-to-component-top translation residual 2.89e-15 mm. Expected versus observed pin rows:
- U_PWR pin 1 (SENSE): expected Monitored-voltage sense node (adjustable 1.15V threshold); observed PWR_SENSE — PASS at pin/net-kind scope.
- U_PWR pin 2 (GND): expected Ground; observed GND — PASS at pin/net-kind scope.
- U_PWR pin 3 (MR_N): expected Active-low manual reset control, or VDD when unused; observed 5V_LDO_HOLD — PASS at pin/net-kind scope.
- U_PWR pin 4 (VDD): expected Supply rail 1.5 to 5.5V; observed 5V_LDO_HOLD — PASS at pin/net-kind scope.
- U_PWR pin 5 (CT): expected Dedicated timing-capacitor node; observed PWR_CT — PASS at pin/net-kind scope.
- U_PWR pin 6 (RESET_N): expected Active-low open-drain reset/control output; observed PWR_EN — PASS at pin/net-kind scope.

Pairwise symmetry — PASS

All six functions/positions/sizes identical. U_PWR MR_N=5V_LDO_HOLD (same as VDD); U_PWR RESET_N=PWR_EN directly shares U_AUDIO MR_N=PWR_EN. Sense, CT and output nets remain instance-specific. This variation is explicitly compatible with TPS3890 p12 Figure23 and section8.3.2; it is not a function swap.

Unresolved findings: none within this limited pin-review commission. Electrical network values and endpoint implementation are outside the supplied dossier scope and are not certified here.

Evidence: evidence.json contains exact envelope subject, per-pin findings and all measured native rows. evidence.tar.gz retains the inspected figure images, native dossier copies, independent derivation, measurement script/results, source digest verification, commands/methods and subprocess logs/runtime. evidence-manifest.json inventories and hashes every regular archive member.


## Verbatim independent report — rj45-pin-carrier-switches-mountedframe1

review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent /root/rj45_pin_carrier_switches_mountedframe1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

SOUND applies only to U_ISO1–U_ISO8 pin-review scope. All eight commissioned references PASS. No whole-board acceptance; pre-route order verdict remains DO-NOT-ORDER. The three flat hashes above are immutable subject bindings, not independently reviewed whole-board conclusions.

Primary evidence: Texas Instruments TMUX2821/TMUX2819 SCDS488, December 2025, frozen PDF SHA256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55. Inspected actual rendered images: PDF p3 Fig4-1/top view and pin-function table; PDF p30 DSG0008A outline; PDF p31 land-pattern example (drawing4218900/E,08/2022); PDF p19 functional diagram and Table7-1. PDF p5 operating table and p26 exact orderable suffix checked in extracted primary text.

Independent derivation preceded dossier comparison. Figure4-1 has pin1 upper left, pins1–4 down the west side, pins5–8 up the east side: CCW top view. The metal underside drawing on p30 has pin1 lower left and is a bottom physical view; explicit y reflection converts that drawing to top view, consistent with Fig4-1 and p31. This manufacturer drawing conversion is distinct from mounting conversion. All eight parts mount front; no dossier reflection is needed. Four top-row instances rotate0°, four lower-row instances rotate180°. Perimeter pads match the p31 example: x=±0.95mm, y=−0.75,−0.25,+0.25,+0.75mm, size0.5×0.25mm; central EP9 size0.9×1.6mm. Expected nine electrical identities are preserved without fused aliases. Native coordinate reconstruction agrees within1e-6mm for every numbered row. Independently computed polygon area is−2.85mm² in the +y-down frame, confirming CCW.

The p3 function table identifies1=S1,2=D1,3=SEL2,4=GND,5=S2,6=D2,7=SEL1,8=VDD,9=thermal-pad GND. TMUX2821 has no NC; the neighboring TMUX2819 NC is not applicable. Table7-1 establishes active-high switch controls. Net labels support function-to-net-kind sanity; this pin review does not measure signal amplitude, rail tolerance, enable waveform, decoupling or loaded performance.

U_ISO1 VERDICT: PASS
Measured native numbered pad rows=9; distinct pad IDs=9; physical identities=9 (8 perimeter+EP9). Dossier separately reports2 unnumbered paste/mechanical pads, yielding11 reported native pads; those two unnumbered geometries are not supplied or claimed individually measured. Fused/collapsed identities=0. Front mount, rotation=0°, component-top pin1 northwest, CCW, four pads west/four east/one center: expected and observed agree. Primary SHA256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p3 Fig4-1, p30 package underside, p31 land pattern; p19 Table7-1 for controls.
U_ISO1 pin 1 (S1): expected bidirectional analog signal; observed FILTER1P; PASS.
U_ISO1 pin 2 (D1): expected bidirectional analog signal; observed ADC1P; PASS.
U_ISO1 pin 3 (SEL2): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO1 pin 4 (GND): expected ground reference; observed GND; PASS.
U_ISO1 pin 5 (S2): expected bidirectional analog signal; observed FILTER1N; PASS.
U_ISO1 pin 6 (D2): expected bidirectional analog signal; observed ADC1N; PASS.
U_ISO1 pin 7 (SEL1): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO1 pin 8 (VDD): expected positive supply rail (1.8–5.5V operating); observed 5V_LDO_HOLD; PASS.
U_ISO1 pin 9 (GND): expected ground reference; observed GND; PASS.

U_ISO2 VERDICT: PASS
Measured native numbered pad rows=9; distinct pad IDs=9; physical identities=9 (8 perimeter+EP9). Dossier separately reports2 unnumbered paste/mechanical pads, yielding11 reported native pads; those two unnumbered geometries are not supplied or claimed individually measured. Fused/collapsed identities=0. Front mount, rotation=0°, component-top pin1 northwest, CCW, four pads west/four east/one center: expected and observed agree. Primary SHA256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p3 Fig4-1, p30 package underside, p31 land pattern; p19 Table7-1 for controls.
U_ISO2 pin 1 (S1): expected bidirectional analog signal; observed FILTER2P; PASS.
U_ISO2 pin 2 (D1): expected bidirectional analog signal; observed ADC2P; PASS.
U_ISO2 pin 3 (SEL2): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO2 pin 4 (GND): expected ground reference; observed GND; PASS.
U_ISO2 pin 5 (S2): expected bidirectional analog signal; observed FILTER2N; PASS.
U_ISO2 pin 6 (D2): expected bidirectional analog signal; observed ADC2N; PASS.
U_ISO2 pin 7 (SEL1): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO2 pin 8 (VDD): expected positive supply rail (1.8–5.5V operating); observed 5V_LDO_HOLD; PASS.
U_ISO2 pin 9 (GND): expected ground reference; observed GND; PASS.

U_ISO3 VERDICT: PASS
Measured native numbered pad rows=9; distinct pad IDs=9; physical identities=9 (8 perimeter+EP9). Dossier separately reports2 unnumbered paste/mechanical pads, yielding11 reported native pads; those two unnumbered geometries are not supplied or claimed individually measured. Fused/collapsed identities=0. Front mount, rotation=0°, component-top pin1 northwest, CCW, four pads west/four east/one center: expected and observed agree. Primary SHA256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p3 Fig4-1, p30 package underside, p31 land pattern; p19 Table7-1 for controls.
U_ISO3 pin 1 (S1): expected bidirectional analog signal; observed FILTER3P; PASS.
U_ISO3 pin 2 (D1): expected bidirectional analog signal; observed ADC3P; PASS.
U_ISO3 pin 3 (SEL2): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO3 pin 4 (GND): expected ground reference; observed GND; PASS.
U_ISO3 pin 5 (S2): expected bidirectional analog signal; observed FILTER3N; PASS.
U_ISO3 pin 6 (D2): expected bidirectional analog signal; observed ADC3N; PASS.
U_ISO3 pin 7 (SEL1): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO3 pin 8 (VDD): expected positive supply rail (1.8–5.5V operating); observed 5V_LDO_HOLD; PASS.
U_ISO3 pin 9 (GND): expected ground reference; observed GND; PASS.

U_ISO4 VERDICT: PASS
Measured native numbered pad rows=9; distinct pad IDs=9; physical identities=9 (8 perimeter+EP9). Dossier separately reports2 unnumbered paste/mechanical pads, yielding11 reported native pads; those two unnumbered geometries are not supplied or claimed individually measured. Fused/collapsed identities=0. Front mount, rotation=0°, component-top pin1 northwest, CCW, four pads west/four east/one center: expected and observed agree. Primary SHA256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p3 Fig4-1, p30 package underside, p31 land pattern; p19 Table7-1 for controls.
U_ISO4 pin 1 (S1): expected bidirectional analog signal; observed FILTER4P; PASS.
U_ISO4 pin 2 (D1): expected bidirectional analog signal; observed ADC4P; PASS.
U_ISO4 pin 3 (SEL2): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO4 pin 4 (GND): expected ground reference; observed GND; PASS.
U_ISO4 pin 5 (S2): expected bidirectional analog signal; observed FILTER4N; PASS.
U_ISO4 pin 6 (D2): expected bidirectional analog signal; observed ADC4N; PASS.
U_ISO4 pin 7 (SEL1): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO4 pin 8 (VDD): expected positive supply rail (1.8–5.5V operating); observed 5V_LDO_HOLD; PASS.
U_ISO4 pin 9 (GND): expected ground reference; observed GND; PASS.

U_ISO5 VERDICT: PASS
Measured native numbered pad rows=9; distinct pad IDs=9; physical identities=9 (8 perimeter+EP9). Dossier separately reports2 unnumbered paste/mechanical pads, yielding11 reported native pads; those two unnumbered geometries are not supplied or claimed individually measured. Fused/collapsed identities=0. Front mount, rotation=180°, component-top pin1 northwest, CCW, four pads west/four east/one center: expected and observed agree. Primary SHA256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p3 Fig4-1, p30 package underside, p31 land pattern; p19 Table7-1 for controls.
U_ISO5 pin 1 (S1): expected bidirectional analog signal; observed FILTER5P; PASS.
U_ISO5 pin 2 (D1): expected bidirectional analog signal; observed ADC5P; PASS.
U_ISO5 pin 3 (SEL2): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO5 pin 4 (GND): expected ground reference; observed GND; PASS.
U_ISO5 pin 5 (S2): expected bidirectional analog signal; observed FILTER5N; PASS.
U_ISO5 pin 6 (D2): expected bidirectional analog signal; observed ADC5N; PASS.
U_ISO5 pin 7 (SEL1): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO5 pin 8 (VDD): expected positive supply rail (1.8–5.5V operating); observed 5V_LDO_HOLD; PASS.
U_ISO5 pin 9 (GND): expected ground reference; observed GND; PASS.

U_ISO6 VERDICT: PASS
Measured native numbered pad rows=9; distinct pad IDs=9; physical identities=9 (8 perimeter+EP9). Dossier separately reports2 unnumbered paste/mechanical pads, yielding11 reported native pads; those two unnumbered geometries are not supplied or claimed individually measured. Fused/collapsed identities=0. Front mount, rotation=180°, component-top pin1 northwest, CCW, four pads west/four east/one center: expected and observed agree. Primary SHA256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p3 Fig4-1, p30 package underside, p31 land pattern; p19 Table7-1 for controls.
U_ISO6 pin 1 (S1): expected bidirectional analog signal; observed FILTER6P; PASS.
U_ISO6 pin 2 (D1): expected bidirectional analog signal; observed ADC6P; PASS.
U_ISO6 pin 3 (SEL2): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO6 pin 4 (GND): expected ground reference; observed GND; PASS.
U_ISO6 pin 5 (S2): expected bidirectional analog signal; observed FILTER6N; PASS.
U_ISO6 pin 6 (D2): expected bidirectional analog signal; observed ADC6N; PASS.
U_ISO6 pin 7 (SEL1): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO6 pin 8 (VDD): expected positive supply rail (1.8–5.5V operating); observed 5V_LDO_HOLD; PASS.
U_ISO6 pin 9 (GND): expected ground reference; observed GND; PASS.

U_ISO7 VERDICT: PASS
Measured native numbered pad rows=9; distinct pad IDs=9; physical identities=9 (8 perimeter+EP9). Dossier separately reports2 unnumbered paste/mechanical pads, yielding11 reported native pads; those two unnumbered geometries are not supplied or claimed individually measured. Fused/collapsed identities=0. Front mount, rotation=180°, component-top pin1 northwest, CCW, four pads west/four east/one center: expected and observed agree. Primary SHA256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p3 Fig4-1, p30 package underside, p31 land pattern; p19 Table7-1 for controls.
U_ISO7 pin 1 (S1): expected bidirectional analog signal; observed FILTER7P; PASS.
U_ISO7 pin 2 (D1): expected bidirectional analog signal; observed ADC7P; PASS.
U_ISO7 pin 3 (SEL2): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO7 pin 4 (GND): expected ground reference; observed GND; PASS.
U_ISO7 pin 5 (S2): expected bidirectional analog signal; observed FILTER7N; PASS.
U_ISO7 pin 6 (D2): expected bidirectional analog signal; observed ADC7N; PASS.
U_ISO7 pin 7 (SEL1): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO7 pin 8 (VDD): expected positive supply rail (1.8–5.5V operating); observed 5V_LDO_HOLD; PASS.
U_ISO7 pin 9 (GND): expected ground reference; observed GND; PASS.

U_ISO8 VERDICT: PASS
Measured native numbered pad rows=9; distinct pad IDs=9; physical identities=9 (8 perimeter+EP9). Dossier separately reports2 unnumbered paste/mechanical pads, yielding11 reported native pads; those two unnumbered geometries are not supplied or claimed individually measured. Fused/collapsed identities=0. Front mount, rotation=180°, component-top pin1 northwest, CCW, four pads west/four east/one center: expected and observed agree. Primary SHA256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p3 Fig4-1, p30 package underside, p31 land pattern; p19 Table7-1 for controls.
U_ISO8 pin 1 (S1): expected bidirectional analog signal; observed FILTER8P; PASS.
U_ISO8 pin 2 (D1): expected bidirectional analog signal; observed ADC8P; PASS.
U_ISO8 pin 3 (SEL2): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO8 pin 4 (GND): expected ground reference; observed GND; PASS.
U_ISO8 pin 5 (S2): expected bidirectional analog signal; observed FILTER8N; PASS.
U_ISO8 pin 6 (D2): expected bidirectional analog signal; observed ADC8N; PASS.
U_ISO8 pin 7 (SEL1): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO8 pin 8 (VDD): expected positive supply rail (1.8–5.5V operating); observed 5V_LDO_HOLD; PASS.
U_ISO8 pin 9 (GND): expected ground reference; observed GND; PASS.

Instance symmetry: U_ISO1–U_ISO8 pin1=FILTERnP,2=ADCnP,5=FILTERnN,6=ADCnN;3 and7=AUDIO_EN;4 and9=GND;8=5V_LDO_HOLD. Each channel retains its own index and P/N pole. No structural divergence across the eight instances.

Unresolved findings: none within commissioned pin-review scope.

Methods: Verified every envelope input SHA256 and size before and after engineering, retained raw verify-before/after logs. Rendered exact primary PDF with pdftoppm under pipeline_runtime.run_stage; inspected pin-03.png, package-30.png, package-31.png, functional-19.png with view_image. Recorded independent-figure-derivation.md before reading dossiers; derived package, pin1, winding, exposed-pad identity and functions from primary figure images. Measured all 72 numbered native pad rows in supplied dossiers with measure.py; compared each to figure-derived expected geometry and functions and native coordinate rotation. Inspected every instance signal/control/power/ground mapping and normalized channel-number symmetry. No live design files, schematic, historical reviews or external sources used. Supplied dossier verification-note assertions were not used as engineering evidence.

Evidence archive retains inspected PNGs, original native dossier copies, independent derivation, measured rows, finite execution methods and raw stdout/stderr/runtime records. Exact primary PDF remains digest-bound in the frozen input packet.


## Verbatim independent report — rj45-pin-carrier-tvs-context1

review_stage: pre-route
review_kind: pin
reviewer: same independent original agent /root/rj45_pin_carrier_tvs_mountedframe1
context: Independent original fresh pin review continued by the same agent with narrowly requested frozen native supporting facts; not a new fresh-agent review
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
release_scope: FIRST-ARTICLE-ONLY
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

Coverage is limited to D_IN and D_QIN_GS in this frozen commission. This is not whole-board acceptance. Board/parts/design-rule hashes above are immutable subject metadata, not independently reviewed board conclusions.

D_IN — VERDICT: PASS

Primary: Littelfuse SMBJ series, revised JC.07/04/25 v4, PDF SHA-256 d7df155be4b1f612085401e8c946f065e284d65a0e7de22b9225a7b73946e51b. Inspected page 1 Functional Diagram and package illustrations, page 2 Electrical Characteristics exact SMBJ15A row, page 5 Dimensions / DO-214AA (SMB J-Bend), and page 6 Part Marking System / Part Numbering System figures.

D_IN pin 1 (K): expect the banded terminal of the unidirectional device on the positive protected rail; observe west pad at component-top (-2.15,0), native (30.649999,82.3), K on 12V_PROTECTED. Matches the page 5 marked-top drawing with band left.
D_IN pin 2 (A): expect the opposite terminal toward ground for a positive-rail shunt suppressor; observe east pad (+2.15,0), native (34.949999,82.3), A on GND. PASS.
D_IN package/count: expect two opposed physical terminals and no EP; measured 2 native pads, 2 unique artifact pad numbers, 2 physical identities (K,A), 0 EP, 0 aliases/identity collapse. Each pad is 2.5 x 2.3 mm; center separation 4.3 mm, resulting inner gap 1.8 mm. This covers the two opposed J-bend terminal locations and satisfies the manufacturer's suggested pad minimum widths/heights (2.16/2.26 mm) and maximum gap (2.74 mm).
D_IN view/winding: front-mounted F.Cu; dossier explicitly uses component-top +x right/+y down, no front reflection. The marked package surface is top, not the side section or solder-pad drawing. Page 6 band-at-top marking image rotates into page 5 band-at-left; no mirror is required. Manufacturer provides K/A identities rather than numeric pin labels; dossier artifact pad 1 aliases the banded cathode, pad 2 the anode. There is no pin-1 corner or meaningful winding for two collinear terminals; reported n/a is correct. No fused physical aliases are needed.
D_IN electrical scope: 15 V standoff supports the named 12 V rail connection at pin-review level. Surge energy, rail tolerances, downstream withstand and clamp sizing are not established by this pin dossier and are outside this limited mapping verdict.

D_QIN_GS — VERDICT: PASS

Primary: Diodes Incorporated BZT52C2V0–BZT52C51, DS18004 Rev. 38-2, October 2017, PDF SHA-256 0fbd7d137524820f0160594065cbceb8c6b3188757c328416d08fceb7418202f. Inspected page 1 explicit Top View / Marking Information and Mechanical Data cathode-band statement, page 2 exact BZT52C12 electrical row, and page 4 SOD123 Package Outline Dimensions / Suggested Pad Layout figure images.

D_QIN_GS pin 1 (K): expect banded SOD123 cathode; observe west pad (-1.65,0), native (40.75,71), K on 12V_PROTECTED. Physical identity and package orientation match the page 1 left-band marking image.
D_QIN_GS pin 2 (A): expect opposite SOD123 anode; observe east pad (+1.65,0), native (44.05,71), A on Q_IN_GATE. Physical identity matches.
D_QIN_GS package/count: expect two opposing physical terminals and no EP; measured 2 native pads, 2 unique artifact pad numbers, 2 physical identities (K,A), 0 EP, 0 aliases/identity collapse. Pads measure 0.9 x 1.2 mm, center separation 3.3 mm. Manufacturer suggested pads are 0.9 x 0.95 mm with 4.05 mm outside span, hence 3.15 mm center separation. Observed centers are 0.075 mm farther outward per pad and still overlap the lead locations in the 3.55–3.85 mm overall-terminal envelope. This difference is not a pin identity or package mismatch.
D_QIN_GS view/winding: front-mounted F.Cu; explicit component-top convention requires no reflection. Compare to the explicit manufacturer Top View by rotation only. No bottom-view pinout was substituted. Numeric 1/2 are artifact designations for K/A, not manufacturer numbered pins. Two collinear terminals have no winding; dossier n/a is correct.
D_QIN_GS electrical PASS, newly resolved: the added Q_IN dossier identifies source pins 1, 2 and 3 on 12V_PROTECTED, gate pin 4 on Q_IN_GATE, and common drain pad 5 (declared physical identities 5–8) on 12V_FUSED. The exact DMP6023LFG primary PDF identifies a P-channel enhancement-mode MOSFET, with negative gate-drive conditions (VGS=-10 V and -4.5 V), and page 2 gives negative threshold and ±20 V gate-source rating. R_QIN_G is the exact 100 kΩ nonpolar resistor with pad 1 on Q_IN_GATE and pad 2 on GND. Thus the native circuit pulls the gate below its source when the positive protected rail is present. D_QIN_GS K=source and A=gate provides the reverse-zener path for negative VGS and forward-diode path for positive VGS. This matches the intended gate-source polarity. The previous missing source/operating-polarity fact is resolved directly by native supporting endpoints and the manufacturer's device identity. No additional engineering question remains within this pin-review group.

The BZT52C12 11.4–12.7 V figure is specified at 5 mA; the 100 kΩ pull-down does not establish that operating current. This review approves connection identity and polarity only, without claiming a guaranteed 11.4–12.7 V clamp at this circuit's current or transient protection performance. Original first-article clamp screening remains outside the pin-mapping acceptance.

Instance symmetry: exactly one commissioned instance of each different part; no same-part instance pair exists to compare. Both preserve the same K=pad 1 west / A=pad 2 east physical convention. Their anodes name different net types because D_IN suppresses the rail to ground and D_QIN_GS clamps Q_IN gate to source; the added native context establishes the latter role.


Continuation provenance and inherited coverage: the physical package, K/A identities, component-top/front-mount convention, conditional two-terminal winding, EP/alias checks, and dimensions above are inherited from my independently completed rj45-pin-carrier-tvs-mountedframe1 review. Original report SHA-256 1da5ec454799801d2fbec7aa0e720fc57e5b3801e4c59347090be8d07be47c50 is preserved verbatim as an input. Its supplied closeout records original engineering INCOMPLETE, delivery PASS and retained journal archive SHA-256 686942183c4b253a7325415ba241413b2ee91f3bb6db008794af6ffd0aa7d44c with all 48 original review members reopened. That archive is provenance, not a newly read engineering source; no live path was opened. The original diode dossier SHA-256 values remain D_IN=0da832b1ba6bd8b6b648fc337d8239d9041b98aa3e6dd62979988c239acd3ce2 and D_QIN_GS=121a0ce3f5d11562bc38cb48232fdbccaee187f7f556db6f10d1be6ebf93ccaa, with their original exact PDF hashes unchanged. I verified those identities; I did not redo or replace the successful whole-group physical work. The old INCOMPLETE report remains immutable.

Newly inspected primary evidence: Diodes DMP6023LFG DS37204 Rev.2-2 PDF SHA-256 1ea244be5e0fe4195ad20cb2da0960ac622b6efc19cf9e579c9eb8ef5777fa27, page 1 Bottom View / Top View / Equivalent Circuit, page 2 Maximum Ratings and Electrical Characteristics, and page 5 Package Outline Dimensions / Suggested Pad Layout. The bottom-view source/gate row must not be treated as component-top: with page 5 bottom view 1–4 along the upper row left-to-right, reflect horizontally and rotate the resulting top view 90° counterclockwise to obtain component-top west pins 1–4 top-to-bottom, matching the supplied native SOURCE/SOURCE/SOURCE/GATE row. Page 1 and page 5 show the common drain region; this supports understanding the declared common-drain endpoints. Q_IN supporting dossier SHA-256 fb4a1a3c3aec8cc518e4b69430d674ef7fe047cde5b73512ea3afc3b755b1b29. Measured 5 numbered native pad rows, 3 explicit fused aliases, 8 declared physical identities; dossier additionally reports 8 unnumbered paste/mechanical pads not shown. No new independent whole-Q_IN footprint verdict is issued.

Newly inspected YAGEO RC0402FR-07100KL exact PDF SHA-256 e42aa2b39be7476fef25efbe4656acbbc246d2b9b625d64db6b46e0f5e34d7af, page 1 3D package figure and specifications. It shows two nonpolar opposing terminations, 100 kΩ, 1%, 0402/1005. R_QIN_G supporting dossier SHA-256 7c0bcdf8ed848adf1a8d90ac5a37f07bbf593a75e987afa57c97a225a0994f80. Measured 2 native pads/2 terminal identities, 0 aliases, 0 EP; native pads (40,79.51) gate and (40,78.49) ground correspond to its stated 90° placement and component-top endpoints. The resistor has no winding or polarity constraint.

Methods and scope: new device-polarity and resistor page-1 figure images were rendered and inspected before reading supporting native dossiers; FET page-2 ratings and page-5 package figures were inspected afterward as supplemental checks. All 13 envelope input bytes verified before and after; envelope canonical SHA-256 b0c9f90304816802dc173178c5b7eaae8e3fbf0c94b0b7001838d6d19cc29b8a. New evidence archive retains actual new inspected figure images, scripts, direct argv commands, combined lossless stdout/stderr, runtime records, native dossiers, and verbatim inherited report/closeout. The original inspected diode images remain in the digest-bound original closeout archive. New group scope is still only D_IN and D_QIN_GS; Q_IN and R_QIN_G supply the exact missing context. Both commissioned refs now PASS. SOUND is a limited pre-route pin-review conclusion, with FIRST-ARTICLE-ONLY / DO-NOT-ORDER retained; it is not whole-board or release acceptance.
