from pathlib import Path
import json,hashlib,sys,re
from datetime import datetime,timezone
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;P=R/'projects/crow-audio-carrier-v1'
sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'))
from pre_route_review_check import digest,design_rules_digest
parts=sorted((P/'02_parts').glob('*/part.yaml'));fields={'board_sha256':digest(P/'04_kicad/crow_audio_carrier_v1.kicad_pcb'),'parts_sha256':hashlib.sha256(b''.join(x.relative_to(P).as_posix().encode()+b'\0'+x.read_bytes()+b'\0' for x in parts)).hexdigest(),'design_rules_sha256':design_rules_digest(P)}
base=sorted(N.glob('rj45-pin-carrier-*-mountedframe1-opened.json'));assert len(base)==13
records=[];bodies=[];refs=[]
for mp in base:
 original=mp.name.removesuffix('-opened.json');name=original.replace('-mountedframe1','-context1') if any('-'+k+'-' in original for k in ['headers','conversion','esd','clock-reset','tvs']) else original
 m=json.loads((N/(name+'-opened.json')).read_text());c=json.loads((N/(name+'-closeout-summary.json')).read_text());assert c['delivery_status']=='PASS' and c['engineering_verdict']=='SOUND' and m['hashes']==fields
 raw=(Path(m['output_dir'])/'report.md').read_bytes();text=raw.decode();assert re.search(r'^design_verdict: SOUND$',text,re.M)
 for k,v in fields.items():assert re.search('^'+k+': '+v+'$',text,re.M)
 refs+=m['refs'];records.append({'name':name,'original':original,'refs':m['refs'],'report_sha256':hashlib.sha256(raw).hexdigest(),'archive':Path(c['archive']).name,'archive_sha256':c['sha256']});bodies.append(text)
expected={p.stem for p in (N/'mounted-frame-placement-pins/crow-audio-carrier-v1/dossiers').glob('*.md')};assert len(refs)==len(set(refs))==61 and set(refs)==expected
count=0;aliases=0
for ref in refs:
 s=(N/'mounted-frame-placement-pins/crow-audio-carrier-v1/dossiers'/(ref+'.md')).read_text();count+=len(re.findall(r'^\| \d',s,re.M));aliases+=len(re.findall(r'^- `\d+`: schematic',s,re.M))
old=P/'08_reviews/pre-route_pin.md';(N/'carrier-pin-before-mounted-frame-aggregate.md').write_bytes(old.read_bytes())
head='review_stage: pre-route\nreview_kind: pin\nreviewer: Independent part-group reviewers listed below; root compiles exact completed reports\ncontext: Thirteen original independent pin contexts; five explicitly continued with requested facts\ndesign_verdict: SOUND\norder_verdict: DO-NOT-ORDER\n'+''.join(k+': '+v+'\n' for k,v in fields.items())+f'\n# Current carrier pin-review collection\n\nAll61 commissioned critical references across13 part groups PASS. Native dossiers contain{count} numbered pad identities plus{aliases} explicit fused physical aliases. This collection is limited to independent pin/package and function/net sanity; it does not accept full-board layout, routed performance, physical qualification or ordering. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.\n\nFive original QUESTION reports remain immutable. The same independent reviewers resolved only their requested context in new reports: ADC straps, reset timing endpoints, FET clamp polarity, header locating/mating assignments, and declared ESD normal signal limits. Continued contexts and inherited physical proofs are explicit; authored operating facts are not physical measurements. The ESD RMS conversion is explicitly sine-equivalent, not an arbitrary waveform peak bound. Cable continuity/fit, transient survival and existing first-article obligations remain held. No source or native PCB changed to resolve these pin questions.\n\n'
head+='\n'.join('- '+r['name']+': refs '+','.join(r['refs'])+'; report SHA256 '+r['report_sha256']+'; durable archive ../01_docs/journal/'+r['archive'] for r in records)+'\n\n'
old.write_text(head+'\n\n'.join('## Verbatim independent report — '+r['name']+'\n\n'+b for r,b in zip(records,bodies)))
record={'created_at':datetime.now(timezone.utc).isoformat(),'fields':fields,'reviews':records,'refs':sorted(refs),'numbered_pad_identities':count,'fused_physical_aliases':aliases,'current_report_sha256':digest(old),'scope':'Root collection of exact-subject independently SOUND group judgments; no new root independent review, layout, release or order acceptance.'};(N/'carrier-mounted-frame-pin-adoption.json').write_text(json.dumps(record,indent=2)+'\n');print('carrier pin collection',len(refs),'refs',count,'numbered pads',aliases,'fused aliases')
