from pathlib import Path
import json,hashlib,sys,re
from datetime import datetime,timezone
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;P=R/'projects/crow-mic-pod-v3'
sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'))
from pre_route_review_check import digest,design_rules_digest
parts=sorted((P/'02_parts').glob('*/part.yaml'));fields={'board_sha256':digest(P/'04_kicad/crow_mic_pod_v3.kicad_pcb'),'parts_sha256':hashlib.sha256(b''.join(x.relative_to(P).as_posix().encode()+b'\0'+x.read_bytes()+b'\0' for x in parts)).hexdigest(),'design_rules_sha256':design_rules_digest(P)}
equiv=json.loads((N/'pod-analog-mounted-frame-equivalence.json').read_text());assert equiv['original_subject']==fields
names=['rj45-pin-pod-analog-approved','rj45-pin-pod-interface-mountedframe1','rj45-pin-pod-diodes-mountedframe1'];records=[];bodies=[];refs=[]
for name in names:
 m=json.loads((N/(name+'-opened.json')).read_text());c=json.loads((N/(name+'-closeout-summary.json')).read_text());assert c['delivery_status']=='PASS' and c['engineering_verdict']=='SOUND' and m['hashes']==fields
 raw=(Path(m['output_dir'])/'report.md').read_bytes();text=raw.decode();assert re.search(r'^design_verdict: SOUND$',text,re.M)
 for k,v in fields.items():assert re.search('^'+k+': '+v+'$',text,re.M)
 refs+=m['refs'];records.append({'name':name,'refs':m['refs'],'report_sha256':hashlib.sha256(raw).hexdigest(),'archive':Path(c['archive']).name,'archive_sha256':c['sha256']});bodies.append(text)
assert len(refs)==len(set(refs))==6 and set(refs)=={'U1','U2','J1','U3','D1','D2'}
old=P/'08_reviews/pre-route_pin.md';(N/'pod-pin-before-mounted-frame-aggregate.md').write_bytes(old.read_bytes())
head='review_stage: pre-route\nreview_kind: pin\nreviewer: Independent part-group reviewers listed below; root compiles verified unchanged reports\ncontext: Original independent group contexts, with exact-board analog proof retained by explicit frame equivalence\ndesign_verdict: SOUND\norder_verdict: DO-NOT-ORDER\n'+''.join(k+': '+v+'\n' for k,v in fields.items())+'\n# Current pod pin-review collection\n\nAll six commissioned critical references PASS: U1/U2 analog23 physical identities, J1/U3 interface15, D1/D2 diodes4;42 distinct per-instance numbered electrical identities. This collection is limited to the independent critical pin/package review; it is not whole-board layout, routing, physical service, or order acceptance. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.\n\nU1/U2 retain their original independently SOUND review on the identical native board/parts/rules. Root regenerated both mounted-frame dossiers and verified their front-mounted coordinates, identity/functions/nets/sizes/sides unchanged; old coordinate display rounded by at most0.005mm. The original report is preserved verbatim below, with its rounding and older frame wording explicit, not restamped as a fresh review. New J1/U3 and D1/D2 reviews use the corrected component-top frame. All original reports and delivery archives remain immutable.\n\n'
head+='\n'.join('- '+r['name']+': refs '+','.join(r['refs'])+'; report SHA256 '+r['report_sha256']+'; durable archive ../01_docs/journal/'+r['archive'] for r in records)+'\n\n'
combined=head+'\n\n'.join('## Verbatim independent report — '+r['name']+'\n\n'+b for r,b in zip(records,bodies))
old.write_text(combined)
record={'created_at':datetime.now(timezone.utc).isoformat(),'fields':fields,'reviews':records,'refs':sorted(refs),'current_report_sha256':digest(old),'frame_equivalence_sha256':digest(N/'pod-analog-mounted-frame-equivalence.json'),'scope':'Root collection of completed exact-subject independent SOUND judgments; no new root independent review and no release/order acceptance.'};(N/'pod-mounted-frame-pin-adoption.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
