# Pre-route physical-pin review

subject: crow-mic-pod-v3 exact zero-track placement board f27517687df124b8cab11830785659c69f1676e9d466adef4da1beacae133b22
date: 2026-09-03
review_stage: pre-route
review_kind: pin
reviewer: Codex subagent, independent exact-board physical-pin lens
context-given: full-tree, with manufacturer documents reopened independently of the design author
source_commit: 51972be041fc572ac82375950bfe8018d7352d7a
board_sha256: f27517687df124b8cab11830785659c69f1676e9d466adef4da1beacae133b22
parts_sha256: a1c05519247eb085b7db7a90a49450bff774de3eccf83042aba64bc31689e860
design_rules_sha256: 0cbb7cab0be102a78062338cd69688b8d7de20728e9e3e40cd9907fa374ecf84
route_yaml_sha256: 96ad2363151b969c8f7893cbbd64c56af4f371cf21ad3bd86a42228e85cbb858
promoted_chain_sha256: db4d0db46b9252fe1758f71cbcd7a9979c0249eeff67ffb0308fdfc50555ec9a
circuit_json_sha256: a073f897ff4fa968da80682bfa54afcdd3bb3b03f80512a78930d12fa75e39b0
kicad_schematic_sha256: 390fa3531348ac2d4f84097743ba0a6b84050dbbe33f059948dab6fe7d5b05d0
netlist_sha256: 1162400995335356e0d940bbd0446ae62afc26bc09223c7c4621923a14b5006e
exact_netlist_sha256: 6cc0d6aec6fcaebba75cbf6a1e0dcc399251679ba084ed47d0a018046e775f80
prelayout_inputs_sha256: d86f40c73a7e859c62614af3d1b1ebf245e85a4fd68cc6e73e6bf2f60906049a
prelayout_checkpoint_sha256: b351eeb8de385a8d7b8314034fc35d0b31fa675dc093acd36cffe6f51971d64a
orientation_receipt_sha256: e98a2ae8a5cd17055ed6203d85b04e3765e7bfd9c5510b2f8cf2d876c6564bba
orientation_subject_sha256: 2b187ff0810d64c47d95b1e928c13ac1a2dc7059211f18a64bffe5cdccda59fd
design_verdict: SOUND
order_verdict: DO-NOT-ORDER

## Scope and result

I independently reviewed the exact board above, its actual pads and nets, the
exact KiCad schematic and netlist, Circuit JSON, the 40-reference manifest,
all selected resistor/capacitor dossiers, and the retained manufacturer PDFs
for J1, U1, U2, U3, D1, D2 and MK1. The board contains the 40 electrical
references plus four mounting holes and zero tracks. No P0, P1 or P2 physical-
pin finding remains.

The board-to-netlist comparison covers 19 nets and 93 connected nodes, with
zero discrepancy and the same four intentional no-connects. A fresh generated
pin audit covered the seven polarity/pin-critical references. P-PINMAP grades
all 32 declared physical identities on the four multi-pin parts and passes.
The project spoke implementation also passes on this exact board and exact
schematic.

## Manufacturer-pin and polarity reconciliation

- **J1 — Molex 43650-0400.** The retained D8 manufacturer drawing's
  component-side PCB layout shows circuit 1 at the right end and the two pegs
  below the contact row. A legal 180-degree rotation puts circuit 1 at the
  project footprint's left-hand pad 1 and the pegs at local `y=-4.32 mm`,
  exactly as placed. The footprint is on F.Cu at 0 degrees and is not flipped;
  this is rotation, not reflection. Its lands are
  `1=12V_POD`, `2=GND`, `3=AUDIO_P`, `4=AUDIO_N`. The body/mouth extends
  toward board `-Y`; the exact-board orientation receipt independently reports
  a northward `[0,-1,0]` access axis, 1.0 alignment and a 0.50 mm mating-plane
  edge offset. The drawing-derived black WRL was used only for body/access
  registration, not as pin-1 evidence.
- **U1 — TI OPA1679IDR.** TI Figure 5-5 gives the D-package top-view sequence
  starting with pin 1 at the upper left and proceeding counter-clockwise. The
  unflipped footprint agrees. Pins 1/2/3 form the VREF follower
  (`VREF`, `VREF`, `VREF_RAW`); 4/11 are `5V_QUIET`/GND; 5/6/7 are the
  VREF-referenced preamplifier (`VREF`, `PRE_FB`, `PRE_OUT`); 8/9/10 are the
  complementary output section (`OUTP_DRV`, `OUTP_FB`, `VREF`); and 12/13/14
  close the spare follower (`VREF`, `SPARE_BUF`, `SPARE_BUF`). No section or
  supply pin is mirrored or interchanged.
- **U2 — TI TPS7A4901DGNR.** The DGN top-view map and the physical footprint
  agree after the board's legal 90-degree rotation: 1 OUT=`5V_QUIET`,
  2 FB=`LDO_FB`, 3 NC=open, 4 GND, 5 EN=`VIN_PROTECTED`,
  6 NR/SS=`LDO_NR`, 7 DNC=open, and 8 IN=`VIN_PROTECTED`. The manufacturer
  PowerPAD is represented as project pad 9 and is grounded. The four
  unnumbered paste apertures are not electrical pads.
- **U3 — TI TPD2E2U06DRLR.** The DRL top view and the unflipped 0-degree
  footprint agree: pins 1 and 2 are open NCs, pin 3 is IO1=`AUDIO_P`, pin 4
  is GND and pin 5 is IO2=`AUDIO_N`.
- **D1/D2.** D1 pad 1 is the footprint's silk-marked cathode end on
  `VIN_PROTECTED`; pad 2 is the anode on `12V_FUSED`, so correct-polarity
  current flows into the protected rail. The exact JKSEMI sheet names the
  two-terminal SMA part but does not assign numeric lead numbers; the numeric
  identity is therefore the explicit project pad convention, with physical
  cathode-band inspection retained in assembly. D2 follows Littelfuse's
  explicit unidirectional cathode-band convention: pad 1/cathode is
  `VIN_PROTECTED` and pad 2/anode is GND. Its -90-degree board rotation changes
  neither role nor polarity.
- **MK1 — PUI AOM-5024L-HD-R.** The PUI drawing marks the positive terminal
  and its recommended circuit drives that terminal through 2.2 kOhm. Project
  pad 1 is the marked positive wire landing on `MIC_RAW`; pad 2 is the negative
  landing on GND. This PCB object is intentionally a 5 mm two-wire landing,
  not a claim that the undimensioned capsule-terminal pitch fits the board.
  MK1 remains excluded from supplier BOM/CPL and requires manual lead-polarity
  inspection and end-to-end acoustic-polarity qualification.

## Resistor and capacitor census

All 25 R/C references pass an independent exact-MPN, dossier, footprint,
two-pad and board-versus-netlist join. Every part uses the dossier-declared
0402/0603/0805/1206/1210 footprint and has only pads 1 and 2; the ceramic
capacitors and resistors are electrically non-polar.

The pin-sensitive value spot checks are also exact: R1/R2 are 324 kOhm/100
kOhm; R3/C7/R4 are 3.9 kOhm/100 uF/2.2 kOhm; R6/R7 and R8 are 22 kOhm; R9 is
18 kOhm; R10/R11 are equal 10 kOhm parts; R12/R13 are equal 100-ohm 0805
parts; and R14 is 4.7 kOhm in 1206. C1-C11 retain the selected source values,
MPNs, packages and schematic nets. Immutable manufacturer-PDF bytes remain
owed for the commodity dossiers that explicitly say so; that is retained
order-time sourcing evidence, not an unresolved passive pin identity.

## Independent replay and permission boundary

- `pin_audit.py`: seven exact critical-part dossiers generated from the board,
  with no board-pad/part-pin join gap.
- P-PINMAP: PASS, four multi-pin references and 32 physical identities.
- Crow spoke implementation: PASS, one of one pod interface, with J1's exact
  MPN, footprint and four-pad map.
- S-COUNT: PASS, four of four artifact pairs agree with the 40-reference
  manifest.
- Board/netlist parity: PASS, 19/19 nets, 93/93 connected nodes and four/four
  intended no-connects.
- KiCad schematic parity: zero issues. The reported 74 unconnected items are
  expected on this deliberately zero-track placement board and are not a route
  or DRC completion claim.
- Connector mirror/orientation: the independent drawing-to-footprint
  reconciliation above agrees with the exact-board machine receipt and its
  hash-bound human approval.

Findings: P0 none; P1 none; P2 none within physical-pin identity, polarity,
package winding, connector mirroring or schematic-to-board pad mapping.

## Routing-authority metadata renewal

The raw route YAML hash and the two checkpoint hashes above were renewed after
the routing-tool path moved from the primary checkout to the detached worktree
`/home/mouse9911/gits/KiCadRoutingTools-worktrees/cccv-5a1bdc4`. The route-file
delta changes only that path and its explanatory comment. The target's tracked
source is clean at commit
`5a1bdc4d9582fa6c9019cf5bab9625ea4452f188`; its only full-status entry is an
untracked `.venv/`, not a tracked source change. The board, placement, seed
geometry, parts, schematic, netlist and semantic `design_rules_sha256` are
byte- or digest-identical to the subject reviewed above. This metadata renewal
therefore adds no physical-pin finding and does not widen the review boundary.

The hashes were renewed again at source commit
`69b75bff9393eda159974aa6ce1e5f8b3610aab7` when the accepted pre-stitch
chain was added at `03_src/route/final_chain.kicad_pcb` and `route.final` /
`route.import_source: promoted` selected it. This is metadata-only with
respect to the pin lens: the zero-track board subject remains the committed
`f2751768...` placement. A mechanical comparison found zero footprint or pad
differences across all 44 footprints between that exact base, the promoted
`db4d0db4...` chain and the later routed worktree output. Direct
P-ROUTEBASE comparison of the existing prepared base to the promoted chain
passes 44 footprints, eight source/prepared vias and 94 prepared segments.
The normal timestamp-sensitive invocation correctly requires `prep` to be
rerun after the newer promotion commit; canonical reuse performs that step
before consuming this placement witness. No conclusion about the promoted
track geometry, final routed board or fabrication follows from this pin-only
compatibility check.

The header was finally renewed at source commit
`6f294faced0e37865c9ee2d4e06c267cc74ddda5` after the deterministic reuse
driver replaced an impossible raw KiCad-netlist byte comparison with the same
narrow electrical `netlist_digest` already used by PR-REVIEW. A fresh export
from the pinned schematic had different raw path/date/UUID bytes but produced
the exact same normalized `11624009...` digest as the frozen netlist. The
26-case crow prelayout-resume suite passes, including its hostile case that
rejects replacing the normalized comparison with a raw-byte comparison. For
the pod, this commit otherwise changes only the two refreshed checkpoints;
the exact board subject, route YAML, promoted chain, parts, schematic,
electrical netlist and semantic design-rule hashes above are unchanged. This
fail-closed conductor correction therefore adds no physical-pin finding and
does not widen the review boundary.

The order verdict remains `DO-NOT-ORDER`. Live authenticated PCBA allocation,
manual J1 assembly and mate continuity, MK1 enclosure/wiring, exact diode/IC
orientation inspection, cable behavior and first-article electrical/acoustic
qualification remain explicit holds. This witness certifies only the physical-
pin lens of the exact zero-track placement board. It is not a standalone
routing authorization and makes no routed-copper, fabrication, assembly,
procurement, environmental-fit or deployment claim.
