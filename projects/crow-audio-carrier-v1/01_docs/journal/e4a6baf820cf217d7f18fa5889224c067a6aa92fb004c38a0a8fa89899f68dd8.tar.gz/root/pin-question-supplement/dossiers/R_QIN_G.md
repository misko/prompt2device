# pin dossier: R_QIN_G  (RC0402FR-07100KL)

- footprint: Resistor_SMD:R_0402_1005Metric
- board position: (40.000000, 79.000000) rot 90.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/RC0402FR-07100KL/Yageo_RC0402FR-07100KL_20260908.pdf
- part.yaml verification note: Exact YAGEO MPN/code/value/package match selected 2026-09-01.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-0.510000,+0.000000) | W | 0.54x0.64 | A | Q_IN_GATE | (+40.000000,+79.510000) |
| 2 | (+0.510000,+0.000000) | E | 0.54x0.64 | B | GND | (+40.000000,+78.490000) |
