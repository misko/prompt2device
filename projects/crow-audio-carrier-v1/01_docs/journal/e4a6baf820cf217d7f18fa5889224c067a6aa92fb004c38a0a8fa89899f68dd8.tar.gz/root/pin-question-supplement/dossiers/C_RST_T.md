# pin dossier: C_RST_T  (CL10B224KA8NNNC)

- footprint: Capacitor_SMD:C_0603_1608Metric
- board position: (122.600000, 73.200000) rot 90.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/CL10B224KA8NNNC/Samsung_CL10B224KA8NNN_specsheet.pdf
- part.yaml verification note: Exact MPN/code/value/package match selected 2026-09-01. A deliberately conservative screening allocation of -10% tolerance, -50% DC-bias loss, and -15% temperature loss leaves 84.15nF; this is not a manufacturer curve or a release performance claim.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-0.775000,+0.000000) | W | 0.9x0.95 | A | RESET_C | (+122.600000,+73.975000) |
| 2 | (+0.775000,+0.000000) | E | 0.9x0.95 | B | RESET_RC | (+122.600000,+72.425000) |
