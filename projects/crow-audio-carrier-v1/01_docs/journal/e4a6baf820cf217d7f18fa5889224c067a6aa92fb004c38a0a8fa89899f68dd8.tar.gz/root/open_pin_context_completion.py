from placement_review_common import *
import re
kind=sys.argv[1];oldname='rj45-pin-carrier-'+kind+'-mountedframe1';name='rj45-pin-carrier-'+kind+'-context1'
meta=json.loads((N/(oldname+'-opened.json')).read_text());old=Path(meta['project']);assert json.loads((Path(meta['envelope']).parent/'attempt.json').read_text())['status']=='PASS'
refs={'conversion':['R_CFG1','R_CFG2','R_CFG4','R_CFG5'],'tvs':['Q_IN','R_QIN_G'],'clock-reset':['R_RST_T','C_RST_T']}[kind]
paths=[]
for row in json.loads(Path(meta['envelope']).read_text())['input_packet']:
 if row['path'] not in ['TASK.md','preflight.py']:paths.append((old/row['path'],row['path']))
for ref in refs:
 p=N/'pin-question-supplement/dossiers'/(ref+'.md');paths.append((p,'supplement/dossiers/'+p.name))
 ds=Path(re.search(r'^- datasheet: (.+)$',p.read_text(),re.M).group(1));ds=ds if ds.is_absolute() else R/ds
 paths.append((ds,ds.relative_to(R).as_posix()))
paths=list(dict.fromkeys(paths));paths.append((Path(meta['output_dir'])/'report.md','previous-completed-report.md'))
paths.append((N/(oldname+'-closeout-summary.json'),'previous-closeout.json'))
extra={'conversion':'Derive actual ADC mode from the four added native resistor dossiers and exact selected resistor PDFs. Compare against CS5308P mode tables and the already supplied ADC pin wiring. Do not assume a desired mode to force agreement.','tvs':'The added Q_IN and R_QIN_G native dossiers provide actual FET source/gate/drain and pull-down endpoints. Derive device polarity from its primary PDF and determine whether the zener orientation is consistent.','clock-reset':'The added R_RST_T and C_RST_T native dossiers provide the exact timing network endpoints and selected component MPNs. Derive required capacitor/resistor connection from the existing primary PDF and compare.'}[kind]
task=f"""# Bounded completion of missing pin context — {kind}

Continue your own independently completed original physical pin review against unchanged original dossiers plus the narrowly requested native supporting-component dossiers and their exact primary PDFs. Original INCOMPLETE delivery is closed and immutable. This is an added-fact question resolution, not a replacement attempt or source candidate. Preserve prior physical findings by exact identity, state inherited versus newly verified coverage, and do not redo successful whole-group work. {extra}

No live project, schematic, author rationale, extra source changes, or children. Same pin-review protocol applies. Read actual relevant primary figures; record new input hashes and facts. If the original question is resolved issue a new complete group report with original board/parts/rules bindings, per-ref verdicts and explicit continuation provenance; never overwrite old report. If not resolved identify the precise missing fact or defect honestly. Only SOUND if every commissioned ref passes. Keep FIRST-ARTICLE-ONLY / DO-NOT-ORDER. Context field must honestly describe independent original pin context continued with native requested facts (do not claim a new fresh agent). Flat report metadata uses review_stage: pre-route, review_kind: pin, design_verdict: SOUND|DEFECTIVE|INCOMPLETE, original subject bindings. Evidence verdict matches report. Old group scope remains unchanged.
"""
o=open_task(name,task,paths,minutes=15);o['agent_id']=meta['agent_id'];o['refs']=meta['refs'];o['hashes']=meta['hashes'];o['slug']=meta['slug'];(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n')
