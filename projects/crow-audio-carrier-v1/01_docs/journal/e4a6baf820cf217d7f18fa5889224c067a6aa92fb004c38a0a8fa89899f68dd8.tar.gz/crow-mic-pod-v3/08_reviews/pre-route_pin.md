review_stage: pre-route
review_kind: pin
reviewer: Independent part-group reviewers listed below; root compiles verified unchanged reports
context: Original independent group contexts, with exact-board analog proof retained by explicit frame equivalence
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: a44b769b1a5ad5fa959b476bd30f91a64aeaba9ad64d7868fa4e60ffbb62ee48
parts_sha256: adf3f7221a131e270f963fab153a2e2f56262932f1e272af9cbc0e4814d5c8a6
design_rules_sha256: 02c4ed58432368b92e3019a06bf20c137dbf90765af16c96c458790e88d54a9f

# Current pod pin-review collection

All six commissioned critical references PASS: U1/U2 analog23 physical identities, J1/U3 interface15, D1/D2 diodes4;42 distinct per-instance numbered electrical identities. This collection is limited to the independent critical pin/package review; it is not whole-board layout, routing, physical service, or order acceptance. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.

U1/U2 retain their original independently SOUND review on the identical native board/parts/rules. Root regenerated both mounted-frame dossiers and verified their front-mounted coordinates, identity/functions/nets/sizes/sides unchanged; old coordinate display rounded by at most0.005mm. The original report is preserved verbatim below, with its rounding and older frame wording explicit, not restamped as a fresh review. New J1/U3 and D1/D2 reviews use the corrected component-top frame. All original reports and delivery archives remain immutable.

- rj45-pin-pod-analog-approved: refs U1,U2; report SHA256 62358161c20c53eef11eb614ac57ebfc923643e36c90c019b93299a75d0fd51b; durable archive ../01_docs/journal/00a00b04cd301851a7c06d4dce11be790b793e412fd4cb3691fa21f07540ad59.tar.gz
- rj45-pin-pod-interface-mountedframe1: refs J1,U3; report SHA256 4dd61c80d92468361eb02a7813bf18a9ab940a392b0fe60f28fb1730ce5e0144; durable archive ../01_docs/journal/1ead989bfed92c5d1dae8abe3d67d90a35b294c395f4706b8deb44d15e6a2b18.tar.gz
- rj45-pin-pod-diodes-mountedframe1: refs D1,D2; report SHA256 632ee919a7157e2a84395cf288914545fc4ae3e8f7127ee5b5d3969eb27581cd; durable archive ../01_docs/journal/7f804900cfac9248dadff9576f29a656c2c77be261b964339a4e7a31c9045ae6.tar.gz

## Verbatim independent report — rj45-pin-pod-analog-approved

review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_pod_analog_approved (actual fresh independent agent)
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: a44b769b1a5ad5fa959b476bd30f91a64aeaba9ad64d7868fa4e60ffbb62ee48
parts_sha256: adf3f7221a131e270f963fab153a2e2f56262932f1e272af9cbc0e4814d5c8a6
design_rules_sha256: 02c4ed58432368b92e3019a06bf20c137dbf90765af16c96c458790e88d54a9f
subject_raw_sha256: eb4c949e854392aeb4ed0f266bb5ed41f4742197118ea5a38815ec7fa91280ef
subject_semantic_sha256: 2e4c182741642c8439045f5dd58f178a439890fcc3ea7519bc17e5def8eb6588

Limited group coverage: U1 and U2 only, every commissioned instance checked. SOUND means these two parts pass the commissioned pin/function/net-kind review. No whole-board acceptance or permission to order. Board/parts/rules hashes above are immutable subject metadata, not independently reviewed conclusions.

## U1

VERDICT: PASS

Primary PDF: `projects/crow-mic-pod-v3/02_parts/OPA1679IDR/opa1679.pdf`; SHA-256 `4072daad4ebc4ec9a74ba6547d721b05db8d0cfc12924bda79e828271aeaec3b`.

Sources: PDF page 5 Figure 5-5 and Pin Functions: OPA1679; PDF pages 44/45 D0014A package outline/example board layout. PDF page 29 package option addendum maps OPA1679IDR to SOIC (D), 14 pins.

Expected D SOIC14: 7 leads per side, pin1 upper-left, CCW top view, no EP or fused pins. Observed 14 numbered native pad rows, 14 unique identities and centers; pins1..7 x=-2.48 and pins8..14 x=+2.48; pin1=(-2.48,-3.81); signed area -37.7952 mm2 in +y-down frame; CCW. No missing or duplicate pins or alias declarations.

Some dossier side labels say N/S because of directional sectors; actual coordinates establish two vertical lead rows and correct winding. Native pitch is 1.27 mm, agreeing with the package. The native 1.95 x 0.60 mm lands centered 4.96 mm apart span the manufacturer lead locations; no identity or mirror defect. D package has no thermal pad; QFN pad requirements are not applied to this SOIC.

- U1 pin 1 (OUTA): expected reference-drive output; observed `VREF` — PASS.
- U1 pin 2 (IN_A_NEG): expected reference-buffer feedback, same net as OUT A; observed `VREF` — PASS.
- U1 pin 3 (IN_A_POS): expected reference input; observed `VREF_RAW` — PASS.
- U1 pin 4 (V_PLUS): expected positive supply rail; observed `5V_QUIET` — PASS.
- U1 pin 5 (IN_B_POS): expected signal/reference input; observed `VREF` — PASS.
- U1 pin 6 (IN_B_NEG): expected feedback sense; observed `PRE_FB` — PASS.
- U1 pin 7 (OUTB): expected signal output; observed `PRE_OUT` — PASS.
- U1 pin 8 (OUTC): expected signal-drive output; observed `OUTP_DRV` — PASS.
- U1 pin 9 (IN_C_NEG): expected feedback sense; observed `OUTP_FB` — PASS.
- U1 pin 10 (IN_C_POS): expected signal/reference input; observed `VREF` — PASS.
- U1 pin 11 (V_MINUS): expected lowest supply rail; observed `GND` — PASS.
- U1 pin 12 (IN_D_POS): expected signal/reference input; observed `VREF` — PASS.
- U1 pin 13 (IN_D_NEG): expected buffer feedback, same net as OUT D; observed `SPARE_BUF` — PASS.
- U1 pin 14 (OUTD): expected buffer output; observed `SPARE_BUF` — PASS.

## U2

VERDICT: PASS

Primary PDF: `projects/crow-mic-pod-v3/02_parts/TPS7A4901DGNR/tps7a49.pdf`; SHA-256 `0a5e198966ab05ebb39f4512355352c0946af5f52e1fbd2e9ec554041123a126`.

Sources: PDF page 4 Section 5 DGN top-view pin drawing and Pin Functions; PDF pages 33/34 DGN0008D package outline/example board layout. PDF page 24 package option addendum maps TPS7A4901DGNR to HVSSOP (DGN), 8 leads.

Expected DGN: 8 leads plus separate PowerPAD9; 4 leads per side, pin1 upper-left, CCW top view. Observed 9 numbered native pad rows, 9 unique identities and centers; pins1..4 x=-2.15, pins5..8 x=+2.15; pin1=(-2.15,-0.97); peripheral signed area -8.342 mm2 in +y-down frame; CCW. Center pad9 GND. No missing or duplicate pins or alias declarations. Four unnumbered paste/mechanical pads reported omitted: 13 total pad objects reported, but 9 electrical identities independently counted.

The native 90-degree placement rotation is undone in the dossier and does not mirror the package. On PDF page 33, the upper package drawing has pin1 upper-left; lower drawing shows underside exposed pad with pin1 lower-left. Board top-view numbering uses the upper drawing and PDF page34 land pattern. Native center pad9 is 1.57 x 1.89 mm, consistent with the DGN0008D exposed-pad land, and connected to GND as permitted. Rounded lead coordinates agree with 0.65 mm pitch. Physical PowerPAD identity9 is retained separately from GND pin4.

- U2 pin 1 (OUT): expected regulated output rail; observed `5V_QUIET` — PASS.
- U2 pin 2 (FB): expected feedback divider/sense node; observed `LDO_FB` — PASS.
- U2 pin 3 (NC): expected open or ground; observed `unconnected-(U2-NC-Pad3)` — PASS.
- U2 pin 4 (GND): expected ground; observed `GND` — PASS.
- U2 pin 5 (EN): expected enable logic; may connect to IN; observed `VIN_PROTECTED` — PASS.
- U2 pin 6 (NR_SS): expected noise-reduction capacitor node; observed `LDO_NR` — PASS.
- U2 pin 7 (DNC): expected no electrical connection; observed `unconnected-(U2-DNC-Pad7)` — PASS.
- U2 pin 8 (IN): expected input supply rail; observed `VIN_PROTECTED` — PASS.
- U2 pin 9 (POWERPAD): expected open or ground thermal pad; observed `GND` — PASS.

## Scope and retained evidence

Exactly one instance of each part is commissioned; same-part cross-instance symmetry is not applicable. U1 channels A/D have matching output/inverting-input buffer nets; B/C have corresponding output and feedback net kinds. All 23 physical electrical identities are individually retained.

U2 NC pin3 and DNC pin7 carry native `unconnected-(...)` markers, consistent with no-connect intent. These markers are not evidence of a routed external connection. This review accepts per-pin net kinds and does not establish hidden topology, required output/NR capacitor presence or values, rail magnitudes, or analog loop behavior. No pin/function mismatch or required pin-review QUESTION was identified.

Independent pin derivation was recorded from source images before dossier content was read. All six inspected PNGs, extracted primary text, native dossier copies, exact input digests, derivation, measured rows, methods, finite subprocess commands/raw logs/runtime, report and evidence JSON are retained in evidence.tar.gz. Whole PDFs remain in the digest-bound frozen input packet. Every envelope input is size/hash verified before and after review. The three checks in result.json describe complete honest handback, not whole-board engineering acceptance.


## Verbatim independent report — rj45-pin-pod-interface-mountedframe1

review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent /root/rj45_pin_pod_interface_mountedframe1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: a44b769b1a5ad5fa959b476bd30f91a64aeaba9ad64d7868fa4e60ffbb62ee48
parts_sha256: adf3f7221a131e270f963fab153a2e2f56262932f1e272af9cbc0e4814d5c8a6
design_rules_sha256: 02c4ed58432368b92e3019a06bf20c137dbf90765af16c96c458790e88d54a9f

Coverage is limited to J1 and U3, one instance of each, in the supplied frozen native dossiers. This is no whole-board acceptance, routing review, mating-system review, or order authorization. The immutable hashes above are commissioned subject metadata, not independently reviewed whole-board conclusions.

The primary figure images were rendered and inspected before opening the native dossiers. Dossier author verification notes were not used as evidence. Only the supplied protocol, native dossiers, and exact SHA-selected primary PDFs informed engineering judgment. See independent-figure-derivation.md, measurements.json, and the archived actual rendered PNGs.

J1 VERDICT: PASS

Primary: Wurth_615008160221_rev001003.pdf, SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048; PDF page 1/6, Dimensions and Recommended Hole Pattern, revision 001.003 dated 2025-07-09. Page 2 states 8P8C. Page 1 images were inspected at 120 and 180 dpi.

View derivation: the recommended hole pattern is interpreted as the mounting/component-top pattern from the mechanical multiview, not as the adjacent underside view. In the upper-left underside drawing the contact tails are toward the lower/rear edge with the mouth above; in the top/body drawing below the mating-face view the mouth is below. The hole pattern likewise places the contact rows toward the rear/upper edge and shield slots toward the mouth/lower edge. This relation distinguishes the top pattern from the underside drawing; the pattern itself does not carry a literal TOP VIEW caption. The underside mechanical image would require reflection to become top view, and was not directly compared as though top. The actual numbered recommended hole pattern is compared by a single 180-degree rotation, without a mirror. J1 is explicitly front-mounted, so its native-to-component-top frame has no reflection.

The manufacturer pattern, using x=0 on its centerline and y=0 on the even row, gives pin 1 at (3.57,4.00), 2 at (2.55,0), 3 at (1.53,4), 4 at (0.51,0), 5 at (-0.51,4), 6 at (-1.53,0), 7 at (-2.55,4), 8 at (-3.57,0). Rotate 180 degrees about pin 1 and translate to its local origin: (x_local,y_local)=(3.57-x,4-y). Every dossier contact center agrees, residual below 1e-6 mm. Pin 1 becomes the upper-left contact; odds run left-to-right on y=0, evens on y=4. The manufacturer's zigzag numbering is not a perimeter sequence, so the dossier's computed CCW label and coarse W/S/N/E side classifications are not independent winding evidence. Individual identities and row offsets are decisive.

J1 pin 1 (CONTACT_1): expected distinct passive contact at (0,0); observed pad 1 at (0,0), 12V_POD.
J1 pin 2 (CONTACT_2): expected distinct passive contact at (1.02,4); observed pad 2 at (1.02,4), GND.
J1 pin 3 (CONTACT_3): expected distinct passive contact at (2.04,0); observed pad 3 at (2.04,0), 12V_POD.
J1 pin 4 (CONTACT_4): expected distinct passive contact at (3.06,4); observed pad 4 at (3.06,4), AUDIO_N.
J1 pin 5 (CONTACT_5): expected distinct passive contact at (4.08,0); observed pad 5 at (4.08,0), AUDIO_P.
J1 pin 6 (CONTACT_6): expected distinct passive contact at (5.10,4); observed pad 6 at (5.10,4), GND.
J1 pin 7 (CONTACT_7): expected distinct passive contact at (6.12,0); observed pad 7 at (6.12,0), 12V_POD.
J1 pin 8 (CONTACT_8): expected distinct passive contact at (7.14,4); observed pad 8 at (7.14,4), GND.
J1 pad 9 (SHIELD_S1): expected one separate shield leg at (10.97,-2.35) after the same rotation; observed pad 9 there on POD_SHIELD.
J1 pad 10 (SHIELD_S2): expected the other shield leg at (-3.83,-2.35); observed pad 10 there on POD_SHIELD.

The primary drawing does not number the two shield legs 9/10; those are artifact identities assigned to the two physically distinct legs, which remain separate. No fused alias is needed or inferred. Both shield pads have the same appropriate shield-net kind. The eight numbered contacts are passive and have no manufacturer-imposed power/data polarity; the observed rail, ground, and audio nets do not conflict with their intrinsic functions. This finding does not certify an external cable pinout, load-current budget, or audio-system polarity.

Measured census: 10 numbered native pad rows and 10 unique electrical/metal-terminal identities (8 contacts plus 2 shield legs), plus 2 dossier-reported unnumbered mechanical/paste pads, total 12 native pads reported. The latter two are omitted from the native position table and were not independently measured as locating holes. The primary depicts two locating holes; their drill dimensions/locations and fabrication clearances are outside this electrical pin-identity verdict. No exposed pad or collapsed physical pin identity exists in the reviewed map. Native-board coordinates equal local plus (45.50,25.86), within 1e-6 mm for all ten rows.

U3 VERDICT: PASS

Primary: tpd2e2u06.pdf, SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; PDF page 3 section 5 DRL Package 5-Pin SOT Top View and Pin Functions; PDF pages 17 and 18 DRL0005A Package Outline and Example Board Layout (4220753/E 11/2024). The DCK pinout on the same page is not applicable to TPD2E2U06DRLR.

Expected top view: left side top-to-bottom pins 1,2,3; right side bottom-to-top 4,5. Pin 1 upper left, numbers wind CCW. Observed component-top coordinates and W/E sides match directly without any extra mirror: 1=(-0.7125,-0.5), 2=(-0.7125,0), 3=(-0.7125,+0.5), 4=(+0.7125,+0.5), 5=(+0.7125,-0.5). The explicitly back-mounted 180-degree instance has native x=49.07-local_x and native y=27.86+local_y; all five rows satisfy this conversion within 1e-6 mm. Its native front projection is appropriately mirrored relative to the mounted-side top view, and was not substituted for that view.

U3 pin 1 (NC): expected no internal connection; datasheet permits floating, GND, or VCC; observed distinct unconnected-(U3-NC1-Pad1) net.
U3 pin 2 (NC): same expectation; observed distinct unconnected-(U3-NC2-Pad2) net.
U3 pin 3 (IO1): expected protected data channel; observed AUDIO_P.
U3 pin 4 (GND): expected ground; observed GND.
U3 pin 5 (IO2): expected protected data channel; observed AUDIO_N.

Measured census: 5 native pad rows, 5 unique pad IDs and 5 physical lead identities, no omitted or fused leads, no EP required or observed. Primary DRL outline and example layout show five individual lands and no center thermal land. Dossier land-column separation 1.425 mm is 0.055 mm smaller than TI's 1.48 mm example; 0.68 x 0.35 mm pads also differ from the example 0.67 x 0.30 mm. The 0.5 mm row pitch, lead identity, sidedness and top-view winding agree; these small alternate land dimensions are not represented as an exact copy of TI's example or as a pin-map defect.

Instance symmetry: each commissioned part has one instance, so no same-part cross-instance comparison is available. Within U3, IO1 and IO2 both see the same kind of audio data net. J1's repeated power/ground contacts remain physically distinct; both shield legs remain distinct on POD_SHIELD. U3 IO1/AUDIO_P corresponds to J1 contact 5/AUDIO_P, and U3 IO2/AUDIO_N to J1 contact 4/AUDIO_N in the supplied net names.

No unresolved pin-review findings. SOUND applies only because both commissioned refs PASS. DO-NOT-ORDER remains mandatory for this pre-route limited review. Evidence archive retains the exact inspected figure images, native dossiers, primary input hashes, derivation, measurements, methods and raw engineering execution records. Full primary PDFs remain digest-bound in the frozen packet.


## Verbatim independent report — rj45-pin-pod-diodes-mountedframe1

review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_pod_diodes_mountedframe1 (fresh independent agent)
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: a44b769b1a5ad5fa959b476bd30f91a64aeaba9ad64d7868fa4e60ffbb62ee48
parts_sha256: adf3f7221a131e270f963fab153a2e2f56262932f1e272af9cbc0e4814d5c8a6
design_rules_sha256: 02c4ed58432368b92e3019a06bf20c137dbf90765af16c96c458790e88d54a9f

Coverage is limited to commissioned refs D1 and D2. Both PASS. This is not whole-board acceptance, routing review, assembly inspection, or permission to order. The three hashes above are immutable subject bindings, not independently reviewed conclusions. Exact envelope subject is retained in evidence.json.

D1 — VERDICT: PASS

Primary: JKSEMI 1N4007(M7)SMA, 2021-10-21 revision c; SHA-256 f893d8385c6fee5af85b9053653bd8e93547c335c031cbab9ecb592c0bb5eddd. Inspected page 1 product illustration, page 2 characteristic figures, page 3 PACKAGE OUTLINE and recommended mounting pads, including an enlarged page-3 render.

The page-1 oblique top illustration shows an end band on a two-terminal SMA rectifier. I interpret this visible band as the conventional cathode mark. The PDF does not literally label that band cathode and does not assign numeric pin IDs; neither omission establishes an ambiguous mark or a pin error. Page 3 explicitly identifies two leads and shows the two opposed terminations and two mounting lands. No exposed pad or fused group is shown. Top/side/end and underside mechanical projections are not numbered pin diagrams and were not mirrored to derive polarity. The banded terminal is K, and the opposite terminal is A; local numeric IDs are compared through those physical functions.

D1 pin 1 (K): expected banded cathode at one end, receiving forward current from A; observed W land at component-top (-2.000,0.000), VIN_PROTECTED. This is consistent with the output of the series rectifier fed by 12V_FUSED.
D1 pin 2 (A): expected opposite terminal and upstream positive supply for forward series conduction; observed E land (+2.000,0.000), 12V_FUSED. Forward direction is 12V_FUSED -> A -> K -> VIN_PROTECTED.

Measured from native dossier: 2 copper pad records, 2 unique numeric pad identities, 2 separate physical terminal identities, 0 EP, 0 collapsed identities, 0 fused aliases. Pad centers are 4.000 mm apart; each land is 2.5 x 1.8 mm. A two-terminal collinear part has no pin-1 corner or CW/CCW winding; the dossier's n/a is correct. Orienting the banded end west requires only rotation of the top component, with no mirror. Front mount at (39.500,35.600), native rotation 0 degrees, gives pad 1 (37.500,35.600) and pad 2 (41.500,35.600), exactly as observed.

D2 — VERDICT: PASS

Primary: Littelfuse SMBJ series v4, revised JC.07/04/25; SHA-256 d7df155be4b1f612085401e8c946f065e284d65a0e7de22b9225a7b73946e51b. Inspected page 1 Functional Diagram and product images, page 2 exact SMBJ15A row, page 5 Physical Specifications and Dimensions, page 6 Part Numbering/Marking System and tape polarity figure.

Page 5 depicts the package top with cathode band at the left end and the other lead at the right; its lower body drawing is a side profile. Page 6 shows a top marking view with cathode band at the upper end, reconciled with page 5 by a 90-degree rotation, not a reflection. The page-1 unidirectional diagram independently identifies K and A. SMBJ15A is the unidirectional variant, with 15 V standoff in its exact table row. Two opposed SMB J-bend terminals and no EP or fused identities are shown. Manufacturer numeric pin numbering is absent; physical K/A identities provide the comparison.

D2 pin 1 (K): expected banded terminal on the positive protected rail for reverse-biased shunt protection; observed W land (-2.150,0.000), VIN_PROTECTED.
D2 pin 2 (A): expected opposite terminal on return; observed E land (+2.150,0.000), GND. This maps the unidirectional TVS correctly across the protected positive rail and ground.

Measured from native dossier: 2 copper pad records, 2 unique numeric pad identities, 2 separate physical terminal identities, 0 EP, 0 collapsed identities, 0 fused aliases. Pad centers are 4.300 mm apart; lands are 2.5 x 2.3 mm. Two collinear terminals establish no winding or pin-1 corner; dossier n/a is correct. Front mount at (27.300,38.000), native rotation -90 degrees, gives K/pad 1 (27.300,35.850) and A/pad 2 (27.300,40.150). In component-top coordinates K remains west; native north is the rotated board-front projection, not a mirroring defect.

Pairwise check: these are different parts and different circuit roles, not duplicate instances. Both use pad 1 = K and pad 2 = A; both cathodes connect to VIN_PROTECTED. D1's A connects to the upstream 12V_FUSED rail, while D2's A connects to ground, consistent with series rectification versus shunt TVS protection. No unexplained instance asymmetry is present.

Method and limits: inspected actual PDF images before comparing the dossier tables; extracted text was used to locate pages. Both dossiers explicitly declare mounted side and component-top convention. Native counts were measured by parsing their pad records, and native positions reconstructed using the stated translations and KiCad rotations. No live design, schematic, historical review, or unrelated primary document was inspected. The dossiers' verification-note claims were not treated as evidence. Only the commissioned pin/package identity and function-net sanity questions are graded. All original input hashes and sizes were verified before and after review. There are no unresolved engineering findings within this scope.
