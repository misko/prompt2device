review_stage: pre-route
review_kind: topology
reviewer_identity: /root/carrier_rj45_native_carrier_topology_mediumfinal3
context: FRESH
date: 2026-09-16T02:49:31.858972+00:00
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
netlist_sha256: 1a67c6e52fa59b14e390ee3a4739efd9864add4f352bf797f4edd952e6a9b1d5
parts_sha256: 7e43d5d63f3021d88fa96b12d4f5bd80048868bad8f66fd53bc1f112743950fd
design_rules_sha256: f2e6cd923804d2dc0465891839c7f6580ff8fe2821aafbd5aba8b163ee40a7ca
schematic_pdf_sha256: 764d33f2f0157f660cffb545106c31a519d2eba800f57fc0f60946224806bd5f
exact_netlist_sha256: 4c88c72afdbd913ffb761033938a69564b60fae72203b899611f2534894001fd
circuit_json_sha256: 3ba272d8fb5b27dd6243bf82a0745bacfed5213faec003d11ba3572b171c13eb
kicad_schematic_sha256: 3c5c1735e65872805ab44a5fb57d67d54eb35890993a3adeb9db080358daf39f

Fresh independent judgment: SOUND for the frozen pre-route topology and the specific authored corrections reviewed here. DO-NOT-ORDER remains mandatory. This is not native board, final routing, fabrication, assembly or production acceptance.

Measured current coverage

I reused archived independent review methods, inspected them, and reran them on the current packet. JSX declaration evaluation, a separate native S-expression parser, and union-find over circuit.json source traces agree on all333 components and943 connected nodes. The complete native census is985 nodes on221 nets, including42 explicit NC nodes. All333 values/MPNs/dossier footprints and native schematic properties agree;120 resistance strings differ only in unit spelling. All988 physical dossier pins resolve through985 native identities plus the three documented Q_IN drain aliases. This includes schematic property fidelity; it is not an independently re-exported native wire netlist.

All205 electrical invariants pass independent evaluation:152 pin/net,51 value,one series-chain and one capacitor-census assertion. Current conditional screens applied to my independently parsed native inventory pass9/9 clock,7/7 TDM and10/10 power/protection checks. Analog coverage is8 exact OPA2320 duals,16 current-limit resistors,16 same-leg feedback resistors,32 shunts,2 external half-supply dividers,2 direct reference-negative returns and2 polarized reference capacitors. Those screens remain conditional engineering bounds, not measured transient/thermal/SI guarantees. Broad project regression and native generation were not repeated.

Corrective deltas and safety authority

The semantic route comparison finds exactly three changed homes from the archived full-review route: reset relocation target, two added endpoint recipes, and the ADC3P seed stub. Replacing only those homes reproduces the prior route. Reconstructing the prior design-rules digest using current rules and that prior route exactly matches the historical digest; no other rule semantics or numeric floor changed. Current floorplan/nets/invariants/supervisor dossier hashes also match the archived reviewed versions. The fresh inventory.json equals the archived complete inventory exactly; historical acceptance was not inherited.

ADC_RESET_N now targets(98.1,74.17), diameter0.30/drill0.20mm, F.Cu–B.Cu. Its two explicit0.20mm F/B endpoint recipes retain the original far endpoints and terminate at the corrected via. At1.6mm nominal thickness the aspect is8:1, or8.8:1 at+10%, below10:1. Independent point-to-segment arithmetic finds0.502406mm edge clearance to the closest authored governed digital seed, ADC_FSYNC, exceeding0.50mm. Final routed-copper reference continuity remains a later gate.

ADC3P/U_ADC.42 now places its via at(99.5,64.9), with one direct0.15mm F.Cu leaf to(99.5,65.3) and the B.Cu endpoint shortened to64.9. Independent expansion of all333 placement anchors/repeat members and isolated native footprint shapes locates C_ADC_CM3P.1 at(99.4,65.28). The prior via center(99.5,65.3) positively overlaps this land; the corrected center does not, and the direct leaf intersects its intended land.

Across985 current component lands,215 ordinary authored via specifications from prep/stitch seeds and exact relocation targets have zero drill-center land overlaps. Eleven separately declared0.60/0.30mm filled-and-capped thermal vias lie only in their permitted exposed pads:9 at U_ADC.49 and2 at U_LDO.15. This source census is not an imported/routed-board census. Native library bytes used as geometry tools are copied and hashed; three native property-enum diagnostics were emitted, with the geometry checks completing successfully.

Selected authority is nets.yaml fab_tier:jlc_4layer_advanced and route.common fab_tier:advanced plus the explicit route_fab_overrides.txt. The latter implies0.05mm annulus from0.25/0.15mm minima. All212 paired source configurations, including thermal fields, meet those paired minima, annulus and10:1 limits; all actual authored drills are at least0.20mm. The unchanged older floorplan0.13mm annulus/0.45mm via defaults are not the selected route contract. I inspected and hashed shared tier/synchronization tooling as tool context; its synchronization preserves named netclasses, assignments and severities. Actual synchronization and emitted native floors must still be proven in the later native run. No tool-context bytes are presented as frozen engineering authority.

Both digital no_vias:true groups retain13 nets and110 authored F.Cu seed segments with zero vias;10 nets have seed copper and3 have none. Per-net minima remain0.18mm, at most3 subnominal segments and at most3mm accumulated subnominal length (maximum ADC_FSYNC2.827200mm). The seed census does not claim completed routes. Existing reference-plane, hole spacing, copper-gap, thermal and ampacity requirements remain bound and unchanged.

Footprint, interfaces and ratings

Current U_PWR/U_AUDIO both use TI_DSE0006A_GNDToe018. Independent S-expression comparison proves only pad2 copper extends0.18mm outward; inward edge, other five lands, model, courtyard and pin1 feature are preserved. All six paste apertures retain exact geometry. Derived mask openings on pads1–3 are0.70x0.15/0.60x0.15/0.60x0.15mm; pads4–6 retain explicit0.05mm expansion. The archived TI pages25–26 were visually reopened, and their primary PDF remains hash-bound. The README correctly discloses the conflicting upper outline versus lower explicit SMD detail, engineering derivation and paste overprint. Gerber aperture and first-article solder inspection remain owed.

R_FSYNC is22ohm CRCW120622R0FKEAHP,1206 footprint, C844025; current dossier declares750mW,1%,100ppm/C and retained Vishay20043 revision20260317. Buffer mapping, all three22ohm terminations,10k input pulldowns and100nF bypass agree. No package-parasitic or impedance guarantee follows.

All80 RJ45 contacts agree:1/3/7=12V_PODn,2/6/8=GND,5=AUDIO_Pn,4=AUDIO_Nn,9/10=CHASSIS. CHASSIS has exactly16 shell nodes and no GND connection. These are custom analog/power cables, not Ethernet/PoE. Input fuse, reverse-polarity MOSFET/gate clamp and cathode-to-bus TVS topology agree. The adopted24.4V×1.2=29.28V transient bound remains below32V buck and50V input ceramics; sustained overvoltage cutoff and universal backfeed blocking are not claimed. Analog3V3_ADC, external bias banks, held-supply supervision, isolation, discharge and hardware reset endpoints remain coherent. Unchanged detailed ratings/primary-source work is reused from the hash-bound prior review rather than repeated datasheet archaeology.

Visual inspection and limits

I visually inspected all19 actual current PDF pages as individually rendered1600-pixel images: power/protection1–5, each jack/channel6–13, ADC/configuration/reference14–16, and clock/TDM/reset17–19. All10 contacts on each jack, NC marks, polarity, labels and ground connections remain distinguishable. Page17 is dense but its crossing bridges and three22ohm resistors are legible; no topology-changing wire/ground-bar conflict was found. This topology corroboration does not replace the separate readability witness.

All436 frozen inputs and seven subject hashes were independently verified before and after the work. Frozen ERC reports0 errors; no fresh ERC is claimed. No live project writes, board saves, generation, child agents, commits or adoption occurred. Actual manufacturer allocation, physical mates/prototype integration, measured fault/ramp/thermal/SI behavior, native routing qualification and release/orderability remain later boundaries. Delivery PASS fields attest complete evidence delivery, not permission to order.
