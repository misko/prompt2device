import sys,json,hashlib,tarfile,shutil
from pathlib import Path
from datetime import datetime,timezone
sys.dont_write_bytecode=True
R=Path('/tmp/rj45-carrier-topology-review-mediumfinal3-tgezucm4');S=Path(__file__).parent;O=S.parent/'outputs';E=json.loads((S.parent/'envelope.json').read_text());H=json.loads((S/'hashes.json').read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
# Reopen and verify all historic member evidence before referencing it.
manifest=json.loads((R/'prior-medium-review/evidence-manifest.json').read_text());hist=[]
for row in manifest['members']:
 b=(S/'historical'/row['path']).read_bytes();assert len(b)==row['size'] and sha(b)==row['sha256'];hist.append(row)
assert len(hist)==manifest['member_count']
(S/'historical-evidence-binding.json').write_text(json.dumps({'source_archive_sha256':manifest['archive_sha256'],'verified_members':hist,'reused_scope':'Methods, unchanged authority/datasheet evidence and full inventory comparison; no inherited verdict'},indent=2))
for name in ['report.md','evidence.json','evidence-manifest.json']:shutil.copyfile(R/'prior-medium-review'/name,S/'historical'/('prior-'+name))
rows=[]
for item in E['input_packet']:
 b=(R/item['path']).read_bytes();assert len(b)==item['size'] and sha(b)==item['sha256'];rows.append(item)
(S/'inputs-after.json').write_text(json.dumps({'count':len(rows),'bad':[],'verified':rows},indent=2))
header={'review_stage':'pre-route','review_kind':'topology','reviewer_identity':'/root/carrier_rj45_native_carrier_topology_mediumfinal3','context':'FRESH','date':datetime.now(timezone.utc).isoformat(),'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER',**H}
(O/'report.md').write_text(''.join(f'{k}: {v}\n' for k,v in header.items())+'\n'+(S/'report-body.md').read_text())
counts={'inputs_before':436,'inputs_after':436,'subject_hashes':7,'components':333,'native_nodes':985,'connected_nodes':943,'no_connect_nodes':42,'physical_pins':988,'fused_aliases':3,'invariants_pass':205,'invariants_total':205,'rj45_contacts':80,'digital_groups':2,'digital_nets':13,'digital_seed_segments':110,'ordinary_authored_via_specs':215,'ordinary_via_land_center_hits':0,'protected_thermal_vias':11,'paired_via_configurations':212,'visual_pages':19}
evidence={'verdict':'SOUND','design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','subject':E['subject'],'subject_hashes':H,'canonical_envelope_sha256':sha((S.parent/'envelope.json').read_bytes()),'methods':['Inspected and reran archived JSX evaluator/native S-expression/union-find inventory methods on current inputs','Independent complete invariant evaluation','Current frozen conditional clock/TDM/power/analog validators on independently parsed native inventory','Exact route semantic comparison and reconstructed prior rules digest','Independent full anchor/repeat placement expansion and isolated native footprint via-center/land geometry','Independent paired via and reset digital-seed clearance arithmetic','Actual19-page current PDF visual inspection','Supervisor copper/paste/mask comparison and reopened archived unchanged primary drawing figures'],'counts':counts,'findings':[],'corrected_findings':['ADC_RESET_N .30/.20 at98.1,74.17:8:1 nominal aspect,0.502406mm nearest digital seed clearance;both attached endpoints corrected','ADC3P via99.5,64.9 outside capacitor land,directF.Cu leaf connected'],'limits':['Pre-route source/topology only; no final native board/routing/fab/assembly acceptance','Reused unchanged detailed primary ratings evidence is explicitly historical and hash-bound','215 authored via specifications are not a final board via census','Shared tool context is separately copied/hashed, not frozen engineering authority','0-error ERC is inherited frozen evidence','Manufacturer allocation, physical mates and measured first article remain owed']}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2))
# Archive current methods/logs/data/images plus narrowly reused historical evidence, no archive nesting.
selected=[]
keep_history={'inventory.json','changed-authority.json','ti-25.png','ti-26.png','prior-report.md','prior-evidence.json','prior-evidence-manifest.json'}
for p in S.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(S)
 if rel.parts[0]=='historical' and p.name not in keep_history:continue
 if rel.parts[0]=='prior-rule-projection':continue
 assert not p.is_symlink() and not p.name.endswith(('.tar','.tar.gz','.zip'))
 selected.append(p)
with tarfile.open(O/'evidence.tar.gz','w:gz') as t:
 for p in sorted(selected):t.add(p,arcname=p.relative_to(S).as_posix(),recursive=False)
members=[];seen=set()
with tarfile.open(O/'evidence.tar.gz','r:gz') as t:
 for m in t.getmembers():
  assert m.isfile() and m.name not in seen and not m.name.startswith('/') and '..' not in Path(m.name).parts;seen.add(m.name)
  b=t.extractfile(m).read();assert len(b)==m.size
  members.append({'path':m.name,'size':len(b),'sha256':sha(b)})
b=(O/'evidence.tar.gz').read_bytes();(O/'evidence-manifest.json').write_text(json.dumps({'archive_sha256':sha(b),'archive_size':len(b),'member_count':len(members),'members':members},indent=2))
(O/'result.json').write_text(json.dumps({'subject':E['subject'],'checks':{k:'PASS' for k in E['completion']['checks']},'unresolved':[]},indent=2))
assert {x.name for x in O.iterdir()}=={'report.md','evidence.json','evidence-manifest.json','evidence.tar.gz','result.json'}
for item in E['input_packet']:
 b=(R/item['path']).read_bytes();assert len(b)==item['size'] and sha(b)==item['sha256']
print('Five outputs packaged, archive reopened:',len(members),'members',len(b),'last input bytes;436 frozen inputs intact')
