#!/usr/bin/python3
import gzip
import hashlib
import io
import json
import os
import stat
import tarfile
from pathlib import Path, PurePosixPath

scratch = Path(__file__).resolve().parent
source = scratch / "evidence"
outputs = scratch.parent / "outputs"
archive_path = outputs / "evidence.tar.gz"
manifest_path = outputs / "evidence-manifest.json"

files = []
for path in sorted(source.rglob("*")):
    info = path.lstat()
    if stat.S_ISLNK(info.st_mode):
        raise RuntimeError(f"symlink forbidden: {path}")
    if path.is_dir():
        continue
    if not stat.S_ISREG(info.st_mode):
        raise RuntimeError(f"non-regular member forbidden: {path}")
    rel = path.relative_to(source).as_posix()
    pure = PurePosixPath(rel)
    if pure.is_absolute() or any(part in ("", ".", "..") for part in pure.parts):
        raise RuntimeError(f"unsafe member path: {rel}")
    data = path.read_bytes()
    files.append((rel, data))

if len({name for name, _ in files}) != len(files):
    raise RuntimeError("duplicate archive member")

raw_tar = io.BytesIO()
with tarfile.open(fileobj=raw_tar, mode="w", format=tarfile.PAX_FORMAT) as archive:
    for name, data in files:
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        info.uid = info.gid = 0
        info.uname = info.gname = ""
        archive.addfile(info, io.BytesIO(data))

with archive_path.open("wb") as raw:
    with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as zipped:
        zipped.write(raw_tar.getvalue())

reopened = []
seen = set()
with tarfile.open(archive_path, mode="r:gz") as archive:
    for member in archive.getmembers():
        name = member.name
        pure = PurePosixPath(name)
        if pure.is_absolute() or any(part in ("", ".", "..") for part in pure.parts):
            raise RuntimeError(f"unsafe reopened member: {name}")
        if name in seen:
            raise RuntimeError(f"duplicate reopened member: {name}")
        seen.add(name)
        if not member.isfile() or member.issym() or member.islnk():
            raise RuntimeError(f"non-regular reopened member: {name}")
        stream = archive.extractfile(member)
        if stream is None:
            raise RuntimeError(f"cannot reopen member: {name}")
        data = stream.read()
        if len(data) != member.size:
            raise RuntimeError(f"size mismatch: {name}")
        reopened.append({"path": name, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()})

archive_data = archive_path.read_bytes()
manifest = {
    "schema": 1,
    "archive_sha256": hashlib.sha256(archive_data).hexdigest(),
    "archive_size": len(archive_data),
    "member_count": len(reopened),
    "members": reopened,
}
manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
