review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 92a4e2fc0fecde845f2dfa0d9e2f5bfbd943372962fb449d699a98d957fc5633
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: 7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c

# Fresh pin review: carrier-switches

Scope is explicitly limited to U_ISO1 through U_ISO8. This is not whole-board acceptance. The mandated `DO-NOT-ORDER` metadata is retained even though this limited engineering domain is SOUND.

Primary document for every reference: Texas Instruments TMUX2821/TMUX2819, SCDS488, December 2025, SHA-256 `493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55`. The actual inspected images were PDF page 3, Figure 4-1 and its Pin Functions table; PDF page 19, Figure 7.1 block diagram and Table 7-1; PDF page 30, DSG0008A package outline 4218900/E; and PDF page 31, DSG0008A land-pattern example 4218900/E.

Independent expected derivation: the manufacturer pin figure is explicitly TOP VIEW. Pin 1 is the upper-left terminal; pins 1,2,3,4 descend the left side and pins 5,6,7,8 ascend the right side, which is CCW in the dossier's stated component-top frame (+x right, +y down). There are four pins per side and a distinct exposed thermal pad, physical identity 9. The required functions are 1 S1, 2 D1, 3 SEL2, 4 GND, 5 S2, 6 D2, 7 SEL1, 8 VDD, and thermal pad GND. Figure 7.1 and Table 7-1 show two independent bidirectional Sx-Dx channels, each controlled by SELx. The land example specifies eight distinct 0.50 x 0.25 mm lands at 0.50 mm pitch, 1.90 mm row spacing, plus a distinct 0.90 x 1.60 mm center land 9.

## U_ISO1

VERDICT: PASS

Measured native counts: 11 pad records total; 9 numbered identity-bearing pads (1-9); 9 distinct electrical/physical copper identities; 2 unnumbered paste/mechanical pads excluded from identity comparison; 0 aliases or fused identities.

Expected vs observed: front-mounted component-top geometry has pin 1 at upper-left and CCW winding, four pins per side, with center EP 9; dossier matches. Pins/functions/nets are 1 S1/FILTER1P, 2 D1/ADC1P, 3 SEL2/AUDIO_EN, 4 GND/GND, 5 S2/FILTER1N, 6 D2/ADC1N, 7 SEL1/AUDIO_EN, 8 VDD/5V_LDO_HOLD, 9 GND/GND. Bidirectional channel endpoints, common logic enable, rail supply, and both ground identities are electrically sane.

## U_ISO2

VERDICT: PASS

Measured native counts: 11 pad records total; 9 numbered identity-bearing pads (1-9); 9 distinct electrical/physical copper identities; 2 unnumbered paste/mechanical pads excluded; 0 aliases or fused identities.

Expected vs observed: the same top-view pin-1 corner, CCW winding, four-per-side count, center EP 9, and complete function order match. Nets are 1 FILTER2P, 2 ADC2P, 3 AUDIO_EN, 4 GND, 5 FILTER2N, 6 ADC2N, 7 AUDIO_EN, 8 5V_LDO_HOLD, 9 GND; their function classes are sane.

## U_ISO3

VERDICT: PASS

Measured native counts: 11 pad records total; 9 numbered identity-bearing pads (1-9); 9 distinct electrical/physical copper identities; 2 unnumbered paste/mechanical pads excluded; 0 aliases or fused identities.

Expected vs observed: the same top-view pin-1 corner, CCW winding, four-per-side count, center EP 9, and complete function order match. Nets are 1 FILTER3P, 2 ADC3P, 3 AUDIO_EN, 4 GND, 5 FILTER3N, 6 ADC3N, 7 AUDIO_EN, 8 5V_LDO_HOLD, 9 GND; their function classes are sane.

## U_ISO4

VERDICT: PASS

Measured native counts: 11 pad records total; 9 numbered identity-bearing pads (1-9); 9 distinct electrical/physical copper identities; 2 unnumbered paste/mechanical pads excluded; 0 aliases or fused identities.

Expected vs observed: the same top-view pin-1 corner, CCW winding, four-per-side count, center EP 9, and complete function order match. Nets are 1 FILTER4P, 2 ADC4P, 3 AUDIO_EN, 4 GND, 5 FILTER4N, 6 ADC4N, 7 AUDIO_EN, 8 5V_LDO_HOLD, 9 GND; their function classes are sane.

## U_ISO5

VERDICT: PASS

Measured native counts: 11 pad records total; 9 numbered identity-bearing pads (1-9); 9 distinct electrical/physical copper identities; 2 unnumbered paste/mechanical pads excluded; 0 aliases or fused identities.

Expected vs observed: this front-mounted instance is rotated 180 degrees on the board, but its de-rotated component-top table has the same pin-1 corner, CCW winding, four-per-side count, center EP 9, and complete function order. Nets are 1 FILTER5P, 2 ADC5P, 3 AUDIO_EN, 4 GND, 5 FILTER5N, 6 ADC5N, 7 AUDIO_EN, 8 5V_LDO_HOLD, 9 GND; their function classes are sane.

## U_ISO6

VERDICT: PASS

Measured native counts: 11 pad records total; 9 numbered identity-bearing pads (1-9); 9 distinct electrical/physical copper identities; 2 unnumbered paste/mechanical pads excluded; 0 aliases or fused identities.

Expected vs observed: this front-mounted instance is rotated 180 degrees on the board, but its de-rotated component-top table has the same pin-1 corner, CCW winding, four-per-side count, center EP 9, and complete function order. Nets are 1 FILTER6P, 2 ADC6P, 3 AUDIO_EN, 4 GND, 5 FILTER6N, 6 ADC6N, 7 AUDIO_EN, 8 5V_LDO_HOLD, 9 GND; their function classes are sane.

## U_ISO7

VERDICT: PASS

Measured native counts: 11 pad records total; 9 numbered identity-bearing pads (1-9); 9 distinct electrical/physical copper identities; 2 unnumbered paste/mechanical pads excluded; 0 aliases or fused identities.

Expected vs observed: this front-mounted instance is rotated 180 degrees on the board, but its de-rotated component-top table has the same pin-1 corner, CCW winding, four-per-side count, center EP 9, and complete function order. Nets are 1 FILTER7P, 2 ADC7P, 3 AUDIO_EN, 4 GND, 5 FILTER7N, 6 ADC7N, 7 AUDIO_EN, 8 5V_LDO_HOLD, 9 GND; their function classes are sane.

## U_ISO8

VERDICT: PASS

Measured native counts: 11 pad records total; 9 numbered identity-bearing pads (1-9); 9 distinct electrical/physical copper identities; 2 unnumbered paste/mechanical pads excluded; 0 aliases or fused identities.

Expected vs observed: this front-mounted instance is rotated 180 degrees on the board, but its de-rotated component-top table has the same pin-1 corner, CCW winding, four-per-side count, center EP 9, and complete function order. Nets are 1 FILTER8P, 2 ADC8P, 3 AUDIO_EN, 4 GND, 5 FILTER8N, 6 ADC8N, 7 AUDIO_EN, 8 5V_LDO_HOLD, 9 GND; their function classes are sane.

Pairwise symmetry: all eight instances preserve the same function-to-net-kind structure. Pins 1/2 are the numbered P-channel FILTER/ADC endpoints; pins 5/6 are the numbered N-channel FILTER/ADC endpoints; pins 3/7 share AUDIO_EN; pin 8 uses 5V_LDO_HOLD; pins 4/9 use GND. U_ISO5-U_ISO8 differ only by a legitimate 180-degree board rotation that disappears in the declared component-top frame.

Unresolved findings: none within commissioned group coverage.
