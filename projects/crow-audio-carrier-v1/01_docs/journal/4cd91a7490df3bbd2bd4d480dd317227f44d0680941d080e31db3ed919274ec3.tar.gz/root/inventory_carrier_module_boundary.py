from pathlib import Path
import re,json,hashlib
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
A=R/'projects/crow-audio-carrier-v1'
p=A/'03_tscircuit/src/crow_audio_carrier_v1.tsx';text=p.read_text()
c=A/'03_tscircuit/build/circuit.json';data=json.loads(c.read_text());refs={x['name'] for x in data if x.get('type')=='source_component'}
start=text.index('const AnalogChannel =');end=text.index('export default',start)
templates=re.findall(r'name=\{`([^`]+)`\}',text[start:end]);analog=[]
for n in range(1,9):
 for t in templates:
  for leg in (['P','N'] if '${leg}' in t else ['']):analog.append(t.replace('${n}',str(n)).replace('${leg}',leg))
assert len(analog)==len(set(analog)) and set(analog)<=refs
sections={}
for match in re.finditer(r'<(?:Chip|C2|R2)\s+name="([^"]+)"([\s\S]*?)(?=<(?:Chip|C2|R2)\s+name=|\Z)',text):
 ref,body=match.groups()
 if ref not in refs:continue
 m=re.search(r'(?:schSectionName|section)="([^"]+)"',body)
 if m:sections[ref]=m.group(1)
core=[r for r,s in sections.items() if s in ['ADC references and mode','Reference buffers and filters','TDM clocks and reset'] and r!='U_ADC']
external_bias=[f'{prefix}{n}{suffix}' for n in [1,2] for prefix,suffix in [('R_VMID','_TOP'),('R_VMID','_BOT'),('C_VMID','_EXT_10U'),('C_VMID','_EXT_1U')]]
buck=['D_BUCK_IN','C_BUCK_IN','C_BUCK_IN2','C_BUCK_IN3','C_BUCK_BST','L_BUCK','C_BUCK_O1','C_BUCK_O2','C_BUCK_O3']
groups={'analog_channel_support':sorted(analog),'adc_references_modes_clocks_reset_interfaces':sorted(core),'external_bias':external_bias,'buck_local_support':buck,'subsystem_ics':['U_ADC','U_BUCK']}
flat=sum(groups.values(),[]);assert len(flat)==len(set(flat)) and set(flat)<=refs
groups['shared_power_spoke_connector_infrastructure']=sorted(refs-set(flat))
assert set(sum(groups.values(),[]))==refs
out={'scope':'READ_ONLY candidate functional boundary inventory; not accepted integration policy or native/layout proof. Analog support includes full protected front end downstream of connector ESD; core includes two external TDM headers. Shared rail/power supervision dependencies remain separately enumerated and may warrant inclusion in final total-complexity study. No geometry authored or candidate spent.','inputs':[{'path':str(x),'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in [p,c]],'generated_refs':len(refs),'groups':{k:{'count':len(v),'refs':v} for k,v in groups.items()},'adc_support_count_excluding_shared_infrastructure':len(analog)+len(core)+len(external_bias),'buck_boundary':'12V_PROTECTED input to 5V_BUCK output: local isolation diode, all three input ceramics, bootstrap, inductor and all three output ceramics; upstream input/spoke protection and downstream hold/quiet-rail circuitry explicitly outside boundary'}
q=Path('/tmp/carrier-rj45-20260912/carrier-module-boundary-inventory.json');q.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v['count'] for k,v in out['groups'].items()},indent=2));print('ADC subtotal',out['adc_support_count_excluding_shared_infrastructure']);print('Remaining',groups['shared_power_spoke_connector_infrastructure'])
