from pathlib import Path
import json
N=Path('/tmp/carrier-rj45-20260912');I=Path('/tmp/carrier-connector-integration-20260911');R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
files={}
for f in I.glob('top-only-guard-*-qualification*'):
 if f.is_file():files['qualification/'+f.name]=str(f)
for slug,rid in [('crow-audio-carrier-v1','qualify-47991033847141ceb4a2b64b2a8972fb'),('crow-mic-pod-v3','qualify-b3268b4d3c2e4897930eeb8958a85e2d')]:
 q=R/'projects'/slug/'06_build/task_runs'/rid/'qualification.json';j=json.loads(q.read_text());files['qualification/'+slug+'.json']=str(q)
for name in ['inventory_carrier_module_boundary.py','carrier-module-boundary-inventory.json','rj45-top-only-source1-closeout-summary.json','prepare_top_only_reassessment_checkpoint.py']:
 files['root/'+name]=str(N/name)
spec={'name':'top-only-reassessment-preflight','project':'crow-audio-carrier-v1','scope':'Root native/repository qualification after accepted assembly-side checker: both qualification receipts and bounded raw logs; read-only complete333-ref functional module inventory with252 ADC-local/front-end supports,9 local buck supports and70 separately enumerated shared/spoke infrastructure refs. Candidate inventory is not accepted P-MOD policy or native geometry. Prior top-only author INCOMPLETE closeout pointer retains2spent native candidates,0routing pilots. No live board changes or gate bypass.','files':files}
(N/'top-only-reassessment-preflight-spec.json').write_text(json.dumps(spec,indent=2)+'\n')
print(len(files))
