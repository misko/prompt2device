from pathlib import Path
from datetime import datetime,timezone
import json,re
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
P=R/'projects/crow-audio-carrier-v1';Pod=R/'projects/crow-mic-pod-v3';Parent=R/'projects/crow-roof-array-v1'
a=json.loads((N/'source-hold-preservation.json').read_text());h=a['sha256'];now=datetime.now(timezone.utc).isoformat()
report=f'''# RJ45 source checkpoint — 2026-09-12

Status: **source INCOMPLETE; no new board or release**.

The approved direction is a nonmagnetic RJ45 port with a factory shielded
Cat6/Cat6A patch cord, carrying analog audio and 12 V. The selected draft uses
Würth 615008160221 jacks and HARTING 09484747743150 15 m Cat6A PUR cords.
The original live source and generated boards still implement Micro-Fit.
The 60-file revised source overlay is preserved as a held proposal; it has
not passed full source review or been adopted into the live design.

## Saved work

[Exact draft and evidence archive](../journal/{h}.tar.gz):
SHA-256 `{h}`, {a['size']} bytes, {a['payload_members']} regular payload
members plus `MANIFEST.json`. Root reopened every member. Original author
proposals, rejected changes, all raw failures, fresh reviewer availability,
independent reviews and corrected root proposals are retained separately.
Baseline commit: `{a['baseline_commit']}`.

Inside the archive, start with `README.md`, `ROOT_REOPEN_AUDIT.json` and
`root/draft-integration-debt.json`. The held overlay is
`root/integrated_source_candidate/`, with exact file identities in
`root/integrated-source-manifest.json`. Resume in an isolated copy of the
baseline; do not blindly copy this draft over the live source.

The draft assigns contacts 1/3/7 to +12 V, 2/6/8 to return, 5 to AUDIO+
and 4 to AUDIO−. Shell tabs 9/10 are CHASSIS on the carrier and isolated
POD_SHIELD on the pod. The three copies of the interface contract have
SHA-256 `cd0307abdfad1edf0d344299b4e09b37be0beda4bf324aa9c788a8b9934f3b4e`.
Ports require an explicit analog/power label and de-energized mating.

## Measured checkpoint

| Check | Result and limit |
|---|---|
| Native startup qualification | 4/4 PASS; tool availability only |
| Fresh reviewer delivery | Availability 3 inputs/2 outputs; review 108 inputs/5 outputs; timely FINAL and closed PASS |
| Parent protocol tests | 14/14 PASS, including 12 known-bad cases; native integration case still owed |
| Carrier protocol tests | 12/12 PASS, including retained native-parser hostiles |
| Pod protocol tests | 10/10 pure tests PASS; native integration case still owed |
| Pod route-policy tests | 10/10 PASS; policy tests do not prove routed copper |
| Rejected-proposal controls | 4/4 discriminate stale board, stale schematic, duplicate pad and duplicate JSON; all were wrongly accepted by the unadopted proposal and rejected by the preserved checker |
| Draft syntax | 14 Python and 26 YAML files parse; no schema or source-admission claim |
| Carrier connector base | INCOMPLETE, 19/42 known, 23 unknown; 3 assemblies and 11 connector instances |
| Carrier source phase | INCOMPLETE; 21 permitted physical deferrals, 3 findings for mate identity/mate/grip |
| Pod connector base | INCOMPLETE, 5/14 known, 9 unknown; 1 assembly and 1 connector instance |
| Pod source phase | INCOMPLETE; 7 permitted physical deferrals, same 3 mate/grip findings |

Both final base and source receipts were reopened through the owning validation
APIs. Valid INCOMPLETE receipts establish an honest stop, not a gate PASS.
The generic runtime prints FAIL for child exit 2; the owning receipt classifies
these results as INCOMPLETE, not malformed source.

The independent source-hold review agrees that generation must stop. It also
identified the carrier standard SOT-553 orientation difference from the pod
custom footprint. Root corrected carrier north clamps to 180° and south to 0°;
an isolated native remeasurement gives 1.935073 mm audio-contact-to-clamp spans
on both sides. The frozen reviewer did not review these later bytes. Neither
its source review nor the footprint measurement is full board acceptance.

## Exact blocker and next input

The cord catalog gives approximately 45 mm boot length and nominal 6.7 mm OD.
It does not establish a maximum mate or grip envelope. The source gate has no
permitted deferral for those facts. The SOURCE-IDENTITY finding follows from
the unknown mate-section evidence; the exact cord MPN itself is selected.

The [measurement request](../evidence/rj45-cord-measurement-request.md) names
the required drawing or controlled sample evidence. Obtain that evidence,
enter the justified dimensions and tolerances into the single connector
contract, recompile base/source receipts, and complete fresh source review.
No sample has been purchased or measured during this work.

## Implementation work after evidence arrives

Before source adoption, finish the carrier's exact B.Cu clamp prefixes and
realized branch-dominance enforcement; retain all existing length/via limits.
Prove CHASSIS copper connectivity and the panel bond independently from
signal GND, and route the pod's isolated shell island. Resolve the pod's
150 VAC jack rating versus its draft DC recommended/absolute fields; prose
alone does not establish an electrical rating. Complete active first-article
and parent decision records, then run the full source and schema checks.

After source admission, regenerate both schematics and boards through the full
conductor. Renew pin, schematic readability, model, bottom assembly, visual
and layout reviews. Complete connector physical qualification before routing.
Only then may fresh routes, DRC 0/0/0, protection/analog/current gates,
fabrication and independent release gates support a new immutable release.

LAYOUT-001 remains closed with all three attempts spent. The late schematic
review remains TIMED_OUT and unaccepted. The prior sealed pod release remains
immutable. Root is the sole live writer; no author or reviewer remains active.
'''
(P/'01_docs/research/2026-09-12-rj45-source-checkpoint.md').write_text(report)
request='''# Selected RJ45 cord — required dimensional evidence

Status: request only; no hardware measurement, supplier response or fit PASS.
Hardware: HARTING 09484747743150 factory 15 m cord, with the exact installed
0948CON47P8BK plug/boot subassembly. This is not authorization to purchase or
send a supplier inquiry.

Provide either a controlled manufacturer drawing with maximum dimensions and
tolerances, or a controlled measurement record tied to exact cord lots and
samples. A measurement record must identify the instruments, calibration,
measurement uncertainty, sample count and a justified extrema/allowance method.
Do not treat one nominal caliper reading as a production maximum.

| Fact | Required evidence |
|---|---|
| Mated datum | Define the seated mating plane and plug insertion datum |
| Complete mate | Bound length, width and height of the plug, boot, strain relief and latch from that datum |
| Latch | Bound free and depressed protrusion, release travel and moving envelope |
| Grip | Bound the actual accessible grip width/diameter and axial length; distinguish the grip object from finger access |
| Variation | State drawing tolerances or measured ranges, uncertainty and deliberate allowances |

Enter approved mate and grip facts into the owning connector contract and
regrade the source phase. The existing approximately 45 mm length and nominal
6.7 mm OD cannot supply those maxima. Do not add a new source deferral category.

Separate installed qualification remains owed: populated-neighbor latch access,
reaction support, board seating, exposure and enclosure tolerances, cable OD
extrema, straight run and 10D repeated-bend allowance using the justified OD.
Both IP20 ends must remain dry and protected from condensation. Record a dry
entry test explicitly; a drawing or an opening render does not prove it.

Electrical qualification is also separate: unpowered 1-1 through 8-8 and
shield continuity, no cross-short, correct audio polarity and power pairing,
finished hot-loop resistance no greater than 2.2 Ω, plug/contact suitability
for the commissioned load, shell isolation, and system ESD/noise testing.
'''
(P/'01_docs/evidence/rj45-cord-measurement-request.md').write_text(request)
with (P/'01_docs/journal/contracts.md').open('a') as f:
 f.write(f'\n\n## Allowed held RJ45 source checkpoint\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Exact 60-file held source overlay, original rejected proposals, completed architecture/protocol/pod/reviewer packets, raw failures, root regression and native footprint checks, and valid INCOMPLETE connector receipts; no source adoption or board/release acceptance |\n\nAudit: SHA-256 equals filename; {a["size"]} bytes and {a["payload_members"]} regular payload members plus MANIFEST.json, all reopened. Reject duplicate, link, traversal and extra entries. Every original inner archive member and all 211 frozen input bindings were reopened. The root carrier rotation and HARTING prose corrections postdate the frozen source-hold review and are not claimed as reviewed.\n')
with (P/'01_docs/journal/schematic.md').open('a') as f:
 f.write(f'''\n\n## {now} — RJ45 draft preserved at the source evidence checkpoint

- Root remains sole live writer. Architecture, protocol author, pod author,
  fresh reviewer availability and independent source-hold review all delivered
  actual FINAL and were closed PASS before their deadlines. Root reopened
  211 frozen input bindings, 22 outputs and 77 original inner archive members.
  Delivery PASS is not engineering acceptance. No worker remains active.
- Integrated 60-file source proposal is held in archive {h}
  ({a['size']} bytes, {a['payload_members']} payload members plus MANIFEST), all
  reopened. Baseline {a['baseline_commit']}; live engineering source and
  generated artifacts are unchanged. See research/2026-09-12-rj45-source-checkpoint.md
  for exact extraction paths, measurements, limitations and the next work order.
- Parent 14/14, carrier 12/12, pod protocol 10/10 pure and pod route-policy
  10/10 tests PASS. Native integration cases remain unchanged and owed.
  Four RED/GREEN controls show the rejected protocol proposal accepted stale
  board/schematic bindings and duplicate pad/JSON records; root preserves the
  original guards. Original bad proposals, their reports and raw failures are
  retained. No new waiver or gate relaxation was introduced.
- The pod proposal also used an invalid deferral class and unmeasured service
  grades. Root corrected them to permitted physical deferrals and unknowns.
  Carrier standard SOT-553 differs by 180 degrees from the pod custom part;
  root corrected north/south clamp rotations after the frozen review and
  measured 1.935073 mm spans on both isolated native transforms. This does not
  prove full-board clearance, copper, assembly or independent delta acceptance.
- Final carrier base INCOMPLETE: 19/42 known, 23 unknown, 3 assemblies/11 refs;
  source admits 21 physical deferrals but blocks mate identity/mate/grip with
  3 findings. Pod base 5/14 known, 9 unknown, 1 assembly/1 ref; source admits
  7 physical deferrals and has the same 3 findings. Owning APIs reopen all four
  receipts as valid INCOMPLETE. Runtime FAIL labels reflect child exit 2.
- Independent source-hold review confirms the source stop. A controlled exact
  cord/boot maximum drawing or controlled sample measurements with uncertainty
  and extrema rationale must establish mate/grip envelopes. Approximate 45 mm
  and nominal 6.7 mm are not maxima. Measurement request is saved under
  evidence/rj45-cord-measurement-request.md. No purchase or physical measurement.
- Next resolve those source facts and draft debts, then fresh full source
  review and synchronized normal regeneration. Native schematic/placement,
  physical connector qualification, routing, DRC 0/0/0, analog/current,
  fabrication and release gates all remain owed. LAYOUT-001 stays closed with
  three attempts spent; late schematic review remains TIMED_OUT/unaccepted.
  No new release; DO-NOT-ORDER.
''')
status=f'''# STATUS beacon — crow audio carrier v1

stage: sourcing
step: RJ45 source gate paused for exact mate and grip envelope evidence
measure: Held 60-file draft; 46 focused tests PASS; carrier source INCOMPLETE with 3 findings; native board remains old Micro-Fit.
state: blocked
next: Obtain controlled cord/boot maximum dimensions or qualified sample measurements; follow research/2026-09-12-rj45-source-checkpoint.md. Complete draft debts and fresh source review before any generation. Root sole writer; no active agents. No new release or order authority.
op_pid:
updated: {now}
'''
(P/'01_docs/STATUS.md').write_text(status)
s=(Pod/'01_docs/STATUS.md').read_text();tail=s[s.index('## Prior sealed design release'):]
(Pod/'01_docs/STATUS.md').write_text(f'''# STATUS beacon — crow microphone pod v3

stage: sourcing
step: Held RJ45 successor draft; source INCOMPLETE on mate and grip
measure: Pod source 3 findings; 10 protocol and 10 route-policy tests PASS. Current generated board and prior release remain Micro-Fit.
state: blocked
next: Follow carrier research/2026-09-12-rj45-source-checkpoint.md and its measurement request; complete source review before regeneration. Root sole writer; no active agents. DO-NOT-ORDER.
op_pid:
updated: {now}

'''+tail)
(Parent/'01_docs/STATUS.md').write_text(f'''# STATUS beacon — crow roof array v1

stage: sourcing
step: User-approved RJ45 and factory Cat6A successor held at source evidence gate
measure: Three draft contracts match; parent pure tests 14/14 PASS. Both boards have 3 source findings for mate/grip evidence. No new board or release.
state: blocked
next: Resume from ../crow-audio-carrier-v1/01_docs/research/2026-09-12-rj45-source-checkpoint.md. Obtain exact cord/boot dimensions, finish held source draft and independent review, then regenerate both boards through all release gates. Root sole writer; no active agents.
op_pid:
updated: {now}
''')
for project,id_ in [(P,'CAR-RJ45-interface-revision'),(Pod,'POD-RJ45-interface-revision')]:
 p=project/'01_docs/findings.yaml';s=p.read_text();start=s.index('id: '+id_);end=s.find('\n- id:',start) if project==P else s.find('\n  - id:',start);end=len(s) if end<0 else end
 chunk=s[start:end];addition=' Held source draft is archived at '+h+'. Source phase is INCOMPLETE with non-deferrable mate/grip envelope evidence; no new native generation is admitted.'
 chunk=re.sub(r'(    finding:|  finding:)([^\n]*)',lambda m:m[1]+m[2]+addition,chunk,count=1)
 s=s[:start]+chunk+s[end:];p.write_text(s)
print('Recorded source checkpoint, measurement request, archive admission and all three current status beacons')
