from pathlib import Path
import hashlib,json,tarfile,gzip,io
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911');J=R/'projects/crow-audio-carrier-v1/01_docs/journal'
files={}
for p in [N/'source-hold-preservation.json',N/'record_source_checkpoint.py',Path(__file__),R/'projects/crow-audio-carrier-v1/06_build/agent_handoff.yaml']:
 assert not p.is_symlink();files[p.name]=p.read_bytes()
for prefix in ['rj45-source-hold-preservation','rj45-source-checkpoint-record','rj45-held-source-contracts-audit','rj45-held-source-handoff']:
 for p in I.glob(prefix+'*'):
  if p.is_file():files['runtime/'+p.name]=p.read_bytes()
manifest={'files':[{'path':n,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(files.items())]}
buf=io.BytesIO()
with gzip.GzipFile(fileobj=buf,mode='wb',mtime=0) as gz:
 with tarfile.open(fileobj=gz,mode='w') as t:
  for n,b in sorted({**files,'MANIFEST.json':(json.dumps(manifest,indent=2)+'\n').encode()}.items()):
   i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
b=buf.getvalue()
with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as t:
 assert set(t.getnames())==set(files)|{'MANIFEST.json'}
 assert len(t.getnames())==len(files)+1 and all(m.isfile() for m in t.getmembers())
 for rec in manifest['files']:
  raw=t.extractfile(rec['path']).read();assert len(raw)==rec['size'] and hashlib.sha256(raw).hexdigest()==rec['sha256']
h=hashlib.sha256(b).hexdigest();p=J/(h+'.tar.gz');assert not p.exists();p.write_bytes(b)
with (J/'contracts.md').open('a') as f:
 f.write(f'\n## Allowed RJ45 source checkpoint closeout\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Exact source archive reopen summary, handoff and validation, checkpoint producer and full repository audit logs; {len(b)} bytes, {len(files)} regular payload members plus MANIFEST.json, all reopened; no source or release admission |\n')
with (J/'schematic.md').open('a') as f:
 f.write(f'\n- Checkpoint closeout: canonical sourcing handoff is 9178 bytes and validates. Repository --present audit grades 17534 files; all 2873 existing violations in 26 units remain within the unchanged recorded debt ceiling, with zero strays. All non-RJ45 finding/gate states are semantically unchanged. Archive `{h}` preserves those raw records ({len(b)} bytes, {len(files)} payload members plus MANIFEST), all reopened.\n')
(N/'checkpoint-closeout.json').write_text(json.dumps({'sha256':h,'size':len(b),'payload_members':len(files)},indent=2)+'\n');print(h,len(b),len(files))
