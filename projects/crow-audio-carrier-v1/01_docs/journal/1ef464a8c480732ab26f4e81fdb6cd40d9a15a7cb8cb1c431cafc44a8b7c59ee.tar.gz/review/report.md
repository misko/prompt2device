review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent /root/rj45_pin_carrier_switches_mountedframe1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

SOUND applies only to U_ISO1–U_ISO8 pin-review scope. All eight commissioned references PASS. No whole-board acceptance; pre-route order verdict remains DO-NOT-ORDER. The three flat hashes above are immutable subject bindings, not independently reviewed whole-board conclusions.

Primary evidence: Texas Instruments TMUX2821/TMUX2819 SCDS488, December 2025, frozen PDF SHA256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55. Inspected actual rendered images: PDF p3 Fig4-1/top view and pin-function table; PDF p30 DSG0008A outline; PDF p31 land-pattern example (drawing4218900/E,08/2022); PDF p19 functional diagram and Table7-1. PDF p5 operating table and p26 exact orderable suffix checked in extracted primary text.

Independent derivation preceded dossier comparison. Figure4-1 has pin1 upper left, pins1–4 down the west side, pins5–8 up the east side: CCW top view. The metal underside drawing on p30 has pin1 lower left and is a bottom physical view; explicit y reflection converts that drawing to top view, consistent with Fig4-1 and p31. This manufacturer drawing conversion is distinct from mounting conversion. All eight parts mount front; no dossier reflection is needed. Four top-row instances rotate0°, four lower-row instances rotate180°. Perimeter pads match the p31 example: x=±0.95mm, y=−0.75,−0.25,+0.25,+0.75mm, size0.5×0.25mm; central EP9 size0.9×1.6mm. Expected nine electrical identities are preserved without fused aliases. Native coordinate reconstruction agrees within1e-6mm for every numbered row. Independently computed polygon area is−2.85mm² in the +y-down frame, confirming CCW.

The p3 function table identifies1=S1,2=D1,3=SEL2,4=GND,5=S2,6=D2,7=SEL1,8=VDD,9=thermal-pad GND. TMUX2821 has no NC; the neighboring TMUX2819 NC is not applicable. Table7-1 establishes active-high switch controls. Net labels support function-to-net-kind sanity; this pin review does not measure signal amplitude, rail tolerance, enable waveform, decoupling or loaded performance.

U_ISO1 VERDICT: PASS
Measured native numbered pad rows=9; distinct pad IDs=9; physical identities=9 (8 perimeter+EP9). Dossier separately reports2 unnumbered paste/mechanical pads, yielding11 reported native pads; those two unnumbered geometries are not supplied or claimed individually measured. Fused/collapsed identities=0. Front mount, rotation=0°, component-top pin1 northwest, CCW, four pads west/four east/one center: expected and observed agree. Primary SHA256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p3 Fig4-1, p30 package underside, p31 land pattern; p19 Table7-1 for controls.
U_ISO1 pin 1 (S1): expected bidirectional analog signal; observed FILTER1P; PASS.
U_ISO1 pin 2 (D1): expected bidirectional analog signal; observed ADC1P; PASS.
U_ISO1 pin 3 (SEL2): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO1 pin 4 (GND): expected ground reference; observed GND; PASS.
U_ISO1 pin 5 (S2): expected bidirectional analog signal; observed FILTER1N; PASS.
U_ISO1 pin 6 (D2): expected bidirectional analog signal; observed ADC1N; PASS.
U_ISO1 pin 7 (SEL1): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO1 pin 8 (VDD): expected positive supply rail (1.8–5.5V operating); observed 5V_LDO_HOLD; PASS.
U_ISO1 pin 9 (GND): expected ground reference; observed GND; PASS.

U_ISO2 VERDICT: PASS
Measured native numbered pad rows=9; distinct pad IDs=9; physical identities=9 (8 perimeter+EP9). Dossier separately reports2 unnumbered paste/mechanical pads, yielding11 reported native pads; those two unnumbered geometries are not supplied or claimed individually measured. Fused/collapsed identities=0. Front mount, rotation=0°, component-top pin1 northwest, CCW, four pads west/four east/one center: expected and observed agree. Primary SHA256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p3 Fig4-1, p30 package underside, p31 land pattern; p19 Table7-1 for controls.
U_ISO2 pin 1 (S1): expected bidirectional analog signal; observed FILTER2P; PASS.
U_ISO2 pin 2 (D1): expected bidirectional analog signal; observed ADC2P; PASS.
U_ISO2 pin 3 (SEL2): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO2 pin 4 (GND): expected ground reference; observed GND; PASS.
U_ISO2 pin 5 (S2): expected bidirectional analog signal; observed FILTER2N; PASS.
U_ISO2 pin 6 (D2): expected bidirectional analog signal; observed ADC2N; PASS.
U_ISO2 pin 7 (SEL1): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO2 pin 8 (VDD): expected positive supply rail (1.8–5.5V operating); observed 5V_LDO_HOLD; PASS.
U_ISO2 pin 9 (GND): expected ground reference; observed GND; PASS.

U_ISO3 VERDICT: PASS
Measured native numbered pad rows=9; distinct pad IDs=9; physical identities=9 (8 perimeter+EP9). Dossier separately reports2 unnumbered paste/mechanical pads, yielding11 reported native pads; those two unnumbered geometries are not supplied or claimed individually measured. Fused/collapsed identities=0. Front mount, rotation=0°, component-top pin1 northwest, CCW, four pads west/four east/one center: expected and observed agree. Primary SHA256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p3 Fig4-1, p30 package underside, p31 land pattern; p19 Table7-1 for controls.
U_ISO3 pin 1 (S1): expected bidirectional analog signal; observed FILTER3P; PASS.
U_ISO3 pin 2 (D1): expected bidirectional analog signal; observed ADC3P; PASS.
U_ISO3 pin 3 (SEL2): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO3 pin 4 (GND): expected ground reference; observed GND; PASS.
U_ISO3 pin 5 (S2): expected bidirectional analog signal; observed FILTER3N; PASS.
U_ISO3 pin 6 (D2): expected bidirectional analog signal; observed ADC3N; PASS.
U_ISO3 pin 7 (SEL1): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO3 pin 8 (VDD): expected positive supply rail (1.8–5.5V operating); observed 5V_LDO_HOLD; PASS.
U_ISO3 pin 9 (GND): expected ground reference; observed GND; PASS.

U_ISO4 VERDICT: PASS
Measured native numbered pad rows=9; distinct pad IDs=9; physical identities=9 (8 perimeter+EP9). Dossier separately reports2 unnumbered paste/mechanical pads, yielding11 reported native pads; those two unnumbered geometries are not supplied or claimed individually measured. Fused/collapsed identities=0. Front mount, rotation=0°, component-top pin1 northwest, CCW, four pads west/four east/one center: expected and observed agree. Primary SHA256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p3 Fig4-1, p30 package underside, p31 land pattern; p19 Table7-1 for controls.
U_ISO4 pin 1 (S1): expected bidirectional analog signal; observed FILTER4P; PASS.
U_ISO4 pin 2 (D1): expected bidirectional analog signal; observed ADC4P; PASS.
U_ISO4 pin 3 (SEL2): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO4 pin 4 (GND): expected ground reference; observed GND; PASS.
U_ISO4 pin 5 (S2): expected bidirectional analog signal; observed FILTER4N; PASS.
U_ISO4 pin 6 (D2): expected bidirectional analog signal; observed ADC4N; PASS.
U_ISO4 pin 7 (SEL1): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO4 pin 8 (VDD): expected positive supply rail (1.8–5.5V operating); observed 5V_LDO_HOLD; PASS.
U_ISO4 pin 9 (GND): expected ground reference; observed GND; PASS.

U_ISO5 VERDICT: PASS
Measured native numbered pad rows=9; distinct pad IDs=9; physical identities=9 (8 perimeter+EP9). Dossier separately reports2 unnumbered paste/mechanical pads, yielding11 reported native pads; those two unnumbered geometries are not supplied or claimed individually measured. Fused/collapsed identities=0. Front mount, rotation=180°, component-top pin1 northwest, CCW, four pads west/four east/one center: expected and observed agree. Primary SHA256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p3 Fig4-1, p30 package underside, p31 land pattern; p19 Table7-1 for controls.
U_ISO5 pin 1 (S1): expected bidirectional analog signal; observed FILTER5P; PASS.
U_ISO5 pin 2 (D1): expected bidirectional analog signal; observed ADC5P; PASS.
U_ISO5 pin 3 (SEL2): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO5 pin 4 (GND): expected ground reference; observed GND; PASS.
U_ISO5 pin 5 (S2): expected bidirectional analog signal; observed FILTER5N; PASS.
U_ISO5 pin 6 (D2): expected bidirectional analog signal; observed ADC5N; PASS.
U_ISO5 pin 7 (SEL1): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO5 pin 8 (VDD): expected positive supply rail (1.8–5.5V operating); observed 5V_LDO_HOLD; PASS.
U_ISO5 pin 9 (GND): expected ground reference; observed GND; PASS.

U_ISO6 VERDICT: PASS
Measured native numbered pad rows=9; distinct pad IDs=9; physical identities=9 (8 perimeter+EP9). Dossier separately reports2 unnumbered paste/mechanical pads, yielding11 reported native pads; those two unnumbered geometries are not supplied or claimed individually measured. Fused/collapsed identities=0. Front mount, rotation=180°, component-top pin1 northwest, CCW, four pads west/four east/one center: expected and observed agree. Primary SHA256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p3 Fig4-1, p30 package underside, p31 land pattern; p19 Table7-1 for controls.
U_ISO6 pin 1 (S1): expected bidirectional analog signal; observed FILTER6P; PASS.
U_ISO6 pin 2 (D1): expected bidirectional analog signal; observed ADC6P; PASS.
U_ISO6 pin 3 (SEL2): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO6 pin 4 (GND): expected ground reference; observed GND; PASS.
U_ISO6 pin 5 (S2): expected bidirectional analog signal; observed FILTER6N; PASS.
U_ISO6 pin 6 (D2): expected bidirectional analog signal; observed ADC6N; PASS.
U_ISO6 pin 7 (SEL1): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO6 pin 8 (VDD): expected positive supply rail (1.8–5.5V operating); observed 5V_LDO_HOLD; PASS.
U_ISO6 pin 9 (GND): expected ground reference; observed GND; PASS.

U_ISO7 VERDICT: PASS
Measured native numbered pad rows=9; distinct pad IDs=9; physical identities=9 (8 perimeter+EP9). Dossier separately reports2 unnumbered paste/mechanical pads, yielding11 reported native pads; those two unnumbered geometries are not supplied or claimed individually measured. Fused/collapsed identities=0. Front mount, rotation=180°, component-top pin1 northwest, CCW, four pads west/four east/one center: expected and observed agree. Primary SHA256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p3 Fig4-1, p30 package underside, p31 land pattern; p19 Table7-1 for controls.
U_ISO7 pin 1 (S1): expected bidirectional analog signal; observed FILTER7P; PASS.
U_ISO7 pin 2 (D1): expected bidirectional analog signal; observed ADC7P; PASS.
U_ISO7 pin 3 (SEL2): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO7 pin 4 (GND): expected ground reference; observed GND; PASS.
U_ISO7 pin 5 (S2): expected bidirectional analog signal; observed FILTER7N; PASS.
U_ISO7 pin 6 (D2): expected bidirectional analog signal; observed ADC7N; PASS.
U_ISO7 pin 7 (SEL1): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO7 pin 8 (VDD): expected positive supply rail (1.8–5.5V operating); observed 5V_LDO_HOLD; PASS.
U_ISO7 pin 9 (GND): expected ground reference; observed GND; PASS.

U_ISO8 VERDICT: PASS
Measured native numbered pad rows=9; distinct pad IDs=9; physical identities=9 (8 perimeter+EP9). Dossier separately reports2 unnumbered paste/mechanical pads, yielding11 reported native pads; those two unnumbered geometries are not supplied or claimed individually measured. Fused/collapsed identities=0. Front mount, rotation=180°, component-top pin1 northwest, CCW, four pads west/four east/one center: expected and observed agree. Primary SHA256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p3 Fig4-1, p30 package underside, p31 land pattern; p19 Table7-1 for controls.
U_ISO8 pin 1 (S1): expected bidirectional analog signal; observed FILTER8P; PASS.
U_ISO8 pin 2 (D1): expected bidirectional analog signal; observed ADC8P; PASS.
U_ISO8 pin 3 (SEL2): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO8 pin 4 (GND): expected ground reference; observed GND; PASS.
U_ISO8 pin 5 (S2): expected bidirectional analog signal; observed FILTER8N; PASS.
U_ISO8 pin 6 (D2): expected bidirectional analog signal; observed ADC8N; PASS.
U_ISO8 pin 7 (SEL1): expected active-high logic control; observed AUDIO_EN; PASS.
U_ISO8 pin 8 (VDD): expected positive supply rail (1.8–5.5V operating); observed 5V_LDO_HOLD; PASS.
U_ISO8 pin 9 (GND): expected ground reference; observed GND; PASS.

Instance symmetry: U_ISO1–U_ISO8 pin1=FILTERnP,2=ADCnP,5=FILTERnN,6=ADCnN;3 and7=AUDIO_EN;4 and9=GND;8=5V_LDO_HOLD. Each channel retains its own index and P/N pole. No structural divergence across the eight instances.

Unresolved findings: none within commissioned pin-review scope.

Methods: Verified every envelope input SHA256 and size before and after engineering, retained raw verify-before/after logs. Rendered exact primary PDF with pdftoppm under pipeline_runtime.run_stage; inspected pin-03.png, package-30.png, package-31.png, functional-19.png with view_image. Recorded independent-figure-derivation.md before reading dossiers; derived package, pin1, winding, exposed-pad identity and functions from primary figure images. Measured all 72 numbered native pad rows in supplied dossiers with measure.py; compared each to figure-derived expected geometry and functions and native coordinate rotation. Inspected every instance signal/control/power/ground mapping and normalized channel-number symmetry. No live design files, schematic, historical reviews or external sources used. Supplied dossier verification-note assertions were not used as engineering evidence.

Evidence archive retains inspected PNGs, original native dossier copies, independent derivation, measured rows, finite execution methods and raw stdout/stderr/runtime records. Exact primary PDF remains digest-bound in the frozen input packet.
