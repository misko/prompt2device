from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,io
root=Path('/tmp/rj45-pin-carrier-logic-mountedframe1-shk9d8ue'); run=root/'06_build/task_runs/rj45-pin-carrier-logic-mountedframe1'
scratch=run/'scratch';out=run/'outputs'; files={}
for p in scratch.rglob('*'):
 if p.is_symlink(): raise ValueError('symlink '+str(p))
 if p.is_file() and not p.name.startswith('package-final.') and not p.name.startswith('preflight-final.'):
  files['methods-and-raw/'+p.relative_to(scratch).as_posix()]=p.read_bytes()
for p in (root/'dossiers').glob('*.md'):files['native-dossiers/'+p.name]=p.read_bytes()
for p in [root/'TASK.md',root/'pin-review-protocol.md',root/'preflight.py',run/'envelope.json',out/'report.md',out/'evidence.json']:
 files['review/'+p.name]=p.read_bytes()
assert all(not n.endswith(('.tar','.gz','.zip')) for n in files)
arc=out/'evidence.tar.gz'
with tarfile.open(arc,'w:gz') as t:
 for name,b in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b))
members=[];seen=set()
with tarfile.open(arc,'r:gz') as t:
 for m in t.getmembers():
  assert m.isfile() and not m.issym() and not m.islnk()
  p=PurePosixPath(m.name);assert not p.is_absolute() and '..' not in p.parts and m.name not in seen
  seen.add(m.name);b=t.extractfile(m).read();assert b==files[m.name] and len(b)==m.size
  members.append({'path':m.name,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
assert set(files)==seen
b=arc.read_bytes(); manifest={'archive_sha256':hashlib.sha256(b).hexdigest(),'archive_size':len(b),'member_count':len(members),'members':members}
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='members'}))
