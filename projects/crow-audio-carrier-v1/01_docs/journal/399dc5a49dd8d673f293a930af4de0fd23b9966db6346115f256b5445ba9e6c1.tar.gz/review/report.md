review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent /root/rj45_pin_carrier_logic_mountedframe1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

Subject (immutable envelope metadata):
{"raw_sha256": "5035a4d897f169e70096073dfe221a95a45b494846553f7ca37e4bc23044e9b2", "semantic_sha256": "f2ce897f9a1f65c14eaa0443a94b89f74134c0cb364ab000bf5a330284f5670f"}

Only U_DUMP,U_LDO_EN,U_OE,U_TDM,U_TDM_SCH. No whole-board acceptance. Pin/package review does not certify timing, drive strength, power-state system behavior, placement or routing.

All five commissioned references PASS. No unresolved pin findings. Total measured native pads:25; physical identities:25; EP:0; alias collapses:0. The three SHA fields above are immutable subject bindings, not reviewed whole-board conclusions.

## Independent method

- Fresh independent agent /root/rj45_pin_carrier_logic_mountedframe1. Only frozen protocol, native dossiers and exact envelope-selected primary PDFs used for engineering judgment. No live project, schematic, history, or children inspected. Embedded dossier verification notes were not used as authority.
- Verified all 11 input size and SHA256 bindings before review and again after engineering. Exact envelope subject is metadata, not a whole-board reviewed conclusion.
- Rendered PDF figures with pdftoppm and opened actual PNGs with view_image before reading native pad dossiers. Datasheet-first derivation retained in independent-expectations.md. Text extraction supplemented electrical tables; it was not used to establish winding.
- Viewed Nexperia 14/17 pages2,3,11 and TI125 pages3,26. Pinout coordinate convention is component top +x right/+y down. Nexperia mechanical top plans use a 90-degree rotation from the pin diagrams; no bottom-view mirror is needed. TI DBV drawing explicitly TOP VIEW; other-package bottom views excluded.
- Recomputed native row count, unique pin numbers, side counts, shoelace winding, and native-coordinate residuals from the dossiers using measure.py. Five separate manufacturer lead identities match five individual dossier pads per instance; no alias declarations or fused lands are required.
- Checked every pin function/net class, 1.65..5.5 V supply compatibility (Nexperia page5 Table6; TI page5 section5.3), inverter versus buffer behavior (Nexperia page4 Table4), and active-low enable (TI page11 Table7-1).
- Checked pairwise symmetry among all three 74LVC1G14 instances and same-package 74LVC1G17. Checked observed shared nets U_DUMP.Y -> U_LDO_EN.A, U_OE.Y -> U_TDM./OE, and U_TDM_SCH.Y -> U_TDM.A.
- Finite direct-argv subprocesses executed under shared pipeline_runtime.run_stage with explicit cwd/environment; raw merged stdout/stderr and runtime receipts retained. One failed /usr/bin/rg launch is retained; successful Python-only package locator replaced that unavailable executable, without replacement of review agent.
- Evidence archive reopens every regular member and verifies path, size and SHA256; no symlinks, traversal, duplicate paths or nested archives. Final delivery preflight is run against the exact envelope.

## U_DUMP

VERDICT: PASS
Part: 74LVC1G14GV,125. Native pad count:5; physical identity count:5; unique pin numbers:5; EP count:0; aliased identities:0.
Primary: projects/crow-audio-carrier-v1/02_parts/74LVC1G14GV,125/74LVC1G14_Rev19.pdf
SHA256: b8f37c700d0fc8374de6d14f0e2caf310c34b480ffab9d63c69bb3b6defbebbf
PDF page 3, GV package SOT753, drawing aaa-035749, and Table 3; PDF page 11, Fig. 13 SOT753.

Expected five distinct leads, no EP, no fused aliases; observed five native pads numbered 1..5, five distinct physical identities, zero EP and zero alias collapses. Expected CCW top-view winding with pin1 upper-left, pins1/2/3 west and 4/5 east; observed precisely that geometry. All instances are front-mounted F.Cu at 0 degrees. Manufacturer pinout and component-top dossier agree at zero rotation, with no mirror. Native coordinates minus board position reproduce local coordinates within floating-point roundoff (<2e-14 mm). Row pitch is 0.95 mm and end span is 1.9 mm, matching mechanical drawings.

U_DUMP pin 1 (NC): expected NC with no functional net vs observed NC on unconnected-(U_DUMP-NC-Pad1) (native isolated unconnected marker); PASS.
U_DUMP pin 2 (A): expected A logic input on a signal net vs observed A on DUMP_RC; PASS.
U_DUMP pin 3 (GND): expected GND on ground vs observed GND on GND; PASS.
U_DUMP pin 4 (Y): expected Y buffer/logic output on a signal net vs observed Y on DUMP_GATE; PASS.
U_DUMP pin 5 (VCC): expected VCC power supply within 1.65..5.5 V vs observed VCC on 5V_LDO_HOLD (nominal 5 V rail); PASS.

## U_LDO_EN

VERDICT: PASS
Part: 74LVC1G14GV,125. Native pad count:5; physical identity count:5; unique pin numbers:5; EP count:0; aliased identities:0.
Primary: projects/crow-audio-carrier-v1/02_parts/74LVC1G14GV,125/74LVC1G14_Rev19.pdf
SHA256: b8f37c700d0fc8374de6d14f0e2caf310c34b480ffab9d63c69bb3b6defbebbf
PDF page 3, GV package SOT753, drawing aaa-035749, and Table 3; PDF page 11, Fig. 13 SOT753.

Expected five distinct leads, no EP, no fused aliases; observed five native pads numbered 1..5, five distinct physical identities, zero EP and zero alias collapses. Expected CCW top-view winding with pin1 upper-left, pins1/2/3 west and 4/5 east; observed precisely that geometry. All instances are front-mounted F.Cu at 0 degrees. Manufacturer pinout and component-top dossier agree at zero rotation, with no mirror. Native coordinates minus board position reproduce local coordinates within floating-point roundoff (<2e-14 mm). Row pitch is 0.95 mm and end span is 1.9 mm, matching mechanical drawings.

U_LDO_EN pin 1 (NC): expected NC with no functional net vs observed NC on unconnected-(U_LDO_EN-NC-Pad1) (native isolated unconnected marker); PASS.
U_LDO_EN pin 2 (A): expected A logic input on a signal net vs observed A on DUMP_GATE; PASS.
U_LDO_EN pin 3 (GND): expected GND on ground vs observed GND on GND; PASS.
U_LDO_EN pin 4 (Y): expected Y buffer/logic output on a signal net vs observed Y on LDO_EN; PASS.
U_LDO_EN pin 5 (VCC): expected VCC power supply within 1.65..5.5 V vs observed VCC on 5V_LDO_HOLD (nominal 5 V rail); PASS.

## U_OE

VERDICT: PASS
Part: 74LVC1G14GV,125. Native pad count:5; physical identity count:5; unique pin numbers:5; EP count:0; aliased identities:0.
Primary: projects/crow-audio-carrier-v1/02_parts/74LVC1G14GV,125/74LVC1G14_Rev19.pdf
SHA256: b8f37c700d0fc8374de6d14f0e2caf310c34b480ffab9d63c69bb3b6defbebbf
PDF page 3, GV package SOT753, drawing aaa-035749, and Table 3; PDF page 11, Fig. 13 SOT753.

Expected five distinct leads, no EP, no fused aliases; observed five native pads numbered 1..5, five distinct physical identities, zero EP and zero alias collapses. Expected CCW top-view winding with pin1 upper-left, pins1/2/3 west and 4/5 east; observed precisely that geometry. All instances are front-mounted F.Cu at 0 degrees. Manufacturer pinout and component-top dossier agree at zero rotation, with no mirror. Native coordinates minus board position reproduce local coordinates within floating-point roundoff (<2e-14 mm). Row pitch is 0.95 mm and end span is 1.9 mm, matching mechanical drawings.

U_OE pin 1 (NC): expected NC with no functional net vs observed NC on unconnected-(U_OE-NC-Pad1) (native isolated unconnected marker); PASS.
U_OE pin 2 (A): expected A logic input on a signal net vs observed A on TDM_SENSE_G; PASS.
U_OE pin 3 (GND): expected GND on ground vs observed GND on GND; PASS.
U_OE pin 4 (Y): expected Y buffer/logic output on a signal net vs observed Y on TDM_OE_N; PASS.
U_OE pin 5 (VCC): expected VCC power supply within 1.65..5.5 V vs observed VCC on 3V3_ADC (nominal 3.3 V rail); PASS.

## U_TDM

VERDICT: PASS
Part: SN74LVC1G125DBVR. Native pad count:5; physical identity count:5; unique pin numbers:5; EP count:0; aliased identities:0.
Primary: projects/crow-audio-carrier-v1/02_parts/SN74LVC1G125DBVR/SN74LVC1G125_SCES223U.pdf
SHA256: 65afa3f9d879b37cb8be507caf84804b24bceeb2e0782ba449fff72160994e4c
PDF page 3, DBV PACKAGE (TOP VIEW), section 4; PDF page 26, DBV0005A / 4214839/K.

Expected five distinct leads, no EP, no fused aliases; observed five native pads numbered 1..5, five distinct physical identities, zero EP and zero alias collapses. Expected CCW top-view winding with pin1 upper-left, pins1/2/3 west and 4/5 east; observed precisely that geometry. All instances are front-mounted F.Cu at 0 degrees. Manufacturer pinout and component-top dossier agree at zero rotation, with no mirror. Native coordinates minus board position reproduce local coordinates within floating-point roundoff (<2e-14 mm). Row pitch is 0.95 mm and end span is 1.9 mm, matching mechanical drawings.

U_TDM pin 1 (OE_N): expected active-low output-enable input on an enable/control net vs observed OE_N on TDM_OE_N; PASS.
U_TDM pin 2 (A): expected A logic input on a signal net vs observed A on TDM_CLEAN; PASS.
U_TDM pin 3 (GND): expected GND on ground vs observed GND on GND; PASS.
U_TDM pin 4 (Y): expected Y buffer/logic output on a signal net vs observed Y on TDM_BUFFERED; PASS.
U_TDM pin 5 (VCC): expected VCC power supply within 1.65..5.5 V vs observed VCC on 3V3_ADC (nominal 3.3 V rail); PASS.

## U_TDM_SCH

VERDICT: PASS
Part: 74LVC1G17GV,125. Native pad count:5; physical identity count:5; unique pin numbers:5; EP count:0; aliased identities:0.
Primary: projects/crow-audio-carrier-v1/02_parts/74LVC1G17GV,125/74LVC1G17.pdf
SHA256: 3db133d57486306950ba1140ac13a8a0ea95509dcefb88db36c08423a819b163
PDF page 3, GV package SOT753, drawing aaa-035749, and Table 3; PDF page 11, Fig. 11 SOT753.

Expected five distinct leads, no EP, no fused aliases; observed five native pads numbered 1..5, five distinct physical identities, zero EP and zero alias collapses. Expected CCW top-view winding with pin1 upper-left, pins1/2/3 west and 4/5 east; observed precisely that geometry. All instances are front-mounted F.Cu at 0 degrees. Manufacturer pinout and component-top dossier agree at zero rotation, with no mirror. Native coordinates minus board position reproduce local coordinates within floating-point roundoff (<2e-14 mm). Row pitch is 0.95 mm and end span is 1.9 mm, matching mechanical drawings.

U_TDM_SCH pin 1 (NC): expected NC with no functional net vs observed NC on unconnected-(U_TDM_SCH-NC-Pad1) (native isolated unconnected marker); PASS.
U_TDM_SCH pin 2 (A): expected A logic input on a signal net vs observed A on TDM_RAW; PASS.
U_TDM_SCH pin 3 (GND): expected GND on ground vs observed GND on GND; PASS.
U_TDM_SCH pin 4 (Y): expected Y buffer/logic output on a signal net vs observed Y on TDM_CLEAN; PASS.
U_TDM_SCH pin 5 (VCC): expected VCC power supply within 1.65..5.5 V vs observed VCC on 3V3_ADC (nominal 3.3 V rail); PASS.

## Instance symmetry

VERDICT: PASS
U_DUMP, U_LDO_EN and U_OE all preserve NC/A/GND/Y/VCC identities. Their 5V_LDO_HOLD versus 3V3_ADC supplies are both valid rail classes and within recommended operating supply range. U_TDM_SCH uses identical package/pin geometry but non-inverting logic. The shared-net dossier evidence connects DUMP_GATE from inverter Y to inverter A, TDM_OE_N from inverter Y to active-low enable pin1, and TDM_CLEAN from Schmitt-buffer Y to U_TDM input2. There is no structural power/input/output swap across the commissioned instances.

NC interpretation: all four NC pads use their own native unconnected-(ref-NC-Pad1) marker rather than a functional rail or signal net. They remain distinct physical pads; no same-net collapsing was assumed.

Geometry: measured signed component-top polygon area is -4.3225 mm² for each ref (CCW with y down). Individual pad centers are pin1(-1.1375,-0.95), pin2(-1.1375,0), pin3(-1.1375,+0.95), pin4(+1.1375,+0.95), pin5(+1.1375,-0.95) mm. All pad sizes are 1.32x0.6 mm. Package numbering, 0.95 mm pitch and five-lead identity census match the primary drawings; this is not a solder-joint process review.

Unresolved findings: none. Limited carrier-logic group verdict: SOUND. Order verdict remains DO-NOT-ORDER at pre-route.
