import gzip
import hashlib
import json
import shutil
import tarfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[4]
RUN = ROOT / "06_build/task_runs/rj45-carrier-clock-route-diagnosis1"
SCRATCH = RUN / "scratch"
OUT = RUN / "outputs"
ENV = json.loads((RUN / "envelope.json").read_text())


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


verified = []
for item in ENV["input_packet"]:
    path = ROOT / item["path"]
    actual = {"path": item["path"], "size": path.stat().st_size, "sha256": digest(path)}
    if actual["size"] != item["size"] or actual["sha256"] != item["sha256"]:
        raise SystemExit(f"input mismatch: {item['path']}")
    verified.append(actual)
(SCRATCH / "input-verification-after.json").write_text(json.dumps({"count": len(verified), "records": verified}, indent=2, sort_keys=True) + "\n")

stage = SCRATCH / "archive-stage"
if stage.exists():
    shutil.rmtree(stage)
(stage / "raw").mkdir(parents=True)
(stage / "analysis").mkdir(parents=True)

copies = {
    SCRATCH / "geometry-clean.json": stage / "analysis/geometry.json",
    SCRATCH / "geometry2-runtime.json": stage / "analysis/geometry-runtime.json",
    SCRATCH / "inspect_geometry.py": stage / "analysis/inspect_geometry.py",
    SCRATCH / "input-verification-after.json": stage / "analysis/input-verification-after.json",
    OUT / "report.md": stage / "report.md",
    OUT / "evidence.json": stage / "evidence.json",
}
for name in [
    "carrier-toponly-route-command.json", "carrier-toponly-route-runtime.json", "carrier-toponly-route.log",
    "carrier-toponly-route-attempt2-command.json", "carrier-toponly-route-attempt2-runtime.json", "carrier-toponly-route-attempt2.log",
    "carrier-clock-rip-all-diagnostic-command.json", "carrier-clock-rip-all-diagnostic-runtime.json", "carrier-clock-rip-all-diagnostic.log",
]:
    copies[ROOT / "root-runs" / name] = stage / "raw" / name
for src, dst in copies.items():
    shutil.copyfile(src, dst)

archive = OUT / "evidence.tar.gz"
with archive.open("wb") as raw:
    with gzip.GzipFile(filename="evidence.tar", mode="wb", fileobj=raw, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode="w") as tf:
            for path in sorted(p for p in stage.rglob("*") if p.is_file()):
                arc = path.relative_to(stage).as_posix()
                info = tf.gettarinfo(str(path), arcname=arc)
                info.uid = info.gid = 0
                info.uname = info.gname = ""
                info.mtime = 0
                with path.open("rb") as f:
                    tf.addfile(info, f)

members = []
seen = set()
with tarfile.open(archive, "r:gz") as tf:
    for member in tf.getmembers():
        pp = PurePosixPath(member.name)
        if member.name in seen or pp.is_absolute() or ".." in pp.parts or member.issym() or member.islnk():
            raise SystemExit(f"unsafe archive member: {member.name}")
        seen.add(member.name)
        if not member.isfile():
            raise SystemExit(f"non-regular archive member: {member.name}")
        data = tf.extractfile(member).read()
        if member.name.endswith("evidence.tar.gz"):
            raise SystemExit("recursive archive")
        members.append({"path": member.name, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()})

manifest = {
    "archive_sha256": digest(archive),
    "archive_size": archive.stat().st_size,
    "member_count": len(members),
    "members": members,
}
(OUT / "evidence-manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
