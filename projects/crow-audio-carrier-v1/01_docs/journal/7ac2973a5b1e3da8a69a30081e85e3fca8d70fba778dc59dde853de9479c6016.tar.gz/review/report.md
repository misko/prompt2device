review_stage: route-diagnosis
review_kind: route_backtrack
reviewer: Codex GPT-6 independent reviewer /root/rj45_carrier_clock_route_diagnosis1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
r0_sha256: cc981839345d9e61bfaf6915014b904dcfa35dacb8b9d4438e15d5fe6888fa4d
config_sha256: 85544c4283ee038d2f283991ff78d2a3f3c2b9a11d9788aed13c8b186a662d4b
exploration_sha256: 4fcaca982615c963b08199af7af0fb21f34de61a7c26b40857f0344eb48c6fe3
exploration_decision_sha256: 1214b54305e8a07ea4330ec18777448bb2e01c046b503f63d06e921690e0c059

# Fresh independent carrier clock-wave route diagnosis

The diagnosis is **SOUND** and the board remains unrouted and **DO-NOT-ORDER**. The stopped frontier is real: both owning attempts have the identical unresolved set `ADC_BCLK, ADC_FSYNC, ADC_MCLK, MCH_MCLK, MCLK_BUF, TDM_RAW`, and the exploration guard correctly records two attempts, one semantic signature, `STAGNATED`, and `stop: true`. The separate all-twelve-clock rip diagnostic is retained as diagnosis only. It does not authorize importing its output or counting it as an accepted route.

The six messages do not describe one failure mode. `ADC_MCLK`, `ADC_BCLK`, and the ADC leg of `TDM_RAW` are first-pass failures. Their limiting geometry is static: U_ADC fine-pitch pads, deterministic source launches, GND/LDO supply copper, and the one-layer F.Cu clock policy. Ripping all twelve clock nets cannot remove those obstacles and left the same three failures. `ADC_FSYNC`, `MCLK_BUF`, and `MCH_MCLK` all route during the first pass and become unresolved only after later tap/rip-up work. Their final reconciliation messages are ordering consequences and must not be misread as proof that their original endpoints are impossible.

## Exact net findings

- **ADC_MCLK — endpoint boxing by static source-owned copper.** U_ADC.34 is at `(98.95,68.60)` with a `0.18 mm` launch to `(99.85,68.60)` and a `0.36 mm` continuation to `(100.25,68.60)`. The first pass stops after 63 iterations. The observed blockers are the adjacent U_ADC/C_LDO_D `LDO_D_FILT` geometry and GND; r0 contains the LDO merge `(98.95,69.30)/(98.95,69.10) -> (99.50,69.205) -> (100.75,69.205) -> (101.225,67.90)`. The all-clock rip run changes none of this and fails identically. This is not clock-net congestion.
- **ADC_BCLK — endpoint boxing with only nominal-clearance-scale space.** U_ADC.29 is at `(98.95,70.60)`, between GND pad 30 at `(98.95,70.20)` and NC pad 28 at `(98.95,71.00)`. Its `0.18 mm` launch ends at `(99.85,70.60)` and widens to `0.36 mm` at `(100.10,70.60)`. The adjacent source-owned GND path runs `(98.95,70.20) -> (99.48,70.20) -> (99.73,70.075) -> (100.55,70.075) -> (100.85,70.55)`. KRT reports all eight cells blocked at the pad and the all-clock rip diagnostic still fails. The limiting foreign copper is static GND/NC geometry, not any removable clock route.
- **TDM_RAW — static one-layer corridor failure on the ADC branch.** The local U_TDM_SCH.2 `(146.3625,52.00)` to R_TDM_PD.1 `(144.70,52.51)` branch routes. The unconnected branch is U_ADC.25 `(98.95,72.20)` through its full-width corner launch `(99.10,72.29) -> (99.70,72.89) -> (100.20,72.89)`. The target launch itself reports open neighbors, but the search exhausts the F.Cu corridor even after ADC_FSYNC is ripped; the all-clock diagnostic again leaves the ADC branch open. This is static foreign copper/one-layer corridor capacity, not proof of a bad U_ADC pad.
- **ADC_FSYNC — reconciliation-only ordering failure.** U_ADC.24 is `(98.20,72.95)` and the source-owned corner route is `(98.29,73.10) -> (98.65,73.46) -> (99.10,73.46)`. It routes on the initial pass in two iterations, producing `1.16 mm` total with `0.96 mm` of retained stub. It is later ripped during the TDM_RAW recovery and is absent at final reconciliation. The later boxed message therefore describes the finished-board ordering state, not a first-pass physical impossibility.
- **MCLK_BUF — reconciliation-only ordering failure at the U_CLK row.** U_CLK.7 is `(148.40,58.75)`, between MCH_FSYNC/U_CLK.6 `(148.40,59.25)` and 3V3_ADC/U_CLK.8 `(148.40,58.25)`. Its bounded launch is `(148.40,58.75) -> (149.05,58.75) -> (149.50,58.55) -> (149.95,58.55)`. It initially routes in 573 iterations and `8.40 mm`, then is ripped first by ADC_BCLK and again by MCH_FSYNC. Re-routing after MCH_FSYNC is installed is boxed by MCH_FSYNC plus immutable 3V3_ADC. This is an ordering/reconciliation conflict.
- **MCH_MCLK — reconciliation-only long-corridor conflict.** Its three pads are U_CLK.1 `(145.60,58.25)`, R_MCH_MCLK_PD.1 `(144.51,56.10)`, and J10.9 `(166.00,49.00)`. The initial main and tap routes both succeed. It is later ripped to recover MCH_FSYNC; reconciliation reconnects the local pair but cannot restore the J10 branch. KRT reports zero blocked neighbors at J10, so J10 is not boxed. The failure is the occupied F.Cu corridor/order after MCH_FSYNC, not the header launch.

## Chosen next stage

Run **one new route-only candidate** after archiving the stopped subject. Change only `route.waves[name=clocks].grid_step` from its implicit `0.10 mm` value to explicit `0.05 mm`. Keep the exact twelve-net list, `layers: [F.Cu]`, `track_width: 0.36`, `clearance: 0.25`, `realized_width.minimum: 0.18`, the existing bounded launch coordinates above, and all rip/iteration limits unchanged. Do not add `rip_existing_nets`, do not lower width or clearance, and do not import the failed r1 or diagnostic output.

This is a new configuration subject rather than attempt 3 of the stopped candidate. It directly tests the only untested route-only variable supported by the evidence: whether the 0.10 mm raster is hiding legal motion beside the already reviewed 0.18-to-0.36 mm launches and exact 0.20/0.25 mm local-to-ordinary clearance transition. The existing logs explicitly report grid cells as the failing frontier; the all-clock rip result rules out another clock rip-list expansion. The candidate must still stop honestly if the same six-net frontier remains.

The source board SHA `92a4e2fc...`, pin review, native render review, and placement geometry do not stale because this field changes no board, placement, footprint, or prepared copper. The prepared r0 is expected to remain byte-identical and must be rehashed to prove that. The route configuration hash, route-progress subject, wave state, and both current exploration/decision records do stale and must start a new exploration lineage while preserving the old two-attempt archive. If prep unexpectedly changes r0, the accepted layout review's `prepared_board_sha256: cc981839...` also stales and must be renewed before routing.

A deterministic launch/source correction is the next escalation only if this single new candidate repeats the static first-pass failures. Placement backtrack is not supported now because three nets already route before reconciliation and the remaining evidence has not shown that moving a component is necessary. Architecture reassessment is not supported by this frontier.

FIRST-ARTICLE-ONLY / DO-NOT-ORDER. This report accepts the diagnosis and bounded next stage only; it does not accept routing, promotion, fabrication, assembly, release, or ordering.
