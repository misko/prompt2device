from pathlib import Path
from datetime import datetime,timezone,timedelta
import sys,json,hashlib,shutil,tempfile
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;name='rj45-model-visibility-reassessment';D=Path(tempfile.mkdtemp(prefix=name+'-'))
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
probe=json.loads((N/'rj45-model-reassessment-availability-opened.json').read_text());assert json.loads((Path(probe['envelope']).parent/'attempt.json').read_text())['status']=='PASS'
m=json.loads((N/'rj45-bottom-model-registration-source-opened.json').read_text());assert json.loads((Path(m['envelope']).parent/'attempt.json').read_text())['status']=='PASS'
shutil.copytree(Path(m['project'])/'input',D/'input')
for f in Path(m['output_dir']).iterdir():
 if f.is_file():q=D/'author'/f.name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,q)
for f in ['envelope.json','attempt.json','admission.json']:
 q=D/'author-allocation'/f;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(Path(m['envelope']).parent/f,q)
for p in ['skills/jlcpcb-fab/references/connector-orientation.md','skills/jlcpcb-fab/scripts/connector_orientation_gate.py','skills/pcb-design/references/execution-graph.md']:
 q=D/'input'/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/p,q)
shutil.copy2('/tmp/carrier-locator-implementation-availability-6c_4vwal/preflight.py',D/'preflight.py')
now=datetime.now(timezone.utc);cut=now+timedelta(minutes=20);hard=now+timedelta(minutes=30)
(D/'TASK.md').write_text((N/'model_reassessment_task.txt').read_text().format(cut=cut.isoformat(),hard=hard.isoformat()))
items=[]
for p in sorted(D.rglob('*')):
 if p.is_file():b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(D).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
s=subject_identity('model_visibility_reassessment',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())]);e=TaskEnvelope(schema=2,task_id=name,stage_id='KICAD-PLACEMENT',run_id=name,subject=s,executor='agent',execution_class='review_wait',recommended_agent_role='judgment',agent_role='judgment',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']})
o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),agent_id='/root/carrier_rj45_model_visibility_reassessment',work_cutoff=cut.isoformat());(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2));print(len(items),'frozeninputs')
