review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 92a4e2fc0fecde845f2dfa0d9e2f5bfbd943372962fb449d699a98d957fc5633
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: 7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c

This review is limited to the commissioned groups D_IN and D_QIN_GS and does not accept the whole board. Both supplied instances were checked.

D_IN VERDICT: PASS

Measured native pad identities: 2. Measured physical terminal identities: 2. Exposed-pad identities: 0. Aliased or fused identities: 0.

Primary document: Littelfuse `Littelfuse_SMBJ_v4_2025-07-04.pdf`, SHA-256 `d7df155be4b1f612085401e8c946f065e284d65a0e7de22b9225a7b73946e51b`, pages 1 and 5, figures `Functional Diagram` and `Dimensions — DO-214AA (SMB J-Bend), Cathode Band`.

D_IN pin 1 (K): expected the banded cathode terminal of the unidirectional SMBJ15A on the positive protected rail vs dossier pad 1 at component-top W on `12V_PROTECTED`; matches after rotation of the manufacturer view, with no mirror.

D_IN pin 2 (A): expected the terminal opposite the cathode band and the low-side return for a unidirectional positive-rail TVS vs dossier pad 2 at component-top E on `GND`; matches.

Package/geometry: expected DO-214AA SMB J-Bend with two distinct collinear terminals, no EP, and no meaningful winding vs two distinct pads, explicit front mount/component-top frame, no EP, and winding reported n/a; matches. No alias collapse is present. One supplied D_IN instance makes the symmetry comparison vacuous.

D_QIN_GS VERDICT: PASS

Measured native pad identities: 2. Measured physical terminal identities: 2. Exposed-pad identities: 0. Aliased or fused identities: 0.

Primary document: Diodes Incorporated `BZT52_DS18004_Rev38-2.pdf`, SHA-256 `0fbd7d137524820f0160594065cbceb8c6b3188757c328416d08fceb7418202f`, pages 1, 2, and 4, figures `SOD123 Top View / Marking Information`, `Electrical Characteristics` exact BZT52C12 row, and `Package Outline Dimensions / Suggested Pad Layout`.

D_QIN_GS pin 1 (K): expected the banded cathode terminal of the BZT52C12 at the higher-potential source/rail side of a gate-source zener clamp vs dossier pad 1 at component-top W on `12V_PROTECTED`; matches after rotation of the manufacturer top view, with no mirror.

D_QIN_GS pin 2 (A): expected the terminal opposite the cathode band on the gate side of the clamp vs dossier pad 2 at component-top E on `Q_IN_GATE`; matches.

Package/geometry: expected SOD123 with two distinct collinear terminals, no EP, and no meaningful winding vs two distinct pads, explicit front mount/component-top frame, no EP, and winding reported n/a; matches. No alias collapse is present. One supplied D_QIN_GS instance makes the symmetry comparison vacuous.

No unresolved findings. The immutable order verdict remains DO-NOT-ORDER as commissioned.
