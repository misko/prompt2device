#!/usr/bin/python3
import hashlib
import json
import os
import tarfile
from pathlib import Path

scratch = Path(__file__).resolve().parent
source = scratch / "evidence"
outputs = scratch.parent / "outputs"
archive = outputs / "evidence.tar.gz"

members = []
paths = sorted(p for p in source.rglob("*") if p.is_file())
seen = set()
for path in paths:
    if path.is_symlink():
        raise RuntimeError(f"symlink forbidden: {path}")
    rel = path.relative_to(source).as_posix()
    if rel.startswith("/") or ".." in Path(rel).parts or rel in seen:
        raise RuntimeError(f"unsafe or duplicate member: {rel}")
    seen.add(rel)
    data = path.read_bytes()
    members.append({"path": rel, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()})

with tarfile.open(archive, "w:gz", format=tarfile.PAX_FORMAT) as tf:
    for path in paths:
        tf.add(path, arcname=path.relative_to(source).as_posix(), recursive=False)

reopened = []
with tarfile.open(archive, "r:gz") as tf:
    names = set()
    for info in tf.getmembers():
        rel = info.name
        if rel.startswith("/") or ".." in Path(rel).parts or rel in names:
            raise RuntimeError(f"unsafe or duplicate archived member: {rel}")
        names.add(rel)
        if not info.isfile() or info.issym() or info.islnk():
            raise RuntimeError(f"non-regular archived member: {rel}")
        stream = tf.extractfile(info)
        if stream is None:
            raise RuntimeError(f"cannot reopen archived member: {rel}")
        data = stream.read()
        reopened.append({"path": rel, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()})
if reopened != members:
    raise RuntimeError("archive reopen census differs from source census")

blob = archive.read_bytes()
manifest = {
    "schema": 1,
    "archive_sha256": hashlib.sha256(blob).hexdigest(),
    "archive_size": len(blob),
    "member_count": len(members),
    "members": members,
}
(outputs / "evidence-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps(manifest))
