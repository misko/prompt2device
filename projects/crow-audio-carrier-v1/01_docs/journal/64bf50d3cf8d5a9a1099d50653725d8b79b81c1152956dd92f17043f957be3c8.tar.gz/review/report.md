review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_conversion_clockground1 (actual fresh agent)
context: FRESH
design_verdict: INCOMPLETE
order_verdict: DO-NOT-ORDER
board_sha256: e85b1461a82f3d3853c19fae694693816e31570d23d37019ef187d6428bea4ae
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: e6d5b0b89efd79051b082f70b283ec7e85e1170ed11ddb94581744d26904c9c7

Coverage is limited to the supplied native U_ADC and U_LDO instances, one of each. This is not whole-board acceptance, route approval, BOM approval, or an order authorization. Immutable hashes above are supplied subject bindings, not independently reviewed conclusions. No known electrical or package defect was established; the ADC needs specific design context before PASS.

U_ADC — VERDICT: QUESTION

Primary: Cirrus CS5308P DS1314F1; SHA256 6ca42cc09ac47ebdacacaee435f05e3f9c34b83d5692e52a2d8a26533e810e57. Actual inspected images: PDF page 4 Figure 1-1, page 7 Figure 2-1, page 93 Figure 10-1. Supporting primary text: pages 5–6 Table 1-1/1-2, pages 19–20 Tables 4-1 through 4-4.

Independent figure derivation before dossier inspection: Figure 1-1 explicitly shows TOP VIEW through package. Pin 1 is upper left on the west bank; pins 1–12 run downward, 13–24 eastward on south, 25–36 upward on east, 37–48 westward on north. This is CCW. Twelve terminals per side plus one exposed ground paddle. Page 93 top view has the pin-1 mark upper left. Its bottom view has pin 1 upper right; horizontal reflection converts that bottom drawing to the top view, matching Figure 1-1. The package is 6 x 6 mm, pitch 0.4 mm, nominal EP 4.6 x 4.6 mm. The unnumbered manufacturer PAD is preserved as the distinct native artifact identity 49, not fused with perimeter ground terminals.

Observed: front mounted, rotation 0, explicit component-top +x right/+y down. No mount reflection applies. Native coordinates match all 48 terminal positions and the center EP without any mirror or rotation. Measured 49 numbered native pads, 49 unique physical identities, nine unnumbered paste-only features, 58 total native pad features. All 49 function assignments match the independent figure; no collapsed physical identities or fused aliases. Native pad dimensions/0.4-mm pitch and center paddle agree with package geometry. The complete per-pin expected/observed comparison is in measured-comparison.json.

U_ADC pins 5,9,31 (VDD_A1/VDD_A2/VDD_IO): expected supply rail; observed 3V3_ADC. PASS.
U_ADC pins 6,8,30,49 (analog/digital grounds and PAD): expected common ground; observed GND for each distinct identity. PASS at net level; physical plane implementation is outside this pre-route review.
U_ADC pins 32,33 (LDO_D_FILT/VDD_D): Figure 2-1 requires the internal digital-LDO output to supply VDD_D; observed both on LDO_D_FILT. PASS.
U_ADC pins 7,1,12,18,43 (LDO_A_FILT, VMID1/2, FILT2P/FILT1P): expected separate bypass/reference/filter nets; observed LDO_A_FILT, VMID1, VMID2, FILT2P, FILT1P. PASS for pin-net role; external component values are not supplied.
U_ADC pins 17,44 (ADC_FILT2N/ADC_FILT1N): Figure 2-1 shows these capacitor returns grounded; observed GND. PASS.
U_ADC pins 23,24,25,29,34 (RESET, FSYNC, DOUT1, BCLK, MCLK): expected reset/frame/data/clock nets; observed ADC_RESET_N, ADC_FSYNC, TDM_RAW, ADC_BCLK, ADC_MCLK. PASS for pin-net role; clock rate and timing are outside dossier evidence.
U_ADC pins 13–16,19–22 (IN5–8 N/P): expected differential analog input pairs; observed ADC5–8 N/P, preserving identities and polarity. PASS.
U_ADC pins 39,40,41,42,45,46,47,48 (IN1–4 N/P): expected physical channels 1,2,3,4; observed logical nets ADC4,ADC3,ADC2,ADC1 respectively, with both polarities preserved. QUESTION: provide the intended logical-to-physical channel assignment and associated stream-order selection. This permutation is not itself an electrical short or winding defect, but its functional intent cannot be certified from the dossier.
U_ADC pins 2,3,10,11 (CONFIG1/2/4/5): expected valid mode-selection straps; observed CFG1,CFG2,CFG4,CFG5 without destinations or resistor values. QUESTION: provide CFG1/CFG2 resistor values and rail/ground destinations to establish hardware mode and ASP/TDM selection, plus CFG4 to resolve channel order. The grounded SPI pins and floating DOUT2–4 are conditionally legitimate, but the dossier cannot establish the required mode.
U_ADC pin 4 (CONFIG3): expected ground permitted for lower TDM slots; observed GND. PASS for hardware strap role (Table 4-2).
U_ADC pins 26–28 (ASP_DOUT2–4): expected float when unused; observed individual unconnected nets. Conditional on the unresolved ASP mode.
U_ADC pins 35–37 (unused SPI_SDO/SCK/SDI): Table 1-2 permits ground when unused; observed GND. U_ADC pin 38 (SPI_CS): unused termination is VDD_IO; observed 3V3_ADC. Conditional on the unresolved control mode.

U_LDO — VERDICT: PASS

Primary: Analog Devices LT3041 Rev. A; SHA256 35dda1deb2ffc9e20545ebe2aefd2fbd690cf9b04e8772290fd4991a4b8ef584. Actual inspected images: PDF page 7 Figure 3, page 36 Figure 98 (05-08-1708). Supporting primary text: pages 7–8 Table 3 and page 27 VIOC guidance.

Independent Figure 3 derivation before dossier inspection: explicit TOP VIEW, pin 1 upper left, pins 1–7 down the left bank, pins 8–14 up the right bank; CCW. EP is explicitly pin 15 GND. Figure 98 bottom view shows pin 1 lower right and 7 lower left, with 8 upper left and 14 upper right. Reflect horizontally to top view, then rotate clockwise 90 degrees to reach Figure 3 orientation (pin 1 upper left). This conversion is solely for the manufacturer bottom drawing; no extra reflection is applied to the front-mounted native table. Nominal package 4 x 3 mm, 0.5-mm pitch; recommended land EP 3.3 x 1.7 mm, terminal 0.70 x 0.25 mm. Rotating the land pattern gives the native 1.7 x 3.3 mm EP and horizontal 0.7 x 0.25 mm terminal pads.

Observed: front mount at rotation 0 with explicit component-top convention. Measured 15 numbered native pads, 15 distinct manufacturer physical identities, eight unnumbered paste-only features, 23 total native pad features. All 14 terminal identities and EP15 match Figure 3. No fused aliases. Native row centers x +/-1.45 mm and y -1.5 through +1.5 mm match the rotated land pattern. The dossier's generic N/S tags at pins 1/7/8/14 arise because |y| exceeds |x|; these are not physical top/bottom terminal banks. Actual coordinates correctly form two seven-pin side banks.

U_LDO pins 1–3 (IN): expected common input rail, observed 5V_LDO_HOLD on three distinct pads. PASS.
U_LDO pin 4 (VIOC): page 27 permits floating unused output; observed individual unconnected net. PASS.
U_LDO pin 5 (EN/UV): expected enable/UV control net, observed LDO_EN. PASS for pin-net role; the external threshold network is outside supplied evidence.
U_LDO pin 6 (PG): unused flag may float; observed unconnected. PASS.
U_LDO pin 7 (ILIM): unused programmable current limit must connect GND; observed GND. PASS.
U_LDO pin 8 (PGFB): unused power-good/fast-start functions require IN; observed 5V_LDO_HOLD, equal to pins 1–3. PASS.
U_LDO pin 9 (SET): expected dedicated setpoint/noise-reduction net, observed LDO_NR. PASS for pin-net role, not certification of external set resistance or output voltage.
U_LDO pins 10,11,15 (GND and EP): expected common GND, observed GND on all three distinct pads. PASS.
U_LDO pins 12–14 (OUTS, OUT, OUT): expected output-sense and output rail, observed 3V3_ADC for each. PASS at net level; Kelvin routing remains to be implemented/reviewed.

Instance symmetry: only one commissioned instance per device, so no same-device pairwise comparison exists. Across this group the LDO output and ADC analog/I/O supply are consistently named 3V3_ADC. No unseen instances are claimed reviewed.

Methods and evidence: exact envelope inputs checked before and after. Primary pinout images were rendered with pdftoppm and inspected using view_image before native dossiers were read; text extraction only supplemented images. Finite subprocess runtime receipts and raw logs, actual inspected images, native dossiers, pin-by-pin computed comparisons, methods script and exact PDF hashes are archived. Source PDFs remain digest-bound in the frozen packet. No project or schematic inspection, no live edits, no child agents. Engineering findings above are delivered completely; delivery PASS does not convert design INCOMPLETE into acceptance.
