from pathlib import Path
import json,hashlib,tarfile,shutil
r=Path('/tmp/rj45-pin-carrier-conversion-clockground1-q3ecx_wr');t=r/'06_build/task_runs/rj45-pin-carrier-conversion-clockground1';s=t/'scratch';o=t/'outputs'
for name in ['report.md','evidence.json','result.json']:shutil.copyfile(o/name,s/name)
archive=o/'evidence.tar.gz'
# Package stable evidence only: the packaging invocation logs are still open.
paths=[p for p in sorted(s.rglob('*')) if p.is_file() and not p.name.startswith('packaging') and not p.name.startswith('final-preflight')]
with tarfile.open(archive,'w:gz') as tar:
 for p in paths:
  assert not p.is_symlink();tar.add(p,arcname=p.relative_to(s).as_posix(),recursive=False)
rows=[];seen=set()
with tarfile.open(archive,'r:gz') as tar:
 for m in tar:
  assert m.isfile() and m.name not in seen and not m.name.startswith('/') and '..' not in Path(m.name).parts and not m.name.endswith(('.tar','.tar.gz','.tgz'))
  seen.add(m.name);b=tar.extractfile(m).read();assert len(b)==m.size
  assert hashlib.sha256(b).hexdigest()==hashlib.sha256((s/m.name).read_bytes()).hexdigest()
  rows.append(dict(path=m.name,size=m.size,sha256=hashlib.sha256(b).hexdigest()))
(o/'evidence-manifest.json').write_text(json.dumps(dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_size=archive.stat().st_size,member_count=len(rows),members=rows),indent=2)+'\n')
print('Archive reopened and verified:',len(rows),'regular members')
