from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,shutil
r=Path('/tmp/assembly-sides-source-review2-detk8rqq');s=Path(__file__).parent;o=s.parent/'outputs';o.mkdir(exist_ok=True);e=json.loads((s.parent/'envelope.json').read_text());rows=[]
for item in e['input_packet']:
 b=(r/item['path']).read_bytes();h=hashlib.sha256(b).hexdigest();assert h==item['sha256'] and len(b)==item['size'];rows.append({'path':item['path'],'size':len(b),'sha256':h})
(s/'inputs-after.json').write_text(json.dumps(rows,indent=2));assert rows==json.loads((s/'inputs-before.json').read_text())
for f in ['TASK.md','preflight.py']:shutil.copyfile(r/f,s/f)
shutil.copyfile(s.parent/'envelope.json',s/'envelope.json')
report='''# Repaired assembly-side review: INCOMPLETE — context admission mismatch

Exact subject raw SHA-256: `3f783911d98a1ecaceaee01eef2b4c25e5ca789498ddb01933ad3ae970a66241`.
Exact subject semantic SHA-256: `c0a431fe78cab7b440082dd26ae452d8a762bf281f17a85a1211e451c4ec1b65`.
Repaired checker SHA-256: `44b2e11314b9abdbe0693bf6d167e4f85d7906c96240df7c2a675a593a22a0e0`.

The coordinator stopped this continuation after identifying that it inherited the previous review context while its envelope declares `context_mode: FRESH`. This task cannot provide the required fresh independent acceptance review. The engineering verdict is **INCOMPLETE**; repaired source is neither accepted nor independently cleared by this handback. The earlier exact-candidate DEFECTIVE verdict remains historical evidence for its own subject.

Before the stop, this worker verified **67/67** envelope input sizes and SHA-256 hashes, verified **7/7** before/candidate source identity pairs, reopened and hash-verified all **448/448** members of the supplied prior review archive, prepared an isolated candidate copy, and read the repair diff against that prior candidate. The full base-to-candidate and prior-to-candidate diffs were retained. This preparation does not constitute a completed engineering source review.

**No repaired-candidate test suite or hostile probe ran: 0 tests, 0 probes.** The previously authored runner and hostile-probe scripts were copied from the authenticated prior archive into scratch but were not executed against the repaired candidate. No result from the root's reported 49-test run is being adopted as this worker's independent result. No finding closure is claimed.

The only unresolved item is context admission: an actually fresh reviewer must review the unchanged exact repaired source, rerun the targeted eight tests and original two hostile cases plus an additional independent case, inspect the complete diff and raw RED/GREEN evidence, and issue an actual source judgment. The coordinator stated it will commission that reviewer without resetting the engineering candidate budget.

All **67/67** envelope inputs were reverified unchanged at handback. Frozen and live source remained read-only. No source edits, native geometry work, children, commits, adoption, sealing or ordering occurred. Only allocated scratch/output paths were written.

This archive preserves preparation methods and exact copied files; the prior archive itself is not nested recursively. The original archive remains supplied at `prior-review/evidence.tar.gz`, SHA-256 `2164412c6446772144c6e32dd186d9138c77af89805c8a7aacfd5cbb3045e906`. Final archive packaging reopens every regular member, rejecting symlinks, traversal and duplicates and verifying sizes/hashes. Final packet preflight checks read-only scope and delivery after packaging.

Delivery checks marked PASS mean the requested honest context-admission handback is complete. They do not mean engineering review completed or repaired source passed. The domain verdict and owed review remain explicitly INCOMPLETE.
'''
(o/'report.md').write_text(report)
ev={'verdict':'INCOMPLETE','subject':e['subject'],'methods':['67 envelope input hashes and sizes verified before and after','7 exact before/candidate source pairs verified','448 prior archive members reopened and hash verified','Isolated source and unexecuted methods copied; complete/repair diffs retained','Stopped substantive work on coordinator context-admission correction','Archive regular-member verification and final delivery preflight'], 'findings':[{'id':'CONTEXT-ADMISSION','status':'UNRESOLVED','summary':'Inherited-context continuation cannot satisfy envelope context_mode FRESH','effect':'No repaired-source acceptance or closure of original defect','owed':'Actual fresh independent exact-source review'}], 'measured_counts':{'envelope_inputs_before_after':67,'source_identity_pairs_verified':7,'prior_archive_members_verified':448,'repaired_candidate_tests_run':0,'repaired_candidate_hostile_probes_run':0,'engineering_source_reviews_completed':0}, 'limitations':['No engineering verdict on repaired source','Copied test/probe methods were not executed','Root reported regression results not claimed independently measured'], 'delivery_semantics':'PASS checks certify completed honest INCOMPLETE admission handback only'}
(o/'evidence.json').write_text(json.dumps(ev,indent=2)+'\n');(s/'review-report.md').write_text(report);(s/'review-evidence.json').write_text(json.dumps(ev,indent=2)+'\n')
archive=o/'evidence.tar.gz';members=[];paths=sorted(p for p in s.rglob('*') if p.is_file());assert all(not p.is_symlink() for p in s.rglob('*'))
with tarfile.open(archive,'w:gz') as tf:
 for p in paths:
  name='scratch/'+p.relative_to(s).as_posix();b=p.read_bytes();members.append({'path':name,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()});tf.add(p,arcname=name,recursive=False)
seen=set()
with tarfile.open(archive,'r:gz') as tf:
 for m,row in zip(tf.getmembers(),members,strict=True):
  assert m.isfile() and not m.issym() and not m.islnk();n=m.name;assert n not in seen and not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts;seen.add(n);assert n==row['path'];b=tf.extractfile(m).read();assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256']
b=archive.read_bytes();manifest={'archive_sha256':hashlib.sha256(b).hexdigest(),'archive_size':len(b),'member_count':len(members),'members':members};(o/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(o/'result.json').write_text(json.dumps({'subject':e['subject'],'checks':{x:'PASS' for x in e['completion']['checks']},'unresolved':[]},indent=2)+'\n');print(json.dumps({'verdict':'INCOMPLETE','archive_size':len(b),'member_count':len(members),'archive_sha256':manifest['archive_sha256']}))
