from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
name='rj45-mixed-side-repaired-integrity';meta=json.loads((N/(name+'-opened.json')).read_text());closed=json.loads((N/(name+'-closeout-summary.json')).read_text())
assert closed['delivery_status']=='PASS' and closed['engineering_verdict']=='SOUND'
D=Path(meta['project']);O=Path(meta['output_dir']);E=json.loads(Path(meta['envelope']).read_text());e=json.loads((O/'evidence.json').read_text());report=(O/'report.md').read_text()
assert e['verdict']=='SOUND' and e['subject']==E['subject']
assert hashlib.sha256(Path(closed['archive']).read_bytes()).hexdigest()==closed['sha256']
for row in E['input_packet']:
 b=(D/row['path']).read_bytes();assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256']
rows=json.loads((D/'source-manifest.json').read_text())['files'];assert len(rows)==13
before={};after={}
for row in rows:
 rel=row['path'];assert not Path(rel).is_absolute() and '..' not in Path(rel).parts
 b=(R/rel).read_bytes();p=(D/'proposal'/rel).read_bytes();assert hashlib.sha256(b).hexdigest()==row['before_sha256'] and len(b)==row['before_size']
 assert hashlib.sha256(p).hexdigest()==row['after_sha256'] and len(p)==row['after_size']
 assert row['after_sha256'] in report,'Reviewer must explicitly cover exact13 postimages'
 before[rel]=b;after[rel]=p
record={'created_at':datetime.now(timezone.utc).isoformat(),'review':closed,'files':rows,'scope':'Exact independently accepted13 source postimages adopted; root full-checkout qualification and normal dependent renewal still owed.'}
(N/'mixed-side-source-adoption-planned.json').write_text(json.dumps(record,indent=2)+'\n')
try:
 for rel,b in after.items():
  assert (R/rel).read_bytes()==before[rel];(R/rel).write_bytes(b);assert (R/rel).read_bytes()==b
except Exception:
 for rel,b in before.items():(R/rel).write_bytes(b)
 raise
(N/'mixed-side-source-adoption.json').write_text(json.dumps(record,indent=2)+'\n')
print('Adopted13 exact independently reviewed source files; full-checkout qualification next')
