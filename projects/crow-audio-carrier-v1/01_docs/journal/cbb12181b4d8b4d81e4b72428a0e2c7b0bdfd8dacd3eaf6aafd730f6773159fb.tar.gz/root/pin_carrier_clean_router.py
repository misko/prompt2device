from pathlib import Path
import json,hashlib,sys
from datetime import datetime,timezone
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911');P=R/'projects/crow-audio-carrier-v1'
sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'))
from pre_route_review_check import design_rules_digest
runtime=json.loads((I/'mixedside1-clean-krt-tracked-state-runtime.json').read_text());assert runtime['status']=='PASS'
p=P/'03_src/route.yaml';before=p.read_bytes();old=b'  krt: ~/gits/KiCadRoutingTools\n';new=b'  krt: /home/mouse9911/gits/KiCadRoutingTools-worktrees/cccv-5a1bdc4\n';assert before.count(old)==1
d=design_rules_digest(P);(N/'carrier-route-before-clean-krt.yaml').write_bytes(before);after=before.replace(old,new);p.write_bytes(after)
try:assert design_rules_digest(P)==d
except Exception:p.write_bytes(before);raise
record={'created_at':datetime.now(timezone.utc).isoformat(),'path':str(p),'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'unchanged_design_rules_sha256':d,'router_commit':'5a1bdc4d9582fa6c9019cf5bab9625ea4452f188','old_checkout':'/home/mouse9911/gits/KiCadRoutingTools','new_checkout':'/home/mouse9911/gits/KiCadRoutingTools-worktrees/cccv-5a1bdc4','basis':'Both git HEADs measured identical; original checkout has8tracked modifications plus untracked tests/env. Selected checkout has zero tracked diff and existing .venv only. Same clean router already selected by pod. Owning semantic design digest explicitly excludes route.krt; unchanged geometry/widths/limits. Normal shared source checkpoint renewal will bind new runtime path before routing.','tracked_clean_runtime':runtime,'scope':'Execution-path correction only; no routing or engineering acceptance.'}
(N/'carrier-clean-router-pin.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
