# pin dossier: D_IN  (SMBJ15A)

- footprint: crow_audio_carrier:Littelfuse_SMBJ15A_SMB_Exact
- board position: (32.799999, 82.300000) rot 0.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/SMBJ15A/Littelfuse_SMBJ_v4_2025-07-04.pdf
- part.yaml verification note: CITED: official Littelfuse SMBJ table exact SMBJ15A row gives 15.0V VR, 16.7-18.5V VBR at 1mA, 24.4V VC and 24.6A IPP; read 2026-09-01.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-2.150000,+0.000000) | W | 2.5x2.3 | K | 12V_PROTECTED | (+30.649999,+82.300000) |
| 2 | (+2.150000,+0.000000) | E | 2.5x2.3 | A | GND | (+34.949999,+82.300000) |
