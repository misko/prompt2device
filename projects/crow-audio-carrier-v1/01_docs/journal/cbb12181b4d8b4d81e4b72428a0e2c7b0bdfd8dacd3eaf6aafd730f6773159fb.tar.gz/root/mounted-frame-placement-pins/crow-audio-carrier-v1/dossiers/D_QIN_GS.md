# pin dossier: D_QIN_GS  (BZT52C12-7-F)

- footprint: Diode_SMD:D_SOD-123
- board position: (42.400000, 71.000000) rot 0.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/BZT52C12-7-F/BZT52_DS18004_Rev38-2.pdf
- part.yaml verification note: CITED part identity and polarity; exact clamp spread/current is retained as first-article screening.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-1.650000,+0.000000) | W | 0.9x1.2 | K | 12V_PROTECTED | (+40.750000,+71.000000) |
| 2 | (+1.650000,+0.000000) | E | 0.9x1.2 | A | Q_IN_GATE | (+44.050000,+71.000000) |
