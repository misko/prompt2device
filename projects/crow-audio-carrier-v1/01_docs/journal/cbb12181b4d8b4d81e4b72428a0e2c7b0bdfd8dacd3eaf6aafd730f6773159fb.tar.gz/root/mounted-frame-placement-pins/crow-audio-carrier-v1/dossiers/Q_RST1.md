# pin dossier: Q_RST1  (2N7002K-7)

- footprint: crow_audio_carrier:Diodes_2N7002K_SOT23_Exact
- board position: (109.500000, 73.500000) rot 0.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/2N7002K-7/2N7002K_DS30896_Rev20-2.pdf
- part.yaml verification note: CITED: Diodes DS30896 Rev. 20-2 pin configuration and equivalent-circuit top-view figures, PDF p.1, independently fix pin 1=G, pin 2=S, pin 3=D; re-read 2026-09-01.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-1.000000,-0.950000) | W | 0.9x0.8 | G | RESET_PULSE_H | (+108.500000,+72.550000) |
| 2 | (-1.000000,+0.950000) | W | 0.9x0.8 | S | GND | (+108.500000,+74.450000) |
| 3 | (+1.000000,+0.000000) | E | 0.9x0.8 | D | ADC_RESET_N | (+110.500000,+73.500000) |
