# pin dossier: U_TDM  (SN74LVC1G125DBVR)

- footprint: Package_TO_SOT_SMD:SOT-23-5
- board position: (154.000000, 54.000000) rot 0.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/SN74LVC1G125DBVR/SN74LVC1G125_SCES223U.pdf
- part.yaml verification note: CITED: TI SCES223U DBV top-view drawing and Pin Functions table, PDF p.3, fix pins 1=OE, 2=A, 3=GND, 4=Y and 5=VCC; Features, PDF p.1, and the Electrical Characteristics table, PDF p.6, fix Ioff partial-power-down/back-drive behavior. Physical behavior remains a first-article power-state test.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-1.137500,-0.950000) | W | 1.32x0.6 | OE_N | TDM_OE_N | (+152.862500,+53.050000) |
| 2 | (-1.137500,+0.000000) | W | 1.32x0.6 | A | TDM_CLEAN | (+152.862500,+54.000000) |
| 3 | (-1.137500,+0.950000) | W | 1.32x0.6 | GND | GND | (+152.862500,+54.950000) |
| 4 | (+1.137500,+0.950000) | E | 1.32x0.6 | Y | TDM_BUFFERED | (+155.137500,+54.950000) |
| 5 | (+1.137500,-0.950000) | E | 1.32x0.6 | VCC | 3V3_ADC | (+155.137500,+53.050000) |
