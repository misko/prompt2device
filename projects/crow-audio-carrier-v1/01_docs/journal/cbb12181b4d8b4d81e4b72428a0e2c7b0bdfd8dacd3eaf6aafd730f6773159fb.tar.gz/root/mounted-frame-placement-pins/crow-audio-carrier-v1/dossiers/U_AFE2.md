# pin dossier: U_AFE2  (OPA2320AIDR)

- footprint: Package_SO:SOIC-8_3.9x4.9mm_P1.27mm
- board position: (72.500000, 47.000000) rot 0.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/OPA2320AIDR/OPA2320_SBOS513F.pdf
- part.yaml verification note: CITED: SBOS513F p4 OPA2320 D-package top view and pin-functions table:1=OUTA,2=-INA,3=+INA,4=V-,5=+INB,6=-INB,7=OUTB,8=V+. Main visual read and fresh independent source review2026-09-09; generated/native acceptance remains incomplete.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-2.475000,-1.905000) | W | 1.95x0.6 | OUTA | OPA_P2 | (+70.025000,+45.095000) |
| 2 | (-2.475000,-0.635000) | W | 1.95x0.6 | -INA | FB_P2 | (+70.025000,+46.365000) |
| 3 | (-2.475000,+0.635000) | W | 1.95x0.6 | +INA | AIN_P2 | (+70.025000,+47.635000) |
| 4 | (-2.475000,+1.905000) | W | 1.95x0.6 | V- | GND | (+70.025000,+48.905000) |
| 5 | (+2.475000,+1.905000) | E | 1.95x0.6 | +INB | AIN_N2 | (+74.975000,+48.905000) |
| 6 | (+2.475000,+0.635000) | E | 1.95x0.6 | -INB | FB_N2 | (+74.975000,+47.635000) |
| 7 | (+2.475000,-0.635000) | E | 1.95x0.6 | OUTB | OPA_N2 | (+74.975000,+46.365000) |
| 8 | (+2.475000,-1.905000) | E | 1.95x0.6 | V+ | 3V3_ADC | (+74.975000,+45.095000) |
