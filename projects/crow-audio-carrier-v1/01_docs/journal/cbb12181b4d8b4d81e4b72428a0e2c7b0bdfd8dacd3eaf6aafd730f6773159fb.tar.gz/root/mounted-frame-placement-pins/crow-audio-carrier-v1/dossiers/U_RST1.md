# pin dossier: U_RST1  (TPS3839K33DBZR)

- footprint: Package_TO_SOT_SMD:SOT-23
- board position: (110.000000, 68.000000) rot 0.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/TPS3839K33DBZR/TPS3839_SBVS193D.pdf
- part.yaml verification note: CITED: TI SBVS193D DBZ package top view and pin table, PDF p.5, fix 1=GND, 2=RESET, 3=VDD; device-information/electrical tables, PDF pp.2 and 7, fix K33 threshold and delay; re-read 2026-09-01.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-0.937500,-0.950000) | N | 1.48x0.6 | GND | GND | (+109.062500,+67.050000) |
| 2 | (-0.937500,+0.950000) | S | 1.48x0.6 | RESET# | POR_N | (+109.062500,+68.950000) |
| 3 | (+0.937500,+0.000000) | E | 1.48x0.6 | VDD | 3V3_ADC | (+110.937500,+68.000000) |
