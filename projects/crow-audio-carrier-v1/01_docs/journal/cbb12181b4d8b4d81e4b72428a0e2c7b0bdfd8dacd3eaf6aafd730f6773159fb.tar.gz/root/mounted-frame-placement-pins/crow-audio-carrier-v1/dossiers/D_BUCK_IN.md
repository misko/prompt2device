# pin dossier: D_BUCK_IN  (US1B-13-F)

- footprint: Diode_SMD:D_SMA
- board position: (26.000000, 58.000000) rot 90.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/US1B-13-F/Diodes_US1A_US1M_DS16008_Rev11-2.pdf
- part.yaml verification note: Primary exact US1B-13-F identity, cathode band, package and limits re-read 2026-09-09. Public exact C154439 identity only; not allocation or order acceptance.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-2.000000,+0.000000) | W | 2.5x1.8 | K | 12V_BUCK_IN | (+26.000000,+60.000000) |
| 2 | (+2.000000,+0.000000) | E | 2.5x1.8 | A | 12V_PROTECTED | (+26.000000,+56.000000) |
