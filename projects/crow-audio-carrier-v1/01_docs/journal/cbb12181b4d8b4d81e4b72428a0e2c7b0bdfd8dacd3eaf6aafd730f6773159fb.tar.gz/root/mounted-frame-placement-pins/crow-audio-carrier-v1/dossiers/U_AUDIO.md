# pin dossier: U_AUDIO  (TPS389001DSER)

- footprint: crow_audio_carrier:TI_DSE0006A_Exact
- board position: (33.000000, 61.100000) rot 0.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/TPS389001DSER/TPS3890_SLVSD65A.pdf
- part.yaml verification note: Primary pin-function table and exact orderable suffix; package land drawing visually inspected2026-09-07. See ADR0009 for modeled versus measured distinction.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-0.550000,-0.500000) | W | 0.8x0.25 | SENSE | ADC_SENSE | (+32.450000,+60.600000) |
| 2 | (-0.600000,+0.000000) | W | 0.7x0.25 | GND | GND | (+32.400000,+61.100000) |
| 3 | (-0.600000,+0.500000) | W | 0.7x0.25 | MR_N | PWR_EN | (+32.400000,+61.600000) |
| 4 | (+0.600000,+0.500000) | E | 0.7x0.25 | VDD | 5V_LDO_HOLD | (+33.600000,+61.600000) |
| 5 | (+0.600000,+0.000000) | E | 0.7x0.25 | CT | AUDIO_CT | (+33.600000,+61.100000) |
| 6 | (+0.600000,-0.500000) | E | 0.7x0.25 | RESET_N | AUDIO_EN | (+33.600000,+60.600000) |
