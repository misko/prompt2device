# pin dossier: U_OE  (74LVC1G14GV,125)

- footprint: Package_TO_SOT_SMD:SOT-23-5
- board position: (149.000000, 65.500000) rot 0.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/74LVC1G14GV,125/74LVC1G14_Rev19.pdf
- part.yaml verification note: CITED: Nexperia Rev19 p1 arbitrary input slew and partial-power operation; p3 exact SOT753 pinout; p5 1uA input /2uA Ioff and 100uA VOH/VOL limits across -40..125C. Source-only design selection; physical tests OWED.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-1.137500,-0.950000) | W | 1.32x0.6 | NC | unconnected-(U_OE-NC-Pad1) | (+147.862500,+64.550000) |
| 2 | (-1.137500,+0.000000) | W | 1.32x0.6 | A | TDM_SENSE_G | (+147.862500,+65.500000) |
| 3 | (-1.137500,+0.950000) | W | 1.32x0.6 | GND | GND | (+147.862500,+66.450000) |
| 4 | (+1.137500,+0.950000) | E | 1.32x0.6 | Y | TDM_OE_N | (+150.137500,+66.450000) |
| 5 | (+1.137500,-0.950000) | E | 1.32x0.6 | VCC | 3V3_ADC | (+150.137500,+64.550000) |
