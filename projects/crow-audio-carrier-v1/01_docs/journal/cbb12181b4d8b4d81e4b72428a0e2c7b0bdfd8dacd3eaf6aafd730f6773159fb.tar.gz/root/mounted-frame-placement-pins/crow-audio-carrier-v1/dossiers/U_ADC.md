# pin dossier: U_ADC  (CS5308P-DN)

- footprint: crow_audio_carrier:Cirrus_CS5308P_QFN48_6x6_P0.4_EP4.6
- board position: (96.000000, 70.000000) rot 0.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/CS5308P-DN/CS5308P_DS1314F1.pdf
- part.yaml verification note: CITED: Cirrus Logic DS1314F1 Figure 1-1 and Table 1-1, PDF pp.4-5, independently fix pins 1-48 and exposed paddle 49; re-read 2026-09-01.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-2.950000,-2.200000) | W | 0.8x0.2 | ADC_VMID1 | VMID1 | (+93.050000,+67.800000) |
| 2 | (-2.950000,-1.800000) | W | 0.8x0.2 | CONFIG1 | CFG1 | (+93.050000,+68.200000) |
| 3 | (-2.950000,-1.400000) | W | 0.8x0.2 | CONFIG2/HGC_SCK | CFG2 | (+93.050000,+68.600000) |
| 4 | (-2.950000,-1.000000) | W | 0.8x0.2 | CONFIG3/HGC_SDO | GND | (+93.050000,+69.000000) |
| 5 | (-2.950000,-0.600000) | W | 0.8x0.2 | VDD_A1 | 3V3_ADC | (+93.050000,+69.400000) |
| 6 | (-2.950000,-0.200000) | W | 0.8x0.2 | GND_A | GND | (+93.050000,+69.800000) |
| 7 | (-2.950000,+0.200000) | W | 0.8x0.2 | LDO_A_FILT | LDO_A_FILT | (+93.050000,+70.200000) |
| 8 | (-2.950000,+0.600000) | W | 0.8x0.2 | GND_A | GND | (+93.050000,+70.600000) |
| 9 | (-2.950000,+1.000000) | W | 0.8x0.2 | VDD_A2 | 3V3_ADC | (+93.050000,+71.000000) |
| 10 | (-2.950000,+1.400000) | W | 0.8x0.2 | CONFIG4/HGC_CS | CFG4 | (+93.050000,+71.400000) |
| 11 | (-2.950000,+1.800000) | W | 0.8x0.2 | CONFIG5 | CFG5 | (+93.050000,+71.800000) |
| 12 | (-2.950000,+2.200000) | W | 0.8x0.2 | ADC_VMID2 | VMID2 | (+93.050000,+72.200000) |
| 13 | (-2.200000,+2.950000) | S | 0.2x0.8 | IN5N | ADC5N | (+93.800000,+72.950000) |
| 14 | (-1.800000,+2.950000) | S | 0.2x0.8 | IN5P | ADC5P | (+94.200000,+72.950000) |
| 15 | (-1.400000,+2.950000) | S | 0.2x0.8 | IN6N | ADC6N | (+94.600000,+72.950000) |
| 16 | (-1.000000,+2.950000) | S | 0.2x0.8 | IN6P | ADC6P | (+95.000000,+72.950000) |
| 17 | (-0.600000,+2.950000) | S | 0.2x0.8 | ADC_FILT2N | GND | (+95.400000,+72.950000) |
| 18 | (-0.200000,+2.950000) | S | 0.2x0.8 | ADC_FILT2P | FILT2P | (+95.800000,+72.950000) |
| 19 | (+0.200000,+2.950000) | S | 0.2x0.8 | IN7N | ADC7N | (+96.200000,+72.950000) |
| 20 | (+0.600000,+2.950000) | S | 0.2x0.8 | IN7P | ADC7P | (+96.600000,+72.950000) |
| 21 | (+1.000000,+2.950000) | S | 0.2x0.8 | IN8N | ADC8N | (+97.000000,+72.950000) |
| 22 | (+1.400000,+2.950000) | S | 0.2x0.8 | IN8P | ADC8P | (+97.400000,+72.950000) |
| 23 | (+1.800000,+2.950000) | S | 0.2x0.8 | RESET | ADC_RESET_N | (+97.800000,+72.950000) |
| 24 | (+2.200000,+2.950000) | S | 0.2x0.8 | ASP_FSYNC | ADC_FSYNC | (+98.200000,+72.950000) |
| 25 | (+2.950000,+2.200000) | E | 0.8x0.2 | ASP_DOUT1 | TDM_RAW | (+98.950000,+72.200000) |
| 26 | (+2.950000,+1.800000) | E | 0.8x0.2 | ASP_DOUT2 | unconnected-(U_ADC-ASP_DOUT2_NC-Pad26) | (+98.950000,+71.800000) |
| 27 | (+2.950000,+1.400000) | E | 0.8x0.2 | ASP_DOUT3 | unconnected-(U_ADC-ASP_DOUT3_NC-Pad27) | (+98.950000,+71.400000) |
| 28 | (+2.950000,+1.000000) | E | 0.8x0.2 | ASP_DOUT4 | unconnected-(U_ADC-ASP_DOUT4_NC-Pad28) | (+98.950000,+71.000000) |
| 29 | (+2.950000,+0.600000) | E | 0.8x0.2 | ASP_BCLK | ADC_BCLK | (+98.950000,+70.600000) |
| 30 | (+2.950000,+0.200000) | E | 0.8x0.2 | GND_D | GND | (+98.950000,+70.200000) |
| 31 | (+2.950000,-0.200000) | E | 0.8x0.2 | VDD_IO | 3V3_ADC | (+98.950000,+69.800000) |
| 32 | (+2.950000,-0.600000) | E | 0.8x0.2 | LDO_D_FILT | LDO_D_FILT | (+98.950000,+69.400000) |
| 33 | (+2.950000,-1.000000) | E | 0.8x0.2 | VDD_D | LDO_D_FILT | (+98.950000,+69.000000) |
| 34 | (+2.950000,-1.400000) | E | 0.8x0.2 | MCLK | ADC_MCLK | (+98.950000,+68.600000) |
| 35 | (+2.950000,-1.800000) | E | 0.8x0.2 | SPI_SDO/I2C_SCL | GND | (+98.950000,+68.200000) |
| 36 | (+2.950000,-2.200000) | E | 0.8x0.2 | SPI_SCK | GND | (+98.950000,+67.800000) |
| 37 | (+2.200000,-2.950000) | N | 0.2x0.8 | SPI_SDI/I2C_SDA | GND | (+98.200000,+67.050000) |
| 38 | (+1.800000,-2.950000) | N | 0.2x0.8 | SPI_CS | 3V3_ADC | (+97.800000,+67.050000) |
| 39 | (+1.400000,-2.950000) | N | 0.2x0.8 | IN1N | ADC4N | (+97.400000,+67.050000) |
| 40 | (+1.000000,-2.950000) | N | 0.2x0.8 | IN1P | ADC4P | (+97.000000,+67.050000) |
| 41 | (+0.600000,-2.950000) | N | 0.2x0.8 | IN2N | ADC3N | (+96.600000,+67.050000) |
| 42 | (+0.200000,-2.950000) | N | 0.2x0.8 | IN2P | ADC3P | (+96.200000,+67.050000) |
| 43 | (-0.200000,-2.950000) | N | 0.2x0.8 | ADC_FILT1P | FILT1P | (+95.800000,+67.050000) |
| 44 | (-0.600000,-2.950000) | N | 0.2x0.8 | ADC_FILT1N | GND | (+95.400000,+67.050000) |
| 45 | (-1.000000,-2.950000) | N | 0.2x0.8 | IN3N | ADC2N | (+95.000000,+67.050000) |
| 46 | (-1.400000,-2.950000) | N | 0.2x0.8 | IN3P | ADC2P | (+94.600000,+67.050000) |
| 47 | (-1.800000,-2.950000) | N | 0.2x0.8 | IN4N | ADC1N | (+94.200000,+67.050000) |
| 48 | (-2.200000,-2.950000) | N | 0.2x0.8 | IN4P | ADC1P | (+93.800000,+67.050000) |
| 49 | (+0.000000,+0.000000) | center | 4.6x4.6 | EP | GND | (+96.000000,+70.000000) |

(9 unnumbered paste/mechanical pads not shown)
