# pin dossier: U_TDM_SCH  (74LVC1G17GV,125)

- footprint: Package_TO_SOT_SMD:SOT-23-5
- board position: (147.500000, 52.000000) rot 0.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/74LVC1G17GV,125/74LVC1G17.pdf
- part.yaml verification note: CITED: exact local Rev16 p3 GV/SOT753 figure aaa-035749 and Table3 visually reopened2026-09-08:1NC,2A,3GND,4Y,5VCC. p4Table4 L-to-L/H-to-H; p1 unlimited input rise/fall; p5-6 full-temperature static limits and discrete thresholds; p8-9 timing test conditions. Physical source acceptance remains owed.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-1.137500,-0.950000) | W | 1.32x0.6 | NC | unconnected-(U_TDM_SCH-NC-Pad1) | (+146.362500,+51.050000) |
| 2 | (-1.137500,+0.000000) | W | 1.32x0.6 | A | TDM_RAW | (+146.362500,+52.000000) |
| 3 | (-1.137500,+0.950000) | W | 1.32x0.6 | GND | GND | (+146.362500,+52.950000) |
| 4 | (+1.137500,+0.950000) | E | 1.32x0.6 | Y | TDM_CLEAN | (+148.637500,+52.950000) |
| 5 | (+1.137500,-0.950000) | E | 1.32x0.6 | VCC | 3V3_ADC | (+148.637500,+51.050000) |
