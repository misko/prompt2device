# pin dossier: U_CLK  (SN74LVC3G34DCUR)

- footprint: Package_SO:VSSOP-8_2.3x2mm_P0.5mm
- board position: (147.000000, 59.000000) rot 0.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/SN74LVC3G34DCUR/SN74LVC3G34_SCES366L.pdf
- part.yaml verification note: CITED: TI SCES366L DCU top view and pin-functions table, PDF p.3, independently fix 1=1A, 2=3Y, 3=2A, 4=GND, 5=2Y, 6=3A, 7=1Y, 8=VCC; re-read 2026-09-01.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-1.400000,-0.750000) | W | 1.25x0.35 | 1A | MCH_MCLK | (+145.600000,+58.250000) |
| 2 | (-1.400000,-0.250000) | W | 1.25x0.35 | 3Y | FSYNC_BUF | (+145.600000,+58.750000) |
| 3 | (-1.400000,+0.250000) | W | 1.25x0.35 | 2A | MCH_BCLK | (+145.600000,+59.250000) |
| 4 | (-1.400000,+0.750000) | W | 1.25x0.35 | GND | GND | (+145.600000,+59.750000) |
| 5 | (+1.400000,+0.750000) | E | 1.25x0.35 | 2Y | BCLK_BUF | (+148.400000,+59.750000) |
| 6 | (+1.400000,+0.250000) | E | 1.25x0.35 | 3A | MCH_FSYNC | (+148.400000,+59.250000) |
| 7 | (+1.400000,-0.250000) | E | 1.25x0.35 | 1Y | MCLK_BUF | (+148.400000,+58.750000) |
| 8 | (+1.400000,-0.750000) | E | 1.25x0.35 | VCC | 3V3_ADC | (+148.400000,+58.250000) |
