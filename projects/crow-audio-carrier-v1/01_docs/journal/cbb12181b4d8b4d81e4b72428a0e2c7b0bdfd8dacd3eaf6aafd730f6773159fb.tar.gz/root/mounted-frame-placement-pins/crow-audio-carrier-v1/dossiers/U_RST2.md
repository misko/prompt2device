# pin dossier: U_RST2  (SN74LVC1G123DCTR)

- footprint: Package_SO:SSOP-8_2.95x2.8mm_P0.65mm
- board position: (118.000000, 72.000000) rot 0.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/SN74LVC1G123DCTR/SN74LVC1G123_SCES586E.pdf
- part.yaml verification note: CITED: TI SCES586E Figure 4-1 and Table 4-1, PDF p.3, independently fix DCT pins 1=A, 2=B, 3=CLR, 4=GND, 5=Q, 6=Cext, 7=Rext/Cext, 8=VCC; re-read 2026-09-01.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-1.700000,-0.975000) | W | 0.3x1.6 | A | GND | (+116.300000,+71.025000) |
| 2 | (-1.700000,-0.325000) | W | 0.3x1.6 | B | 3V3_ADC | (+116.300000,+71.675000) |
| 3 | (-1.700000,+0.325000) | W | 0.3x1.6 | CLR# | POR_N | (+116.300000,+72.325000) |
| 4 | (-1.700000,+0.975000) | W | 0.3x1.6 | GND | GND | (+116.300000,+72.975000) |
| 5 | (+1.700000,+0.975000) | E | 0.3x1.6 | Q | RESET_PULSE_H | (+119.700000,+72.975000) |
| 6 | (+1.700000,+0.325000) | E | 0.3x1.6 | Cext | RESET_C | (+119.700000,+72.325000) |
| 7 | (+1.700000,-0.325000) | E | 0.3x1.6 | Rext/Cext | RESET_RC | (+119.700000,+71.675000) |
| 8 | (+1.700000,-0.975000) | E | 0.3x1.6 | VCC | 3V3_ADC | (+119.700000,+71.025000) |
