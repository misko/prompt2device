# pin dossier: U_ESD3  (TPD2E2U06DRLR)

- footprint: Package_TO_SOT_SMD:SOT-553
- board position: (103.570000, 27.860000) rot 0.000000 degrees (native KiCad)
- mounted side: back (B.Cu)
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/TPD2E2U06DRLR/TPD2E2U06_SLLSEG9C.pdf
- part.yaml verification note: CITED: TI SLLSEG9C DRL top view and Pin Functions table, PDF p.3, independently fix 1=NC, 2=NC, 3=IO1, 4=GND, 5=IO2; electrical/ESD tables PDF pp.3-5 fix the stated limits; re-read 2026-09-01.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Back mount: native KiCad relative coordinates are reflected y -> -y after undoing rotation.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-0.712500,-0.500000) | W | 0.68x0.35 | NC | unconnected-(U_ESD3-NC1-Pad1) | (+102.857500,+28.360000) |
| 2 | (-0.712500,+0.000000) | W | 0.68x0.35 | NC | unconnected-(U_ESD3-NC2-Pad2) | (+102.857500,+27.860000) |
| 3 | (-0.712500,+0.500000) | W | 0.68x0.35 | IO1 | AUDIO_P3 | (+102.857500,+27.360000) |
| 4 | (+0.712500,+0.500000) | E | 0.68x0.35 | GND | GND | (+104.282500,+27.360000) |
| 5 | (+0.712500,-0.500000) | E | 0.68x0.35 | IO2 | AUDIO_N3 | (+104.282500,+28.360000) |
