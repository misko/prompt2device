# pin dossier: D_HOLD  (B340A-13-F)

- footprint: Diode_SMD:D_SMA
- board position: (50.400000, 58.100000) rot 0.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/B340A-13-F/B340A_DS30891_Rev19-2.pdf
- part.yaml verification note: Primary exact ordering, pin assignment and electrical table reopened2026-09-07; catalog exact identity only, not allocation.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-2.000000,+0.000000) | W | 2.5x1.8 | K | 5V_LDO_FEED | (+48.400000,+58.100000) |
| 2 | (+2.000000,+0.000000) | E | 2.5x1.8 | A | 5V_BUCK | (+52.400000,+58.100000) |
