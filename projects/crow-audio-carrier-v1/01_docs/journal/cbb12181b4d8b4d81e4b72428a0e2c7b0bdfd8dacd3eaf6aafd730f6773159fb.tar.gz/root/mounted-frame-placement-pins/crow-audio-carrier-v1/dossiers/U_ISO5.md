# pin dossier: U_ISO5  (TMUX2821DSGR)

- footprint: crow_audio_carrier:TI_DSG0008A_Exact
- board position: (40.500000, 85.900000) rot 180.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/TMUX2821DSGR/TMUX28xx_SCDS488.pdf
- part.yaml verification note: Primary pin-function table and exact orderable suffix; package land drawing visually inspected2026-09-07. See ADR0009 for modeled versus measured distinction.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-0.950000,-0.750000) | W | 0.5x0.25 | S1 | FILTER5P | (+41.450000,+86.650000) |
| 2 | (-0.950000,-0.250000) | W | 0.5x0.25 | D1 | ADC5P | (+41.450000,+86.150000) |
| 3 | (-0.950000,+0.250000) | W | 0.5x0.25 | SEL2 | AUDIO_EN | (+41.450000,+85.650000) |
| 4 | (-0.950000,+0.750000) | W | 0.5x0.25 | GND | GND | (+41.450000,+85.150000) |
| 5 | (+0.950000,+0.750000) | E | 0.5x0.25 | S2 | FILTER5N | (+39.550000,+85.150000) |
| 6 | (+0.950000,+0.250000) | E | 0.5x0.25 | D2 | ADC5N | (+39.550000,+85.650000) |
| 7 | (+0.950000,-0.250000) | E | 0.5x0.25 | SEL1 | AUDIO_EN | (+39.550000,+86.150000) |
| 8 | (+0.950000,-0.750000) | E | 0.5x0.25 | VDD | 5V_LDO_HOLD | (+39.550000,+86.650000) |
| 9 | (+0.000000,+0.000000) | center | 0.9x1.6 | GND | GND | (+40.500000,+85.900000) |

(2 unnumbered paste/mechanical pads not shown)
