# pin dossier: Q_PRE  (AO3401A)

- footprint: Package_TO_SOT_SMD:SOT-23
- board position: (44.020000, 58.100000) rot 180.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/AO3401A/AO3401A_Rev3.1.pdf
- part.yaml verification note: AO3401A Rev3.1 page1 SOT23 Top View/Bottom View drawings: marked gate-side lead=G1, other paired lead=S2, single opposite lead=D3; page2 Electrical Characteristics table. Reopened exact retained PDF2026-09-10; pin/value mapping unchanged. Catalog identity is not allocation.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-0.937500,-0.950000) | N | 1.48x0.6 | G | PRE_GATE | (+44.957500,+59.050000) |
| 2 | (-0.937500,+0.950000) | S | 1.48x0.6 | S | 5V_LDO_FEED | (+44.957500,+57.150000) |
| 3 | (+0.937500,+0.000000) | E | 1.48x0.6 | D | 5V_LDO_HOLD | (+43.082500,+58.100000) |
