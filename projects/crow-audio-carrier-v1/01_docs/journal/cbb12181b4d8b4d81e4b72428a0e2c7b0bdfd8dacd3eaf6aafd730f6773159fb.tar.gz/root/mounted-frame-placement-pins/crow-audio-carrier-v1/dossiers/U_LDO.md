# pin dossier: U_LDO  (LT3041ADE#TRPBF)

- footprint: Package_DFN_QFN:DFN-14-1EP_3x4mm_P0.5mm_EP1.7x3.3mm
- board position: (64.500000, 70.000000) rot 0.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/LT3041ADE-TRPBF/LT3041_RevA.pdf
- part.yaml verification note: Primary Rev.A pin table and package05-08-1708 inspected independently; standard KiCad pad1(-1.45,-1.5),14(1.45,-1.5), EP15(0,0),1.7x3.3mm match the rotated manufacturer land drawing. JLC model/rotation and new placement remain unreviewed.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-1.450000,-1.500000) | N | 0.7x0.25 | IN | 5V_LDO_HOLD | (+63.050000,+68.500000) |
| 2 | (-1.450000,-1.000000) | W | 0.7x0.25 | IN | 5V_LDO_HOLD | (+63.050000,+69.000000) |
| 3 | (-1.450000,-0.500000) | W | 0.7x0.25 | IN | 5V_LDO_HOLD | (+63.050000,+69.500000) |
| 4 | (-1.450000,+0.000000) | W | 0.7x0.25 | VIOC | unconnected-(U_LDO-VIOC_NC-Pad4) | (+63.050000,+70.000000) |
| 5 | (-1.450000,+0.500000) | W | 0.7x0.25 | EN_UV | LDO_EN | (+63.050000,+70.500000) |
| 6 | (-1.450000,+1.000000) | W | 0.7x0.25 | PG | unconnected-(U_LDO-PG_NC-Pad6) | (+63.050000,+71.000000) |
| 7 | (-1.450000,+1.500000) | S | 0.7x0.25 | ILIM | GND | (+63.050000,+71.500000) |
| 8 | (+1.450000,+1.500000) | S | 0.7x0.25 | PGFB | 5V_LDO_HOLD | (+65.950000,+71.500000) |
| 9 | (+1.450000,+1.000000) | E | 0.7x0.25 | SET | LDO_NR | (+65.950000,+71.000000) |
| 10 | (+1.450000,+0.500000) | E | 0.7x0.25 | GND | GND | (+65.950000,+70.500000) |
| 11 | (+1.450000,+0.000000) | E | 0.7x0.25 | GND | GND | (+65.950000,+70.000000) |
| 12 | (+1.450000,-0.500000) | E | 0.7x0.25 | OUTS | 3V3_ADC | (+65.950000,+69.500000) |
| 13 | (+1.450000,-1.000000) | E | 0.7x0.25 | OUT | 3V3_ADC | (+65.950000,+69.000000) |
| 14 | (+1.450000,-1.500000) | N | 0.7x0.25 | OUT | 3V3_ADC | (+65.950000,+68.500000) |
| 15 | (+0.000000,+0.000000) | center | 1.7x3.3 | GND | GND | (+64.500000,+70.000000) |

(8 unnumbered paste/mechanical pads not shown)
