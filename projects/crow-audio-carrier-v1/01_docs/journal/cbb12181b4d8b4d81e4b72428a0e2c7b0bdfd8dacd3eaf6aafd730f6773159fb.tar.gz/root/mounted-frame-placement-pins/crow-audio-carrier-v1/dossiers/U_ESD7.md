# pin dossier: U_ESD7  (TPD2E2U06DRLR)

- footprint: Package_TO_SOT_SMD:SOT-553
- board position: (105.430000, 112.140000) rot 180.000000 degrees (native KiCad)
- mounted side: back (B.Cu)
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/TPD2E2U06DRLR/TPD2E2U06_SLLSEG9C.pdf
- part.yaml verification note: CITED: TI SLLSEG9C DRL top view and Pin Functions table, PDF p.3, independently fix 1=NC, 2=NC, 3=IO1, 4=GND, 5=IO2; electrical/ESD tables PDF pp.3-5 fix the stated limits; re-read 2026-09-01.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Back mount: native KiCad relative coordinates are reflected y -> -y after undoing rotation.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-0.712500,-0.500000) | W | 0.68x0.35 | NC | unconnected-(U_ESD7-NC1-Pad1) | (+106.142500,+111.640000) |
| 2 | (-0.712500,+0.000000) | W | 0.68x0.35 | NC | unconnected-(U_ESD7-NC2-Pad2) | (+106.142500,+112.140000) |
| 3 | (-0.712500,+0.500000) | W | 0.68x0.35 | IO1 | AUDIO_P7 | (+106.142500,+112.640000) |
| 4 | (+0.712500,+0.500000) | E | 0.68x0.35 | GND | GND | (+104.717500,+112.640000) |
| 5 | (+0.712500,-0.500000) | E | 0.68x0.35 | IO2 | AUDIO_N7 | (+104.717500,+111.640000) |
