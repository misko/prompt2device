# pin dossier: C_HOLD1  (EEEFK1A471P)

- footprint: crow_audio_carrier:Panasonic_EEEFK1A471P_8x10.2_Exact
- board position: (59.000000, 83.900000) rot 0.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/EEEFK1A471P/Panasonic_FK_ABA0000C1181_20260210.pdf
- part.yaml verification note: CITED: official Panasonic FK catalog exact standard-product row EEEFK1A471P gives 470uF +/-20%, 10V, 8.0x10.2 mm size F, 47uA leakage, 160mohm maximum impedance and 600mArms ripple; standard land a=3.1, b=4.0, c=2.0 mm; reviewed 2026-09-01.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-3.550000,+0.000000) | W | 4.0x2.0 | POSITIVE | 5V_LDO_HOLD | (+55.450000,+83.900000) |
| 2 | (+3.550000,+0.000000) | E | 4.0x2.0 | NEGATIVE | GND | (+62.550000,+83.900000) |
