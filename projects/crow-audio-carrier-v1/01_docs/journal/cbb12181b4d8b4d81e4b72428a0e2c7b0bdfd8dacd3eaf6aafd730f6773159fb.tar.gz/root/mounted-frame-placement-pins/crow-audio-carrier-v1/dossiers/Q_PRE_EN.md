# pin dossier: Q_PRE_EN  (2N7002K-7)

- footprint: crow_audio_carrier:Diodes_2N7002K_SOT23_Exact
- board position: (39.860000, 57.900000) rot 0.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/2N7002K-7/2N7002K_DS30896_Rev20-2.pdf
- part.yaml verification note: CITED: Diodes DS30896 Rev. 20-2 pin configuration and equivalent-circuit top-view figures, PDF p.1, independently fix pin 1=G, pin 2=S, pin 3=D; re-read 2026-09-01.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-1.000000,-0.950000) | W | 0.9x0.8 | G | PWR_EN | (+38.860000,+56.950000) |
| 2 | (-1.000000,+0.950000) | W | 0.9x0.8 | S | GND | (+38.860000,+58.850000) |
| 3 | (+1.000000,+0.000000) | E | 0.9x0.8 | D | PRE_GATE | (+40.860000,+57.900000) |
