# pin dossier: U_BUCK  (AP63205WU-7)

- footprint: Package_TO_SOT_SMD:TSOT-23-6
- board position: (42.000000, 66.000000) rot 0.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/AP63205WU-7/AP63205_DS41326_Rev3-2.pdf
- part.yaml verification note: CITED: Diodes DS41326 Rev. 3-2 Pin Descriptions, PDF p.2, fix 1=FB, 2=EN, 3=VIN, 4=GND, 5=SW, 6=BST; Table 3, Section 10, and ordering table, PDF pp.12-16, fix the 5V network, inductor constraints, and AP63205WU-7 identity; re-read 2026-09-01.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-1.137500,-0.950000) | W | 1.32x0.6 | FB | 5V_BUCK | (+40.862500,+65.050000) |
| 2 | (-1.137500,+0.000000) | W | 1.32x0.6 | EN | 12V_BUCK_IN | (+40.862500,+66.000000) |
| 3 | (-1.137500,+0.950000) | W | 1.32x0.6 | VIN | 12V_BUCK_IN | (+40.862500,+66.950000) |
| 4 | (+1.137500,+0.950000) | E | 1.32x0.6 | GND | GND | (+43.137500,+66.950000) |
| 5 | (+1.137500,+0.000000) | E | 1.32x0.6 | SW | BUCK_SW | (+43.137500,+66.000000) |
| 6 | (+1.137500,-0.950000) | E | 1.32x0.6 | BST | BUCK_BST | (+43.137500,+65.050000) |
