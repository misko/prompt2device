# pin dossier: Q_IN  (DMP6023LFG-13)

- footprint: Package_SON:Diodes_PowerDI3333-8
- board position: (40.000000, 74.800000) rot 0.000000 degrees (native KiCad)
- mounted side: front (F.Cu)
- computed winding of pins 1..N: **n/a (collinear perimeter pins)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/DMP6023LFG-13/DMP6023LFG_DS37204_Rev2-2.pdf
- part.yaml verification note: CITED: Diodes DS37204 Rev. 2-2 bottom/top-view pin drawing and ordering table, PDF p.1, fix pins 1-3=source, pin 4=gate, pins 5-8=common drain and the -13 suffix; the Maximum Ratings and Electrical Characteristics tables, PDF p.2, fix -60V VDS, +/-20V VGS, -6.2A at 70C and 25mOhm maximum at VGS=-10V. Extraction correction 2026-09-07: all eight physical identities retained, with explicit cited aliases for the manufacturer-fused drain positions; primary PDF revision/bytes unchanged.

Local coordinates are COMPONENT-TOP mm: looking at the component from its mounted side,
with board translation and rotation undone; +x is RIGHT, +y is DOWN.
Front mount: native KiCad relative coordinates need no reflection.
Winding and N/S/E/W sides use this component-top frame; compare a manufacturer TOP VIEW by rotation only.
The native board coordinates retain the board-front projection, +x right/+y down, without any transform.
Frame conversion does not validate the footprint or electrical connections.

| pad | local (x,y) | side | size | function (part.yaml) | NET on board | native board (x,y) |
|---|---|---|---|---|---|---|
| 1 | (-1.500000,-0.975000) | W | 0.7x0.42 | SOURCE | 12V_PROTECTED | (+38.500000,+73.825000) |
| 2 | (-1.500000,-0.325000) | W | 0.7x0.42 | SOURCE | 12V_PROTECTED | (+38.500000,+74.475000) |
| 3 | (-1.500000,+0.325000) | W | 0.7x0.42 | SOURCE | 12V_PROTECTED | (+38.500000,+75.125000) |
| 4 | (-1.500000,+0.975000) | W | 0.7x0.42 | GATE | Q_IN_GATE | (+38.500000,+75.775000) |
| 5 | (+0.455000,+0.000000) | E | 1.71x2.37 | DRAIN_COMMON | 12V_FUSED | (+40.455000,+74.800000) |

Declared pin aliases (review these against the manufacturer drawing):
- `6`: schematic `5`, footprint `5`, fused: `true`; why: Manufacturer drain positions 5-8 share the exposed drain leadframe; the source symbol and exact KiCad composite drain land use identity 5.; evidence: Diodes DS37204 Rev.2-2 p.1 bottom-view package figure and equivalent circuit; p.5 package/land drawing; Package_SON:Diodes_PowerDI3333-8 composite pad 5 includes all four drain fingers.
- `7`: schematic `5`, footprint `5`, fused: `true`; why: Manufacturer drain positions 5-8 share the exposed drain leadframe; the source symbol and exact KiCad composite drain land use identity 5.; evidence: Diodes DS37204 Rev.2-2 p.1 bottom-view package figure and equivalent circuit; p.5 package/land drawing; Package_SON:Diodes_PowerDI3333-8 composite pad 5 includes all four drain fingers.
- `8`: schematic `5`, footprint `5`, fused: `true`; why: Manufacturer drain positions 5-8 share the exposed drain leadframe; the source symbol and exact KiCad composite drain land use identity 5.; evidence: Diodes DS37204 Rev.2-2 p.1 bottom-view package figure and equivalent circuit; p.5 package/land drawing; Package_SON:Diodes_PowerDI3333-8 composite pad 5 includes all four drain fingers.

(8 unnumbered paste/mechanical pads not shown)
