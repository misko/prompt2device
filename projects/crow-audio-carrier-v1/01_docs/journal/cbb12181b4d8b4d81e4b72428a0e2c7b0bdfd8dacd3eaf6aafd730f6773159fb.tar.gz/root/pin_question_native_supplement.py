from pathlib import Path
import json,hashlib,sys
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'));import pin_audit,pcbnew
P=R/'projects/crow-audio-carrier-v1';bp=next((P/'04_kicad').glob('*.kicad_pcb'));before=bp.read_bytes();b=pcbnew.LoadBoard(str(bp));fp=next(f for f in b.GetFootprints() if f.GetReference()=='J9')
result={'board_sha256':hashlib.sha256(before).hexdigest(),'ref':'J9','side':str(b.GetLayerName(fp.GetLayer())),'rotation':fp.GetOrientationDegrees(),'frame':'Approved pin_audit.local_pads component-top, all native pads including empty-number mechanical pad. Raw extraction only; no expected orientation judgment.','extractor_sha256':hashlib.sha256((R/'skills/kicad-pcb/scripts/pin_audit.py').read_bytes()).hexdigest(),'pads':pin_audit.local_pads(fp)}
assert bp.read_bytes()==before
out=N/'pin-question-supplement';out.mkdir(exist_ok=True);p=out/'J9-all-native-pads.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'pads':len(result['pads'])}))
