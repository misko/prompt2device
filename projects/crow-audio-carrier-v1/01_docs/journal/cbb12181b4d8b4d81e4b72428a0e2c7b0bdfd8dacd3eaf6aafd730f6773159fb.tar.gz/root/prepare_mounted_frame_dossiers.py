from pathlib import Path
import json,hashlib,sys,shutil,os
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911')
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
assert hashlib.sha256((R/'skills/kicad-pcb/scripts/pin_audit.py').read_bytes()).hexdigest()=='af0520dc3e4e77da123c4627174df57ae54230c0b96d2e712965080b56995cd7'
out=N/'mounted-frame-placement-pins';out.mkdir(exist_ok=False)
proof=[]
for short,slug,expected,circuitsha in [('carrier','crow-audio-carrier-v1',61,'a3fdcd5dbad16cbbd8873cee3c501e5a855f06268ca9628bc999daf9c8f20e37'),('pod','crow-mic-pod-v3',6,'5af679860d64eb6fb79575b8f088a49a59efcfef8c157d645a5513f6b2185b68')]:
 p=R/'projects'/slug;assert hashlib.sha256((p/'03_tscircuit/build/circuit.json').read_bytes()).hexdigest()==circuitsha,'Regenerate BOM from changed CircuitJSON instead'
 target=out/slug;target.mkdir();shutil.copy2(N/'approved-placement-pins'/slug/'pin-bom.csv',target/'pin-bom.csv')
 board=next((p/'04_kicad').glob('*.kicad_pcb'));before=board.read_bytes()
 for kind in ['pin','critical-pin']:
  old=json.loads((I/(short+'-approved-'+kind+'-dossiers-command.json')).read_text());argv=[x.replace(str(N/'approved-placement-pins'),str(out)) for x in old['argv']]
  label=short+'-mounted-frame-'+kind+'-dossiers'
  (I/(label+'-command.json')).write_text(json.dumps({'argv':argv,'cwd':str(R)},indent=2)+'\n')
  result=run_stage({'id':label,'work_class':'local','timeout_s':120},argv,cwd=R,log_path=I/(label+'.log'),env={'PATH':os.environ['PATH'],'HOME':os.environ['HOME'],'LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'},console_line_limit=4,console_tail_lines=3)
  (I/(label+'-runtime.json')).write_text(json.dumps(result.to_mapping(),indent=2)+'\n')
  assert result.status=='PASS',(label,result.to_mapping())
 assert board.read_bytes()==before
 fs=sorted((target/'dossiers').glob('*.md'));assert len(fs)==expected,(slug,len(fs))
 proof.append({'project':slug,'board_sha256':hashlib.sha256(before).hexdigest(),'circuit_json_sha256':circuitsha,'dossiers':[{'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in fs]})
(out/'generation-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'groups':len(proof),'dossiers':sum(len(x['dossiers']) for x in proof)}))
