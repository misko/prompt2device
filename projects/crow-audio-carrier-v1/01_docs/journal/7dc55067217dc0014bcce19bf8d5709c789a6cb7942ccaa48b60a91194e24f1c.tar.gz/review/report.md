# Focused orientation-view D-BACK

**Domain result: EVIDENCE_OWNER_CORRECTION_REQUIRED. Delivery: complete honest review.** The current machine 9/9 PASS is reproducible. Current J1/J5 mandatory inside images do not show their targets' rear faces sufficiently for human orientation approval. This is an evidence/camera problem; it does not establish a wrong connector placement. No human approval, routing, release, order, clearance, service, or physical qualification is granted.

## Exact bindings and method

All 665 frozen inputs match envelope canonical SHA `94fcc5b110d40a3f059ce6e197312b53b2bd58a234bee77e9acfab303a103b3a`. All 11 present view hashes match the receipt. Board SHA is `9c30a147b2d94babd98bc2af4150d4e87270d2efb81a8bd39e88f1b9529a99f4`; orientation semantic subject is `da8a0198f5bcb822ce7e94760fedd1cefb6eabd5f010ea765ebe29c7dc8e3112`. Config, floorplan, native model identities/transforms, renderer/tool identity and all nine recorded measurements were recomputed from the frozen board and match exactly. This reproduction uses the owning functions and is not claimed as an independent geometry checker. Independent judgment below uses all 11 actual images, board coordinates, depth order, and distinguishable model mouth/rear features. The supplied native registration aggregate says 6/6 PASS and binds this board/config; registration was not rerun.

Board outline is X20–170, Y20–120 mm. J1–J4 origins are X36/68/100/132, Y25.86, rotation0; J5–J8 are X45/77/109/141, Y114.14, rotation180. J9 is (28,69), rotation90. All nine have native offset/rotation (0,0,0), unit scale, front mounting; footprint rotation supplies the board direction. RJ45 native SHA `3f902b89d4bd756b121be056782deff312efb127c9c48f2c798ebd6db0e59f49`; J9 native SHA `301488732bd715060f80583e9cc8936bbbbd584dbe14055705d89d0d37442ffb`. J9 is a source-owned conservative model, not manufacturer CAD.

## All 11 views

| View | Physical object and assessment |
|---|---|
| J1_top | J1, correct north-edge footprint box and north arrow; roof visible. |
| J1_outside, back | Central mouth is J1; J2 partly at left. Cavity, contacts and latch opening visible. |
| J1_inside, front | Central mouth is **J5**, J6 at right. J1's rear is behind the south row. Required rear evidence is unjudgeable. |
| J5_top | J5, correct south-edge footprint box and south arrow; roof visible. |
| J5_outside, front | Central mouth is J5; J6 at right. Cavity and contacts visible. |
| J5_inside, back | Central mouth is **J1**, J2 at left. J5's rear is behind the north row. Required rear evidence is unjudgeable. |
| J9_top | Correct west-edge dark housing and top latch, arrow west. Arrow obscures some surface. |
| J9_outside, left | J9's two cavities, two contacts and latch silhouette identifiable; only about100 px wide and low contrast. |
| J9_inside, right | J9's solid rear and latch outline identifiable; no two-cavity opening. Small and dark. |
| J9_profile_a, front | J9 is the low black silhouette left of the large J5 mouth. J9 latch/side remains visible; adjacent RJ45 does not cover its main silhouette. |
| J9_profile_b, back | J9 is the low black silhouette right of the large J1 mouth. Main silhouette remains visible. |

Thus the initial blanket suggestion that intervening RJ45 housings make J9 profiles unjudgeable is not supported. Target attribution and readable inspection are needed; the larger RJ45 is not J9. None of these observations is explicit human acceptance of keying or cable use.

## Why the RJ45 inside identity is wrong in the pixels

The front camera looks north from the south cable edge; the back camera looks south from the north cable edge. Labels and intended mapping are correct. Cardinal side projection retains X and height, but removes north–south depth. J1 footprint interval is [30.895,48.245] mm; J5 is [32.755,50.105] mm. Their projected intervals overlap15.49 mm of17.35 mm (89.28%), while their origin depths differ88.28 mm. This is footprint-projection overlap, **not** a model occlusion percentage or pixel-derived body bbox.

The frozen front/back board strip spans X419–1963 px at board row777. J1's front window is [531,574,710,980] px; J5's front window is [550,574,729,980]. Their image differences are mostly a19 px horizontal crop shift plus labels. The back windows are similarly [1672,574,1851,980] and [1653,574,1832,980]. At front, nearer J5 shows the characteristic RJ45 cavity/contacts while masking J1 rear; at back, nearer J1 masks J5. A calibration or camera-name correction cannot recover depth lost by this projection. Top boxes do correctly identify their individual references.

## Bounded native diagnostics and limitation

Exactly two native images were produced from the byte-identical frozen board, with models unchanged, using `pipeline_runtime.run_stage`, explicit cwd/environment and120 s per command. Both used `kicad-cli pcb render --side top`, orthographic default, 2400×1600 requested (2384×1568 actual), quality high, opaque background and lights top0.8/bottom0.2/side0.6/camera0.8:

- `--rotate 60,0,0`: camera above the north side; J5 rear row separates from J1 mouth row. J5 upper rear shield is visible; nearby C_A5N/P bodies cover lower rear portions.
- `--rotate 300,0,0` (equivalent to −60° X): camera above the south side; J1 rear row separates from J5 mouth row. J1 upper rear shield is visible; nearby C_A1P/N bodies cover lower rear portions.

The negative-angle spelling was rejected by the CLI parser before rendering; its log is retained. Representing the same planned angle as300° produced the second image. No third native image or angle search occurred. Both diagnostics and commands/elapsed times/hashes are archived. They are not inserted into the current receipt or approved.

All J1–J9 and tall local film-capacitor models resolve and match. Twenty other `${KICAD10_3DMODEL_DIR}` references do not resolve through the inherited environment. All20 files exist and were hashed at `~/.local/share/kicad/10.0/3dmodels`; the existing `model_coverage_check.kicad_env()` synthesizes this fallback in Python. The native CLI was not passed that table, the system3dmodels directory is absent, and KiCad10 config has no explicit variable. **A Python coverage pass does not establish that the renderer selected the same files.** This review does not claim definite omission of all20 or complete-scene visibility.

The decisive remaining property is whether the intended rear face is sufficiently visible with every source model actually loaded, including the local film capacitors. The two diagnostics establish a useful existing camera route, but do not close that property. Stop rendering here.

## Minimum owning correction

The existing native CLI can produce useful elevated views; the present orientation gate has no admissible alternate-inside recipe or receipt path. Manual replacement of PNGs cannot supply a trustworthy accepted receipt.

Change the evidence owner `skills/jlcpcb-fab/scripts/connector_orientation_gate.py` and its connector-orientation procedure, not placement/native geometry:

1. Reuse the existing coverage substitution table and pass it explicitly to native rendering. Bind the actual native scene dependency hashes; fail complete-scene evidence if any required body cannot be resolved. Do not start a new model framework or broad registration exercise.
2. Add a deterministic elevated-inside recipe for the opposing rows. The measured candidates are J1 top/300,0,0 and J5 top/60,0,0. Keep full-board context and clearly identify the intended leftmost north/south target using exact coordinates. A focused oblique crop needs its own validated projection; do not feed it to the cardinal board-strip crop function. Preserve all parts. Confirm the target rear is actually judgeable with complete native loading before accepting the images.
3. Keep mandatory top/outside/inside for J1, J5 and J9; retain9/9 machine denominator. J9 needs readable target inspection, not a waiver based on the adjacent RJ45. Burn in true camera/rotation/projection, exact subject, target identity and renderer identity.
4. Regenerate the owning receipt, bump semantic-engine identity for camera semantics, and request fresh explicit human approval of all image hashes. The current schema1 approval path enforces full hash equality. The schema2 branch in `validate_approval` checks the key set but deliberately skips hash equality; it cannot provide the requested all-image-hash guarantee for replacements. Do not use semantic-only approval reuse for this correction.

Required regression properties: an opposite-facing overlapping-row fixture must expose that valid camera labels and9/9 machine geometry do not make the target rear visible; an accepted elevated fixture must establish target identity and rear visibility with bound complete native loading. Any mandatory image hash/key, camera recipe, native transform/model, denominator or semantic subject change must invalidate approval. Exercise both approval schemas rather than relying only on schema1. Preserve signed-Z native-side and physical mating-datum controls.

The five-file delivery has exact task-subject checks marked PASS because input verification, evidence delivery and this bounded review are complete. Engineering evidence correction and explicit human approval remain owed, as recorded in `evidence.domain_result`; they are not silently converted into delivery failures or human PASS.
