# Fresh isolated source handoff after independent return-scope D-BACK

Read current-handoff, decision/report.md and exact supported source boundary.
Root owns all live files. Author only scratch postimages; no board construction,
load/save/generation/fill/DRC/prep/router/native candidate, commit or live/frozen
write. Existing native4/4 remains closed; root may admit ONEcandidate5 only after
complete exact source preflight under the reviewed changed decision. No native6.

Prepare one coherent complete correction, bound to the independent decision:
1. Apply the exact independently reviewed2file shadow/census partial postimages
   from partial-proposal/after (stackup.yaml and test_route_source_contract.py).
   Preserve their complete hostile controls, exact identities and true original
   INCOMPLETE19/20 result as history. Do not call partial acceptance fullGREEN.
2. If and only if final decision supports the precise rectangle, change ONLY
   ADC_WEST_LOCAL.rect xmin89.5→89.35, retaining67.7/93.6/72.35, F.Cu/deny:[],
   existing permitted nets and width/clearance floors. Preserve the already
   independently adopted ADC2 polygon and every other floorplan field. No route,
   placement, pad, via, thermal, copper stack or other reservation changes.
3. Append explicit supported rationale to governing ADR0030 and the existing
   ADC_WEST_LOCAL width AND clearance rationales in rules/nets.yaml, as required
   by the final review. State both width AND paired-clearance geographic effect, current
   actual membership unchanged, whole-capsule requirement and new0.01mm source
   margin. Preserve all historical quantities and old text as context, no claim
   of native/thermal/return-cut/assembly/order qualification. At most5 coherent
   existing files unless exact decision requires otherwise; do not broaden scope.
4. Extend the same maintained route-contract test module with a complete pure
   source check of all sub0.30mm GND primitives against proper net/layer/width
   scopes and full capsule containment. Derive complete point-spec coverage; no
   hidden non-seed source omission. Preserve ordinary GND0.30,17current0.18 plus
   3current0.20 and exact current owner identities, not just a count that can be
   satisfied by unrelated copper. Retain original tests. Meaningful hostile
   controls must reject old scope, escaped round end, wrong net/layer permission,
   inappropriate width floor and empty/missing population where applicable.
   Do not grade only centers or accept native insideArea overlap as containment.
5. Show actual maintained regression RED against exact prior floorplan and
   GREEN proposed coherent afterimages; normal route-contract suite must now
   pass completely, including previously failing endpoint subtests and existing
   CHASSIS/ownership/reference/via controls. Run focused ADC feed/source/electrical
   invariant/thermal and safe ground-source tests on the composed floorplan to
   preserve the adopted ADC2 union and all32sourcefull-ground targets. Do not run
   BOARD-producing fixture tests or broad unrelated suites. Retain rawcommands,
   contexts, all setupFAILs and durations using shared runtime defaultconsole.

Full postimages under scratch/after/<repo-relative>, before/afterhashmanifest,
minimaldiff, exact changed-geometry and complete source-invariance proof. Include
independent decision identity, source guards/hostility and all actual scripts/logs
in the five-output archive. All frozenTSX imports/tools/partmetadata are supplied.
Explicit real R GIT_DIR may resolve immutable historical controls; record blobs.
No tool installs. If any prerequisite remains missing or a test fails, preserve
the complete defect and return INCOMPLETE; do not invent new native permission.
Root will reopen exact source preflight, then separately admit/bind the one
candidate and commission independent exact source/native acceptance before any
new geometry is live-adopted. Source handback is not that final acceptance.


Delivery mechanics: Allocated scratch: /tmp/rj45-final-return-scope-source1-yzp7k16j/06_build/task_runs/rj45-final-return-scope-source1/scratch . Final outputs: /tmp/rj45-final-return-scope-source1-yzp7k16j/06_build/task_runs/rj45-final-return-scope-source1/outputs . Root sole live writer. Frozen packet read-only; make working copies under the allocated scratch dir only. No live writes, commits, children, background processes, or source adoption. Verify every envelope input before/after. Use /usr/bin/python3 -B and shared pipeline_runtime.run_stage for finite direct-argv subprocesses, explicit cwd/environment, raw stdout/stderr/runtime retained under scratch. Shared runtime is at /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts. Images can be opened with view_image.

Work cutoff 2026-09-13T22:39:39.652810+00:00, hard 2026-09-13T22:46:39.652810+00:00, zero replacements. Stop engineering at work cutoff and return actual FINAL promptly. Preserve honest INCOMPLETE if coverage absent; delivery PASS means complete honest handback, never engineering acceptance. Outputs exactly report.md, evidence.json, evidence-manifest.json, evidence.tar.gz, result.json. evidence.json requires verdict SOUND|DEFECTIVE|INCOMPLETE and exact envelope subject, methods, findings and measured counts. Archive all actual methods/raw evidence/runtime; manifest archive_sha256/archive_size/member_count/members with path,size,sha256; reopen every regular member, no symlink/traversal/duplicate/recursive archive. result.json exact subject, checks inputs-verified/review-complete/evidence-complete PASS only when factually complete delivery; unresolved [] for delivered honest findings. Use preflight.py with exact envelope after packaging to validate delivery. Final response gives domain verdict and unresolved findings, exact report and archive.
