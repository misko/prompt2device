"""Copy a source workspace only. No admission, final manifest or PCB producer."""
from pathlib import Path
import datetime,hashlib,json,shutil,tempfile
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
N=Path(__file__).parent
S=Path(tempfile.mkdtemp(prefix='crow-adc2-native5-preparation-'))
W=S/'work';P=W/'projects/crow-audio-carrier-v1';live=R/'projects/crow-audio-carrier-v1'
def ignored(path,names):
    return [n for n in names if n in ['__pycache__','node_modules','.git'] or n.endswith('.pyc')
            or (Path(path).name=='journal' and n.endswith('.tar.gz'))]
for rel in ['01_docs','02_parts','03_src','08_reviews','03_tscircuit/src','03_tscircuit/kicad','06_build/netlists']:
    shutil.copytree(live/rel,P/rel,ignore=ignored)
for skill in ['kicad-pcb','pcb-design','jlcpcb-fab']:
    shutil.copytree(R/'skills'/skill,W/'skills'/skill,ignore=ignored)
shutil.copytree(R/'projects/crow-roof-array-v1/03_src',W/'projects/crow-roof-array-v1/03_src',ignore=ignored)
(P/'04_kicad').mkdir(parents=True)
prior=S/'predecessor';prior.mkdir()
for f in (live/'04_kicad').iterdir():
    if f.is_file():
        target=prior/f.name if f.suffix=='.kicad_pcb' else P/'04_kicad'/f.name
        shutil.copy2(f,target)
(S/'methods').mkdir()
origin=Path('/tmp/rj45-coherent-top-only-source1-dz0edoky/06_build/task_runs/rj45-coherent-top-only-source1/scratch/methods')
for name in ['fill.py','native_returns.py','native_source_binding.py']:
    shutil.copy2(origin/name,S/'methods'/name)
shutil.copy2(N/'candidate5_native_driver_draft.py',S/'methods/native_driver.py')
assert not (P/'04_kicad/crow_audio_carrier_v1.kicad_pcb').exists()
assert not (P/'06_build/route/r0.kicad_pcb').exists()
assert not (S/'admission.json').exists()
assert not (S/'input-manifest.json').exists()
record={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'workspace':str(S),'work':str(W),'project':str(P),
        'scope':'Preparatory copied source/tools and separately labeled prior PCB only. Native4/4 remains closed; no admission, final input manifest, source overlay beyond currently adopted ADC2, or native generation.',
        'native_generated':0,'future_required':'Independent return-width reassessment, coherent exact source handback/preflight and explicit root cumulative admission before any producer.',
        'excluded':'Disposable build stages except canonical netlists; journal archives already preserved in live immutable content-addressed evidence home; node_modules/cache.'}
(N/'future-native-workspace-preparation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
