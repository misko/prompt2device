from pathlib import Path
import json
import thermal_review_common as common
source=Path(common.__file__).read_text().replace('rj45-placement-thermal-availability-opened.json','rj45-return-width-scope-availability-opened.json')
ns={'__file__':common.__file__};exec(compile(source,'<final-return-source>','exec'),ns)
R,N=common.R,common.N
m=json.loads((N/'rj45-return-width-reassessment1-opened.json').read_text());D=Path(m['project']);O=Path(m['output_dir'])
assert json.loads(Path(m['attempt']).read_text())['status']=='PASS'
close=json.loads((N/'rj45-return-width-reassessment1-closeout-summary.json').read_text())
assert close['engineering_verdict']=='DEFECTIVE'
report=(O/'report.md').read_text()
assert 'I support ROOT reconciling ADC_WEST_LOCAL' in report
assert 'This is five owning files' in report
copies=[(D/'project','project'),(D/'shared','shared'),(D/'canon','canon'),
        (D/'partial-proposal','partial-proposal'),(O,'decision'),
        (D/'current-handoff','current-handoff'),
        (N/'rj45-return-width-reassessment1-closeout-summary.json','decision-closeout.json')]
task='''# Fresh isolated source handoff after independent return-scope D-BACK

Read current-handoff, decision/report.md and exact supported source boundary.
Root owns all live files. Author only scratch postimages; no board construction,
load/save/generation/fill/DRC/prep/router/native candidate, commit or live/frozen
write. Existing native4/4 remains closed; root may admit ONEcandidate5 only after
complete exact source preflight under the reviewed changed decision. No native6.

Prepare one coherent complete correction, bound to the independent decision:
1. Apply the exact independently reviewed2file shadow/census partial postimages
   from partial-proposal/after (stackup.yaml and test_route_source_contract.py).
   Preserve their complete hostile controls, exact identities and true original
   INCOMPLETE19/20 result as history. Do not call partial acceptance fullGREEN.
2. If and only if final decision supports the precise rectangle, change ONLY
   ADC_WEST_LOCAL.rect xmin89.5→89.35, retaining67.7/93.6/72.35, F.Cu/deny:[],
   existing permitted nets and width/clearance floors. Preserve the already
   independently adopted ADC2 polygon and every other floorplan field. No route,
   placement, pad, via, thermal, copper stack or other reservation changes.
3. Append explicit supported rationale to governing ADR0030 and the existing
   ADC_WEST_LOCAL width AND clearance rationales in rules/nets.yaml, as required
   by the final review. State both width AND paired-clearance geographic effect, current
   actual membership unchanged, whole-capsule requirement and new0.01mm source
   margin. Preserve all historical quantities and old text as context, no claim
   of native/thermal/return-cut/assembly/order qualification. At most5 coherent
   existing files unless exact decision requires otherwise; do not broaden scope.
4. Extend the same maintained route-contract test module with a complete pure
   source check of all sub0.30mm GND primitives against proper net/layer/width
   scopes and full capsule containment. Derive complete point-spec coverage; no
   hidden non-seed source omission. Preserve ordinary GND0.30,17current0.18 plus
   3current0.20 and exact current owner identities, not just a count that can be
   satisfied by unrelated copper. Retain original tests. Meaningful hostile
   controls must reject old scope, escaped round end, wrong net/layer permission,
   inappropriate width floor and empty/missing population where applicable.
   Do not grade only centers or accept native insideArea overlap as containment.
5. Show actual maintained regression RED against exact prior floorplan and
   GREEN proposed coherent afterimages; normal route-contract suite must now
   pass completely, including previously failing endpoint subtests and existing
   CHASSIS/ownership/reference/via controls. Run focused ADC feed/source/electrical
   invariant/thermal and safe ground-source tests on the composed floorplan to
   preserve the adopted ADC2 union and all32sourcefull-ground targets. Do not run
   BOARD-producing fixture tests or broad unrelated suites. Retain rawcommands,
   contexts, all setupFAILs and durations using shared runtime defaultconsole.

Full postimages under scratch/after/<repo-relative>, before/afterhashmanifest,
minimaldiff, exact changed-geometry and complete source-invariance proof. Include
independent decision identity, source guards/hostility and all actual scripts/logs
in the five-output archive. All frozenTSX imports/tools/partmetadata are supplied.
Explicit real R GIT_DIR may resolve immutable historical controls; record blobs.
No tool installs. If any prerequisite remains missing or a test fails, preserve
the complete defect and return INCOMPLETE; do not invent new native permission.
Root will reopen exact source preflight, then separately admit/bind the one
candidate and commission independent exact source/native acceptance before any
new geometry is live-adopted. Source handback is not that final acceptance.
'''
ns['open_task']('rj45-final-return-scope-source1',task,copies,minutes=16,role='authoring')
