from pathlib import Path
import json
import thermal_review_common as common
source=Path(common.__file__).read_text().replace('rj45-placement-thermal-availability-opened.json','rj45-return-width-scope-availability-opened.json')
ns={'__file__':common.__file__};exec(compile(source,'<return-width-review>','exec'),ns)
R,N=common.R,common.N;P=R/'projects/crow-audio-carrier-v1'
m=json.loads((N/'rj45-baseline-route-contract-source1-opened.json').read_text());D=Path(m['project']);O=Path(m['output_dir']);S=Path(m['scratch_dir']);assert json.loads(Path(m['attempt']).read_text())['status']=='PASS'
copies=[(P/'03_src','project/03_src'),(P/'03_tscircuit/src','project/03_tscircuit/src'),
        (P/'01_docs/decisions','project/01_docs/decisions'),(P/'04_kicad','project/04_kicad'),
        (P/'02_parts/CS5308P-DN','project/02_parts/CS5308P-DN'),
        (P/'06_build/netlists','project/06_build/netlists'),
        (P/'01_docs/STATUS.md','current-handoff/STATUS.md'),
        (P/'01_docs/findings.yaml','current-handoff/findings.yaml'),
        (O,'partial-proposal/delivery'),(S/'after','partial-proposal/after'),
        (S/'source-analysis.json','partial-proposal/source-analysis.json'),
        (R/'skills/kicad-pcb','shared/skills/kicad-pcb'),
        (R/'skills/pcb-design','shared/skills/pcb-design'),
        (R/'CLAUDE.md','canon/CLAUDE.md'),(R/'tests/README.md','canon/testing.md'),
        (N/'return-width-kicad-primary.md','canon/kicad-rule-area-semantics.md'),
        (N/'adc2-reservation-source-adoption.json','current-handoff/adc2-adoption.json')]
prior=Path('/tmp/rj45-coherent-top-only-source1-dz0edoky/06_build/task_runs/rj45-coherent-top-only-source1/scratch/work/projects/crow-audio-carrier-v1/04_kicad')
copies.append((prior,'candidate4-prepared'))
for p in (P/'02_parts').glob('*/part.yaml'):
    if p.parent.name!='CS5308P-DN':copies.append((p,'project/'+p.relative_to(P).as_posix()))
task='''# Fresh independent D-BACK: ADC1 narrow-ground return authority

Root sole live writer. SOURCE/analytical review only; do not generate/save/fill
any PCB, run DRC/prep/router, edit frozen/live sources, or consume a native trial.
Read current handoff and exact partial source handback, ADR0015/0030, actual
floorplan/route/nets and Cirrus primary. Current adopted ADC2-only polygon change
is hash-bound in adc2-adoption.json but NOT regenerated. Existing native boards
are older unchanged geometry; independently establish local ADC1 identity before
using them. Source acceptance is never inferred from native net names alone.

The baseline partial proposal is exactly2files, shadow stackup and route-contract
tests. It corrects missing CHASSIS class/censuses, retaining all original methods
and hostility, but normal suite20methods has19PASS/oneFAIL with two subtests:
C_VMID1_470N.2 GND spec1 width0.18, [89.45,68.7]→[89.45,69.17]→[91.2,69.17].
Fullcapsule xmin89.36 lies0.14mm outside ADC_WEST_LOCAL xmin89.5. Ordinary GND
floor0.30; five eligible0.18 GND scopes do not contain full copper. ADC_FEED
scopes are3V3-only; pour/via barriers are not width authority. ADR0030 accepts
this north return column while nets.yaml scoped-floor rationale and source tests
require whole-capsule coverage. Do not infer a native DRC violation: actual
emitter uses insideArea overlap, distinct from enclosure in KiCad10manual.

Required independent judgment:
1. Re-derive exact source/native segment widths, fullshape bounds and eligible
   scopes. Read actual emitter plus versioned official KiCad documentation if
   needed. Identify precisely whether this is a physical violation, an authored
   scope mismatch, or a test error; no diagnosis may silently weaken the stronger
   written whole-capsule obligation.
2. Before recommending repair, perform one complete narrow-GND source population
   census against all applicable scoped-floor regions, distinguishing every
   instantiated primitive from bank/spec/default counts. Include all sub0.30mm
   GND source segments and their proper permissions, width and whole-capsule
   coverage. Classify any additional residuals coherently. Do not stop at this
   first failing row, borrow wrong-net scopes or use overlap as containment.
3. Compare the smallest owning-source alternatives while preserving existing
   return-column placement/clearances, fourVMIDcuts, threeLTquietcuts, fivepaddle
   exclusions, allvias/reservations and all electrical/current/width floors.
   One concrete option to assess is monotonic extension of the existing
   ADC_WEST_LOCAL rectangle westward to89.35mm (10um beyond the measuredcapsule),
   retaining other three bounds, deny:[], layerF.Cu and existing exact authorized
   nets/minwidth. This is a PROPOSAL, not authority. Compare its complete affected
   area/pad/source-track/via/scope population and alternatives such as a local
   polygon extension or route modification. Recommend a precise supported source
   boundary only if geometry/ownership evidence supports it; otherwise reject
   and explain next owner. No physical new candidate or modified saved board.
4. Independently review the exact2file partial shadow/test postimages, including
   CHASSIS shell mapping, outerlayers, inferred-reference metadata, 49added seed
   owners/15viaoverrides and unchanged source/copper floors. Reproduce retained
   relevant normal failures/hostilecontrols in scratch if helpful. ItsINCOMPLETE
   domain remains original; state any scoped acceptance separately. Do not
   normalize away the remaining capsule failures or call19/20aPASS.
5. Recommend one coherent final source handoff containing all demonstrated
   necessary owners and maintained regressions. State whether reviewed changed
   local width/reservation premise supports ROOT conditional admission of AT
   MOST ONE cumulative candidate5 after exact source preflight, preserving all4
   prior candidates and the already accepted ADC2 union. No candidate6/reset.
   A future proof must grade ordinary placementP-DRC BEFOREprep and then prepared
   DRC/fullreturncuts/sourcebinding; every actual earlier refusal remains binding.

Use independent mathematical/nativeSHAPE methods, not author assertions proving
themselves. Analytically building footprint shapes and loading existing native
copies read-only is allowed; BOARD-producing fixture tests are not. Shared tools
and allTSX imports are frozen. Historical Git controls can read immutable objects
through explicit real R GIT_DIR; record commits/blobs. No installs; inspect APIs.
Read-only official KiCad/Cirrus primary lookup allowed and must be preserved.
No live adoption, order/release/thermal/assembly claim.
'''
ns['open_task']('rj45-return-width-reassessment1',task,copies,minutes=21)
