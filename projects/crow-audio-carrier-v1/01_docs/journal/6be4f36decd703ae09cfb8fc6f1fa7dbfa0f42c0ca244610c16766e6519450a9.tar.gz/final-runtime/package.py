from pathlib import Path
import hashlib,json,tarfile,io
s=Path(__file__).parent;o=s.parent/'outputs';archive=o/'evidence.tar.gz'
files=[p for p in sorted(s.rglob('*')) if p.is_file() and not p.name.startswith('preflight') and p.name not in ['package.log','package-runtime.json']]
files += [o/'report.md',o/'evidence.json',o/'result.json']
with tarfile.open(archive,'w:gz') as tar:
 for p in files:
  assert not p.is_symlink()
  name=('scratch/'+p.relative_to(s).as_posix()) if p.is_relative_to(s) else 'review/'+p.name
  tar.add(p,arcname=name,recursive=False)
members=[];seen=set()
with tarfile.open(archive,'r:gz') as tar:
 for m in tar.getmembers():
  assert m.isfile() and not m.issym() and not m.islnk()
  assert not m.name.startswith('/') and '..' not in Path(m.name).parts and m.name not in seen
  assert not m.name.endswith(('.tar','.tar.gz','.tgz'))
  seen.add(m.name);b=tar.extractfile(m).read();assert len(b)==m.size
  members.append(dict(path=m.name,size=m.size,sha256=hashlib.sha256(b).hexdigest()))
b=archive.read_bytes()
(o/'evidence-manifest.json').write_text(json.dumps(dict(archive_sha256=hashlib.sha256(b).hexdigest(),archive_size=len(b),member_count=len(members),members=members),indent=2))
print(json.dumps(dict(archive=str(archive),member_count=len(members),archive_size=len(b))))
