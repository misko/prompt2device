review_stage: pre-route
review_kind: pin
reviewer: fresh agent /root/rj45_pin_carrier_esd_clockground1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: e85b1461a82f3d3853c19fae694693816e31570d23d37019ef187d6428bea4ae
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: e6d5b0b89efd79051b082f70b283ec7e85e1170ed11ddb94581744d26904c9c7

Limited coverage: U_ESD1–U_ESD8 only, pre-route pin review. No whole-board acceptance or order authorization. Immutable hashes above are subject bindings, not independent review of those full artifacts.

Manufacturer derivation preceded dossier inspection. Rendered and visually inspected TI TPD2E2U06 SLLSEG9C PDF pp.3,17,18, SHA256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed. Page 3 DRL 5-Pin SOT Top View and Pin Functions establish 1=NC upper-left, 2=NC middle-left, 3=IO1 lower-left, 4=GND lower-right, 5=IO2 upper-right; numbering is CCW. Page 17 DRL0005A Package Outline (4220753/E, 11/2024) confirms pin-1 ID area and five separate leads; no EP or fused identities. The numbered upper package plan agrees with explicit p.3 top view; the lower unnumbered projection was not used for winding. Page 18 Example Board Layout confirms five individual lands, 0.5 mm vertical pitch. No manufacturer bottom-view mirror was applied.

All dossiers declare front mounting and component-top coordinates (+x right, +y down). Every instance has three west pads and two east pads. Pin 1 is upper-left. Native rotations are 180 degrees for U_ESD1–4 and 0 degrees for U_ESD5–8. Independent native-coordinate reconstruction matches every row; the shoelace signed area is -1.425 mm² in y-down coordinates, hence CCW. No reflection is needed. Five native rows, five unique native centers and five distinct physical lead identities per instance; no alias or identity collapse. Total: 40 native pads, 40 physical identities, zero EP and zero fused aliases.

Native pads measure 0.68×0.35 mm at x=±0.7125 mm and y=-0.5,0,+0.5 mm on west / ±0.5 mm on east. TI's example uses 0.67×0.30 mm and x=±0.74 mm; it is an example, not an exact mandated land template. The small dimensional differences do not change lead identity, count, pitch, pin-1 corner, or winding. This pin review does not grade solder-process land optimization.

U_ESD1 VERDICT: PASS
Measured native pads: 5; physical identities: 5; distinct centers: 5; EP: 0; fused aliases: 0. Primary source: SHA256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed, PDF pp.3/17/18, DRL top view/functions and DRL0005A outline/land pattern. Expected CCW, pin 1 upper-left, west 1/2/3 and east 4/5; observed exact identity/order agreement in component-top frame.
U_ESD1 pin 1 (NC): expected unconnected NC; observed unconnected-(U_ESD1-NC1-Pad1). PASS.
U_ESD1 pin 2 (NC): expected unconnected NC; observed unconnected-(U_ESD1-NC2-Pad2). PASS.
U_ESD1 pin 3 (IO1): expected protected signal line; observed AUDIO_P1. PASS.
U_ESD1 pin 4 (GND): expected ground; observed GND. PASS.
U_ESD1 pin 5 (IO2): expected protected signal line; observed AUDIO_N1. PASS.

U_ESD2 VERDICT: PASS
Measured native pads: 5; physical identities: 5; distinct centers: 5; EP: 0; fused aliases: 0. Primary source: SHA256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed, PDF pp.3/17/18, DRL top view/functions and DRL0005A outline/land pattern. Expected CCW, pin 1 upper-left, west 1/2/3 and east 4/5; observed exact identity/order agreement in component-top frame.
U_ESD2 pin 1 (NC): expected unconnected NC; observed unconnected-(U_ESD2-NC1-Pad1). PASS.
U_ESD2 pin 2 (NC): expected unconnected NC; observed unconnected-(U_ESD2-NC2-Pad2). PASS.
U_ESD2 pin 3 (IO1): expected protected signal line; observed AUDIO_P2. PASS.
U_ESD2 pin 4 (GND): expected ground; observed GND. PASS.
U_ESD2 pin 5 (IO2): expected protected signal line; observed AUDIO_N2. PASS.

U_ESD3 VERDICT: PASS
Measured native pads: 5; physical identities: 5; distinct centers: 5; EP: 0; fused aliases: 0. Primary source: SHA256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed, PDF pp.3/17/18, DRL top view/functions and DRL0005A outline/land pattern. Expected CCW, pin 1 upper-left, west 1/2/3 and east 4/5; observed exact identity/order agreement in component-top frame.
U_ESD3 pin 1 (NC): expected unconnected NC; observed unconnected-(U_ESD3-NC1-Pad1). PASS.
U_ESD3 pin 2 (NC): expected unconnected NC; observed unconnected-(U_ESD3-NC2-Pad2). PASS.
U_ESD3 pin 3 (IO1): expected protected signal line; observed AUDIO_P3. PASS.
U_ESD3 pin 4 (GND): expected ground; observed GND. PASS.
U_ESD3 pin 5 (IO2): expected protected signal line; observed AUDIO_N3. PASS.

U_ESD4 VERDICT: PASS
Measured native pads: 5; physical identities: 5; distinct centers: 5; EP: 0; fused aliases: 0. Primary source: SHA256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed, PDF pp.3/17/18, DRL top view/functions and DRL0005A outline/land pattern. Expected CCW, pin 1 upper-left, west 1/2/3 and east 4/5; observed exact identity/order agreement in component-top frame.
U_ESD4 pin 1 (NC): expected unconnected NC; observed unconnected-(U_ESD4-NC1-Pad1). PASS.
U_ESD4 pin 2 (NC): expected unconnected NC; observed unconnected-(U_ESD4-NC2-Pad2). PASS.
U_ESD4 pin 3 (IO1): expected protected signal line; observed AUDIO_P4. PASS.
U_ESD4 pin 4 (GND): expected ground; observed GND. PASS.
U_ESD4 pin 5 (IO2): expected protected signal line; observed AUDIO_N4. PASS.

U_ESD5 VERDICT: PASS
Measured native pads: 5; physical identities: 5; distinct centers: 5; EP: 0; fused aliases: 0. Primary source: SHA256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed, PDF pp.3/17/18, DRL top view/functions and DRL0005A outline/land pattern. Expected CCW, pin 1 upper-left, west 1/2/3 and east 4/5; observed exact identity/order agreement in component-top frame.
U_ESD5 pin 1 (NC): expected unconnected NC; observed unconnected-(U_ESD5-NC1-Pad1). PASS.
U_ESD5 pin 2 (NC): expected unconnected NC; observed unconnected-(U_ESD5-NC2-Pad2). PASS.
U_ESD5 pin 3 (IO1): expected protected signal line; observed AUDIO_P5. PASS.
U_ESD5 pin 4 (GND): expected ground; observed GND. PASS.
U_ESD5 pin 5 (IO2): expected protected signal line; observed AUDIO_N5. PASS.

U_ESD6 VERDICT: PASS
Measured native pads: 5; physical identities: 5; distinct centers: 5; EP: 0; fused aliases: 0. Primary source: SHA256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed, PDF pp.3/17/18, DRL top view/functions and DRL0005A outline/land pattern. Expected CCW, pin 1 upper-left, west 1/2/3 and east 4/5; observed exact identity/order agreement in component-top frame.
U_ESD6 pin 1 (NC): expected unconnected NC; observed unconnected-(U_ESD6-NC1-Pad1). PASS.
U_ESD6 pin 2 (NC): expected unconnected NC; observed unconnected-(U_ESD6-NC2-Pad2). PASS.
U_ESD6 pin 3 (IO1): expected protected signal line; observed AUDIO_P6. PASS.
U_ESD6 pin 4 (GND): expected ground; observed GND. PASS.
U_ESD6 pin 5 (IO2): expected protected signal line; observed AUDIO_N6. PASS.

U_ESD7 VERDICT: PASS
Measured native pads: 5; physical identities: 5; distinct centers: 5; EP: 0; fused aliases: 0. Primary source: SHA256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed, PDF pp.3/17/18, DRL top view/functions and DRL0005A outline/land pattern. Expected CCW, pin 1 upper-left, west 1/2/3 and east 4/5; observed exact identity/order agreement in component-top frame.
U_ESD7 pin 1 (NC): expected unconnected NC; observed unconnected-(U_ESD7-NC1-Pad1). PASS.
U_ESD7 pin 2 (NC): expected unconnected NC; observed unconnected-(U_ESD7-NC2-Pad2). PASS.
U_ESD7 pin 3 (IO1): expected protected signal line; observed AUDIO_P7. PASS.
U_ESD7 pin 4 (GND): expected ground; observed GND. PASS.
U_ESD7 pin 5 (IO2): expected protected signal line; observed AUDIO_N7. PASS.

U_ESD8 VERDICT: PASS
Measured native pads: 5; physical identities: 5; distinct centers: 5; EP: 0; fused aliases: 0. Primary source: SHA256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed, PDF pp.3/17/18, DRL top view/functions and DRL0005A outline/land pattern. Expected CCW, pin 1 upper-left, west 1/2/3 and east 4/5; observed exact identity/order agreement in component-top frame.
U_ESD8 pin 1 (NC): expected unconnected NC; observed unconnected-(U_ESD8-NC1-Pad1). PASS.
U_ESD8 pin 2 (NC): expected unconnected NC; observed unconnected-(U_ESD8-NC2-Pad2). PASS.
U_ESD8 pin 3 (IO1): expected protected signal line; observed AUDIO_P8. PASS.
U_ESD8 pin 4 (GND): expected ground; observed GND. PASS.
U_ESD8 pin 5 (IO2): expected protected signal line; observed AUDIO_N8. PASS.

Instance symmetry: every pin has the same kind of net across all eight instances: 1/2 isolated NC nets, 3 AUDIO_Pn, 4 GND, 5 AUDIO_Nn. IO1/IO2 are two equivalent protection channels, not a manufacturer-defined positive/negative polarity pair. No swaps or structural divergence found. NC rows are explicitly unconnected; no datasheet-permitted NC tie exception is needed.

Unresolved pin findings: none. Signal voltage, ESD routing efficacy, and whole-board behavior are outside the supplied pin-review scope.
