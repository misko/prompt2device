from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,datetime,shutil
s=Path(__file__).parent;run=s.parent;base=s.parents[3];out=run/'outputs';out.mkdir(exist_ok=True)
e=json.loads((run/'envelope.json').read_text());b=json.loads((s/'independent-before.json').read_text());a=json.loads((s/'independent-after.json').read_text());f=json.loads((s/'all-group-final-audit.json').read_text())
findings=[
'Exact byte and semantic change: only groups/4/mount_side back to front, line142. Refs, model SHA, authorities, transforms, thresholds, dimensions and five other groups unchanged.',
'Actual frozen native consumer rejects old back declaration with declared mount_side back differs from actual front footprint side; all six exact proposed tuples accept, covering28 distinct refs.',
'One authorized copied owning registration invocation PASS in7.204972s under180s bound; fuse regenerated, five prevalidated caches hit and remain byte-identical. No registration retry, no product placement/routing run, no source repair.',
'All six post caches and receipts reopened and current-tuple validated. All229 attachment datums graded, with declared per-group tolerances retained. All28 instances front. All signed fractions >=0.75; minimum0.81250202955, fuse1.0.',
'Fuses:16/16 positive native-pad-polygon overlaps, minimum1.9299861mm2; maximum centre delta0.03136241061mm versus0.2mm; Fab and courtyard outward0mm versus0.2/0.25mm. Signed pixels above51014, below0.',
'Exact fuse model comprises24 vertices in three simple indexed-face solids, no nested Transform, bounds4.73x3.41x1.8mm with z0..1.8mm. Every source model transform identity; native top-side attachment unchanged; board yaw0 forF1-F4 and180 forF5-F8.',
'Authored side census: floorplan placement.sides empty, assembly top-only and bottom_population none, all six proposed registration mounting declarations front. Floorplan B.Cu is a copper zone, compatible with top assembly. Native SMD flags309 =306 fitted parts plus3 fiducials, all top.',
'224/224 frozen input sizes and hashes match both before and after; exact copied source and board digests retained. No live write or adoption.',
'Nonengineering delivery-schema lookup /usr/bin/rg failed to launch because that absolute executable does not exist; raw ERROR and command/runtime retained. Python source inspection supplied the schema. Initial bootstrap reads/copy/runtime-API setup were direct filesystem setup commands, recorded in initial-actions.json and runtime-api.txt; engineering execution used bounded shared runtime.'
]
evidence={'verdict':'SOUND','subject':e['subject'],'scope':'Exact one-file F1-F8 mount_side correction and bounded native P-MODEL-REG evidence only','methods':['224-input before/after SHA256 census','exact byte replacement and recursive YAML semantic diff','copied native pcbnew LoadBoard census and owning tuple rejection control','copied accepted_cache_valid validation before and after','one180s-bounded copied owning model_registration_gate.py run','all6 group receipt attachment/tolerance revalidation','12 existing/new signed-side PNG measurements','new fuse populated-minus-bare extraction and native pad polygon overlap remeasurement','four image view inspections','exact WRL vertices/transform inspection','authored YAML side fields and keys census'],'findings':findings,'measured_counts':{'inputs':224,'groups':6,'registered_instances':28,'attachment_datums':229,'unchanged_caches':5,'generated_groups':1,'registration_invocations':1,'fitted_smd_top':306,'fitted_smd_bottom':0,'fiducials_top':3,'fuse_overlap_graded':16,'fuse_overlap_total':16},'before_sha256':b['source_before_sha256'],'after_sha256':b['source_after_sha256'],'board_sha256':b['board_sha256'],'all_group_measurements':f['all_group_measurements'],'signed_side_measurements':a['signed'],'fuse_measurements':a['fuse_measurements'],'unresolved_engineering_findings':[],'remaining_stage_obligations':['Root source adoption and canonical gate renewal are separate','Carrier checkpoint/schematic renewal and mandatory handoff remain owed','No whole placement, orientation, routing, release, thermal fault qualification or human approval acceptance','Six prior exploratory native attempts remain spent; this coupon validation is not a seventh placement attempt; pod unchanged']}
(out/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
lines=['SOUND for the exact F1–F8 mounting-side source correction and bounded native model registration. No unresolved defect was found within that scope.','',
'The proposal changes only `mount_side: back` to `mount_side: front` at line 142 of `03_src/rules/model_registration.yaml`. The copied owning tuple consumer actually rejects the old declaration and accepts all six proposed groups / 28 refs. Every other source field is byte-for-byte unchanged.','',
'The single authorized owning registration run passed 6/6 groups in 7.205 seconds under its 180-second limit. It generated the fuse coupon only. Five existing caches were independently validated before execution and remained byte-identical afterward; all six resulting caches and receipts reopen against current tuples.','',
'| Group | Refs | Attachment datums | Max centre delta mm | Front signed fraction |','|---|---|---:|---:|---:|']
for r,z in zip(f['all_group_measurements'],a['signed']):lines.append(f"| {r['group']} | {','.join(r['refs'])} | {r['attachment_graded']}/{r['attachment_total']} | {r['max_centre_delta_mm']:.6f} | {z['front_fraction']:.6f} |")
lines +=['','All 229 attachment datums pass. All groups have zero measured Fab and courtyard outward excursion. Retained fit/courtyard limits are respectively 0.35/0.35 mm for Wurth and Molex, 0.15/0.25 mm for Samtec, and 0.20/0.25 mm for the three SMD groups. Every signed-side minimum remains 0.75.','',
'Independent remeasurement of the new populated-minus-bare fuse images gives 16/16 positive pad overlaps, minimum 1.9299861 mm², maximum centre delta 0.03136241061 mm, and no search-window contact. Both side images yield 51,014 pixels above the board and zero below: fraction 1.0. Visual inspection of the overlay, both side images and original un-eroded difference agrees. The exact simple WRL solids span 4.73 × 3.41 × 1.80 mm, z=0..1.80 mm, with no nested transform and identity model transforms on all eight front-side native footprints.','',
'The native board has 306 fitted SMD parts on top and zero below. Its 309 SMD flags include three fiducials. The floorplan has an empty placement-side override map; assembly explicitly requires top only and no bottom population; all six proposed registration declarations agree. The B.Cu zone is routing copper and is consistent with top-only assembly.','',
'Frozen input verification passed 224/224 before and after. Exact identities:','',f"- Before source: `{b['source_before_sha256']}`",f"- Proposed source: `{b['source_after_sha256']}`",f"- Unchanged PCB: `{b['board_sha256']}`",'',
'All review engineering commands, raw merged stdout/stderr, command metadata and runtime outcomes are retained with the methods and exact before/after data. One nonengineering schema lookup attempted unavailable `/usr/bin/rg` and has an explicit ERROR record; Python source inspection completed that lookup. Initial bootstrap reads, hash/copy setup and runtime API inspection preceded the runtime wrapper and are recorded separately. No owning gate retry or repair occurred.','',
'This is exact-source and native coupon registration acceptance only. Native signed pixels are exterior occupancy, not a general solid-volume proof, and raster erosion can miss thin features; exact unchanged fuse geometry and un-eroded evidence were inspected for this correction. Whole carrier placement/orientation, interpart fit, routing, manufacture, thermal faults and human approval are not accepted here. Root remains sole live writer; source adoption, carrier checkpoint/schematic renewal and mandatory handoff remain owed. Six exploratory native attempts remain spent; this coupon is not a seventh placement attempt. Pod unchanged.','']
(out/'report.md').write_text('\n'.join(lines))
(out/'result.json').write_text(json.dumps({'subject':e['subject'],'checks':{k:'PASS' for k in e['completion']['checks']},'unresolved':[]},indent=2)+'\n')
# Archive only complete files, including exact frozen originals and copied working evidence.
archive=out/'evidence.tar.gz';members=[]
files=[]
for r in e['input_packet']:files.append((base/r['path'],'frozen/'+r['path']))
files.append((run/'envelope.json','envelope.json'))
for p in sorted(s.rglob('*')):
 if p.is_file():files.append((p,'review/'+p.relative_to(s).as_posix()))
for name in ['report.md','evidence.json','result.json']:files.append((out/name,'delivery/'+name))
assert len({name for _,name in files})==len(files)
with tarfile.open(archive,'w:gz') as t:
 for p,name in files:
  assert not p.is_symlink();q=PurePosixPath(name);assert not q.is_absolute() and '..' not in q.parts
  data=p.read_bytes();members.append({'path':name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()});t.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
 actual=t.getmembers();assert len(actual)==len(members)
 for item,expected in zip(actual,members):
  assert item.isfile() and item.name==expected['path'];data=t.extractfile(item).read();assert len(data)==expected['size'] and hashlib.sha256(data).hexdigest()==expected['sha256']
manifest={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_size':archive.stat().st_size,'member_count':len(members),'members':members}
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k!='members'}))
