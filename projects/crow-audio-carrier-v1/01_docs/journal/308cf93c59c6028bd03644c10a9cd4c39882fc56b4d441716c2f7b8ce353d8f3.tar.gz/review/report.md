# Exact assembly-side source review: DEFECTIVE

Subject raw SHA-256: `e2ffb5f37e9d814f666ba4ea407bb4bf72ddf77d9e959007737aa7fc1d63d56e`.
Subject semantic SHA-256: `315c82db630289a91ca78ccbad8e724780bfcd7cbbc24f842cc56fb154ee8601`.
This verdict binds only the seven before/candidate pairs in `candidate/source-identity.json`, including checker SHA-256 `64f790bbd733c29ebc28834eff5c9edc8aca8938b0a4c3e0b53b9dd5ce5e4116`.

## Finding F1 — P1: conflicting population rows bypass the fitted-SMD side gate

Affected source: `skills/jlcpcb-fab/scripts/assembly_coverage.py:612-620`, in `check_assembly_sides`; the loader/check also allow repeated references across `not_assembled` entries. The new nonpopulation comprehension exempts a reference if **any** entry calls it `dnp_by_design` or `test_point`, even when another explicit entry requires manual fitting. The result is an exit-zero false pass and a false zero fitted-SMD denominator.

MEASURED independent public-CLI control: J9 is a B.Cu footprint with two numbered B.Cu SMD lands, deliberately without `attr smd`, excluded from CPL. `sides: [top]`, a substantive `user_supplied` entry, and `disposition: Fit J9 manually after factory assembly` yield exit **1**, exactly one `SMD-SIDE-NOT-ALLOWED`, and fitted-SMD denominator **1**. Adding one contradictory DNP entry for the same J9, with all board/CPL/BOM/MANIFEST bytes unchanged, yields exit **0**, `fails: []`, `assembly_sides_status: GRADED`, `smd_side_graded: 0`, and an empty native histogram. Both DNP-before-manual and manual-before-DNP orders reproduce this. The existing schema accepts both entries. This is contradictory machine-readable authority, not the acknowledged inability to inspect whether a consistently declared DNP was physically populated.

Exact reproducers and per-call commands, runtime, raw stdout/stderr and JSON are archived under `scratch/hostile/manual_bottom_control/`, `scratch/hostile/conflict_dnp_then_manual/`, and `scratch/hostile/conflict_manual_then_dnp/`. Independent constructor: `scratch/hostile.py`. Repair should reject contradictory per-reference population declarations or otherwise require unambiguous nonpopulation before excluding a reference; add both-order public-CLI known-bad controls. No repair was applied to this frozen candidate.

## Review and measured coverage

All **57/57** envelope inputs were size/hash verified before and after review; **7/7** source pairs independently match their before/after identities. Complete diff retained as `scratch/complete.diff`. All seven source-file changes were reviewed: checker data flow and public CLI, tests, testing documentation, assembly procedure, A-POS policy canon, assembly template and governing rules contract.

MEASURED: original seven authored tests passed **7/7**, with **4** known-bad families and **41** tests unselected. A second capture-only run retained every public checker call through shared `pipeline_runtime.run_stage`: **21/21** expected CLI outcomes (**13** rejected, **8** accepted). The authored test code and candidate checker bytes were unchanged; the driver replaced only the subprocess capture seam and added Python `-B`. Repetition was solely to retain each raw checker stream, which the normal harness only exposes on failed assertions. Methods, fixtures, commands, raw logs, outputs and runtime records are archived.

MEASURED independent probes: **6** public CLI cases. The ordinary manual-bottom control and exempt-prefix-bottom case reject and each grade one SMD; DNP still present on CPL rejects and remains in the one-SMD denominator; missing legacy sides explicitly reports `UNDECLARED_OR_INVALID`, zero side-graded SMD, and native bottom census one. The two contradictory-declaration cases falsely pass as detailed in F1. Thus **4/6** independent probes behave consistently with the intended contract and **2/6** expose the same defect.

INHERITED, reopened raw evidence: root final assembly suite **48 passed / 0 failed**, **24** known-bad tests. This reviewer did not rerun the 41 older fleet-dependent tests. Root actual RED log contains four known-bad families failing because pre-fix public checker calls exited zero on false premises; it also contains two clean-test missing-summary-key failures. The original zero-selection run (`0 passed, 0 failed, 47 skipped`) is explicitly **not** qualifying RED. The later seventh land-census test was not present in that six-test historical RED log; neither this review nor its evidence claims otherwise.

INHERITED root supporting checks: skill authority PASS; documentation **15/15**; disclosure **14/14**, including its **2** declared blind spots. Root contracts suite **16 passed / 1 failed** on untracked project files; the packet does not contain a successful after-staging full audit. That gate remains owed to root and no ratchet waiver is accepted here.

The additive policy, procedure and template changes consistently locate enforcement in existing A-POS and distinguish manual SMD from DNP/test-point nonpopulation and separate THT process qualification. The parser counts actual numbered SMD copper independently of the authoring SMD attribute; bare unnumbered fiducials are excluded. CPL native-side agreement is always checked, even without legacy side policy. Existing summary keys remain and new denominators are explicit. Apart from F1, no additional concrete regression or full-diff defect was established within this exact-source review.

INHERITED native gap: carrier **306 SMD = 290 top + 16 bottom**; pod **31 = 30 top + 1 bottom**. These prove the old layouts violate top-only policy, not that placement is completed or accepted. No board geometry was changed or independently remeasured here.

## Scope and delivery

Applicable PCB design and JLC fabrication skills and their execution/assembly procedures were used. Reviewer remained READ_ONLY to frozen candidate and live source, working exclusively in allocated scratch/output directories, with no children, source adoption, commits, geometry edits, sealing or ordering. Runtime source dependencies used from the expressly authorized live shared runtime are hash-recorded in `scratch/runtime-dependencies.json`.

No physical component, body/clearance, paste-access, solderability or release-acceptance claim is made. Correctly and consistently declared DNP cannot be physically verified by this offline check. Missing legacy sides remain ungraded and cannot establish top-only compliance. F1 remains unresolved in the exact frozen candidate; delivery completion checks certify an honest completed review, not engineering acceptance.

Packaging reopens every regular archive member and verifies exact size/SHA-256, rejecting symlinks, traversal and duplicates. Final delivery is validated with the packet `preflight.py` and exact allocated envelope after packaging.
