# Independent small-outline PAD-GEOM/PAD-MISMATCH review

Review date: **2026-09-11**. Subject raw SHA-256 `0e7eb5c2ae158d8cd549b2c269251d060c0a501e1fc3449e689594fe364be8e9`; semantic SHA-256 `51e03be93e685b90c81d8cca51c27c4589167bd140c2fbd34034bf8ea82f508a`.

## Result

Seven scoped PAD-GEOM findings were independently reviewed. Four Nexperia SOT753 references are **PASS-supported-adjudication**. Two 2N7002K-7 references are **FAIL-source-defect** because the native land is narrower than the exact manufacturer's recommended land. The AO3401A reference is **INCOMPLETE** because the exact supplied manufacturer PDF contains pin topology but no dimensional package drawing or recommended land pattern. No scoped PAD-MISMATCH finding exists for the four supplied codes; the raw fits for them remain diagnostic and do not supply land acceptance.

The task text separately requires a disposition of `D_BUCK_IN`. That reference/code is absent from `scope.json` and no exact C154439 datasheet, JLC footprint, symbol, or model is in the immutable packet. Its raw `1<->2` disagreement (native 4.00 mm, JLC 5.14 mm, delta 1.14 mm) and failed 0-degree fit (0.57 mm) are therefore **INCOMPLETE** and remain an order-preview hold. The 0-degree mount-fallback row is not land acceptance.

## Measurement method

Native pad centers, sizes, physical numbers, nets, footprint origins, and board rotations were parsed from the hash-bound board. JLC pads were parsed from the supplied per-code cache. The JLC pattern was rotated 180 degrees, as independently corroborated by the physical pin drawings and JLC symbols, then translated by the unweighted common-pad centroid. Residuals and rectangular copper-overlap areas were recomputed from those inputs; `pattern_measurements.json` records every pad.

Manufacturer PDFs were rendered through the bounded runtime and visually inspected: Diodes DS30896 Rev.20-2 pages 1 and 7; AOS AO3401A Rev.3.1 page 1; Nexperia 74LVC1G14 Rev.19 pages 3 and 11; Nexperia 74LVC1G17 Rev.16 pages 3 and 11. Populated-versus-bare board crops were also inspected for every scoped reference and D_BUCK_IN. Those crops show nonempty bodies with leads on the expected pad rows, but render fit was not used as land acceptance.

## Exact dispositions

| LCSC / refs | Board rotation | Native vs JLC geometry after 180-degree numbered-pad transform | Manufacturer/contact result | Disposition |
|---|---:|---|---|---|
| C85047 / Q_PRE_EN, Q_RST1 | 0°, 0° | `1-3` 2.101934 vs 2.488473 mm; delta 0.386540 mm. Centroid translation `(0.070833,0)` mm; max residual 0.283333 mm, RMS 0.200347 mm. Native pads 1.475×0.600 mm; JLC 1.000×0.800 mm; minimum JLC-pad area overlap 71.563%. | Exact Diodes page 7 recommended land: row-center spacing `C=2.0` mm, pad width `X=0.8` mm, row-normal pad length `Y=0.9` mm, and overall pair-row half-span `X1=1.35` mm (giving ±0.95 mm pad centers with 0.8 mm pads). In the cache coordinate frame the recommended centers are pair row `(-1.0,±0.95)` and single row `(1.0,0)`, size 0.9×0.8 mm. Native row spacing is 1.875 mm (−0.125 mm), native pad size is 1.475×0.600 mm (+0.575/−0.200 mm), and it covers only 75.0% of each recommended land area. The package drawing gives terminal width `b=0.30..0.51` mm and terminal-center tolerances from `e=0.89..1.03`, `e1=1.78..2.05`; the native 0.600 mm tangential pad can miss the extreme projected lead edge by up to 0.030 mm. | **FAIL-source-defect** for both refs. Replace the native SOT-23 land with the exact manufacturer-recommended geometry at the existing component origin and orientation; do not relocate the board component to match JLC CAD. Re-run twin fit, DRC, paste/mask, and renders. |
| C15127 / Q_PRE | 180° | Same geometric family: `1-3` 2.101934 vs 2.488473 mm; delta 0.386540 mm; max residual 0.283333 mm; RMS 0.200347 mm; minimum JLC-pad area overlap 71.563%. Pin functions agree as 1=G, 2=S, 3=D. | Exact AO3401A page 1 visually fixes G/S/D topology and the pin-1 body mark, but the five-page PDF contains no dimensional SOT-23 drawing and no recommended land. Importing dimensions from the different Diodes part would violate the exact-manufacturer authority requirement. | **INCOMPLETE**. Obtain an AOS-authored AO3401A SOT23 package/land authority (or an explicitly authorized AOS package standard), then measure the native and JLC lands against it. No adjudication proposed. |
| C131093 / U_DUMP, U_LDO_EN, U_OE | 0° each | `1-5` 2.275 vs 2.600 mm; delta 0.325 mm. Centroid translation `(0.0325,0)` mm; max residual 0.195 mm, RMS 0.159217 mm. Native pads 1.325×0.600 mm; effective JLC pads 1.199×0.551 mm; minimum JLC-pad area overlap 88.991%. | Exact Nexperia page 11 gives `E=1.3..1.7`, `HE=2.5..3.0`, `Lp=0.2..0.6`, `bp=0.25..0.40`, and fixed pitch `e=0.95` mm. Thus each row's conservative terminal envelope is 0.65..1.50 mm from the body center and ±0.20 mm about its pitch center. The native pad spans 0.475..1.800 mm and ±0.300 mm, containing the full stated terminal envelope with 0.175 mm inner, 0.300 mm outer, and 0.100 mm lateral minimum copper margins. Page 3 fixes 1=NC, 2=A, 3=GND, 4=Y, 5=VCC; JLC symbol and board nets agree. | **PASS-supported-adjudication** for all three exact refs. The 0.325 mm pad-center-distance difference is benign because both rows remain within a native land that fully contains the manufacturer's terminal envelope. |
| C6076 / U_TDM_SCH | 0° | `1-5` 2.275 vs 2.600 mm; delta 0.325 mm. Centroid translation `(0.0325,0)` mm; max residual 0.195 mm, RMS 0.159217 mm. Native pads 1.325×0.600 mm; JLC pads 1.100×0.600 mm; minimum JLC-pad area overlap 92.500%. | Exact Nexperia page 11 has the same SOT753 tolerances and full native containment/margins stated above. Page 3 fixes 1=NC, 2=A, 3=GND, 4=Y, 5=VCC; JLC symbol and board nets agree. | **PASS-supported-adjudication** for this exact ref. |
| C154439 / D_BUCK_IN (task-text requirement, outside supplied four-code scope) | 90° native | Raw report only: native `1-2` 4.00 mm, JLC 5.14 mm, delta 1.14 mm; best fit 0.57 mm at 0°. Native pads are 2.5×1.8 mm at local x=−2/+2; native pad 1 is the upper board pad after the 90° placement. | The populated crop shows a pale transverse stripe nearer the lower contact, while native pad 1 is upper. The packet provides no exact C154439 manufacturer drawing or catalog CAD that identifies that stripe as a cathode band or maps the manufacturer's cathode contact. This is not a second polarity channel. | **INCOMPLETE; explicit order-preview hold.** Supply the exact manufacturer PDF and C154439 cache, then prove cathode contact to native pad 1 and recompute PAD-GEOM/PAD-MISMATCH. |

The three C131093 occurrences are byte-congruent in local pad geometry and all are at 0°. The two C85047 occurrences are likewise congruent and at 0°. C6076 has the same native SOT-23-5 geometry; Q_PRE's 180° board rotation preserves all distances and overlap fractions. No repeat-instance exception or board relocation is proposed.

## Proposed adjudications

Only the two positively supported SOT753 PAD-GEOM dispositions are proposed. Each is code- and reference-bounded; neither waives model, body, fetch, render, rotation, polarity, source-board, or order-preview obligations.

```yaml
- lcsc: C131093
  refs: [U_DUMP, U_LDO_EN, U_OE]
  status: PAD-GEOM
  why: "2026-09-11 measured from board SHA-256 7765810d8f9734f0ff893f7411ae80628ccddf5e78a78ee920a3303e9d2a8631, supplied JLC footprint SHA-256 9a59f5a320c2a6bfa4fd017c37da6150b7981982b4daa8cee1cd0fe482e29219, and Nexperia 74LVC1G14 Rev.19 PDF SHA-256 b8f37c700d0fc8374de6d14f0e2caf310c34b480ffab9d63c69bb3b6defbebbf pp.3,11: native pads contain the entire stated SOT753 terminal envelope (0.65..1.50 mm radial, ±0.20 mm lateral) with >=0.175/0.300/0.100 mm inner/outer/lateral margins; 180-degree numbered-pad fit max residual 0.195 mm and minimum JLC-pad overlap 88.991%."
- lcsc: C6076
  refs: [U_TDM_SCH]
  status: PAD-GEOM
  why: "2026-09-11 measured from board SHA-256 7765810d8f9734f0ff893f7411ae80628ccddf5e78a78ee920a3303e9d2a8631, supplied JLC footprint SHA-256 59bc357ad086289224fa9d585330f1765ea09924f9a4ed09bb78595e79a98415, and Nexperia 74LVC1G17 Rev.16 PDF SHA-256 3db133d57486306950ba1140ac13a8a0ea95509dcefb88db36c08423a819b163 pp.3,11: native pads contain the entire stated SOT753 terminal envelope with >=0.175/0.300/0.100 mm inner/outer/lateral margins; 180-degree numbered-pad fit max residual 0.195 mm and minimum JLC-pad overlap 92.500%."
```

## Visual-inspection record

- `2n7002_p1.png`: exact MPN family/order suffix and G/S/D top-view topology inspected; `2n7002_p7.png`: dimensional package and recommended-land table/figure inspected.
- `ao3401_p1.png`: exact AO3401A identity, top/bottom view, G/S/D topology, and top-side mark inspected; absence of dimensional land authority confirmed from the complete extracted PDF text.
- `lvc14_p3.png`, `lvc17_p3.png`: GV/SOT753 transparent top-view pin numbering and functions inspected.
- `lvc14_p11.png`, `lvc17_p11.png`: SOT753 outline, tolerance table, coordinate frame, terminal geometry, and pin numbering inspected.
- `sot23_power_pop_vs_bare.png`, `sot23_reset_pop_vs_bare.png`, `sot753_left_pop_vs_bare.png`, and `sot753_right_pop_vs_bare.png`: all seven scoped bodies are visibly populated over their native pad rows; these images do not overturn the land findings.
- `diode_buck_in_pop_vs_bare.png`: native pad geometry, model stripe, and missing authoritative cathode mapping inspected; hold retained.

This report proposes no native-board or release approval.
