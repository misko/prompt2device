# Independent corrective SOT-23 land-authority review

Review date: **2026-09-11**. Subject raw SHA-256 `c72051977ba8609154ae256ccadd181e9c5800076bd8e718dc982ea9c31c8d0f`; semantic SHA-256 `84d0f1a09dd9bd4fc958c53d146d611842013611bb94b126ebcb96d5137d10da`.

## Result

- **2N7002K-7 / Q_PRE_EN and Q_RST1: FAIL-source-defect.** The stock KiCad `SOT-23` copper does not contain the exact Diodes terminal tolerance envelope. The paired terminals can extend 0.015 mm past the inner pad edge and 0.030 mm past the outer pad edge in the tangential direction. Adopt the exact Diodes suggested land given below at the existing component origins and rotations.
- **AO3401A / Q_PRE: PASS-supported-adjudication for copper lands.** A newly retrieved exact AOS authority chain links AO3401A to AOS SOT23 package outline PO-00001 version N. Although the generic KiCad land differs from AOS's 0.80 mm square recommendation, it contains the complete AOS terminal tolerance envelope with at least 0.050 mm tangential, 0.500 mm inner-radial, and 0.175 mm outer-radial copper margin. No AO3401A land change is justified.

This is a source judgment, not acceptance of a future generated board. No live source or board was edited.

## Exact authority and coordinate frame

The native footprint frame has the paired row at `x < 0`: pin 1 at `(-x,-y)`, pin 2 at `(-x,+y)`, and the single pin 3 at `(+x,0)`. Rotating each manufacturer top-view drawing 90 degrees clockwise produces the native frame: `G/1 -> (-x,-y)`, `S/2 -> (-x,+y)`, `D/3 -> (+x,0)`. There is no mirror.

The hash-bound board has Q_PRE_EN at `(39.86,57.9)`, rotation 0 degrees; Q_RST1 at `(109.5,73.5)`, rotation 0 degrees; and Q_PRE at `(44.02,58.1)`, rotation 180 degrees. All three embed the same native pads: pin 1 `(-0.9375,-0.95)`, pin 2 `(-0.9375,+0.95)`, pin 3 `(+0.9375,0)`, each `1.475 x 0.600 mm`. Origins, rotations, pin numbers, and electrical functions must remain unchanged.

For 2N7002K-7, the controlling input is `parts/2N7002K-7/2N7002K_DS30896_Rev20-2.pdf`, SHA-256 `669e5d68d6458e0879d7396416bdcdb3ef9966ea60f054773d4c891d735aa818`, size 539413. Page 1 explicitly includes ordering suffix `2N7002K-7`, SOT23, and physical `G/S/D = 1/2/3`; page 7 supplies both the package tolerances and suggested land.

For AO3401A, the exact supplied datasheet `parts/AO3401A/AO3401A_Rev3.1.pdf`, SHA-256 `0d8e3261ae280e007b5837fff60c55142f2d92af71edc4d02aee6f7a760a785c`, size 326568, fixes the exact MPN, SOT23 package, pin-1 body mark, and `G/S/D = 1/2/3`. The public AOS product page retrieved at 2026-09-11T18:56:14.357837Z names AO3401A, package SOT23, dimensions 2.90x2.80, and directly links its package PDF. The downloaded package PDF is AOS document PO-00001 version N, SHA-256 `b6fac64d55f133ce74dd85ddddc618c3d5408e9531cb21e660f6a8ef3d8c5408`, size 276341. Proposed committed authority path: `parts/AO3401A/AOS_PO-00001N_SOT23.pdf`; source URL: `https://www.aosmd.com/sites/default/files/res/package/SOT23.pdf`. The retained exact-MPN chain is `AO3401A_product.html` -> `AO3401A_product_chain.json` -> that PDF. The separately downloaded live AO3401A datasheet is byte-identical to the supplied one.

## Terminal-envelope analysis

The generic native pad covers radial distances 0.200..1.675 mm from the body center. Its positive paired tangential span is 0.650..1.250 mm; the negative side is symmetric.

Diodes page 7 gives `E=2.25..2.55`, `E1=1.20..1.40`, `e1=1.78..2.05`, and `b=0.30..0.51 mm`. The positive paired terminal can therefore occupy `e1_min/2 - b_max/2 = 0.635 mm` through `e1_max/2 + b_max/2 = 1.280 mm`. The native pad begins at 0.650 and ends at 1.250 mm, leaving 0.015 and 0.030 mm uncovered. This independently confirms the prior defect; it does not assume that every difference from a recommended pattern is a defect.

The Diodes suggested land gives `C=2.0`, `X=0.8`, `X1=1.35`, `Y=0.9`, `Y1=2.9 mm`. In the native frame these are 0.90 x 0.80 mm rectangular pads at `(-1.00,-0.95)`, `(-1.00,+0.95)`, and `(+1.00,0)`. The paired terminal envelope then has minimum inner/outer tangential margins 0.085/0.070 mm and inner/outer radial margins 0.050/0.175 mm.

AOS PO-00001N gives `E=2.60..3.00`, `E1=1.40..1.80`, `e1=1.90 BSC`, and `b=0.30..0.50 mm`. Its radial terminal envelope is 0.700..1.500 mm, fully inside the native 0.200..1.675 mm pad span. Each fixed paired center is at `y=+/-0.950`; the maximum half lead width is 0.250 mm and the native half pad width is 0.300 mm, leaving 0.050 mm on each tangential side. AOS recommends 0.80 mm square pads with 2.40 mm row-center spacing and 0.95 mm from the symmetry axis to each paired center, but complete tolerance coverage proves the generic land remains valid.

The embedded generic `F.Fab` body is 2.90 x 1.30 mm. That matches the Diodes nominal body but is narrower than the AOS nominal 2.90 x 1.60 mm body. The AO3401A copper adjudication does not make that generic fab graphic an AOS dimensional authority; if exact assembly drawing semantics are required, its fab body should be corrected separately while retaining the accepted copper.

## Proposed source correction for 2N7002K-7

Add the following project-local footprint as `project/03_src/lib/crow_audio_carrier.pretty/Diodes_2N7002K_SOT23_Exact.kicad_mod`, then assign it only to Q_PRE_EN and Q_RST1. The fab polygon uses Diodes nominal `D=2.90` and `E1=1.30 mm` and chamfers the pin-1 corner. The courtyard is a rectangular 0.25 mm excess around the larger of the maximum body and recommended copper, rounded outward to the 0.05 mm grid: `x=+/-1.70`, `y=+/-1.75 mm`. The silkscreen triangle between the paired pads points toward pin 1. The existing correct stock SOT-23 STEP reference and zero offset/rotation/scale are unchanged. KiCad 10 successfully reopened and upgraded this exact module.

```kicad_mod
(footprint "Diodes_2N7002K_SOT23_Exact"
  (version 20241229)
  (generator "source_author")
  (layer "F.Cu")
  (descr "Diodes 2N7002K SOT23 exact suggested land, DS30896 Rev.20-2 page 7")
  (tags "Diodes 2N7002K SOT23")
  (attr smd)
  (fp_text reference "REF**" (at 0 -2.10) (layer "F.SilkS") (effects (font (size 0.7 0.7) (thickness 0.12))))
  (fp_text value "2N7002K" (at 0 2.10) (layer "F.Fab") (effects (font (size 0.7 0.7) (thickness 0.10))))
  (fp_line (start -0.76 -1.56) (end 0.76 -1.56) (stroke (width 0.12) (type default)) (layer "F.SilkS"))
  (fp_line (start -0.76 -1.56) (end -0.76 -1.45) (stroke (width 0.12) (type default)) (layer "F.SilkS"))
  (fp_line (start 0.76 -1.56) (end 0.76 -0.51) (stroke (width 0.12) (type default)) (layer "F.SilkS"))
  (fp_line (start 0.76 0.51) (end 0.76 1.56) (stroke (width 0.12) (type default)) (layer "F.SilkS"))
  (fp_line (start 0.76 1.56) (end -0.76 1.56) (stroke (width 0.12) (type default)) (layer "F.SilkS"))
  (fp_line (start -0.76 1.56) (end -0.76 1.45) (stroke (width 0.12) (type default)) (layer "F.SilkS"))
  (fp_poly (pts (xy -1.30 -0.38) (xy -1.06 -0.05) (xy -1.54 -0.05)) (stroke (width 0.12) (type default)) (fill solid) (layer "F.SilkS"))
  (fp_poly (pts (xy -0.65 -1.125) (xy -0.325 -1.45) (xy 0.65 -1.45) (xy 0.65 1.45) (xy -0.65 1.45)) (stroke (width 0.10) (type default)) (fill none) (layer "F.Fab"))
  (fp_rect (start -1.70 -1.75) (end 1.70 1.75) (stroke (width 0.05) (type default)) (fill none) (layer "F.CrtYd"))
  (pad "1" smd rect (at -1.00 -0.95) (size 0.90 0.80) (layers "F.Cu" "F.Paste" "F.Mask"))
  (pad "2" smd rect (at -1.00 0.95) (size 0.90 0.80) (layers "F.Cu" "F.Paste" "F.Mask"))
  (pad "3" smd rect (at 1.00 0) (size 0.90 0.80) (layers "F.Cu" "F.Paste" "F.Mask"))
  (model "${KICAD10_3DMODEL_DIR}/Package_TO_SOT_SMD.3dshapes/SOT-23.step" (offset (xyz 0 0 0)) (scale (xyz 1 1 1)) (rotate (xyz 0 0 0)))
)
```

After root authors the source change, normal regeneration must demonstrate that Q_PRE_EN and Q_RST1 retain their exact origins, 0-degree rotations, pad numbers/nets, and model transform. Re-run footprint resolution, DRC, pad/mask/paste checks, and board renders on the newly generated board. Those future checks are not satisfied by this read-only review.

## Visual inspection

`diodes_p1.png` was inspected for the exact `2N7002K-7` ordering row, SOT23 top-view G/S/D topology, and no-mirror mapping. `diodes_p7.png` was inspected for the dimensional outline, units, and all five suggested-land dimensions. `ao3401a_p1.png` was inspected for exact MPN, package name, top/bottom views, pin-1 mark, and G/S/D topology. `aos_sot23.png` was inspected for document identity PO-00001 version N, millimeter units, full dimensional table, and the 0.80/0.95/2.40 mm recommended land. No NTS drawing was scaled; every numeric conclusion comes from printed dimensions.
