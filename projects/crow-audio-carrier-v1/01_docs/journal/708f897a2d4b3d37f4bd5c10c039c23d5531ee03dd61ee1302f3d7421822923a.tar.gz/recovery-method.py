from pathlib import Path
import sys,json,hashlib
N=Path('/tmp/carrier-rj45-20260912');R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet
from pipeline_runtime import close_agent_attempt
name='rj45-top-only-correction1';m=json.loads((N/(name+'-opened.json')).read_text());D=Path(m['project']);E=TaskEnvelope.from_json(Path(m['envelope']).read_text());S=Path(m['scratch_dir'])
event={'host':'collaboration','agent_id':m['agent_id'],'state':'error','envelope_sha256':m['envelope_sha256'],'cleanup':'unknown','detail':'Actual host FINAL reports provider usage limit and failed agent turn; five declared delivery outputs absent. No successful engineering/delivery claim. Root recovers durable scratch evidence separately.'}
(N/(name+'-host-error.json')).write_text(json.dumps(event,indent=2)+'\n');a=close_agent_attempt(E,cwd=D,event=event);valid,errs=verify_input_packet(E,D);assert valid,errs
files={};changes=[]
for p in S.rglob('*'):
 if not p.is_file() or p.is_symlink() or '__pycache__' in p.parts or p.suffix=='.pyc':continue
 rel=p.relative_to(S)
 if rel.parts[0]=='work':
  wrel=p.relative_to(S/'work');parts=wrel.parts
  if parts[0]!='projects':continue
  if len(parts)<3:continue
  if parts[2] in ['03_src','02_parts','01_docs']:
   live=R/wrel
   if live.is_file() and live.read_bytes()==p.read_bytes():continue
   if p.suffix not in ['.yaml','.yml','.py','.md','.json','.sh']:continue
   before=D/'input'/wrel
   if not before.exists():before=R/wrel
   changes.append({'path':wrel.as_posix(),'before_sha256':hashlib.sha256(before.read_bytes()).hexdigest() if before.is_file() else None,'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
   files['source_candidate/'+wrel.as_posix()]=str(p)
   if before.is_file():files['before/'+wrel.as_posix()]=str(before)
   continue
  if parts[2] not in ['04_kicad','06_build']:continue
  if p.suffix in ['.gz','.zip','.step','.wrl']:continue
 if p.suffix in ['.gz','.zip']:continue
 files['scratch/'+rel.as_posix()]=str(p)
for p in Path(m['envelope']).parent.iterdir():
 if p.is_file():files['allocation/'+p.name]=str(p)
record={'delivery_status':a.status,'frozen_inputs_verified':len(E.input_packet),'source_changes':changes,'declared_outputs_present':[],'engineering':'INCOMPLETE; provider error before handback. Native candidate3 exists; no candidate4 or route pilot. Recovered author analytical options and failures are unreviewed. No live source adopted.'}
(N/(name+'-recovery.json')).write_text(json.dumps(record,indent=2)+'\n');files['RECOVERY.json']=str(N/(name+'-recovery.json'));files['recovery-method.py']=str(Path(__file__));files['host-error.json']=str(N/(name+'-host-error.json'))
spec={'name':name+'-provider-recovery','project':'crow-audio-carrier-v1','scope':'Actual provider ERROR interrupted source owner before all five handback outputs. Root separately verifies942frozeninputs and preserves recovered exact changedsource before/postimages, nativecandidate3, full raw DRC/classification, failedprep/path checks, analytical alternatives, methods/views/runtime. Recovery is not author delivery PASS, independent acceptance or permission for candidate4. Cumulative3nativecandidates/0routingpilots; liveboardsunchanged.','files':files};(N/(name+'-recovery-spec.json')).write_text(json.dumps(spec,indent=2)+'\n');print(json.dumps({'status':a.status,'files':len(files),'changes':changes},indent=2))
