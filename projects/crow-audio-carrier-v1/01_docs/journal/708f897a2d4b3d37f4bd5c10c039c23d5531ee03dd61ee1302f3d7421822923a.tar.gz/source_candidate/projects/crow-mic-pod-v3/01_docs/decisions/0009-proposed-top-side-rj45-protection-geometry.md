---
id: 0009
date: 2026-09-13
status: proposed
---
# 0009 — proposed top-side RJ45 protection geometry

## Context

The accepted top-only manufacturing decision reopens the prior underside connector cell. This proposal supplies explicit owning geometry contracts and preserves the old controls. It remains INCOMPLETE.

## Options

Flipping beneath the jack is physically invalid. Retaining bottom SMD violates the user requirement. A bounded rear-side top clamp and side fuse is the selected source proposal; changing jack/cord/pinmap or weakening transient protection was not considered.

## Decision

The exact jack and patch cord, pin map, electrical graph, fitted population, fault/current/voltage limits, trace-width floors and two-sided copper capability are unchanged. All fitted SMD is intended on F.Cu, including manual and consigned SMD. No bottom-assembly exception is introduced.

Primary constraints: TI SLLSEG9C section10.1/p11 requests connector-near placement, straight protected traces, rounded corners and separation of struck/unprotected conductors; Figure12/p12 shows no IO stubs and a local ground via. The stored exact primary PDF and its actual page12 image were read. Source: https://www.ti.com/lit/ds/symlink/tpd2e2u06.pdf . These are layout requirements, not a published 4.2mm or 9.0mm system guarantee. Jack drawing001.003 p1 and native WR-MJ26c geometry fix the shell and tails: https://www.we-online.com/components/products/datasheet/615008160221.pdf .

The nominal shell is local x[-3.93,11.07],y[-6.36,7.09]mm. Pin5 at(4.08,0) has nearest shell edge6.36mm; rear7.09mm. The conductor lies inside the shell, so any top SMD clamp outside the occupied shell cannot retain a4.0mm center or4.2mm path budget. Added board width cannot shorten that intrinsic distance. Free EMI fingers reach x[-5.058081,12.218081] and remain included by the unchanged native footprint/model. Front placement conflicts with the mouth/board-edge service space. Side placement is obstructed by the locating-hole and spring/body geometry and does not provide a<4.2mm pin5 path.

The selected rear cell uses U center local(2.5,8.89),180degrees relative to a north-facing jack. Its nominal body-to-shell rear gap is1.00mm; nearest SMD copper-to-shell rear gap1.125mm; courtyard centerline gap0.35mm. These are nominal CAD quantities, not installed tolerance or rework qualification. In this orientation the courtyard-limited rear center would be y>8.54mm. This candidate adds0.35mm nominal courtyard separation. It is a bounded feasible pod construction, not proof of globally shortest route or a qualified rework-tool envelope. Jack±0.15mm dimensional tolerances and SOT-553 maximum body/tail tolerances must remain in independent body/service review.

Proposed electrical geometry contracts: F.Cu-only, no via before each clamp; AUDIO+ center<=8.6mm, routed prefix<=9.0mm; AUDIO- center<=5.7mm, prefix<=7.5mm. Carrier entry-ESD copper-gap ceiling<=7.7mm. These ceilings round the measured pod center8.434729/5.538173mm and native copper gaps7.587931/4.662686mm. Saved pod rounded0.35mm-radius prefixes measure8.719085/6.991305mm and have minimum measured local foreign-copper gap0.195001mm, above the unchanged0.127mm board floor. They are proposed engineering budgets, not additional manufacturer protection ratings. Independent review must decide whether the longer unavoidable unprotected lead remains appropriate for the existing system ESD requirement. No transient-protection sufficiency or first-article success is claimed.

Each IO enters the selected clamp pad before a separate post-clamp launch to its through via. Native pod contact analysis finds exactly one outside-prefix same-net track contact per prefix, at that clamp pad center; no off-pad pre-clamp branch or prefix via exists. The post-clamp vias intentionally await downstream routing. A0.50mm wide,0.85mm long F.Cu GND launch goes to a dedicated nearby through via. Native pod fill connects it to F.Cu and B.Cu ground and J1 pins2/6/8; shell9/10 stay separate. Figure12 supports a local return via, but the drawing and graph do not prove event impedance or enclosure ESD immunity.

The old owner YAML is retained as exact negative controls in the source-task evidence. Proposed YAML replaces only the identified placement geometry budgets/layer; prefix targets and no-stub intent are unchanged. Fresh independent source review is mandatory before any adoption. No route campaign, source adoption, release or ordering authorization results from this proposal.

## Consequences

Pod outline remains60x40mm and J1 stays(45.5,25.86,0); only fitted component U3 moves from bottom(49.07,27.86,180 native) to top(48.0,34.75,180). Source file before flip convention was U3 orientation0 on bottom. Native candidate has31/31 fitted SMD on top and0 bottom, including manually fitted parts; THT/copper-only items are separately enumerated. All44native footprints retain exact footprint and pad/net identities.

Source preparation emitted94copper primitives with0refused. Full-severity native DRC/refill/parity reports6dangling seed warnings,33opens,0parity; each exact endpoint is classified in the source-task evidence. The saved C10.2 GND pocket remains an explicit open; the historical R13 escape/C10 rescue proposal was not adopted. No whole-board routing or DRC acceptance is claimed.

The unchanged shared critical-path checker was run against the exact saved pod board with both old and proposed owner contracts. Both calls refuse AUDIO_P arc contacts because the existing graph adapter does not support PCB_ARC. Native rounded copper/DRC/contact measurements remain useful author evidence, but neither invocation is a passing contract control or independent gate. Supporting rounded native arcs at that shared checker is separate owning-tool work, not an authorized change in this source task.

Arcs originate in explicit source: candidate2 `03_src/route.yaml` `prep.seed_stubs.stubs[*].arcs`, authored by retained `methods/author2.py`. The unchanged shared `route_and_stitch_generic.py:p_seed_stubs` emits each declaration as nativePCB_ARC; no automatic prep rounding is involved. Each north-side cell has twoAUDIO+ and threeAUDIO− tangent fillets of nominal0.35mm radius, transformed180degrees for the south bank. Exact native/source endpoint rounding is retained in the measurement files.

The earlier source uses straight/chamfered polyline primitives with the same endpoints, clamp-pad-first contact, post-clamp vias and ground launch. Its analytic centerline lengths are8.749330265mm AUDIO+ and7.172201295mm AUDIO−. No candidate1prepared-board proof exists. Returning directly to those sharp/chamfered corners is not an unexamined substitute forTI's rounded-corner guidance. A supported straight-segment representation could instead approximate each current rounded fillet using chords<=0.05mm: at nominalR0.35mm, maximum sagitta is0.000893999mm. This changes the physical source copper only within a stated tolerance and retains every endpoint; it does not hide or filter arcs from a checker. Native clearance, pad contact, no-stub topology and TI-layout judgment still require a new owning-source trial after independentD-BACK. This is read-only analysis: no source3 or native trial occurred. Shared critical-path acceptance remains owed.

**Preferred supported alternative for independent reassessment:** retain candidate1's original straight/chamfered source paths. Root explicitly prefers that already-supported native representation; fine chord tessellation is not proposed implementation work and no broad checker change is requested. Source comparison shows the same first/last prefix endpoints for both IOs and byte-equivalent source declarations for both post-clamp launches and the GND launch. Candidate1 analytic lengths8.749330/7.172201mm fit the proposed9.0/7.5mm routed bounds, and unchanged U3/J1 poses retain the same pad-center/body geometry. Candidate1 was not prepared or DRC-graded; its sharp/chamfered-corner clearance remains unverified, so candidate2's rounded-copper minimum cannot be transferred. TI Figure12 itself illustrates straight/chamfered routing while section10.1 discusses rounded corners; independent source review must judge the supported layout against the protection intent. Both source representations are preserved and the two-candidate cap stays closed.
