from pathlib import Path
import sys,os,json,shutil
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_runtime import run_stage
S=Path(__file__).resolve().parents[1];slug=sys.argv[1];P=S/'work/projects'/slug;stem=slug.replace('-','_');kind='carrier' if 'carrier' in slug else 'pod';T=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/kicad-pcb/scripts')
env={k:os.environ[k] for k in ['PATH','HOME','LANG'] if k in os.environ};env.update(PYTHONDONTWRITEBYTECODE='1',KICAD10_FOOTPRINT_DIR='/usr/share/kicad/footprints')
def run(name,args,timeout=120):
 n=kind+'-'+name;out=run_stage({'id':n,'work_class':'local','timeout_s':timeout},args,log_path=S/'logs'/f'{n}.log',cwd=P,env=env,console_line_limit=30);(S/'logs'/f'{n}.runtime.json').write_text(json.dumps(out.to_mapping(),indent=2));return out.returncode
assert run('rules-before',['/usr/bin/python3','-B',str(T/'generate_rules_generic.py'),'.'])==0
assert run('prep',['/usr/bin/python3','-B',str(T/'route_and_stitch_generic.py'),'prep','03_src/route.yaml'])==0
# Preserve original placement then promote only deterministic r0 in this scratch work copy for ordinary fill/rules/gates.
place=S/'native-placement'/slug;place.mkdir(parents=True,exist_ok=True)
for p in (P/'04_kicad').glob('*'):
 if p.is_file():shutil.copy2(p,place/p.name)
shutil.copy2(P/'06_build/route/r0.kicad_pcb',P/'04_kicad'/f'{stem}.kicad_pcb')
assert run('fill',['/usr/bin/python3','-B',str(S/'methods/fill.py'),str(P/'04_kicad'/f'{stem}.kicad_pcb')])==0
assert run('rules-last',['/usr/bin/python3','-B',str(T/'generate_rules_generic.py'),'.'])==0
run('saved-fill',['/usr/bin/python3','-B',str(T/'route_and_stitch_generic.py'),'verify-fill','03_src/route.yaml'])
run('drc',['kicad-cli','pcb','drc','--severity-all','--refill-zones','--schematic-parity','--exit-code-violations','--format','json','-o',str(S/f'{kind}-drc.json'),str(P/'04_kicad'/f'{stem}.kicad_pcb')])
run('critical-path',['/usr/bin/python3','-B',str(T/'critical_path_check.py'),str(P/'04_kicad'/f'{stem}.kicad_pcb'),'--config','03_src/rules/critical_paths.yaml','--json',str(S/f'{kind}-critical-path.json')])
