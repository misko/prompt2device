from pathlib import Path
import pcbnew as p,yaml,json,math,hashlib,sys
S=Path(__file__).resolve().parents[1];R=S.parents[3];slug=sys.argv[1];kind='carrier' if 'carrier' in slug else 'pod';P=S/'work/projects'/slug;stem=slug.replace('-','_');bp=P/'04_kicad'/f'{stem}.kicad_pcb';b=p.LoadBoard(str(bp));b.BuildConnectivity();f={q.GetReference():q for q in b.GetFootprints()};base=p.LoadBoard(str(R/'input/projects'/slug/'04_kicad'/f'{stem}.kicad_pcb'));bf={q.GetReference():q for q in base.GetFootprints()}
def xy(q):return [p.ToMM(q.x),p.ToMM(q.y)]
def bb(q):return [p.ToMM(q.GetLeft()),p.ToMM(q.GetTop()),p.ToMM(q.GetRight()),p.ToMM(q.GetBottom())]
def gap(a,z):
 if a.Collide(z,0):return 0.
 lo=0;hi=p.FromMM(500)
 while hi-lo>1:
  m=(lo+hi)//2
  if a.Collide(z,m):hi=m
  else:lo=m
 return p.ToMM(hi)
def desc(q):
 d={'class':q.GetClass(),'uuid':q.m_Uuid.AsString(),'xy':xy(q.GetPosition())}
 if hasattr(q,'GetNetname'):d['net']=q.GetNetname()
 if isinstance(q,p.PAD):d.update(ref=q.GetParentFootprint().GetReference(),pad=q.GetNumber(),size=xy(q.GetSize()),drill=xy(q.GetDrillSize()),layer=q.GetLayerName())
 if isinstance(q,p.PCB_TRACK):
  d.update(layer=q.GetLayerName(),start=xy(q.GetStart()),end=xy(q.GetEnd()))
  if q.GetClass()!='PCB_VIA':d.update(width=p.ToMM(q.GetWidth()),length=p.ToMM(q.GetLength()))
  else:d.update(diameter=p.ToMM(q.GetBoundingBox().GetWidth()),drill=p.ToMM(q.GetDrillValue()) if hasattr(q,'GetDrillValue') else None)
 return d
def identity(q):return {'fpid':q.GetFPID().GetUniStringLibId(),'pads':sorted((x.GetNumber(),x.GetNetname()) for x in q.Pads())}
rows=[]
for ref,q in sorted(f.items()):
 smd=bool(q.GetAttributes()&p.FP_SMD);smdlands=[x.GetNumber() for x in q.Pads() if x.GetAttribute()==p.PAD_ATTRIB_SMD and x.GetNumber()];bare=ref.startswith(('TP','FID')) or ref=='MK1';fitted=(smd or bool(smdlands)) and not bare
 rows.append({'ref':ref,'fpid':q.GetFPID().GetUniStringLibId(),'pose':xy(q.GetPosition())+[q.GetOrientationDegrees()],'layer':q.GetLayerName(),'smd_attribute':smd,'numbered_smd_lands':smdlands,'fitted_smd':fitted,'classification':'fitted SMD including manual/consigned' if fitted else 'bare fiducial/test/capsule wire land' if bare else 'THT/mechanical','identity_matches_baseline':ref in bf and identity(q)==identity(bf[ref]),'pads':[desc(z) for z in q.Pads()]})
pads={ref+'.'+z.GetNumber():z for ref,q in f.items() for z in q.Pads()};tracks=list(b.GetTracks());route=yaml.safe_load((P/'03_src/route.yaml').read_text());prefix=[];launches=[];mech=[]
for i in (range(1,9) if kind=='carrier' else [1]):
 jr=f'J{i}';ur=f'U_ESD{i}' if kind=='carrier' else 'U3';j=f[jr];u=f[ur];jy=xy(j.GetPosition())[1];sg=1 if kind!='carrier' or i<5 else -1
 cj=j.GetCourtyard(p.F_CrtYd);cu=u.GetCourtyard(p.F_CrtYd)
 entry={ 'jack':jr,'clamp':ur,'courtyard_collision':cj.Collide(cu),'courtyard_polygon_gap_mm':gap(cj,cu),'nominal_body_rear_gap_mm':1.0,'nominal_courtyard_centerline_gap_mm':.35,'courtyard_graphic_stroke_gap_mm':.30,'nominal_copper_shell_gap_mm':1.125,'jack_mouth_y':jy-sg*6.36,'clamp_pose':xy(u.GetPosition())+[u.GetOrientationDegrees()],'installed_tolerance_and_solder_rework':'UNKNOWN; no selected tool/placement/seating tolerance scene'}
 if kind=='carrier':entry['fuse_copper_gap_mm']=gap(pads[f'F{i}.2'].GetEffectiveShape(p.F_Cu),pads[jr+'.1'].GetEffectiveShape(p.F_Cu))
 mech.append(entry)
 for leg,jpin,upin in [('P','5','3'),('N','4','5')]:
  st=next(x for x in route['prep']['seed_stubs']['stubs'] if x.get('pin')==jr+'.'+jpin and x.get('net','').startswith('AUDIO_'));segs=[];missing=[]
  for ss in st['segments']:
   for a,z in zip(ss['pts'],ss['pts'][1:]):
    aa=[round(v,3) for v in a];zz=[round(v,3) for v in z];mt=[t for t in tracks if t.GetClass()=='PCB_TRACK' and t.GetNetname()==st['net'] and math.dist(xy(t.GetStart()),aa)<.000002 and math.dist(xy(t.GetEnd()),zz)<.000002]
    if len(mt)!=1:missing.append([aa,zz,len(mt)])
    segs+=mt
  ids={t.m_Uuid.AsString() for t in segs};contacts=[]
  for t in segs:
   for o in tracks:
    if o.m_Uuid.AsString() in ids or o.GetNetname()!=st['net'] or not o.IsOnLayer(p.F_Cu):continue
    if t.GetEffectiveShape(p.F_Cu).Collide(o.GetEffectiveShape(p.F_Cu),0):contacts.append({'prefix':desc(t),'other':desc(o)})
  prefix.append({'from':jr+'.'+jpin,'to':ur+'.'+upin,'net':st['net'],'pad_center_mm':math.dist(xy(pads[jr+'.'+jpin].GetPosition()),xy(pads[ur+'.'+upin].GetPosition())),'native_copper_gap_mm':gap(pads[jr+'.'+jpin].GetEffectiveShape(p.F_Cu),pads[ur+'.'+upin].GetEffectiveShape(p.F_Cu)),'native_prefix_complete':not missing,'native_length_mm':sum(p.ToMM(t.GetLength()) for t in segs) if not missing else None,'primitive_count':len(segs),'missing_segments':missing,'primitives':[desc(t) for t in segs],'nonprefix_contacts':contacts})
 g=pads[ur+'.4'];cn=b.GetConnectivity();connected=[desc(q) for q in cn.GetConnectedItems(g)];drops=[t for t in tracks if t.GetClass()=='PCB_VIA' and t.GetNetname()=='GND' and math.dist(xy(t.GetPosition()),xy(g.GetPosition()))<1]
 zones=[]
 for via in drops:
  for z in b.Zones():
   if z.GetIsRuleArea() or z.GetNetname()!='GND':continue
   for layer in [p.F_Cu,p.In1_Cu,p.In2_Cu,p.B_Cu]:
    if z.IsOnLayer(layer):zones.append({'layer':b.GetLayerName(layer),'islands':z.GetFilledPolysList(layer).OutlineCount(),'via_contact':z.GetFilledPolysList(layer).Collide(via.GetEffectiveShape(layer),0)})
 launches.append({'ground_pad':desc(g),'vias':[desc(t) for t in drops],'connected_items':connected,'jack_ground_pads':[q['pad'] for q in connected if q.get('ref')==jr and q.get('pad') in ['2','6','8']],'zone_contacts':zones})
mounts=[]
for ref in ['H1','H2','H3','H4']:
 if ref not in f:continue
 q=f[ref];court=q.GetCourtyard(p.F_CrtYd);nearest=[]
 for rr,ff in f.items():
  if rr==ref or math.dist(xy(q.GetPosition()),xy(ff.GetPosition()))>25:continue
  c=ff.GetCourtyard(p.F_CrtYd)
  if c.OutlineCount():nearest.append({'ref':rr,'gap_mm':gap(court,c),'collision':court.Collide(c)})
 mounts.append({'ref':ref,'pose':xy(q.GetPosition()),'courtyard_bounds':bb(court.BBox()),'nearest':sorted(nearest,key=lambda z:z['gap_mm'])[:8]})
# Clearances of exact authored AUDIO_P versus NC2 on saved native carrier footprint (analytical tracks only).
refused=[]
if kind=='carrier':
 for st in route['prep']['seed_stubs']['stubs']:
  if not st['net'].startswith('AUDIO_P'):continue
  ix=st['net'][7:];nc=pads[f'U_ESD{ix}.2'];near=[]
  for ss in st.get('segments',[]):
   for a,z in zip(ss['pts'],ss['pts'][1:]):
    sh=p.SHAPE_SEGMENT(p.VECTOR2I_MM(*[round(v,3) for v in a]),p.VECTOR2I_MM(*[round(v,3) for v in z]),p.FromMM(ss['width']));near.append(gap(sh,nc.GetEffectiveShape(p.F_Cu)))
  refused.append({'pin':st.get('pin'),'net':st['net'],'native_NC2':desc(nc),'min_native_gap_mm':min(near),'unchanged_seed_clearance_mm':route['prep']['seed_stubs']['clearance']})
else:
 pad=pads['U3.5'];near=[t for t in tracks if t.GetClass()=='PCB_VIA' and t.GetNetname()=='AUDIO_N'];refused=[{'pad':desc(pad),'via':desc(v),'actual_native_collision':pad.GetEffectiveShape(p.F_Cu).Collide(v.GetEffectiveShape(p.F_Cu),0),'native_edge_gap_mm':gap(pad.GetEffectiveShape(p.F_Cu),v.GetEffectiveShape(p.F_Cu))} for v in near]
res={'board_sha256':hashlib.sha256(bp.read_bytes()).hexdigest(),'artifact_kind':'generated placement; prepare failed and no seed copper saved' if kind=='carrier' else 'prepared and filled native candidate','population':rows,'counts':{'footprints':len(rows),'identity_matches':sum(q['identity_matches_baseline'] for q in rows),'fitted_smd':sum(q['fitted_smd'] for q in rows),'fitted_smd_top':sum(q['fitted_smd'] and q['layer']=='F.Cu' for q in rows),'fitted_smd_bottom':sum(q['fitted_smd'] and q['layer']=='B.Cu' for q in rows),'tracks':len(tracks)},'prefixes':prefix,'ground_launches':launches,'cell_mechanics':mech,'mounts':mounts,'native_failure_diagnosis':refused,'native_items':[desc(t) for t in tracks]}
if kind=='carrier':
 res['R_PWR_PU_gap_mm']=min(gap(a.GetEffectiveShape(p.F_Cu),z.GetEffectiveShape(p.F_Cu)) for a in f['R_PWR_PU'].Pads() for z in f['U_PWR_SENSE'].Pads()) if 'U_PWR_SENSE' in f else 'target in owning dossier must be located'
(S/f'{kind}-native-measurements.json').write_text(json.dumps(res,indent=2));print(json.dumps(res['counts']));print('prefixes',[(q['from'],q['native_length_mm']) for q in prefix]);print('failure diagnosis',[(q.get('pin'),q.get('min_native_gap_mm'),q.get('actual_native_collision'),q.get('native_edge_gap_mm')) for q in refused]);print('mount minima',[(q['ref'],q['nearest'][:1]) for q in mounts])
