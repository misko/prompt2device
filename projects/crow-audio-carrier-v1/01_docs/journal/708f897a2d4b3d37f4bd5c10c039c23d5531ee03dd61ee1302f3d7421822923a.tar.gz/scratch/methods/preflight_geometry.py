from pathlib import Path
import pcbnew as p,yaml,json,math,hashlib
S=Path(__file__).resolve().parents[1];R=S.parents[3];P=S/'work/projects/crow-audio-carrier-v1';f=yaml.safe_load((P/'03_src/floorplan.yaml').read_text());rp=P/'03_src/route.yaml';r=yaml.safe_load(rp.read_text())
# Complete source construction, no native board generation or save.
r['prep']['keepouts']['mounting_holes']['refdes_prefix']='H';r['prep']['keepouts']['npth_pads']={'margin':.25}
for st in r['prep']['seed_stubs']['stubs']:
 if st.get('net','').startswith('POD_12V'):st['net']='12V_POD'+st['net'][7:]
rp.write_text(yaml.safe_dump(r,sort_keys=False,width=120))
b=p.LoadBoard(str(R/'input/projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb'));fps={q.GetReference():q for q in b.GetFootprints()}
def pose(q,x,y,a):
 if q.GetLayer()==p.B_Cu:q.Flip(q.GetPosition(),False)
 q.SetPosition(p.VECTOR2I_MM(x,y));q.SetOrientationDegrees(a)
for i in range(1,9):
 jx,jy,ang=f['placement']['anchors'][f'J{i}'];sg=1 if i<5 else -1
 pose(fps[f'J{i}'],jx,jy,ang);pose(fps[f'F{i}'],jx-sg*9,jy,ang);pose(fps[f'U_ESD{i}'],jx+sg*2.5,jy+sg*8.89,180 if i<5 else 0)
for ref,xy in zip(['H1','H2','H3','H4'],f['board']['mounting_holes']['at']):pose(fps[ref],*xy,0)
pose(fps['FID1'],25,33,0);pose(fps['R_PWR_PU'],32.4,53.94,90)
def vec(q):return p.VECTOR2I_MM(*q)
def xy(q):return [p.ToMM(q.x),p.ToMM(q.y)]
def gap(a,b):
 if a.Collide(b,0):return 0.
 lo=0;hi=p.FromMM(100)
 while hi-lo>1:
  mid=(hi+lo)//2
  if a.Collide(b,mid):hi=mid
  else:lo=mid
 return p.ToMM(hi)
segments=[]
for st in r['prep']['seed_stubs']['stubs']:
 for ss in st.get('segments',[]):
  if ss['layer']!='F.Cu':continue
  for a,z in zip(ss['pts'],ss['pts'][1:]):segments.append((st['net'],st.get('pin'),p.SHAPE_SEGMENT(vec(a),vec(z),p.FromMM(ss['width'])),a,z,ss['width']))
rows=[];holes=[]
for net,pin,shape,a,z,width in segments:
 if not(pin and pin.startswith('F') and net.startswith('12V_POD')):continue
 near=[]
 for ref,q in fps.items():
  for pad in q.Pads():
   if pad.GetNetname()==net or not pad.IsOnLayer(p.F_Cu):continue
   d=gap(shape,pad.GetEffectiveShape(p.F_Cu))
   if d<1:near.append({'ref':ref,'pad':pad.GetNumber(),'net':pad.GetNetname(),'gap_mm':d,'npth':pad.GetAttribute()==p.PAD_ATTRIB_NPTH})
 for n,other,s,aa,zz,ww in segments:
  if n!=net:
   d=gap(shape,s)
   if d<1:near.append({'seed_pin':other,'net':n,'gap_mm':d})
 rows.append({'net':net,'pin':pin,'start':a,'end':z,'width':width,'near':near})
for ref,q in fps.items():
 if ref.startswith('J'):
  for pad in q.Pads():
   if pad.GetAttribute()==p.PAD_ATTRIB_NPTH:
    x,y=xy(pad.GetPosition());rr=p.ToMM(pad.GetDrillSize().x)/2+.25
    rect=p.SHAPE_RECT(vec([x-rr,y-rr]),p.FromMM(2*rr),p.FromMM(2*rr))
    close=[{'pin':pin,'start':a,'end':z,'trace_edge_to_barrier_mm':gap(sh,rect)} for n,pin,sh,a,z,w in segments if pin and pin.startswith('F') and math.dist(a,[x,y])<15]
    holes.append({'ref':ref,'xy':[x,y],'drill_mm':p.ToMM(pad.GetDrillSize().x),'barrier_half_extent':rr,'old_half_extent':3.2,'nearest_fanout_barrier_gap':min([x['trace_edge_to_barrier_mm'] for x in close],default=None)})
res={'scope':'Analytical native footprint and SHAPE_SEGMENT preflight only, no native board save or generation.','fanout_segments':rows,'jack_holes':holes,'min_foreign_gap':min(n['gap_mm'] for row in rows for n in row['near']),'old_mounting_obstacles':20,'new_mounting_obstacles':4,'explicit_all_npth_obstacles':20}
(S/'analytic-fanout-preflight.json').write_text(json.dumps(res,indent=2));print('segments',len(rows),'min foreign gap',res['min_foreign_gap'],'jack holes',len(holes),'min barrier gap',min(x['nearest_fanout_barrier_gap'] for x in holes if x['nearest_fanout_barrier_gap'] is not None));print('net names',sorted({x['net'] for x in rows}))
# Current supplied qualification dependency bytes must still match; no redundant native probe.
allrows=[]
for qfile in (R/'qualification').glob('*.json'):
 q=json.loads(qfile.read_text())
 for path,h in q['dependencies']['files'].items():
  pp=Path(path);actual=hashlib.sha256(pp.read_bytes()).hexdigest() if pp.is_file() else None;allrows.append({'path':path,'expected':h,'actual':actual,'match':actual==h})
(S/'qualification-dependencies.json').write_text(json.dumps({'count':len(allrows),'all_match':all(x['match'] for x in allrows),'rows':allrows},indent=2));print('qualification',len(allrows),all(x['match'] for x in allrows))
