import sys,os,json
from pathlib import Path
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_runtime import run_stage
S=Path(__file__).resolve().parents[1];kind=sys.argv[1];slug='crow-audio-carrier-v1' if kind=='carrier' else 'crow-mic-pod-v3';P=S/'work/projects'/slug
root=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');git=(root/'.git').read_text().strip().split(': ',1)[1]
env={k:os.environ[k] for k in ['PATH','HOME','LANG'] if k in os.environ};env.update(PYTHONDONTWRITEBYTECODE='1',KICAD10_FOOTPRINT_DIR='/usr/share/kicad/footprints',GIT_DIR=git)
mods=['test_rj45_entry_paths','test_ground_connections','test_local_placement_source'] if kind=='carrier' else ['test_check_realized_routes']
res=run_stage({'id':kind+'-source-tests','work_class':'local','timeout_s':120},['/usr/bin/python3','-B','-m','unittest','-v',*mods],log_path=S/'logs'/f'{kind}-source-tests.log',cwd=P/'03_src/tests',env=env,console_line_limit=35);(S/'logs'/f'{kind}-source-tests.runtime.json').write_text(json.dumps(res.to_mapping(),indent=2));sys.exit(res.returncode or 0)
