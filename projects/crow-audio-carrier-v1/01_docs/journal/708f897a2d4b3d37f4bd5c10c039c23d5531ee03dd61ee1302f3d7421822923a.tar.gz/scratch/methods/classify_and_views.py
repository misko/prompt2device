from pathlib import Path
import json,pcbnew as p,math,re,hashlib
from collections import Counter
S=Path(__file__).resolve().parents[1];results={}
def xy(q):return [p.ToMM(q.x),p.ToMM(q.y)]
def polyrows(poly):
 return [[[p.ToMM(poly.Outline(i).CPoint(j).x),p.ToMM(poly.Outline(i).CPoint(j).y)] for j in range(poly.Outline(i).PointCount())] for i in range(poly.OutlineCount())]
for kind,slug,drcfile in [('carrier','crow-audio-carrier-v1','carrier-placement-drc.json'),('pod','crow-mic-pod-v3','pod-drc.json')]:
 bp=S/'work/projects'/slug/'04_kicad'/f'{slug.replace("-","_")}.kicad_pcb';b=p.LoadBoard(str(bp));fps={f.GetReference():f for f in b.GetFootprints()};items=[*b.GetTracks(),*b.GetDrawings(),*b.Zones()]
 for f in b.GetFootprints():items.extend([f,*f.Pads(),*f.GraphicalItems(),f.Reference(),f.Value()])
 index={q.m_Uuid.AsString():q for q in items};d=json.loads((S/drcfile).read_text());out=[]
 for section in ['violations','unconnected_items','schematic_parity']:
  for n,row in enumerate(d[section]):
   witnesses=[]
   for item in row['items']:
    q=index.get(item['uuid']);witnesses.append(dict(item,native_uuid_found=q is not None,native_class=q.GetClass() if q else None,native_position_mm=xy(q.GetPosition()) if q else None))
   typ=row['type'];endpoints=' -> '.join(x['description'] for x in row['items'])
   if section=='unconnected_items':
    category='NAMED_DOWNSTREAM_OPEN';action='Route and regrade these exact native disconnected endpoints: '+endpoints
    if any('Pad 2 [GND] of C10 ' in x['description'] for x in row['items']):category='INHERITED_C10_GROUND_SOURCE_OWED';action='Source-owned C10.2 GND return is still isolated; restore via/return under separate admitted pod source work and prove saved fill.'
    if kind=='carrier':action+='; carrier prep failed, so this placement has no saved deterministic signal/fanout copper and is not a prepared candidate.'
   elif typ=='clearance':category='STALE_PACKAGE_RULE_AREA_SOURCE_DEFECT';action='Move the exact existing pads-only PKG_PAD_ESD scope with its owning clamp in a fresh source correction. Retain0.15mm pad-only authority and0.20mm track clearance; this does not cure launch clearance.'
   elif typ in ['silk_overlap','silk_over_copper']:category='TOP_CLAMP_CAPTION_SOURCE_DEFECT';action='Resolve the named CH caption collision in source and regenerate in a future admitted candidate; no silk waiver or current fix claimed.'
   elif typ in ['track_dangling','via_dangling']:category='NAMED_DOWNSTREAM_SEED_OPEN';action='Complete the named seed endpoint route in its owning later source/routing stage: '+endpoints
   else:category='UNRESOLVED_NATIVE_FINDING';action='Independent exact finding judgment owed: '+endpoints
   out.append({'id':kind+'-'+section+'-'+str(n+1),'section':section,'type':typ,'severity':row['severity'],'description':row['description'],'items':witnesses,'classification':category,'disposition':action})
 result={'board_sha256':hashlib.sha256(bp.read_bytes()).hexdigest(),'counts':{sec:len(d[sec]) for sec in ['violations','unconnected_items','schematic_parity']},'rows':out,'all_report_uuid_endpoints_found':all(i['native_uuid_found'] for x in out for i in x['items'])};(S/f'{kind}-drc-classification.json').write_text(json.dumps(result,indent=2));results[kind]=result['counts'];print(kind,result['counts'],'alluuidfound',result['all_report_uuid_endpoints_found'])
 bounds=(24,53,20,39) if kind=='carrier' else (44,51,30,37)
 x0,x1,y0,y1=bounds;scale=55;svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{(x1-x0)*scale}" height="{(y1-y0)*scale}" viewBox="{x0} {y0} {x1-x0} {y1-y0}"><rect x="{x0}" y="{y0}" width="{x1-x0}" height="{y1-y0}" fill="#fafaf7"/>']
 def polygon(points,fill,stroke,width=.02,dash=''):
  coords=' '.join(f'{x},{y}' for x,y in points);svg.append(f'<polygon points="{coords}" fill="{fill}" stroke="{stroke}" stroke-width="{width}" {dash}/>')
 for ref,fp in fps.items():
  x,y=xy(fp.GetPosition())
  if not(x0-7<x<x1+7 and y0-7<y<y1+7):continue
  for points in polyrows(fp.GetCourtyard(p.F_CrtYd)):polygon(points,'none','#b19aca',.025,'stroke-dasharray=".15 .15"')
  for pad in fp.Pads():
   if not pad.IsOnLayer(p.F_Cu):continue
   for points in polyrows(pad.GetEffectivePolygon(p.F_Cu)):polygon(points,'#debd74','#534529')
   px,py=xy(pad.GetPosition())
   if pad.GetDrillSizeX()>0:svg.append(f'<circle cx="{px}" cy="{py}" r="{p.ToMM(pad.GetDrillSizeX())/2}" fill="white" stroke="#555" stroke-width=".025"/>')
   if pad.GetNumber():svg.append(f'<text x="{px}" y="{py+.10}" text-anchor="middle" font-size=".28" fill="#151a20">{pad.GetNumber()}</text>')
  svg.append(f'<text x="{x}" y="{y+.8}" text-anchor="middle" font-size=".35" fill="#333">{ref}</text>')
 for track in b.GetTracks():
  if not track.IsOnLayer(p.F_Cu):continue
  a,z=xy(track.GetStart()),xy(track.GetEnd());color={'AUDIO_P':'#df403b','AUDIO_N':'#346abd','GND':'#339967'}.get(track.GetNetname(),'#bc4d37')
  if track.GetClass()=='PCB_VIA':
   rad=p.ToMM(track.GetBoundingBox().GetWidth())/2;drill=p.ToMM(track.GetDrillValue())/2
   svg.append(f'<circle cx="{a[0]}" cy="{a[1]}" r="{rad}" fill="{color}" stroke="black" stroke-width=".015"/><circle cx="{a[0]}" cy="{a[1]}" r="{drill}" fill="white"/>')
  else:svg.append(f'<line x1="{a[0]}" y1="{a[1]}" x2="{z[0]}" y2="{z[1]}" stroke="{color}" stroke-width="{p.ToMM(track.GetWidth())}" stroke-linecap="round"/>')
 svg.append('</svg>');(S/'views'/f'{kind}-local-native.svg').write_text(''.join(svg))
(S/'view-review-notes.md').write_text('Opened all four actual KiCad top/bottom renders. Carrier and pod show fitted SMD only on top; bottom views show THT solder lands/vias without fitted SMD. Carrier J9 body is visibly inset from the new west edge; this image does not establish mate/latch/tool access. Top carrier caption crowding is visible, and native DRC independently locates CH1–8 collisions. Pod clamp is top behind jack; the separate native local-copper view exposes the AUDIO-minus annulus/land overlap. No complete prepared carrier copper exists. Rendered models resolve333/333carrier and32/32pod; model visibility is not assembly/tolerance/service approval.\n')
