from pathlib import Path
import pcbnew as p,yaml,json,math,hashlib
S=Path(__file__).resolve().parents[1];rows=[]
def vec(q):return p.VECTOR2I_MM(*q)
def xy(q):return [p.ToMM(q.x),p.ToMM(q.y)]
def gap(a,b):
 if a.Collide(b,0):return 0.
 lo=0;hi=p.FromMM(100)
 while hi-lo>1:
  m=(lo+hi)//2
  if a.Collide(b,m):hi=m
  else:lo=m
 return p.ToMM(hi)
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 carrier='carrier' in slug;P=S/'work/projects'/slug;bp=P/'04_kicad'/f'{slug.replace("-","_")}.kicad_pcb';before=bp.read_bytes();b=p.LoadBoard(str(bp));f={q.GetReference():q for q in b.GetFootprints()};r=yaml.safe_load((P/'03_src/route.yaml').read_text());shapes=[]
 # A single finite analytical alternative: all AUDIO prefixes/post launches0.20 wide,
 # N post launch goes1.00mm directly rearward from clamp pad, via diameter unchanged.
 for st in r['prep']['seed_stubs']['stubs']:
  entry=st.get('pin','').startswith('J') and st['net'].startswith('AUDIO_');post=st.get('pin','').startswith('U_ESD') or (not carrier and st.get('pin') in ['U3.3','U3.5']);audio=entry or (post and st['net'].startswith('AUDIO_'))
  for ss in st.get('segments',[]):
   if ss['layer']!='F.Cu':continue
   pts=ss['pts'];width=.20 if audio else ss['width']
   if post and st['net'].startswith('AUDIO_N'):
    a=pts[0];sg=1 if not carrier or int(st['net'][7:])<5 else -1;pts=[a,[a[0],a[1]+sg]]
   for a,z in zip(pts,pts[1:]):shapes.append({'net':st['net'],'pin':st.get('pin'),'a':a,'z':z,'width':width,'shape':p.SHAPE_SEGMENT(vec(a),vec(z),p.FromMM(width)),'kind':'track','analytical_changed':audio})
  for via in st.get('vias',[]):
   q=via
   if post and st['net'].startswith('AUDIO_N'):
    a=st['segments'][0]['pts'][0];sg=1 if not carrier or int(st['net'][7:])<5 else -1;q=[a[0],a[1]+sg]
   diameter=st.get('via',r['prep']['seed_stubs']['via'])['size'];shapes.append({'net':st['net'],'pin':st.get('pin'),'a':q,'z':q,'width':diameter,'shape':p.SHAPE_CIRCLE(vec(q),p.FromMM(diameter/2)),'kind':'via','analytical_changed':post and st['net'].startswith('AUDIO_N')})
 target=[q for q in shapes if q['analytical_changed']];near=[]
 for q in target:
  for ref,fp in f.items():
   if math.dist(q['a'],xy(fp.GetPosition()))>12:continue
   for pad in fp.Pads():
    if not pad.IsOnLayer(p.F_Cu) or pad.GetNetname()==q['net']:continue
    d=gap(q['shape'],pad.GetEffectiveShape(p.F_Cu))
    if d<.5:near.append({'owner':q['pin'],'kind':q['kind'],'from':q['a'],'to':q['z'],'width':q['width'],'foreign':ref+'.'+pad.GetNumber(),'foreign_net':pad.GetNetname(),'gap_mm':d})
  for other in shapes:
   if q['net']==other['net'] or math.dist(q['a'],other['a'])>12:continue
   d=gap(q['shape'],other['shape'])
   if d<.5:near.append({'owner':q['pin'],'kind':q['kind'],'from':q['a'],'to':q['z'],'width':q['width'],'foreign_seed':other['pin'],'foreign_net':other['net'],'gap_mm':d})
 via_rows=[]
 for q in target:
  if q['kind']!='via':continue
  ref,num=q['pin'].split('.');pad=next(x for x in f[ref].Pads() if x.GetNumber()==num)
  via_rows.append({'pin':q['pin'],'proposed_via_center':q['a'],'diameter':q['width'],'native_pad_edge_gap_mm':gap(q['shape'],pad.GetEffectiveShape(p.F_Cu)),'pad_size':xy(pad.GetSize()),'pad_center':xy(pad.GetPosition()),'native_pad_contact':q['shape'].Collide(pad.GetEffectiveShape(p.F_Cu),0)})
 assert before==bp.read_bytes()
 rows.append({'board':slug,'scope':'Finite read-only SHAPE_SEGMENT/SHAPE_CIRCLE analytical option only; NO source edit, BOARD save, generator, checker call, routing admission or candidate4. Needs fresh upstream width/launch decision.','signal_width_mm':.20,'new_N_post_rearward_length_mm':1.,'analyzed_primitives':len(target),'min_foreign_gap_mm':min(x['gap_mm'] for x in near),'near_pairs':near,'N_vias':via_rows})
(S/'analytical-next-decision-options.json').write_text(json.dumps(rows,indent=2));print([(q['board'],q['analyzed_primitives'],q['min_foreign_gap_mm'],q['N_vias']) for q in rows])
