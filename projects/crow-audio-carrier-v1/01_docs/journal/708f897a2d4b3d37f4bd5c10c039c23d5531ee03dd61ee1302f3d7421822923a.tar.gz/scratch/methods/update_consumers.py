from pathlib import Path
S=Path(__file__).resolve().parents[1];A=S/'work/projects/crow-audio-carrier-v1/03_src';P=S/'work/projects/crow-mic-pod-v3/03_src'
p=A/'check_analog_paths.py';t=p.read_text();start=t.index('        if row[\'max_length_mm\'] != 4.2',t.index('def validate_entry_paths'));end=t.index('    chassis =',start)
t=t[:start]+'''        positive = net.startswith('AUDIO_P')
        routed, centre = (9.0,8.6) if positive else (7.5,5.7)
        if row['max_length_mm'] != routed or row['max_pad_centre_mm'] != centre or row['layer'] != 'F.Cu' or prefixes[pair]['targets'] != [target]:
            raise PathError(f'{net}: changed protection path limit/layer/target')
        seeds = [x for x in route['prep']['seed_stubs']['stubs'] if x['net'] == net]
        entries = [x for x in seeds if x.get('pin') == pair[0]]
        launches = [x for x in seeds if x.get('pin') == pair[1]]
        if len(seeds) != 2 or len(entries) != 1 or len(launches) != 1:
            raise PathError(f'{net}: missing/duplicate/changed connector prefix or clamp launch seed')
        entry, launch = entries[0], launches[0]
        if entry.get('vias') or entry.get('arcs') or set(entry) != {'net','pin','segments'} or len(entry.get('segments',[])) != 1:
            raise PathError(f'{net}: changed connector prefix seed geometry')
        if set(launch) != {'net','pin','segments','vias'} or len(launch.get('segments',[])) != 1 or len(launch.get('vias',[])) != 1:
            raise PathError(f'{net}: changed post-clamp launch inventory')
        if any(x['layer'] != 'F.Cu' or x['width'] != .26 for seed in seeds for x in seed['segments']):
            raise PathError(f'{net}: connector prefix seed layer/width differs from admitted0.26mm')
        # The exact admitted cell coordinates bind source pad contact; the saved
        # copper checker remains the independent dominance/contact authority.
        n = int(net[7:]); sg = 1 if n < 5 else -1
        jx,jy = (38.+32*(n-1),25.86) if n < 5 else (43.+32*(n-5),114.14)
        def point(q): return [round(jx+sg*q[0],4),round(jy+sg*q[1],4)]
        local = [[4.08,0],[4.08,5.64],[3.2125,6.5075],[3.2125,8.39]] if positive else [[3.06,4],[3.06,4.84],[.9,7],[.9,9.04],[1.25,9.39],[1.7875,9.39]]
        post = [[3.2125,8.39],[4.1,8.39]] if positive else [[1.7875,9.39],[2.35,9.39]]
        if entry['segments'][0]['pts'] != [point(q) for q in local] or launch['segments'][0]['pts'] != [point(q) for q in post] or launch['vias'] != [point(post[-1])]:
            raise PathError(f'{net}: changed/off-pad connector prefix or post-clamp launch')
''' +t[end:];p.write_text(t)
p=A/'tests/test_ground_connections.py';t=p.read_text().replace('BOTTOM_TARGETS','CLAMP_TARGETS').replace('# helper is top-only and cannot establish underside clamp placement.','# helper plus this explicit native witness establishes all eighteen top lands.').replace('expected=pcbnew.B_Cu if pin in CLAMP_TARGETS else pcbnew.F_Cu','expected=pcbnew.F_Cu').replace('pcbnew.F_Cu if pin in CLAMP_TARGETS else pcbnew.B_Cu','pcbnew.B_Cu');p.write_text(t)
p=A/'tests/test_local_placement_source.py';t=p.read_text().replace('[36.0+32*i,','[38.0+32*i,').replace('[45.0+32*i,','[43.0+32*i,').replace("{'x0':20., 'y0':20., 'x1':170., 'y1':120.}","{'x0':16., 'y0':20., 'x1':170., 'y1':120.}").replace('[[25.,25.],[165.,25.],[25.,115.],[165.,115.]]','[[21.,25.],[165.,25.],[21.,115.],[165.,115.]]').replace('[[29.,29.],[161.,29.],[29.,111.]]','[[25.,33.],[161.,29.],[29.,111.]]').replace('F# BOT','F# PTC').replace("b.place_cfg['sides'][ref], 'bottom'","b.place_cfg['sides'].get(ref,'top'), 'top'").replace("{ref} BOT","{ref} PTC").replace('F1 BOT','F1 PTC').replace('F2 BOT','F2 PTC').replace("else: b.place_cfg['sides']['F1']='top'","else: b.place_cfg['sides']['F1']='bottom'");p.write_text(t)
p=A/'tests/test_rj45_entry_paths.py';t=p.read_text().replace("c['short_paths'][0]['layer']='F.Cu'","c['short_paths'][0]['layer']='B.Cu'").replace("r['prep']['seed_stubs']['stubs'][0]['vias']=[{'at':[1,1]}]","next(x for x in r['prep']['seed_stubs']['stubs'] if x.get('pin')=='J1.5')['vias']=[[1,1]]").replace("r['prep']['seed_stubs']['stubs'].pop(0)","r['prep']['seed_stubs']['stubs'].remove(next(x for x in r['prep']['seed_stubs']['stubs'] if x.get('pin')=='J1.5'))").replace("=4.3","=9.001").replace("=4.1","=8.601").replace('independent_native_bottom_pads','independent_native_top_pads').replace("'SOT-553',True","'SOT-553',False").replace("if x['net'].startswith('AUDIO_')","if x['net'].startswith('AUDIO_') and x['pin'].startswith('J')").replace("math.dist(pads[start],pads[end]),4.","math.dist(pads[start],pads[end]),path['max_pad_centre_mm']").replace("zip(pts,pts[1:])),4.2","zip(pts,pts[1:])),path['max_length_mm']")
# Named negative controls ensure separate post-clamp support is never a blanket extra-row waiver.
pos=t.index('    def test_grounded_shell')
t=t[:pos]+'''    def test_extra_ghost_duplicate_and_offpad_seeds_fail(self):
        for defect in ('extra','ghost','duplicate','offpad','post-via'):
            r=copy.deepcopy(self.route)
            entry=next(x for x in r['prep']['seed_stubs']['stubs'] if x.get('pin')=='J1.5')
            launch=next(x for x in r['prep']['seed_stubs']['stubs'] if x.get('pin')=='U_ESD1.3')
            if defect=='extra':r['prep']['seed_stubs']['stubs'].append(dict(net='AUDIO_P1',pin='TP_GHOST.1',segments=[]))
            if defect=='ghost':launch['pin']='U_ESD1.2'
            if defect=='duplicate':r['prep']['seed_stubs']['stubs'].append(copy.deepcopy(entry))
            if defect=='offpad':entry['segments'][0]['pts'][-1][0]+=.1
            if defect=='post-via':launch['vias'][0][0]+=.1
            with self.assertRaises(checker.PathError):checker.validate_entry_paths(self.config,r,self.pins)
''' +t[pos:];p.write_text(t)
p=P/'tests/test_check_realized_routes.py';t=p.read_text();a=t.index('        required =');z=t.index('        return checker.PathResult(',a);t=t[:a]+'        required = "F.Cu"\n'+t[z:];t=t.replace('on_front_layer_fails','on_back_layer_fails').replace('instead of B.Cu only','instead of F.Cu only')
for name in ['test_audio_positive_prefix_on_back_layer_fails','test_audio_negative_prefix_on_back_layer_fails']:
 a=t.index('    def '+name);z=t.index('\n    def ',a+5);part=t[a:z].replace('frozenset({"F.Cu"})','frozenset({"B.Cu"})');t=t[:a]+part+t[z:]
t=t.replace('test_audio_pad_centre_over_four_mm_fails','test_audio_pad_centre_over_positive_budget_fails').replace('frozenset({"B.Cu"}), 4.001','frozenset({"F.Cu"}), 8.601').replace('test_audio_realized_copper_over_4_2_mm_fails','test_audio_realized_copper_over_negative_budget_fails').replace('"AUDIO_N", 4.201','"AUDIO_N", 7.501').replace('frozenset({"B.Cu"}), 1.935073','frozenset({"F.Cu"}), 5.538173').replace('exceeds 4.200 mm','exceeds 7.500 mm')
a=t.index('    def test_branch_before_clamp_fails');z=t.index('\n    def ',a+5);part=t[a:z].replace('frozenset({"B.Cu"})','frozenset({"F.Cu"})');t=t[:a]+part+t[z:];p.write_text(t)
print('Project policy consumers and five existing test files updated; no physical source geometry changed.')
