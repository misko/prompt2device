from pathlib import Path
import json,pcbnew as p,math,re,hashlib
from collections import Counter
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Circle
S=Path(__file__).resolve().parents[1];results={}
def xy(q):return [p.ToMM(q.x),p.ToMM(q.y)]
def polyrows(poly):
 return [[[p.ToMM(poly.Outline(i).CPoint(j).x),p.ToMM(poly.Outline(i).CPoint(j).y)] for j in range(poly.Outline(i).PointCount())] for i in range(poly.OutlineCount())]
for kind,slug,drcfile in [('carrier','crow-audio-carrier-v1','carrier-placement-drc.json'),('pod','crow-mic-pod-v3','pod-drc.json')]:
 bp=S/'work/projects'/slug/'04_kicad'/f'{slug.replace("-","_")}.kicad_pcb';b=p.LoadBoard(str(bp));fps={f.GetReference():f for f in b.GetFootprints()};items=[*b.GetTracks(),*b.GetDrawings(),*b.Zones()]
 for f in b.GetFootprints():items.extend([f,*f.Pads(),*f.GraphicalItems(),f.Reference(),f.Value()])
 index={q.m_Uuid.AsString():q for q in items};d=json.loads((S/drcfile).read_text());out=[]
 for section in ['violations','unconnected_items','schematic_parity']:
  for n,row in enumerate(d[section]):
   witnesses=[]
   for item in row['items']:
    q=index.get(item['uuid']);witnesses.append(dict(item,native_uuid_found=q is not None,native_class=q.GetClass() if q else None,native_position_mm=xy(q.GetPosition()) if q else None))
   typ=row['type'];endpoints=' -> '.join(x['description'] for x in row['items'])
   if section=='unconnected_items':
    category='NAMED_DOWNSTREAM_OPEN';action='Route and regrade these exact native disconnected endpoints: '+endpoints
    if any('Pad 2 [GND] of C10 ' in x['description'] for x in row['items']):category='INHERITED_C10_GROUND_SOURCE_OWED';action='Source-owned C10.2 GND return is still isolated; restore via/return under separate admitted pod source work and prove saved fill.'
    if kind=='carrier':action+='; carrier prep failed, so this placement has no saved deterministic signal/fanout copper and is not a prepared candidate.'
   elif typ=='clearance':category='STALE_PACKAGE_RULE_AREA_SOURCE_DEFECT';action='Move the exact existing pads-only PKG_PAD_ESD scope with its owning clamp in a fresh source correction. Retain0.15mm pad-only authority and0.20mm track clearance; this does not cure launch clearance.'
   elif typ in ['silk_overlap','silk_over_copper']:category='TOP_CLAMP_CAPTION_SOURCE_DEFECT';action='Resolve the named CH caption collision in source and regenerate in a future admitted candidate; no silk waiver or current fix claimed.'
   elif typ in ['track_dangling','via_dangling']:category='NAMED_DOWNSTREAM_SEED_OPEN';action='Complete the named seed endpoint route in its owning later source/routing stage: '+endpoints
   else:category='UNRESOLVED_NATIVE_FINDING';action='Independent exact finding judgment owed: '+endpoints
   out.append({'id':kind+'-'+section+'-'+str(n+1),'section':section,'type':typ,'severity':row['severity'],'description':row['description'],'items':witnesses,'classification':category,'disposition':action})
 result={'board_sha256':hashlib.sha256(bp.read_bytes()).hexdigest(),'counts':{sec:len(d[sec]) for sec in ['violations','unconnected_items','schematic_parity']},'rows':out,'all_report_uuid_endpoints_found':all(i['native_uuid_found'] for x in out for i in x['items'])};(S/f'{kind}-drc-classification.json').write_text(json.dumps(result,indent=2));results[kind]=result['counts'];print(kind,result['counts'],'alluuidfound',result['all_report_uuid_endpoints_found'])
 fig,ax=plt.subplots(figsize=(12,8));ax.set_aspect('equal');ax.set_facecolor('#fafaf7')
 for ref,fp in fps.items():
  x,y=xy(fp.GetPosition());bounds=(24,53,20,39) if kind=='carrier' else (44,51,30,37)
  if not(bounds[0]-7<x<bounds[1]+7 and bounds[2]-7<y<bounds[3]+7):continue
  for shape in fp.GraphicalItems():
   if not isinstance(shape,p.PCB_SHAPE) or shape.GetLayer() not in [p.F_Fab,p.F_CrtYd]:continue
   if shape.GetShape()==p.SHAPE_T_SEGMENT:
    a,z=xy(shape.GetStart()),xy(shape.GetEnd());ax.plot([a[0],z[0]],[a[1],z[1]],color='#9ca3af' if shape.GetLayer()==p.F_CrtYd else '#59636e',lw=.8)
  court=fp.GetCourtyard(p.F_CrtYd)
  for points in polyrows(court):ax.add_patch(Polygon(points,fill=False,edgecolor='#b19aca',lw=.8,linestyle='--'))
  for pad in fp.Pads():
   if not pad.IsOnLayer(p.F_Cu):continue
   for points in polyrows(pad.GetEffectivePolygon(p.F_Cu)):ax.add_patch(Polygon(points,facecolor='#debd74',edgecolor='#534529',lw=.5))
   px,py=xy(pad.GetPosition())
   if pad.GetDrillSizeX()>0:ax.add_patch(Circle((px,py),p.ToMM(pad.GetDrillSizeX())/2,color='white',ec='#555'))
   if pad.GetNumber():ax.text(px,py,pad.GetNumber(),ha='center',va='center',fontsize=6)
  ax.text(x,y+.7,ref,fontsize=8,ha='center')
 for t in b.GetTracks():
  if not t.IsOnLayer(p.F_Cu):continue
  a,z=xy(t.GetStart()),xy(t.GetEnd());color={'AUDIO_P':'#df403b','AUDIO_N':'#346abd','GND':'#339967'}.get(t.GetNetname(),'#bc4d37')
  if t.GetClass()=='PCB_VIA':ax.add_patch(Circle(a,p.ToMM(t.GetBoundingBox().GetWidth())/2,fc=color,ec='black',lw=.6));ax.add_patch(Circle(a,p.ToMM(t.GetDrillValue())/2,fc='white'))
  else:ax.plot([a[0],z[0]],[a[1],z[1]],color=color,lw=3,solid_capstyle='round')
 ax.set_xlim(bounds[:2]);ax.set_ylim(bounds[3],bounds[2]);ax.grid(alpha=.2);ax.set_xlabel('Native board x / mm');ax.set_ylabel('Native board y / mm');ax.set_title('Carrier native placement only — preparation refused; NO saved fanout' if kind=='carrier' else 'Pod saved native top copper — AUDIO− pad/via overlap visible')
 fig.tight_layout();fig.savefig(S/'views'/f'{kind}-local-native.png',dpi=170);plt.close(fig)
(S/'view-review-notes.md').write_text('Opened all four actual KiCad top/bottom renders. Carrier and pod show fitted SMD only on top; bottom views show THT solder lands/vias without fitted SMD. Carrier J9 body is visibly inset from the new west edge; this image does not establish mate/latch/tool access. Top carrier caption crowding is visible, and native DRC independently locates CH1–8 collisions. Pod clamp is top behind jack; the separate native local-copper view exposes the AUDIO-minus annulus/land overlap. No complete prepared carrier copper exists. Rendered models resolve333/333carrier and32/32pod; model visibility is not assembly/tolerance/service approval.\n')
