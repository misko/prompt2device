from pathlib import Path
import yaml,json,copy,hashlib
S=Path(__file__).resolve().parents[1];R=S.parents[3];W=S/'work';checks=[]
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 P=W/'projects'/slug;carrier='carrier' in slug
 fpath=P/'03_src/floorplan.yaml';f=yaml.safe_load(fpath.read_text());rp=P/'03_src/route.yaml';r=yaml.safe_load(rp.read_text());old=copy.deepcopy(r)
 if carrier:
  f['board']['outline']['x0']=16.0
  for xy in f['board']['mounting_holes']['at']:
   if xy[0]==22:xy[0]=21.0
  fpath.write_text(yaml.safe_dump(f,sort_keys=False,width=120))
 c1=yaml.safe_load((R/'history/top-only/candidate1'/slug/'03_src/route.yaml').read_text())
 originals={st['pin']:st for st in c1['prep']['seed_stubs']['stubs'] if st.get('pin','').startswith('J') and st.get('net','').startswith('AUDIO_')}
 stubs=r['prep']['seed_stubs']['stubs']
 for k,st in enumerate(stubs):
  if st.get('pin') not in originals:continue
  v=copy.deepcopy(originals[st['pin']]);pts=v['segments'][0]['pts']
  if v['net'].startswith('AUDIO_N'):
   sg=1 if not carrier or int(v['pin'][1:v['pin'].index('.')])<5 else -1
   elbow=pts[-2];pts[-2:-1]=[[elbow[0],round(elbow[1]-sg*.35,4)],[round(elbow[0]+sg*.35,4),elbow[1]]]
  stubs[k]=v
 if carrier:
  for i in range(1,9):
   jx,jy,_=f['placement']['anchors'][f'J{i}'];sg=1 if i<5 else -1
   def pt(q):return [round(jx+sg*q[0],4),round(jy+sg*q[1],4)]
   # Fuse output detours below west peg, then reaches pin1; odd power row bus faces mouth.
   paths=[[[-6.385,0],[-6.385,3.14],[-1.2,3.14],[0,1.94],[0,0]],[[0,0],[0,-1.7],[6.12,-1.7],[6.12,0]],[[2.04,0],[2.04,-1.7]]]
   stubs.append({'net':f'POD_12V{i}','pin':f'F{i}.2','segments':[{'layer':'F.Cu','width':.60,'pts':[pt(q) for q in path]} for path in paths]})
 r['flow']['blockers'][0]='PROPOSED ADR0030A/0009P candidate3: 154x100 carrier, retained top-side cell poses, ordinary 45-degree AUDIO-minus final chamfer, and full-width source fuse fanout. Exact-source independent acceptance and native gate closure owed; historical candidates1/2 remain INCOMPLETE.'
 rp.write_text(yaml.safe_dump(r,sort_keys=False,width=120))
 launches=lambda v:[st for st in v['prep']['seed_stubs']['stubs'] if st.get('pin','').startswith('U_ESD') or (not carrier and st.get('pin','').startswith('U3.'))]
 checks.append({'board':slug,'unchanged_postclamp_ground_launches':launches(old)==launches(r),'count':len(launches(old)),'prefix_count':len(originals)})
 if not carrier:
  p=P/'03_src/rules/nets.yaml';t=p.read_text();t=t.replace('exactly B.Cu','exactly F.Cu');p.write_text(t)
(S/'source-construction-checks.json').write_text(json.dumps(checks,indent=2));print(checks)
