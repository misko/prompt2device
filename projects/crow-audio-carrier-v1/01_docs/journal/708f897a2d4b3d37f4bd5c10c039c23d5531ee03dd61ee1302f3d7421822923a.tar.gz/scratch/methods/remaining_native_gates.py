from pathlib import Path
import sys,os,json
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_runtime import run_stage
S=Path(__file__).resolve().parents[1];T=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/kicad-pcb/scripts');P=S/'work/projects/crow-audio-carrier-v1';bp=P/'04_kicad/crow_audio_carrier_v1.kicad_pcb';env={k:os.environ[k] for k in ['PATH','HOME','LANG'] if k in os.environ};env['PYTHONDONTWRITEBYTECODE']='1'
commands=[('carrier-placement-drc',['kicad-cli','pcb','drc','--severity-all','--refill-zones','--schematic-parity','--exit-code-violations','--format','json','-o',str(S/'carrier-placement-drc.json'),str(bp)]),('carrier-critical-placement',['/usr/bin/python3','-B',str(T/'critical_path_check.py'),str(bp),'--config','03_src/rules/critical_paths.yaml','--json',str(S/'carrier-critical-placement.json')]),('carrier-pad-separation',['/usr/bin/python3','-B',str(T/'pad_separation.py'),str(bp),'--project','.']),('carrier-placement-policy',['/usr/bin/python3','-B',str(T/'policy_audit.py'),'.','--board','crow_audio_carrier_v1','--skip-drc','--phase','placement'])]
for name,argv in commands:
 r=run_stage({'id':name,'work_class':'local','timeout_s':120},argv,log_path=S/'logs'/f'{name}.log',cwd=P,env=env,console_line_limit=20);(S/'logs'/f'{name}.runtime.json').write_text(json.dumps(r.to_mapping(),indent=2))
