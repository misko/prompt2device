from pathlib import Path
import tarfile,hashlib,json,stat,os
S=Path(__file__).resolve().parents[1];O=S.parent/'outputs';dest=O/'evidence.tar.gz';members=[]
# All engineering logs are closed. Packaging is a local Python archive operation;
# no child command, native operation, mutation/adoption or new design trial occurs.
files=[]
for p in sorted(S.rglob('*')):
 if p.is_symlink():raise RuntimeError('symlink '+str(p))
 if not p.is_file():continue
 if p.name.endswith(('.tar.gz','.tgz','.zip')):continue
 files.append(p)
with tarfile.open(dest,'w:gz',compresslevel=6) as t:
 for p in files:
  rel=p.relative_to(S).as_posix();assert not rel.startswith('/') and '..' not in Path(rel).parts
  data=p.read_bytes();members.append({'path':rel,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()});t.add(p,arcname=rel,recursive=False)
seen=set()
with tarfile.open(dest,'r:gz') as t:
 obs=t.getmembers();assert len(obs)==len(members)
 for row,m in zip(members,obs):
  assert m.isfile() and not m.issym() and m.name==row['path'] and m.name not in seen and '..' not in Path(m.name).parts and not m.name.startswith('/');seen.add(m.name)
  data=t.extractfile(m).read();assert len(data)==row['size']==m.size and hashlib.sha256(data).hexdigest()==row['sha256']
b=dest.read_bytes();manifest={'archive_sha256':hashlib.sha256(b).hexdigest(),'archive_size':len(b),'member_count':len(members),'members':members,'verification':'Every regular member reopened and hashed; no symlink, traversal, duplicate or recursive archive member.'};(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert sorted(x.name for x in O.iterdir())==['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md','result.json']
print(json.dumps({k:manifest[k] for k in ['archive_sha256','archive_size','member_count']}))
