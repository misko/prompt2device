from pathlib import Path
import shutil,yaml,json,math
S=Path(__file__).resolve().parents[1];W=S/'work'
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 P=W/'projects'/slug; snap=S/'candidate1'/slug
 shutil.copytree(P/'03_src',snap/'03_src');shutil.copytree(P/'04_kicad',snap/'04_kicad')
 p=P/'03_src/floorplan.yaml';f=yaml.safe_load(p.read_text())
 if 'carrier' in slug:
  f['board']['outline']['x0']=17.0
  for xy in f['board']['mounting_holes']['at']:
   if xy[0]==25:xy[0]=22.0
  f['board']['fiducials']['at'][0]=[25.0,33.0]
  for b in f['placement']['repeat']:
   north=b['index_from']==1;b['members']['F{i}']={'at':[-11.5,-21.14] if north else [11.5,21.14],'rot':0 if north else 180}
   b['captions']=[{'text':'F{i} PTC','at':[-11.5,-17.8] if north else [11.5,17.8],'size':.5,'nudge':False}]
  p.write_text(yaml.safe_dump(f,sort_keys=False,width=120))
 # Round only connector-prefix bends using source-owned tangent arcs, 0.35mm radius.
 p=P/'03_src/route.yaml';r=yaml.safe_load(p.read_text())
 for stub in r['prep']['seed_stubs']['stubs']:
  if not(stub.get('pin','').startswith('J') and stub.get('net','').startswith('AUDIO_')):continue
  seg=stub['segments'][0];pts=seg['pts']; ends=[];arcs=[]
  start=pts[0]
  for a,b,c in zip(pts,pts[1:],pts[2:]):
   l1=math.dist(a,b);l2=math.dist(b,c);u=[(a[k]-b[k])/l1 for k in [0,1]];v=[(c[k]-b[k])/l2 for k in [0,1]]
   theta=math.acos(max(-1,min(1,sum(u[k]*v[k] for k in [0,1]))));rad=.35;d=rad/math.tan(theta/2)
   assert d<min(l1,l2)/2
   e=[b[k]+d*u[k] for k in [0,1]];z=[b[k]+d*v[k] for k in [0,1]]
   bis=[u[k]+v[k] for k in [0,1]];bl=math.hypot(*bis);ctr=[b[k]+bis[k]/bl*rad/math.sin(theta/2) for k in [0,1]]
   mid=[ctr[k]+(b[k]-ctr[k])/math.dist(b,ctr)*rad for k in [0,1]]
   ends.append({'layer':'F.Cu','width':seg['width'],'pts':[start,e]});arcs.append({'layer':'F.Cu','width':seg['width'],'start':e,'mid':mid,'end':z});start=z
  ends.append({'layer':'F.Cu','width':seg['width'],'pts':[start,pts[-1]]});stub['segments']=ends;stub['arcs']=arcs
 p.write_text(yaml.safe_dump(r,sort_keys=False,width=120))
 print(slug,'candidate2 source saved')
