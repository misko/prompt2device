from pathlib import Path
import json,yaml,hashlib,shutil,re,math
S=Path(__file__).resolve().parents[1];W=S/'work';E=json.loads((S.parents[3]/'06_build/task_runs/rj45-top-only-source1/envelope.json').read_text()) if False else json.loads((S.parent/'envelope.json').read_text())
m=json.loads((S/'pod-measurements.json').read_text());a=json.loads((S/'carrier-candidate2-analytic.json').read_text())
# Classify every raw native row with exact endpoints; no count-only residual classes.
d=json.loads((S/'pod-native2/drc.json').read_text());rows=[]
for group in ['violations','unconnected_items','schematic_parity']:
 for i,v in enumerate(d[group]):
  ends=[{'description':z['description'],'uuid':z['uuid'],'position_mm':z['pos'],'kind':'pad' if z['description'].startswith('Pad ') else 'via' if z['description'].startswith('Via ') else 'track' if z['description'].startswith('Track ') else 'filled_zone' if z['description'].startswith('Zone ') else 'other exact native item'} for z in v['items']]
  if group=='unconnected_items':
   special=any('of C10 ' in z['description'] and '[GND]' in z['description'] for z in ends)
   cause='Existing isolated C10.2 GND return remains owed; prior proposed rescue via was never qualified/adopted.' if special else 'Exact named endpoints remain physically disconnected in this partial deterministic seed board; their ordinary downstream route is owed.'
  else:cause='Intentional partial seed launch ends at the exact endpoint shown; continuation remains owed and warning is not waived.'
  rows.append({'id':f'{group}:{i}','native_type':v['type'],'severity':v['severity'],'description':v['description'],'endpoints':ends,'classification':cause,'disposition':'OPEN; no final DRC acceptance'})
(S/'pod-native-drc-classification.json').write_text(json.dumps({'counts':{k:len(d[k]) for k in ['violations','unconnected_items','schematic_parity']},'rows':rows},indent=2))
# Exact unchanged graph/part identity for the successful pod native subject.
base=json.loads((S/'crow-mic-pod-v3-baseline-inventory.json').read_text());new={x['ref']:x for x in m['population']};identity=[]
for x in base:
 y=new[x['ref']];bp=sorted((z['n'],z['net']) for z in x['pads']);np=sorted((z['pad'],z['net']) for z in y['pads']);identity.append({'ref':x['ref'],'part_identity_equal':x['fp']==y['footprint'],'pad_net_identity_equal':bp==np,'before_pose':x['pose']+[x['layer']],'after_pose':y['pose']+[y['layer']]})
assert all(x['part_identity_equal'] and x['pad_net_identity_equal'] for x in identity)
(S/'pod-native-identity.json').write_text(json.dumps(identity,indent=2))
common='''The exact jack and patch cord, pin map, electrical graph, fitted population, fault/current/voltage limits, trace-width floors and two-sided copper capability are unchanged. All fitted SMD is intended on F.Cu, including manual and consigned SMD. No bottom-assembly exception is introduced.

Primary constraints: TI SLLSEG9C section10.1/p11 requests connector-near placement, straight protected traces, rounded corners and separation of struck/unprotected conductors; Figure12/p12 shows no IO stubs and a local ground via. The stored exact primary PDF and its actual page12 image were read. Source: https://www.ti.com/lit/ds/symlink/tpd2e2u06.pdf . These are layout requirements, not a published 4.2mm or 9.0mm system guarantee. Jack drawing001.003 p1 and native WR-MJ26c geometry fix the shell and tails: https://www.we-online.com/components/products/datasheet/615008160221.pdf .

The nominal shell is local x[-3.93,11.07],y[-6.36,7.09]mm. Pin5 at(4.08,0) has nearest shell edge6.36mm; rear7.09mm. The conductor lies inside the shell, so any top SMD clamp outside the occupied shell cannot retain a4.0mm center or4.2mm path budget. Added board width cannot shorten that intrinsic distance. Free EMI fingers reach x[-5.058081,12.218081] and remain included by the unchanged native footprint/model. Front placement conflicts with the mouth/board-edge service space. Side placement is obstructed by the locating-hole and spring/body geometry and does not provide a<4.2mm pin5 path.

The selected rear cell uses U center local(2.5,8.89),180degrees relative to a north-facing jack. Its nominal body-to-shell rear gap is1.00mm; nearest SMD copper-to-shell rear gap1.125mm; courtyard centerline gap0.35mm. These are nominal CAD quantities, not installed tolerance or rework qualification. In this orientation the courtyard-limited rear center would be y>8.54mm. This candidate adds0.35mm nominal courtyard separation. It is a bounded feasible pod construction, not proof of globally shortest route or a qualified rework-tool envelope. Jack±0.15mm dimensional tolerances and SOT-553 maximum body/tail tolerances must remain in independent body/service review.

Proposed electrical geometry contracts: F.Cu-only, no via before each clamp; AUDIO+ center<=8.6mm, routed prefix<=9.0mm; AUDIO- center<=5.7mm, prefix<=7.5mm. Carrier entry-ESD copper-gap ceiling<=7.7mm. These ceilings round the measured pod center8.434729/5.538173mm and native copper gaps7.587931/4.662686mm. Saved pod rounded0.35mm-radius prefixes measure8.719085/6.991305mm and have minimum measured local foreign-copper gap0.195001mm, above the unchanged0.127mm board floor. They are proposed engineering budgets, not additional manufacturer protection ratings. Independent review must decide whether the longer unavoidable unprotected lead remains appropriate for the existing system ESD requirement. No transient-protection sufficiency or first-article success is claimed.

Each IO enters the selected clamp pad before a separate post-clamp launch to its through via. Native pod contact analysis finds exactly one outside-prefix same-net track contact per prefix, at that clamp pad center; no off-pad pre-clamp branch or prefix via exists. The post-clamp vias intentionally await downstream routing. A0.50mm wide,0.85mm long F.Cu GND launch goes to a dedicated nearby through via. Native pod fill connects it to F.Cu and B.Cu ground and J1 pins2/6/8; shell9/10 stay separate. Figure12 supports a local return via, but the drawing and graph do not prove event impedance or enclosure ESD immunity.

The old owner YAML is retained as exact negative controls in the source-task evidence. Proposed YAML replaces only the identified placement geometry budgets/layer; prefix targets and no-stub intent are unchanged. Fresh independent source review is mandatory before any adoption. No route campaign, source adoption, release or ordering authorization results from this proposal.
'''
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 P=W/'projects'/slug;car='carrier' in slug;num='0030' if car else '0009'
 extra='''Carrier mechanical source candidate2 is153x100mm (x17..170,y20..120), versus150x100mm. North J1-J4 shift+2mmX; southJ5-J8 shift-2mmX, preserving0.50mm mouth exposure and axial directions. Source connector service contracts derive position from floorplan; absolute service/contact scenes and mounting interfaces need renewal. Left mounting centers move fromx25 tox22; FID1 moves(29,29)->(25,33). Native generator still refuses F1/H1: F1(29,25.86),courtyard rect x25.24..32.76/y23.90..27.82; H1(22,25),courtyard circle radius3.45mm. Exact checker polygon overlap window0.300x4.010mm. No complete candidate carrier board exists; no carrier top-only native acceptance can be transferred from the pod.

The adjacent fuse is set at jack local(-9,0) with its output pad facing pin1, transformed180degrees in the south bank. Analytic exact native F1.2/J1.1 copper gap4.845mm exceeds old4.5mm; propose5.0mm only for this same geometry. Littelfuse GD06/10/24 pp6-7 fixes the1.78x3.15mm lands and exact maximum body. The number5.0mm is an engineering gap allowance, not a fuse electrical-rating change. A straight fuse-to-pin1 centerline intersects the locating-hole keepout, so full0.60mm-minimum power fanout around the locating hole, all parallel contacts1/3/7, return paths and fault/current transfer remain owed. The nominal pad gap never proves a direct legal route.

The two native generation candidates are exhausted. One possible analytic mechanical adjustment is additional west movement of the left hole and outline beyond0.300mm, with independent mount/fastener/edge review; no third geometry was authored or generated. Another is a coordinated jack/fuse shift that must also regrade the clamp and neighboring film bodies. Do not restart routing against either failed candidate.

R_PWR_PU's isolated+0.04mmY source correction is retained from the prior independent native-gap evidence; it is not native-requalified here. The prior VMID dominance source is deliberately not imported because its C_VDDA1_10N.2 isolated GND pocket remains unresolved. Thermal12, ADC FILTP reservoir order and AP63205/ADC support-boundary/P-MOD metadata corrections remain named owed work; none gains acceptance from this connector task.
''' if car else '''Pod outline remains60x40mm and J1 stays(45.5,25.86,0); only fitted component U3 moves from bottom(49.07,27.86,180 native) to top(48.0,34.75,180). Source file before flip convention was U3 orientation0 on bottom. Native candidate has31/31 fitted SMD on top and0 bottom, including manually fitted parts; THT/copper-only items are separately enumerated. All44native footprints retain exact footprint and pad/net identities.

Source preparation emitted94copper primitives with0refused. Full-severity native DRC/refill/parity reports6dangling seed warnings,33opens,0parity; each exact endpoint is classified in the source-task evidence. The saved C10.2 GND pocket remains an explicit open; the historical R13 escape/C10 rescue proposal was not adopted. No whole-board routing or DRC acceptance is claimed.
'''
 text=f'---\nid: {num}\ndate: 2026-09-13\nstatus: proposed\n---\n# {num} — proposed top-side RJ45 protection geometry\n\n## Context\n\nThe accepted top-only manufacturing decision reopens the prior underside connector cell. This proposal supplies explicit owning geometry contracts and preserves the old controls. It remains INCOMPLETE.\n\n## Options\n\nFlipping beneath the jack is physically invalid. Retaining bottom SMD violates the user requirement. A bounded rear-side top clamp and side fuse is the selected source proposal; changing jack/cord/pinmap or weakening transient protection was not considered.\n\n## Decision\n\n'+common+'\n## Consequences\n\n'+extra
 (P/'01_docs/decisions'/f'{num}-proposed-top-side-rj45-protection-geometry.md').write_text(text)
# Native geometry sketch: preserve original PCB plots separately; this is an analytical diagram, not a generated board.
svg=['<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="720" viewBox="16 18 37 23"><rect x="16" y="18" width="37" height="23" fill="white"/><text x="17" y="19.3" font-size=".65">Carrier candidate2 analytical native-footprint pose — generator FAILED</text>']
for x in a['native_shapes']:
 color={'F1':'#c63d32','H1':'#376bb1','J1':'#d99f20'}[x['ref']]
 for g in x['courtyard_native']:
  if g['kind']=='Rect':
   l,t=g['start'];rr,bb=g['end'];svg.append(f'<rect x="{l}" y="{t}" width="{rr-l}" height="{bb-t}" fill="{color}" fill-opacity=".2" stroke="{color}" stroke-width=".07"/>')
  elif g['kind']=='Circle':
   cx,cy=g['start'];rad=math.dist(g['start'],g['end']);svg.append(f'<circle cx="{cx}" cy="{cy}" r="{rad}" fill="{color}" fill-opacity=".2" stroke="{color}" stroke-width=".07"/>')
 px,py,_=x['pose'];svg.append(f'<text x="{px}" y="{py}" font-size=".6" fill="{color}">{x["ref"]}</text>')
svg.append('<path d="M17 20H53 M17 20V40" fill="none" stroke="black" stroke-width=".1"/><text x="17.4" y="37" font-size=".6">Native H1 circle overlaps F1 rectangle; no clearance acceptance.</text></svg>');(S/'carrier-failure-analytic.svg').write_text(''.join(svg))
print('Classified',len(rows),'native rows; exact pod identities',len(identity),'; two proposed ADRs and analytic failure view written')
