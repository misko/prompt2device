from pathlib import Path
import yaml,json,re,hashlib
S=Path(__file__).resolve().parents[1];W=S/'work';changes=[]
def save(p,v):p.write_text(yaml.safe_dump(v,sort_keys=False,width=120))
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 P=W/'projects'/slug; fp=P/'03_src/floorplan.yaml';f=yaml.safe_load(fp.read_text()); rpath=P/'03_src/route.yaml';r=yaml.safe_load(rpath.read_text());carrier='carrier' in slug
 f['placement']['sides']={}
 if carrier:
  for i in range(1,9):f['placement']['anchors'][f'J{i}'][0]+=2 if i<5 else -2
  for bank in f['placement']['repeat']:
   north=bank['index_from']==1
   bank['members']['F{i}']={'at':[-11,-18] if north else [11,18],'rot':0 if north else 180}
   bank['members']['U_ESD{i}']={'at':[0,-12.25] if north else [0,12.25],'rot':180 if north else 0}
   bank['captions']=[{'text':'F{i} PTC','at':[-11,-14.8] if north else [11,14.8],'size':.5,'nudge':False}]
  # A separately useful 40um proximity correction; no mixed-side or VMID acceptance inherited.
  f['placement']['anchors']['R_PWR_PU'][1]=53.94
 else:f['placement']['anchors']['U3']=[48.0,34.75,180]
 st=r['prep']['seed_stubs']['stubs']
 st[:]=[v for v in st if not ((v.get('pin','').startswith('J') and v.get('net','').startswith('AUDIO_')) or (v.get('pin')=='U3.4' and not carrier))]
 cells=[]
 for i in (range(1,9) if carrier else [1]):
  j=f'J{i}';u=f'U_ESD{i}' if carrier else 'U3';suffix=str(i) if carrier else '';north=(not carrier or i<5);sg=1 if north else -1;jx,jy,_=f['placement']['anchors'][j]
  def pt(xy):return [round(jx+sg*xy[0],4),round(jy+sg*xy[1],4)]
  prefP=[[4.08,0],[4.08,5.64],[3.2125,6.5075],[3.2125,8.39]]
  prefN=[[3.06,4],[3.06,4.84],[.9,7],[.9,9.39],[1.7875,9.39]]
  ground=[[1.7875,8.39],[1.7875,7.54]]
  for net,pad,prefix,post in [(f'AUDIO_P{suffix}','3',prefP,[[3.2125,8.39],[4.1,8.39]]),(f'AUDIO_N{suffix}','5',prefN,[[1.7875,9.39],[2.35,9.39]])]:
   st.append({'net':net,'pin':j+('.5' if pad=='3' else '.4'),'segments':[{'layer':'F.Cu','width':.26,'pts':[pt(q) for q in prefix]}]})
   st.append({'net':net,'pin':u+'.'+pad,'segments':[{'layer':'F.Cu','width':.26,'pts':[pt(q) for q in post]}],'vias':[pt(post[-1])]})
  st.append({'net':'GND','pin':u+'.4','segments':[{'layer':'F.Cu','width':.50,'pts':[pt(q) for q in ground]}],'vias':[pt(ground[-1])]})
  cells.append({'jack':j,'clamp':u,'jack_pose':[jx,jy,0 if north else 180],'clamp_pose':pt([2.5,8.89])+[180 if north else 0],'prefix_P':[pt(q) for q in prefP],'prefix_N':[pt(q) for q in prefN],'ground_drop':pt(ground[-1]),'post_vias':[pt([4.1,8.39]),pt([2.35,9.39])]})
 # Existing thresholds deliberately retained. F.Cu seed proposal conflicts until new decision reviewed.
 r['flow'].setdefault('blockers',[]).insert(0,'TOP-ONLY SOURCE PROPOSAL: old B.Cu/4.0mm/4.2mm/3.0mm ESD contracts remain binding and fail this physical candidate; new rear-cell geometry decision and exact independent review are owed. No routing admission.')
 save(fp,f);save(rpath,r)
 (S/f'{slug}-candidate1-cell-intent.json').write_text(json.dumps(cells,indent=2))
 print(slug,'source authored, cells',len(cells))
