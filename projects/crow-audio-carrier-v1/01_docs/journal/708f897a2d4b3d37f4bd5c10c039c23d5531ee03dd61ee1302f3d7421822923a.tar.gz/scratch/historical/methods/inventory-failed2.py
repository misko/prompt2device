import pcbnew as p,json
from pathlib import Path
S=Path(__file__).resolve().parents[1]
def pt(x):return [p.ToMM(x.x),p.ToMM(x.y)]
def bb(b):return [p.ToMM(b.GetX()),p.ToMM(b.GetY()),p.ToMM(b.GetRight()),p.ToMM(b.GetBottom())]
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 P=S/'work/projects'/slug;B=p.LoadBoard(str(next((P/'04_kicad').glob('*.kicad_pcb'))));out=[]
 for f in B.GetFootprints():
  out.append({'ref':f.GetReference(),'pose':pt(f.GetPosition())+[f.GetOrientationDegrees()],'layer':f.GetLayerName(),'attributes':f.GetAttributes(),'fp':f.GetFPID().GetUniStringLibId(),'body_graphics':[(g.GetShapeStr(),bb(g.GetBoundingBox())) for g in f.GraphicalItems() if g.GetLayer()==p.F_Fab],'pads':[{'n':x.GetNumber(),'net':x.GetNetname(),'xy':pt(x.GetPosition()),'size':pt(x.GetSize()),'bbox':bb(x.GetBoundingBox()),'attribute':x.GetAttribute()} for x in f.Pads()]})
 (S/f'{slug}-baseline-inventory.json').write_text(json.dumps(out,indent=2))
 refs=['J1','U_ESD1','F1','C_A1P','C_A1N'] if 'carrier' in slug else ['J1','U3','F1','R12','R13','D1']
 print(slug)
 for x in out:
  if x['ref'] in refs: print(json.dumps(x))
