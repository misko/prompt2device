import pcbnew as p,json,math,hashlib,yaml
from pathlib import Path
from collections import Counter
S=Path(__file__).resolve().parents[1];P=S/'work/projects/crow-mic-pod-v3';bp=S/'pod-native2/crow_mic_pod_v3.kicad_pcb';b=p.LoadBoard(str(bp));b.BuildConnectivity();f={x.GetReference():x for x in b.GetFootprints()};cn=b.GetConnectivity()
def xy(q):return [p.ToMM(q.x),p.ToMM(q.y)]
def box(q):return [p.ToMM(q.GetLeft()),p.ToMM(q.GetTop()),p.ToMM(q.GetRight()),p.ToMM(q.GetBottom())]
def gap_native(a,b):
 lo=0;hi=p.FromMM(1000)
 if a.Collide(b,0):return 0.0
 while hi-lo>1:
  mid=(lo+hi)//2
  if a.Collide(b,mid):hi=mid
  else:lo=mid
 return p.ToMM(hi)
def des(q):
 d={'class':q.GetClass(),'uuid':q.m_Uuid.AsString(),'xy':xy(q.GetPosition())}
 if hasattr(q,'GetNetname'):d['net']=q.GetNetname()
 if isinstance(q,p.PAD):d.update(ref=q.GetParentFootprint().GetReference(),pad=q.GetNumber(),bbox=box(q.GetBoundingBox()))
 if isinstance(q,p.PCB_TRACK):d.update(layer=q.GetLayerName(),width=p.ToMM(q.GetBoundingBox().GetWidth() if q.GetClass()=="PCB_VIA" else q.GetWidth()),length=p.ToMM(q.GetLength()),start=xy(q.GetStart()),end=xy(q.GetEnd()))
 return d
pads={r+'.'+z.GetNumber():z for r,q in f.items() for z in q.Pads()};rows=[]
for r,q in sorted(f.items()):
 smd=bool(q.GetAttributes()&p.FP_SMD);copper_only=r.startswith(('TP','FID')) or r=='MK1';fitted=smd and not copper_only
 rows.append({'ref':r,'footprint':q.GetFPID().GetUniStringLibId(),'layer':q.GetLayerName(),'pose':xy(q.GetPosition())+[q.GetOrientationDegrees()],'native_attribute':q.GetAttributes(),'smd':smd,'fitted_smd':fitted,'classification':'fitted SMD including manual/consigned' if fitted else 'copper-only fiducial/test/capsule-wire landing' if copper_only else 'THT/mechanical','pads':[des(z) for z in q.Pads()]})
metrics={}
for a,z in [('J1.5','U3.3'),('J1.4','U3.5')]:
 x,y=pads[a],pads[z];metrics[a+'->'+z]={'pad_center_mm':math.dist(xy(x.GetPosition()),xy(y.GetPosition())),'native_copper_gap_mm':p.ToMM(x.GetEffectiveShape(p.F_Cu).GetClearance(y.GetEffectiveShape(p.F_Cu)))}
tracks=list(b.GetTracks());r=yaml.safe_load((P/'03_src/route.yaml').read_text());prefix=[]
for st in r['prep']['seed_stubs']['stubs']:
 if not(st.get('pin','').startswith('J') and st.get('net','').startswith('AUDIO_')):continue
 segs=[]
 for s in st['segments']:
  for a,z in zip(s['pts'],s['pts'][1:]):
   aa=[round(v,3) for v in a];zz=[round(v,3) for v in z]
   matches=[t for t in tracks if t.GetClass()=='PCB_TRACK' and t.GetNetname()==st['net'] and math.dist(xy(t.GetStart()),aa)<.000002 and math.dist(xy(t.GetEnd()),zz)<.000002]
   assert len(matches)==1,(a,z,len(matches));segs+=matches
 for a in st.get('arcs',[]):
  aa=[round(v,3) for v in a['start']];zz=[round(v,3) for v in a['end']]
  matches=[t for t in tracks if t.GetClass()=='PCB_ARC' and t.GetNetname()==st['net'] and math.dist(xy(t.GetStart()),aa)<.000002 and math.dist(xy(t.GetEnd()),zz)<.000002]
  assert len(matches)==1;segs+=matches
 ids={t.m_Uuid.AsString() for t in segs};contacts=[]
 for t in segs:
  for o in tracks:
   if o.m_Uuid.AsString() in ids or o.GetNetname()!=st['net'] or not o.IsOnLayer(p.F_Cu):continue
   if t.GetEffectiveShape(p.F_Cu).Collide(o.GetEffectiveShape(p.F_Cu),0):contacts.append({'prefix':des(t),'other':des(o)})
 prefix.append({'source':st['pin'],'net':st['net'],'primitive_count':len(segs),'native_length_mm':sum(p.ToMM(t.GetLength()) for t in segs),'all_F_Cu':all(t.GetLayer()==p.F_Cu for t in segs),'source_defined_no_via':not st.get('vias'),'primitives':[des(t) for t in segs],'nonprefix_same_net_contacts':contacts})
g=pads['U3.4'];components=[des(z) for z in cn.GetConnectedItems(g)];via=[t for t in tracks if t.GetClass()=='PCB_VIA' and t.GetNetname()=='GND' and math.dist(xy(t.GetPosition()),[47.2875,33.4])<.001];assert len(via)==1
zones=[]
for z in b.Zones():
 if z.GetIsRuleArea():continue
 for lay in [p.F_Cu,p.B_Cu]:
  if z.IsOnLayer(lay):zones.append({'layer':b.GetLayerName(lay),'uuid':z.m_Uuid.AsString(),'outline_count':z.GetFilledPolysList(lay).OutlineCount(),'via_contact':z.GetFilledPolysList(lay).Collide(via[0].GetEffectiveShape(lay),0),'groundpad_contact':lay==p.F_Cu and z.GetFilledPolysList(lay).Collide(g.GetEffectiveShape(lay),0)})
# Native same-layer actual foreign-copper gaps around all affected clamp/prefix copper.
newids={x['uuid'] for pref in prefix for x in pref['primitives']};selected=[q for q in tracks if q.m_Uuid.AsString() in newids or (q.GetNetname() in ['AUDIO_P','AUDIO_N','GND'] and 45.5<p.ToMM(q.GetPosition().x)<50 and 32<p.ToMM(q.GetPosition().y)<36)]
neighbors=[]
for q in selected:
 for o in [*tracks,*pads.values()]:
  if o.GetNetname()==q.GetNetname() or not o.IsOnLayer(p.F_Cu):continue
  gap=gap_native(q.GetEffectiveShape(p.F_Cu),o.GetEffectiveShape(p.F_Cu))
  if gap<1.0:neighbors.append({'item':des(q),'foreign':des(o),'native_gap_mm':gap})
result={'board_sha256':hashlib.sha256(bp.read_bytes()).hexdigest(),'population':rows,'counts':{'all_footprints':len(rows),'fitted_smd':sum(x['fitted_smd'] for x in rows),'top_fitted_smd':sum(x['fitted_smd'] and x['layer']=='F.Cu' for x in rows),'bottom_fitted_smd':sum(x['fitted_smd'] and x['layer']=='B.Cu' for x in rows)},'pad_metrics':metrics,'prefixes':prefix,'ground':{'pad':des(g),'via':des(via[0]),'pad_to_via_center_mm':math.dist(xy(g.GetPosition()),xy(via[0].GetPosition())),'connected_component':components,'zone_contacts':zones,'interpretation':'Native connected component proves plane/contact connectivity, not transient sufficiency.'},'local_foreign_copper_pairs_below_1mm':neighbors}
(S/'pod-measurements.json').write_text(json.dumps(result,indent=2));print(json.dumps(result['counts']));print(json.dumps(metrics));print('prefix lengths',[(x['source'],x['native_length_mm']) for x in prefix]);print('ground connector pads',[(x.get('ref'),x.get('pad')) for x in components if x.get('ref')=='J1']);print('min local gap',min(x['native_gap_mm'] for x in neighbors))
