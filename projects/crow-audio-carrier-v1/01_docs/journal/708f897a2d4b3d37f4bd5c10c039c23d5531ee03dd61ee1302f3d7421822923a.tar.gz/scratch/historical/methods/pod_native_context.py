from pathlib import Path
import shutil,sys,pcbnew
S=Path(__file__).resolve().parents[1];P=S/'work/projects/crow-mic-pod-v3';d=S/'pod-native2';d.mkdir();stem='crow_mic_pod_v3'
for ext in ['kicad_pro','kicad_dru','kicad_sch']:shutil.copy2(P/'04_kicad'/f'{stem}.{ext}',d/f'{stem}.{ext}')
# Resolve the native proof's project-local footprint libraries without changing footprint bytes.
src=(P/'04_kicad/fp-lib-table').read_text().replace('${KIPRJMOD}',str(P/'04_kicad'))
(d/'fp-lib-table').write_text(src)
b=pcbnew.LoadBoard(str(P/'06_build/route/r0.kicad_pcb'));pcbnew.ZONE_FILLER(b).Fill(b.Zones());b.Save(str(d/f'{stem}.kicad_pcb'))
print('Native fill saved',len(list(b.GetTracks())),'tracks/vias',len(list(b.Zones())),'zones')
