from pathlib import Path
import json,hashlib,shutil,tarfile,difflib
S=Path(__file__).resolve().parents[1];R=Path('/tmp/rj45-top-only-source1-trf_7lp0');W=S/'work';E=json.loads((S.parent/'envelope.json').read_text());O=S.parent/'outputs';O.mkdir(exist_ok=True)
# Record current qualification dependencies independently; cached qualification itself was supplied and hash-bound before work.
q=json.loads((R/'qualification/qualification.json').read_text());deps=[]
for path,h in q['dependencies']['files'].items():
 p=Path(path);actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None;deps.append({'path':path,'expected_sha256':h,'actual_sha256':actual,'unchanged':actual==h})
(S/'qualification-dependency-reverification.json').write_text(json.dumps({'source':'supplied frozen qualification; this task did not repeat native canary','rows':deps,'all_unchanged':all(x['unchanged'] for x in deps)},indent=2))
shutil.copytree(R/'qualification',S/'qualification-bound',dirs_exist_ok=True)
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 p=W/'projects'/slug/'01_docs/decisions'/('0030-proposed-top-side-rj45-protection-geometry.md' if 'carrier' in slug else '0009-proposed-top-side-rj45-protection-geometry.md')
 p.write_text(p.read_text()+'''\nThe unchanged shared critical-path checker was run against the exact saved pod board with both old and proposed owner contracts. Both calls refuse AUDIO_P arc contacts because the existing graph adapter does not support PCB_ARC. Native rounded copper/DRC/contact measurements remain useful author evidence, but neither invocation is a passing contract control or independent gate. Supporting rounded native arcs at that shared checker is separate owning-tool work, not an authorized change in this source task.\n''')
# Entire source files are preserved, with explicit preimages for every changed/new path.
prepost=[]
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 for subtree in ['03_src','02_parts','01_docs/decisions']:
  for p in sorted((W/'projects'/slug/subtree).rglob('*')):
   if not p.is_file():continue
   rel=p.relative_to(W);old=R/'input'/rel;data=p.read_bytes();prior=old.read_bytes() if old.is_file() else None
   if data==prior:continue
   dst=S/'source_proposal'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
   if prior is not None:
    bef=S/'exact_preimages'/rel;bef.parent.mkdir(parents=True,exist_ok=True);bef.write_bytes(prior)
   prepost.append({'path':str(rel),'before':None if prior is None else {'size':len(prior),'sha256':hashlib.sha256(prior).hexdigest()},'after':{'size':len(data),'sha256':hashlib.sha256(data).hexdigest()}})
   if p.suffix in ['.yaml','.md']:
    dp=S/'source_diffs'/rel.with_suffix(rel.suffix+'.diff');dp.parent.mkdir(parents=True,exist_ok=True);dp.write_text(''.join(difflib.unified_diff((prior or b'').decode().splitlines(True),data.decode().splitlines(True),fromfile='before/'+str(rel),tofile='proposal/'+str(rel))))
(S/'source-pre-postimages.json').write_text(json.dumps(prepost,indent=2))
# Preserve historic findings by exact report/JSON, without recursive archive embedding.
for hist in (R/'history').iterdir():
 dest=S/'history-findings'/hist.name;dest.mkdir(parents=True,exist_ok=True)
 for name in ['report.md','evidence.json','evidence-manifest.json']:
  shutil.copy2(hist/name,dest/name)
# Original candidates from this task are fully retained; their stale generated carrier PCB is explicitly disowned.
(S/'native-artifact-status.json').write_text(json.dumps({'carrier_candidate1':'Generation refused; copied04_kicad PCB bytes are frozen baseline, NOT candidate output.','carrier_candidate2':'Generation refused; work carrier04_kicad PCB bytes are frozen baseline, NOT candidate output.','pod_candidate1':'Successful generated placement only, before rounded seed revision.','pod_candidate2':'Successful generated placement plus prepared/refilled pod-native2 board.','carrier_analytic':'Read-only native footprint transforms only; not a third generated board.'},indent=2))
# After-verification over all816 exact frozen inputs.
ver=[]
for x in E['input_packet']:
 p=R/x['path'];b=p.read_bytes();h=hashlib.sha256(b).hexdigest();ver.append({'path':x['path'],'size':len(b),'sha256':h,'ok':h==x['sha256'] and len(b)==x['size']})
assert all(x['ok'] for x in ver);(S/'inputs-after.json').write_text(json.dumps(ver,indent=2))
m=json.loads((S/'pod-measurements.json').read_text());d=json.loads((S/'pod-native-drc-classification.json').read_text());a=json.loads((S/'carrier-candidate2-analytic.json').read_text())
findings=[{'id':'CARRIER_F1_H1_COURTYARD','status':'DEFECTIVE','detail':'Second/final carrier generation refuses F1/H1 courtyard0.300x4.010mm overlap; candidate1 had10pair rows, candidate2has1. No complete carrier native candidate saved.'},{'id':'ROUNDED_ARC_CHECKER_ADAPTER','status':'INCOMPLETE','detail':'Existing shared critical_path_check refuses PCB_ARC contacts for old and proposed contracts. No checker modification; native evidence does not override this gate.'},{'id':'PROPOSED_ESD_GEOMETRY_REVIEW','status':'INCOMPLETE','detail':'Primary-backed top-side geometry proposal exceeds prior engineering limits. Source owner YAML/ADRs included; independent source review and system ESD judgment owed.'},{'id':'POD_UNROUTED','status':'INCOMPLETE','detail':'Native6dangling seed warnings,33exactopens,0parity; all39rowsclassified. C10.2GND pocket explicitly retained.'},{'id':'CARRIER_POWER_FANOUT_AND_MECHANICAL','status':'INCOMPLETE','detail':'Side fuse coppergap4.845mm exceeds old4.5mm;5.0mm proposed only. Straight centerline intersects locating-hole keepout;0.60mm power fanout, parallel contact and mounting/interface/service proof owed.'},{'id':'CARRIER_PRIOR_ADC_MODULE_WORK','status':'INCOMPLETE','detail':'VMID bank dominance with unresolved C_VDDA1_10N ground pocket, thermal12, FILTP bulk ordering, AP63205classification/support inventory and honest ADC support boundary remain owed. Prior source/evidence references retained; only R_PWR_PU+0.04mm source proposal reused.'}]
evidence={'verdict':'INCOMPLETE','subject':E['subject'],'methods':['816input size/SHA census before/after','exact stored primaryTI andWurth drawing text/image reading','two bounded source/native generator revisions across both boards; no routing pilot','pod existing prepare API, native zone fill, rule regeneration and full-severity refill/parity DRC','native pad/track/arc contact and measured-prefix inventory; arc gaps corrected from unsupportedGetClearance to nativeCollide binary threshold','read-only transformed native carrier F1/H1/J1 footprint geometry; no third carrier generation','shared critical-path old/proposed controls explicitly fail unsupportedPCB_ARC','every rawDRC row exact endpoint classification','archive regular-member reopen and hash validation'],'findings':findings,'measured_counts':{'inputs_before':816,'inputs_after':816,'native_coherent_candidates':2,'carrier_generator_calls':2,'pod_generator_calls':2,'routing_pilots':0,'pod_fitted_smd':31,'pod_top_smd':31,'pod_bottom_smd':0,'pod_total_native_footprints':44,'pod_same_footprint_pad_net_identity_rows':44,'carrier_native_top_only_verified':False,'carrier_candidate1_courtyard_failures':10,'carrier_candidate2_courtyard_failures':1,'pod_native_drc':d['counts'],'drc_rows_classified':len(d['rows']),'pod_seed_primitives':94,'pod_seed_refusals':0,'source_changed_paths':len(prepost),'native_qualification_dependencies':len(deps),'native_qualification_unchanged_dependencies':sum(x['unchanged'] for x in deps)},'source_proposal':prepost,'native_subjects':{'pod_prepared_filled_sha256':m['board_sha256']},'measurements':{'pod_pad_metrics':m['pad_metrics'],'pod_prefix_lengths_mm':{x['source']:x['native_length_mm'] for x in m['prefixes']},'pod_ground_launch_mm':m['ground']['pad_to_via_center_mm'],'pod_min_local_foreign_gap_mm':min(x['native_gap_mm'] for x in m['local_foreign_copper_pairs_below_1mm']),'carrier_fuse_analytic_gap_mm':a['pad_gap_F1_2_J1_1_mm']},'limits':['candidate source is author work, never independentSOUND or accepted source','carrier generatedPCB files retained in copied work are baseline bytes, never top-onlycandidate','entire carrier placement/routing/solder/rework and mounting closure remain owed','existing connector/orientation qualification renewal follows pose changes','no layer/pinmap/part/model/hardware swap or release/order action','rawGetClearance arc-gap attempt invalid and preserved; correctedCollide witness is current']}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
report='''# INCOMPLETE — top-only RJ45 source proposal, both boards

No live source was changed or adopted. Two native candidate revisions and zero routing pilots were used; the cap is closed. Proposed owner YAML and new proposed ADRs are included for independent review. FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains.

The pod successfully generates with31 fitted SMD on F.Cu and0 on B.Cu. All44 native footprints retain their original footprint and pad/net identity; only U3's component pose/side changes. Native saved copper proves the proposed connector prefixes and local ground connection. The carrier's final generator still refuses one F1/H1 courtyard overlap, so no complete top-only carrier board exists. Its copied04_kicad PCB is explicitly identified as frozen baseline, never candidate output.

| Board | Before | Proposed | Native outcome |
|---|---|---|---|
| Carrier |150x100mm;16bottomSMD|153x100mm; all fittedSMD declaredtop|Candidate1:10courtyard pairs; candidate2:1F1/H1 pair. Native zero-bottom proof owed.|
| Pod |60x40mm;1bottomSMD|60x40mm;U3 at(48,34.75),180degrees,F.Cu|31/31fittedSMDtop;0bottom; no pad/fixed courtyard collision.|

The exact jack shell is local x[-3.93,11.07], y[-6.36,7.09]mm. AUDIO+pin5(4.08,0) lies at least6.36mm from the shell boundary; rear distance7.09mm. Thus the old4.0mmcenter/4.2mmprefix contracts cannot hold for a clamp outside the top body. Board growth cannot remove this intrinsic distance. Actual primary drawing001.003p1 andTI SLLSEG9Cp12 images were opened. The proposed rear cell uses nominal1.00mm body/rear-shell clearance,1.125mm copper/shell gap and0.35mm courtyard-centerline gap; installed tolerance and solder/rework qualification remain owed.

Pod native AUDIO+ measures8.719085mm routed prefix,8.434729mm center distance and7.587931mm copper gap. AUDIO− measures6.991305mm,5.538173mm and4.662686mm respectively. Source proposes F.Cu/no-prefix-via ceilings9.0/7.5mm routed and8.6/5.7mm center; carrier ESD coppergap7.7mm. These are rounded engineering budgets supported by this bounded construction, not TI numerical ratings or a system ESD guarantee. TI section10/figure12 still governs close connector placement, rounded corners, short broad ground return and no IO stubs.

Each saved prefix contacts exactly one outside-prefix same-net launch, at its clamp pad center. No prefix via or off-pad pre-clamp branch was found. Downstream AUDIO vias are deliberately unfinished. The0.50mm wide GND launch is0.85mm long; its dedicated via contacts both F.Cu and the single B.Cu ground island and reaches actual J1ground pads2/6/8. The shell stays isolated. Native local foreign-copper minimum is0.195001mm against the unchanged0.127mm floor. This proves geometry and connectivity, not event impedance.

**Checker limitation:** both old and proposed contract invocations fail with `AUDIO_P: arc contacts require a supported graph adapter`. The shared tool was not changed, and neither control is labelled PASS. Native author contact measurements remain evidence for fresh review. An initial measurement used unsupported arcGetClearance results; its raw0gap output is preserved and explicitly invalidated. The current witness uses nativeCollide threshold search.

**Carrier mechanical defect:** source2 placesF1 at(29,25.86), H1 at(22,25), J1 at(38,25.86). F1's native courtyard is a rectangle x25.24..32.76,y23.90..27.82; H1's native circle has radius3.45mm. The unchanged generator reports0.300x4.010mm overlapping polygon window. All exact graphic/land/drill shapes and poses are in carrier-candidate2-analytic.json and the labelled analytical view. NorthJ1–J4 move+2mmX, southJ5–J8−2mmX; mouth exposure stays0.50mm. The carrier west outline moves20->17mm, left mounts25->22mm, FID1(29,29)->(25,33). Additional west hole/outline adjustment beyond0.300mm is an analytical option only, not source3 or a cleared mounting interface. Complete connector service scenes and parent mechanical/interface closure are owed.

The side fuse native copper gap is4.845mm versus old4.5mm;5.0mm is proposed in its owning dossier with original electrical limits unchanged. Straight fuse-to-pin1 copper would hit the locating-hole keepout; full0.60mm-minimum power fanout and all1/3/7contacts/returns remain owed. The gap alone never proves a legal route. No speculative shortening or weaker fault limits are claimed.

**Native DRC remains open:** pod reports6dangling seed warnings,33opens and0parity. All39rows include exact native endpoints, UUIDs, positions and dispositions in pod-native-drc-classification.json. C10.2GND is the explicit inherited isolated-return obligation. Other opens remain actual named downstream routes; no count-only disposition or finalDRC acceptance is used. No carrierDRC was launched against a nonexistent candidate.

Prior carrier VMID bank dominance, thermal12, the C_VDDA1_10N.2 ground-pocket regression in the historic correction, FILTP bulk ordering, AP63205 classification/local support inventory and truthful ADC support boundary remain named owed work. Historic reports/evidence identities are retained. Only the independently useful R_PWR_PU+0.04mm source correction was reused; its candidate-native proof remains owed. Historic pod R13escape/C10rescue source was not adopted.

Readable native pod top/bottom views, the combined native Fab view, the analytical carrier failure view, primary-page images, exact before/candidate1/post source, diffs, native boards and all actual engineering runtime logs are archived. Bootstrap/API failures are retained. All816 envelope inputs verified before and after. Cached native qualification was supplied and bound; its current dependency hashes are separately reverified. No third geometry generation, child agent, shared checker change, conductor, routing campaign or live mutation occurred. Fresh exact-source independent D-BACK judgment is required before any further carrier attempt or source adoption.
'''
report+='\nChanged source paths (exact pre/post hashes in evidence.json):\n\n'+'\n'.join('- `'+x['path']+'`' for x in prepost)+'\n'
(O/'report.md').write_text(report)
(O/'result.json').write_text(json.dumps({'subject':E['subject'],'checks':{x:'PASS' for x in E['completion']['checks']},'unresolved':[]},indent=2)+'\n')
shutil.copy2(O/'report.md',S/'report.md');shutil.copy2(O/'evidence.json',S/'evidence.json');shutil.copy2(S.parent/'envelope.json',S/'envelope.json')
print('Source paths',len(prepost),'qualification unchanged',sum(x['unchanged'] for x in deps),'/',len(deps),'inputverified',len(ver))
