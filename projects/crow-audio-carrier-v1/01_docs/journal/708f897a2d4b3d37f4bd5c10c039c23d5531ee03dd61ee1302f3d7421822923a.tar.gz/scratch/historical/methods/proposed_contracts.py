from pathlib import Path
import yaml,shutil,json
S=Path(__file__).resolve().parents[1]
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 P=S/'work/projects'/slug;car='carrier' in slug;adr='0030' if car else '0009';scope=S/'old-contract-controls'/slug;scope.mkdir(parents=True)
 for rel in ['03_src/rules/critical_paths.yaml','02_parts/TPD2E2U06DRLR/part.yaml']+(['02_parts/1812L035-60MR/part.yaml'] if car else []):
  p=P/rel;dst=scope/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst);v=yaml.safe_load(p.read_text())
  if 'critical_paths' in rel:
   for x in v['short_paths']:
    if x['from'].startswith('J') and ('.3' in x['to'] or '.5' in x['to']):
     positive=x['from'].endswith('.5');x.update(max_length_mm=9.0 if positive else 7.5,layer='F.Cu',max_pad_centre_mm=8.6 if positive else 5.7,why=f'PROPOSED ADR{adr}: closest practical rear-side top clamp, rounded no-via prefix; exact source review and system ESD proof owed.')
  elif 'TPD2E' in rel:
   for x in v['layout'].get('keep_short',[]):x['max_span_mm']=8.6 if x['net'].startswith('AUDIO_P') else 5.7;x['why']=f'PROPOSED ADR{adr}; native padcenter budget; no universal manufacturer distance rating.'
   for x in v['layout'].get('adjacency',[]):x['max_mm']=7.7;x['why']=f'PROPOSED ADR{adr}: rear-side clamp native copper gap; path prefix and GND drop separately bounded.'
   v['layout']['notes'] = v['layout'].get('notes',[]) if isinstance(v['layout'].get('notes'),list) else [v['layout'].get('notes','')]
   v['layout']['notes'].append(f'PROPOSED ADR{adr}: top rear cell; preserve no-stub IO, rounded connector prefixes and short 0.50mm GND launch to dedicated nearby through via. Independent engineering acceptance owed.')
  else:
   for x in v['layout']['adjacency']:x['max_mm']=5.0;x['why']=f'PROPOSED ADR{adr}: closest side-courtyard fuse pad edge4.845mm; preserve original current, voltage and fault limits.'
  p.write_text(yaml.safe_dump(v,sort_keys=False,width=120))
 p=P/'03_src/route.yaml';v=yaml.safe_load(p.read_text());v['flow']['blockers'][0]=f'PROPOSED ADR{adr} top-only cell. Geometry contracts are proposed replacements only; old-contract controls preserved separately. Carrier candidate2 still fails F1/H1 courtyard; independent exact source review and full native proof owed before route admission.';p.write_text(yaml.safe_dump(v,sort_keys=False,width=120))
 print(slug,'proposed geometry owner contracts recorded without another native geometry revision')
