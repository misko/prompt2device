import sys,os,json
from pathlib import Path
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_runtime import run_stage
S=Path(__file__).resolve().parents[1]
name=sys.argv[1]; cwd=sys.argv[2]; timeout=float(sys.argv[3]); argv=sys.argv[4:]
e=dict(os.environ);e['PYTHONDONTWRITEBYTECODE']='1';e['KICAD10_FOOTPRINT_DIR']='/usr/share/kicad/footprints'
r=run_stage({'id':name,'work_class':'local','timeout_s':timeout},argv,log_path=S/'logs'/f'{name}.log',cwd=cwd,env=e,heartbeat_s=10,console_line_limit=35)
(S/'logs'/f'{name}.runtime.json').write_text(json.dumps(r.to_mapping(),indent=2)+'\n')
sys.exit(r.returncode if r.returncode is not None else 2)
