from pathlib import Path
import json,hashlib,shutil
R=Path('/tmp/rj45-top-only-source1-trf_7lp0'); S=Path(__file__).resolve().parents[1];E=json.loads((R/'06_build/task_runs/rj45-top-only-source1/envelope.json').read_text())
rows=[]
for x in E['input_packet']:
 p=R/x['path'];d=p.read_bytes(); rows.append(dict(path=x['path'],size=len(d),sha256=hashlib.sha256(d).hexdigest(),ok=len(d)==x['size'] and hashlib.sha256(d).hexdigest()==x['sha256']))
(S/'inputs-before.json').write_text(json.dumps(rows,indent=2));assert all(x['ok'] for x in rows)
# Copy exact tool/source tree, omit historic build evidence and archives only.
def ignore(path,names):
 return [n for n in names if n.endswith(('.tar.gz','.pyc')) or n=='__pycache__' or (n=='evidence' and Path(path).name=='01_docs')]
shutil.copytree(R/'input',S/'work',ignore=ignore)
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 p=S/'work/projects'/slug
 shutil.copytree(p/'03_src',S/'before'/slug/'03_src')
 shutil.copytree(p/'02_parts',S/'before'/slug/'02_parts')
 shutil.copytree(p/'04_kicad',S/'before'/slug/'04_kicad')
print('Verified',len(rows),'inputs; copied working tree and before source/native context')
