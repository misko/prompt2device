from pathlib import Path
import json,yaml,hashlib,shutil,difflib
S=Path(__file__).resolve().parents[1];R=Path('/tmp/rj45-top-only-source1-trf_7lp0');O=S.parent/'outputs'
a=yaml.safe_load((S/'candidate1/crow-mic-pod-v3/03_src/route.yaml').read_text());b=yaml.safe_load((S/'work/projects/crow-mic-pod-v3/03_src/route.yaml').read_text());
def selected(y):return [x for x in y['prep']['seed_stubs']['stubs'] if x.get('pin') in ['J1.5','J1.4','U3.3','U3.5','U3.4']]
x=selected(a);y=selected(b);rows=[]
for q,t in zip(x,y):
 prefix=q['pin'].startswith('J');rows.append({'pin':q['pin'],'net':q['net'],'prefix':prefix,'same_first_endpoint':q['segments'][0]['pts'][0]==t['segments'][0]['pts'][0],'same_last_endpoint':q['segments'][-1]['pts'][-1]==t['segments'][-1]['pts'][-1],'source_exactly_equal':q==t,'clearance_status':'candidate1 not natively prepared; do not inherit candidate2 rounded-copper clearance'})
(S/'supported-straight-alternative.json').write_text(json.dumps({'scope':'existing source/evidence comparison only, no source3/native run','preferred_alternative':'candidate1 original straight/chamfered source','rows':rows},indent=2))
txt='''\n**Preferred supported alternative for independent reassessment:** retain candidate1's original straight/chamfered source paths. Root explicitly prefers that already-supported native representation; fine chord tessellation is not proposed implementation work and no broad checker change is requested. Source comparison shows the same first/last prefix endpoints for both IOs and byte-equivalent source declarations for both post-clamp launches and the GND launch. Candidate1 analytic lengths8.749330/7.172201mm fit the proposed9.0/7.5mm routed bounds, and unchanged U3/J1 poses retain the same pad-center/body geometry. Candidate1 was not prepared or DRC-graded; its sharp/chamfered-corner clearance remains unverified, so candidate2's rounded-copper minimum cannot be transferred. TI Figure12 itself illustrates straight/chamfered routing while section10.1 discusses rounded corners; independent source review must judge the supported layout against the protection intent. Both source representations are preserved and the two-candidate cap stays closed.\n'''
for p in (S/'work/projects').glob('*/01_docs/decisions/*proposed-top-side-rj45-protection-geometry.md'):p.write_text(p.read_text()+txt)
for p in [O/'report.md',S/'report.md']:p.write_text(p.read_text()+txt)
pre=json.loads((S/'source-pre-postimages.json').read_text())
for row in pre:
 rel=Path(row['path']);p=S/'work'/rel;data=p.read_bytes();row['after']={'size':len(data),'sha256':hashlib.sha256(data).hexdigest()};shutil.copy2(p,S/'source_proposal'/rel)
 old=R/'input'/rel;prior=old.read_text() if old.is_file() else '';(S/'source_diffs'/rel.with_suffix(rel.suffix+'.diff')).write_text(''.join(difflib.unified_diff(prior.splitlines(True),data.decode().splitlines(True),fromfile='before/'+str(rel),tofile='proposal/'+str(rel))))
(S/'source-pre-postimages.json').write_text(json.dumps(pre,indent=2));e=json.loads((O/'evidence.json').read_text());e['source_proposal']=pre;e['arc_representation_analysis']['preferred_alternative']='Candidate1 original straight/chamfered source, not fine chords or broad checker changes; fresh native proof owed.';(O/'evidence.json').write_text(json.dumps(e,indent=2)+'\n');shutil.copy2(O/'evidence.json',S/'evidence.json');print(rows)
