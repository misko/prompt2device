from pathlib import Path
import sys,os,json,dataclasses
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_runtime import run_stage
S=Path(__file__).resolve().parent.parent
name=sys.argv[1]
out=run_stage({'id':name,'work_class':'local','timeout_s':180},sys.argv[2:],log_path=S/(name+'.runtime.log'),cwd=S,env=dict(os.environ),heartbeat_s=10)
(S/(name+'.outcome.json')).write_text(json.dumps(dataclasses.asdict(out),default=str,indent=2))
sys.exit(0 if out.status=='PASS' else 1)
