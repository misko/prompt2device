from pathlib import Path
import pcbnew as p,json,yaml,math,hashlib
P=Path('/tmp/rj45-top-only-reassessment1-9immtefn');S=Path(__file__).resolve().parent.parent
def xy(v):return [p.ToMM(v.x),p.ToMM(v.y)]
def bb(v):return [p.ToMM(v.GetLeft()),p.ToMM(v.GetTop()),p.ToMM(v.GetRight()),p.ToMM(v.GetBottom())]
def shape(g):return dict(kind=g.GetShapeStr(),start=xy(g.GetStart()),end=xy(g.GetEnd()),width=p.ToMM(g.GetWidth()),bounds=bb(g.GetBoundingBox()))
f=yaml.safe_load((P/'evidence/source_proposal/projects/crow-audio-carrier-v1/03_src/floorplan.yaml').read_text())
b=p.LoadBoard(str(P/'input/projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb'));fps={v.GetReference():v for v in b.GetFootprints()}
# Transform only the already sourced poses in memory, plus analytical proposed hole centers; no board save/generation.
poses={k:v for k,v in f['placement']['anchors'].items()}
for r in json.loads((P/'evidence/carrier-candidate2-analytic.json').read_text())['component_pose_changes']:poses[r['ref']]=r['after'][:3]
poses.update(H1=[21,25,0],H3=[21,115,0])
for k,v in poses.items():
 q=fps[k]
 if q.GetLayer()==p.B_Cu:q.Flip(q.GetPosition(),False)
 q.SetPosition(p.VECTOR2I_MM(*v[:2]));q.SetOrientationDegrees(v[2])
out={'scope':'READ ONLY analytical transform; no third native candidate','board_size':[154,100],'nearby':[]}
for ref,q in sorted(fps.items()):
 if p.ToMM(q.GetPosition().x)>55 and ref not in ['H2','H4']:continue
 out['nearby'].append(dict(ref=ref,pose=xy(q.GetPosition())+[q.GetOrientationDegrees()],fp=q.GetFPID().GetUniStringLibId(),fab=[shape(g) for g in q.GraphicalItems() if isinstance(g,p.PCB_SHAPE) and g.GetLayer()==p.F_Fab],courtyard=[shape(g) for g in q.GraphicalItems() if isinstance(g,p.PCB_SHAPE) and g.GetLayer()==p.F_CrtYd],pads=[dict(num=z.GetNumber(),pos=xy(z.GetPosition()),size=xy(z.GetSize()),drill=xy(z.GetDrillSize()),net=z.GetNetname(),bounds=bb(z.GetBoundingBox())) for z in q.Pads()]))
out['mount_control']=[dict(mount_x=x,nominal_gap_mm=25.24-x-3.45,stroke_aware_gap_mm=25.24-.025-x-3.45-.025,drill_to_edge_mm=3.4,courtyard_to_edge_mm=1.525) for x in [22,21]]
pod=p.LoadBoard(str(S/'selected/pod-native2/crow_mic_pod_v3.kicad_pcb')); base=p.LoadBoard(str(P/'input/projects/crow-mic-pod-v3/04_kicad/crow_mic_pod_v3.kicad_pcb'))
def ident(q):return [q.GetFPID().GetUniStringLibId(),sorted((z.GetNumber(),z.GetNetname(),xy(z.GetSize()),xy(z.GetDrillSize())) for z in q.Pads())]
bef={q.GetReference():q for q in base.GetFootprints()};out['pod']={'footprints':len(list(pod.GetFootprints())),'identical':[],'changed_poses':[],'smd':[]}
for q in pod.GetFootprints():
 r=q.GetReference();out['pod']['identical'].append(dict(ref=r,equal=ident(q)==ident(bef[r])))
 a=xy(q.GetPosition())+[q.GetOrientationDegrees(),q.GetLayerName()];z=xy(bef[r].GetPosition())+[bef[r].GetOrientationDegrees(),bef[r].GetLayerName()]
 if a!=z:out['pod']['changed_poses'].append(dict(ref=r,before=z,after=a))
 if q.GetAttributes()&p.FP_SMD:out['pod']['smd'].append(dict(ref=r,layer=q.GetLayerName()))
out['paths']=[]
for slug in ['crow-mic-pod-v3','crow-audio-carrier-v1']:
 r1=yaml.safe_load((P/'candidate1'/slug/'03_src/route.yaml').read_text())['prep']['seed_stubs']['stubs'];r2=yaml.safe_load((P/'evidence/source_proposal/projects'/slug/'03_src/route.yaml').read_text())['prep']['seed_stubs']['stubs']
 for a in r1:
  if not(a.get('pin','').startswith('J') and a.get('net','').startswith('AUDIO')):continue
  z=next(z for z in r2 if z.get('pin')==a['pin'] and z.get('net')==a['net']);v=a['segments'][0]['pts'];turn=[]
  for aa,ab,ac in zip(v,v[1:],v[2:]):
   u=[ab[i]-aa[i] for i in range(2)];w=[ac[i]-ab[i] for i in range(2)];turn.append(math.degrees(math.acos(max(-1,min(1,sum(x*y for x,y in zip(u,w))/math.hypot(*u)/math.hypot(*w))))))
  out['paths'].append(dict(board=slug,pin=a['pin'],pts=v,length=sum(math.dist(aa,ab) for aa,ab in zip(v,v[1:])),turn_degrees=turn,same_endpoints=v[0]==z['segments'][0]['pts'][0] and v[-1]==z['segments'][-1]['pts'][-1],width=a['segments'][0]['width']))
(S/'independent-native-inspection.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k!='nearby'},indent=2));print('J9',json.dumps(next(r for r in out['nearby'] if r['ref']=='J9')))
