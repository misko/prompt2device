from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,sys
P=Path('/tmp/rj45-top-only-reassessment1-9immtefn'); S=Path(__file__).resolve().parent.parent
E=json.loads((S.parent/'envelope.json').read_text())
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for i in E['input_packet']:
 p=P/i['path']; rows.append({'path':i['path'],'size':p.stat().st_size,'sha256':digest(p),'ok':p.stat().st_size==i['size'] and digest(p)==i['sha256']})
(S/('inputs-'+sys.argv[1]+'.json')).write_text(json.dumps(rows,indent=2)); assert all(x['ok'] for x in rows)
print('inputs verified',len(rows))
if sys.argv[1]!='before':sys.exit()
manifest=json.loads((P/'author/evidence-manifest.json').read_text());print('manifest keys',manifest.keys())
with tarfile.open(P/'author/evidence.tar.gz') as t:
 names=set();members=[]
 for m in t.getmembers():
  n=PurePosixPath(m.name);assert not n.is_absolute() and '..' not in n.parts and m.name not in names and not m.issym() and not m.islnk();names.add(m.name)
  if not m.isfile():continue
  data=t.extractfile(m).read(); members.append({'path':m.name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 (S/'author-archive-inventory.json').write_text(json.dumps(members,indent=2))
 print('archive regular members',len(members))
 print('\n'.join(m['path'] for m in members if any(x in m['path'] for x in ['methods/','measure','drc','prepared','prefix','hash','straight'])))
