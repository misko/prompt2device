from pathlib import Path
import pcbnew as p,json,hashlib
P=Path('/tmp/rj45-top-only-reassessment1-9immtefn');S=Path(__file__).resolve().parent.parent
b=p.LoadBoard(str(P/'input/projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb'));h=next(q for q in b.GetFootprints() if q.GetReference()=='H1');f=p.FootprintLoad(str(P/'input/projects/crow-audio-carrier-v1/03_src/lib/crow_audio_carrier.pretty'),'Littelfuse_1812L035_60_Exact');f.SetPosition(p.VECTOR2I_MM(29,25.86));f.SetOrientationDegrees(0)
def bb(z):return [p.ToMM(z.GetLeft()),p.ToMM(z.GetTop()),p.ToMM(z.GetRight()),p.ToMM(z.GetBottom())]
rows=[]
for x in [22,21]:
 h.SetPosition(p.VECTOR2I_MM(x,25));a=h.GetCourtyard(p.F_CrtYd);z=f.GetCourtyard(p.F_CrtYd);ab=a.BBox();zb=z.BBox();rows.append(dict(hole_x=x,hole_polygon_bounds=bb(ab),fuse_polygon_bounds=bb(zb),polygon_collision=a.Collide(z),projected_x_gap_mm=p.ToMM(zb.GetLeft()-ab.GetRight()),nominal_exact_circle_rect_gap_mm=25.24-x-3.45,stroke_gap_mm=25.24-.025-x-3.45-.025))
assert rows[0]['polygon_collision'] and not rows[1]['polygon_collision']
(S/'native-polygon-controls.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
