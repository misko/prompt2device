from pathlib import Path
import json,math,pcbnew as p,yaml,hashlib
P=Path('/tmp/rj45-top-only-reassessment1-9immtefn');S=Path(__file__).resolve().parent.parent
b=p.LoadBoard(str(S/'selected/pod-native2/crow_mic_pod_v3.kicad_pcb'));meas=json.loads((S/'selected/pod-measurements.json').read_text());route=yaml.safe_load((P/'candidate1/crow-mic-pod-v3/03_src/route.yaml').read_text())['prep']['seed_stubs']['stubs'];tracks=list(b.GetTracks());pads=[z for f in b.GetFootprints() for z in f.Pads()]
def xy(z):return [p.ToMM(z.x),p.ToMM(z.y)]
def gap(a,z):
 if a.Collide(z,0):return 0
 lo=0;hi=p.FromMM(100)
 while hi-lo>1:
  m=(lo+hi)//2
  if a.Collide(z,m):hi=m
  else:lo=m
 return p.ToMM(hi)
out={'scope':'Independent analytical SHAPE_SEGMENT controls against saved pod context; no PCB_TRACK creation, board mutation/save, source file or native candidate; no clearance acceptance transfer','cases':[]}
for net in ['AUDIO_P','AUDIO_N']:
 st=next(q for q in route if q.get('pin','').startswith('J') and q.get('net')==net);original=st['segments'][0]['pts'];cases=[('candidate1_exact',original)]
 if net=='AUDIO_N':cases.append(('single_45deg_chamfer_analytical',[*original[:3],[46.4,34.9],[46.75,35.25],original[-1]]))
 for name,pts in cases:
  rows=[]
  for a,z in zip(pts,pts[1:]):
   sh=p.SHAPE_SEGMENT(p.SEG(p.VECTOR2I_MM(*a),p.VECTOR2I_MM(*z)),p.FromMM(.26))
   for ob in tracks+pads:
    if ob.GetNetname()==net or not ob.IsOnLayer(p.F_Cu):continue
    g=gap(sh,ob.GetEffectiveShape(p.F_Cu))
    if g<.7:rows.append(dict(segment=[a,z],gap_mm=g,foreign_class=ob.GetClass(),foreign_uuid=ob.m_Uuid.AsString(),foreign_net=ob.GetNetname(),foreign_pos=xy(ob.GetPosition())))
  out['cases'].append(dict(name=name,net=net,pts=pts,length_mm=sum(math.dist(a,z) for a,z in zip(pts,pts[1:])),min_foreign_copper_gap_mm=min(q['gap_mm'] for q in rows),pairs_below_0_7_mm=rows))
out['limitations']=['Saved foreign AUDIO+ geometry retains rounded arcs; both proposed straight-prefix contexts must be jointly regenerated and checked later.','Only saved pod copper/pads are included; no new carrier or full manufacturing clearance proof.','The 0.35mm cut uses the retained 90-degree fillet tangent distances as a constrained analytical comparison, not arbitrary clearance searching.','No path source, native candidate, tessellation or checker modification is authored.']
(S/'chamfer-analytical-control.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
