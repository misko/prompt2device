from pathlib import Path
import json,math,yaml,hashlib,pcbnew as p
def pointseg(q,a,b):
 v=[b[i]-a[i] for i in range(2)]; t=max(0,min(1,sum((q[i]-a[i])*v[i] for i in range(2))/sum(x*x for x in v)));return math.dist(q,[a[i]+t*v[i] for i in range(2)])
def pointbox(q,bd):return math.hypot(max(bd[0]-q[0],0,q[0]-bd[2]),max(bd[1]-q[1],0,q[1]-bd[3]))
def linepoint(line,q):return min(pointseg(q,a,b) for a,b in zip(line,line[1:]))
def linebox(line,bd):
 corners=[(bd[0],bd[1]),(bd[2],bd[1]),(bd[2],bd[3]),(bd[0],bd[3])];ds=[pointbox(q,bd) for q in line]
 for a,b in zip(line,line[1:]):
  ds.extend(pointseg(q,a,b) for q in corners)
  for c,d in zip(corners,corners[1:]+corners[:1]):
   def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
   if cross(a,b,c)*cross(a,b,d)<=0 and cross(c,d,a)*cross(c,d,b)<=0 and max(min(a[0],b[0]),min(c[0],d[0]))<=min(max(a[0],b[0]),max(c[0],d[0])) and max(min(a[1],b[1]),min(c[1],d[1]))<=min(max(a[1],b[1]),max(c[1],d[1])):return 0
 return min(ds)
P=Path('/tmp/rj45-top-only-reassessment1-9immtefn');S=Path(__file__).resolve().parent.parent
data=json.loads((S/'independent-native-inspection.json').read_text());near={q['ref']:q for q in data['nearby']}
out={'scope':'Analytical geometric controls, not native route/assembly proof','mount_nearest':{},'source_hashes':[]}
for h,xy in [('H1',(21,25)),('H3',(21,115))]:
 rows=[]
 for ref,f in near.items():
  if ref==h:continue
  for g in f['courtyard']:
   bd=g['bounds']; gap=pointbox(xy,bd)-3.475
   rows.append(dict(ref=ref,conservative_bbox_courtyard_gap_mm=gap))
 out['mount_nearest'][h]=sorted(rows,key=lambda q:q['conservative_bbox_courtyard_gap_mm'])[:8]
out['J9_edge_relation']={'body_front_x_mm':19.08,'baseline_body_overhang_mm':.92,'candidate2_body_setback_mm':2.08,'proposed_body_setback_mm':3.08,'conclusion':'Existing edge_faces gate proves direction only. Installed housing/tool/enclosure clearance remains unknown. Additional setback is 1 mm relative to candidate2, 4 mm relative to baseline.'}
# Exact nominal locating hole and pads from native author-bound drawing/footprints.
# A lower (rearward) detour at y29 avoids the locating hole and stops before GND pin2 at x39.02.
c=(34.72,26.56);path=[(31.615,25.86),(31.615,29),(36.8,29),(38,27.8),(38,25.86)]
line=path;straight=[(31.615,25.86),(38,25.86)]
j=next(q for q in json.loads((P/'evidence/carrier-candidate2-analytic.json').read_text())['native_shapes'] if q['ref']=='J1')
foreign=[]
for z in j['pads']:
 if z['number'] in ['1','3','7']:continue
 if z['number']=='': gap=linepoint(line,z['xy'])-1.59-.3;clear=.25
 else:gap=linebox(line,z['bounds'])-.3;clear=.2
 foreign.append(dict(pad=z['number'],xy=z['xy'],conservative_trace_edge_gap_mm=gap,required_mm=clear))
out['fuse_corridor']={'analytical_centerline':path,'length_mm':sum(math.dist(a,b) for a,b in zip(path,path[1:])),'width_mm':.6,'hole_center':c,'hole_radius_mm':1.59,'min_hole_clearance_mm':.25,'straight_hole_edge_gap_mm':linepoint(straight,c)-1.59-.3,'detour_hole_edge_gap_mm':linepoint(line,c)-1.59-.3,'foreign_pad_checks':foreign,'assumptions':'Nominal pads and hole geometry, conservative shell-pad bounding rectangles. Full existing copper, parallel contacts1/3/7, return, holes, prep keepouts and thermal/fault proof remain owning-source obligations.'}
ev=json.loads((P/'author/evidence.json').read_text())
for row in ev['source_proposal']:
 rr={'path':row['path']}
 for label,folder in [('before','input'),('after','evidence/source_proposal')]:
  q=P/folder/row['path'];e=row[label]
  if e is None:rr[label]={'expected_absent':True,'ok':not q.exists()}
  else:rr[label]={'size':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()};rr[label]['ok']=all(rr[label][k]==e[k] for k in ['size','sha256'])
 out['source_hashes'].append(rr)
assert all(v[k]['ok'] for v in out['source_hashes'] for k in ['before','after'])
# In-memory native saved-board ground and prefix evidence, no save or modifications.
b=p.LoadBoard(str(S/'selected/pod-native2/crow_mic_pod_v3.kicad_pcb'));b.BuildConnectivity();fp={q.GetReference():q for q in b.GetFootprints()};pads={r+'.'+z.GetNumber():z for r,q in fp.items() for z in q.Pads()};cn=b.GetConnectivity();meas=json.loads((S/'selected/pod-measurements.json').read_text())
def xy(v):return [p.ToMM(v.x),p.ToMM(v.y)]
tracks={z.m_Uuid.AsString():z for z in b.GetTracks()};prefs=[]
for pref in meas['prefixes']:
 objs=[tracks[z['uuid']] for z in pref['primitives']];ids={z.m_Uuid.AsString() for z in objs};contacts=[]
 for a in objs:
  for z in tracks.values():
   if z.m_Uuid.AsString() in ids or z.GetNetname()!=a.GetNetname() or not z.IsOnLayer(p.F_Cu):continue
   if a.GetEffectiveShape(p.F_Cu).Collide(z.GetEffectiveShape(p.F_Cu),0):contacts.append({'prefix':a.m_Uuid.AsString(),'other':z.m_Uuid.AsString(),'class':z.GetClass(),'start':xy(z.GetStart()),'end':xy(z.GetEnd())})
 prefs.append(dict(source=pref['source'],length_mm=sum(p.ToMM(z.GetLength()) for z in objs),primitive_count=len(objs),all_top=all(z.GetLayer()==p.F_Cu for z in objs),contacts=contacts))
g=pads['U3.4'];via=next(z for z in tracks.values() if z.GetClass()=='PCB_VIA' and math.dist(xy(z.GetPosition()),[47.2875,33.4])<.001);zones=[]
for z in b.Zones():
 if z.GetIsRuleArea():continue
 for lay in [p.F_Cu,p.B_Cu]:
  if z.IsOnLayer(lay):zones.append(dict(layer=b.GetLayerName(lay),islands=z.GetFilledPolysList(lay).OutlineCount(),via_contact=z.GetFilledPolysList(lay).Collide(via.GetEffectiveShape(lay),0)))
comp=[q.GetParentFootprint().GetReference()+'.'+q.GetNumber() for q in cn.GetConnectedItems(g) if isinstance(q,p.PAD)]
out['pod_saved_native']={'prefixes':prefs,'ground_pad_to_via_mm':math.dist(xy(g.GetPosition()),xy(via.GetPosition())),'ground_connected_J1':[v for v in comp if v.startswith('J1.')],'ground_zone_contacts':zones,'pad_metrics':{a+'->'+z:{'center_mm':math.dist(xy(pads[a].GetPosition()),xy(pads[z].GetPosition())),'copper_gap_mm':p.ToMM(pads[a].GetEffectiveShape(p.F_Cu).GetClearance(pads[z].GetEffectiveShape(p.F_Cu)))} for a,z in [('J1.5','U3.3'),('J1.4','U3.5')]}}
dr=json.loads((S/'selected/pod-native2/drc.json').read_text());out['drc_counts']={k:len(dr[k]) for k in ['violations','unconnected_items','schematic_parity']}
(S/'independent-constraints.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='source_hashes'},indent=2));print('Source hash rows',len(out['source_hashes']))
