from pathlib import Path
import json,hashlib,yaml
P=Path('/tmp/rj45-top-only-reassessment1-9immtefn');S=Path(__file__).resolve().parent.parent
out={'qualification_dependencies':[],'preserved_launches':[],'drc_rows':[]}
files={}
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 q=json.loads((P/'qualification'/f'{slug}.json').read_text());files.update(q['dependencies']['files'])
 a=yaml.safe_load((P/'candidate1'/slug/'03_src/route.yaml').read_text())['prep']['seed_stubs']['stubs'];z=yaml.safe_load((P/'evidence/source_proposal/projects'/slug/'03_src/route.yaml').read_text())['prep']['seed_stubs']['stubs']
 for row in a:
  pin=row.get('pin','')
  if not(pin.startswith('U_ESD') or slug=='crow-mic-pod-v3' and pin.startswith('U3.')):continue
  matches=[v for v in z if v.get('pin')==pin and v.get('net')==row.get('net')];out['preserved_launches'].append({'board':slug,'pin':pin,'net':row.get('net'),'equal':len(matches)==1 and row==matches[0]})
for name,digest in sorted(files.items()):
 q=Path(name);raw=q.read_bytes();out['qualification_dependencies'].append({'path':name,'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'matches_cached':hashlib.sha256(raw).hexdigest()==digest})
assert all(v['matches_cached'] for v in out['qualification_dependencies'])
assert all(v['equal'] for v in out['preserved_launches'])
dr=json.loads((S/'selected/pod-native2/drc.json').read_text());cl=json.loads((P/'evidence/pod-native-drc-classification.json').read_text())
for row in cl['rows']:
 typ,n=row['id'].split(':');native=dr[typ][int(n)];nu=sorted(z['uuid'] for z in native['items']);ru=sorted(z['uuid'] for z in row['endpoints']);ok=nu==ru and native['type']==row['native_type'];out['drc_rows'].append({'id':row['id'],'uuids_match':ok,'classification':row['classification'],'disposition':row['disposition']})
assert len(out['drc_rows'])==39 and all(v['uuids_match'] for v in out['drc_rows'])
(S/'final-audit.json').write_text(json.dumps(out,indent=2));print('verified dependencies',len(files),'preserved launches',len(out['preserved_launches']),'native DRC rows',len(out['drc_rows']))
