from pathlib import Path
import tarfile,json,hashlib
P=Path('/tmp/rj45-top-only-reassessment1-9immtefn');S=Path(__file__).resolve().parent.parent
inv=json.loads((S/'author-archive-inventory.json').read_text()); mani=json.loads((P/'author/evidence-manifest.json').read_text()); mm={m['path']:m for m in mani['members']}
assert all(m=={k:mm[m['path']][k] for k in m} for m in inv)
sel=[m for m in inv if m['path'].startswith('methods/') or m['path'] in ['pod-measurements.json','supported-straight-alternative.json','pod-native2/drc.json'] or m['path'].endswith('.kicad_pcb') and 'pod-native' in m['path']]
print('SELECTED',json.dumps(sel,indent=2))
with tarfile.open(P/'author/evidence.tar.gz') as t:
 for m in sel:
  data=t.extractfile(m['path']).read();assert hashlib.sha256(data).hexdigest()==m['sha256'];p=S/'selected'/m['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
(S/'selected-members.json').write_text(json.dumps(sel,indent=2))
