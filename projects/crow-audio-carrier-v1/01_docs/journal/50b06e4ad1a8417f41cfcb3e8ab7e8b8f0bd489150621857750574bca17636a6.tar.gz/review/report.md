review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_switches_clockground1 (actual fresh independent agent)
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: e85b1461a82f3d3853c19fae694693816e31570d23d37019ef187d6428bea4ae
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: e6d5b0b89efd79051b082f70b283ec7e85e1170ed11ddb94581744d26904c9c7

The three hashes above are immutable subject metadata, not reviewed conclusions.

Envelope subject: {"raw_sha256": "bf46c0bb3fa50942a6ad06baafb3bfbab66e645c8dbf52f723ed4cb2eea3fca2", "semantic_sha256": "47e8f70c8bd08c632f729e401266af4de6465e7896be1622859e147a5814b1a1"}

Primary document SHA-256: 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55

Manufacturer basis: TI TMUX2821/TMUX2819 SCDS488, December 2025, exact SHA-selected PDF. Visually inspected pdftoppm renderings at 120 dpi: PDF page 3 Figure 4-1 and Pin Functions; page 19 TMUX2821 functional block diagram and Table 7-1; pages 30–32 DSG0008A outline 4218900/E (08/2022), land pattern and stencil examples. Figure 4-2 is the other device and was not used as the TMUX2821 pinout.

Figure-derived top-view expectation: pin 1/S1 at NW; 2/D1, 3/SEL2, 4/GND descend the west edge; 5/S2, 6/D2, 7/SEL1, 8/VDD ascend the east edge. Eight perimeter terminals wind CCW in physical top view. The separate central thermal pad is GND and is physically numbered 9 in the mechanical drawing. The underside mechanical drawing on page 30 has pin 1 at lower left and pin 4 upper left; reflecting its vertical coordinate converts it to the top-view orientation independently confirmed by Figure 4-1 and page 31. It must not be compared unconverted to top-view native coordinates. There are no fused terminal identities or permitted aliases.

Page 31 land example gives 1.9 mm row spacing, 0.5 mm pitch, eight 0.5 x 0.25 mm lands, central 0.9 x 1.6 mm land. Page 32 shows two paste apertures on EP, not two additional electrical identities. Dossier apertures are 0.85 x 0.71 mm each (83.82% EP area); the manufacturer's example is 87%. This small stencil-example variation does not alter pin identity, winding or net assignment; stencil-process qualification is outside this pin review.

All dossiers explicitly specify front mounting and component-top +x right/+y down. U_ISO1–4 have native rotation 0 degrees, U_ISO5–8 have 180 degrees. Only translation/rotation is used; no dossier mirror. Every native coordinate is checked against the local figure-derived coordinate with the declared rotation. The perimeter polygon signed area in the y-down frame is -2.85 mm², confirming CCW; EP is excluded from winding.

Electrical expectation: S1↔D1 and S2↔D2 are bidirectional signal paths. Logic SEL1/SEL2 high enables their channels when powered (Table 7-1). Both selectors on AUDIO_EN therefore act together. VDD requires a positive supply; 5V_LDO_HOLD is a supply-kind net. Both ground identities must be GND. No NC exists in TMUX2821. Filter-to-ADC P/N paths remain paired and structurally identical across all eight instances.

Procedure: verified all envelope input sizes and SHA-256 before and after review; used finite pipeline_runtime.run_stage direct argv subprocesses for extraction, rendering, comparison and preflight. Actual rendered images were opened with view_image. An initial U_ISO1 dossier preview occurred during protocol setup; package expectations above were independently read from actual figures before systematic all-instance comparison. No author verification note was treated as evidence. Python comparison checks every supplied native pad row, count, coordinate, function, size and net against the independently derived package facts; no live board or schematic was read. Frozen native dossiers are the native evidence source, not a newly extracted board.

Scope: only U_ISO1 through U_ISO8 pin/package/function-net review, pre-route. No whole-board acceptance, routing, signal amplitudes, timing, power integrity, decoupling placement or production solder-process qualification is implied. No missing context is needed to resolve these commissioned pin checks.

U_ISO1 VERDICT: PASS

Measured: 9 numbered native pads; 9 distinct physical electrical identities (8 leads + EP); 2 unnumbered paste features; 11 total native features; zero fused identities or aliases. Primary: SHA-256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p.3 Figure 4-1/Pin Functions, p.19 Table 7-1/block diagram, pp.30–32 DSG0008A figures. Expected NW pin 1 and CCW perimeter: observed NW pin 1 and CCW; native rotation 0° is consistent.

U_ISO1 pin 1 (S1): expected channel 1 signal source at W (-0.95, -0.75); observed matching function/location on FILTER1P. PASS.

U_ISO1 pin 2 (D1): expected channel 1 signal drain at W (-0.95, -0.25); observed matching function/location on ADC1P. PASS.

U_ISO1 pin 3 (SEL2): expected channel 2 logic control at W (-0.95, 0.25); observed matching function/location on AUDIO_EN. PASS.

U_ISO1 pin 4 (GND): expected ground reference at W (-0.95, 0.75); observed matching function/location on GND. PASS.

U_ISO1 pin 5 (S2): expected channel 2 signal source at E (0.95, 0.75); observed matching function/location on FILTER1N. PASS.

U_ISO1 pin 6 (D2): expected channel 2 signal drain at E (0.95, 0.25); observed matching function/location on ADC1N. PASS.

U_ISO1 pin 7 (SEL1): expected channel 1 logic control at E (0.95, -0.25); observed matching function/location on AUDIO_EN. PASS.

U_ISO1 pin 8 (VDD): expected positive supply at E (0.95, -0.75); observed matching function/location on 5V_LDO_HOLD. PASS.

U_ISO1 pin 9 (GND): expected ground reference at center (0.0, 0.0); observed matching function/location on GND. PASS.

U_ISO2 VERDICT: PASS

Measured: 9 numbered native pads; 9 distinct physical electrical identities (8 leads + EP); 2 unnumbered paste features; 11 total native features; zero fused identities or aliases. Primary: SHA-256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p.3 Figure 4-1/Pin Functions, p.19 Table 7-1/block diagram, pp.30–32 DSG0008A figures. Expected NW pin 1 and CCW perimeter: observed NW pin 1 and CCW; native rotation 0° is consistent.

U_ISO2 pin 1 (S1): expected channel 1 signal source at W (-0.95, -0.75); observed matching function/location on FILTER2P. PASS.

U_ISO2 pin 2 (D1): expected channel 1 signal drain at W (-0.95, -0.25); observed matching function/location on ADC2P. PASS.

U_ISO2 pin 3 (SEL2): expected channel 2 logic control at W (-0.95, 0.25); observed matching function/location on AUDIO_EN. PASS.

U_ISO2 pin 4 (GND): expected ground reference at W (-0.95, 0.75); observed matching function/location on GND. PASS.

U_ISO2 pin 5 (S2): expected channel 2 signal source at E (0.95, 0.75); observed matching function/location on FILTER2N. PASS.

U_ISO2 pin 6 (D2): expected channel 2 signal drain at E (0.95, 0.25); observed matching function/location on ADC2N. PASS.

U_ISO2 pin 7 (SEL1): expected channel 1 logic control at E (0.95, -0.25); observed matching function/location on AUDIO_EN. PASS.

U_ISO2 pin 8 (VDD): expected positive supply at E (0.95, -0.75); observed matching function/location on 5V_LDO_HOLD. PASS.

U_ISO2 pin 9 (GND): expected ground reference at center (0.0, 0.0); observed matching function/location on GND. PASS.

U_ISO3 VERDICT: PASS

Measured: 9 numbered native pads; 9 distinct physical electrical identities (8 leads + EP); 2 unnumbered paste features; 11 total native features; zero fused identities or aliases. Primary: SHA-256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p.3 Figure 4-1/Pin Functions, p.19 Table 7-1/block diagram, pp.30–32 DSG0008A figures. Expected NW pin 1 and CCW perimeter: observed NW pin 1 and CCW; native rotation 0° is consistent.

U_ISO3 pin 1 (S1): expected channel 1 signal source at W (-0.95, -0.75); observed matching function/location on FILTER3P. PASS.

U_ISO3 pin 2 (D1): expected channel 1 signal drain at W (-0.95, -0.25); observed matching function/location on ADC3P. PASS.

U_ISO3 pin 3 (SEL2): expected channel 2 logic control at W (-0.95, 0.25); observed matching function/location on AUDIO_EN. PASS.

U_ISO3 pin 4 (GND): expected ground reference at W (-0.95, 0.75); observed matching function/location on GND. PASS.

U_ISO3 pin 5 (S2): expected channel 2 signal source at E (0.95, 0.75); observed matching function/location on FILTER3N. PASS.

U_ISO3 pin 6 (D2): expected channel 2 signal drain at E (0.95, 0.25); observed matching function/location on ADC3N. PASS.

U_ISO3 pin 7 (SEL1): expected channel 1 logic control at E (0.95, -0.25); observed matching function/location on AUDIO_EN. PASS.

U_ISO3 pin 8 (VDD): expected positive supply at E (0.95, -0.75); observed matching function/location on 5V_LDO_HOLD. PASS.

U_ISO3 pin 9 (GND): expected ground reference at center (0.0, 0.0); observed matching function/location on GND. PASS.

U_ISO4 VERDICT: PASS

Measured: 9 numbered native pads; 9 distinct physical electrical identities (8 leads + EP); 2 unnumbered paste features; 11 total native features; zero fused identities or aliases. Primary: SHA-256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p.3 Figure 4-1/Pin Functions, p.19 Table 7-1/block diagram, pp.30–32 DSG0008A figures. Expected NW pin 1 and CCW perimeter: observed NW pin 1 and CCW; native rotation 0° is consistent.

U_ISO4 pin 1 (S1): expected channel 1 signal source at W (-0.95, -0.75); observed matching function/location on FILTER4P. PASS.

U_ISO4 pin 2 (D1): expected channel 1 signal drain at W (-0.95, -0.25); observed matching function/location on ADC4P. PASS.

U_ISO4 pin 3 (SEL2): expected channel 2 logic control at W (-0.95, 0.25); observed matching function/location on AUDIO_EN. PASS.

U_ISO4 pin 4 (GND): expected ground reference at W (-0.95, 0.75); observed matching function/location on GND. PASS.

U_ISO4 pin 5 (S2): expected channel 2 signal source at E (0.95, 0.75); observed matching function/location on FILTER4N. PASS.

U_ISO4 pin 6 (D2): expected channel 2 signal drain at E (0.95, 0.25); observed matching function/location on ADC4N. PASS.

U_ISO4 pin 7 (SEL1): expected channel 1 logic control at E (0.95, -0.25); observed matching function/location on AUDIO_EN. PASS.

U_ISO4 pin 8 (VDD): expected positive supply at E (0.95, -0.75); observed matching function/location on 5V_LDO_HOLD. PASS.

U_ISO4 pin 9 (GND): expected ground reference at center (0.0, 0.0); observed matching function/location on GND. PASS.

U_ISO5 VERDICT: PASS

Measured: 9 numbered native pads; 9 distinct physical electrical identities (8 leads + EP); 2 unnumbered paste features; 11 total native features; zero fused identities or aliases. Primary: SHA-256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p.3 Figure 4-1/Pin Functions, p.19 Table 7-1/block diagram, pp.30–32 DSG0008A figures. Expected NW pin 1 and CCW perimeter: observed NW pin 1 and CCW; native rotation 180° is consistent.

U_ISO5 pin 1 (S1): expected channel 1 signal source at W (-0.95, -0.75); observed matching function/location on FILTER5P. PASS.

U_ISO5 pin 2 (D1): expected channel 1 signal drain at W (-0.95, -0.25); observed matching function/location on ADC5P. PASS.

U_ISO5 pin 3 (SEL2): expected channel 2 logic control at W (-0.95, 0.25); observed matching function/location on AUDIO_EN. PASS.

U_ISO5 pin 4 (GND): expected ground reference at W (-0.95, 0.75); observed matching function/location on GND. PASS.

U_ISO5 pin 5 (S2): expected channel 2 signal source at E (0.95, 0.75); observed matching function/location on FILTER5N. PASS.

U_ISO5 pin 6 (D2): expected channel 2 signal drain at E (0.95, 0.25); observed matching function/location on ADC5N. PASS.

U_ISO5 pin 7 (SEL1): expected channel 1 logic control at E (0.95, -0.25); observed matching function/location on AUDIO_EN. PASS.

U_ISO5 pin 8 (VDD): expected positive supply at E (0.95, -0.75); observed matching function/location on 5V_LDO_HOLD. PASS.

U_ISO5 pin 9 (GND): expected ground reference at center (0.0, 0.0); observed matching function/location on GND. PASS.

U_ISO6 VERDICT: PASS

Measured: 9 numbered native pads; 9 distinct physical electrical identities (8 leads + EP); 2 unnumbered paste features; 11 total native features; zero fused identities or aliases. Primary: SHA-256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p.3 Figure 4-1/Pin Functions, p.19 Table 7-1/block diagram, pp.30–32 DSG0008A figures. Expected NW pin 1 and CCW perimeter: observed NW pin 1 and CCW; native rotation 180° is consistent.

U_ISO6 pin 1 (S1): expected channel 1 signal source at W (-0.95, -0.75); observed matching function/location on FILTER6P. PASS.

U_ISO6 pin 2 (D1): expected channel 1 signal drain at W (-0.95, -0.25); observed matching function/location on ADC6P. PASS.

U_ISO6 pin 3 (SEL2): expected channel 2 logic control at W (-0.95, 0.25); observed matching function/location on AUDIO_EN. PASS.

U_ISO6 pin 4 (GND): expected ground reference at W (-0.95, 0.75); observed matching function/location on GND. PASS.

U_ISO6 pin 5 (S2): expected channel 2 signal source at E (0.95, 0.75); observed matching function/location on FILTER6N. PASS.

U_ISO6 pin 6 (D2): expected channel 2 signal drain at E (0.95, 0.25); observed matching function/location on ADC6N. PASS.

U_ISO6 pin 7 (SEL1): expected channel 1 logic control at E (0.95, -0.25); observed matching function/location on AUDIO_EN. PASS.

U_ISO6 pin 8 (VDD): expected positive supply at E (0.95, -0.75); observed matching function/location on 5V_LDO_HOLD. PASS.

U_ISO6 pin 9 (GND): expected ground reference at center (0.0, 0.0); observed matching function/location on GND. PASS.

U_ISO7 VERDICT: PASS

Measured: 9 numbered native pads; 9 distinct physical electrical identities (8 leads + EP); 2 unnumbered paste features; 11 total native features; zero fused identities or aliases. Primary: SHA-256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p.3 Figure 4-1/Pin Functions, p.19 Table 7-1/block diagram, pp.30–32 DSG0008A figures. Expected NW pin 1 and CCW perimeter: observed NW pin 1 and CCW; native rotation 180° is consistent.

U_ISO7 pin 1 (S1): expected channel 1 signal source at W (-0.95, -0.75); observed matching function/location on FILTER7P. PASS.

U_ISO7 pin 2 (D1): expected channel 1 signal drain at W (-0.95, -0.25); observed matching function/location on ADC7P. PASS.

U_ISO7 pin 3 (SEL2): expected channel 2 logic control at W (-0.95, 0.25); observed matching function/location on AUDIO_EN. PASS.

U_ISO7 pin 4 (GND): expected ground reference at W (-0.95, 0.75); observed matching function/location on GND. PASS.

U_ISO7 pin 5 (S2): expected channel 2 signal source at E (0.95, 0.75); observed matching function/location on FILTER7N. PASS.

U_ISO7 pin 6 (D2): expected channel 2 signal drain at E (0.95, 0.25); observed matching function/location on ADC7N. PASS.

U_ISO7 pin 7 (SEL1): expected channel 1 logic control at E (0.95, -0.25); observed matching function/location on AUDIO_EN. PASS.

U_ISO7 pin 8 (VDD): expected positive supply at E (0.95, -0.75); observed matching function/location on 5V_LDO_HOLD. PASS.

U_ISO7 pin 9 (GND): expected ground reference at center (0.0, 0.0); observed matching function/location on GND. PASS.

U_ISO8 VERDICT: PASS

Measured: 9 numbered native pads; 9 distinct physical electrical identities (8 leads + EP); 2 unnumbered paste features; 11 total native features; zero fused identities or aliases. Primary: SHA-256 493e5c0d4eb5ca55dea82dbcce59b1be9c353577e256c161821662c38bb9ac55; p.3 Figure 4-1/Pin Functions, p.19 Table 7-1/block diagram, pp.30–32 DSG0008A figures. Expected NW pin 1 and CCW perimeter: observed NW pin 1 and CCW; native rotation 180° is consistent.

U_ISO8 pin 1 (S1): expected channel 1 signal source at W (-0.95, -0.75); observed matching function/location on FILTER8P. PASS.

U_ISO8 pin 2 (D1): expected channel 1 signal drain at W (-0.95, -0.25); observed matching function/location on ADC8P. PASS.

U_ISO8 pin 3 (SEL2): expected channel 2 logic control at W (-0.95, 0.25); observed matching function/location on AUDIO_EN. PASS.

U_ISO8 pin 4 (GND): expected ground reference at W (-0.95, 0.75); observed matching function/location on GND. PASS.

U_ISO8 pin 5 (S2): expected channel 2 signal source at E (0.95, 0.75); observed matching function/location on FILTER8N. PASS.

U_ISO8 pin 6 (D2): expected channel 2 signal drain at E (0.95, 0.25); observed matching function/location on ADC8N. PASS.

U_ISO8 pin 7 (SEL1): expected channel 1 logic control at E (0.95, -0.25); observed matching function/location on AUDIO_EN. PASS.

U_ISO8 pin 8 (VDD): expected positive supply at E (0.95, -0.75); observed matching function/location on 5V_LDO_HOLD. PASS.

U_ISO8 pin 9 (GND): expected ground reference at center (0.0, 0.0); observed matching function/location on GND. PASS.

All eight instances have identical pin-to-net kinds, with only channel numbers changing. Aggregate: 72 numbered pads / 72 physical electrical identities, 16 paste features, 88 native features. No FAIL or QUESTION findings. Limited group verdict SOUND; order remains DO-NOT-ORDER.
