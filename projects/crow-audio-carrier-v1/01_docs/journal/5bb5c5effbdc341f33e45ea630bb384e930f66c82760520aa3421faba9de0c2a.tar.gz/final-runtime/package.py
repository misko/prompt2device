from pathlib import Path,PurePosixPath
import hashlib,json,tarfile,io
S=Path(__file__).parent;R=S.parents[3];O=S.parent/'outputs'
def h(b):return hashlib.sha256(b).hexdigest()
def dump(p,obj):p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
env=json.loads((S.parent/'envelope.json').read_text());identity=json.loads((R/'expected-subject.json').read_text())
rows=[]
for i in env['input_packet']:
 b=(R/i['path']).read_bytes();rows.append({'path':i['path'],'size':len(b),'sha256':h(b),'pass':len(b)==i['size'] and h(b)==i['sha256']})
assert len(rows)==751 and all(x['pass'] for x in rows);dump(S/'inputs-after.json',rows)
header={'review_stage':'pre-route','review_kind':'schematic_render','reviewer_identity':'Codex /root/carrier_rj45_native_carrier_readability_none1','context':'FRESH','date':'2026-09-14','design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER',**identity}
(O/'report.md').write_text(''.join(f'{k}: {v}\n' for k,v in header.items())+'\n'+(S/'report-body.md').read_text())
summary=json.loads((S/'summary.json').read_text());image=json.loads((S/'image-equivalence.json').read_text());fidelity=json.loads((S/'fidelity.json').read_text())
evidence={'subject':env['subject'],'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','identity':identity,'context':'FRESH','reviewer_identity':header['reviewer_identity'],'counts':{'frozen_inputs':751,'subject_hashes':7,'parts':89,'current_pdf_pages':19,'preceding_pdf_pages':19,'visually_opened_current_pages':19,'native_components':333,'native_nets':221,'native_pins':985,'source_traces':1475,'source_native_pin_partitions':221,'explicit_nc_nets':42,'installed_first_power_refs':333,'body_pixels':image['total_body_pixels'],'body_changed_pixels':image['body_changed_pixels'],'locator_refs':23,'locator_pin_rows':46,'source_full_pads':32,'source_none_pads':1,'erc_errors':0,'erc_warnings':2637},'methods':['Frozen owning seven-hash recomputation; full input SHA256 verification before/after','Poppler pdftoppm 144dpi current/prior full-page raster comparison, body y>=120, complete full diff bounding boxes','Direct host view_image inspection of every current full page and current headers','Independent native S-expression inventory and complete preceding/current equality','Independent CircuitJSON source_trace union-find vs native pin partition equality including singleton NC','Full shared-path source byte comparison, textual and parsed semantic delta inspection','Exact first-power and locator reference membership checks, connector native maps, source pad-mode census'],'findings':[],'limits':['Readability scope only; separate topology E-INV acceptance','Measured raster equality at144dpi only','Native6 PCB/return/cut/locator review and pod orientation separate','SOURCE PASS and FULL INCOMPLETE physical obligations remain','FIRST-ARTICLE-ONLY / DO-NOT-ORDER','External checkpoint authority verification owned separately by root'],'source_delta':json.loads((S/'delta.json').read_text()),'image_equivalence':image,'erc_classes':summary['erc']}
dump(O/'evidence.json',evidence)
selected=[]
for p in sorted(S.iterdir()):
 if not p.is_file() or p.name.startswith(('integrated-','package.log','package-runtime','preflight-')):continue
 selected.append(('scratch/'+p.name,p))
for p in sorted((R/'preceding-receipts/readability').iterdir()):
 if p.is_file():selected.append(('preceding-receipts/readability/'+p.name,p))
selected += [('owner/pre_route_review_check.py',R/'context/skills/kicad-pcb/scripts/pre_route_review_check.py'),('review/report.md',O/'report.md'),('review/evidence.json',O/'evidence.json')]
members=[];archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,p in selected:
  assert not p.is_symlink();b=p.read_bytes();ti=tarfile.TarInfo(name);ti.size=len(b);ti.mode=0o644;tar.addfile(ti,io.BytesIO(b));members.append({'path':name,'size':len(b),'sha256':h(b)})
manifest={'archive_sha256':h(archive.read_bytes()),'archive_size':archive.stat().st_size,'member_count':len(members),'members':members};dump(O/'evidence-manifest.json',manifest)
seen=set()
with tarfile.open(archive,'r:gz') as tar:
 for m in tar.getmembers():
  name=PurePosixPath(m.name);assert m.isfile() and not name.is_absolute() and '..' not in name.parts and m.name not in seen and not m.name.endswith(('.tar.gz','.tgz','.tar'));seen.add(m.name)
  b=tar.extractfile(m).read();expected=next(x for x in members if x['path']==m.name);assert expected=={'path':m.name,'size':len(b),'sha256':h(b)}
assert len(seen)==len(members)
dump(S/'archive-reopen.json',{'status':'PASS','member_count':len(seen),'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size']})
dump(O/'result.json',{'subject':env['subject'],'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]})
print(json.dumps({'status':'PASS','outputs':sorted(p.name for p in O.iterdir()),'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'member_count':len(members)}))
