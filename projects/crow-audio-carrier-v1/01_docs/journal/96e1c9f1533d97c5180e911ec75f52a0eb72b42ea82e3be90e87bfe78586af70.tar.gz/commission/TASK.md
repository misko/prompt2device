# Fresh independent D-BACK: real native thermal consumer and return-source owner

Read current-handoff FIRST. Root owns every live A/P/shared file. Five native
candidates are spent, no sixth candidate or routing pilot admitted. No native
BOARD construction, generation, prep, router, changed-property board experiment
or Save. Existing exact board can be loaded read-only and refilled IN MEMORY
with unchanged source/settings to inspect its actual filled polygons and graph.
Do not change a native property and call it a diagnostic rather than a trial.
Bounded source/analytical work and read-only official primary/code lookup allowed.

Actual candidate5 stopped BEFOREprep: generated source-correct new50vertex ADC2
pour reservation and west rectangle, but SAME C_VDDA2_10N.2 GND starved thermal
(1spoke/min2),499unconnected/0parity. All later prepared/native/return stages
NOT_RUN; they are absent, not missing evidence of attempted success. The
previous independent recommendation that this pad-clearance pour reservation
could remedy ordinary placement was a hypothesis, now falsified in this form.
Read exact raw command/stages/source/native. Do not use historical prepared
results to accept this earlier subject or alter gate ordering/floors/allowedtypes.

Required complete bounded causal handback:
1. Independently verify current exact source→generated region/pad/settings,
   especially ADC_VMID2_RETURN_POUR full target plus0.25mm envelope, all50vertices,
   F-only deny:pours/tracks-viasallowed, and ADC_WEST_LOCAL rectxmin89.35.
   Re-derive exact thermal target footprint/net/pad-shape/minimum/default/local
   zone settings and complete affected pad/return/zone population. Explain why
   owning DRC still sees one thermal. Inspect actual filled geometry unchanged,
   and KiCad10 consumer behavior from official docs/source where needed. Separate
   measured behavior, causal source interpretation and untested alternatives.
   Investigate rule-area thermal semantics and any shape/zone issue rather than
   assuming a stale board. Root recorded localpad zone connection -1/inherited;
   this is a fact, not a completed diagnosis.
2. Compare correct owning-source options, including whether an explicit per-pad
   no-zone-connection declaration can express the existing intended via/seed-only
   ground return. This is a PROPOSAL to assess, not authority. Full ambient-plane
   connection was independently rejected for shortcut risk. Preserve all prior
   VMID owner/drop cuts, current explicit ADC8 return/VMID2 seed/via graph and
   minimum2thermalspokes/globalfloors. Do not relabel an unresolved thermal as
   allowed or run prep to hide the ordinary pre-prep refusal. If the existing
   source schema/consumer cannot express supported intent, identify that precise
   upstream representation limitation and complete affected population.
3. Independently judge source-only final five-file composition: original author
   postimages PLUS root-test-supplement in the same test file. Source floor only
   changes westxmin; nets only appends two why rationales, shadowCHASSIS matches
   prior supported mapping, ADR0030append-only. All original20 methods preserved;
   three added methods pin20 narrow GND primitives in10banks with full capsules,
   exactpermissions and full-population hostiles. Root supplement rejects
   conflicting points/region/ref/polygon and has actual helperRED/final23GREEN.
   Original root61run binds originalauthor bytes; final coverage is explicit
   final23 plus unchanged focused38, not a restamped single61run. Review this
   checker property and reproduce meaningful selected RED/GREEN independently.
   Whole source board-producing fixtures remain forbidden. Source-SOUND may be
   separately supported while native remains DEFECTIVE; do not conflate them.
4. Reopen/classify all500 rawrows with nativeUUID/net identities and actual causes.
   The499opens are unprepared stage routing work; zoneUUID can name many islands.
   Distinguish any real unintended current return connection from later routing
   obligation. Do not claim source-defined return proof in a track-free placement.
   Keep existing source-cut declarations as future required proof, not inherited
   physical PASS. No full assembly/orientation/thermal-current/release claim.
5. Return a precise supported upstream decision and next source/preflight/native
   evidence obligations, or explicit INCOMPLETE questions if theory not resolved.
   No candidate6 is admitted by this review, no history/reset/cap alteration. Root
   decides next work only after actual full handback; do not start implementation.

All exact before/after/source/native inputs are frozen; work in scratch. Check
all hashes before/after and retain actual methods/rawlogs/officiallinks. Evidence
must distinguish the failed hypothesis and this new decision without deleting
any earlier refusal. No installs, live edits, children, commits or user approval
inference. Pod current human orientation remains pending. Five exact outputs;
deliveryPASS is compatible with honest nativeDEFECTIVE or domainINCOMPLETE.


Delivery mechanics: Allocated scratch: /tmp/rj45-candidate5-thermal-dback1-v8m9c3l0/06_build/task_runs/rj45-candidate5-thermal-dback1/scratch . Final outputs: /tmp/rj45-candidate5-thermal-dback1-v8m9c3l0/06_build/task_runs/rj45-candidate5-thermal-dback1/outputs . Root sole live writer. Frozen packet read-only; make working copies under the allocated scratch dir only. No live writes, commits, children, background processes, or source adoption. Verify every envelope input before/after. Use /usr/bin/python3 -B and shared pipeline_runtime.run_stage for finite direct-argv subprocesses, explicit cwd/environment, raw stdout/stderr/runtime retained under scratch. Shared runtime is at /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts. Images can be opened with view_image.

Work cutoff 2026-09-13T23:07:59.755969+00:00, hard 2026-09-13T23:14:59.755969+00:00, zero replacements. Stop engineering at work cutoff and return actual FINAL promptly. Preserve honest INCOMPLETE if coverage absent; delivery PASS means complete honest handback, never engineering acceptance. Outputs exactly report.md, evidence.json, evidence-manifest.json, evidence.tar.gz, result.json. evidence.json requires verdict SOUND|DEFECTIVE|INCOMPLETE and exact envelope subject, methods, findings and measured counts. Archive all actual methods/raw evidence/runtime; manifest archive_sha256/archive_size/member_count/members with path,size,sha256; reopen every regular member, no symlink/traversal/duplicate/recursive archive. result.json exact subject, checks inputs-verified/review-complete/evidence-complete PASS only when factually complete delivery; unresolved [] for delivered honest findings. Use preflight.py with exact envelope after packaging to validate delivery. Final response gives domain verdict and unresolved findings, exact report and archive.
