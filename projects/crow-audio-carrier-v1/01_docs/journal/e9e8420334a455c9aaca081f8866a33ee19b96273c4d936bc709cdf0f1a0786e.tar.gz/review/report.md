# Independent mounted-side/model-visibility reassessment

**Decision: candidate1 is an admissible actual-mounted-side correction for the exact eight-fuse subject, with scoped independent geometry evidence and a still-owed G-VACUOUS declaration/fixture. It is not yet an adopted source change.** Candidate2 remains rejected. No third registration method, model repair, source adoption, layout acceptance, release, order, or energized test is authorized by this review. Cumulative coherent variants remain **2**.

The exact review subject is raw `ec59a5c3f114d7e713086a685c6cae7a3f11310de4eafb57eec38f71c6a3657e`, semantic `7c006ec3035a1fe54fd46de92ddfd4e068d88cda21f95cd88e1b883694a0cf7a`. The actual frozen carrier PCB is SHA256 `9c30a147b2d94babd98bc2af4150d4e87270d2efb81a8bd39e88f1b9529a99f4`; these are distinct identities. Candidate1 native engine is `62b7bfc51860fc22f14c6a31993f63b2bfdbafeebb7dc84ddef99bd5093a79ea`.

## Input and source integrity

MEASURED: canonical envelope SHA `c49d70158b9e5a842bb5139e9560461869876d80dad383dcc967e38f921f1073`, all **102/102** frozen input lengths/digests, and every **2,131/2,131** regular member of author archive `552daa03b15d7fb6db457b2607634f64ad5c48a84d7dcaa315adfa529d28de7c` verify. Archive size is 32,261,541 bytes. No links, duplicate paths, traversal, or nested archives were accepted. All nine candidate1 beforeimages equal the corresponding frozen inputs; fresh diffs and hashes are in `source-verification.json` and the nine `.diff` files.

Before selection: original engine demands F.Fab/F.CrtYd for the deliberately back-mounted fuses and rejects them; no candidate is live. After this judgment: select **unchanged candidate1** for narrowly prescribed evidence/ratchet completion, not candidate2 and not an implemented successor. The carrier rule changes only the fuse group's `mount_side: front` to `back`. Candidate1 selects the native mounted-side datums, validates declared/native side, preserves the native flip during coupon normalization, chooses the bottom camera and orders inverse mirrored boxes. Its signed-side predicate and threshold are unchanged. All 17 pre-existing test/helper functions are AST-identical; the three additions are the mounted fixture and two tests. Nothing in this review changes them.

## Independent concrete geometry

MEASURED using `native_subject.py`, KiCad's native `pcb export vrml`, `derive_geometry.py`, and `native_representation_probe.py`. Neither derivation imports a checker/model transform. The review copy retains the exact eight native footprints and full board outline, removes unrelated footprints, and rebinds model paths to the identical frozen WRL. Its bytes consequently differ from the full source PCB; the native census and original hash preserve that distinction.

The WRL has **three explicit IndexedFaceSet rectangular solids, 24 listed corners, 18 quad faces, and zero internal Transform/Inline/USE nodes**. All eight corners per solid are independently checked against its Cartesian extrema. Direct coordinate bounds, multiplied by the native unit factor 2.54, are X ±2.365, Y ±1.705, Z 0..1.800 mm: **4.730 × 3.410 × 1.800 mm**. Native-exported mesh extrema independently agree within 0.000002 mm. This is the actual derived drawing-envelope model despite its filename, **not manufacturer CAD, nominal physical height, or physical qualification**.

Native export establishes a PCB-midplane frame: X=PCB X, Y=−PCB Y, Z upwards. The declared board thickness is 1.600 mm, with nominal mounting faces at Z ±0.800 mm. Its exported laminate-color mesh spans approximately ±0.7875 mm. The native model operators are independently evaluated from exported axis-angle rotations with Rodrigues' formula; source vertices are transformed through those operators, not through gate code.

| Refs | Native PCB positions mm | Native angle | Mount / model pose | Actual model Z mm |
|---|---|---:|---|---|
| F1–F4 | (32.2,31.4), (64.2,31.4), (96.2,31.4), (128.199999,31.4) | 0° | B.Cu; offset/rotation zero; scale 1 | −2.600..−0.800 |
| F5–F8 | (48.8,108.6), (80.8,108.6), (112.8,108.6), (144.8,108.6) | 180° | B.Cu; offset/rotation zero; scale 1 | −2.600..−0.800 |

Every one of eight exported translations matches the corresponding native footprint center within 0.000002 mm. The 0° mount uses an X-axis half-turn; the 180° mount uses a Y-axis half-turn. Every real body is fully outside the nominal stack on the back, except its zero-volume contact plane. There is **1.800 mm outward depth and 0.900 mm centroid distance** from that face. There is **zero standoff**, not a positive clearance. The reported tiny ~1e−7 mm Z errors are exporter rounding, not penetration evidence.

A malicious X180 inversion of the **same real model at all eight actual placements** independently exports to Z −0.800..+1.000 mm. It emerges **0.200 mm beyond the opposite face**. Candidate1 freshly rejects it: signed back fraction **0.062581**, versus unchanged **0.750000** minimum, a 0.687419 fraction separation. The actual good model passes **8/8 bodies, 16/16 pad overlaps**, maximum center error 0.031 mm, minimum per-pad overlap 1.930 mm², zero Fab/courtyard excursion and signed back fraction 1.000000. This establishes concrete margin for these bytes, not a universal 1.8 mm visibility floor.

## What the failed synthetic model really represents

The original simplifying explanation “a wholly buried inverted 1 mm body” is **rejected**. The source intends a Box of height 1 with inner translation 0.5 under outer scale 0.393700787. Native export retains that outer scale but exports the inner translation as **0.19685039**. Its actual imported local Z therefore spans approximately **−0.30314960..+0.69685038 mm**, rather than the source-intended 0..1.

With the saved back mount and X180 inversion, all three actual synthetic placements (0°, +90°, −90°) occupy approximately **−1.10314960..−0.10314962 mm**. About **0.30315 mm** remains genuinely outside the intended back face, while about **0.69685 mm** lies inside the nominal board slab. The equivalent front case occupies +0.10315..+1.10315 mm. Thus all *visible exterior* body can appear on the declared side although most of the solid occupies the board. This is a visibility/representation blind spot, not evidence that a reflected volume is correctly registered.

Fresh results:

| Exact review probe | Owning checker result | Signed intended-side fraction |
|---|---|---:|
| Original engine, mirrored front 1 mm malicious case | false PASS, 3/3 | 1.000000 |
| Candidate1, same front case | false PASS, 3/3 | 1.000000 |
| Candidate1, original back case | false PASS, 3/3 | 1.000000 |
| Original engine, height-only 3 mm front contrast | FAIL, signed-side reason | 0.683611 |
| Candidate1, height-only 3 mm back contrast | FAIL, signed-side reason | 0.653401 |

The single contrast parameter is height h, with source translation h/2 retaining the same intended base plane; XY, footprint positions, poses, pads, tolerances and denominator remain fixed. `replay_vacuity.py` reconstructs these two cases and **first asserts the malicious PASS, then asserts the genuine signed-side FAIL**. It is a successful review replay, not an adopted decorated fixture.

Both front/back pixels were opened visually. The 1 mm side views contain actual gray model pixels protruding on the declared side. An independent color census finds 1,709 gray pixels below the back board strip and zero above; the corresponding front case has 1,851 above and zero below. The real fuse side has 23,364 brown pixels below and zero above; its inversion has 3,564 above and 396 below. These are diagnostic color observations of these particular images, not a replacement gate or precise physical metrology. The plan overlay shows all eight fuse bodies centered on the mounted B.Fab envelopes and overlapping both native lands. Side silhouettes overlap along camera rays, so side-image visible-object count is not the eight-reference denominator; the native census supplies it.

Consequently bare-copper contamination alone and a generic “subtraction should fix this” claim are rejected. Native body pixels really exist on the declared side. The separate exporter transform chain explains the representation shift and the images corroborate it. No universal VRML-compliance diagnosis is made. The actual direct-coordinate fuse has no nested-transform mechanism and its entire volume is outside the stack.

INHERITED, reopened in the verified author archive: candidate1 maintained suite **13 passed / 0 failed / 10 known-bad**, original-source swap **0 passed / 2 failed** on the added mounted tests, restored mounted tests **2/2**, and carrier orchestration **6/6 groups**. Those broad runs were not repeated here. Candidate2's preserved terminal result is **12 passed / 2 failed**; it falsely passes both its new buried case and the old extended-SMD front inversion control. Its six-group pass cannot rescue it. It remains rejected unchanged.

## Required completion and decision forks

G-VACUOUS in the frozen canon and tests/README explicitly distinguishes a declared false PASS from a known-bad must-fail control. M1 still requires independent evidence for the concrete design; declaration alone is insufficient. The existing failure occurs under the original front checker and the side predicate is unchanged, while all original test functions remain unchanged. Thus the evidence supports candidate1's side correction with a bounded, existing blind spot; it does **not** establish a new safety weakening that demands rewriting this real fuse model.

Before source integration is considered complete, the owner must add this exact block to the native engine's **module docstring** and bind it to an executable new fixture:

```text
VACUITY: Signed-side fractions measure visible exterior pixels, not full
model volume. A 1 mm nested-Transform Box with a 180-degree model-X
inversion can PASS on a 1.6 mm PCB while most native-imported solid lies
inside the board. In the pinned native consumer, about 0.30315 mm remains
outside the declared side and about 0.69685 mm is inside the nominal
stack; the measured intended-side fraction is 1.0. The original front
checker shares this failure. The bound fixture asserts this false PASS
first, then requires a signed-side FAIL when only height h changes from
1 to 3 mm with translation h/2. This gate does not establish full-volume
board exclusion; exact-model independent geometry evidence is required
when that property is load-bearing.
```

Use `@test("native signed-side visibility omits buried model volume", kind="vacuity", gate="native_model_registration.py")`. Its first assertion must be `must_pass` on the malicious case; subsequently `must_fail` on the measured height-only contrast, asserting the signed-side reason so unrelated breakage cannot count. Preserve the original front control, the candidate1 asymmetric 0/90/270 and unmirrored-camera controls, and every candidate2 rejected must-fail observation. **Do not reclassify or weaken an existing required-fail test.** The new vacuity fixture records a separate observed limitation; source work has not been done by this reviewer.

Bind the exact-board geometry, source/model hashes, eight poses, exporter method and hostile inversion result into the owner-reviewed evidence. Reopen candidate1 through the normal native and aggregate gates after integration, run the maintained regression/contract checks and the G-VACUOUS binding audit, and preserve the receipt denominator and ordinary tuple invalidation. A documentation/fixture binding change alters tool identity; old cache receipts cannot simply be restamped. Scope accepted by this judgment is **only the candidate1 correction and exact model-registration argument**, not full carrier placement or assembly release.

The preferred next decision is evidence/ratchet completion with the selected algorithm unchanged. This is no new numerical search and creates no third coherent variant. The exhausted source envelope does not permit another launch merely renamed as documentation: root must preserve variants2 and record its reviewed, limited completion scope before executing any further owner work under the applicable runtime.

If the owner cannot satisfy that bound declaration, an unchanged required-fail control fails after integration, or a changed real asset introduces internal transforms/buried volume, keep source admission NON-PASS and reopen the **model/adjudication producer** at P-MODEL-REG. The decisive property is the native-consumed full-solid Z relative to the stack, including internal transforms, not a greener pixel ratio. One potentially discriminating upstream experiment would native-export the same nested model and a mathematically equivalent flattened direct-coordinate representation, preserving dimensions and external pose: native geometry agreement would reject the representation hypothesis; disagreement would identify a representation repair. **That experiment is not authorized under this exhausted hypothesis/cap and was not performed.** It requires an explicitly reviewed changed model-representation question with cumulative history intact. No universal parser project is mandatory for the currently proven direct-coordinate model.

## Delivery limits

All measurements are scratch-only and bounded through shared `pipeline_runtime.run_stage`, at most 300 seconds per outer stage. Three diagnostic setup failures are retained: unavailable pcbnew thickness accessor, absent NumPy, and invalid console-tail configuration. They were replaced by text thickness/native export, pure standard-library algebra, and valid observer configuration; none changed the checker or source model. Native export of the author's synthetic source warns that it has no proper outline; the gate's generated coupons do have an explicit outline and the source model-transform evidence is still readable. This warning is retained, not a DRC claim.

The review archive contains only fresh review methods, their pinned execution dependencies and measurements, including failed diagnostics. The original author archive is referenced above, not nested. Delivery checks passing mean this independent judgment and its handback are complete; the still-owed source/doc/fixture work and all downstream acceptance boundaries remain explicit. Root remains sole live writer and owns closure/preservation.
