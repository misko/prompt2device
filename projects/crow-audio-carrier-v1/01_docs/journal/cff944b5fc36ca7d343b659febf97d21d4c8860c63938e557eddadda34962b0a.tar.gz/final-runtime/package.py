from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,shutil,io
s=Path(__file__).parent;o=s.parent/'outputs';o.mkdir(exist_ok=True)
env=json.loads((s.parent/'envelope.json').read_text())
for n in ['report.md','evidence.json']:shutil.copyfile(s/n,o/n)
(o/'result.json').write_text(json.dumps({'subject':env['subject'],'checks':{k:'PASS' for k in env['completion']['checks']},'unresolved':[]},indent=2)+'\n')
files=sorted(p for p in s.rglob('*') if p.is_file() and not p.is_symlink() and not p.name.endswith('.tar.gz'))
archive=o/'evidence.tar.gz';records=[]
with tarfile.open(archive,'w:gz') as tar:
 for p in files:
  name=p.relative_to(s).as_posix();b=p.read_bytes();i=tarfile.TarInfo('evidence/'+name);i.size=len(b);i.mode=0o644
  tar.addfile(i,io.BytesIO(b));records.append({'path':i.name,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
seen=set()
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(records)
 for member,record in zip(members,records):
  name=PurePosixPath(member.name)
  assert member.isfile() and not name.is_absolute() and '..' not in name.parts and member.name not in seen and not member.name.endswith('.tar.gz')
  seen.add(member.name);b=tar.extractfile(member).read()
  assert record=={'path':member.name,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()}
manifest={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_size':archive.stat().st_size,'member_count':len(records),'members':records}
(o/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='members'}))
