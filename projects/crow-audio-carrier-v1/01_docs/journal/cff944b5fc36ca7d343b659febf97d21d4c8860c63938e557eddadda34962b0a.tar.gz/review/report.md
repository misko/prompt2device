review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_conversion_mountedframe1 (same independent original reviewer)
context: CONTINUATION of independent original pin review with requested native ADC strap facts; not a new fresh agent
review_disposition: FIRST-ARTICLE-ONLY
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7
subject_raw_sha256: e208b779ab4c1f5efb4c3f438ae34f2e16a3f21444ecf9539183028af744329d
subject_semantic_sha256: d59c9dfb39ff827029a8e486a65c79e5ea3262fbb07ffab19cd03d8907b9b70e

The sole original question Q1 is resolved by the added native strap dossiers and exact primary resistor PDFs. Both commissioned refs U_ADC and U_LDO now PASS within the original pin/net review scope. This is a bounded continuation of my own original review, not a new fresh review or a replacement of the closed INCOMPLETE delivery. No whole-board, clock-source/timing, channel-order system, routing, assembly-file or production acceptance follows. FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains in force.

## Exact continuation provenance

Original task: rj45-pin-carrier-conversion-mountedframe1. Original report bytes are included unchanged as previous-completed-report.md, SHA-256 c503197ab32c1baf101dfec1a36f465cf2561448c240da4bf3f5c63dc97f5578, 11623 bytes. Original subject raw SHA-256 084c8feea47a96890190eb4e165a289213c3182484692775ad05c2995190f84f; semantic SHA-256 cff15c2597f85a783ec9ab7a5133740a27b050694cac0be01dcb54c166b510c2. The supplied previous-closeout.json binds the archived original delivery to SHA-256 361bb86619da71a7f1c64182238461e4154d6f1126d1f076044216686a1a30cb, 2754188 bytes; it records the original 76-member evidence archive was reopened. That original archive is inherited evidence, not reopened from the live project during this continuation.

The unchanged U_ADC dossier is SHA-256 804a07d935a6dbe2c1f2366b3ee3aee3d3bc0b53260bb19c9b0995417d40acde; U_LDO is cd67b0631b413bfd67e54be79032816924d24d92494f20ac916159ab78247b2f. All original primary PDF digests are unchanged and reverified. The new envelope canonical SHA-256 is 6b964100f479f94dff5e2212bdfd6420e508beb162fd48ed3fefde7c2df46f14. This report uses its new exact subject above, while preserving the original commissioned board/parts/rules bindings as metadata.

Inherited proof: original primary figure inspection, package winding, pin-1 positions, separate terminal/EP identities, all function identities, static net classes and instance symmetry. The original method disclosure, including the bootstrap dossier-read sequence, remains in the unchanged original report. Newly verified proof: the values, geometry and native net endpoints of R_CFG1, R_CFG2, R_CFG4 and R_CFG5; the corresponding actual ADC hardware mode and applicability of grounded/unused ADC pins. Successful whole-group physical inspection was not repeated.

## Newly verified supporting resistor facts

Actual primary PDF p.1 images show a two-terminal 0402/1005 resistor, nominal 1.0 × 0.5 × 0.35 mm, with end metallization and no EP, polarity mark, or manufacturer terminal numbering. Two collinear nonpolar contacts establish no winding or privileged pin-1 corner. Pads 1 and 2 are distinct interchangeable physical end terminals; no fusion or alias is asserted. Each dossier is front F.Cu, native rotation 180°, with component-top pad 1 (-0.51,0), pad 2 (+0.51,0), both 0.54 × 0.64 mm. Native-to-local conversion is rotation only after translation, never a mirror. Each has two measured numbered native rows, two unique centers and two represented physical terminals; zero missing/duplicate identities, zero EPs. The same-MPN R_CFG1/R_CFG4 instances retain the same terminal types; opposite pull direction is a legitimate configuration choice.

| Supporting ref | Exact primary PDF hash (p.1 drawing and Specifications) | Primary value | Native pad 1 → pad 2 nets | Result |
|---|---|---|---|---|
| R_CFG1 | b894ff1ce27e9567b396a6cb9c16750970e4145c03bf64367db0cc8ca107459f | RC0402FR-074K7L, 4.7 kΩ, 1% | CFG1 → GND | PASS |
| R_CFG2 | 86e35763f809c9aa780f4e8ad0d3d6f71b57a3d3afdeb5f523837e5a29da9813 | RC0402FR-070RL, zero-ohm jumper | CFG2 → 3V3_ADC | PASS |
| R_CFG4 | b894ff1ce27e9567b396a6cb9c16750970e4145c03bf64367db0cc8ca107459f | RC0402FR-074K7L, 4.7 kΩ, 1% | CFG4 → 3V3_ADC | PASS |
| R_CFG5 | e42aa2b39be7476fef25efbe4656acbbc246d2b9b625d64db6b46e0f5e34d7af | RC0402FR-07100KL, 100 kΩ, 1% | CFG5 → GND | PASS |

R_CFG1 native pads are (87.91,63.90)/(86.89,63.90); R_CFG2 (85.01,70.40)/(83.99,70.40); R_CFG4 (87.91,76.10)/(86.89,76.10); R_CFG5 (87.91,74.30)/(86.89,74.30). Measured transform residuals are below 1e-13 mm. The eight new pad rows are recorded in support-measurements.json. These four refs are supporting context; the commissioned group remains U_ADC/U_LDO.

## U_ADC — VERDICT: PASS

Primary CS5308P DS1314F1 SHA-256 6ca42cc09ac47ebdacacaee435f05e3f9c34b83d5692e52a2d8a26533e810e57. Inherited actual figure evidence: PDF p.4 Figure 1-1 (explicit TOP VIEW), p.5 Table 1-1, p.8 Figure 2-2, p.93 Figure 10-1. Newly rendered and inspected: pp.19–20 Tables 4-1–4-4; p.6 Table 1-2; p.35 Table 4-13; pp.36–37, especially Figure 4-15 and accompanying DOUT usage text.

Inherited physical findings remain PASS: 49 measured numbered native rows, 49 unique pad numbers/centers, 49 physical identities (48 perimeter terminals and one PAD mapped to artifact 49), no missing or duplicate identities. Pin 1 is upper-left west, pins 1–12 run down west, 13–24 across south, 25–36 up east, 37–48 back across north: CCW. Front mounting, zero rotation and no mirror match the manufacturer TOP VIEW. Inherited signed twice-area is -67.37 mm² in y-down coordinates. EP49 is 4.6 × 4.6 mm at (0,0), GND; pitch is 0.4 mm with 12 terminals on each edge. No fused pins/aliases. Nine unnumbered paste/mechanical pads are reported in the dossier footer, not independently measured from its omitted rows.

Q1 resolution, derived from the actual connections without assuming a desired mode:

U_ADC pin 2 (CONFIG1): expected 4.7 kΩ pull-down to GND_A to select hardware ASP Secondary Mode at 44.1/48 kHz per Table 4-1; observed CFG1 through R_CFG1=4.7 kΩ to GND — PASS. This excludes software-control selection and sample-rate autodetect.
U_ADC pin 3 (CONFIG2/HGC_SCK): expected zero-ohm pull-up to VDD_A for TDM minimum time slots per Table 4-1; observed CFG2 through R_CFG2=0 Ω to 3V3_ADC, the same rail as ADC VDD_A pins 5 and 9 — PASS.
U_ADC pin 4 (CONFIG3/HGC_SDO): expected default slots 0–7 in eight-slot mode per p.36; observed GND, which Table 4-2 identifies as the lower slot group — PASS.
U_ADC pin 10 (CONFIG4/HGC_CS): expected 4.7 kΩ pull-up for default channel order per Table 4-3; observed CFG4 through R_CFG4=4.7 kΩ to 3V3_ADC — PASS. It does not select reversed ASP channel order.
U_ADC pin 11 (CONFIG5): expected 100 kΩ pull-down for linear-phase, fast-roll-off filtering with HPF enabled per Table 4-4; observed CFG5 through R_CFG5=100 kΩ to GND — PASS.
U_ADC pin 25 (ASP_DOUT1): Table 4-13 at 44.1/48 kHz and minimum-slot TDM selects one output with eight slots per frame; p.37 Figure 4-15 explicitly assigns it to DOUT1. Observed TDM_RAW on pad 25 — PASS.
U_ADC pins 26,27,28 (ASP_DOUT2–4): expected unused in eight-slot mode per p.37, floating per Table 1-2; observed the three distinct unconnected-(U_ADC-ASP_DOUTx_NC-Padn) nets — PASS.
U_ADC pins 35,36,37 (SPI_SDO/I2C_SCL,SPI_SCK,SPI_SDI/I2C_SDA): expected unused control-port pins grounded per Table 1-2 because CONFIG1 establishes hardware control; observed GND on all three — PASS.
U_ADC pin 38 (SPI_CS): expected unused pin connected to VDD_IO per Table 1-2; observed 3V3_ADC, identical to VDD_IO pin 31 — PASS.

The derived mode requires external secondary-mode clocks. Table 4-13 requires BCLK ≥256 fs and a constant integer multiple of fs; this corresponds to at least 11.2896 MHz for 44.1 kHz or 12.288 MHz for 48 kHz. ADC_FSYNC, ADC_BCLK and ADC_MCLK remain signal-net-class passes inherited from the original review. Actual external clock generation and timing are not part of this requested missing-strap completion and are not asserted as verified.

All other ADC findings remain inherited PASS: pins 5/9/31 share 3V3_ADC; 6/8/30 and EP49 are GND; 32/33 share LDO_D_FILT as required; 7,1,12 have dedicated LDO/reference nodes; 17/44 are ground-side filter connections; 18/43 are dedicated filter-positive nodes; the eight differential pairs preserve N/P; 23/24/29/34 use reset/synchronization/clock signal nets. All 49 primary function identities matched the original native rows. One instance is supplied, so inter-instance symmetry is not applicable.

The inherited channel-label permutation remains explicit: manufacturer IN1/2/3/4 connect to ADC4/3/2/1 net pairs, while IN5–8 connect to ADC5–8. With newly established default ASP order, TDM slots 0–7 therefore carry the input pairs named ADC4,ADC3,ADC2,ADC1,ADC5,ADC6,ADC7,ADC8. This is an observed mapping, not an assertion that an external system's channel naming convention is correct.

## U_LDO — VERDICT: PASS (inherited, unchanged)

Primary LT3041 Rev.A SHA-256 35dda1deb2ffc9e20545ebe2aefd2fbd690cf9b04e8772290fd4991a4b8ef584; original actual images pp.7–8 Figure 3/Table 3, p.31 Figures 87–89, p.36 Figure 98 package 05-08-1708. The exact ADE#TRPBF ordering entry is bound to that DFN package.

Inherited measured counts: 15 numbered native rows, 15 unique numbers/centers and 15 physical identities (14 terminals plus EP15), no missing/duplicate identities, no fusion or aliases. Two seven-terminal side rows at 0.5 mm pitch; upper-left pin 1; CCW numbering; signed twice-area -17.4 mm² in y-down coordinates. Front-mounted, zero rotation against Figure 3 TOP VIEW. Figure 98 bottom-view conversion was explicitly mirror-x to top view then clockwise 90° rotation; this did not mirror the dossier. EP15 is 1.7 × 3.3 mm on GND. Eight unnumbered paste/mechanical pads are footer-reported only.

U_LDO pins 1/2/3 (IN): expected common input rail; observed 5V_LDO_HOLD — PASS.
U_LDO pins 4/6 (VIOC/PG): expected float when unused; observed distinct unconnected nets — PASS.
U_LDO pin 5 (EN/UV): expected enable/UVLO node; observed LDO_EN — PASS for net class.
U_LDO pin 7 (ILIM): expected ground when external current limit is unused; observed GND — PASS.
U_LDO pin 8 (PGFB): expected IN tie when PG/fast start are unused; observed 5V_LDO_HOLD — PASS.
U_LDO pin 9 (SET): expected dedicated setpoint/bypass node; observed LDO_NR — PASS for net class.
U_LDO pins 10/11/15 (GND/GND/EP): expected GND; observed GND — PASS.
U_LDO pins 12/13/14 (OUTS/OUT/OUT): expected output sense and common output rail; observed 3V3_ADC — PASS for net connectivity.

All 15 function identities matched. One instance was supplied; IN/OUT/GND same-function groups are internally symmetric. External setpoint/capacitor values, Kelvin routing and thermal implementation remain outside the original pin-table scope.

## Delivery and remaining scope

No unresolved engineering finding remains within this bounded group pin review. The previous report remains historically INCOMPLETE; this new SOUND continuation applies only with the added native facts and its exact envelope subject. All 16 envelope inputs were verified before/after by size and SHA-256. Actual new PDF images, native supporting dossiers, original report/closeout, measurements, scripts and stage logs are archived. Finite direct-argv subprocesses used /usr/bin/python3 -B and shared pipeline_runtime.run_stage with explicit cwd/environment and retained raw stdout/stderr/runtime. Only allocated scratch/output paths were written. The evidence archive is reopened member-by-member and hashed; the exact-envelope preflight validates the final delivery. Delivery PASS does not authorize order or expand the scope beyond U_ADC/U_LDO.
