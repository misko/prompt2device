from pathlib import Path
S=Path(__file__).resolve().parents[1];R=S.parents[3];A=S/'work/projects/crow-audio-carrier-v1';P=S/'work/projects/crow-mic-pod-v3'
p=A/'03_src/check_analog_paths.py';t=p.read_text();needle="    short = {(x['from'],x['to']):x for x in config['short_paths']}";replacement="""    admitted_nets={net for target,net in expected.values()}
    audio_seeds=[x for x in route['prep']['seed_stubs']['stubs'] if x.get('net','').startswith('AUDIO_')]
    if len(audio_seeds)!=32 or {x['net'] for x in audio_seeds}!=admitted_nets:
        raise PathError('entry source requires exactly the two named prefix/post banks for sixteen AUDIO nets')
    if route['prep']['seed_stubs']['via'] != {'size':.50,'drill':.20}:
        raise PathError('entry launch via family differs from admitted0.50/0.20mm')
"""+needle;assert needle in t;t=t.replace(needle,replacement);p.write_text(t)
p=A/'03_src/tests/test_rj45_entry_paths.py';t=p.read_text().replace("'extra-bank'):","'extra-bank','unknown-bank','via-family'):").replace("            if defect=='extra-bank':", "            if defect=='unknown-bank':r['prep']['seed_stubs']['stubs'].append(dict(net='AUDIO_P9',pin='J9.5',segments=[]))\n            if defect=='via-family':r['prep']['seed_stubs']['via']['size']=.6\n            if defect=='extra-bank':");p.write_text(t)
p=A/'03_src/tests/test_thermal_source.py';t=p.read_text().replace('shape=rect_shape(area[\'rect\'])','shape=area_shape(area)').replace('from test_regulator_source import','from test_adc_source import area_shape\nfrom test_regulator_source import').replace('(11,18)','(11,43)');p.write_text(t)
# Actual final native return census, adapted from independently reviewed read-only full-shape graph.
original=(S/'reference-methods/rj45-adc-return-reassessment1/independent.py').read_text();prefix=original[:original.index('supply=pid(')];prefix=prefix.replace("S=pathlib.Path(__file__).parent;P=S/'selected/history/candidate2/native/06_build/route/r0.kicad_pcb';", "S=pathlib.Path(__file__).resolve().parents[1];P=pathlib.Path(sys.argv[1]);")
prefix=prefix.replace("print('loaded native'", "print('loaded final candidate native'")
tail='''
carrier='carrier' in str(P);result={'board_path':str(P),'board_sha256':before,'stored_fill_counts':stored,'fill_method':'fresh in-memory fill of exact final saved candidate; no Save','objects':objects,'ground_edges':edges,'ground_nodes':len(gnd),'ground_pair_checks':pairs,'planes':sorted(planes)}
if carrier:
 vmid=[]
 for bank,pin,drop in [(1,6,[91.6,69.5]),(2,8,[89.8,71.5])]:
  owner=pid('U_ADC',pin);drops={i for i in gnd if objects[i]['kind']=='via' and math.dist(objects[i]['xy'],drop)<1e-6}
  for cap in ['470N','4U7']:
   a=pid(f'C_VMID{bank}_{cap}',2);vmid.append(dict(ref=f'C_VMID{bank}_{cap}',owner=summary(owner),drops=[summary(i) for i in drops],intact=bfs(a,planes),cut=bfs(a,planes,drops|{owner}),surface_owner=bfs(a,{owner},{i for i in gnd if objects[i]['layer']!='F.Cu' or objects[i]['kind']=='zone'}),direct_zone=[i for i in adj[a] if objects[i]['kind']=='zone']))
 outpad=pid('C_LDO_OUT',2);quiet=[]
 for ref in ['C_LDO_NR4','C_LDO_NR5','R_LDO_SET']:
  a=pid(ref,2);quiet.append(dict(ref=ref,to_output=bfs(a,{outpad}),intact=bfs(a,planes),cut=bfs(a,planes,{outpad}),direct_zone=[i for i in adj[a] if objects[i]['kind']=='zone']))
 paddle=pid('U_ADC',49);ground=[]
 for pin in [6,8,30,17,44]:
  a=pid('U_ADC',pin);ground.append(dict(pin=pin,surface=bfs(a,{paddle},{i for i in gnd if objects[i]['layer']!='F.Cu'}),through_plane=bfs(a,{paddle})))
 supply=pid('C_VDDA1_10N',2);drops=[i for i in gnd if objects[i]['kind']=='via' and math.dist(objects[i]['xy'],[90,67.5])<1e-6];contain=[]
 for i in drops:
  site=objects[i]['xy'];circ=shapes[i]
  for j in adj[i]:
   o=objects[j]
   if o['kind']!='zone':continue
   rings=[o['outer']]+o['holes'];boundary=[]
   for ring in rings:
    for aa,zz in zip(ring,ring[1:]+ring[:1]):boundary.append(k.SHAPE_SEGMENT(v(*aa),v(*zz),0))
   contain.append(dict(via=summary(i),zone=summary(j),center_inside=shapes[j].Contains(v(*site)),full_disk_margin=min(gap(circ,e) for e in boundary)))
 expected14={f'C_ISO{i}.2' for i in range(1,9)}|{'C_ADC_CM4P.2','C_ADC_CM4N.2','U_LDO_EN.3','C_VDDA1_10N.2','C_VMID1_470N.2','C_VMID2_470N.2'}
 settings=[summary(i) for i in gnd if objects[i]['kind']=='pad' and objects[i].get('ref','')+'.'+objects[i].get('pad','') in expected14]
 result.update(vmid=vmid,quiet=quiet,ground_queries=ground,supply_to_plane=bfs(supply,planes),supply_drop_containment=contain,additional_full_pads=settings)
 result['checks']={'vmid4':len(vmid)==4 and all(r['intact'] and r['surface_owner'] and not r['cut'] and not r['direct_zone'] and len(r['drops'])==4 for r in vmid),'quiet3':len(quiet)==3 and all(r['to_output'] and r['intact'] and not r['cut'] and not r['direct_zone'] for r in quiet),'paddle5':len(ground)==5 and all(not r['surface'] and r['through_plane'] for r in ground),'supply_closure':bool(result['supply_to_plane']) and len(drops)==4,'supply_disk4':len(contain)==4 and all(r['center_inside'] and r['full_disk_margin']>0 for r in contain),'exact14_full_pads':len(settings)==14 and all(r['zone']==2 for r in settings)}
else:
 refs=sorted({objects[i]['ref'] for i in gnd if objects[i]['kind']=='pad'});pads_ground=[]
 for i in gnd:
  if objects[i]['kind']=='pad':pads_ground.append(dict(pad=summary(i),plane_path=bfs(i,planes)))
 result['ground_pads']=pads_ground
 result['checks']={'C10_broad_return':bool(bfs(pid('C10',2),planes)),'U3_broad_return':bool(bfs(pid('U3',4),planes))}
 result['R7_C9_remaining_island']=[r for r in pads_ground if r['pad']['ref'] in ['R7','C9']]
assert hashlib.sha256(P.read_bytes()).hexdigest()==before
(S/('carrier-return-graph.json' if carrier else 'pod-return-graph.json')).write_text(json.dumps(result,indent=2));print(result['checks'],flush=True)
sys.exit(0 if all(result['checks'].values()) else 1)
'''
(S/'methods/native_returns.py').write_text(prefix+tail)
# Native measurements have no inherited acceptance label.
t=(R/'candidate3-methods/native_measure.py').read_text().replace("'generated placement; prepare failed and no seed copper saved' if kind=='carrier' else 'prepared and filled native candidate'","'candidate4 native; preparation status is separately recorded'")
(S/'methods/native_measure.py').write_text(t)
(S/'methods/fill.py').write_text((R/'candidate3-methods/fill.py').read_text())
(S/'methods/render_native.py').write_text((R/'candidate3-methods/render_native.py').read_text())
print('Finite source guard coverage and native measurement/graph methods prepared; no native execution.')
