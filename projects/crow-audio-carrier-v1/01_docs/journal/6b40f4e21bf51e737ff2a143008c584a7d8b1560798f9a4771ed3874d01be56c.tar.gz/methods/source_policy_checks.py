from pathlib import Path
import sys,os,json,hashlib,yaml
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_runtime import run_stage
S=Path(__file__).resolve().parents[1];R=S.parents[3];T=S/'work/skills/kicad-pcb/scripts';env={k:os.environ[k] for k in ['PATH','HOME','LANG'] if k in os.environ};env['PYTHONDONTWRITEBYTECODE']='1';results=[]
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 P=S/'work/projects'/slug;kind='carrier' if 'carrier' in slug else 'pod'
 for tag,script,args in [('module-first','module_first_check.py',[]),('power','power_topology.py',['--margin','--off-control']),('rules-source','rules_audit.py',['--phase','source']),('policy-source','policy_audit.py',['--skip-drc','--phase','source'])]:
  name=kind+'-'+tag;argv=['/usr/bin/python3','-B',str(T/script),str(P),*args];r=run_stage({'id':name,'work_class':'local','timeout_s':120},argv,log_path=S/'logs'/f'{name}.log',cwd=P,env=env,console_line_limit=25);(S/'logs'/f'{name}.runtime.json').write_text(json.dumps(r.to_mapping(),indent=2));results.append(dict(name=name,rc=r.returncode))
A=S/'work/projects/crow-audio-carrier-v1';inventory=json.loads((R/'root/carrier-module-boundary-inventory.json').read_text());groups=inventory['groups'];local=set(sum([groups[k]['refs'] for k in ['analog_channel_support','adc_references_modes_clocks_reset_interfaces','external_bias']],[]));allrefs=set(sum([g['refs'] for g in groups.values()],[]));rules=yaml.safe_load((A/'03_src/rules/integration.yaml').read_text());assert len(local)==252 and set(rules['selections'][0]['support_refs'])==local and 'U_ADC' not in local;assert len(allrefs-local-{'U_ADC'})==80;assert set(rules['selections'][1]['support_refs'])==set(groups['buck_local_support']['refs']) and len(groups['buck_local_support']['refs'])==9
five=[]
for p in (R/'adc-source-fragment/source').rglob('*'):
 if p.is_file():
  q=S/'work'/p.relative_to(R/'adc-source-fragment/source');a=hashlib.sha256(p.read_bytes()).hexdigest();z=hashlib.sha256(q.read_bytes()).hexdigest();assert a==z;five.append(dict(path=str(q.relative_to(S/'work')),sha256=z))
assert len(five)==5;assert rules['module_support_threshold']==10
(S/'source-policy-checks.json').write_text(json.dumps(dict(stages=results,adc_files=five,local_adc_support=sorted(local),other_dependencies=sorted(allrefs-local-{'U_ADC'}),buck_support=groups['buck_local_support']['refs'],counts=dict(adc_support=252,other_dependencies=80,buck_support=9,adc_files=5)),indent=2));print(results)
