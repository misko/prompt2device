from pathlib import Path
import sys,json,yaml,copy,math,hashlib
S=Path(__file__).resolve().parents[1];R=S.parents[3];A=S/'work/projects/crow-audio-carrier-v1';P=S/'work/projects/crow-mic-pod-v3'
sys.path.insert(0,str(A/'03_src/tests'));from test_adc_source import area_shape
import pcbnew as p
checks=[]
f=yaml.safe_load((A/'03_src/floorplan.yaml').read_text());r=yaml.safe_load((A/'03_src/route.yaml').read_text());beforef=yaml.safe_load((R/'candidate3-work/projects/crow-audio-carrier-v1/03_src/floorplan.yaml').read_text());beforer=yaml.safe_load((R/'candidate3-work/projects/crow-audio-carrier-v1/03_src/route.yaml').read_text())
assert len(f['keepouts'])==83 and len(beforef['keepouts'])==77
changed=[a['name'] for a,z in zip(beforef['keepouts'],f['keepouts']) if a!=z];assert changed==[f'PKG_PAD_ESD{i}_2_3' for i in range(1,9)]
assert f['design_rules']==beforef['design_rules'];assert f['zones']==beforef['zones'];assert r['prep']['keepouts']==beforer['prep']['keepouts']
assert r['prep']['seed_stubs']['via']==beforer['prep']['seed_stubs']['via'];checks.append('All77originalregions; only8ESD moves,6exactADC additions; unchanged fabrication/zone/prep floors')
# Existing package rule consumer must expose pads_only. No source widening occurs.
nets=yaml.safe_load((A/'03_src/rules/nets.yaml').read_text());oldnets=yaml.safe_load((R/'candidate3-work/projects/crow-audio-carrier-v1/03_src/rules/nets.yaml').read_text());assert nets==oldnets
# A polygon concavity is preserved by the fixture helper rather than replaced by its bbox.
poly=dict(points=[[0,0],[3,0],[3,1],[1,1],[1,3],[0,3]])
sh=area_shape(poly);inside=p.SHAPE_CIRCLE(p.VECTOR2I_MM(.5,2),100000);notch=p.SHAPE_CIRCLE(p.VECTOR2I_MM(2,2),100000)
assert p.SHAPE.Collide(sh,inside,0) and not p.SHAPE.Collide(sh,notch,0);checks.append('Polygon-area fixture accepts filled leg and rejects bbox-only concavity')
# Exact CH5 rectangle controls: baseline reference location collides; admitted
# reference shift clears without moving/removing any printed geometry.
data=json.loads((S/'analytical-preflight.json').read_text())[0];texts={x['text']:x for x in data['caption_and_reference_controls']};ch=texts['CH5']['bbox'];rx=texts['R_X5P']['bbox'];u=texts['U_ESD5']['bbox']
def sep(a,b):return math.hypot(max(a[0]-b[2],b[0]-a[2],0),max(a[1]-b[3],b[1]-a[3],0))
oldrx=[rx[0],rx[1]+.4,rx[2],rx[3]+.4];assert sep(ch,oldrx)<.16 and sep(ch,rx)>=.16 and sep(ch,u)>=.16
assert f['silk']['refdes']['preferred_offsets']['R_X5P']==[[-6.0,5.6]] and f['silk']['refdes']['preferred_offsets']['U_ESD5']==[[0.,-2.2]];checks.append('CH5 old-reference control fails; explicit RX5P and U_ESD5 positions clear full native boxes')
# Full64 source fanout segment census with exact unchanged electrical construction.
fan=lambda r:[st for st in r['prep']['seed_stubs']['stubs'] if st['net'].startswith('12V_POD') and st.get('pin','').startswith('F')]
assert fan(r)==fan(beforer);assert len(fan(r))==8;assert sum(len(ss['pts'])-1 for st in fan(r) for ss in st['segments'])==64
assert all(ss['width']==.60 and ss['layer']=='F.Cu' for st in fan(r) for ss in st['segments']);checks.append('8fanouts/64segments exact unchanged0.60mm')
# All nine GND launches and P endpoints/vias remain unchanged.
for project in [A,P]:
 old=yaml.safe_load((R/'candidate3-work/projects'/project.name/'03_src/route.yaml').read_text());new=yaml.safe_load((project/'03_src/route.yaml').read_text());bank={s['pin']:s for s in new['prep']['seed_stubs']['stubs']}
 for st in old['prep']['seed_stubs']['stubs']:
  if st['pin'].startswith('U_ESD') or (project==P and st['pin'].startswith('U3.')):
   if st['net']=='GND':assert st==bank[st['pin']]
   if st['net'].startswith('AUDIO_P'):
    expected=copy.deepcopy(st)
    if project==A:expected['segments'][0]['width']=.20
    assert bank[st['pin']]==expected
checks.append('9P endpoint/via constructions and9GND launches preserved')
# Pod exact additive R13 bank is the sole additional post-net bank; C10 absent.
pr=yaml.safe_load((P/'03_src/route.yaml').read_text());audio=[s for s in pr['prep']['seed_stubs']['stubs'] if s['net'].startswith('AUDIO_')];assert len(audio)==5 and {s['pin'] for s in audio}=={'J1.5','J1.4','U3.3','U3.5','R13.2'};assert all(ss['width']==.26 for s in audio for ss in s['segments']);assert not any(s['pin']=='C10.2' for s in pr['prep']['seed_stubs']['stubs']);checks.append('Podexact5AUDIO banks:4retained0.26+1R13;noC10')
# Every fitted pad source and primary input remains bound by the frozen packet.
unchanged=[]
for source in (S/'work/skills').rglob('*'):
 if source.is_file():
  old=R/'candidate3-work'/source.relative_to(S/'work');assert source.read_bytes()==old.read_bytes();unchanged.append(str(source.relative_to(S/'work')))
(S/'final-source-controls.json').write_text(json.dumps(dict(checks=checks,shared_files_unchanged=unchanged,source_regions_changed=changed,ch5_gaps=dict(old_R_X5P=sep(ch,oldrx),selected_R_X5P=sep(ch,rx),U_ESD5=sep(ch,u))),indent=2));print(checks)
