from pathlib import Path
import pcbnew as p,json
S=Path(__file__).resolve().parents[1];R=S.parents[3];bp=R/'candidate3-work/projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb';b=p.LoadBoard(str(bp))
def box(q):
 bb=q.GetBoundingBox();return [p.ToMM(bb.GetX()),p.ToMM(bb.GetY()),p.ToMM(bb.GetRight()),p.ToMM(bb.GetBottom())]
rows=[]
for fp in b.GetFootprints():
 for q in [fp.Reference(),*fp.GraphicalItems(),*fp.Pads()]:
  bb=box(q)
  if bb[0]>46 or bb[2]<34 or bb[1]>106 or bb[3]<96:continue
  if not (q.IsOnLayer(p.F_SilkS) or q.IsOnLayer(p.F_Mask)):continue
  rows.append(dict(ref=fp.GetReference(),class_=q.GetClass(),uuid=q.m_Uuid.AsString(),text=q.GetText() if hasattr(q,'GetText') else '',box=bb,fp_xy=[p.ToMM(fp.GetPosition().x),p.ToMM(fp.GetPosition().y)],visible=q.IsVisible() if hasattr(q,'IsVisible') else True))
for q in b.GetDrawings():
 if hasattr(q,'GetText') and q.GetText()=='CH5':rows.append(dict(text=q.GetText(),box=box(q)))
(S/'ch5-inventory.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
