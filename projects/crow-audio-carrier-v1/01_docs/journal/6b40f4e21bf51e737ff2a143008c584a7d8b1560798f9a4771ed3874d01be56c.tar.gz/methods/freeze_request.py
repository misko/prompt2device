from pathlib import Path
import hashlib,json,sys,os,ast,shutil,yaml,pcbnew,_pcbnew
S=Path(__file__).resolve().parents[1];R=S.parents[3];W=S/'work';sys.path.insert(0,str(W/'skills/kicad-pcb/scripts'));import model_coverage_check
files=[]
def record(p):
 data=p.read_bytes();return dict(path=str(p),size=len(data),sha256=hashlib.sha256(data).hexdigest())
# Parse every actual executable method without executing native construction.
for p in (S/'methods').glob('*.py'):ast.parse(p.read_text(),filename=str(p))
for executable in ['/usr/bin/python3','/usr/bin/kicad-cli','/usr/bin/xvfb-run']:
 assert os.access(executable,os.X_OK);files.append(record(Path(executable)))
for p in [Path(pcbnew.__file__),Path(_pcbnew.__file__)]:files.append(record(p))
model_rows=[];native_libs=set()
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 P=W/'projects'/slug;f=yaml.safe_load((P/'03_src/floorplan.yaml').read_text());assert (P/f['project']['netlist']).is_file();stem=slug.replace('-','_');bp=P/'04_kicad'/f'{stem}.kicad_pcb';assert bp.is_file();assert bp.with_suffix('.kicad_sch').is_file()
 rows=model_coverage_check.inspect(bp);assert all(row['resolved'] for row in rows);model_rows.append(dict(slug=slug,models=len(rows),all_resolved=True))
 for row in rows:
  for m in row['models']:
   if m['resolved']:native_libs.add(Path(m['resolved']))
 b=pcbnew.LoadBoard(str(bp))
 for fp in b.GetFootprints():
  lib,name=str(fp.GetFPID().GetUniStringLibId()).split(':',1)
  local=P/'03_src/lib'/f'{lib}.pretty'/f'{name}.kicad_mod';system=Path('/usr/share/kicad/footprints')/f'{lib}.pretty'/f'{name}.kicad_mod';path=local if local.is_file() else system;assert path.is_file(),str(path);native_libs.add(path)
for p in sorted(native_libs):files.append(record(p))
# Full supplied worktree is the concrete native execution input, including
# pinned schematic/netlist/model/library/config bytes and unchanged shared gates.
for p in sorted(W.rglob('*')):
 if p.is_file():files.append(record(p))
for p in sorted((S/'methods').glob('*.py')):
 if p.name!='freeze_request.py':files.append(record(p))
# Hash-bound live shared runtime package that runs the driver and its stages.
for p in sorted(Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts').glob('pipeline_*.py')):files.append(record(p))
files={row['path']:row for row in files};manifest=dict(scope='Full candidate4 input files, methods, native library/models, executables and shared runtime; generated outputs are mutable only inside scratch',files=[files[k] for k in sorted(files)])
(S/'candidate-input-manifest.json').write_text(json.dumps(manifest,indent=2))
recovery=json.loads((R/'root/rj45-top-only-correction1-recovery.json').read_text());changed={v['path'] for v in recovery['source_changes']}
for p in sorted((W/'projects').rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(W);q=R/'candidate3-work'/rel
 if q.is_file() and p.read_bytes()!=q.read_bytes() and ('/03_src/' in str(rel) or '/01_docs/' in str(rel) or '/02_parts/' in str(rel)):changed.add(str(rel))
changes=[]
for name in sorted(changed):
 p=W/name;slug=Path(name).parts[1];rel=Path(*Path(name).parts[2:]);before=R/'live-preimages'/slug/rel
 if not before.exists():before=R/'input'/name
 changes.append(dict(path=name,before=record(before) if before.exists() else None,after=record(p)))
(S/'source-pre-post-manifest.json').write_text(json.dumps(changes,indent=2));(S/'setup-preflight.json').write_text(json.dumps(dict(executables=True,method_syntax=True,models=model_rows,native_library_model_files=len(native_libs),candidate_input_files=len(files),source_changed_files=len(changes),shared_runtime_bound=True),indent=2))
request=dict(candidate_id='top-only-native4',max_new_native_candidates=1,max_routing_pilots=0,argv=['/usr/bin/python3','-B',str(S/'methods/native_driver.py'),'--root-admitted-candidate4'],cwd=str(S),timeout_s=1100,source_manifest=record(S/'candidate-input-manifest.json'),source_changes_manifest=record(S/'source-pre-post-manifest.json'),driver=record(S/'methods/native_driver.py'),source_preflight_paths=[str(S/n) for n in ['analytical-preflight.json','final-source-controls.json','source-policy-checks.json','setup-preflight.json']],status='SOURCE_PREFLIGHT_COMPLETE_AWAITING_ROOT_GUARDED_EXECUTION',root_only=True)
(S/'native-request.json').write_text(json.dumps(request,indent=2));print('Frozen',len(files),'candidate input files and',len(changes),'source changes; models',model_rows);print(S/'native-request.json')
