from pathlib import Path
import pcbnew as p,yaml,json,math,hashlib
S=Path(__file__).resolve().parents[1];R=S.parents[3]
def xy(q):return [p.ToMM(q.x),p.ToMM(q.y)]
def vec(q):return p.VECTOR2I_MM(*[round(v,3) for v in q])
def box(q):
 bb=q.GetBoundingBox();return [p.ToMM(bb.GetLeft()),p.ToMM(bb.GetTop()),p.ToMM(bb.GetRight()),p.ToMM(bb.GetBottom())]
def sep(a,b):return math.hypot(max(a[0]-b[2],b[0]-a[2],0),max(a[1]-b[3],b[1]-a[3],0))
def gap(a,b):
 if a.Collide(b,0):return 0.
 lo=0;hi=p.FromMM(500)
 while hi-lo>1:
  m=(lo+hi)//2
  if a.Collide(b,m):hi=m
  else:lo=m
 return p.ToMM(hi)
def region_shape(k):
 if 'rect' in k:
  x,y,xx,yy=k['rect'];return p.SHAPE_RECT(vec([x,y]),p.FromMM(xx-x),p.FromMM(yy-y))
 poly=p.SHAPE_POLY_SET();chain=p.SHAPE_LINE_CHAIN()
 for x,y in k['points']:chain.Append(p.VECTOR2I(round(x*1e6),round(y*1e6)))
 chain.SetClosed(True);poly.AddOutline(chain);return poly
results=[]
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 carrier='carrier' in slug;P=S/'work/projects'/slug;bp=R/'candidate3-work/projects'/slug/'04_kicad'/f'{slug.replace("-","_")}.kicad_pcb';before=hashlib.sha256(bp.read_bytes()).hexdigest();b=p.LoadBoard(str(bp));fps={f.GetReference():f for f in b.GetFootprints()};rt=yaml.safe_load((P/'03_src/route.yaml').read_text());fl=yaml.safe_load((P/'03_src/floorplan.yaml').read_text());shapes=[];targets=[]
 for st in rt['prep']['seed_stubs']['stubs']:
  pin=st.get('pin');net=st['net'];target=net.startswith('AUDIO_') or (carrier and (pin.startswith('F') and net.startswith('12V_POD') or pin=='C_VDDA1_10N.2'))
  for ss in st.get('segments',[]):
   for a,z in zip(ss['pts'],ss['pts'][1:]):shapes.append(dict(net=net,pin=pin,kind='track',a=a,z=z,width=ss['width'],layers=[ss['layer']],target=target,shape=p.SHAPE_SEGMENT(vec(a),vec(z),p.FromMM(ss['width']))))
  for q in st.get('vias',[]):
   vd=st.get('via',rt['prep']['seed_stubs']['via']);shapes.append(dict(net=net,pin=pin,kind='via',a=q,z=q,width=vd['size'],drill=vd['drill'],layers=['F.Cu','B.Cu']+(['In1.Cu','In2.Cu'] if carrier else []),target=target,shape=p.SHAPE_CIRCLE(vec(q),p.FromMM(vd['size']/2))))
 targets=[s for s in shapes if s['target']];near=[];bad=[];contacts=[];pairs=0
 for t in targets:
  required=.25 if t['pin']=='C_VDDA1_10N.2' else rt['prep']['seed_stubs']['clearance']
  for ref,fp in fps.items():
   for pad in fp.Pads():
    layers=[l for l in t['layers'] if pad.IsOnLayer(b.GetLayerID(l))]
    if not layers:continue
    if t['kind']=='via' and pad.GetAttribute()==p.PAD_ATTRIB_SMD and t['shape'].Collide(pad.GetEffectiveShape(b.GetLayerID(layers[0])),0):contacts.append(dict(pin=t['pin'],pad=ref+'.'+pad.GetNumber(),net=pad.GetNetname()))
    if pad.GetNetname()==t['net']:continue
    pairs+=1;shape=pad.GetEffectiveShape(b.GetLayerID(layers[0]))
    if not t['shape'].Collide(shape,p.FromMM(1.5)):continue
    d=gap(t['shape'],shape);row=dict(owner=t['pin'],kind=t['kind'],foreign=ref+'.'+pad.GetNumber(),foreign_net=pad.GetNetname(),gap_mm=d,required=required)
    near.append(row)
    if d<required-2e-6:bad.append(row)
  for o in shapes:
   if o['net']==t['net'] or not set(o['layers'])&set(t['layers']):continue
   pairs+=1
   if not t['shape'].Collide(o['shape'],p.FromMM(1.5)):continue
   d=gap(t['shape'],o['shape']);row=dict(owner=t['pin'],kind=t['kind'],foreign_seed=o['pin'],foreign_kind=o['kind'],foreign_net=o['net'],gap_mm=d,required=required);near.append(row)
   if d<required-2e-6:bad.append(row)
 regions=fl.get('keepouts',[])+[dict(name=f'PREP_RECT{i}',layers=['F.Cu','In1.Cu','In2.Cu','B.Cu'],rect=[k['x0'],k['y0'],k['x1'],k['y1']],deny=['tracks','vias','pours']) for i,k in enumerate(rt['prep']['keepouts'].get('rects',[]))]
 hits=[]
 for t in targets:
  for k in regions:
   denied='vias' if t['kind']=='via' else 'tracks'
   if denied in k['deny'] and set(k['layers'])&set(t['layers']) and t['shape'].Collide(region_shape(k),0):hits.append(dict(pin=t['pin'],kind=t['kind'],region=k['name']))
 npths=[dict(ref=ref,pad=x.GetNumber(),uuid=x.m_Uuid.AsString(),xy=xy(x.GetPosition()),drill=xy(x.GetDrillSize())) for ref,fp in fps.items() for x in fp.Pads() if x.GetAttribute()==p.PAD_ATTRIB_NPTH]
 # Every source region against the actual complete moved-footprint population.
 base=p.LoadBoard(str(R/'input/projects'/slug/'04_kicad'/bp.name));bf={q.GetReference():q for q in base.GetFootprints()};moved=[]
 for ref,fp in fps.items():
  old=bf[ref]
  if xy(fp.GetPosition())+[fp.GetOrientationDegrees(),fp.GetLayerName()]!=xy(old.GetPosition())+[old.GetOrientationDegrees(),old.GetLayerName()]:moved.append(ref)
 census=[]
 for k in fl.get('keepouts',[]):
  poly=region_shape(k);bb=poly.BBox();rb=xy(bb.GetPosition())+xy(bb.GetEnd());census.append(dict(name=k['name'],layers=k['layers'],deny=k['deny'],bounds=rb,hits=[dict(ref=ref,state=state) for ref in moved for state,fp in [('old',bf[ref]),('new',fps[ref])] if sep(rb,box(fp))==0]))
 texts=[];movetext={};objects=list(b.GetDrawings())
 for fp in fps.values():objects += [fp.Reference(),*fp.GraphicalItems(),*fp.Pads()]
 if carrier:
  for q in b.GetDrawings():
   if not hasattr(q,'GetText'):continue
   text=q.GetText()
   if text.startswith('CH') and text[2:].isdigit():movetext[q.m_Uuid.AsString()]=[xy(q.GetPosition())[0],38.5 if int(text[2:])<5 else 101.5]
   elif text.startswith('F') and text.endswith(' PTC'):movetext[q.m_Uuid.AsString()]=[xy(q.GetPosition())[0],28.6 if int(text.split()[0][1:])<5 else 111.4]
  movetext[fps['R_X5P'].Reference().m_Uuid.AsString()]=[41.1,99.25]
  movetext[fps['U_ESD5'].Reference().m_Uuid.AsString()]=[40.5,103.05]
 def transformed(q):
  bb=box(q);uid=q.m_Uuid.AsString()
  if uid in movetext:
   old=xy(q.GetPosition());new=movetext[uid];bb=[bb[0]+new[0]-old[0],bb[1]+new[1]-old[1],bb[2]+new[0]-old[0],bb[3]+new[1]-old[1]]
  return bb
 for q in objects:
  if q.m_Uuid.AsString() not in movetext:continue
  bb=transformed(q);neartext=[]
  for o in objects:
   if o.m_Uuid.AsString()==q.m_Uuid.AsString():continue
   silk=o.IsOnLayer(p.F_SilkS) and (not hasattr(o,'IsVisible') or o.IsVisible());mask=o.GetClass()=='PAD' and o.IsOnLayer(p.F_Mask)
   if not(silk or mask):continue
   d=sep(bb,transformed(o))
   if d<.5:neartext.append(dict(uuid=o.m_Uuid.AsString(),description=o.GetText() if hasattr(o,'GetText') else o.GetParentFootprint().GetReference()+'.'+o.GetNumber() if mask else o.GetClass(),gap=d))
  texts.append(dict(text=q.GetText(),xy=movetext[q.m_Uuid.AsString()],bbox=bb,near=neartext,conflicts=[n for n in neartext if n['gap']<.16-1e-9]))
 result=dict(slug=slug,read_only_board_sha256=before,source_primitives=len(shapes),target_primitives=len(targets),pair_comparisons=pairs,near=near,bad_pairs=bad,via_smd_contacts=contacts,forbidden_region_hits=hits,npths=npths,moved_refs=moved,all_source_regions=census,caption_and_reference_controls=texts)
 assert before==hashlib.sha256(bp.read_bytes()).hexdigest();results.append(result)
 print(slug,'pairs',pairs,'bad',len(bad),'via pad contacts',len(contacts),'forbidden',hits,'npth',len(npths),'regions',len(census),'text conflicts',[(t['text'],t['conflicts']) for t in texts if t['conflicts']],flush=True)
(S/'analytical-preflight.json').write_text(json.dumps(results,indent=2));assert not any(r['bad_pairs'] or r['via_smd_contacts'] or r['forbidden_region_hits'] or any(t['conflicts'] for t in r['caption_and_reference_controls']) for r in results)
