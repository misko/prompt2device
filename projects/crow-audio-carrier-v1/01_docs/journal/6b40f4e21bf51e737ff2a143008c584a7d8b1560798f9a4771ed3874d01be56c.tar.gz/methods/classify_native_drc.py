from pathlib import Path
import json,sys,pcbnew as p,hashlib,collections
S=Path(__file__).resolve().parents[1];summary={}
def xy(v):return [p.ToMM(v.x),p.ToMM(v.y)]
for kind,slug in [('carrier','crow-audio-carrier-v1'),('pod','crow-mic-pod-v3')]:
 P=S/'work/projects'/slug;bp=P/'04_kicad'/f'{slug.replace("-","_")}.kicad_pcb';b=p.LoadBoard(str(bp));d=json.loads((S/f'{kind}-drc.json').read_text());objects=[*b.GetTracks(),*b.GetDrawings(),*b.Zones()]
 for f in b.GetFootprints():objects += [f,f.Reference(),f.Value(),*f.Pads(),*f.GraphicalItems()]
 index={o.m_Uuid.AsString():o for o in objects};rows=[]
 for section in ['violations','unconnected_items','schematic_parity']:
  for n,row in enumerate(d[section]):
   witnesses=[];nets=set();pins=set()
   for item in row.get('items',[]):
    q=index.get(item['uuid']);w=dict(item,native_uuid_found=q is not None)
    if q:
     w.update(native_class=q.GetClass(),native_position=xy(q.GetPosition()),native_layer=q.GetLayerName())
     if hasattr(q,'GetNetname'):w['native_net']=q.GetNetname();nets.add(q.GetNetname())
     if isinstance(q,p.PAD):w['native_ref']=q.GetParentFootprint().GetReference();w['native_pad']=q.GetNumber();pins.add(w['native_ref']+'.'+w['native_pad'])
     if isinstance(q,p.ZONE) and not q.GetIsRuleArea():w['islands_by_layer']={b.GetLayerName(l):q.GetFilledPolysList(l).OutlineCount() for l in q.GetLayerSet().CuStack()}
    witnesses.append(w)
   endpoints=' -> '.join(x.get('description','') for x in row.get('items',[]));typ=row['type']
   if section=='unconnected_items':
    category='DOWNSTREAM_ROUTING_OWED';cause='This exact disconnected component pair has no completed route in the source-owned prepared candidate. Complete and regrade the named route: '+endpoints
    if 'GND' in nets:
     category='GROUND_RETURN_ROUTING_OWED';cause='This ground row requires full-island topology attribution; a zone UUID can identify several disconnected polygons. '
     if kind=='pod':cause+='The independent full-fill graph locates the residual R7.2/C9.2 island; C10.2 is on the broad component. Preserve the final route/stitch obligation, not an invented C10 repair. '+endpoints
     elif pins & {'U_PWR.2','R_PWR_BOT.2','U_AUDIO.2'}:cause+='The named U_PWR/R_PWR_BOT or U_AUDIO return is an existing owning routing obligation. '+endpoints
     else:category='CURRENT_GROUND_CLOSURE_REQUIRES_REVIEW';cause+='Compare this exact row with carrier-return-graph.json; unexpected VMID/quiet/supply closure failures are current source defects. '+endpoints
    if any(x.startswith('12V_POD') for x in nets):
     category='POWER_BRANCH_REMAINDER_OWED';cause='Source F1..F8 fanout only covers fuse-output to jack1/3/7; check source-native-binding and native connectivity to distinguish missing required fanout from upstream or remaining branch routing. '+endpoints
   elif typ in ['track_dangling','via_dangling']:
    category='DOWNSTREAM_SEED_TERMINUS_OWED';cause='The exact named prepared-seed endpoint awaits its declared downstream routing owner: '+endpoints
   elif section=='schematic_parity':category='CURRENT_SCHEMATIC_PARITY_DEFECT';cause='Current board and pinned schematic differ at these exact identities: '+endpoints
   else:category='CURRENT_NATIVE_GEOMETRY_OR_POLICY_DEFECT';cause='Current candidate violates '+typ+' at these exact native objects; this is not deferred routing closure: '+endpoints
   rows.append(dict(id=f'{kind}-{section}-{n+1}',section=section,type=typ,severity=row.get('severity'),description=row.get('description'),items=witnesses,classification=category,cause=cause))
 out=dict(board_sha256=hashlib.sha256(bp.read_bytes()).hexdigest(),drc_sha256=hashlib.sha256((S/f'{kind}-drc.json').read_bytes()).hexdigest(),counts={sec:len(d[sec]) for sec in ['violations','unconnected_items','schematic_parity']},rows=rows,classification_counts=dict(collections.Counter(x['classification'] for x in rows)),all_uuid_endpoints_found=all(i['native_uuid_found'] for row in rows for i in row['items']))
 (S/f'{kind}-drc-classification.json').write_text(json.dumps(out,indent=2));summary[kind]=dict(counts=out['counts'],classifications=out['classification_counts'],all_uuids=out['all_uuid_endpoints_found']);print(kind,summary[kind])
(S/'drc-classification-summary.json').write_text(json.dumps(summary,indent=2))
