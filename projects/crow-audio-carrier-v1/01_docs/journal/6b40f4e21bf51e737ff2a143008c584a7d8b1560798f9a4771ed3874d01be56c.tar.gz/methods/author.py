from pathlib import Path
import yaml,json,copy,shutil
S=Path(__file__).resolve().parents[1];R=S.parents[3];W=S/'work';A=W/'projects/crow-audio-carrier-v1';P=W/'projects/crow-mic-pod-v3'
overlay=json.loads((R/'adc-source-fragment/adc-return-overlay.json').read_text())
for path in (R/'adc-source-fragment/source').rglob('*'):
 if path.is_file():shutil.copy2(path,W/path.relative_to(R/'adc-source-fragment/source'))
for project in (A,P):
 carrier=project==A;fpath=project/'03_src/floorplan.yaml';rp=project/'03_src/route.yaml';f=yaml.safe_load(fpath.read_text());r=yaml.safe_load(rp.read_text())
 stubs=r['prep']['seed_stubs']['stubs'];changed=0
 for st in stubs:
  pin=st.get('pin','');net=st.get('net','')
  if net.startswith('AUDIO_') and (pin.startswith('J') or pin.startswith('U_ESD') or pin.startswith('U3.')):
   if carrier:
    for seg in st['segments']:assert seg['width']==.26;seg['width']=.20;changed+=1
   if net.startswith('AUDIO_N') and not pin.startswith('J'):
    seg=st['segments'][0];x,y=seg['pts'][0];sign=1 if not carrier or int(pin[5:pin.index('.')])<5 else -1
    seg['pts'][-1]=[x,round(y+sign,4)];st['vias']=[seg['pts'][-1].copy()]
 if carrier:
  assert changed==32
  assert len(f['keepouts'])==77
  for region in f['keepouts']:
   if region['name'].startswith('PKG_PAD_ESD'):
    i=int(region['name'][11:region['name'].index('_2_3')]);x=40.865+32*(i-1) if i<5 else 39.440+32*(i-5);y=34.070 if i<5 else 105.070
    region['layers']=['F.Cu'];region['rect']=[round(x,3),y,round(x+.695,3),round(y+.860,3)]
  f['keepouts'].extend(copy.deepcopy(overlay['floorplan_add_keepouts']))
  for replacement in overlay['floorplan_replace_patterns']:
   bank=f['placement']['patterns'];assert bank.count(replacement['before'])==1;bank[bank.index(replacement['before'])]=replacement['after']
  for replacement in overlay['route_replace_stubs']:
   assert stubs.count(replacement['before'])==1;stubs[stubs.index(replacement['before'])]=replacement['after']
  assert not any(x.get('pin')==overlay['route_add_stub']['pin'] for x in stubs);stubs.append(overlay['route_add_stub'])
  f['placement']['anchors']['R_PWR_PU'][1]=53.94
  for caption in f['silk']['captions']:
   if isinstance(caption,dict) and caption['text'].startswith('CH') and caption['text'][2:].isdigit():caption['at'][1]=38.5 if int(caption['text'][2:])<5 else 101.5
  for i,bank in enumerate(f['placement']['repeat']):
   for cap in bank.get('captions',[]):
    if cap['text']=='F{i} PTC':cap['at'][1]=-18.4 if i==0 else 18.4
  f['silk']['refdes']['preferred_offsets'].update(R_X5P=[[-6.0,5.6]],U_ESD5=[[0.0,-2.2]])
 r['flow']['blockers'][0]='PROPOSED coherent candidate4: reviewed top-only carrier154x100/x21 mounts, exact carrier0.20/pod0.26 signals, rearward N launches and ordinary45-degree prefixes; complete source dependency correction with ADC returns. Fresh exact-source/native acceptance and normal owning gates remain owed; historical top-only candidates1..3 and ADC candidates1..2 remain spent.'
 fpath.write_text(yaml.safe_dump(f,sort_keys=False,width=120));rp.write_text(yaml.safe_dump(r,sort_keys=False,width=120))
# Exact production source guards; preserve all existing guards.
p=A/'03_src/check_analog_paths.py';t=p.read_text().replace("x['width'] != .26","x['width'] != .20").replace('admitted0.26mm','admitted0.20mm').replace('[[1.7875,9.39],[2.35,9.39]]','[[1.7875,9.39],[1.7875,10.39]]');p.write_text(t)
p=A/'03_src/tests/test_ground_connections.py';t=p.read_text().replace('Eighteen current','Thirty-two current').replace('all eighteen top lands','all thirty-two top lands').replace('test_exact_eighteen_source_owned_ground_pads','test_exact_thirty_two_source_owned_ground_pads').replace('len(selected),18','len(selected),32');pos=t.index('\ndef frozen');t=t[:pos]+"\n# Exactly fourteen additions admitted with the ADC reservations/drop decision.\nADDITIONAL_TARGETS={'C_ADC_CM4P.2','C_ADC_CM4N.2','U_LDO_EN.3','C_VDDA1_10N.2',\n                    'C_VMID1_470N.2','C_VMID2_470N.2'} | {f'C_ISO{i}.2' for i in range(1,9)}\nTARGETS |= ADDITIONAL_TARGETS\n"+t[pos:];p.write_text(t)
p=A/'03_src/tests/test_rj45_entry_paths.py';t=p.read_text();pos=t.index('    def test_grounded_shell');t=t[:pos]+'''    def test_exact_admitted_signal_width_layer_and_negative_via(self):
        for defect in ('old-width','below-floor','wrong-layer','old-n-via','missing-n-via','extra-bank'):
            r=copy.deepcopy(self.route)
            e=next(x for x in r['prep']['seed_stubs']['stubs'] if x.get('pin')=='J1.5')
            n=next(x for x in r['prep']['seed_stubs']['stubs'] if x.get('pin')=='U_ESD1.5')
            if defect=='old-width':e['segments'][0]['width']=.26
            if defect=='below-floor':e['segments'][0]['width']=.19
            if defect=='wrong-layer':e['segments'][0]['layer']='B.Cu'
            if defect=='old-n-via':n['vias']=[[40.35,35.25]];n['segments'][0]['pts'][-1]=[40.35,35.25]
            if defect=='missing-n-via':n['vias']=[]
            if defect=='extra-bank':r['prep']['seed_stubs']['stubs'].append(copy.deepcopy(n))
            with self.assertRaises(checker.PathError,msg=defect):checker.validate_entry_paths(self.config,r,self.pins)
''' +t[pos:];p.write_text(t)
for project in (A,P):
 p=project/'02_parts/TPD2E2U06DRLR/part.yaml';t=p.read_text().replace('rounded connector prefixes','ordinary 45-degree connector prefixes').replace('PROPOSED ADR0030:', 'PROPOSED ADR0030 candidate4:' if project==A else 'PROPOSED ADR0009 candidate4:');p.write_text(t)
p=A/'01_docs/ARCHITECTURE.md';t=p.read_text().replace('The 150 × 100 mm first-article board','The proposed 154 × 100 mm first-article board');t+='\nADR0030 proposes outline x16..170/y20..120 mm with west mounting centers x21 mm (east x165, y25/115). The J9 physical mouth at x19.08 is set back3.08 mm from the new west edge. Direction-only edge_faces does not establish mouth exposure, mate/latch/tool clearance, pigtail/restraint routing or enclosure fit; these existing service holds require renewed exact scenes. All fitted SMD, including manual/consigned, is on F.Cu. This source batch remains proposed pending exact-source/native review.\n';p.write_text(t)
print('Source overlay and bounded protection dependencies composed; pod residual decision still pending.')
