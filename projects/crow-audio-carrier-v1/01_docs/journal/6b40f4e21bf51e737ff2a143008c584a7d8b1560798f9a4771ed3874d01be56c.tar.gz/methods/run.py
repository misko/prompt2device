from pathlib import Path
import sys,os,json
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_runtime import run_stage
S=Path(__file__).resolve().parents[1]
name=sys.argv[1];cwd=sys.argv[2];timeout=float(sys.argv[3]);argv=sys.argv[4:]
env={k:os.environ[k] for k in ['PATH','HOME','LANG','DISPLAY'] if k in os.environ};env.update(PYTHONDONTWRITEBYTECODE='1',KICAD10_FOOTPRINT_DIR='/usr/share/kicad/footprints')
root=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');env['GIT_DIR']=(root/'.git').read_text().strip().split(': ',1)[1]
r=run_stage({'id':name,'work_class':'local','timeout_s':timeout},argv,log_path=S/'logs'/f'{name}.log',cwd=cwd,env=env,heartbeat_s=10,console_line_limit=25)
(S/'logs'/f'{name}.runtime.json').write_text(json.dumps(r.to_mapping(),indent=2));sys.exit(r.returncode if r.returncode is not None else 2)
