from pathlib import Path
import sys,copy,json,pcbnew as p,yaml
S=Path(__file__).resolve().parents[1];A=S/'work/projects/crow-audio-carrier-v1';R=S.parents[3];sys.path.insert(0,str(A/'03_src/tests'));from test_digital_launch_source import pair_clearance,rect_shape
from test_rj45_entry_paths import EntryTests
x=EntryTests();x.setUp();bad=copy.deepcopy(x.route);bad['prep']['seed_stubs']['stubs'].append(dict(net='AUDIO_P9',pin='J9.5',segments=[]))
import check_analog_paths as checker
try:checker.validate_entry_paths(x.config,bad,x.pins);raise AssertionError('unknown bank accepted')
except checker.PathError:pass
# Demonstrate the same exact changed construction without the added complete
# bank guard accepts the hostile extra net, then the actual source rejects it.
t=(A/'03_src/check_analog_paths.py').read_text();start=t.index('    admitted_nets=');end=t.index('    short =',start);ns=dict(__file__=str(A/'03_src/check_analog_paths.py'),__name__='source_guard_red_control');exec(compile(t[:start]+t[end:],str(A/'03_src/check_analog_paths.py'),'exec'),ns);ns['validate_entry_paths'](x.config,bad,x.pins)
f=yaml.safe_load((A/'03_src/floorplan.yaml').read_text());nets=yaml.safe_load((A/'03_src/rules/nets.yaml').read_text());area=next(a for a in f['keepouts'] if a['name']=='PKG_PAD_ESD1_2_3');rule=next(r for r in nets['scoped_clearances'] if r['zone']==area['name']);xx,yy,xxx,yyy=area['rect'];center=p.VECTOR2I_MM((xx+xxx)/2,(yy+yyy)/2);primitives={'track':p.SHAPE_SEGMENT(center,center,100000),'via':p.SHAPE_CIRCLE(center,50000),'pour':rect_shape(area['rect'])};rows=[]
# Standalone fixture comparator grades non-pad source items; explicit pad-only
# exclusion must block this exact same-net-pair attempt for every item type.
for kind,sh in primitives.items():
 a=dict(id='hostile-'+kind,net=rule['nets_a'][0],shape=sh);b=dict(id='NC2',net=rule['nets_b'][0],shape=sh)
 # Use a degenerate segment for Collide dispatch where needed; all primitives
 # occupy the same actual scoped native region, no candidate is modified.
 if kind=='via':a['shape']=p.SHAPE_SEGMENT(center,center,100000);b['shape']=a['shape']
 actual=pair_clearance(a,b,f,nets);widened=copy.deepcopy(nets);next(r for r in widened['scoped_clearances'] if r['zone']==area['name'])['pads_only']=False;hostile=pair_clearance(a,b,f,widened);assert actual==.25 and hostile==.15;rows.append(dict(kind=kind,ordinary_fixture_clearance=actual,wrong_pad_exception_clearance=hostile))
bp=R/'candidate3-work/projects/crow-mic-pod-v3/04_kicad/crow_mic_pod_v3.kicad_pcb';board=p.LoadBoard(str(bp));pad=next(q for f in board.GetFootprints() if f.GetReference()=='R13' for q in f.Pads() if q.GetNumber()=='2');good=p.SHAPE_CIRCLE(p.VECTOR2I_MM(62.913,34.7),300000);old=p.SHAPE_CIRCLE(p.VECTOR2I_MM(62.4,35.6),300000);assert not p.SHAPE.Collide(good,pad.GetEffectiveShape(p.F_Cu),0) and p.SHAPE.Collide(old,pad.GetEffectiveShape(p.F_Cu),0)
out=dict(unknown_audio_bank_actual_rejected=True,without_complete_bank_guard_hostile_accepted=True,pads_only_nonpad_controls=rows,R13_known_bad_collision=True,R13_fixed_offpad=True,scope='Read-only source/analytical controls, no new native candidate');(S/'additional-source-controls.json').write_text(json.dumps(out,indent=2));print(out)
