"""One root-admitted candidate4 only. Never run during source preflight."""
from pathlib import Path
import os,sys,json,hashlib,shutil,datetime
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_runtime import run_stage
S=Path(__file__).resolve().parents[1];R=S.parents[3];W=S/'work';T=W/'skills/kicad-pcb/scripts';F=W/'skills/jlcpcb-fab/scripts'
assert sys.argv[1:]==['--root-admitted-candidate4']
manifest=json.loads((S/'candidate-input-manifest.json').read_text())
for row in manifest['files']:
 p=Path(row['path']);data=p.read_bytes();assert len(data)==row['size'] and hashlib.sha256(data).hexdigest()==row['sha256'],str(p)
# Exclusive marker prevents accidental rerun even after a failed stage.
with (S/'native-candidate4-started.json').open('x') as q:json.dump(dict(start=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_manifest_sha256=hashlib.sha256((S/'candidate-input-manifest.json').read_bytes()).hexdigest()),q)
env={k:os.environ[k] for k in ['PATH','HOME','LANG','DISPLAY'] if k in os.environ};env.update(PYTHONDONTWRITEBYTECODE='1',KICAD10_FOOTPRINT_DIR='/usr/share/kicad/footprints',KICAD10_3DMODEL_DIR='/usr/share/kicad/3dmodels',CIRCUITS_ROOT=str(W));root=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');env['GIT_DIR']=(root/'.git').read_text().strip().split(': ',1)[1]
results=[]
def stage(name,argv,cwd,timeout=120):
 r=run_stage({'id':name,'work_class':'local','timeout_s':timeout},argv,log_path=S/'logs'/f'{name}.log',cwd=cwd,env=env,console_line_limit=25,heartbeat_s=10);receipt=r.to_mapping();(S/'logs'/f'{name}.runtime.json').write_text(json.dumps(receipt,indent=2));results.append(dict(name=name,argv=argv,cwd=str(cwd),returncode=r.returncode,runtime=receipt));(S/'native-stage-results.json').write_text(json.dumps(results,indent=2));return r.returncode
py=lambda path,*args:['/usr/bin/python3','-B',str(path),*map(str,args)]
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 P=W/'projects'/slug;kind='carrier' if 'carrier' in slug else 'pod';stem=slug.replace('-','_');bp=P/'04_kicad'/f'{stem}.kicad_pcb';base=R/'input/projects'/slug/'04_kicad'/bp.name;old=S/'native-preimages'/slug;old.mkdir(parents=True,exist_ok=True)
 # Historical candidates cannot masquerade as the new generated/prepared output.
 if bp.exists():shutil.move(bp,old/bp.name)
 r0=P/'06_build/route/r0.kicad_pcb'
 if r0.exists():shutil.move(r0,old/'historical-r0.kicad_pcb')
 generated=stage(kind+'-generate',py(T/'generate_board_generic.py','03_src/floorplan.yaml'),P)==0
 if bp.exists():
  stage(kind+'-rules-before',py(T/'generate_rules_generic.py','.'),P)
  placement=S/'native-placement'/slug;placement.mkdir(parents=True,exist_ok=True)
  for q in (P/'04_kicad').iterdir():
   if q.is_file():shutil.copy2(q,placement/q.name)
  prepared=stage(kind+'-prep',py(T/'route_and_stitch_generic.py','prep','03_src/route.yaml'),P)==0
  if r0.exists():shutil.copy2(r0,bp)
  stage(kind+'-fill',py(S/'methods/fill.py',bp),P)
  # LAST writer of native rules; no geometry modification follows this stage.
  stage(kind+'-rules-last',py(T/'generate_rules_generic.py','.'),P)
  checks=[
   ('saved-fill',py(T/'route_and_stitch_generic.py','verify-fill','03_src/route.yaml')),
   ('drc',['kicad-cli','pcb','drc','--severity-all','--refill-zones','--schematic-parity','--exit-code-violations','--format','json','-o',str(S/f'{kind}-drc.json'),str(bp)]),
   ('critical-path',py(T/'critical_path_check.py',bp,'--config','03_src/rules/critical_paths.yaml','--json',S/f'{kind}-critical-path.json')),
   ('pad-separation',py(T/'pad_separation.py',bp,'--project','.')),
   ('placement',py(T/'placement_gates.py',bp,'--courtyard','--json',S/f'{kind}-placement.json')),
   ('model-coverage',py(T/'model_coverage_check.py',bp,'-o',S/f'{kind}-model-coverage.json')),
   ('via-in-pad',py(T/'via_in_pad_guard.py',base,bp,'--json',S/f'{kind}-via-in-pad.json')),
   ('net-parity',py(T/'board_netlist_parity.py',bp,base)),
   ('assembly-side',py(F/'assembly_coverage.py','.', '--board',bp,'--json',S/f'{kind}-assembly-coverage.json')),
   ('policy-placement',py(T/'policy_audit.py','.', '--board',stem,'--skip-drc','--phase','placement','--output',S/f'{kind}-policy-placement.txt')),
   ('rules-full',py(T/'rules_audit.py','.', '--board',bp)),
   ('tier',py(T/'tier_preflight.py','.', '--board',bp)),
   ('source-native-binding',py(S/'methods/native_source_binding.py',P)),
   ('full-native-measurements',py(S/'methods/native_measure.py',slug)),
   ('return-graph',py(S/'methods/native_returns.py',bp)),
   ('spoke-native',py(P/'03_src/check_spoke_implementation.py')),
  ]
  for name,argv in checks:stage(kind+'-'+name,argv,P)
  if kind=='carrier':
   stage('carrier-analog-path-native',py(P/'03_src/check_analog_paths.py','--board',bp,'--output',S/'carrier-analog-copper.json'),P)
   for ref in ['D_HOLD','D_BUCK_IN','D_IN','U_DUMP','U_LDO_EN','U_OE','U_TDM_SCH','Q_PRE','Q_PRE_EN','Q_RST1']:
    stage('carrier-terminal-'+ref,py(P/'03_src/tests/check_native_terminal_envelope.py',ref,'--board',bp),P)
   stage('carrier-final-native-source-tests',['/usr/bin/python3','-B','-m','unittest','-v','test_check_spoke_implementation','test_rj45_entry_paths','test_ground_connections','test_package_clearances','test_adc_channel_map','test_adc_feed_invariants','test_thermal_source'],P/'03_src/tests',180)
  else:
   stage('pod-realized-paths',py(P/'03_src/check_realized_routes.py',bp),P)
   stage('pod-final-native-source-tests',['/usr/bin/python3','-B','-m','unittest','-v','test_check_realized_routes','test_check_spoke_implementation'],P/'03_src/tests')
  # The view helper performs only rendering and preserves per-side run receipts.
  stage(kind+'-renders',py(S/'methods/render_native.py',slug),P,240)
 else:results.append(dict(name=kind+'-dependent-native-checks',returncode=None,status='INCOMPLETE',reason='Generator produced no new board; all historical native copies retained separately'))
# Every raw DRC row, including all open rows, receives UUID-resolved attribution.
if all((S/f'{kind}-drc.json').is_file() for kind in ['carrier','pod']):stage('classify-all-native-drc',py(S/'methods/classify_native_drc.py'),S)
(S/'native-stage-results.json').write_text(json.dumps(results,indent=2));print('Candidate4 execution complete; failed stages retained:',[(r['name'],r.get('returncode')) for r in results if r.get('returncode')!=0],flush=True)
sys.exit(0 if all(r.get('returncode')==0 for r in results) else 1)
