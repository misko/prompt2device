from pathlib import Path
import sys,os,json
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_runtime import run_stage
S=Path(__file__).resolve().parents[1];T=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/kicad-pcb/scripts');slug=sys.argv[1];kind='carrier' if 'carrier' in slug else 'pod';P=S/'work/projects'/slug;bp=P/'04_kicad'/f'{slug.replace("-","_")}.kicad_pcb';env={k:os.environ[k] for k in ['PATH','HOME','LANG'] if k in os.environ};env['PYTHONDONTWRITEBYTECODE']='1';(S/'views').mkdir(exist_ok=True)
for side in ['top','bottom']:
 name=kind+'-render-native-'+side;argv=['/usr/bin/python3','-B',str(T/'render_board.py'),str(bp),str(S/'views'/f'{kind}-{side}.png'),'--side',side,'--width','1400','--height','900','--quality','basic']
 r=run_stage({'id':name,'work_class':'local','timeout_s':120},argv,log_path=S/'logs'/f'{name}.log',cwd=P,env=env,console_line_limit=25);(S/'logs'/f'{name}.runtime.json').write_text(json.dumps(r.to_mapping(),indent=2))
