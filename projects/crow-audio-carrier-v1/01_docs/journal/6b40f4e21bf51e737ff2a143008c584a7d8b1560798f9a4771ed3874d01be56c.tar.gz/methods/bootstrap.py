from pathlib import Path
import hashlib,json,shutil
S=Path(__file__).resolve().parents[1];R=S.parents[3]
e=json.loads((S.parent/'envelope.json').read_text())
rows=[]
for v in e['input_packet']:
 p=R/v['path']; data=p.read_bytes(); h=hashlib.sha256(data).hexdigest(); assert h==v['sha256'] and len(data)==v['size'],str(p)
 rows.append(dict(path=v['path'],size=len(data),sha256=h))
(S/'inputs-before.json').write_text(json.dumps(rows,indent=2))
shutil.copytree(R/'candidate3-work',S/'work')
print('Verified',len(rows),'frozen inputs; copied candidate3 working tree')
