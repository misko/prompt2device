from pathlib import Path
import sys,json,yaml,pcbnew as p,math,hashlib
S=Path(__file__).resolve().parents[1];P=Path(sys.argv[1]);bp=P/'04_kicad'/f'{P.name.replace("-","_")}.kicad_pcb';b=p.LoadBoard(str(bp));r=yaml.safe_load((P/'03_src/route.yaml').read_text());f=yaml.safe_load((P/'03_src/floorplan.yaml').read_text());tracks=list(b.GetTracks());rows=[]
def xy(v):return [p.ToMM(v.x),p.ToMM(v.y)]
def rounded(q):return xy(p.VECTOR2I_MM(*[round(x,3) for x in q]))
for st in r['prep']['seed_stubs']['stubs']:
 for ss in st.get('segments',[]):
  for aa,zz in zip(ss['pts'],ss['pts'][1:]):
   a,z=rounded(aa),rounded(zz);matches=[t.m_Uuid.AsString() for t in tracks if t.GetClass()=='PCB_TRACK' and t.GetLayerName()==ss['layer'] and t.GetNetname()==st['net'] and abs(p.ToMM(t.GetWidth())-ss['width'])<1e-6 and ((math.dist(xy(t.GetStart()),a)<2e-6 and math.dist(xy(t.GetEnd()),z)<2e-6) or (math.dist(xy(t.GetStart()),z)<2e-6 and math.dist(xy(t.GetEnd()),a)<2e-6))];rows.append(dict(pin=st['pin'],net=st['net'],kind='track',layer=ss['layer'],width=ss['width'],start=a,end=z,native_uuids=matches))
 for site in st.get('vias',[]):
  vd=st.get('via',r['prep']['seed_stubs']['via']);a=rounded(site);matches=[t.m_Uuid.AsString() for t in tracks if t.GetClass()=='PCB_VIA' and t.GetNetname()==st['net'] and math.dist(xy(t.GetPosition()),a)<2e-6 and abs(p.ToMM(t.GetWidth(p.F_Cu))-vd['size'])<1e-6 and abs(p.ToMM(t.GetDrillValue())-vd['drill'])<1e-6];rows.append(dict(pin=st['pin'],net=st['net'],kind='via',site=a,geometry=vd,native_uuids=matches))
regions=[];zones={z.GetZoneName():z for z in b.Zones() if z.GetIsRuleArea()}
for k in f.get('keepouts',[]):
 z=zones.get(k['name']);regions.append(dict(name=k['name'],present=z is not None,layers=[b.GetLayerName(l) for l in z.GetLayerSet().CuStack()] if z else None,expected_layers=k['layers'],deny=k['deny'],uuid=z.m_Uuid.AsString() if z else None))
refs=[]
for fp in b.GetFootprints():
 bare=fp.GetReference().startswith(('TP','FID')) or fp.GetReference()=='MK1';smd=bool(fp.GetAttributes()&p.FP_SMD) or any(q.GetAttribute()==p.PAD_ATTRIB_SMD and q.GetNumber() for q in fp.Pads());refs.append(dict(ref=fp.GetReference(),uuid=fp.m_Uuid.AsString(),fitted_smd=bool(smd and not bare),layer=fp.GetLayerName(),xy=xy(fp.GetPosition()),visible_reference=fp.Reference().IsVisible()))
missing=[r for r in rows if not r['native_uuids']];badregions=[r for r in regions if not r['present'] or set(r['layers'])!=set(r['expected_layers'])];bottom=[r for r in refs if r['fitted_smd'] and r['layer']!='F.Cu'];invisible=[r for r in refs if not r['visible_reference'] and not r['ref'].startswith(('H','FID'))]
result=dict(board_sha256=hashlib.sha256(bp.read_bytes()).hexdigest(),declared_seed_primitives=len(rows),matched_seed_primitives=len(rows)-len(missing),missing=missing,all_seed_rows=rows,source_regions=regions,badregions=badregions,all_references=refs,bottom_smd=bottom,invisible_references=invisible,checks=dict(all_declared_seeds=not missing,source_regions=not badregions,top_only=not bottom,visible_refs=not invisible))
(S/('carrier-source-native-binding.json' if 'carrier' in P.name else 'pod-source-native-binding.json')).write_text(json.dumps(result,indent=2));print(result['checks'],'seeds',len(rows),'missing',len(missing),'regions',len(regions),'invisible',invisible);sys.exit(0 if all(result['checks'].values()) else 1)
