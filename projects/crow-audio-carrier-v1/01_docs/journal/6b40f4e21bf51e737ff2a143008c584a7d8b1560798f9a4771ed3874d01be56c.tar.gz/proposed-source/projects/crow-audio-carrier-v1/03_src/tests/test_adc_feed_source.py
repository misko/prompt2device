"""Live ADC-feed source regression; isolated footprints, never a BOARD.

Native contact and full-shape clearance prove only the local authored source.
They cannot prove global routability, filled return, thermal/fault withstand,
assembly, safe power-up, or release readiness. Known-bad mutations reconstruct
the rejected cap-gap rule, old ground drop, disconnected feed and runaway leaf.
"""
import copy
import math
import subprocess
import unittest
from pathlib import Path

import pcbnew
import yaml
from test_adc_source import load_source, native_geometry, inspect, extent_errors
from test_digital_launch_source import segment_rows
from test_regulator_source import connected_reach, contained, via_rows
from test_power_landing_source import copper_groups

PROJECT=Path(__file__).resolve().parents[2]
REPO=PROJECT.parents[1]
REOPENED={f'U_ADC.{n}' for n in [2,3,5,8,9,10,11]}


def frozen(name, revision='549a4e793ba7f42cd971e25d96cdbbdd36f708ea'):
    return yaml.safe_load(subprocess.check_output(['git','show',
        revision+':projects/crow-audio-carrier-v1/03_src/'+name],cwd=REPO,timeout=15))


def native_gap_mm(a,b):
    """Independent native-shape clearance bisection, one-nanometre interval."""
    lo,hi=0,1000000
    while hi-lo>1:
        mid=(lo+hi)//2
        if pcbnew.SHAPE.Collide(a,b,mid):hi=mid
        else:lo=mid
    return lo/1e6


def has_connected_full_entry(route,geometry,pin):
    groups=copper_groups('3V3_ADC',geometry,route)
    own=[g for g in groups if any(p['kind']=='pad' and p['id']==pin for p in g)]
    return len(own)==1 and any(p['kind']=='seed' and p['width']>=1.2 for p in own[0])


class AdcFeedSourceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.floor,cls.route,cls.nets,*_=load_source()
        cls.geometry=native_geometry(cls.floor)
        cls.rows=segment_rows(cls.route)
        cls.banks={b['pin']:b for b in cls.route['prep']['seed_stubs']['stubs']}

    def test_seven_adc_banks_and_physical_authority_survive_regulator_change(self):
        accepted=frozen('route.yaml','1b725986')['prep']['seed_stubs']['stubs']
        expected={b['pin']:b for b in accepted if b['pin'] in REOPENED}
        self.assertEqual(len(expected),7)
        self.assertEqual({p:self.banks[p] for p in REOPENED},expected)
        before=frozen('floorplan.yaml','1b725986')
        refs={'U_ADC','C_VDDA1_10N','C_VDDA2_10N','C_VMID1_470N',
              'C_VMID1_4U7','C_VMID2_470N','C_VMID2_4U7'}
        for ref in refs:
            self.assertEqual(self.floor['placement']['anchors'][ref],
                             before['placement']['anchors'][ref],ref)
        # ADR0030 changes only these explicit mechanical fields; retain all other board settings.
        before['board']['outline']['x0']=16.0
        before['board']['mounting_holes']['at']=[[21.,25.],[165.,25.],[21.,115.],[165.,115.]]
        before['board']['fiducials']['at']=[[25.,33.],[161.,29.],[29.,111.]]
        for key in ['board','design_rules','zones']:
            self.assertEqual(self.floor[key],before[key])
        old_nets=frozen('rules/nets.yaml','1b725986')
        select=lambda ns:[r for r in ns['scoped_clearances'] if r['zone'].startswith('ADC_FEED_CAP_GAP_')]
        self.assertEqual(len(select(self.nets)),2)
        self.assertEqual(select(self.nets),select(old_nets))
        self.assertEqual((len(self.banks),len(self.rows),len(via_rows(self.route))),(154, 391, 43))

    def test_full_feeds_are_connected_to_real_adc_and_bypass_pads(self):
        for n,cap in [(5,'C_VDDA1_10N.1'),(9,'C_VDDA2_10N.1')]:
            pin=f'U_ADC.{n}';bank=self.banks[pin]
            self.assertFalse(bank.get('vias'))
            self.assertTrue(has_connected_full_entry(self.route,self.geometry,pin))
            self.assertEqual([s['width'] for s in bank['segments']],[.18,.18,1.2])
            self.assertIn(cap,connected_reach(self.route,self.geometry,pin))
        bad=copy.deepcopy(self.route)
        next(b for b in bad['prep']['seed_stubs']['stubs'] if b['pin']=='U_ADC.5')['segments'].pop(1)
        self.assertFalse(has_connected_full_entry(bad,self.geometry,'U_ADC.5'))
        self.assertTrue(has_connected_full_entry(bad,self.geometry,'U_ADC.9'))

    def test_native_pad_gaps_and_trace_clearance_are_measured_not_assumed(self):
        pads={p['id']:p for p in self.geometry['pads']}
        checks=0
        for side,pin in [(1,'U_ADC.5'),(2,'U_ADC.9')]:
            for value in ['470N','4U7']:
                pair=[pads[f'C_VMID{side}_{value}.{n}'] for n in [1,2]]
                self.assertAlmostEqual(native_gap_mm(pair[0]['shape'],pair[1]['shape']),.65,places=6)
                y=pair[0]['at'][1]
                crossing=[r for r in self.rows if r['id']==pin and r['a'][0]==r['b'][0]
                          and min(r['a'][1],r['b'][1])<y<max(r['a'][1],r['b'][1])]
                self.assertEqual(len(crossing),1)
                for pad in pair:
                    self.assertAlmostEqual(native_gap_mm(crossing[0]['shape'],pad['shape']),.235,places=6);checks+=1
        self.assertEqual(checks,8)

    def test_explicit_local_clearance_is_necessary_and_not_global(self):
        rules=[r for r in self.nets['scoped_clearances'] if r['zone'].startswith('ADC_FEED_CAP_GAP_')]
        self.assertEqual(len(rules),2)
        areas={a['name']:a for a in self.floor['keepouts']}
        for rule in rules:
            self.assertEqual(rule['nets'],['3V3_ADC']);self.assertEqual(rule['clearance'],'0.23mm')
            self.assertEqual(areas[rule['zone']]['layers'],['F.Cu']);self.assertEqual(areas[rule['zone']]['deny'],[])
        bad=copy.deepcopy(self.nets)
        for r in bad['scoped_clearances']:
            if r['zone'].startswith('ADC_FEED_CAP_GAP_'):r['clearance']='0.24mm'
        failures=inspect(self.floor,self.route,bad,self.geometry)['failures']
        self.assertEqual(len([r for r in failures if r['kind']=='segment-pad' and r['other'].startswith('C_VMID')]),8)

    def test_whole_feed_capsules_and_exact_additive_length(self):
        areas={a['name']:a for a in self.floor['keepouts']}
        lengths=[]
        for n,suffix in [(5,'NORTH'),(9,'SOUTH')]:
            pin=f'U_ADC.{n}';spec=self.banks[pin]['segments'][1]
            rows=[r for r in self.rows if r['id']==pin and r['a'] in spec['pts'][:-1] and r['b'] in spec['pts'][1:]]
            self.assertEqual(len(rows),6)
            self.assertTrue(all(contained(r,areas['ADC_FEED_'+suffix]) for r in rows))
            length=sum(math.dist(r['a'],r['b']) for r in rows)
            self.assertAlmostEqual(length,6.938221893892777,places=8);lengths.append(length)
        self.assertAlmostEqual(sum(lengths),13.876443787785554,places=8)
        bad=copy.deepcopy(self.route)
        next(b for b in bad['prep']['seed_stubs']['stubs'] if b['pin']=='U_ADC.5')['segments'][1]['pts'][-1]=[91.3,55.]
        self.assertIn('U_ADC.5',extent_errors(self.floor,bad,self.nets))

    def test_ground_return_reaches_its_own_drop_and_rejects_old_site(self):
        reached=set(connected_reach(self.route,self.geometry,'U_ADC.8'))
        self.assertTrue({'C_VMID2_470N.2','C_VMID2_4U7.2','U_ADC.8:via0'}<=reached)
        self.assertFalse({'U_ADC.6','U_ADC.49'}&reached)
        own=next(v for v in via_rows(self.route) if v['pin']=='U_ADC.8')
        for pad in self.geometry['pads']:
            self.assertFalse(own['hole'].Collide(pad['shape'],255000-2),pad['id'])
        self.assertEqual(self.banks['U_ADC.8']['vias'],[[89.8,71.5]])
        self.assertEqual(self.banks['U_ADC.8']['via'],dict(size=.5,drill=.2))
        bad=copy.deepcopy(self.route)
        next(b for b in bad['prep']['seed_stubs']['stubs'] if b['pin']=='U_ADC.8')['vias']=[[90.55,71.0]]
        failures=inspect(self.floor,bad,self.nets,self.geometry)['failures']
        self.assertTrue(any(r['kind']=='via-hole/physical-layer-pad' and r['item']=='U_ADC.8:via0' for r in failures))

    def test_shared_rail_nonwest_power_copper_has_exact_current_subtotal(self):
        rows=[r for r in self.rows if r['net']=='3V3_ADC' and r['width']<1.2 and r['id'] not in {'U_ADC.5','U_ADC.9'}]
        self.assertEqual(len(rows),28)
        self.assertAlmostEqual(sum(math.dist(r['a'],r['b']) for r in rows),36.720035810134515,places=8)


if __name__=='__main__':unittest.main()
