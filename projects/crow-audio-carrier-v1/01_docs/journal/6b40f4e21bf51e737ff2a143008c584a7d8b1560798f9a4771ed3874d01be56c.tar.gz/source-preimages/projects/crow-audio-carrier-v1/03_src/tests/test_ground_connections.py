"""Eighteen current source-owned solid GND pads, not thermal qualification.

The positive test is run RED on 84db6eb2's unchanged source before repair.
The saved native-fill/DRC experiment separately grades realized copper;
these tests deliberately do not certify connectivity from a source setting.
"""
import copy
from pathlib import Path
import subprocess
import unittest

import pcbnew
import yaml

from test_digital_launch_source import native_geometry
from test_route_source_contract import load_source

SRC=Path(__file__).resolve().parents[1]
ROOT=SRC.parents[2]
BASE='84db6eb2'
# ADR0027 exchanged CM logical references over fixed physical lands. The
# complete physical pad-setting preservation is checked by test_adc_channel_map.
TARGETS={'C_ADC_CM2N.2','C_ADC_CM2P.2','C_ADC_CM6N.2','C_ADC_CM6P.2',
         'R_AUDIO_PD.2','C_VMID1_EXT_1U.2','R_ADC_PD1P.2','U_OE.3',
         'U_TDM_SCH.3','U_LDO.15'}
BOTTOM_TARGETS={f'U_ESD{i}.4' for i in range(1,9)}
TARGETS |= BOTTOM_TARGETS

def frozen(name):
    path=(SRC/name).relative_to(ROOT)
    return yaml.safe_load(subprocess.check_output(['git','show',f'{BASE}:{path}'],
        cwd=ROOT,text=True,timeout=15))

def inspect(floor,pins):
    errors=[];selected=[]
    for row in floor['placement']['patterns']:
        if 'pad_overrides' not in row:continue
        if set(row)!={'match','pad_overrides'}:errors.append('extra-pattern-field')
        refs=row['match']
        if not isinstance(refs,list) or any(not isinstance(r,str) or any(c in r for c in '*?[]') for r in refs):
            errors.append('nonexact-ref-selector');continue
        for ov in row['pad_overrides']:
            if set(ov)!={'pads','on_net','zone_connection'}:errors.append('extra-override-field')
            if ov.get('zone_connection')!='full':errors.append('not-solid')
            if ov.get('on_net')!='GND':errors.append('not-ground-guarded')
            pads=ov.get('pads',[])
            if not isinstance(pads,list) or not pads:errors.append('empty-pad-selector');continue
            for ref in refs:
                for number in pads:
                    pin=ref+'.'+str(number);selected.append(pin)
                    if pins.get((ref,str(number)))!='GND':errors.append('wrong-native-net:'+pin)
    if set(selected)!=TARGETS:errors.append('target-coverage')
    if len(selected)!=len(set(selected)):errors.append('duplicate-target')
    return errors,selected

class GroundConnectionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.floor,cls.route,*_=load_source()
        cls.geometry=native_geometry(cls.floor)
        cls.pins=cls.geometry['pins']

    def test_exact_eighteen_source_owned_ground_pads(self):
        errors,selected=inspect(self.floor,self.pins)
        self.assertEqual(errors,[])
        self.assertEqual(len(selected),18)

    def test_real_old_source_is_rejected(self):
        self.assertIn('target-coverage',inspect(frozen('floorplan.yaml'),self.pins)[0])

    def test_wrong_net_broad_ref_and_extra_pad_are_rejected(self):
        good={'match':['U_OE'],'pad_overrides':[{'pads':['3'],'on_net':'GND','zone_connection':'full'}]}
        for mutate,expected in [
            (lambda r:None,'duplicate-target'),
            (lambda r:r['pad_overrides'][0].update(on_net='3V3_ADC'),'not-ground-guarded'),
            (lambda r:r.update(match=['U_*']),'nonexact-ref-selector'),
            (lambda r:r['pad_overrides'][0].update(pads=['2','3']),'wrong-native-net:U_OE.2'),
            (lambda r:r['pad_overrides'][0].update(clearance=0),'extra-override-field')]:
            bad=copy.deepcopy(self.floor);row=copy.deepcopy(good);mutate(row)
            bad['placement']['patterns'].append(row)
            self.assertIn(expected,inspect(bad,self.pins)[0])

    def test_no_required_solid_connection_can_be_omitted(self):
        for target in TARGETS:
            bad=copy.deepcopy(self.floor)
            for row in bad['placement']['patterns']:
                if 'pad_overrides' not in row:continue
                ref=target.rsplit('.',1)[0]
                if ref in row['match']:row['match'].remove(ref)
            self.assertIn('target-coverage',inspect(bad,self.pins)[0],target)

    def test_lt_quiet_returns_remain_isolated_from_direct_ep_bonds(self):
        from test_regulator_source import QUIET_PINS, quiet_errors, connected_reach
        self.assertEqual(quiet_errors(self.floor,self.route,self.geometry),[])
        for pin in QUIET_PINS:
            self.assertNotIn('U_LDO.15',connected_reach(self.route,self.geometry,pin))
            self.assertIn('C_LDO_OUT.2',connected_reach(self.route,self.geometry,pin))
        for pin in ('U_LDO.7','U_LDO.10','U_LDO.11'):
            self.assertIn('U_LDO.15',connected_reach(self.route,self.geometry,pin))

    def test_targets_are_real_smd_ground_lands_on_declared_sides(self):
        # Narrow side-aware witness: the shared signal-path native_geometry
        # helper is top-only and cannot establish underside clamp placement.
        from test_local_placement_source import source_builder
        from source_inventory import parse_netlist
        project=SRC.parent
        comps,pins,_=parse_netlist(project/self.floor['project']['netlist'])
        source=source_builder(self.floor)
        board=pcbnew.BOARD()
        board.SetCopperLayerCount(4)
        for ref in sorted({pin.split('.')[0] for pin in TARGETS}):
            lib,name=comps[ref][0].split(':')
            directory=(project/'03_src/lib/crow_audio_carrier.pretty' if lib=='crow_audio_carrier'
                       else Path('/usr/share/kicad/footprints')/(lib+'.pretty'))
            fp=pcbnew.FootprintLoad(str(directory),name)
            self.assertIsNotNone(fp,ref)
            board.Add(fp)  # Keep the parent alive before and throughout Flip.
            x,y,rot,_=source.initial_pose(ref)
            fp.SetOrientationDegrees(rot)
            fp.SetPosition(pcbnew.VECTOR2I(round(x*1e6),round(y*1e6)))
            if source.place_cfg.get('sides',{}).get(ref,'top')=='bottom':
                fp.Flip(fp.GetPosition(),False)
            for pin in sorted(p for p in TARGETS if p.split('.')[0]==ref):
                number=pin.split('.')[1]
                pads=[p for p in fp.Pads() if p.GetNumber()==number]
                self.assertEqual(len(pads),1,pin)
                self.assertEqual(pads[0].GetAttribute(),pcbnew.PAD_ATTRIB_SMD,pin)
                expected=pcbnew.B_Cu if pin in BOTTOM_TARGETS else pcbnew.F_Cu
                self.assertTrue(pads[0].IsOnLayer(expected),pin)
                self.assertFalse(pads[0].IsOnLayer(pcbnew.F_Cu if pin in BOTTOM_TARGETS else pcbnew.B_Cu),pin)
                self.assertEqual(pins[(ref,number)],'GND',pin)

if __name__=='__main__':unittest.main(verbosity=2)
