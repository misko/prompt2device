# ADR-0001 — one-CS5308P TDM8 topology for eight synchronous channels

Status: accepted for first article
Date: 2026-09-01

Use one CS5308P-DN in hardware secondary ASP, minimum-slot TDM mode. The external MCHStreamer is the only clock master. Multiple stereo ADCs were rejected because they add independent clock/configuration state, inter-device phase uncertainty, and extra serial aggregation without improving the eight-channel requirement. A generic ADC module was rejected because no reviewed module exposes eight active-balanced analog inputs, the mandated spoke pinout, and the MCHStreamer TDM8 electrical boundary.

Consequences: the CS5308P QFN, reference network, buffered VMID, reset sequence, and external input stages are all critical. The bare-IC exception is deliberate and must remain machine-visible in `integration.yaml`.

2026-09-07 source correction: DS1314F1 Table1-2 p6 requires unused SPI_CS
pin38 high at VDD_IO. It now ties3V3_ADC. The other unused control pins
35/36/37 remain GND. The exact source and generated-pin invariant must
retain this distinction; a blanket all-unused-control-pins-to-GND rule is wrong.
