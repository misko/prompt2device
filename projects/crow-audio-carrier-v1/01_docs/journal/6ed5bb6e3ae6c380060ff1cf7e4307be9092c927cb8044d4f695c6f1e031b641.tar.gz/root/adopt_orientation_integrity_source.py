"""Adopt only the exact independently accepted combined source after closure."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import tarfile

N = Path(__file__).parent
R = Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
sha = lambda data: hashlib.sha256(data).hexdigest()
metas = {}
for name in ['rj45-orientation-integrity-source', 'rj45-orientation-integrity-review']:
    m = json.loads((N / (name + '-opened.json')).read_text())
    E = Path(m['envelope'])
    D = Path(m['project'])
    env = json.loads(E.read_text())
    assert json.loads((E.parent / 'attempt.json').read_text())['status'] == 'PASS'
    for row in env['input_packet']:
        p = D / row['path']
        b = p.read_bytes()
        assert not p.is_symlink() and len(b) == row['size'] and sha(b) == row['sha256']
    c = json.loads((N / (name + '-closeout-summary.json')).read_text())
    assert c['delivery_status'] == 'PASS' and sha(Path(c['archive']).read_bytes()) == c['sha256']
    metas[name] = (m, c, env)

am, ac, ae = metas['rj45-orientation-integrity-source']
rm, rc, re = metas['rj45-orientation-integrity-review']
review = json.loads((Path(rm['output_dir']) / 'evidence.json').read_text())
assert review['subject'] == re['subject']
assert isinstance(review['domain_result'], str)
assert review['domain_result'].split(':', 1)[0].strip() == 'SOUND', 'Independent SOUND acceptance is required'
author_archive = Path(am['output_dir']) / 'evidence.tar.gz'
assert sha(author_archive.read_bytes()) == sha((Path(rm['project']) / 'author/evidence.tar.gz').read_bytes())
expected = json.loads((N / 'orientation-integrity-candidate-files.json').read_text())
assert len(expected) == 7 and len({row['path'] for row in expected}) == 7
plans = []
with tarfile.open(author_archive) as t:
    for row in expected:
        rel = row['path']
        assert not Path(rel).is_absolute() and '..' not in Path(rel).parts
        before = t.extractfile('beforeimages/' + rel).read()
        after = t.extractfile('source_candidate/' + rel).read()
        assert sha(before) == row['before_sha256'] and sha(after) == row['after_sha256']
        assert (R / rel).read_bytes() == before
        plans.append((rel, before, after))
record = {
    'created_at': datetime.now(timezone.utc).isoformat(),
    'author_archive': ac['sha256'], 'review_archive': rc['sha256'],
    'review_subject': re['subject'], 'files': expected,
    'claim': 'Exact independently SOUND combined seven-file source adopted. Two original camera/scene candidates remain spent; one focused integrity correction completed. Normal shared-input renewal and fresh user orientation approval remain owed; no routing, release or physical acceptance.',
}
for rel, before, after in plans:
    assert (R / rel).read_bytes() == before
for rel, before, after in plans:
    (R / rel).write_bytes(after)
for rel, before, after in plans:
    assert (R / rel).read_bytes() == after
(N / 'orientation-integrity-source-adoption.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
