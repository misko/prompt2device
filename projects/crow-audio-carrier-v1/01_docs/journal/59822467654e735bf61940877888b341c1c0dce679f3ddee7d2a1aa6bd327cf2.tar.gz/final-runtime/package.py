import sys,json,hashlib,tarfile
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
S=Path(__file__).parent;R=S.parents[3];O=S.parent/'outputs';e=json.loads((S.parent/'envelope.json').read_text());checks=[]
for row in e['input_packet']:
 b=(R/row['path']).read_bytes();checks.append({'path':row['path'],'size':len(b),'sha256':hashlib.sha256(b).hexdigest(),'pass':len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256']})
assert all(x['pass'] for x in checks);(S/'inputs-after.json').write_text(json.dumps(checks,indent=2))
files=[p for p in sorted(S.rglob('*')) if p.is_file() and p.name not in ['packaging.log','packaging.runtime.json']]
assert not any(p.is_symlink() for p in files)
archive=O/'evidence.tar.gz';members=[]
with tarfile.open(archive,'w:gz') as tf:
 for p in files:
  b=p.read_bytes();name=p.relative_to(S).as_posix();assert not name.endswith(('.tar','.tar.gz','.tgz','.zip'));tf.add(p,arcname=name,recursive=False);members.append({'path':name,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
with tarfile.open(archive,'r:gz') as tf:
 seen=set()
 for member in tf.getmembers():
  name=member.name;assert member.isfile() and name not in seen and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts;seen.add(name)
  b=tf.extractfile(member).read();expected=next(x for x in members if x['path']==name);assert len(b)==expected['size'] and hashlib.sha256(b).hexdigest()==expected['sha256']
assert len(seen)==len(members)
manifest={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_size':archive.stat().st_size,'member_count':len(members),'members':members,'reopened_regular_members':len(seen)}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps({k:v for k,v in manifest.items() if k!='members'}))
