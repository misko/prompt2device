review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_headers_mountedframe1 (same actual reviewer, requested-context continuation)
context: CONTINUATION
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
qualification_status: FIRST-ARTICLE-ONLY
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

Scope: J10, J11 and J9 intrinsic physical pin identities and declared board-level interface allocations only. SOUND does not accept the assembled cables, harness, installed fit, whole-board placement, routing, manufacturing release, or an order. All existing first-article interface holds remain.

Provenance and context

The original completed review remains INCOMPLETE, with original verdicts J10 QUESTION, J11 QUESTION, J9 QUESTION. It has not been edited or retrospectively relabeled. Its exact report is supplied as previous-completed-report.md, SHA-256 2f17b2c60f8e078bb83fc6125cd480796186fa8d36a2194d8362ad2b9d4e3f2c. Supplied previous-closeout.json identifies immutable journal archive ae31466f4a547acf3c2e4c2baf0ea5f1c4ee87e84ff14f7ff0a3c3fa002d6d53; that live archive was not opened in this continuation. The original TMM rotation proof and electrical identity counts are retained by this provenance rather than rerunning the previously successful physical review.

This is explicitly CONTINUATION despite the generic envelope context_mode field saying FRESH. New architecture text is authored design context, not independent manufacturer evidence. New primary MCHStreamer and TCSD figures were independently inspected. J9-all-native-pads.json is supplied native extraction, checked against the exact original board hash; it is not treated as a manufacturer expectation. All 14 envelope inputs verified before and after work. Only supplied frozen inputs and the permitted execution framework were read.

Primary sources and actual figure inspections

- Original Samtec TMM-Series_RevAS.pdf: 66d9ffaa15ef8ff9b1614640d81fd2d1c2c6629b522df0cddc64acac3e73efc3, page 1 FIG.1. Retained original top-view proof: double-row 12 contacts match each TMM dossier by clockwise 90-degree rotation. Zigzag numbering is not perimeter winding; no mirror was permitted. Original images remain in the closed original evidence archive.
- Original Molex SD-43650-001 D8 PDF: b8942b95bc3fe4c02171de9e714d99b2688055e249ba1524e3c2a8c3cf78eaa3, page 1 PCB LAYOUT: COMPONENT SIDE and PCB LAYOUT: 2 CKT. Retained manufacturer-derived expectation is used for the newly supplied asymmetric point.
- MCHStreamer_User_Manual.pdf: 2cf36d628df68607d007b971a13a3a578916d74629d6660571daf218cfbc6edd. Newly rendered/inspected page 10 Figure 1 (explicit top of board) and Table 1, page 24 Figure 12/Table 12 (TDM firmware), page 8 section 2.4 and power-header figure.
- TCSD-Series_RevBE.pdf: fa4643ec2ea321bf7bc186d20bf8c1b31a7fb0b3d335662c2ba8eba9007b108b. Newly rendered/inspected all four sheets; sheets 1-2 establish first-position indicators, ordinary double-end arrangement, reverse-wiring and reverse-connector distinctions. Sheets 3-4 contain assembly/strain-relief details, not additional proof of an installed cable.
- Newly authored architecture: 79bab8c4b8c4b74d9fc6e909b2891b0501a6b90eca1f89a54cc5e10eeb939978, ADC and clocks section and J9 custom power-entry description.
- New native J9 extraction: 63d9eca7268e8bd300fbe8072db87c8b6802861eaa85b6cceec295c650a7ea48.

J10 VERDICT: PASS (original QUESTION resolved at declared board-interface level)

Counts: 12 numbered native dossier rows, 12 unique physical electrical identities, 12 distinct locations; no exposed pad, physical identity collapse, or fused alias. The original package proof is retained unchanged.

MCHStreamer Figure 1 explicitly shows top-of-board J1 with pin 1 lower left, pin 2 above, odd numbers along the lower row and even numbers above. This independently agrees with the original Samtec TMM figure. A clockwise 90-degree rotation maps those physical identities to J10's component-top sequence: 1=(0,0), 2=(2,0), 3=(0,2), through 11=(0,10), 12=(2,10). This is a comparison between board-top header identities, not an assertion that looking into a female cable socket uses the same unreflected visual frame.

Pin | Expected from MCH TDM8 Table 12 and declared capture-only use | Native J10 net
---|---|---
1 | MCH data OUT Ch1-8, intentionally unused by carrier | unconnected-(J10-NC1-Pad1)
2 | MCH data IN Ch1-8, carrier ADC stream | ADC_TDM
3-8 | TDM8 unused | six individual unconnected J10 pad nets
9 | MCH MCLK output | MCH_MCLK
10 | MCH BCLK output | MCH_BCLK
11 | Ground | GND
12 | MCH FSYNC output | MCH_FSYNC

All 12 identities/allocations agree. Page 24's TDM8 column, rather than page 10's sample I2S pin descriptions, establishes the data and FSYNC use. An unused module output at pin 1 is properly left disconnected. The declaration that MCH is clock master agrees with the primary output directions. This does not validate loaded firmware, edge timing or actual USB channel behavior.

J11 VERDICT: PASS (original QUESTION resolved at declared board-interface level)

Counts: 12 numbered native dossier rows, 12 unique physical identities, 12 distinct locations; no EP, fused alias or collapsed identity. Original TMM package proof retained. MCH Figure 1 J3 top-of-board drawing places pin 1 upper left, pin 2 upper right and odd/even pairs progressing downward, directly matching J11 component-top identities.

J11 pin 1: expected official J3 ground from Table 1; observed GND. PASS.
J11 pin 2: expected official J3 3.3 V output from Table 1 and section 2.4; observed MCH_3V3_SENSE. Authored architecture declares approximately 0.320 mA sensing, not carrier-rail power; this is the correct kind of connection to that output. The primary permits external loading up to 200 mA. No independent check of the downstream sense circuitry is claimed here. PASS.
J11 pins 3-12: expected unused in this declared two-wire sensing connection; observed ten individual unconnected pad nets. In particular TDM Table 12 identifies J3 pin 11 as inverted BCLK output, which may remain unused. PASS.

The original J10/J11 asymmetries at pins 1,2,9,10,11,12 resolve: they serve different official module ports, J1 and J3. Identical passive terminal-strip part numbers do not require identical signal roles across different ports. Primary tables independently confirm those declared differences.

J9 VERDICT: PASS (original orientation QUESTION resolved; custom allocation distinguished from physical harness proof)

Counts: 2 numbered native electrical identities plus 1 separate unnumbered mechanical point, total 3 native pad objects. All three positions are now available. The added point has component-top (1.50,-4.32), size 3.00x3.00, tht=true, no net; native board coordinate (23.68,67.50). The extraction does not encode drill diameter or plating, so its 3.00 mm size is not falsely reported as a measured drill.

The original manufacturer component-side derivation, referenced to circuit 1, is circuit 1=(0,0), circuit 2=(-3,0), locating peg=(-1.50,+4.32). A permitted 180-degree rotation predicts (0,0), (+3,0), (+1.50,-4.32). All three measured native component-top points match. The previously indistinguishable x-mirror would put the peg at (+1.50,+4.32), which the new extraction disproves. The signed two-vector determinant remains -12.96 mm² under the actual match and would reverse sign under the mirror. This resolves rotation-versus-mirror and numbered contact identity, without assigning a winding to two collinear electrical pins.

All three points also obey the front-mounted 90-degree native transform (X,Y)=(28+localY,69-localX). The mechanical point establishes the housing side relative to the contact row; no additional mounting reflection is introduced.

J9 pin 1: expected a passive circuit 1 contact; the custom board allocation names it +12V_IN. Observed 12V_IN. PASS.
J9 pin 2: expected a passive circuit 2 contact; the custom board allocation names it GND. Observed GND. PASS.

The Molex manufacturer drawing defines contact identity, not the voltage of a custom harness. Requiring it to declare this project's 12 V allocation was not an intrinsic pin-review requirement. Authored architecture establishes the selected power-entry role and custom pigtail construction, while the native dossier states the actual contact allocation. Board-level polarity is therefore unambiguous: deliver positive to physical circuit 1 and return to circuit 2. This is a harness requirement, not a claim that the supplied packet independently demonstrates an assembled red/black pigtail's continuity or insertion.

Retained physical interface holds, not waived

The declared J10-to-MCH-J1 and J11-to-MCH-J3 connections require like-numbered contact continuity, with each end correctly oriented to its own physical pin 1. TCSD RevBE sheet 1 ties the colored conductor to the first-position indicator in the standard arrangement and shows a distinct -RW reverse-wiring option; sheet 2 distinguishes reversed connector/notch configurations. These are evidence that cable orientation must be specified and checked, not evidence that every TCSD variant or an unobserved cable is interchangeable. This packet does not establish the exact installed cable option, female-face orientation, or measured continuity. No such orientation has been invented; connector marking alignment, pin-to-pin continuity, engagement depth, retention, split-cable behavior and fit remain physical interface holds. The board's intended numbered assignments themselves are established above.

J9 assembled harness polarity/continuity, cavity insertion, restraint and first-article mechanical fit remain holds. Drill diameter/plating is absent from the new extraction and is not qualified by this pin-mapping result. No current, thermal, protection, signal-integrity or power-sequencing qualification is conferred.

Final scoped pin verdict: SOUND. Current J10 PASS, J11 PASS, J9 PASS. Original per-ref QUESTION verdicts and INCOMPLETE closeout remain historical immutable results. There are no remaining intrinsic numbered-contact or declared board-net allocation questions in this commissioned group. FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains in force.
