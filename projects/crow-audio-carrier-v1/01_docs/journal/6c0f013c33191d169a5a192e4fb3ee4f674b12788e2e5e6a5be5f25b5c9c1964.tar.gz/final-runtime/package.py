from pathlib import Path,PurePosixPath
import sys,json,hashlib,tarfile
sys.path.insert(0,"/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts")
from pipeline_execution import TaskEnvelope,verify_input_packet,envelope_sha256
S=Path(__file__).parent;R=S.parents[3];O=S.parent/'outputs'
e=TaskEnvelope.from_json((S.parent/'envelope.json').read_text());assert envelope_sha256(e)=='29f991d4e68c68be0225393c80e89eba60c3f5a1c89dc0842f3d52406d644aa2'
v=verify_input_packet(e,R);assert v[0],v
(S/'inputs-after.json').write_text(json.dumps({'verification':v,'canonical_envelope_sha256':envelope_sha256(e),'inputs':json.loads((S.parent/'envelope.json').read_text())['input_packet']},indent=2))
(O/'result.json').write_text(json.dumps({'subject':e.subject.to_mapping(),'checks':{'inputs-verified':'PASS','review-complete':'PASS','evidence-complete':'PASS'},'unresolved':[]},indent=2))
files=[]
for p in sorted(S.rglob('*')):
 assert not p.is_symlink()
 if p.is_file() and not p.name.startswith('final_preflight') and p.suffix not in ('.gz','.tar'):files.append((p,p.relative_to(S).as_posix()))
a=O/'evidence.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for p,n in files:t.add(p,arcname=n,recursive=False)
records=[];seen=set()
with tarfile.open(a,'r:gz') as t:
 for z in t.getmembers():
  n=z.name;p=PurePosixPath(n)
  assert z.isfile() and not z.issym() and not z.islnk() and not p.is_absolute() and '..' not in p.parts and n not in seen
  assert not n.endswith(('.tar','.tar.gz','.tgz','.zip'))
  seen.add(n);d=t.extractfile(z).read();assert len(d)==z.size and d==(S/n).read_bytes()
  records.append({'path':n,'size':len(d),'sha256':hashlib.sha256(d).hexdigest()})
assert len(records)==len(files)
manifest={'archive_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'archive_size':a.stat().st_size,'member_count':len(records),'members':records}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2));assert verify_input_packet(e,R)[0]
print(json.dumps({'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'members_reopened':len(records),'inputs':'PASS','canonical_envelope':'PASS'}))
