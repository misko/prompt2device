from pathlib import Path
from collections import Counter
import json,hashlib,pcbnew
R=Path.cwd();N=Path('/tmp/carrier-rj45-20260912');P=R/'projects/crow-mic-pod-v3';bp=P/'04_kicad/crow_mic_pod_v3.kicad_pcb';gp=P/'06_build/drc/gate.json'
e=json.loads((P/'06_build/task_runs/rj45-pod-placement-after-top_only1/outputs/evidence.json').read_text());prior=e['drc_classification']['06_build/drc/pre_route.json'];g=json.loads(gp.read_text());pre=json.loads((P/'06_build/drc/pre_route.json').read_text());key=lambda x:json.dumps(x,sort_keys=True)
assert hashlib.sha256(bp.read_bytes()).hexdigest()==prior['board_sha256'];assert not g['violations'] and not g['schematic_parity'];assert Counter(map(key,g['unconnected_items']))==Counter(map(key,pre['unconnected_items']));assert len(prior['unconnected_items'])==len(g['unconnected_items'])==58
b=pcbnew.LoadBoard(str(bp));assert not list(b.GetTracks());pads={p.m_Uuid.AsString():p for f in b.GetFootprints() for p in f.Pads()}
for row in prior['unconnected_items']:
 for end in row['endpoints']:
  raw=end['report_item'];pad=pads[raw['uuid']];v=end['native_pad'];assert pad.GetNetname()==v['net'];assert pad.GetNumber()==v['number'] and pad.GetParentFootprint().GetReference()==v['ref'];assert all(abs(getattr(pad.GetPosition(),axis)/1e6-raw['pos'][axis])<.000002 for axis in ['x','y'])
out={'board_sha256':prior['board_sha256'],'report_sha256':hashlib.sha256(gp.read_bytes()).hexdigest(),'method':'Fresh all-severity/refill/parity native DRC; all 58 raw rows equal preceding independently classified current placement rows. Every 116 UUID/XY/net endpoint independently reopened through pcbnew. No tracks/vias; no routing acceptance.','counts':{'violations':0,'unconnected_items':58,'schematic_parity':0,'endpoints_verified':116},'rows':prior['unconnected_items'],'raw':g}
(N/'pod-top-only-current-classification.json').write_text(json.dumps(out,indent=2)+'\n');print(out['counts'])
