from pathlib import Path
import sys,json
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
out=[]
for slug in ['crow-audio-carrier-v1']:
 p=R/'projects'/slug
 for stage in ['prelayout-inputs','prelayout','schematic']:
  record=p/'06_build/checkpoints'/f'{stage}.json';d=json.loads(record.read_text())
  if stage=='prelayout-inputs':cmd=['/usr/bin/python3','-B',str(R/'projects/crow-roof-array-v1/03_src/prelayout_input_checkpoint.py'),'verify',str(p),'--repo-root',str(R),'--record',str(record)]
  else:cmd=['/usr/bin/python3','-B',str(R/'skills/kicad-pcb/scripts/stage_checkpoint.py'),'verify',str(p),stage]
  name=f'{slug}-{stage}-locator-policy-current';result=run_stage({'id':name,'work_class':'local','timeout_s':30},cmd,log_path=N/(name+'.log'),cwd=R,env={'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':'/home/mouse9911','PYTHONDONTWRITEBYTECODE':'1'},console_line_limit=2,console_tail_lines=1)
  row={'project':slug,'stage':stage,'fields':len(d['files']),'result':result.to_mapping()};out.append(row);(N/'locator-policy-current-checkpoints.json').write_text(json.dumps(out,indent=2)+'\n');assert result.status=='PASS'
print([(x['project'],x['stage'],x['fields']) for x in out])
