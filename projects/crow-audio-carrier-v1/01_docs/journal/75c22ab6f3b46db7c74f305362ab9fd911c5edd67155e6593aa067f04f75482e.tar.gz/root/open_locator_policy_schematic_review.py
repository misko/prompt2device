from pathlib import Path
from datetime import datetime,timezone,timedelta
import sys,json,hashlib,shutil,tempfile
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
slug,lens=sys.argv[1:3];revision=sys.argv[3] if len(sys.argv)>3 else '';short='pod' if 'pod' in slug else 'carrier';name=f'rj45-{short}-{lens}-review'+('-'+revision if revision else '');D=Path(tempfile.mkdtemp(prefix=name+'-'));P=D/'project';live=R/'projects'/slug
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'))
from pre_route_review_check import digest,netlist_digest,design_rules_digest
for directory in ['02_parts','03_src','03_tscircuit/src']:
 shutil.copytree(live/directory,P/directory,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
files=['03_tscircuit/manifest.yaml','03_tscircuit/build/circuit.json','03_tscircuit/build/schematic.pdf','06_build/build_provenance.json','06_build/erc.rpt','06_build/erc_errors.rpt']
files += [str(p.relative_to(live)) for p in (live/'04_kicad').glob('*.kicad_sch')]
files += [str(p.relative_to(live)) for p in (live/'06_build/netlists').glob('*.net')]
files += [str(p.relative_to(live)) for p in (live/'06_build/checkpoints').glob('*.json')]
files += [str(p.relative_to(live)) for p in (live/'01_docs').glob('*') if p.is_file()]
files += [str(p.relative_to(live)) for folder in ['decisions','sourcing'] for p in (live/'01_docs'/folder).rglob('*') if p.is_file()]
files += [str(p.relative_to(live)) for p in (live/'06_build/verification').glob('connector_assembly*.json')]
files += [str(p.relative_to(live)) for p in (live/'06_build/sourcing').glob('*') if p.is_file()]
for rel in sorted(set(files)):
 src=live/rel
 if src.exists():
  dst=P/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
for rel in ['CLAUDE.md','skills/pcb-design/SKILL.md','skills/pcb-design/references/execution-runtime.md','skills/pcb-design/references/review-and-publication.md','skills/kicad-pcb/references/design-policies.md','skills/kicad-pcb/references/tscircuit-folder.md','skills/kicad-pcb/scripts/pre_route_review_check.py']:
 dst=D/'context'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/rel,dst)
for kind in ['topology','schematic_render']:
 dst=D/'previous-reviews'/f'pre-route_{kind}.md';dst.parent.mkdir(exist_ok=True);shutil.copy2(live/'08_reviews'/dst.name,dst)
# Only the immediately accepted subject is carried as comparison evidence.
for previous_lens in ['topology','readability']:
 prior_revision = 'top_only1'
 meta=json.loads((N/f'rj45-{short}-{previous_lens}-review-{prior_revision}-opened.json').read_text())
 assert json.loads((Path(meta['envelope']).parent/'attempt.json').read_text())['status']=='PASS'
 dst=D/'preceding-receipts'/previous_lens;dst.mkdir(parents=True)
 for filename in ['report.md','evidence-manifest.json']:
  shutil.copy2(Path(meta['output_dir'])/filename,dst/filename)
 shutil.copy2(Path(meta['envelope']).parent/'attempt.json',dst/'delivery-attempt.json')
 if previous_lens=='topology':
  old=Path(meta['project'])/'project';old_dst=D/'preceding-subject'
  for folder in ['03_tscircuit/src','06_build/netlists','03_src','02_parts']:
   shutil.copytree(old/folder,old_dst/folder)
  for rel in ['03_tscircuit/build/circuit.json','03_tscircuit/build/schematic.pdf','03_src/floorplan.yaml']+[str(x.relative_to(old)) for x in (old/'04_kicad').glob('*.kicad_sch')]:
   target=old_dst/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old/rel,target)
probe=json.loads((N/'rj45-locator-policy-schematic-availability-opened.json').read_text())
assert json.loads((Path(probe['envelope']).parent/'attempt.json').read_text())['status']=='PASS'
assert (live/'06_build/checkpoints/schematic.json').is_file()
for key in ['rj45-locator-policy-source-review1-closeout-summary.json','locator-policy-source-adoption.json']:
 dst=D/'decision-context'/key;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(N/key,dst)
shutil.copy2('/tmp/carrier-locator-implementation-availability-6c_4vwal/preflight.py',D/'preflight.py')
net=next((P/'06_build/netlists').glob('*.net'));parts=sorted((P/'02_parts').glob('*/part.yaml'))
hashes={'netlist_sha256':netlist_digest(net),'parts_sha256':hashlib.sha256(b''.join(p.relative_to(P).as_posix().encode()+b'\0'+p.read_bytes()+b'\0' for p in parts)).hexdigest(),'design_rules_sha256':design_rules_digest(P),'schematic_pdf_sha256':digest(P/'03_tscircuit/build/schematic.pdf'),'exact_netlist_sha256':digest(net),'circuit_json_sha256':digest(P/'03_tscircuit/build/circuit.json'),'kicad_schematic_sha256':digest(next((P/'04_kicad').glob('*.kicad_sch')))}
(D/'expected-subject.json').write_text(json.dumps(hashes,indent=2)+'\n')
now=datetime.now(timezone.utc);cut=now+timedelta(minutes=15);hard=now+timedelta(minutes=22)
(D/'TASK.md').write_text(f'''# Fresh independent {lens} review after exact locator-policy source correction

Review exact frozen project/ for {slug}; root is sole live writer. Follow copied canon, current source/dossiers, generated CircuitJSON/native schematic/netlist and PDF. Do not load prior conversation or historical review reasoning. preceding-subject/ and preceding-receipts/ pin the immediately preceding top-only schematic subject for independently checked equivalence; they do not accept current bytes. Previous raw reports are immutable receipts only.

This renewal follows exact one-file policy_waivers.yaml correction adopted at23b35a34. The preceding top_only1 topology verdict was DEFECTIVE at CARRIER-TOPONLY-RULE-001: locator23 vs policy25 with now-visible R_ADC_PD1P/R_PWR_BOT. The preceding electrical graph was independently SOUND and preceding readability was SOUND. The exact separately reviewed correction removes only those2refs and changes expected output/budget25->23; no other source, electrical, geometry, renderer or checker change. Independent source review verified all333native refs1043pads/23exceptions/23pages, original and re-added-ref failures, and continued stale independent visual receipt rejection. Source verdict is not current schematic acceptance or active waiver. Independently verify actual delta and current complete electrical/source/native graph plus drawing bodies. Inspect exact corrected rule membership and unchanged conditional waiver effectiveness. Preserve original DEFECTIVE and oldSOUND readability separately; no old report is acceptance of new hashes.

Topology lens: independently verify current connector pins and nets, source/native fidelity, shield isolation, electrical and rating facts, and every actual changed component/rule/source row. Compare all prior/current native component and pin censuses and classify additions/removals/deltas explicitly; derive current pod counts rather than inheriting an earlier40component denominator. Apply the maintained project source-to-native electrical invariants with an integrated current review. This packet owns carrier only: verify its current333first-power references. Pod population is outside this review. No voltage/current limit may rise from a source renewal. Renew all seven exact subject hashes using the frozen owning algorithm. A part/route seed source verdict cannot accept an unreviewed netlist.

Readability may use independently measured all-page native pixel equality to the immediately accepted subject, excluding only identified generated identity headers, to preserve observed unchanged visual coverage. Inspect current headers and integrated pages, plus every changed page/body and every prior unresolved readability finding. If equality is not proved, perform the full actual page census. Text extraction alone is not rendered readability; source descriptions are not delivered schematic. Reuse relevant unchanged-source evidence with explicit provenance, never restamp old reports. No unrelated checker code suite repetitions are required.

Readability lens: inspect actual deliveredPDF using images, including legible10-pinRJ45 labels, wires, power/shield labels and polarity/NC; all-page equality must be measured, not inferred from text extraction. Currentpower1/3/7,return2/6/8,audio+5,audio-4,shell9/10. CarrierCHASSIS andpodPOD_SHIELD isolatedGND. Customanalog/power viafactoryCat6A RJ45, NOT Ethernet/PoE; poweroffmating. Preserve classified ERCwarnings; zeroerrors does not mean all-severityclean. OldMicroFitdrawings/releases are historical.

Prototype boundary is accepted: SOURCEPASS and authenticFULLINCOMPLETE23carrier/9pod physicalobligations, FIRST-ARTICLE-ONLY/DO-NOT-ORDER; no extra physical-measurement prerequisite before fabrication. Publiccatalog design-only admission with blank operator response is not allocatedstock/order. No release or layout/route acceptance from this review. LAYOUT001closed3/3 unchanged.

All subprocess engineering/native/imageanalysis commands via shared pipeline_runtime.run_stage, finite timeout/directargv/explicitcwd/environment; /usr/bin/python3 -B and PYTHONDONTWRITEBYTECODE=1. Scratch/output only writable. Hostview_image permitted for images. Verify all frozen inputs before/after and use providedpreflight.py after packaging. No source edits/checkpointrestamp/livewrites. A discovered defect means DEFECTIVE, incompletecoverage means INCOMPLETE, never fakeSOUND.

report.md flat fields:review_stage:pre-route, review_kind:{'topology' if lens=='topology' else 'schematic_render'}, revieweridentity, context:FRESH,date,design_verdict:SOUND|DEFECTIVE|INCOMPLETE,order_verdict:DO-NOT-ORDER and exactsevenhashes. State measured coverage/denominators, source changes and actionable findings/limitations. Five outputs exactlyreport.md,evidence.json,evidence-manifest.json,evidence.tar.gz,result.json. evidence.json includes verdict,exactenvelope subject,methods/counts/findings. Archive methods/rawlogs/runtime/equivalenceevidence;manifest archive_sha256/archive_size/member_count/members(path,size,sha256), independentlyreopeneachregularmember, nosymlinks/traversal/duplicates/recursivearchive. result exactsubject andchecksevidence-complete/inputs-verified/review-complete PASSforhonestcompletedreview; domainacceptanceseparate. Work/actualFINALcutoff{cut.isoformat()},hard{hard.isoformat()},zero replacements. Root closes immediately on actualFINAL then independently verifies/adopts currentSOUND bytes.
''')
items=[]
for p in sorted(D.rglob('*')):
 if p.is_file():
  b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(D).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
s=subject_identity('native_schematic_review',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
e=TaskEnvelope(schema=2,task_id=name,stage_id='KICAD-SCHEMATIC',run_id=name,subject=s,executor='reviewer',execution_class='review_wait',recommended_agent_role='judgment',agent_role='judgment',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']})
o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),agent_id=f'/root/carrier_rj45_native_{short}_{lens}'+('_'+revision.replace('-','_') if revision else ''),work_cutoff=cut.isoformat());(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o));print(len(items),'frozen files')
