from pathlib import Path
import urllib.request,json,hashlib,datetime
import fitz
D=Path(__file__).parent
rows=[]
for name,url in [('molex-0400-product-record.pdf','https://static6.arrow.com/aropdfconversion/ebab874208bc1239da8a7d23e48fe71bccfab056/0436500400displaypdf.pdf'),('molex-0200-product-record.pdf','https://www.official.cz/static/_dokumenty/5/0/6/1/7/436500200.pdf')]:
 row={'url':url,'filename':name,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(url,timeout=25) as response:b=response.read(10*1024*1024);row['status']=response.status;row['final_url']=response.url
  (D/name).write_bytes(b);row.update(size=len(b),sha256=hashlib.sha256(b).hexdigest());doc=fitz.open(stream=b,filetype='pdf');row['links']=[x['uri'] for p in doc for x in p.get_links() if 'uri' in x and ('stp' in x['uri'].lower() or 'step' in x['uri'].lower())]
 except Exception as e:row['error']=repr(e)
 rows.append(row);print(json.dumps(row),flush=True)
(D/'link-discovery.json').write_text(json.dumps(rows,indent=2)+'\n')
