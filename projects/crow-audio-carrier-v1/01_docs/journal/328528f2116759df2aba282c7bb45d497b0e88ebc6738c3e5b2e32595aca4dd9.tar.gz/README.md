# Connector prerequisites — isolated candidate, not live design acceptance

Source inspected at f160e516 in the carrier worktree. Root retained sole live
project writer. No reviewer replacement was dispatched and no failed attempt
was reopened. All new geometry is a scratch candidate; source adoption belongs
to the subsequent model/placement owner after the schematic handoff.

## Measurements and primary authority

- Samtec exact drawing: source/TMM-Series_RevAS.pdf, SHA256
  66d9ffaa15ef8ff9b1614640d81fd2d1c2c6629b522df0cddc64acac3e73efc3.
  Sheet1 was rendered and inspected. Double-row 3.94REF width,12mm nominal
  six-position length,1.50REF insulator; style01 post A3.20,tail B3.50REF,
  straight length L8.20REF and contact C2.54REF. Table1 does not label A or C
  MIN; the existing dossier's minimum wording requires owner correction.
  The drawing is inch-dimensioned with metric references and title-block
  tolerances; this candidate does not sweep tolerances, flash, bow or pin tilt.
- Current generic KiCad model: source/PinHeader_2x06_P2.00mm_Vertical.step,
  SHA256 f029e4cc0f45d493369e12463a119f8b17d5b18b222c63cb738e8b55cf93d2d7.
  It contains364VERTEX_POINT locations, Z levels -2.8,-2.675,0,2,5.875,6mm.
  Its terminal extent differs from the selected Samtec drawing. Measurement
  is a STEP vertex dependency census, not a general curved-solid bbox solver.
- Candidate source generator constructs new prisms from dimensional facts;
  no manufacturer CAD copied. Encoding helper is retained under source/ and
  SHA-bound by samtec-candidate.json. Candidate body3.94x12x1.5mm, twelve .5mm
  square posts, z-3.5..4.7mm. Tips, insulator grooves, flash and tilt omitted.
- Fresh native qualification PASS4/4. Candidate P-MODEL-REG PASS4instances /
  48drilledcentres; maximum centre delta0.032mm, no measured projection beyond
  F.Fab/courtyard, front-side fraction0.825968 above0.75required. Original coupon
  top/front renders preserve four quarter-turn orientations and were viewed.
  The registration checker normalizes its internal coupon to0degrees; its
  four rows are not four independent model-transform qualifications.
- Deliberately inverted Z model keeps XY/pin registration and FAILS the exact
  mounting-side channel:0.534720below0.75. Full failed native receipt retained.
- Molex drawing source/SD43650-D8.pdf fixes the8.92mm nominal mouth depth and
  locates the10.16mm maximum board-edge dimension at the locating-peg centre,
  not the signal-pin row. Source arithmetic gives J1–J8 peg-to-edge6.68mm,
  mouth2.08mm inboard; J9 peg-to-edge3.68mm,mouth0.92mmoutboard. All nine are
  within this nominal location limit. No tolerance stack or native-board
  orientation approval is inferred. Do not copy another board's flush-mouth
  offset range or move these anchors merely because the mouth is recessed.

## Public CAD retrieval

0200 exact CAD URI was extracted from a manufacturer-authored product PDF at
https://www.official.cz/static/_dokumenty/5/0/6/1/7/436500200.pdf.
Both ordinary Molex automated-content STEP requests timed out after30seconds
with0bytes. They are FETCH_FAILED, not proven NO_CAD. No unchanged retry.
The older pdm_docs STEP link from Mouser redirects to Molex's product page in
the web tool. Samtec's exact product page currently requests an email address
for instant model downloads; no submission or message was made:
https://www.samtec.com/products/tmm-106-01-l-d.
Molex existing rectangular envelopes omit cavities/locking detail and cannot
supply a visible-mouth review. Exact public CAD remains owed; the current
candidate only addresses the Samtec header's dimensional representation.

## Retained setup failures

Initial PDF link parsing failed before any request because fitz was absent;
installed pdftohtml replaced it. Arrow mirror then timed out, while the other
PDF downloaded. First native coupon render failed because the helper omitted
HOME; the corrected helper preserved the actual HOME and completed. First
inverted-control wrapper rejected console_tail_lines greater than its line
limit before dispatch; corrected bounds allowed the actual known-bad run.
All original scripts and logs remain. No semantic engineering failure was
relabeled, no acceptance gate changed, no third-party approval fabricated.

## Next owner actions

Adopt nothing from this archive automatically. Review exact dimensional and
frame interpretation; integrate candidate generator/model and corrected Samtec
facts into their source owners together if accepted. Then regenerate and rerun
all affected source/checkpoint/review/model gates. For J10/J11, an explicit
vertical-top-entry orientation exclusion can explain why they have no planar
edge mouth; it cannot waive model registration, pin1 identity or TCSD/MCHStreamer
fit/service qualification. All11connectors stay in the denominator. Obtain
visible Molex mouth geometry and authoritative bounds before directional views.

The prepared schematic reviewer correction is still pending its additional
allowance. This research supplies no review acceptance, placement acceptance,
route, physical qualification, order authority or release.
