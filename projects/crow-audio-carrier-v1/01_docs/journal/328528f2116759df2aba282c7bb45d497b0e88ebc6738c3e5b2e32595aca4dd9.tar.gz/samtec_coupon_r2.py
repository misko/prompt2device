from pathlib import Path
import sys,os,json,hashlib
import pcbnew
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;sys.path.insert(0,str(R/'skills/pcb-design/scripts'));from pipeline_runtime import run_stage
board=pcbnew.BOARD();lib=P/'03_src/lib/crow_audio_carrier.pretty';name='Samtec_TMM-106-01-L-D_2x06_P2.00mm_Vertical';candidate=D/'Samtec_TMM-106-01-L-D_reference-candidate.wrl'
for idx,angle in enumerate([0,90,180,270]):
 fp=pcbnew.FootprintLoad(str(lib),name);assert fp and len(list(fp.Models()))==1
 fp.SetReference('P'+str(angle));fp.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(15+idx*25),pcbnew.FromMM(25)));fp.SetOrientationDegrees(angle);model=fp.Models()[0];model.m_Filename=str(candidate);fp.Models()[0]=model;board.Add(fp)
for a,b in [((5,5),(110,5)),((110,5),(110,45)),((110,45),(5,45)),((5,45),(5,5))]:
 edge=pcbnew.PCB_SHAPE(board);edge.SetShape(pcbnew.SHAPE_T_SEGMENT);edge.SetLayer(pcbnew.Edge_Cuts);edge.SetStart(pcbnew.VECTOR2I(pcbnew.FromMM(a[0]),pcbnew.FromMM(a[1])));edge.SetEnd(pcbnew.VECTOR2I(pcbnew.FromMM(b[0]),pcbnew.FromMM(b[1])));edge.SetWidth(pcbnew.FromMM(.05));board.Add(edge)
path=D/'samtec-candidate-coupon.kicad_pcb';pcbnew.SaveBoard(str(path),board)
rows=[]
for side in ['top','front']:
 r=run_stage({'id':'candidate-'+side,'work_class':'local','timeout_s':40},['kicad-cli','pcb','render','--width','1800','--height','1000','--quality','basic','--side',side,'-o',str(D/('candidate-'+side+'.png')),str(path)],log_path=D/('candidate-'+side+'-r2.log'),cwd=D,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},console_line_limit=2,console_tail_lines=1);rows.append(r.to_mapping());assert r.status=='PASS'
cmd=['/usr/bin/python3',str(R/'skills/jlcpcb-fab/scripts/native_model_registration.py'),str(path),str(D/'candidate-registration'),'--refs','P0,P90,P180,P270','--model-sha256',hashlib.sha256(candidate.read_bytes()).hexdigest(),'--registration-datum','drilled_centres','--fit-tol-mm','0.2','--courtyard-tol-mm','0.05','--search-margin-mm','4','--width','1600','--height','1200','--mount-side','front']
r=run_stage({'id':'candidate-registration','work_class':'local','timeout_s':80},cmd,log_path=D/'candidate-registration-r2.log',cwd=D,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},console_line_limit=4,console_tail_lines=3);rows.append(r.to_mapping());(D/'candidate-native-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'registration_status':r.status,'coupon_footprints':len(list(board.GetFootprints())),'candidate_only':True}));assert r.status=='PASS'
