# Native model physical registration — `native_top.png`

board_sha256: 79e3d47330b9dd3311f1b7032d5ffd070f44de8c2d43e0feb7b4e1b9a08f13fd
coupon_sha256: 735b3cde338e152ef6704da0dc824f81302c8dea2760e17d75ab4219a2b308fb
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 203b64514712efde0877bccd3a741fa06c9bcadeb3150878dd3b87fa45d3d0fa
footprint_registration_datum_sha256: e94002f06e208e0d26e6dba6fab90fe1be1b8ce399e837ff3575288a64ab6247
model_transform_sha256: 6cf53f0e2e5e9c07c31120b0a7392007f28e50daeb9d9b4fabcff69a71234dd2
registration_contract_sha256: e08681f30fd5aa9f2af8ec81793d749043c70a46c965e4879883a430ceab9d3a
tuple_cache_key: 77839cbeaf1322699345e31c3c282e8937882ef23fd8fa9ce9e9c77bc6323290
calibration_px_per_mm: 22.1640 x, 22.1712 y
anisotropy: 0.9997
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.050
registration_datum: drilled_centres
mount_side: front
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 0.534720
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected drilled_centres field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | registration centres inside | min pad margin mm |
|---|---:|---:|---:|---:|---:|
| P0 | 0.032 | 0.000 | 0.000 | 12/12 | 0.935 |
| P90 | 0.024 | 0.000 | 0.000 | 12/12 | 0.945 |
| P180 | 0.028 | 0.000 | 0.000 | 12/12 | 0.935 |
| P270 | 0.019 | 0.000 | 0.000 | 12/12 | 0.945 |

## Failures

- native body occupies only 0.535 of measured side-view solid on front mount side; minimum is 0.750
