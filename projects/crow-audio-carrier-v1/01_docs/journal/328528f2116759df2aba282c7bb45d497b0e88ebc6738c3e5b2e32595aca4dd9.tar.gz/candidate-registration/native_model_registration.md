# Native model physical registration — `native_top.png`

board_sha256: cf645d41d7c75b95d9895cd048d6c57be659e2690b48140a64911c94629f5797
coupon_sha256: 82de6d567139099f3fb1ee10dd8db7fdd631a5e70ce7d243985aa67af1e73b66
a-render_verdict: PASS
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 3a9f0dd56986b0a8b9fa5229f8fcd12451cb9b857a472bb36f87992f8f086737
footprint_registration_datum_sha256: e94002f06e208e0d26e6dba6fab90fe1be1b8ce399e837ff3575288a64ab6247
model_transform_sha256: 6cf53f0e2e5e9c07c31120b0a7392007f28e50daeb9d9b4fabcff69a71234dd2
registration_contract_sha256: e08681f30fd5aa9f2af8ec81793d749043c70a46c965e4879883a430ceab9d3a
tuple_cache_key: 2ac1d2ae8f162a0f5f8a7c5a9fae062e013cdce716cb1dd283f543b41d25549c
calibration_px_per_mm: 22.1640 x, 22.1712 y
anisotropy: 0.9997
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.050
registration_datum: drilled_centres
mount_side: front
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 0.825968
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected drilled_centres field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | registration centres inside | min pad margin mm |
|---|---:|---:|---:|---:|---:|
| P0 | 0.032 | 0.000 | 0.000 | 12/12 | 0.935 |
| P90 | 0.024 | 0.000 | 0.000 | 12/12 | 0.945 |
| P180 | 0.028 | 0.000 | 0.000 | 12/12 | 0.935 |
| P270 | 0.019 | 0.000 | 0.000 | 12/12 | 0.945 |

## Failures

- none
