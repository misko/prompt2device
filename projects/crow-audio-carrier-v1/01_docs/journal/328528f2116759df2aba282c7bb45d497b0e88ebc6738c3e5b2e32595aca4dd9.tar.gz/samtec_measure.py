from pathlib import Path
import sys,re,hashlib,json,os
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;sys.path.insert(0,str(R/'skills/pcb-design/scripts'));from pipeline_runtime import run_stage
p=Path('/home/mouse9911/.local/share/kicad/10.0/3dmodels/Connector_PinHeader_2.00mm.3dshapes/PinHeader_2x06_P2.00mm_Vertical.step');s=p.read_text();entities={int(m.group(1)):m.group(2) for m in re.finditer(r'#(\d+)\s*=\s*(.*?);',s,re.S)};solids=[]
for k,v in entities.items():
 if not v.startswith('MANIFOLD_SOLID_BREP'):continue
 todo=[k];seen=set();pts=[]
 while todo:
  q=todo.pop()
  if q in seen:continue
  seen.add(q);text=entities.get(q,'');todo.extend(int(x) for x in re.findall(r'#(\d+)',text))
  m=re.match(r"VERTEX_POINT\s*\([^,]*,\s*#(\d+)\s*\)",text)
  if m:
   c=entities[int(m.group(1))];coords=re.match(r'CARTESIAN_POINT\s*\([^,]*,\s*\(([^)]+)\)\s*\)',c)
   if coords:pts.append([float(x.strip()) for x in coords.group(1).split(',')])
 assert pts
 bounds=[min(x[i] for x in pts) for i in range(3)]+[max(x[i] for x in pts) for i in range(3)]
 solids.append({'entity':k,'vertices':len(pts),'vertex_bounds':bounds,'vertex_span':[bounds[i+3]-bounds[i] for i in range(3)]})
pdf=P/'02_parts/TMM-106-01-L-D/TMM-Series_RevAS.pdf';r=run_stage({'id':'samtec-drawing-view','work_class':'local','timeout_s':30},['/usr/bin/pdftoppm','-f','1','-singlefile','-r','150','-png',str(pdf),str(D/'samtec-drawing')],log_path=D/'samtec-drawing.log',cwd=D,env={'PATH':os.environ['PATH'],'LANG':'C.UTF-8'});(D/'samtec-drawing-runtime.json').write_text(json.dumps(r.to_mapping(),indent=2)+'\n');assert r.status=='PASS'
result={'source_model':str(p),'source_model_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_pdf_sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'method':'STEP MANIFOLD_SOLID_BREP dependency graph; Cartesian locations referenced by VERTEX_POINT only; reports vertex bounds, not a general curved-solid envelope solver','solids':solids}
(D/'samtec-solid-measurement.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
