from pathlib import Path,PurePosixPath
import sys,os,json,hashlib,zipfile,datetime
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');D=Path(__file__).parent;sys.path.insert(0,str(R/'skills/pcb-design/scripts'));from pipeline_runtime import run_stage
rows=[]
for mpn in ['436500200','436500400']:
 url=f'https://www.molex.com/content/dam/molex/molex-dot-com/products/automated/en-us/3dcadmodels/436/43650/{mpn}_stp.zip';dest=D/(mpn+'_stp.zip')
 argv=['/usr/bin/curl','--http1.1','--location','--fail','--show-error','--silent','--connect-timeout','10','--max-time','30','--dump-header',str(D/(mpn+'-headers.txt')),'--output',str(dest),url]
 r=run_stage({'id':'fetch-'+mpn,'work_class':'local','timeout_s':35},argv,log_path=D/(mpn+'-fetch.log'),cwd=D,env={'PATH':os.environ['PATH'],'LANG':'C.UTF-8'},heartbeat_s=10)
 row={'url':url,'url_authority':'0200 URI extracted from manufacturer product PDF; 0400 corresponding exact resource name from published product record','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runtime':r.to_mapping(),'members':[]}
 if r.status=='PASS':
  b=dest.read_bytes();row.update(size=len(b),sha256=hashlib.sha256(b).hexdigest())
  try:
   with zipfile.ZipFile(dest) as z:
    for m in z.infolist():
     p=PurePosixPath(m.filename);assert not p.is_absolute() and '..' not in p.parts and m.file_size<100*1024*1024
     if m.is_dir():continue
     data=z.read(m);row['members'].append({'name':m.filename,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
     out=D/mpn/p;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
  except Exception as e:row['parse_error']=repr(e)
 rows.append(row);(D/'cad-fetch.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k!='runtime'}),flush=True)
