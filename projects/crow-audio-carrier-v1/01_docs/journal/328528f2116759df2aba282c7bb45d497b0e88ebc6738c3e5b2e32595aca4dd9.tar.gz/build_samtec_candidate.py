"""Unadopted drawing-derived TMM-106-01-L-D candidate, no live writes.

Primary authority: TMM revision AS sheet1; metric reference dimensions.
Source code constructs new prisms; no manufacturer CAD copied. Nominal/reference
body and terminal geometry only, not production extremes or socket-fit proof.
"""
from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent
source=P/'03_src/build_package_models.py';spec=importlib.util.spec_from_file_location('model_encoder',source);g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
# Footprint frame: odd pads at x0, even pads x2; rows y0..10.
# Double-row body width3.94REF, length6*2=12 (+0/-.25), thickness1.50REF.
# Style01: post A3.20 (not labeled MIN), tail B3.50REF, overall L8.20REF;
# contact area C2.54REF. Details/tolerance extremes are explicitly not modeled.
shapes=[g.box('insulator_reference_envelope',-0.97,-1.0,2.97,11.0,0.0,1.5)]
for row in range(6):
 for col in range(2):
  pin=2*row+col+1;x=2.0*col;y=2.0*row
  shapes.append(g.box(f'terminal_{pin}',x-.25,y-.25,x+.25,y+.25,-3.5,4.7,g.METAL))
data=g.encode(shapes).encode();out=D/'Samtec_TMM-106-01-L-D_reference-candidate.wrl';out.write_bytes(data)
record={'status':'UNADOPTED_CANDIDATE','source_pdf':'02_parts/TMM-106-01-L-D/TMM-Series_RevAS.pdf','source_pdf_sha256':hashlib.sha256((P/'02_parts/TMM-106-01-L-D/TMM-Series_RevAS.pdf').read_bytes()).hexdigest(),'source_page':1,'generator_encoder_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(data).hexdigest(),'candidate_size':len(data),'solids':len(shapes),'terminals':12,'body_reference_mm':[3.94,12,1.5],'post_mm':3.2,'tail_reference_mm':3.5,'pin_reference_overall_mm':8.2,'contact_area_reference_mm':2.54,'post_note':'Drawing table does not label post A or contact area C as minimum; previous dossier wording requires correction. A is critical C2 and title-block inch tolerances apply unless specified. No tolerance sweep claimed.','frame':'footprintXY down; exporter negates Y once; Z0 seating plane','limitations':['Insulator grooves, tip chamfers, flash, bow and pin tilt omitted.','Maximum production envelope and socket insertion/retention unqualified.','No inherent mechanical polarization, per source header type.','No board, footprint, model registration, orientation approval or source adoption.']}
(D/'samtec-candidate.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
