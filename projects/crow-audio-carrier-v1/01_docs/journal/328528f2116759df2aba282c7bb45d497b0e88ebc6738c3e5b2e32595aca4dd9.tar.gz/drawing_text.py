from pathlib import Path
import sys,os,json
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');D=Path(__file__).parent;P=R/'projects/crow-audio-carrier-v1';sys.path.insert(0,str(R/'skills/pcb-design/scripts'));from pipeline_runtime import run_stage
r=run_stage({'id':'samtec-drawing-text','work_class':'local','timeout_s':20},['/usr/bin/pdftotext','-layout',str(P/'02_parts/TMM-106-01-L-D/TMM-Series_RevAS.pdf'),str(D/'samtec-drawing.txt')],log_path=D/'samtec-text.log',cwd=D,env={'PATH':os.environ['PATH'],'LANG':'C.UTF-8'});assert r.status=='PASS'
print((D/'samtec-drawing.txt').read_text())
