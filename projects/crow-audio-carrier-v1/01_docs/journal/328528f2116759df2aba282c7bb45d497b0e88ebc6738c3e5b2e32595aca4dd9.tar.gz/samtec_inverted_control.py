from pathlib import Path
import sys,os,json,hashlib,importlib.util
import pcbnew
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;sys.path.insert(0,str(R/'skills/pcb-design/scripts'));from pipeline_runtime import run_stage
spec=importlib.util.spec_from_file_location('encoder',P/'03_src/build_package_models.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
shapes=[g.box('deliberately_inverted_body',-.97,-1,2.97,11,-1.5,0)]
for row in range(6):
 for col in range(2):
  x=col*2;y=row*2;shapes.append(g.box('terminal_'+str(2*row+col+1),x-.25,y-.25,x+.25,y+.25,-4.7,3.5,g.METAL))
model=D/'Samtec_TMM_deliberately_inverted.wrl';model.write_text(g.encode(shapes));board=pcbnew.LoadBoard(str(D/'samtec-candidate-coupon.kicad_pcb'))
for fp in board.GetFootprints():
 m=fp.Models()[0];m.m_Filename=str(model);fp.Models()[0]=m
out=D/'samtec-inverted-coupon.kicad_pcb';pcbnew.SaveBoard(str(out),board)
cmd=['/usr/bin/python3',str(R/'skills/jlcpcb-fab/scripts/native_model_registration.py'),str(out),str(D/'inverted-registration'),'--refs','P0,P90,P180,P270','--model-sha256',hashlib.sha256(model.read_bytes()).hexdigest(),'--registration-datum','drilled_centres','--fit-tol-mm','0.2','--courtyard-tol-mm','0.05','--search-margin-mm','4','--width','1600','--height','1200','--mount-side','front']
r=run_stage({'id':'inverted-registration-control','work_class':'local','timeout_s':80},cmd,log_path=D/'inverted-registration.log',cwd=D,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},console_line_limit=4,console_tail_lines=6);(D/'inverted-runtime.json').write_text(json.dumps(r.to_mapping(),indent=2)+'\n')
report=(D/'inverted-registration/native_model_registration.md').read_text();assert r.status=='FAIL' and r.returncode!=0
print(report)
