from pathlib import Path
import urllib.request,json,hashlib,datetime,sys,os,re,html
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');D=Path(__file__).parent;sys.path.insert(0,str(R/'skills/pcb-design/scripts'));from pipeline_runtime import run_stage
rows=[]
for name,url in [('molex-0400-product-record.pdf','https://static6.arrow.com/aropdfconversion/ebab874208bc1239da8a7d23e48fe71bccfab056/0436500400displaypdf.pdf'),('molex-0200-product-record.pdf','https://www.official.cz/static/_dokumenty/5/0/6/1/7/436500200.pdf')]:
 row={'url':url,'filename':name,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(url,timeout=25) as response:b=response.read(10*1024*1024);row['status']=response.status;row['final_url']=response.url
  (D/name).write_bytes(b);row.update(size=len(b),sha256=hashlib.sha256(b).hexdigest())
  r=run_stage({'id':'links-'+name[:10],'work_class':'local','timeout_s':20},['/usr/bin/pdftohtml','-i','-stdout',str(D/name)],log_path=D/(name+'.html.log'),cwd=D,env={'PATH':os.environ['PATH'],'LANG':'C.UTF-8'},console_line_limit=0,console_tail_lines=0);(D/(name+'.runtime.json')).write_text(json.dumps(r.to_mapping(),indent=2)+'\n')
  row['links']=sorted(set(html.unescape(u) for u in re.findall(r'href="([^"]+)"',(D/(name+'.html.log')).read_text()) if 'stp' in u.lower() or 'step' in u.lower()))
 except Exception as e:row['error']=repr(e)
 rows.append(row);print(json.dumps(row),flush=True)
(D/'link-discovery.json').write_text(json.dumps(rows,indent=2)+'\n')
