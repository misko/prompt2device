import json, sys
from pathlib import Path

sys.dont_write_bytecode = True
scripts = Path("/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts")
sys.path.insert(0, str(scripts))
from pipeline_runtime import run_stage

scratch = Path(sys.argv[1])
out = run_stage(
    {"id": "waiver_native_extract", "work_class": "local", "timeout_s": 30},
    ["/usr/bin/python3", "-B", str(scratch / "native_extract.py"), str(scratch / "crow_audio_carrier_v1.kicad_pcb")],
    log_path=scratch / "native_extract2.log",
    cwd=scratch,
    console_line_limit=20,
)
(scratch / "native_runtime.json").write_text(json.dumps(out.to_mapping(), sort_keys=True, indent=2) + "\n")
if out.returncode != 0:
    raise SystemExit(out.returncode)
