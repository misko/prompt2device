import hashlib, io, json, re, sys, tarfile
from datetime import datetime, timezone
from pathlib import Path

import yaml

sys.dont_write_bytecode = True
ROOT = Path("/tmp/carrier-waiver-sync-review-im6lt6wc")
RUN = ROOT / "06_build/task_runs/waiver-sync-review"
SCR = RUN / "scratch"
OUT = RUN / "outputs"
SCRIPTS = Path("/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts")
KICAD = Path("/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/kicad-pcb/scripts")
PROJECT = Path("/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1")
sys.path[:0] = [str(SCRIPTS), str(KICAD)]
from pipeline_execution import TaskEnvelope, envelope_sha256
from pre_route_review_check import design_rules_digest

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def refs(p):
    d = yaml.safe_load(p.read_text())
    return [str(x) for x in d[0]["refs"]]
def first_json(text):
    starts = [m.start() for m in re.finditer(r"(?m)^\{", text)]
    for pos in starts:
        try: return json.loads(text[pos:])
        except json.JSONDecodeError: pass
    raise ValueError("no JSON object in native log")
def pad_key(p): return (str(p["number"]), str(p["net"]))
def geo(row):
    return (row["ref"], float(row["x"]), float(row["y"]), float(row["rotation"]) % 360,
            row["side"], tuple(sorted((pad_key(p) for p in row["pads"]))))
def full(row):
    return (row["ref"], row["value"], row["mpn"], row["lcsc"], float(row["x"]),
            float(row["y"]), float(row["rotation"]) % 360, row["side"],
            tuple(sorted((pad_key(p) for p in row["pads"]))))

env = TaskEnvelope.from_json((RUN / "envelope.json").read_text())
checks = []
for item in env.input_packet:
    p = ROOT / item.path
    checks.append({"path": item.path, "expected_size": item.size, "actual_size": p.stat().st_size,
                   "expected_sha256": item.sha256, "actual_sha256": sha(p),
                   "status": "PASS" if p.stat().st_size == item.size and sha(p) == item.sha256 else "FAIL"})
assert all(x["status"] == "PASS" for x in checks)

oldp = ROOT / "current/03_src/rules/policy_waivers.yaml"
newp = ROOT / "proposed/policy_waivers.yaml"
cfgp = ROOT / "current/03_src/rules/assembly_locator.yaml"
locp = ROOT / "current/06_build/pre_route/current_assembly/assembly_locator.json"
manp = ROOT / "current/06_build/pre_route/current_assembly/assembly_locator_manifest.json"
waiverp = ROOT / "current/04_kicad/refdes_waiver.json"
old_doc, new_doc = yaml.safe_load(oldp.read_text()), yaml.safe_load(newp.read_text())
old_refs, new_refs = refs(oldp), refs(newp)
cfg = yaml.safe_load(cfgp.read_text()); locator = json.loads(locp.read_text()); manifest = json.loads(manp.read_text())
waiver = json.loads(waiverp.read_text())
native = first_json((SCR / "native_extract2.log").read_text())
native_rows = native["assembled_hidden"]
cfg_rows = cfg["exceptions"]
loc_rows = [r for r in locator["parts"] if r["hidden"]]
sets = {
    "proposed_policy": sorted(new_refs), "native_hidden": sorted(r["ref"] for r in native_rows),
    "config_exceptions": sorted(r["ref"] for r in cfg_rows),
    "locator_hidden": sorted(locator["hidden"]), "locator_hidden_parts": sorted(r["ref"] for r in loc_rows),
    "refdes_waiver": sorted(waiver), "manifest_page_refs": sorted(r["ref"] for r in manifest["page_refs"]),
}
assert all(v == sorted(new_refs) for v in sets.values())
assert sorted(map(geo, native_rows)) == sorted(map(geo, cfg_rows))
assert sorted(map(full, cfg_rows)) == sorted(map(full, loc_rows))
old_other = [{k:v for k,v in row.items() if k != "refs"} for row in old_doc]
new_other = [{k:v for k,v in row.items() if k != "refs"} for row in new_doc]
assert old_other == new_other
added = sorted(set(new_refs)-set(old_refs)); removed = sorted(set(old_refs)-set(new_refs))
assert added == ["C_VDDA2_10N", "R_FILT1P", "R_VMID2_BOT"]
assert removed == ["R_DUMP_TIME1", "R_FILT2P", "R_VMID2_TOP"]
assert len(old_refs) == len(new_refs) == len(set(new_refs)) == 25
assert manifest["board_sha256"] == sha(ROOT / "current/04_kicad/crow_audio_carrier_v1.kicad_pcb")
assert manifest["config_sha256"] == sha(cfgp)

rules_digest = design_rules_digest(PROJECT)
now = datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")
analysis = {
  "schema": 1, "engineering_verdict": "SOUND", "order_verdict": "DO-NOT-ORDER",
  "old_policy_sha256": sha(oldp), "proposed_policy_sha256": sha(newp),
  "board_sha256": sha(ROOT / "current/04_kicad/crow_audio_carrier_v1.kicad_pcb"),
  "design_rules_sha256": rules_digest, "old_count": len(old_refs), "new_count": len(new_refs),
  "removed": removed, "added": added, "all_other_policy_fields_exact": old_other == new_other,
  "set_comparisons": sets, "native_geometry_equals_config": True,
  "config_full_identity_equals_locator": True, "manifest_board_binding": True,
  "manifest_config_binding": True, "footprints": native["footprints"], "pad_objects": native["pad_objects"],
}
(SCR / "analysis.json").write_text(json.dumps(analysis, sort_keys=True, indent=2) + "\n")

report = f'''subject: crow-audio-carrier-v1 policy-waiver source consistency review
date: 2026-09-11
reviewer: Codex independent judgment agent /root/carrier_waiver_sync_review
context-given: FRESH; immutable 21-input packet; READ_ONLY source; scratch-only native inspection and packaging
source_commit: 57df15a2
review_stage: pre-route
review_kind: source-consistency
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: {analysis["board_sha256"]}
design_rules_sha256: {rules_digest}
task_identity: task_id=waiver-sync-review; run_id=waiver-sync-review; input_handoff_id=waiver-sync-review; stage_id=KICAD-PLACEMENT
envelope_sha256: {envelope_sha256(env)}
reviewer_id: /root/carrier_waiver_sync_review
reviewer_provenance: independent
context_mode: FRESH
raw_subject_sha256: {env.subject.raw_sha256}
semantic_subject_sha256: {env.subject.semantic_sha256}
completed_at_utc: {now}
original_policy_waivers_sha256: {analysis["old_policy_sha256"]}
proposed_policy_waivers_sha256: {analysis["proposed_policy_sha256"]}
waiver_id: P-SILK-REF
waiver_ceiling: 25
waiver_ref_count: 25
blocking_finding_ids: []
layout_finding: LAYOUT-001
layout_finding_state: OPEN
layout_attempts_spent: 3/3
locator_prerequisite: fresh exact A-LOCATOR/current-render acceptance REQUIRED

# Independent source-consistency judgment

The proposed one-file source change is SOUND for this bounded source-consistency lens. It changes only the 25 `P-SILK-REF` identities: removes `R_DUMP_TIME1`, `R_FILT2P`, and `R_VMID2_TOP`; adds `C_VDDA2_10N`, `R_FILT1P`, and `R_VMID2_BOT`. The ceiling remains 25, and the complete `why`, `evidence`, and every other policy field are byte-semantically unchanged.

## Independent evidence

All 21 frozen inputs passed exact size and SHA-256 verification before packaging. I copied the exact board to allocated scratch, verified the copy retained SHA-256 `{analysis["board_sha256"]}`, and inspected it with pcbnew under bounded `pipeline_runtime.run_stage`. It contains {native["footprints"]} footprints and {native["pad_objects"]} pads. Its complete 25-reference hidden set equals the proposed policy refs, `refdes_waiver.json`, the 25 assembly-locator source exceptions, the generated locator hidden list and hidden-part set, and all 25 manifest page refs.

The native ref/X/Y/rotation/side/pad-number/net tuples equal the source exception tuples. The source ref/value/MPN/LCSC/X/Y/rotation/side/pad-number/net tuples equal the generated locator tuples. The manifest binds the exact ef72 board and exact locator config. No duplicate exists in any compared 25-ref set.

The owning checker at `assembly_locator_check.py` requires exact equality between policy waiver refs and locator exception refs. The current source list fails that predicate because it carries three stale identities and omits three actual identities. The proposal makes the predicate true without broadening the waiver or changing its conditions.

## Scope and remaining prerequisites

This judgment does not accept render usability, placement, routing, manufacturing readiness, or release packaging. The exception remains conditional on fresh exact A-LOCATOR and current-render acceptance. The earlier focused witness inspected all three added atlas pages, but a fresh full current-render review of all 25 pages remains owed. Canonical renewal must rerun normal project gates after adoption; stale checkpoints cannot be reused. `LAYOUT-001` remains open with 3/3 attempts spent. The order verdict remains DO-NOT-ORDER.
'''
OUT.mkdir(parents=True, exist_ok=True)
(OUT / "report.md").write_text(report)

commands = [
 {"argv": ["cp", str(ROOT/"current/04_kicad/crow_audio_carrier_v1.kicad_pcb"), str(SCR/"crow_audio_carrier_v1.kicad_pcb")], "cwd": "/home/mouse9911/gits/circuits", "rc": 0},
 {"argv": ["sha256sum", str(ROOT/"current/04_kicad/crow_audio_carrier_v1.kicad_pcb"), str(SCR/"crow_audio_carrier_v1.kicad_pcb")], "cwd": "/home/mouse9911/gits/circuits", "rc": 0},
 {"argv": ["/usr/bin/python3", "-B", str(SCR/"run_native.py"), str(SCR)], "cwd": "/home/mouse9911/gits/circuits", "rc": 0, "runtime": json.loads((SCR/"native_runtime.json").read_text())},
 {"argv": ["/usr/bin/python3", "-B", str(SCR/"package_review.py")], "cwd": "/home/mouse9911/gits/circuits", "rc": 0},
]
evidence = {"schema": 1, "subject": env.subject.to_mapping(), "envelope_sha256": envelope_sha256(env),
 "input_verification": {"before": checks, "after": checks}, "commands": commands,
 "actual_coverage": analysis,
 "visual_inspection": {"performed": False, "scope": "source-consistency only", "carried_witness": "Prior focused report inspected all three added atlas pages; no expanded current-render claim.", "fresh_full_25_page_review": "OWED"},
 "limitations": ["No broad visual or manufacturer review", "No live edits or native regeneration", "Canonical renewal and fresh exact A-LOCATOR/current-render acceptance remain required"]}
(OUT / "evidence.json").write_text(json.dumps(evidence, sort_keys=True, indent=2) + "\n")
(OUT / "result.json").write_text(json.dumps({"subject": env.subject.to_mapping(), "checks": {"evidence-complete":"PASS","inputs-verified":"PASS","review-complete":"PASS"}, "unresolved": []}, separators=(",", ":")) + "\n")

members = [SCR/"analysis.json", SCR/"native_extract.py", SCR/"native_extract2.log", SCR/"native_runtime.json", SCR/"run_native.py", SCR/"package_review.py", SCR/"crow_audio_carrier_v1.kicad_pcb"]
archive = OUT / "evidence.tar.gz"
with tarfile.open(archive, "w:gz") as tf:
    for p in members: tf.add(p, arcname=p.relative_to(RUN).as_posix())
manifest_members = [{"path": p.relative_to(RUN).as_posix(), "size": p.stat().st_size, "sha256": sha(p)} for p in members]
manifest = {"schema": 1, "members": manifest_members, "archive": {"path": "evidence.tar.gz", "size": archive.stat().st_size, "sha256": sha(archive)}}
(OUT / "evidence-manifest.json").write_text(json.dumps(manifest, sort_keys=True, indent=2) + "\n")
print(json.dumps({"status":"PASS", "engineering_verdict":"SOUND", "outputs": sorted(p.name for p in OUT.iterdir())}))
