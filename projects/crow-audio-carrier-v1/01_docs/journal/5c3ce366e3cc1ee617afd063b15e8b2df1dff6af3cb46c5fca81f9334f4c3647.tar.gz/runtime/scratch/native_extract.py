import json, sys
from pathlib import Path
import pcbnew

board_path = Path(sys.argv[1])
board = pcbnew.LoadBoard(str(board_path))
rows = []
for fp in board.GetFootprints():
    ref = fp.GetReference()
    field = fp.Reference()
    if not field.IsVisible():
        pads = sorted(
            ({"number": p.GetNumber(), "net": p.GetNetname()} for p in fp.Pads()),
            key=lambda p: (p["number"], p["net"]),
        )
        pos = fp.GetPosition()
        rows.append({
            "ref": ref,
            "board_only": bool(fp.GetAttributes() & pcbnew.FP_BOARD_ONLY),
            "x": pos.x / 1_000_000,
            "y": pos.y / 1_000_000,
            "rotation": fp.GetOrientationDegrees(),
            "side": "top" if fp.GetLayer() == pcbnew.F_Cu else "bottom",
            "pads": pads,
        })
out = {
    "board": str(board_path),
    "footprints": len(board.GetFootprints()),
    "pad_objects": sum(len(fp.Pads()) for fp in board.GetFootprints()),
    "hidden": sorted(rows, key=lambda r: r["ref"]),
    "assembled_hidden": sorted((r for r in rows if not r["board_only"]), key=lambda r: r["ref"]),
}
print(json.dumps(out, sort_keys=True, indent=2))
