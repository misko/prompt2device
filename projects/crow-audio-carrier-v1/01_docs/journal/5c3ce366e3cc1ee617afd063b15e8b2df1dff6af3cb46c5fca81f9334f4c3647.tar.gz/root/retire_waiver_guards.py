from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,tarfile,subprocess
D=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';sha=lambda b:hashlib.sha256(b).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R).strip(),'require committed source and evidence'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();h=json.loads((D/'owned-placement-preservation-result.json').read_text())['sha256'];path=P/'01_docs/journal'/(h+'.tar.gz');assert sha(path.read_bytes())==h
with tarfile.open(path) as t:
 doc=json.load(t.extractfile('MANIFEST.json'));members=doc['members'];refs=doc['references'];assert set(t.getnames())==set(members)|{'MANIFEST.json'}
 def read(n):
  if n in members:
   row=members[n];b=t.extractfile(n).read()
  else:
   row=refs[n]
   if 'git_commit' in row:b=subprocess.check_output(['git','show',row['git_commit']+':'+row['path']],cwd=R)
   else:b=read(row['archive_member'])
  assert sha(b)==row['sha256'] and len(b)==row['size'],n
  return b
 for n in members:read(n)
 for n in refs:read(n)
 old=json.loads(read('generated/06_build/checkpoints/prelayout-inputs.json'))
 for key in old['explicit']:
  p=R/key.removeprefix('repo:');assert sha(p.read_bytes())==old['files'][key]['sha256'],key
 guards=['06_build/checkpoints/prelayout-inputs.json','06_build/checkpoints/prelayout.json','06_build/checkpoints/schematic.json','06_build/sourcing/prelayout_request.json','06_build/sourcing/prelayout_response.csv'];retired=[]
 for n in guards:
  p=P/n;assert not p.is_symlink();b=p.read_bytes();assert b==read('generated/'+n),n;retired.append({'path':n,'sha256':sha(b),'size':len(b)})
 absent=['06_build/sourcing/prelayout_receipt.json']
 for n in absent:assert not (P/n).exists() and not (P/n).is_symlink()
for row in retired:(P/row['path']).unlink()
r={'time':datetime.now(timezone.utc).isoformat(),'source_commit':head,'archive_sha256':h,'retired':retired,'absent':absent,'companion_count':len(old['explicit']),'authorization':'Accepted companion policy-waiver identity synchronization and original finish/release goal. Exact stale guards archived/reopened then retired for normal regeneration; no restamping.'}
(D/'waiver-guard-retirement.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
