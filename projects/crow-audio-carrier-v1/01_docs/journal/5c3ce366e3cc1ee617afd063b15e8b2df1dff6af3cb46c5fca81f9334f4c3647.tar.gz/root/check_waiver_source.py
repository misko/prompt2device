from pathlib import Path
import sys,json,yaml,hashlib
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;j=json.loads((D/'waiver-sync-review-opened.json').read_text())[0];Q=Path(j['project']);sys.path.insert(0,str(R/'skills/jlcpcb-fab/scripts'))
from assembly_locator_check import waiver_refs
old=Q/'current/03_src/rules/policy_waivers.yaml';new=Q/'proposed/policy_waivers.yaml';config={x['ref'] for x in yaml.safe_load((P/'03_src/rules/assembly_locator.yaml').read_text())['exceptions']};native=set(json.loads((P/'04_kicad/refdes_waiver.json').read_text()));manifest={x['ref'] for x in json.loads((P/'06_build/pre_route/current_assembly/assembly_locator_manifest.json').read_text())['page_refs']}
assert waiver_refs(old)!=config and waiver_refs(new)==config==native==manifest and len(config)==25
x,y=yaml.safe_load(old.read_text()),yaml.safe_load(new.read_text());assert len(x)==len(y)==1;del x[0]['refs'];del y[0]['refs'];assert x==y
print(json.dumps({'original_source_predicate':'FAIL as originally observed','proposed_source_predicate':'PASS25/25 policy/config/native/manifest identities','all_other_policy_fields_unchanged':True,'scope':'Source identity only; current full locator visual review and all downstream gates remain owed'},indent=2))
