# Recorded canonical attempt

- qualify: rc=0, 20.234467s; full raw output execution.log
- placement: rc=1, 111.727877s; full raw output execution.log
- locator-current-assembly: rc=0, 3.596433s; full raw output execution.log
- locator-current-twin: rc=0, 12.218888s; full raw output execution.log
- locator-current-overlay: rc=0, 1.489299s; full raw output execution.log
- locator-native-full-top: rc=0, 11.795017s; full raw output execution.log
- Authored input hashes: 592/592
- All generated identities are in execution.json.
- Stop at the last actual recorded gate. No routing or release acceptance.
