from pathlib import Path
import subprocess,json,hashlib,sys
sys.dont_write_bytecode=True
import pcbnew
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;oldpath=D/'channel-prior-pin-board.kicad_pcb';oldpath.write_bytes(subprocess.check_output(['git','show','f2675b43:projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb'],cwd=R));current=P/'04_kicad/crow_audio_carrier_v1.kicad_pcb';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(oldpath)=='9aa1c2c821a31129176a8b519b9a211d78dfc011adb997a64470c03d0726891f'
def row(f):
 return {'position':[f.GetPosition().x,f.GetPosition().y],'rotation':f.GetOrientationDegrees(),'layer':f.GetLayer(),'value':f.GetValue(),'fpid':str(f.GetFPID().GetLibNickname())+':'+str(f.GetFPID().GetLibItemName()),'attributes':int(f.GetAttributes()),'pads':sorted((p.GetNumber(),p.GetPosition().x,p.GetPosition().y,p.GetSize().x,p.GetSize().y,p.GetNetname(),p.GetOrientationDegrees(),p.GetShape(),p.GetRoundRectCornerRadius(),p.GetDrillSize().x,p.GetDrillSize().y,p.GetAttribute(),tuple(p.GetLayerSet().Seq()),p.GetLocalSolderMaskMargin(),p.GetLocalSolderPasteMargin(),p.GetLocalSolderPasteMarginRatio(),p.GetLocalZoneConnection()) for p in f.Pads())}
assert sha(current)!=sha(oldpath), 'New placement has not yet been generated'
boards={name:pcbnew.LoadBoard(str(p)) for name,p in [('previous',oldpath),('current',current)]}
maps={name:{f.GetReference():row(f) for f in board.GetFootprints()} for name,board in boards.items()};a,b=maps.values();assert a.keys()==b.keys()
changed=sorted(r for r in a if a[r]!=b[r]);caps={f'C_ADC_CM{n}{leg}':f'C_ADC_CM{5-n}{leg}' for n in range(1,5) for leg in ['P','N']}
assert changed==sorted(['U_ADC',*caps]),changed
net_map={f'ADC{n}{leg}':f'ADC{5-n}{leg}' for n in range(1,5) for leg in ['P','N']}
import copy
expected={}
for ref,v in a.items():
 target=caps.get(ref,ref);v=copy.deepcopy(v)
 if ref=='U_ADC' or ref in caps:
  pads=[]
  for pad in v['pads']:
   q=list(pad);q[5]=net_map.get(q[5],q[5]);pads.append(tuple(q))
  v['pads']=sorted(pads)
 expected[target]=v
assert expected==b,[r for r in expected if expected[r]!=b[r]]
# Unchanged manufacturer pin identity; only ADC placement guidance changed.
import yaml
prefix='projects/crow-audio-carrier-v1/'
names=subprocess.check_output(['git','ls-tree','-r','--name-only','f2675b43','--',prefix+'02_parts'],cwd=R,text=True).splitlines()
previous_parts={n.removeprefix(prefix):subprocess.check_output(['git','show','f2675b43:'+n],cwd=R) for n in names if n.endswith('/part.yaml')}
current_parts={f.relative_to(P).as_posix():f.read_bytes() for f in (P/'02_parts').glob('*/part.yaml')}
assert previous_parts.keys()==current_parts.keys()
part_delta=[n for n in previous_parts if previous_parts[n]!=current_parts[n]];assert part_delta==['02_parts/CS5308P-DN/part.yaml'],part_delta
old_doc=yaml.safe_load(previous_parts[part_delta[0]]);new_doc=yaml.safe_load(current_parts[part_delta[0]])
assert {k:v for k,v in old_doc.items() if k!='layout'}=={k:v for k,v in new_doc.items() if k!='layout'}
proof={'board_sha256':sha(current),'previous_board_sha256':sha(oldpath),'footprints':len(b),'pad_objects':sum(len(v['pads']) for v in b.values()),'changed_pin_projections':changed,'unaffected_exact_footprints':len(b)-len(changed),'expected_transformed_projection_equal':True,'old_untransformed_projection_equal':False,'part_files':len(current_parts),'changed_part_files':part_delta,'unchanged_manufacturer_identity_except_layout_guidance':True,'cap_reference_exchange':caps,'net_exchange_at_adc_and_caps':net_map,'method':'Native pcbnew full keyed footprint/pad projection; exact equality only after the explicit ADR0027 mapping. Old untransformed projection must differ on exactly nine refs. Every pad shape/position/angle/size/drill/layers/mask/paste/local-zone-connection property retained.','limits':'No new datasheet-derived pin judgment or body/silk/render/route acceptance. Supply this measured delta to a fresh independent pin reviewer before aggregation.'}
(D/'channel-pin-transfer-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
