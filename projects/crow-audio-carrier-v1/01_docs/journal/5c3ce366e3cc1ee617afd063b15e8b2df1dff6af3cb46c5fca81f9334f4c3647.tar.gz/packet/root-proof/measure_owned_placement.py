from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
import pcbnew
D=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';Q=P;OLD=Path('/tmp/carrier-owned-source-review-qbyj34yf/current');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=(D/'verify_channel_pin_transfer.py').read_text();ns={'pcbnew':pcbnew};exec(s[s.index('def row(f):'):s.index("assert sha(current)")],ns)
a=pcbnew.LoadBoard(str(OLD/'04_kicad/crow_audio_carrier_v1.kicad_pcb'));b=pcbnew.LoadBoard(str(Q/'04_kicad/crow_audio_carrier_v1.kicad_pcb'));rows=lambda board:{f.GetReference():ns['row'](f) for f in board.GetFootprints()};ra,rb=rows(a),rows(b);assert ra==rb
hidden=lambda board: sorted(f.GetReference() for f in board.GetFootprints() if not f.Reference().IsVisible() and not f.GetAttributes()&pcbnew.FP_BOARD_ONLY)
x,y=hidden(a),hidden(b)
def fields(board):
 return {f.GetReference():(f.Reference().IsVisible(),f.Reference().GetPosition().x,f.Reference().GetPosition().y,f.Reference().GetTextAngleDegrees(),f.Reference().GetTextSize().x,f.Reference().GetTextThickness()) for f in board.GetFootprints()}
fa,fb=fields(a),fields(b);changed=sorted(r for r in fa if fa[r]!=fb[r]);assert changed==['R_DUMP_TIME1','R_VMID2_TOP'],changed
assert len(y)==25 and set(y).issubset(x),y
record={'board_sha256':sha(OLD/'04_kicad/crow_audio_carrier_v1.kicad_pcb'),'candidate_sha256':sha(Q/'04_kicad/crow_audio_carrier_v1.kicad_pcb'),'footprints':len(ra),'pad_objects':sum(len(x['pads']) for x in ra.values()),'native_physical_pin_projection_equal':ra==rb,'previous_hidden':x,'candidate_hidden':y,'changed_reference_fields':changed,'all_other_reference_fields_exact':True,'newly_visible':sorted(set(x)-set(y)),'newly_hidden':sorted(set(y)-set(x)),'candidate_fields':{r:fb[r] for r in changed},'candidate_status':'Exact native projection/refdes proof for regenerated canonical placement; owning DRC, current pin/render/locator/layout review remain separate.'}
(D/'owned-placement-native-proof.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
