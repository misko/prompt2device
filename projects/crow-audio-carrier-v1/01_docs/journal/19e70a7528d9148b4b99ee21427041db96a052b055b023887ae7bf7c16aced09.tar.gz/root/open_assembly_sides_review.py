from placement_review_common import *
import subprocess
name='assembly-sides-source-review1'
files=['skills/jlcpcb-fab/scripts/assembly_coverage.py','skills/jlcpcb-fab/references/assembly-and-order.md','skills/kicad-pcb/references/design-policies.md','skills/pcb-design/templates/contracts/03_src/rules/contracts.md','skills/pcb-design/templates/03_src/rules/assembly.yaml','tests/t1_assembly_gates.py','tests/README.md']
B=N/'assembly-sides-beforeimages';B.mkdir(exist_ok=True)
records=[];copies=[]
for rel in files:
 p=R/rel;b=subprocess.run(['git','show','HEAD:'+rel],cwd=R,capture_output=True,check=True).stdout;q=B/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 copies.extend([(p,'candidate/'+rel),(q,'before/'+rel)])
 records.append({'path':rel,'before_sha256':hashlib.sha256(b).hexdigest(),'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(N/'assembly-sides-source-identity.json').write_text(json.dumps(records,indent=2)+'\n');copies.append((N/'assembly-sides-source-identity.json','candidate/source-identity.json'))
for rel in ['CLAUDE.md','tests/harness.py','skills/pcb-design/SKILL.md','skills/jlcpcb-fab/SKILL.md','skills/pcb-design/references/execution-runtime.md','skills/pcb-design/references/lifecycle-and-backtrack.md']:
 copies.append((R/rel,'candidate/'+rel))
for label in ['assembly-sides-red','assembly-sides-red-actual','assembly-sides-green','assembly-sides-full','assembly-sides-final-full','assembly-sides-native-gap','assembly-sides-native-gap-v2','assembly-sides-authority','assembly-sides-docs','assembly-sides-contracts','assembly-sides-disclosure']:
 for suffix in ['.log','-runtime.json','-command.json']:
  p=Path('/tmp/carrier-connector-integration-20260911')/(label+suffix)
  if p.is_file():copies.append((p,'root-evidence/'+p.name))
copies.append((N/'top-only-existing-native-gap.json','root-evidence/native-gap.json'))
task='''# Independent exact assembly-side source review

Fresh independent source/code review of7exact candidate sourcefiles. Root owns live source; candidate frozen/read-only; work in scratch. Use applicablePCBskill and testsREADME. Newuser requirement bothboards allfittedSMDTOPinclmanual. OwningexistingA-POS/assembly_coverage nowchecks declared sides against native numberedsmdcopperandCPLmountedside. No CAD geometry source or physical design acceptance in this review.

Review complete diff against before/ and exact candidate/source-identity.json, data flow, full public CLI behavior, backward compatibility and policy/contract coherence. Independently run seven new 'assembly sides' tests (copy minimal same repo hierarchy to scratch so harness FAB_SCRIPTS resolves there). Tests call public CLI and synthesize byte fixtures; no network/nativepcbnewneeded. Rootfull48test result may be inherited explicitly for oldfleetfixtures, not claimedrerun. Probe at least one independent hostile case outside authored tests. Verify rawroot RED was realexit0wrongbehavior, initialzeroselectiondiagnosticnotcounted. Newgate counts actual numberedSMDcopper ratherthanattrs toexcludebareFID; manualoffCPLstillgraded, DNP/testpointoffCPLexcluded, mechanicalwithSMDlandsincluded. Sidesmissinglegacyexplicitungraded, malformedprovidedpolicyfails; native/CPLsidealwaysmustagree. THTprocesscheckstillseparate. Check summarydenominatorsaretruthful. Nativeexistinggap root306carrierSMD incl16bottom/31podincl1bottom provesoldlayoutfails, not top-onlycompletedclaim.

No new broad features or rewriting upstream schemas; report concrete regression/falsepass or honestSOUNDexactfiles. Give source reviewverdictSOUND|DEFECTIVE|INCOMPLETE with affectedpaths/check/evidence. Known limits: no physical component/clearance/paste proof; correctlydeclaredDNP can't bephysicallyverifiedoffline. Missinglegacysidepolicy remainsungraded; no top-onlyclaimfromabsence. No editing candidate, project, checkerlive, sealingororder. If dependency absent, copy exact live read-only andhashrecord or stateowedscope. Root fullaudit initiallyfaileduntrackednewarchives/ADRs andwillrerunafterstaging; no ratchetwaiver. Root does not ask this reviewer to accept finalproject/release or toplanelayout.
'''
o=open_task(name,task,copies,minutes=15,role='judgment')
