from pathlib import Path
import sys,json,hashlib
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');sys.path.insert(0,str(R/'skills/jlcpcb-fab/scripts'))
from assembly_coverage import read_footprints,load_assembly,check_assembly_sides
out={}
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 p=R/'projects'/slug;b=next((p/'04_kicad').glob('*.kicad_pcb'));a=p/'03_src/rules/assembly.yaml';fps=read_footprints(b)
 fails,summary=check_assembly_sides(fps,[],load_assembly(a))
 out[slug]={'board_sha256':hashlib.sha256(b.read_bytes()).hexdigest(),'assembly_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'summary':summary,'findings':fails,'native_smd_refs':[f['ref'] for f in fps if f.get('smd_copper_pads')]}
print(json.dumps({s:{'summary':v['summary'],'findings':v['findings']} for s,v in out.items()},indent=2))
Path('/tmp/carrier-rj45-20260912/top-only-existing-native-gap.json').write_text(json.dumps(out,indent=2)+'\n')
assert len(out['crow-audio-carrier-v1']['findings'])==16
assert len(out['crow-mic-pod-v3']['findings'])==1
