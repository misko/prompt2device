from pathlib import Path
from datetime import datetime,timezone
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
now=datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S')
entry=f'''

## {now} UTC — user requires top-only fitted SMD; source redesign opened

The verbatim user directive is appended to both boards and parent BRIEF. Accepted manufacturing decisions carrier0029/pod0008/parent0014 require all fitted SMD on F.Cu, including manual/consigned parts, with modest board growth authorized. Both assembly.yaml now declare sides:[top]. Existing native layouts remain unchanged and FAIL the new requirement: carrier306 fitted SMD has16bottom (F1–8,U_ESD1–8), pod31 has1bottom (U3). Top-only placement is not yet implemented or accepted. Bare fiducial/test copper and THT joints do not count as fitted SMD.

Both obsolete mixed-side source tasks delivered actual FINAL and closed PASS17:06:16Z/17:06:17Z (delivery only); engineering INCOMPLETE is retained. Carrier2/2candidates spent: VMID4/4 dominance,12thermals cleared,20/20silk ownership and R_PWR_PU2.472974mm gap were author-measured, but C_VDDA1_10N.2 isolated ground island and AP63205 module-type applicability remain. No source adopted. Pod one unqualified R13/C10 proposal was preserved; no candidate generation or routing pilot ran. Durable archives carrier b36e0248e8e7caa87efc8779c2e17bdc2874de6cdabc0f56744511171a7cb40c (649 frozen/290 inner) and pod eb24335683b7db88deb5d5b4a2676a2441eacee352a33832c4cfb59356359058 (370 frozen/43 inner) preserve actual handbacks. Prior attempt budgets remain spent.

New shared isolated source owner /root/rj45_top_only_source1 has816frozen inputs, envelopea3b0f0ec4fc4ac7b4701090a80ca852e5d1beb4e35e19c27496f05586b1e6b7b, workcut17:46:27Z/hard17:53:27Z, atmost2native candidates/0routing pilots/0replacements. Root owns both live boards. Author early geometry reports jack audio pin5 sits at least6.36mm inside nominal body; old4.0mm padcenter/4.2mm bottom-prefix limits cannot carry unchanged to an external top clamp. This is inherited preliminary diagnosis, not adopted replacement limits. Exact source geometry, protection path and primary guidance must support a reviewable replacement. Factory jack/cord/pinmap remain selected.

Root assembly-side checker proposal independently reads native numbered SMD lands and CPL side, includes manual population and reports missing legacy policy as ungraded. Public CLI regression pre-fix had4known-bad families falsely exit0; initial zero-test filter diagnostic is excluded. Current48/48assembly tests pass (24known-bad). Fresh independent source reviewer /root/assembly_sides_source_review1 has57frozen inputs, envelope7e8e144f0a1ace617ab9365995793d17c3d24d796310476b0621d18c956a7dc5, workcut17:32:19Z/hard17:39:19Z. No pending verdict adopted. Source/checkpoint/placement/routing/export/twin and changed orientation subjects must renew after exact source acceptance. FIRST-ARTICLE-ONLY/DO-NOT-ORDER; neither new release minted.
'''
# Retrieve actual closure dates rather than trust report prose.
import json
N=Path('/tmp/carrier-rj45-20260912')
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3','crow-roof-array-v1']:
 p=R/'projects'/slug/'01_docs/journal/placement.md'
 with p.open('a') as f:f.write(entry)
# Correct preceding overbroad transport diagnosis with actual later observation.
p=R/'projects/crow-audio-carrier-v1/01_docs/journal/schematic.md'
with p.open('a') as f:f.write(f'''

## {now} UTC — correction to twin transport diagnosis; top-only redesign

The16:31 entry overstates the failed CAD fetch set: reopening the raw16:23run shows only three HTTP403 positive-CAD failures (C53283916,C1509297,C6937839), plus two successful actual absence observations (C3761431,C861313). These distinct facts were never admissible as five CAD absences. Root normal diagnostic twin reused49positive CAD cache codes with194hash-verified files and no copied absence observations. New requests at16:52:44.609080Z/16:52:45.891966Z freshly observed the two exact absences. Ordinary twin13.217s PASS333/333bodies (300CPL+33manual),290rotation fits. Same-camera overlays measured76/317top and8/16bottom;249bodies below the fixed2mm measurement floor remain explicitly unresolvable, not pixel-verified. Relocated292-file bundle preserved all333 nonempty in-bundle model paths. Archiveb665e317c53c7976ee70cd3b4ce139ad4f3fdb7911c92206121d71a791127b8d preserves362reopenedmembers. Transport is recovered; final render acceptance remains owed, and the newtop-only manufacturing directive supersedes this oldlayout subject.

Pod first actual configured routing campaign3candidates failed the same real R13.2 via-in-pad in2.599s, no FINAL or acceptance. Correct configuredKRT checkoutcccv-5a1bdc4 is clean at5a1bdc4d9582fa6c9019cf5bab9625ea4452f188; an earlier diagnostic queried the wrong unused defaultcheckout. This is a source geometry defect, not a router environment blocker. Routing archive05862ef49808f81e9f3e846375764eecd1afb2bc2795ca138dd2c8926f60c234 preserves the failed campaign. Latest placement journal owns the newtop-only design stage; root solelivewriter, no obsolete mixed-side routing retry. Neither new release minted.
''')
print('Appended factual checkpoint and corrected transport diagnosis.')
