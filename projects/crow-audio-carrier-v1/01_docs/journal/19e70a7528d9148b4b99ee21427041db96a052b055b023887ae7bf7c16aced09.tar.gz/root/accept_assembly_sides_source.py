from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
m=json.loads((N/'assembly-sides-fresh-review2-opened.json').read_text());a=json.loads(Path(m['attempt']).read_text());assert a['status']=='PASS'
c=json.loads((N/'assembly-sides-fresh-review2-closeout-summary.json').read_text());assert c['engineering_verdict']=='SOUND'
D=Path(m['project']);rows=json.loads((D/'candidate/source-identity.json').read_text())
assert len(rows)==7
for row in rows:
 p=R/row['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['after_sha256']
 assert p.read_bytes()==(D/'candidate'/row['path']).read_bytes()
gap=json.loads((N/'top-only-existing-native-gap.json').read_text())
for slug,record in gap.items():
 p=R/'projects'/slug;b=next((p/'04_kicad').glob('*.kicad_pcb'));assert hashlib.sha256(b.read_bytes()).hexdigest()==record['board_sha256']
 assert hashlib.sha256((p/'03_src/rules/assembly.yaml').read_bytes()).hexdigest()==record['assembly_sha256']
record={'accepted_at':datetime.now(timezone.utc).isoformat(),'scope':'Seven exact assembly-side checker/test/documentation source files only; bothnativeboards still failtop-only. Repository finalchecks separatelyowed.','review_closed_at':a['finished_at'],'review_archive':c['sha256'],'source_files':rows,'native_gap':gap}
(N/'assembly-sides-source-acceptance.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ['source_files','native_gap']},indent=2))
