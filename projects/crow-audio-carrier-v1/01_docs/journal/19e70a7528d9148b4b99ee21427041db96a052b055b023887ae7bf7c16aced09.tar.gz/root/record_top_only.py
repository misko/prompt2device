from pathlib import Path
from datetime import datetime,timezone
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
quote='Can we please make sure all SMD components are from one side? it will be tricky and costly to assign from both sides. We can expand the board a bit in size if tha thelps'
now=datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S')
for slug,num,old in [('crow-audio-carrier-v1','0029','0028'),('crow-mic-pod-v3','0008','0007'),('crow-roof-array-v1','0014','0013')]:
 p=R/'projects'/slug
 brief=p/'01_docs/BRIEF.md'
 brief.write_text(brief.read_text()+f'\n\n## 2026-09-13 — single-side SMD assembly directive\n\n> {quote}\n\nCurrent requirement: all fitted SMD components on the top (F.Cu) side of both\ncarrier and pod, including consigned or manually fitted SMD parts. Board growth\nis authorized where needed for placement, soldering and rework access.\nImplementation and regenerated layout acceptance remain pending.\n')
 adr=p/f'01_docs/decisions/{num}-top-only-smd-assembly.md'
 assert not adr.exists()
 adr.write_text(f'''---
id: {num}
date: 2026-09-13
status: accepted
---
# {num} — top-only SMD assembly

## Context

The user explicitly requested single-side SMD assembly to simplify assembly and
reduce cost, and authorized a modest board expansion if it helps. The previous
carrier layout has sixteen underside SMD components (F1–F8 and U_ESD1–U_ESD8);
the pod has one (U3). Those generated layouts do not satisfy the new requirement.

## Options

- Retain mixed-side SMD: rejected by the user manufacturing requirement.
- Move every fitted SMD component to the top and expand the board where needed:
  selected. This requires a new connector/protection layout because flipping
  an underside component beneath a jack would collide with its body.

## Decision

All fitted SMD components on both boards shall mount on F.Cu. This includes
machine-placed, consigned and manually fitted SMD components. No manual-fit
exception permits bottom SMD population. Unpopulated copper test pads, vias,
through-hole solder joints and copper routing are not SMD component population.
The factory RJ45 jack, patch cord, pin map and analog/DC interface remain selected.

This decision supersedes the mixed-side manufacturing and placement portions
of prior factory-RJ45 decisions, including carrier ADR0028 and pod ADR0007;
the historical records and their remaining interface decisions are retained.
Assembly policy must declare sides: [top]. Modest board growth is authorized;
its exact dimensions will follow measured body, tool and copper clearances.

## Consequences

Do not flip components in place under the jack. Rework source placement and
source-owned protection paths together, checking real pad, body, tail and rework
clearances. Prior geometry-specific bottom-layer ESD path requirements must be
reconciled explicitly with the new physical layout and primary protection
requirements before adoption. Existing limits remain in force until a justified,
independently reviewed replacement is adopted; changing a limit to pass is not
an acceptable repair. No release gate is waived by this manufacturing decision.

Previous layouts, route trials and reviews remain historical evidence. Regenerate
both boards and renew all affected source, placement, routing, BOM/CPL, twin and
release checks. Changed connector scenes need current orientation review and any
required human approval. The required result is no fitted SMD on B.Cu, verified
from native board bytes and the exported CPL, including manual-fit population.
This records accepted intent; it is not a claim of completed layout or assembly
savings measured by an assembler. FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains.
''')
 status=p/'01_docs/STATUS.md'
 status.write_text(f'''# STATUS beacon — {slug}

stage: placement
step: User requires top-only SMD assembly on both boards; coherent source redesign pending
measure: MEASURED: existing carrier16 and pod1 bottom SMD parts do not satisfy new requirement. Mixed-side authors closed INCOMPLETE with evidence preserved. Neither new release minted.
state: working
next: Root owns both live boards. Redesign top-side connector/protection cells with authorized board growth, independently review source, regenerate and renew affected gates. No obsolete mixed-side routing trial.
op_pid:
updated: {now}
''')
 if slug!='crow-roof-array-v1':
  a=p/'03_src/rules/assembly.yaml';s=a.read_text().replace('sides: [top, bottom]','sides: [top]')
  s=s.replace('Hand-solder the exact jack after two-sided SMT assembly','Hand-solder the exact jack after top-side SMT assembly')
  s=s.replace('  bottom_population: U_ESD1-U_ESD8 and F1-F8; bottom paste, CPL and clearance require exact qualification','  bottom_population: "none; all fitted SMD, including manual and consigned parts, must be on top"')
  s=s.replace('  bottom_population: "U3 only; require bottom paste/CPL and assembler DFM acceptance beside J1 tails"','  bottom_population: "none; all fitted SMD, including manual and consigned parts, must be on top"')
  s=s.replace('  - qualify bottom U_ESD1-U_ESD8 and F1-F8 stencil, paste, rotation, THT tail/fillet separation and rework access before PCBA','  - verify all fitted SMD on top, including U_ESD1-U_ESD8 and F1-F8; qualify top stencil, paste, rotation, THT body/tail separation and rework access before PCBA')
  a.write_text(s)
print('Recorded verbatim directive, three accepted manufacturing ADRs and top-only assembly intent; native layouts unchanged.')
