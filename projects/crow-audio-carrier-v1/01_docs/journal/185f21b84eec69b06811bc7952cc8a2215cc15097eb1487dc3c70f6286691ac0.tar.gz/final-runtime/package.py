import hashlib
import json
import os
import tarfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
RUN = ROOT / "06_build/task_runs/rj45-carrier-render-locator-toponly3"
SCRATCH = RUN / "scratch"
OUT = RUN / "outputs"
OUT.mkdir(exist_ok=True)

import sys
sys.path.insert(0, "/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts")
from pipeline_execution import TaskEnvelope, verify_input_packet

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

envelope = TaskEnvelope.from_json((RUN / "envelope.json").read_text())
verified, failures = verify_input_packet(envelope, ROOT)
assert verified and not failures
census = json.loads((SCRATCH / "source-census.json").read_text())
refs = [row["ref"] for row in census["locator_page_refs"]]
assert len(refs) == 23 and len(set(refs)) == 23
assert all(row["matches_manifest"] for row in census["locator_member_checks"])

approved = ROOT / "project/06_build/pre_route/approved_native_bottom.png"
reproduced = SCRATCH / "reproduced-bottom.png"
from PIL import Image, ImageChops, ImageStat
a = Image.open(approved).convert("RGB")
b = Image.open(reproduced).convert("RGB")
assert a.size == b.size
diff = ImageChops.difference(a, b)
h = diff.histogram()
diff_metrics = {
    "approved_sha256": sha(approved),
    "reproduced_sha256": sha(reproduced),
    "dimensions": list(a.size),
    "difference_bbox": list(diff.getbbox()) if diff.getbbox() else None,
    "mean_absolute_channel_difference": ImageStat.Stat(diff).mean,
    "nonzero_channel_sample_counts": [sum(h[c*256+1:(c+1)*256]) for c in range(3)],
    "interpretation": "Independent exact-recipe rerender is visually equivalent; tiny per-channel variation is consistent with ray-render sampling and does not change any body/side judgment."
}
(SCRATCH / "bottom-rerender-comparison.json").write_text(json.dumps(diff_metrics, indent=2) + "\n")

completed = datetime.now(timezone.utc).isoformat()
subject = envelope.subject.to_mapping()
report = f"""# Fresh independent carrier pre-route native render review

review_stage: pre-route
review_kind: render
reviewer: Codex GPT-6 independent reviewer /root/rj45_carrier_render_locator_toponly3
context: FRESH
completed_at: {completed}
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 92a4e2fc0fecde845f2dfa0d9e2f5bfbd943372962fb449d699a98d957fc5633
design_rules_sha256: 7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c
locator_manifest_sha256: 1dbd47a33fd57e5cd5af3c2ad52fe444e2479ad89fe5cfd7c67e4b6c4a2e91dd
locator_reviewed_refs: {json.dumps(refs, separators=(',', ':'))}

## Judgment

The exact frozen carrier board is sound for the pre-route native-render gate. The complete native top, front, back, left, right, oblique, connector-detail, and corrected native bottom evidence show a coherent full-board assembly. J1-J8 expose their RJ45 mouths outward in two opposed edge rows; J9 exposes the keyed power inlet toward the west edge; J10 and J11 are upright top-entry headers. The views preserve the real occlusion between parts rather than hiding bodies.

The corrected bottom render is consistent with the board source and with an independently repeated exact bottom-render recipe. It contains only the expected through-board pads, pins, retention pegs, mounting holes, and nominal connector geometry visible beyond the edges. It does not show fitted SMD bodies under the board. In particular, F1-F8 and U_ESD1-U_ESD8 are all source-measured on F.Cu and their bodies are absent from the underside image. The repeated render has the same 1568x872 composition and only a mean absolute ray-sampling difference of 0.0204-0.0215 levels per RGB channel.

Source census: 340 total mounted footprints, all 340 on F.Cu and zero on B.Cu; 309 footprints consist entirely of SMD pads, all on F.Cu and zero on B.Cu. There are 333 model-bearing fitted component bodies. The exact seven model omissions are H1, H2, H3, H4, FID1, FID2, and FID3. Those omissions are nominal mechanical mounting-hole/fiducial features, not missing fitted component bodies. Four rectangular Edge.Cuts primitives form the board boundary; 21 NPTH instances comprise the four board mounting holes, sixteen RJ45 retention pegs, and the J9 mechanical hole.

The accepted model-registration aggregate and all six underlying registration groups were reopened with their plan, side, and overlay imagery. The exact-board aggregate is PASS; tuple-bound bodies agree with footprint Fab/courtyard and drilled-centre or SMD-pad datums within their stated tolerances. No unintended body-to-body or body-to-board interaction is visible. Connector pins and retention pegs crossing the PCB plane are intentional.

The complete locator HTML contains all 333 assembly parts, and its manifest binds the exact board, BOM, CPL, generator, template, and checker. Every one of the 23 locator PNG pages and all 23 rasterized PDF pages was inspected. Each page clearly identifies its exception reference in a whole-board map and an enlarged local view with a unique highlighted body and numbered pads. The HTML, JSON, PDF, and 23 PNG hashes all match the manifest.

## Findings

- none

## Limits and release posture

Pixel evidence cannot qualify production tolerances, connector mating force, enclosure clearance, or service access. Native Fab/render geometry remains nominal, and small bodies can be occluded in whole-board views; source coordinates, footprints, registration overlays, and dedicated connector views resolve the reviewed side/datum facts. Catalog component-body twin fidelity is a separate gate and was not inferred from the native 333/333 body census. The board remains unrouted. Factory Cat6A/RJ45 carries custom analog/DC rather than Ethernet or PoE and requires power-off mating. FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains mandatory.
"""
(OUT / "report.md").write_text(report)

evidence = {
    "schema": 1,
    "subject": subject,
    "verdict": "SOUND",
    "review_stage": "pre-route",
    "review_kind": "render",
    "reviewer": "Codex GPT-6 independent reviewer /root/rj45_carrier_render_locator_toponly3",
    "completed_at": completed,
    "methods": [
        "Verified all 719 frozen envelope inputs before review and immediately before packaging.",
        "Opened the full native top/bottom/cardinal/oblique render set and all connector-detail views.",
        "Reopened the exact-board model-registration aggregate plus all six group reports and plan/side/overlay imagery.",
        "Measured mounted sides, coordinates, model/pad census, edge primitives, and NPTH features from the frozen native board with pcbnew.",
        "Repeated the exact bottom kicad-cli render recipe in scratch and compared the resulting pixels with the approved image.",
        "Opened all 23 locator PNG pages and rasterized and inspected all 23 PDF pages; checked the HTML part census and every manifest member hash."
    ],
    "findings": [],
    "measured_counts": {
        "envelope_inputs_verified": 719,
        "footprints_total": 340,
        "mounted_front": 340,
        "mounted_back": 0,
        "all_smd_pad_footprints_front": 309,
        "all_smd_pad_footprints_back": 0,
        "model_bodies": 333,
        "nominal_mechanical_model_omissions": 7,
        "connectors_reviewed": 11,
        "rj45_connectors_reviewed": 8,
        "locator_refs_reviewed": 23,
        "locator_png_pages_reviewed": 23,
        "locator_pdf_pages_reviewed": 23,
        "native_registration_groups_reviewed": 6,
        "edge_cut_primitives": 4,
        "npth_instances": 21
    },
    "identities": {
        "board_sha256": census["board_sha256"],
        "design_rules_sha256": "7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c",
        "bottom_render_sha256": census["bottom_render_sha256"],
        "locator_manifest_sha256": census["locator_manifest_sha256"],
        "orientation_rendered_board_sha256": census["orientation_rendered_board_sha256"],
        "locator_reviewed_refs": refs,
        "nominal_mechanical_model_omissions": census["fitted_without_models"]
    },
    "bottom_rerender_comparison": diff_metrics,
    "limitations": [
        "Native render pixels do not qualify physical production tolerances or service access.",
        "Catalog component-body twin fidelity is outside this native-render judgment.",
        "The exact board is unrouted and remains FIRST-ARTICLE-ONLY / DO-NOT-ORDER."
    ]
}
(OUT / "evidence.json").write_text(json.dumps(evidence, indent=2) + "\n")

archive_sources = [
    "review_method.py", "source-census.json", "bottom-rerender-comparison.json",
    "locator-contact-sheet.jpg", "pdf-contact-sheet.jpg", "orientation-contact-sheet.jpg",
    "registration-contact-sheet.jpg", "reproduced-bottom.png", "bottom-diff.png",
    "review3-source-census.log", "review3-source-census-runtime.json",
    "review3-registration-sheet.log", "review3-registration-sheet-runtime.json",
    "review3-pdf-raster.log", "review3-pdf-raster-runtime.json",
    "review3-pdf-raster2.log", "review3-pdf-raster2-runtime.json",
    "review3-pdf-sheet.log", "review3-pdf-sheet-runtime.json",
    "review3-bottom-reproduce.log", "review3-bottom-reproduce-runtime.json",
]
archive = OUT / "evidence.tar.gz"
with tarfile.open(archive, "w:gz", format=tarfile.PAX_FORMAT) as tf:
    for name in archive_sources:
        p = SCRATCH / name
        assert p.is_file() and not p.is_symlink()
        info = tf.gettarinfo(str(p), arcname=name)
        info.uid = info.gid = 0
        info.uname = info.gname = ""
        with p.open("rb") as stream:
            tf.addfile(info, stream)

members=[]
seen=set()
with tarfile.open(archive, "r:gz") as tf:
    for member in tf.getmembers():
        assert member.isfile() and member.name not in seen and not member.name.startswith("/") and ".." not in Path(member.name).parts
        seen.add(member.name)
        stream=tf.extractfile(member); assert stream is not None
        data=stream.read(); assert len(data)==member.size
        members.append({"path":member.name,"size":member.size,"sha256":hashlib.sha256(data).hexdigest()})
manifest={"schema":1,"archive_sha256":sha(archive),"archive_size":archive.stat().st_size,"member_count":len(members),"members":members}
(OUT / "evidence-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")

result={"subject":subject,"checks":{"evidence-complete":"PASS","inputs-verified":"PASS","review-complete":"PASS"},"unresolved":[]}
(OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"completed_at":completed,"verdict":"SOUND","archive":str(archive),"members":len(members)},indent=2))
