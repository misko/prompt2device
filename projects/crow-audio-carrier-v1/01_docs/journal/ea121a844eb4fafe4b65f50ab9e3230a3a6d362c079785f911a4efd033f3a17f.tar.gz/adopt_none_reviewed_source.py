from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
review=json.loads((N/'rj45-none-return-independent-review1-closeout-summary.json').read_text());assert review['delivery_status']=='PASS' and review['engineering_verdict']=='SOUND';assert hashlib.sha256(Path(review['archive']).read_bytes()).hexdigest()==review['sha256']
meta=json.loads((N/'rj45-none-return-independent-review1-opened.json').read_text());D=Path(meta['project']);spec=json.loads((N/'none-final-governance/input-source-spec.json').read_text());assert len(spec['files'])==9
pending=[];accepted=[]
for row in spec['files']:
 rel=row['path'];p=R/rel;got=hashlib.sha256(p.read_bytes()).hexdigest();already=rel.endswith('/01_docs/findings.yaml');assert got==(row['after_sha256'] if already else row['before_sha256']),rel
 after=Path(row['after_path']).read_bytes();assert hashlib.sha256(after).hexdigest()==row['after_sha256']
 frozen=D/('root-narrative/after.yaml' if already else 'after/'+rel);assert frozen.read_bytes()==after
 if not already:pending.append((p,after))
 accepted.append({**row,'already_adopted_root_narrative':already})
boards=json.loads((N/'none-author-live-state-corroboration.json').read_text())['live_boards']
for rel,h in boards.items():assert hashlib.sha256((R/rel).read_bytes()).hexdigest()==h
for p,b in pending:p.write_bytes(b)
for row in spec['files']:assert hashlib.sha256((R/row['path']).read_bytes()).hexdigest()==row['after_sha256']
for rel,h in boards.items():assert hashlib.sha256((R/rel).read_bytes()).hexdigest()==h
record={'adopted_at':datetime.now(timezone.utc).isoformat(),'new_source_files':len(pending),'reviewed_composition_files':len(accepted),'source_files':accepted,'independent_review_archive':review['sha256'],'live_boards_unchanged':boards,'scope':'Exact independently SOUND9-file source composition:8new adoptions,1already-recorded root narrative correction. Final complete qualification binds identical9postimages. Native candidate5 remainsDEFECTIVE; no6admission performed. No schematic/checkpoint restamping or native promotion.','next_prerequisite':'Separately admitted maintained native pad/side fixture; then explicit reviewed changed-decision admission if all required facts hold.'}
(N/'none-reviewed-source-adoption.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'adopted_at':record['adopted_at'],'new_files':len(pending),'reviewed_files':9,'native_unchanged':True}))
