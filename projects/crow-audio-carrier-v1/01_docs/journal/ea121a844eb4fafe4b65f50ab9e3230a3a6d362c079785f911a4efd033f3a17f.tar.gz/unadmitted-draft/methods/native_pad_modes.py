from pathlib import Path
import json,sys,hashlib
import pcbnew as k
S=Path(__file__).resolve().parents[1];bp=Path(sys.argv[1]);c=json.loads((S/'methods/expected-pad-modes.json').read_text());b=k.LoadBoard(str(bp));rows=[]
for fp in b.GetFootprints():
 for p in fp.Pads():
  if p.GetNetname()=='GND':rows.append({'id':fp.GetReference()+'.'+p.GetNumber(),'uuid':p.m_Uuid.AsString(),'net':p.GetNetname(),'mode':int(p.GetLocalZoneConnection()),'xy_nm':[p.GetPosition().x,p.GetPosition().y]})
full=[r['id'] for r in rows if r['mode']==2];none=[r['id'] for r in rows if r['mode']==0];inherited=[r['id'] for r in rows if r['mode']==-1]
checks={'complete_ground_population':len(rows)==c['ground_pad_count'],'exact_full_population':len(full)==c['native_full_count'] and set(full)==set(c['source_full']+c['existing_native_full']),'exact_none_population':len(none)==c['native_none_count'] and set(none)==set(c['source_none']),'remaining_inherited':len(inherited)==c['inherited_count'],'closed_modes':all(r['mode'] in [-1,0,2] for r in rows)}
result={'board_sha256':hashlib.sha256(bp.read_bytes()).hexdigest(),'scope':'Saved native local pad modes only; does not establish zone-contact or prepared return/cut topology.','checks':checks,'rows':rows}
(S/'native-pad-mode-binding.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'checks':checks,'ground_pads':len(rows),'full':len(full),'none':len(none),'inherited':len(inherited)}));raise SystemExit(0 if all(checks.values()) else 1)
