from pathlib import Path
from datetime import datetime,timezone
import sys,json,hashlib
import pcbnew as k
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911')
for name in ['BOARD','LoadBoard','SaveBoard','ZONE_FILLER']:
 def forbidden(*a,_name=name,**kw):raise AssertionError('Forbidden '+_name)
 setattr(k,name,forbidden)
log=(I/'none-pad-side-fixture.log').read_text();assert '... ok' in log and '\nRan 1 test in ' in log and '\nOK\nTraceback' in log and log.rstrip().endswith('StopIteration')
assert json.loads((I/'none-pad-side-fixture-runtime.json').read_text())['status']=='FAIL'
sys.path.insert(0,str(R/'projects/crow-audio-carrier-v1/03_src/tests'))
from test_route_source_contract import load_source
from test_local_placement_source import source_builder
floor,route,nets,stack,comps,pins=load_source();ref='C_VDDA2_10N';lib,name=comps[ref][0].split(':');directory=R/'projects/crow-audio-carrier-v1/03_src/lib/crow_audio_carrier.pretty' if lib=='crow_audio_carrier' else Path('/usr/share/kicad/footprints')/(lib+'.pretty');fp=k.FootprintLoad(str(directory),name);assert fp is not None
source=source_builder(floor);x,y,rot,_=source.initial_pose(ref);assert source.place_cfg.get('sides',{}).get(ref,'top')=='top';fp.SetOrientationDegrees(rot);fp.SetPosition(k.VECTOR2I_MM(x,y))
pads=[p for p in fp.Pads() if p.GetNumber()=='2'];assert len(pads)==1;p=pads[0];extra={'ref':ref,'pad':'2','fpid':comps[ref][0],'net':pins[(ref,'2')],'smd':p.GetAttribute()==k.PAD_ATTRIB_SMD,'front':p.IsOnLayer(k.F_Cu),'back':p.IsOnLayer(k.B_Cu)};assert extra['net']=='GND' and extra['smd'] and extra['front'] and not extra['back']
a=json.loads((N/'none-reviewed-source-adoption.json').read_text())
for row in a['source_files']:assert hashlib.sha256((R/row['path']).read_bytes()).hexdigest()==row['after_sha256']
record={'status':'PASS','scope':'Combined actual maintained32pad/side test PASS and separate native extra-NONE-pad SMD/front witness. Original enclosing runner remainsFAIL because optional lookup used unset native reference; no BOARD fixture rerun or receipt restamp.','maintained_test':'GroundConnectionTests.test_targets_are_real_smd_ground_lands_on_declared_sides','maintained_testsRun':1,'maintained_source_targets':32,'original_outer_runtime':'FAIL','original_extension_error':'StopIteration; native_geometry leaves native references unset and binds source identities separately.','synthetic_board_python_api_calls_in_original_fixture':1,'extra_witness_board_calls':0,'product_board_constructions':0,'extra_none_pad':extra,'source_postimages_unchanged':9,'raw_evidence':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [N/'none_pad_side_fixture.py',N/'none-pad-side-fixture-started.json',I/'none-pad-side-fixture.log',I/'none-pad-side-fixture-runtime.json']],'completed_at':datetime.now(timezone.utc).isoformat()}
(N/'none-pad-side-fixture-result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'status':'PASS','maintained_source_targets':32,'extra_none_pad':extra,'product_board_constructions':0,'original_outer_runtime':'FAIL preserved'}))
