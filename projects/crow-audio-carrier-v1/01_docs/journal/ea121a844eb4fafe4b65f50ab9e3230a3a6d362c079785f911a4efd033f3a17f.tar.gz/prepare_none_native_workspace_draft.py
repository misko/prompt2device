"""Preparation only; never admits or executes another native construction."""
from pathlib import Path
import tempfile,shutil,json,hashlib
N=Path(__file__).parent;F=Path('/tmp/crow-none-return-full-qualification-20260913');OLD=Path('/tmp/crow-adc2-native5-preparation-8jf47vo0');Q=Path(tempfile.mkdtemp(prefix='crow-none-native6-unadmitted-'))
ignore=shutil.ignore_patterns('__pycache__','*.pyc','node_modules','.git')
for rel in ['projects/crow-audio-carrier-v1/03_src','projects/crow-audio-carrier-v1/02_parts','projects/crow-audio-carrier-v1/03_tscircuit/src','projects/crow-audio-carrier-v1/06_build/netlists','projects/crow-audio-carrier-v1/01_docs','skills','scripts']:
 # Exclude journal archives from proposed native inputs; exact source/decision
 # references remain separately bound on any future admission.
 src=F/rel;dst=Q/'work'/rel
 if rel.endswith('/01_docs'):
  shutil.copytree(src,dst,ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.tar.gz'))
 else:shutil.copytree(src,dst,ignore=ignore)
# Keep actual source-generated schematics/project setup as inputs, no preceding PCB.
src=OLD/'work/projects/crow-audio-carrier-v1/04_kicad';dst=Q/'work/projects/crow-audio-carrier-v1/04_kicad';shutil.copytree(src,dst,ignore=shutil.ignore_patterns('*.kicad_pcb','*.bak'))
shutil.copytree(OLD/'methods',Q/'methods',ignore=ignore)
spec=json.loads((N/'none-final-governance/input-source-spec.json').read_text())
for row in spec['files']:
 p=Q/'work'/row['path']
 # tests/t1 fixture is not a board producer input, but retain exact accepted
 # qualification source so a future manifest can bind the full correction.
 if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(F/row['path'],p)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==row['after_sha256']
source=(N/'candidate5_native_driver_draft.py').read_text();source=source.replace('candidate5','candidate6').replace('CANDIDATE5','CANDIDATE6').replace("admission['prior_native_candidates'] == 4","admission['prior_native_candidates'] == 5").replace("assert admission['independent_exact_source_native_acceptance'] == 'OWED_AFTER_THIS_CANDIDATE'","assert admission['independent_exact_source_acceptance'] == 'PASS'\nassert admission['independent_exact_native_acceptance'] == 'OWED_AFTER_THIS_CANDIDATE'")
source=source.replace('one root-admitted coherent ADC2 reservation/ADC1 scope candidate.','UNADMITTED explicit NONE-source native candidate; preparation only.').replace('Independent upstream recommendations and exact composed source preflight admit\nconstruction only; fresh independent exact source/native acceptance is still owed.','Requires actual independent source acceptance and an explicit reviewed changed\nupstream decision before root admission. Five prior attempts remain spent.\nThis file has not executed and does not admit construction by existing.')
(Q/'native_driver_DRAFT.py').write_text(source)
assert not list(Q.rglob('*.kicad_pcb'))
assert not (Q/'admission.json').exists() and not (Q/'input-manifest.json').exists()
record={'workspace':str(Q),'status':'UNADMITTED_NOT_RUN','source_files':9,'root_qualification_spec_sha256':hashlib.sha256((N/'none-final-governance/input-source-spec.json').read_bytes()).hexdigest(),'copied_methods':'Historical native methods copied unchanged as drafts; exact new NONE native binding and ordinary full/return classification must be reviewed before use. No physical acceptance inherited.','constraints':'No admission/start/input-manifest or PCB/r0 exists. No ledger/budget/history change. Await independent source and changed-decision judgment; root must explicitly admit before any use.'}
(Q/'PREPARATION_ONLY.json').write_text(json.dumps(record,indent=2)+'\n');(N/'none-native-workspace-draft.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
