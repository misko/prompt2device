from pathlib import Path
from datetime import datetime,timezone
import sys,json,hashlib,unittest
import pcbnew as k
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
adopt=json.loads((N/'none-reviewed-source-adoption.json').read_text());assert adopt['reviewed_composition_files']==9
for row in adopt['source_files']:assert hashlib.sha256((R/row['path']).read_bytes()).hexdigest()==row['after_sha256']
admission={'scope':'One maintained synthetic ground pad/side witness plus the exact new NONE pad SMD/side observation. Fresh independent source review d92be7eb supports prerequisite under separately permitted fixture scope. Root authorizes exactly1synthetic empty BOARD container, no product generation/Save/Load/Fill/prep/router, no6admission or budget reset.','max_synthetic_board_constructors':1,'maintained_test':'test_ground_connections.GroundConnectionTests.test_targets_are_real_smd_ground_lands_on_declared_sides','started_at':datetime.now(timezone.utc).isoformat()}
with (N/'none-pad-side-fixture-started.json').open('x') as f:json.dump(admission,f,indent=2)
original=k.BOARD;calls=[]
def one_board(*a,**kw):
 assert not calls,'More than one synthetic BOARD forbidden';calls.append('BOARD');return original(*a,**kw)
k.BOARD=one_board
for name in ['LoadBoard','SaveBoard','ZONE_FILLER']:
 def forbidden(*a,_name=name,**kw):raise AssertionError('Forbidden '+_name)
 setattr(k,name,forbidden)
sys.path.insert(0,str(R/'projects/crow-audio-carrier-v1/03_src/tests'))
import test_ground_connections as g
suite=unittest.defaultTestLoader.loadTestsFromName(admission['maintained_test']);assert suite.countTestCases()==1
r=unittest.TextTestRunner(verbosity=2).run(suite)
assert calls==['BOARD'] and r.wasSuccessful()
fp=next(f for f in g.GroundConnectionTests.geometry['footprints'] if f.GetReference()=='C_VDDA2_10N');pads=[p for p in fp.Pads() if p.GetNumber()=='2'];assert len(pads)==1;p=pads[0]
extra={'ref':'C_VDDA2_10N','pad':'2','smd':p.GetAttribute()==k.PAD_ATTRIB_SMD,'front':p.IsOnLayer(k.F_Cu),'back':p.IsOnLayer(k.B_Cu)};assert extra['smd'] and extra['front'] and not extra['back']
for row in adopt['source_files']:assert hashlib.sha256((R/row['path']).read_bytes()).hexdigest()==row['after_sha256']
record={'scope':admission['scope'],'maintained_test':admission['maintained_test'],'testsRun':r.testsRun,'status':'PASS','synthetic_board_constructors':len(calls),'product_board_constructions':0,'full_targets':len(g.TARGETS),'extra_none_pad':extra,'source_files_unchanged':9,'completed_at':datetime.now(timezone.utc).isoformat()}
(N/'none-pad-side-fixture-result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
