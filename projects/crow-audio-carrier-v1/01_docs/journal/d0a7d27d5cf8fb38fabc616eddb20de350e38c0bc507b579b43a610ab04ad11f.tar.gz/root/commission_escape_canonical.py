from pathlib import Path
from datetime import datetime,timezone,timedelta
import json,sys,hashlib,shutil,subprocess
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent
sys.path.insert(0,str(R/'skills/pcb-design/scripts'));sys.path.insert(0,str(R/'projects/crow-roof-array-v1/03_src'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
from prelayout_input_checkpoint import authored_census
retirement=json.loads((D/'escape-guard-retirement.json').read_text())
dirty=subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines()
assert set(dirty)<=set('projects/crow-audio-carrier-v1/'+r['path'] for r in retirement['retired']), 'Only exact archived guard retirement may be uncommitted'
assert not subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).strip()
for n in [r['path'] for r in retirement['retired']]+retirement['absent']:
 assert not (P/n).exists() and not (P/n).is_symlink(),n
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();now=datetime.now(timezone.utc);cut=now+timedelta(minutes=18);hard=now+timedelta(minutes=20);rid='escape-canonical-'+now.strftime('%Y%m%dT%H%M%SZ');H=P/'06_build/handoffs'/rid;H.mkdir(parents=True);ep=P/'06_build/task_runs'/rid/'envelope.json'
shutil.copyfile(D/'escape_canonical_runner.py',H/'runner.py');shutil.copyfile('/tmp/carrier-keying-source-review-27x1olqz/preflight.py',H/'preflight.py')
(H/'runner-config.json').write_text(json.dumps({'envelope':str(ep),'work_cutoff':cut.isoformat()},indent=2)+'\n')
(H/'TASK.md').write_text(f'''# Fresh logged canonical attempt

Agent-role mechanical, economy/low effort; fresh context, no children. Exclusive live project writer; root is READ_ONLY until actual FINAL and closure. Source {head}. Read CLAUDE.md, pcb-design skill and supplied runner. Execute exactly:

/usr/bin/python3 -B {H}/runner.py

This prebuilt runner verifies frozen inputs and absence of the already-retired guards, runs native qualification, one normal conductor, and only the precise expected fresh J-PCBA-PRELAYOUT rc2 pause permits one public continuation. All subprocesses use bounded runtime and preserve complete raw stdout/stderr, actualargv/cwd/rc/times in allocated scratch AND required execution.log/execution.json. It stops at the first other gate. Do not edit the runner or source, repeat it, delete/restore guards, route, alter reviews, commit or substitute ad hoc commands.

Fresh source correction changes only historical superseded TPS7A9201DSKR escape.tier_required from standard to advanced to match the unchanged owning package model. Current U_LDO remains LT3041, current project fabrication tier alreadyadvanced. No installed component, electrical/TSX/rules/pad/labelgeometry change. Original P-ESC87dossiers/1failure retained; corrected exact owning check and fresh source review accepted before dispatch. Prior full placement4/4PASS/nativeef72 and LAYOUT001 closure remain historical accepted pre-change evidence; the all-part/checkpoint census makes downstream source bindings stale, so renew normally without review restamps or ignored inputs. Outgoing five guards/six companions preserved in c60aec968cc6667c05f08bc15ec86ef4c7e63aa8fd3c27b7b7bc39519d2a2c89. Existing LAYOUT001 allthree spent attempts/history unchanged and closed by accepted source backtrack, no fourth diagnostic or route authority from this run. Source frozen; one normal run only.

After runner returns, inspect report, execution.json and tail of execution.log. Do not diagnose or fix unexpected engineering gates. Run mandatory delivery/writer preflight:
/usr/bin/python3 -B {H}/preflight.py {ep}

Deliver actual FINAL with exact last gate, childrc/duration and outputpaths. Runner creates required report.md,evidence.json,execution.log,execution.json,result.json. If runner itself fails, retain actual outputs and report INCOMPLETE; never fabricate a log/check. You may correct packaging only if source/runtime facts are retained; no change to original runtime/runner evidence. Work/FINAL cutoff{cut.isoformat()}, hardclose{hard.isoformat()}; reserve2minutes for preflight. Finish promptly after the first real gate. Send progress when the real run starts or stops.
''')
sources={R/key.removeprefix('repo:') for key in authored_census(P,R,[])}
for n in ['CLAUDE.md','skills/pcb-design/SKILL.md','skills/pcb-design/references/execution-runtime.md','skills/pcb-design/references/lifecycle-and-backtrack.md','skills/pcb-design/references/compute-tiers.md']:sources.add(R/n)
index={};inputs=[]
for p in sorted(sources):
 b=p.read_bytes();index[str(p)]=hashlib.sha256(b).hexdigest()
 if p.is_relative_to(P):inputs.append(p)
 else:
  target=H/'shared-source'/p.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
(H/'source-index.json').write_text(json.dumps(index,indent=2)+'\n');inputs.extend(p for p in H.rglob('*') if p.is_file());items=[]
for p in sorted(set(inputs)):
 b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(P).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
subject=subject_identity('escape_canonical_renewal',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())]);scope=sorted(['01_docs/STATUS.md','01_docs/journal/placement.md','03_tscircuit/build','03_tscircuit/dist','03_tscircuit/kicad','03_tscircuit/node_modules','03_tscircuit/verification','04_kicad','06_build'])
e=TaskEnvelope(schema=2,task_id=rid,stage_id='KICAD-SCHEMATIC',run_id=rid,subject=subject,executor='agent',execution_class='local',recommended_agent_role='mechanical',agent_role='mechanical',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=rid,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'EXCLUSIVE','paths':scope},output_path=f'06_build/task_runs/{rid}/attempt.json',completion={'outputs':sorted(['report.md','evidence.json','execution.log','execution.json']),'checks':sorted(['inputs-verified','raw-run-recorded','processes-closed'])})
o=open_agent_attempt(e,cwd=P);o.update(project=str(P),envelope=str(ep),task=str(H/'TASK.md'),preflight=str(H/'preflight.py'),work_cutoff=cut.isoformat(),agent_id='/root/carrier_escape_canonical');Path('/tmp/carrier-escape-canonical-opened.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2))
