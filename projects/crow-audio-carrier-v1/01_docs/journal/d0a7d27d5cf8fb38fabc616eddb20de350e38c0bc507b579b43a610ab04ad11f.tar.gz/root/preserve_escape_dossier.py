from pathlib import Path
import json,hashlib,tarfile,io,subprocess,shutil,sys
sys.dont_write_bytecode=True
D=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet
j=json.loads((D/'escape-dossier-review-opened.json').read_text())[0];root=Path(j['project']);A=Path(j['attempt']).parent;O=Path(j['output_dir']);a=json.loads((A/'attempt.json').read_text());e=TaskEnvelope.from_json(Path(j['envelope']).read_text());sha=lambda b:hashlib.sha256(b).hexdigest();assert a['status']=='PASS' and verify_input_packet(e,root)[0]
files={'packet/'+x.path:root/x.path for x in e.input_packet}
for p in A.rglob('*'):
 if p.is_file():files['runtime/'+p.relative_to(A).as_posix()]=p
for n in ['preserve_escape_dossier.py','escape-dossier-review-reopening.json','escape-source-adoption.json','retire_escape_guards.py','commission_escape_canonical.py','escape_canonical_runner.py']:
 files['root/'+n]=D/n
for prefix in ['escape-source-', 'owned-layout-present-contracts']:
 for p in Path('/tmp/carrier-connector-integration-20260911').glob(prefix+'*'):
  if p.is_file():files['root/validation/'+p.name]=p
members={n:{'size':p.stat().st_size,'sha256':sha(p.read_bytes())} for n,p in files.items()};tmp=D/'escape-dossier-accepted.tar.gz'
with tarfile.open(tmp,'w:gz',compresslevel=3) as t:
 for n,p in files.items():t.add(p,arcname=n,recursive=False)
 b=(json.dumps({'members':members},indent=2)+'\n').encode();m=tarfile.TarInfo('MANIFEST.json');m.size=len(b);t.addfile(m,io.BytesIO(b))
h=sha(tmp.read_bytes());out=P/'01_docs/journal'/(h+'.tar.gz');assert not out.exists();shutil.copyfile(tmp,out)
with tarfile.open(out) as t:
 assert len(t.getnames())==len(members)+1 and set(t.getnames())==set(members)|{'MANIFEST.json'}
 assert all(x.isfile() and not Path(x.name).is_absolute() and '..' not in Path(x.name).parts for x in t.getmembers())
 for n,m in members.items():b=t.extractfile(n).read();assert len(b)==m['size'] and sha(b)==m['sha256']
with (P/'01_docs/journal/contracts.md').open('a') as f:f.write(f'\n## Allowed historical escape dossier correction\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Exact historical TPS7A9201 escape-tier correction, fresh source review and complete frozen/runtime evidence, original failing preflight, root adoption and required renewal preparation; no board or fabrication-tier change |\n')
result={'archive':str(out),'sha256':h,'size':out.stat().st_size,'members':len(members),'inputs':len(e.input_packet)};(D/'escape-dossier-preservation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
