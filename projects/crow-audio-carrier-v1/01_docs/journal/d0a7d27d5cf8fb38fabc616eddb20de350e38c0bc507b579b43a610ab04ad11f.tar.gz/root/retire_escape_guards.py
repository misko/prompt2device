from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,tarfile,subprocess
D=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';sha=lambda b:hashlib.sha256(b).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R).strip(),'require committed source and evidence'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
h='c60aec968cc6667c05f08bc15ec86ef4c7e63aa8fd3c27b7b7bc39519d2a2c89';path=P/'01_docs/journal'/(h+'.tar.gz');assert sha(path.read_bytes())==h
retired=[]
with tarfile.open(path) as t:
 doc=json.load(t.extractfile('MANIFEST.json'));members=doc['members'];assert set(t.getnames())==set(members)|{'MANIFEST.json'}
 for n,row in members.items():
  b=t.extractfile(n).read();assert sha(b)==row['sha256'] and len(b)==row['size'],n
 old=json.load(t.extractfile('06_build/checkpoints/prelayout-inputs.json'))
 for key in old['explicit']:
  p=R/key.removeprefix('repo:');assert sha(p.read_bytes())==old['files'][key]['sha256'],key
 for n in doc['guard_paths']:
  p=P/n;assert not p.is_symlink()
  if n in doc['absent_guard_paths']:assert not p.exists(),n
  else:
   row=members[n];b=p.read_bytes();assert len(b)==row['size'] and sha(b)==row['sha256'],n;retired.append(dict(path=n,**row))
# Delete only the complete prevalidated stale generated guard set.
for row in retired:(P/row['path']).unlink()
r={'time':datetime.now(timezone.utc).isoformat(),'source_commit':head,'archive_sha256':h,'retired':retired,'absent':doc['absent_guard_paths'],'companion_count':len(old['explicit']),'authorization':'Accepted historical TPS7A9201 escape dossier correction and original finish/release goal; exact archived stale guards retired for one normal regeneration, no restamping.'}
(D/'escape-guard-retirement.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
