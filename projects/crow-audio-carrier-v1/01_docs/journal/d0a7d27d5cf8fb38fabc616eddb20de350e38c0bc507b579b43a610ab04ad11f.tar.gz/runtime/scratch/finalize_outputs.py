#!/usr/bin/python3
from __future__ import annotations

import hashlib
import json
import re
import sys
import tarfile
from pathlib import Path

PACKET = Path("/tmp/carrier-escape-dossier-review-vxmmen_1")
RUN = PACKET / "06_build/task_runs/escape-dossier-review"
SCRATCH = RUN / "scratch"
OUTPUTS = RUN / "outputs"
WORKTREE = Path("/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901")
PROJECT = PACKET / "current/projects/crow-audio-carrier-v1"
sys.path.insert(0, str(WORKTREE / "skills/pcb-design/scripts"))
from pipeline_runtime import run_stage


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def runtime(name: str) -> dict:
    return json.loads((SCRATCH / f"{name}.runtime.json").read_text())


after = run_stage(
    {"id": "input-after", "work_class": "local", "timeout_s": 120, "produces": []},
    ["/usr/bin/python3", "-B", str(SCRATCH / "analyze_packet.py"), "--phase", "after"],
    log_path=SCRATCH / "input-after.log", cwd=PACKET,
    heartbeat_s=10, console_line_limit=10, console_tail_lines=5,
)
(SCRATCH / "input-after.runtime.json").write_text(
    json.dumps(after.to_mapping(), indent=2, sort_keys=True) + "\n")
if after.returncode != 0:
    raise SystemExit("post-review input verification failed")
analysis = json.loads((SCRATCH / "input-after.log").read_text())

report = OUTPUTS / "report.md"
header_lines = []
for line in report.read_text().splitlines():
    if line.startswith("## "):
        break
    header_lines.append(line)
field_re = re.compile(r"^([a-z][a-z0-9_-]*):\s*(.+)$")
pairs = [field_re.match(line).groups() for line in header_lines if field_re.match(line)]
names = [name for name, _ in pairs]
duplicates = sorted({name for name in names if names.count(name) > 1})
required = {
    "subject", "date", "reviewer", "context-given", "source_commit",
    "review_stage", "review_kind", "review_scope", "board_sha256",
    "parts_sha256", "proposed_parts_sha256", "partial_packet_rules_sha256",
    "design_verdict", "order_verdict", "completed_at", "task_identity",
    "envelope_sha256", "reviewer_id", "reviewer_provenance",
    "raw_subject_sha256", "semantic_subject_sha256", "input_coverage",
    "part_declaration_coverage", "original_escape_outcome",
    "proposed_escape_outcome", "correction_field_count", "correction_field",
    "correction_old_value", "correction_new_value", "current_board_fab_tier",
    "current_native_tps7a92_occurrences", "current_native_lt3041_occurrences",
    "blocking_finding_ids",
}
missing = sorted(required - set(names))
unexpected_canonical_digest = "design_rules_sha256" in names
header_check = {
    "schema": 1,
    "status": "PASS" if not duplicates and not missing and not unexpected_canonical_digest else "FAIL",
    "field_count": len(names),
    "duplicates": duplicates,
    "required_count": len(required),
    "missing_required": missing,
    "canonical_design_rules_digest_omitted": not unexpected_canonical_digest,
    "reason": "Packet lacks all contributors required for the canonical owning design_rules_digest; partial packet value is explicitly scoped.",
}
(SCRATCH / "report-header-validation.json").write_text(
    json.dumps(header_check, indent=2, sort_keys=True) + "\n")
if header_check["status"] != "PASS":
    raise SystemExit(f"report header validation failed: {header_check}")

initial = json.loads((SCRATCH / "command-index.json").read_text())["commands"]
commands = list(initial)
commands.extend([
    {
        "name": "input-before-r2",
        "argv": ["/usr/bin/python3", "-B", str(SCRATCH / "analyze_packet.py"), "--phase", "before"],
        "cwd": str(PACKET), "runtime": runtime("input-before-r2"),
    },
    {
        "name": "datasheet-pages",
        "argv": ["/usr/bin/pdftoppm", "-f", "30", "-l", "33", "-r", "180", "-png",
                 str(PROJECT / "02_parts/TPS7A9201DSKR/TPS7A92_SBVS318B.pdf"), str(SCRATCH / "tps7a92-package")],
        "cwd": str(PACKET), "runtime": runtime("datasheet-pages"),
    },
    {
        "name": "datasheet-montage",
        "argv": ["/usr/bin/montage", str(SCRATCH / "tps7a92-package-30.png"),
                 str(SCRATCH / "tps7a92-package-31.png"), str(SCRATCH / "tps7a92-package-32.png"),
                 str(SCRATCH / "tps7a92-package-33.png"), "-tile", "2x2", "-geometry",
                 "1200x1600+8+8", str(SCRATCH / "tps7a92-package-montage.png")],
        "cwd": str(PACKET), "runtime": runtime("datasheet-montage"),
    },
    {
        "name": "input-after",
        "argv": ["/usr/bin/python3", "-B", str(SCRATCH / "analyze_packet.py"), "--phase", "after"],
        "cwd": str(PACKET), "runtime": after.to_mapping(),
    },
])
for command in commands:
    log_path = Path(command["runtime"]["log_path"])
    command["log"] = {"path": str(log_path.relative_to(SCRATCH)), "size": log_path.stat().st_size, "sha256": sha(log_path)}

evidence = {
    "schema": 1,
    "subject": analysis["envelope"]["subject"],
    "task": {
        "task_id": "escape-dossier-review", "run_id": "escape-dossier-review",
        "input_handoff_id": "escape-dossier-review", "stage_id": "KICAD-PLACEMENT",
        "agent_role": "judgment", "context_mode": "FRESH", "writer_scope": "READ_ONLY",
    },
    "provenance": {
        "envelope_sha256": analysis["envelope"]["canonical_sha256"],
        "envelope_file_sha256": analysis["envelope"]["raw_file_sha256"],
        "frozen_packet_source_commit": "d70fbd108ad1fbfe9aef82a7752c7c31b10ed85c",
        "observed_worktree_head_after_packet": "34745dd2c5b4ffc8fc8cc2a5e1c23fafb59882b5",
        "worktree_head_scope": "Recorded only as runtime environment identity; it does not restamp the frozen packet.",
    },
    "input_verification": {
        "before": json.loads((SCRATCH / "input-before-r2.log").read_text())["input_verification"],
        "after": analysis["input_verification"],
    },
    "actual_coverage": {
        "part_declarations": "87/87 current and 87/87 proposed-substitution graded",
        "current_failures": 1,
        "proposed_failures": 0,
        "proposal_semantic_leaf_differences": analysis["proposal"]["semantic_leaf_difference_count"],
        "proposal_difference": analysis["proposal"]["semantic_leaf_differences"],
        "current_board_and_schematic_tps7a92_occurrences": 0,
        "current_board_and_schematic_lt3041_occurrences": 12,
        "rendered_primary_pdf_pages": [30, 31, 32, 33],
        "inspected_primary_pdf_pages": [30, 31, 32, 33],
    },
    "engineering": {
        "design_verdict": "SOUND",
        "order_verdict": "DO-NOT-ORDER",
        "minimal_change": {"path": "escape.tier_required", "from": "jlc_4layer_standard", "to": "jlc_4layer_advanced"},
        "current_parts_sha256": analysis["population"]["parts_sha256_current"],
        "proposed_parts_sha256": analysis["population"]["parts_sha256_proposed"],
        "board_sha256": analysis["current_design"]["board_sha256"],
        "current_fab_tier": analysis["current_design"]["fab_tier"],
        "partial_packet_rules_sha256": analysis["current_design"]["design_rules_sha256"],
        "partial_digest_scope": "Not the canonical design_rules_sha256: the read-only packet omits owning contributors such as route/floorplan context.",
        "superseded_and_absent": {
            "dossier_status": "superseded", "adr_selects_lt3041": analysis["current_design"]["adr_lt3041_selected"],
            "pcb_tps_occurrences": analysis["current_design"]["pcb_tps7a92_occurrences"],
            "schematic_tps_occurrences": analysis["current_design"]["schematic_tps7a92_occurrences"],
        },
        "downstream_invalidation": "The all-part digest changes; all canonical reviews/checkpoints that bind it require owning renewal. No in-place restamp, waiver, route change, or guard retirement is admitted.",
    },
    "visual_inspection": json.loads((SCRATCH / "visual-inspection.json").read_text()),
    "report_header_validation": header_check,
    "commands": commands,
    "execution_exceptions": [
        {
            "name": "input-before", "disposition": "Initial helper called a nonexistent TaskEnvelope.sha256 method; full original log retained. Corrected to owning envelope_sha256 API and rerun PASS in the same attempt."
        },
        {
            "name": "datasheet-montage", "disposition": "Optional /usr/bin/montage executable was absent; full runtime receipt retained. Four page PNGs had already rendered successfully and were each inspected directly."
        },
        {
            "name": "source-commit", "disposition": "Returned the worktree HEAD after packet creation. Frozen packet provenance remains d70fbd10; the observed HEAD is not used to restamp it."
        },
    ],
    "delivery": {"status": "COMPLETE", "unresolved": []},
}
(OUTPUTS / "evidence.json").write_text(json.dumps(evidence, indent=2, sort_keys=True) + "\n")

result = {
    "subject": analysis["envelope"]["subject"],
    "checks": {"evidence-complete": "PASS", "inputs-verified": "PASS", "review-complete": "PASS"},
    "unresolved": [],
}
(OUTPUTS / "result.json").write_text(json.dumps(result, separators=(",", ":")) + "\n")

archive = OUTPUTS / "evidence.tar.gz"
sources: list[tuple[Path, str]] = []
for path in sorted(SCRATCH.rglob("*")):
    if path.is_file():
        sources.append((path, "scratch/" + path.relative_to(SCRATCH).as_posix()))
for name in ("report.md", "evidence.json", "result.json"):
    sources.append((OUTPUTS / name, "outputs/" + name))
with tarfile.open(archive, "w:gz") as tar:
    for path, arcname in sources:
        tar.add(path, arcname=arcname, recursive=False)

members = [{"path": arcname, "size": path.stat().st_size, "sha256": sha(path)} for path, arcname in sources]
with tarfile.open(archive, "r:gz") as tar:
    actual_names = tar.getnames()
if actual_names != [member["path"] for member in members]:
    raise SystemExit("archive membership/order mismatch")
manifest = {
    "schema": 1,
    "archive": {"path": "evidence.tar.gz", "size": archive.stat().st_size, "sha256": sha(archive)},
    "member_count": len(members),
    "members": members,
}
(OUTPUTS / "evidence-manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
print(json.dumps({"header": header_check, "archive": manifest["archive"], "members": len(members)}, sort_keys=True))
