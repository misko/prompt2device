#!/usr/bin/python3
from __future__ import annotations

import json
import sys
from pathlib import Path

PACKET = Path("/tmp/carrier-escape-dossier-review-vxmmen_1")
SCRATCH = PACKET / "06_build/task_runs/escape-dossier-review/scratch"
WORKTREE = Path("/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901")
PROJECT = PACKET / "current/projects/crow-audio-carrier-v1"
sys.path.insert(0, str(WORKTREE / "skills/pcb-design/scripts"))
from pipeline_runtime import run_stage


def spec(name: str, seconds: int = 120) -> dict[str, object]:
    return {"id": name, "work_class": "local", "timeout_s": seconds, "produces": []}


def run(name: str, argv: list[str], cwd: Path = PACKET, seconds: int = 120) -> dict[str, object]:
    outcome = run_stage(
        spec(name, seconds), argv,
        log_path=SCRATCH / f"{name}.log", cwd=cwd,
        heartbeat_s=10, console_line_limit=40, console_tail_lines=15,
    )
    mapping = outcome.to_mapping()
    (SCRATCH / f"{name}.runtime.json").write_text(json.dumps(mapping, indent=2, sort_keys=True) + "\n")
    return mapping


def main() -> int:
    python = "/usr/bin/python3"
    checker = PACKET / "current/skills/kicad-pcb/scripts/escape_check.py"
    parts = sorted((PROJECT / "02_parts").glob("*/part.yaml"))
    proposed = PACKET / "proposed-part.yaml"
    original = PROJECT / "02_parts/TPS7A9201DSKR/part.yaml"
    proposed_population = [proposed if p == original else p for p in parts]
    commands = [
        ("input-before", [python, "-B", str(SCRATCH / "analyze_packet.py"), "--phase", "before"], PACKET, 120),
        ("escape-current-87", [python, "-B", str(checker), *map(str, parts)], PACKET, 120),
        ("escape-proposed-87", [python, "-B", str(checker), *map(str, proposed_population)], PACKET, 120),
        ("escape-current-tps", [python, "-B", str(checker), str(original)], PACKET, 60),
        ("escape-proposed-tps", [python, "-B", str(checker), str(proposed)], PACKET, 60),
        ("escape-dfn-model", [python, "-B", str(checker), "--style", "dfn", "--pitch", "0.5"], PACKET, 60),
        ("proposal-diff", ["/usr/bin/diff", "-u", str(original), str(proposed)], PACKET, 60),
        ("source-commit", ["/usr/bin/git", "rev-parse", "HEAD"], WORKTREE, 60),
        ("datasheet-text", ["/usr/bin/pdftotext", "-layout", str(PROJECT / "02_parts/TPS7A9201DSKR/TPS7A92_SBVS318B.pdf"), str(SCRATCH / "TPS7A92_SBVS318B.txt")], PACKET, 60),
    ]
    outcomes = []
    for name, argv, cwd, seconds in commands:
        outcomes.append({"name": name, "argv": argv, "cwd": str(cwd), "runtime": run(name, argv, cwd, seconds)})
    (SCRATCH / "command-index.json").write_text(json.dumps({"schema": 1, "commands": outcomes}, indent=2, sort_keys=True) + "\n")
    expected_rc = {
        "input-before": 0,
        "escape-current-87": 1,
        "escape-proposed-87": 0,
        "escape-current-tps": 1,
        "escape-proposed-tps": 0,
        "escape-dfn-model": 0,
        "proposal-diff": 1,
        "source-commit": 0,
        "datasheet-text": 0,
    }
    errors = [x["name"] for x in outcomes if x["runtime"]["returncode"] != expected_rc[x["name"]]]
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
