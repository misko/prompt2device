#!/usr/bin/python3
from __future__ import annotations

import json
import sys
from pathlib import Path

PACKET = Path("/tmp/carrier-escape-dossier-review-vxmmen_1")
SCRATCH = PACKET / "06_build/task_runs/escape-dossier-review/scratch"
WORKTREE = Path("/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901")
sys.path.insert(0, str(WORKTREE / "skills/pcb-design/scripts"))
from pipeline_runtime import run_stage

outcome = run_stage(
    {"id": "input-before-r2", "work_class": "local", "timeout_s": 120, "produces": []},
    ["/usr/bin/python3", "-B", str(SCRATCH / "analyze_packet.py"), "--phase", "before"],
    log_path=SCRATCH / "input-before-r2.log", cwd=PACKET,
    heartbeat_s=10, console_line_limit=10, console_tail_lines=5,
)
(SCRATCH / "input-before-r2.runtime.json").write_text(
    json.dumps(outcome.to_mapping(), indent=2, sort_keys=True) + "\n")
raise SystemExit(0 if outcome.returncode == 0 else 1)
