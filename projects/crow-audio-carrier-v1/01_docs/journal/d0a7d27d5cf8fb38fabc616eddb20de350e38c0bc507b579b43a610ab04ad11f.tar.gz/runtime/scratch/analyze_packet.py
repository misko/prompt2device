#!/usr/bin/python3
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

import yaml

PACKET = Path("/tmp/carrier-escape-dossier-review-vxmmen_1")
WORKTREE = Path("/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901")
PROJECT = PACKET / "current/projects/crow-audio-carrier-v1"
ENVELOPE = PACKET / "06_build/task_runs/escape-dossier-review/envelope.json"


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def leaf_differences(a: object, b: object, prefix: str = "") -> list[dict[str, object]]:
    if isinstance(a, dict) and isinstance(b, dict):
        out: list[dict[str, object]] = []
        for key in sorted(set(a) | set(b)):
            path = f"{prefix}.{key}" if prefix else str(key)
            if key not in a:
                out.append({"path": path, "original": None, "proposed": b[key]})
            elif key not in b:
                out.append({"path": path, "original": a[key], "proposed": None})
            else:
                out.extend(leaf_differences(a[key], b[key], path))
        return out
    if isinstance(a, list) and isinstance(b, list):
        out = []
        for index in range(max(len(a), len(b))):
            path = f"{prefix}[{index}]"
            if index >= len(a):
                out.append({"path": path, "original": None, "proposed": b[index]})
            elif index >= len(b):
                out.append({"path": path, "original": a[index], "proposed": None})
            else:
                out.extend(leaf_differences(a[index], b[index], path))
        return out
    return [] if a == b else [{"path": prefix, "original": a, "proposed": b}]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase", choices=("before", "after"), required=True)
    args = ap.parse_args()

    envelope_doc = json.loads(ENVELOPE.read_text())
    sys.path.insert(0, str(WORKTREE / "skills/pcb-design/scripts"))
    from pipeline_execution import TaskEnvelope, envelope_sha256
    envelope = TaskEnvelope.from_json(ENVELOPE.read_text())
    canonical_envelope_sha = envelope_sha256(envelope)

    verification = []
    failures = []
    for item in envelope_doc["input_packet"]:
        path = PACKET / item["path"]
        actual = {
            "name": item["name"],
            "path": item["path"],
            "exists": path.is_file(),
            "expected_size": item["size"],
            "actual_size": path.stat().st_size if path.is_file() else None,
            "expected_sha256": item["sha256"],
            "actual_sha256": sha(path) if path.is_file() else None,
        }
        actual["status"] = "PASS" if (
            actual["exists"] and actual["actual_size"] == actual["expected_size"]
            and actual["actual_sha256"] == actual["expected_sha256"]
        ) else "FAIL"
        verification.append(actual)
        if actual["status"] != "PASS":
            failures.append(actual)

    parts = sorted((PROJECT / "02_parts").glob("*/part.yaml"))
    current_path = PROJECT / "02_parts/TPS7A9201DSKR/part.yaml"
    proposed_path = PACKET / "proposed-part.yaml"
    current_doc = yaml.safe_load(current_path.read_text())
    proposed_doc = yaml.safe_load(proposed_path.read_text())
    differences = leaf_differences(current_doc, proposed_doc)

    sys.path.insert(0, str(PACKET / "current/skills/kicad-pcb/scripts"))
    import pre_route_review_check
    rules_sha = pre_route_review_check.design_rules_digest(PROJECT)
    parts_sha = hashlib.sha256(b"".join(
        p.relative_to(PROJECT).as_posix().encode() + b"\0" + p.read_bytes() + b"\0"
        for p in parts
    )).hexdigest()
    proposed_parts_sha = hashlib.sha256(b"".join(
        p.relative_to(PROJECT).as_posix().encode() + b"\0"
        + (proposed_path.read_bytes() if p == current_path else p.read_bytes()) + b"\0"
        for p in parts
    )).hexdigest()

    pcb = PROJECT / "04_kicad/crow_audio_carrier_v1.kicad_pcb"
    sch = PROJECT / "04_kicad/crow_audio_carrier_v1.kicad_sch"
    pcb_text = pcb.read_text(errors="replace")
    sch_text = sch.read_text(errors="replace")
    nets_doc = yaml.safe_load((PROJECT / "03_src/rules/nets.yaml").read_text())
    adr = (PROJECT / "01_docs/decisions/0025-shared-rail-protection-architecture.md").read_text()
    original_log = (PACKET / "owned-placement-preflight.log").read_text(errors="replace")

    tier_counts: dict[str, int] = {}
    status_counts: dict[str, int] = {}
    for path in parts:
        doc = yaml.safe_load(path.read_text()) or {}
        tier = ((doc.get("escape") or {}).get("tier_required"))
        tier_counts[str(tier)] = tier_counts.get(str(tier), 0) + 1
        status = str(doc.get("status"))
        status_counts[status] = status_counts.get(status, 0) + 1

    result = {
        "schema": 1,
        "phase": args.phase,
        "input_verification": {
            "status": "PASS" if not failures else "FAIL",
            "verified": len(verification) - len(failures),
            "total": len(verification),
            "failures": failures,
            "entries": verification,
        },
        "envelope": {
            "canonical_sha256": canonical_envelope_sha,
            "raw_file_sha256": sha(ENVELOPE),
            "subject": envelope_doc["subject"],
        },
        "proposal": {
            "current_sha256": sha(current_path),
            "proposed_sha256": sha(proposed_path),
            "semantic_leaf_difference_count": len(differences),
            "semantic_leaf_differences": differences,
            "byte_size_equal": current_path.stat().st_size == proposed_path.stat().st_size,
        },
        "population": {
            "part_declarations": len(parts),
            "tier_counts_current": tier_counts,
            "status_counts": status_counts,
            "parts_sha256_current": parts_sha,
            "parts_sha256_proposed": proposed_parts_sha,
        },
        "current_design": {
            "fab_tier": nets_doc.get("fab_tier"),
            "board_sha256": sha(pcb),
            "schematic_sha256": sha(sch),
            "design_rules_sha256": rules_sha,
            "pcb_tps7a92_occurrences": len(re.findall(r"TPS7A92(?:01DSKR)?", pcb_text, re.I)),
            "schematic_tps7a92_occurrences": len(re.findall(r"TPS7A92(?:01DSKR)?", sch_text, re.I)),
            "pcb_lt3041_occurrences": len(re.findall(r"LT3041", pcb_text, re.I)),
            "schematic_lt3041_occurrences": len(re.findall(r"LT3041", sch_text, re.I)),
            "adr_tps_superseded": "supersed" in adr.lower() and "TPS7A92" in adr,
            "adr_lt3041_selected": "LT3041" in adr,
        },
        "original_preflight": {
            "escape_failure_lines": [line for line in original_log.splitlines() if line.startswith("FAIL TPS7A9201DSKR:")],
            "escape_summary_lines": [line for line in original_log.splitlines() if line.startswith("P-ESC ")],
            "placement_review_pass": "PR-REVIEW PASS (placement)" in original_log,
            "escape_packages_rc_1": "[escape_packages] rc=1" in original_log,
        },
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
