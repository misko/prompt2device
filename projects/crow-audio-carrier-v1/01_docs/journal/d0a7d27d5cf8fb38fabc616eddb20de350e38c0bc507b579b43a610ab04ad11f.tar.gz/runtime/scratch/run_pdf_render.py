#!/usr/bin/python3
from __future__ import annotations

import json
import sys
from pathlib import Path

PACKET = Path("/tmp/carrier-escape-dossier-review-vxmmen_1")
SCRATCH = PACKET / "06_build/task_runs/escape-dossier-review/scratch"
WORKTREE = Path("/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901")
PDF = PACKET / "current/projects/crow-audio-carrier-v1/02_parts/TPS7A9201DSKR/TPS7A92_SBVS318B.pdf"
sys.path.insert(0, str(WORKTREE / "skills/pcb-design/scripts"))
from pipeline_runtime import run_stage


def execute(name: str, argv: list[str]) -> None:
    outcome = run_stage(
        {"id": name, "work_class": "local", "timeout_s": 120, "produces": []},
        argv, log_path=SCRATCH / f"{name}.log", cwd=PACKET,
        heartbeat_s=10, console_line_limit=20, console_tail_lines=10,
    )
    (SCRATCH / f"{name}.runtime.json").write_text(
        json.dumps(outcome.to_mapping(), indent=2, sort_keys=True) + "\n")
    if outcome.returncode != 0:
        raise SystemExit(1)


execute("datasheet-pages", [
    "/usr/bin/pdftoppm", "-f", "30", "-l", "33", "-r", "180", "-png",
    str(PDF), str(SCRATCH / "tps7a92-package")
])
execute("datasheet-montage", [
    "/usr/bin/montage",
    str(SCRATCH / "tps7a92-package-30.png"),
    str(SCRATCH / "tps7a92-package-31.png"),
    str(SCRATCH / "tps7a92-package-32.png"),
    str(SCRATCH / "tps7a92-package-33.png"),
    "-tile", "2x2", "-geometry", "1200x1600+8+8",
    str(SCRATCH / "tps7a92-package-montage.png")
])
