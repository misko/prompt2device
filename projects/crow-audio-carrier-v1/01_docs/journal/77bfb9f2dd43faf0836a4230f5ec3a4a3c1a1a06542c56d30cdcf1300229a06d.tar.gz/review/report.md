# RJ45 carrier first placement — stopped at P-ADJ-PAIR

The single authorized normal checkpoint continuation generated a fresh RJ45 PCB and stopped at `[4c] P-ADJ`, return code **1**, runtime **19.580 s** (outer **19.723 s**, no timeout). Eight fuse/connector power-pad gaps failed: F1.2→J1.1 through F8.2→J8.1 on12V_POD1..8 each measure **8.84 mm against4.5 mm**, exceeding the limit by4.34 mm. All eight exact subjects and the full native policy report are preserved.

All636frozen inputs,453protected live source/method preimages, exact schematic checkpoint and prelaunch canonical handoff verified. Actual project scope was snapshotted before execution; no prelaunch differences. Final EXCLUSIVE writer scope PASS; no protected-source edits. No retry or git operation. The placement beacon and journal now record this gate.

S-COUNT333/333 components, spoke8/8, P-PINMAP47multi-pin refs/411physical identities, models333/333 and PADSEP PASS. Placement feasibility7/7PASS-or-NA comprises fivePASS/twoNA; keep_short62/62PASS and all415/415declared budgets resolve. These are individual gate results, not independent layout acceptance.

PCB SHA256: `73bdcc6f4d625973d98a591537d599f037a2fedf069fededabb482bd1fbe97e1`. Circuit SHA256: `cdf4a417923cba2a75a06db4c853473c4fe9690277523b1e3a5776aabd48233e`. Netlist SHA256: `184d040015ce6645aece04b3834f69c74f4f141ea9ebdbb1b4008f186515d3a9`. All exact output paths/hashes are in evidence.json and the archive manifest.

Fresh DRC and every later pipeline stage are NOT RUN: escape/tier, route preparation, orientation, independent placement review, route import/taps/stitch, final route acceptance, layout seal and release. The historical pre_route.json remains unchanged:0violations/499unconnected/0parity. Every one of its499nodes has an individual endpoint/net/cause classification plus raw node in evidence.json and scratch/drc-classification.json. Its historical open connections do not measure the new PCB. No gate.json existed at launch or was deleted. The compact placement handoff was generated and validated successfully without touching that stale historical report.

FIRST-ARTICLE-ONLY / DO-NOT-ORDER. FULL23physical obligations stay deferred; first-power card P2missing17refs remains the separate next source batch. LAYOUT001closed3/3 unchanged. Root owns closure/commit and the next source decision. Mechanical work is complete and writer ownership returns only with actual FINAL and owning closure.
