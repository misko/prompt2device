from pathlib import Path,PurePosixPath
import sys,json,hashlib,tarfile,re,datetime,collections
sys.dont_write_bytecode=True
P=Path.cwd(); R=P.parents[1]; T=P/'06_build/task_runs/rj45-carrier-first-placement'; S=T/'scratch'; O=T/'outputs'; O.mkdir(exist_ok=True)
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet,writer_scope_receipt
from pipeline_runtime import _tree_snapshot,_changed_paths,_snapshot_sha256
H=lambda b:hashlib.sha256(b).hexdigest()
def write(p,d): p.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
def rec(p): return {'path':str(p.relative_to(P)),'size':p.stat().st_size,'sha256':H(p.read_bytes())}
e=json.loads((T/'envelope.json').read_text()); E=TaskEnvelope.from_json((T/'envelope.json').read_text()); A=json.loads((T/'admission.json').read_text()); B=json.loads((S/'project-before.json').read_text()); C=_tree_snapshot(P,ignored=frozenset(A['ignored'])); changes=_changed_paths(B,C)
write(S/'project-final.json',C); write(S/'final-changed-paths.json',changes)
verified=verify_input_packet(E,P); assert verified[0]; write(S/'inputs-final.json',{'status':'PASS','count':len(e['input_packet']),'details':verified})
protected=json.loads((S/'protected-preimages.json').read_text()); mismatch=[k for k,v in protected.items() if not (R/k).is_file() or H((R/k).read_bytes())!=v]; assert not mismatch
write(S/'protected-final.json',{'status':'PASS','verified_count':len(protected),'mismatches':mismatch,'hashes':protected})
scope=writer_scope_receipt(E.writer_scope,_changed_paths(A['before'],C),before_sha256=_snapshot_sha256(A['before']),after_sha256=_snapshot_sha256(C),protected_paths=tuple(sorted((E.output_path,A['claim'])))); assert scope['status']=='PASS'; write(S/'scope-final.json',scope)
drc=P/'06_build/drc/pre_route.json'; d=json.loads(drc.read_text()); assert B[str(drc.relative_to(P))]==C[str(drc.relative_to(P))]
rows=[]
for kind in ['violations','unconnected_items','schematic_parity']:
 for i,node in enumerate(d[kind]):
  endpoints=[x['description'] for x in node.get('items',[])]; nets=sorted(set(re.findall(r'\[([^]]+)\]',' '.join(endpoints))))
  assert kind=='unconnected_items' and node['type']=='unconnected_items' and node['description']=='Missing connection between items'
  rows.append({'id':f'{kind}:{i+1:04d}','category':kind,'cause_class':'HISTORICAL_OPEN_CONNECTION','cause':'Historical DRC reports no conductive connection between '+ ' and '.join(endpoints)+'. This unchanged report predates the new RJ45 PCB; the current-board cause is NOT MEASURED.','nets':nets,'raw_node':node})
classification={'report':rec(drc),'historical':True,'date':d['date'],'unchanged_from_launch':True,'current_board_applicable':False,'counts':{k:len(d[k]) for k in ['violations','unconnected_items','schematic_parity']},'classified_count':len(rows),'rows':rows}; write(S/'drc-classification.json',classification)
failures=[{'part_mpn':'1812L035-60MR','ref_pair':[f'F{i}',f'J{i}'],'net':f'12V_POD{i}','pad_pair':[f'F{i}.2',f'J{i}.1'],'gap_mm':8.84,'maximum_mm':4.5,'excess_mm':4.34,'cause':'Entry fuse power pad is too far from the exact RJ45 power contact under the authored adjacency contract.'} for i in range(1,9)]
write(S/'placement-failure-subjects.json',failures)
subjects=[P/'03_tscircuit/build/circuit.json',P/'03_tscircuit/build/schematic.pdf',P/'03_tscircuit/manifest.yaml',P/'04_kicad/crow_audio_carrier_v1.kicad_sch',P/'04_kicad/crow_audio_carrier_v1.kicad_pcb',P/'06_build/netlists/crow_audio_carrier_v1.net',P/'03_src/floorplan.yaml',P/'03_src/route.yaml',P/'02_parts/1812L035-60MR/part.yaml',P/'06_build/checkpoints/schematic.json',T/'envelope.json',P/'06_build/handoffs/rj45-carrier-first-placement/TASK.md',drc]
for x in subjects: assert x.is_file() and not x.is_symlink()
not_run=['fresh pre-route DRC and placement_drc_check','escape/tier gates after placement policy','route preparation','model registration/orientation and independent placement reviews','route import','route taps','stitch','final route acceptance','layout seal','release','physical acceptance']
command=json.loads((S/'command.json').read_text()); runtime=json.loads((P/'06_build/pipeline_state/rj45_first_placement.json').read_text())
evidence={'schema':1,'task_id':e['task_id'],'subject':e['subject'],'envelope':rec(T/'envelope.json'),'delivery_result':'COMPLETE_HONEST_DELIVERY','domain_result':'BLOCKED_P_ADJ_PAIR','stopping_gate':'[4c] P-ADJ / P-ADJ-PAIR','command':command,'runtime':runtime,'input_verification':{'status':'PASS','frozen_inputs':636,'protected_preimages':453,'initial_project_changes':0},'scope':scope,'subjects':[rec(x) for x in subjects],'component_and_pin_coverage':{'component_refs':333,'source_pin_count':985,'source_net_count':221,'generated_spoke_connectors':8,'pinmap_multi_pin_refs':47,'declared_physical_pin_identities_graded':411,'model_fitted_footprints':333,'padsep_copper_pads':1009,'padsep_footprints_including_mechanical':340},'source_pin_count_basis':'Accepted frozen schematic handoff; P-PINMAP separately grades declared multi-pin physical identities.','placement_failure_subjects':failures,'placement_policy':rec(P/'06_build/placement_policy_audit.md'),'drc_classification':classification,'not_run':not_run,'handoff':{'generation':json.loads((S/'handoff-generation.json').read_text()),'validation':json.loads((S/'handoff-final-validation.json').read_text()),'artifact':rec(P/'06_build/agent_handoff.yaml')},'gate_json':{'present_before':False,'present_after':(P/'06_build/drc/gate.json').exists(),'deleted_by_agent':False},'limitations':['No source correction or retry performed.','LAYOUT001 closed3/3 unchanged; no fourth diagnostic.','First-power card missing17fittedrefs remains separate P2 next source batch.','Connector FULL23 physical obligations remain deferred; FIRST-ARTICLE-ONLY / DO-NOT-ORDER.','Historical DRC findings do not grade new PCB.'],'final_preflight_path':str(S/'provided-preflight-final.json')}
write(O/'evidence.json',evidence)
report=f'''# RJ45 carrier first placement — stopped at P-ADJ-PAIR

The single authorized normal checkpoint continuation generated a fresh RJ45 PCB and stopped at `[4c] P-ADJ`, return code **1**, runtime **19.580 s** (outer **19.723 s**, no timeout). Eight fuse/connector power-pad gaps failed: F1.2→J1.1 through F8.2→J8.1 on12V_POD1..8 each measure **8.84 mm against4.5 mm**, exceeding the limit by4.34 mm. All eight exact subjects and the full native policy report are preserved.

All636frozen inputs,453protected live source/method preimages, exact schematic checkpoint and prelaunch canonical handoff verified. Actual project scope was snapshotted before execution; no prelaunch differences. Final EXCLUSIVE writer scope PASS; no protected-source edits. No retry or git operation. The placement beacon and journal now record this gate.

S-COUNT333/333 components, spoke8/8, P-PINMAP47multi-pin refs/411physical identities, models333/333 and PADSEP PASS. Placement feasibility7/7PASS-or-NA comprises fivePASS/twoNA; keep_short62/62PASS and all415/415declared budgets resolve. These are individual gate results, not independent layout acceptance.

PCB SHA256: `{H((P/'04_kicad/crow_audio_carrier_v1.kicad_pcb').read_bytes())}`. Circuit SHA256: `{H((P/'03_tscircuit/build/circuit.json').read_bytes())}`. Netlist SHA256: `{H((P/'06_build/netlists/crow_audio_carrier_v1.net').read_bytes())}`. All exact output paths/hashes are in evidence.json and the archive manifest.

Fresh DRC and every later pipeline stage are NOT RUN: escape/tier, route preparation, orientation, independent placement review, route import/taps/stitch, final route acceptance, layout seal and release. The historical pre_route.json remains unchanged:0violations/499unconnected/0parity. Every one of its499nodes has an individual endpoint/net/cause classification plus raw node in evidence.json and scratch/drc-classification.json. Its historical open connections do not measure the new PCB. No gate.json existed at launch or was deleted. The compact placement handoff was generated and validated successfully without touching that stale historical report.

FIRST-ARTICLE-ONLY / DO-NOT-ORDER. FULL23physical obligations stay deferred; first-power card P2missing17refs remains the separate next source batch. LAYOUT001closed3/3 unchanged. Root owns closure/commit and the next source decision. Mechanical work is complete and writer ownership returns only with actual FINAL and owning closure.
'''
(O/'report.md').write_text(report)
write(O/'result.json',{'subject':e['subject'],'checks':{k:'PASS' for k in e['completion']['checks']},'unresolved':[]})
files={x for x in subjects}
for rel in changes:
 p=P/rel
 if p.is_file(): files.add(p)
for p in S.iterdir():
 if p.is_file() and p.name!='package.py': files.add(p)
# Capture exact stable feasibility bundle members used by this run even when regenerated bytes match.
for p in (P/'06_build/verification/pipeline/bundles/placement_feasibility').rglob('*'):
 if p.is_file(): files.add(p)
for p in [O/'report.md',O/'evidence.json',O/'result.json']: files.add(p)
archive=O/'evidence.tar.gz'
records=[]
with tarfile.open(archive,'w:gz') as tf:
 for p in sorted(files):
  assert p.is_file() and not p.is_symlink(); rel=str(p.relative_to(P)); assert rel!=str(archive.relative_to(P)); records.append(rec(p)); tf.add(p,arcname=rel,recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 members=tf.getmembers(); names=[m.name for m in members]; assert len(names)==len(set(names))==len(records)
 byname={x['path']:x for x in records}
 for m in members:
  pp=PurePosixPath(m.name); assert m.isfile() and not pp.is_absolute() and '..' not in pp.parts
  b=tf.extractfile(m).read(); assert len(b)==byname[m.name]['size'] and H(b)==byname[m.name]['sha256']
write(O/'evidence-manifest.json',{'schema':1,'archive_sha256':H(archive.read_bytes()),'archive_size':archive.stat().st_size,'member_count':len(records),'members':records,'verification':'All regular members independently reopened; no symlinks, duplicate paths, traversal or recursive archive.'})
print(json.dumps({'archive_sha256':H(archive.read_bytes()),'archive_size':archive.stat().st_size,'members':len(records),'scope':scope['status'],'changed_paths':len(changes),'drc_classified':len(rows)}))
