from pathlib import Path
import json,hashlib,tarfile,sys,os
S=Path(__file__).parent;P=S.parents[3];D=S.parent/'outputs';E=json.loads((S.parent/'envelope.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
verified=[]
for row in E['input_packet']:
 b=(P/row['path']).read_bytes();assert len(b)==row['size'] and sha(b)==row['sha256'];verified.append(row['path'])
(S/'inputs-after.json').write_text(json.dumps({'verified':len(verified),'paths':verified},indent=2))
hashes=json.loads((S/'hashes.json').read_text());counts=json.loads((S/'comparison.json').read_text());geometry=json.loads((S/'geometry.json').read_text())
headers={'review_stage':'pre-route','review_kind':'topology','reviewer_identity':'Codex /root/carrier_rj45_native_carrier_topology_none1','context':'FRESH','date':'2026-09-13','design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER',**hashes}
(D/'report.md').write_text('\n'.join(k+': '+v for k,v in headers.items())+'\n'+(S/'report-body.md').read_text())
evidence={'schema':1,'verdict':'SOUND','design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','subject':E['subject'],'subject_hashes':hashes,'review_stage':'pre-route','review_kind':'topology','context':'FRESH','input_verification':{'before':751,'after':len(verified)},'methods':['complete source/native identity and pin comparison','all-trace named-net union-find','fresh native schematic export','owning seven-hash recomputation for both subjects','205 maintained electrical invariants and7 ADR coverage','maintained native power/analog/clock screens','complete source return-mode/capsule and native-integer polygon population','19-page actual PDF raster equality and integrated human visual inspection'],'counts':{k:v for k,v in counts.items() if k not in ['narrow_ground','pad_modes']},'source_geometry':{k:v for k,v in geometry.items() if k!='west'},'findings':[],'limits':['Native6 PCB review is separate','23 locator exceptions remain conditional on current atlas/render acceptance','SOURCE PASS does not change FULL INCOMPLETE23','FIRST-ARTICLE-ONLY / DO-NOT-ORDER','No pod population or physical PCB claim']}
(D/'evidence.json').write_text(json.dumps(evidence,indent=2))
deps=[]
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
for path in [R/'skills/pcb-design/scripts/pipeline_runtime.py',R/'skills/kicad-pcb/scripts/generate_board_generic.py',R/'skills/kicad-pcb/scripts/kicad_sch_parity.py',R/'skills/kicad-pcb/scripts/electrical_invariants.py',Path('/usr/lib/python3/dist-packages/pcbnew.py')]:
 b=path.read_bytes();deps.append({'path':str(path),'size':len(b),'sha256':sha(b)})
(S/'external-method-dependencies.json').write_text(json.dumps(deps,indent=2))
selected=[p for p in S.iterdir() if p.is_file() and p.name not in ['package.py','package.log','package.runtime.json','preflight.log','preflight.runtime.json']]
selected+= [D/'report.md',D/'evidence.json'];members=[]
archive=D/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in sorted(selected):
  assert not p.is_symlink();name=('methods/' if p.parent==S else 'review/')+p.name;b=p.read_bytes();members.append({'path':name,'size':len(b),'sha256':sha(b)});tf.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 seen=set();actual=tf.getmembers();assert len(actual)==len(members)
 expected={m['path']:m for m in members}
 for m in actual:
  assert m.isfile() and m.name not in seen and not m.name.startswith('/') and '..' not in Path(m.name).parts and not m.name.endswith(('.tar','.tar.gz'));seen.add(m.name)
  b=tf.extractfile(m).read();assert len(b)==expected[m.name]['size'] and sha(b)==expected[m.name]['sha256']
manifest={'archive_sha256':sha(archive.read_bytes()),'archive_size':archive.stat().st_size,'member_count':len(members),'members':members}
(D/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2))
(D/'result.json').write_text(json.dumps({'subject':E['subject'],'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]},indent=2))
assert sorted(p.name for p in D.iterdir())==['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md','result.json']
print(json.dumps({'verdict':'SOUND','verified':len(verified),'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'members_reopened':len(members)},indent=2))
