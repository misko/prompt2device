from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,io,shutil,sys,importlib
from datetime import datetime,timezone
S=Path(__file__).parent;Q=S.parents[3];O=S.parent/'outputs';P=S/'repo/projects/crow-audio-carrier-v1';R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=json.loads((S.parent/'envelope.json').read_text());delta=json.loads((Q/'source-delta.json').read_text());subject=env['subject']
checks=[]
for x in env['input_packet']:
    f=Q/x['path'];checks.append({'path':x['path'],'sha256':H(f),'size':f.stat().st_size,'verified':H(f)==x['sha256'] and f.stat().st_size==x['size']})
assert len(checks)==430 and all(r['verified'] for r in checks)
(S/'raw/inputs-after.json').write_text(json.dumps(checks,indent=2))
# Actual entrypoints and imported shared modules used by proof and runtime.
sys.path[:0]=[str(R/'skills/pcb-design/scripts'),str(R/'skills/kicad-pcb/scripts'),str(P/'03_src/tests')]
for mod in ['pipeline_runtime','generate_board_generic','generate_rules_generic','placement_gates','policy_audit','test_ground_connections','test_local_placement_source','test_source_silkscreen','test_package_models','test_protection_architecture','test_rj45_entry_paths']:
    importlib.import_module(mod)
files={Path(m.__file__).resolve() for m in list(sys.modules.values()) if getattr(m,'__file__',None) and Path(m.__file__).is_file() and (str(Path(m.__file__).resolve()).startswith(str(R/'skills')) or str(Path(m.__file__).resolve()).startswith(str(P/'03_src')))}
files.add(R/'skills/kicad-pcb/scripts/placement_drc_check.py')
methods=[]
for f in sorted(files):
    rel='shared/'+str(f.relative_to(R)) if f.is_relative_to(R) else 'source_tests/'+str(f.relative_to(P))
    methods.append({'path':str(f),'archive_path':'methods/'+rel,'sha256':H(f),'size':f.stat().st_size})
(S/'raw/method-identities.json').write_text(json.dumps(methods,indent=2))
meas=json.loads((S/'raw/independent-measurements.json').read_text());model=json.loads((S/'raw/bottom-model-semantics.json').read_text())
report='''SOUND — source selection only. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.

This fresh review judges the exact frozen combined nine-file carrier source correction. It does not accept the schematic, placement, routes, assembly process, physical qualification or release. Earlier expired verdicts were not used as authority. No source edits, geometry variants, search, children or live writes were performed.

Exact subject: semantic `{semantic_sha256}`; raw `{raw_sha256}`.

The source census independently verifies 9 changed and 299 unchanged compared source files; all 430 frozen packet inputs match before and after. All nine before/after diffs were read. Changed files:

{census}

The exact F1–F8 source poses are preserved from the admitted frozen campaign. North fuses are at (32.2,31.4), (64.2,31.4), (96.2,31.4), (128.2,31.4), authored 180° and native bottom 0°. South fuses are at (48.8,108.6), (80.8,108.6), (112.8,108.6), (144.8,108.6), authored 0° and native bottom 180°. Each native rectangular fuse pad 2 to jack pad 1 shortest edge distance is 3.315 mm, leaving 1.185 mm against the unchanged 4.5 mm requirement. These are eight frozen placements, with no global-optimum claim; the earlier lateral bound was axis-aligned only. All fuse pads occupy B.Cu and B.Paste. Eight unchanged identity model attachments were checked using the 2.54 mm VRML unit, native Y convention, actual rotation and bottom Y/Z reflection. The 4.73 × 3.41 × 1.8 mm maximum model envelope lies below the bottom copper plane, and visual terminal centres register to their native pads. This is model semantics, not physical fit.

Only U_ESD1–U_ESD8 GND pad 4 gains full zone connection. The eight clamp poses, underside population, signal lands, signal-net ownership and non-ground inherited zone settings remain unchanged. No thermal floor, clearance, waiver, exclusion or electrical rule was relaxed. Independent refill reports no starved thermal or other violation. Existing solid returns remain, giving eighteen explicitly guarded ground pads in the source consumer.

The connector change is a disclosed project-derived copper/silk land, not vendor approval. Native non-silk projection equality, allowing only the two shell land lengths, preserves all eight signal pads, hole centres, 2 × 1 mm shield slots, F.Fab, courtyard and model registration. The manufacturer drawing 001.003 page 1 was reopened and viewed: 0.8 mm signals, 3.18 mm locators, 13.7 mm locator span, 14.8 mm shell-slot span, 2.04 mm same-row pitch, 1.02 mm stagger and 4 mm rows agree. The 2.5 × 1.5 mm shell copper ovals retain a uniform 0.25 mm nominal annulus. Independent capsule geometry changes the nominal nearest NPTH-to-copper gap from 0.024846718 to 0.268639492 mm, above the unchanged 0.25 mm floor by only 0.018639492 mm. This is no tolerance guarantee or physical qualification. Side silk ends at local y=-5.50, giving 0.30 mm ink clearance to the locked y=-5.86 edge; outboard line and marker are removed. Hole/mate/body/model datums remain unchanged. Independent hashes are footprint `71ddc2085058b171a232326aec8adfe5d13ea40cf5c974b4aa9bfd0fea528ec0` and STEP `3f902b89d4bd756b121be056782deff312efb127c9c48f2c798ebd6db0e59f49`.

Every F# BOT caption has exactly one correct nearby fuse owner, at 2.886174 mm, below the unchanged 3 mm limit. These captions are on top silk and explicitly direct service to the bottom. All CH1–CH8 captions remain nearest their own jack and clear actual native component body/pad boxes. I viewed the actual native north/south top silk crops, top Fab overlays and mirrored bottom silk/Fab crops. The CH/F# BOT labels are legible and unobscured; bottom F1–F8 and U_ESD1–8 reference labels are readable from the bottom. This conclusion uses mirrored plots and native mirrored reference properties, not an unmirrored-text assumption. Broader inherited refdes ownership warnings remain for owning placement/assembly review.

Assembly source explicitly retains two sides and now names all eight bottom fuses plus eight bottom clamps for paste, CPL/rotation, THT-tail/fillet separation and rework qualification. First-power installed references change from 316 to exactly 333 by adding only D_BUCK_IN and R_IN1P/N through R_IN8P/N. The set equals the native fitted component set. Every other card field is byte-equivalent after parsing and restoring the prior installed list: no voltage, current or power limit is increased. ADR0025's shared 3V3_ADC/amplifier rail and passive external VMID dividers are preserved, with the independent 23-test protection suite rejecting split rails, retired buffers and hostile electrical substitutions. The existing held 13.2 V functional corner remains held: the unchanged first-article plan requires a reviewed card/procedure update before that test where current rows stop at 12.0 V.

Stock regeneration in scratch produces a board byte-identical to the frozen candidate: SHA-256 `9c30a147b2d94babd98bc2af4150d4e87270d2efb81a8bd39e88f1b9529a99f4`. There are 333 fitted components plus 7 mounting/fiducial footprints, 0 routed tracks and 11 thermal vias. All 340 native footprint/pad/model/graphic projections match the frozen board, and whole-board bytes match as well. The rules generator ran last before native severity-all/refill/schematic-parity/exit-code DRC. Actual native result is 0 violations / 499 unconnected / 0 parity, with exit code 5 faithfully retained. The four pre-existing ignored-check settings are recorded in native DRC; no change is made to them. Each of all 499 unconnected pairs was independently classified using both native UUIDs, net names and endpoint positions; every pad endpoint also matches source-netlist pin ownership. The complete 998-endpoint witness is archived, not replaced by an aggregate. They are missing same-net connections on the track-free pre-route board; route feasibility and routed/final-clean acceptance are not claimed.

The independent placement consumer grades 333 assembled envelopes with 0 close/overlapping pairs and 0 envelope-to-foreign-pad findings at unchanged 0.10 mm clearance; its reported minimum is a search-ceiling lower bound, not a measured global minimum. P-OUT minimum is 1.32 mm; coarse capacity demand is 17 versus 257 at x=36.5 mm. These local checks support source selection and do not adopt placement. Focused tests independently pass: 31 ground/local-placement/silkscreen tests, 5 entry-contract tests and 23 shared-rail/protection tests, including their actual hostile consumers (59 total). Root's reported 39-test aggregate was not used as independent evidence.

The review harness initially omitted Bun from its explicit PATH, lacked optional CairoSVG, and had a scratch filename/API/net-name/UUID setup mismatch. Failed logs are retained; the corrected explicit Bun environment, installed librsvg and KiCad 10 API were used without changing candidate or shared source. All engineering subprocesses launched after runtime setup used pipeline_runtime.run_stage, explicit cwd/environment and 180-second bounds; the filename-shadow failure occurred while importing the runtime and launched no engineering child. Actual reused method hashes and raw logs/receipts are archived. The runtime is bounded, not hermetic. No source/geometry retry or candidate variant was generated.

Source selection is SOUND with no actionable defect or missing review coverage. SOURCE/FULL remains 23 carrier / 9 pod physical unknowns. FIRST-ARTICLE-ONLY / DO-NOT-ORDER, custom analog/power RJ45 (not Ethernet/PoE), power-off mating, LAYOUT001 closed 3/3, preceding variant spend and all owning engineering gates remain unchanged. Physical qualification is not invented as an extra prerequisite to prototype fabrication; this review does not authorize ordering or release.
'''.format(**subject,census='\n'.join('- `'+x['path']+'`' for x in delta['changed']))
(O/'report.md').write_text(report)
evidence={'schema':1,'verdict':'SOUND','scope':'Exact frozen combined nine-file source selection only; FIRST-ARTICLE-ONLY / DO-NOT-ORDER','subject':subject,'reviewed_at':datetime.now(timezone.utc).isoformat(),'source_delta':delta['changed'],'unchanged_count':len(delta['unchanged']),'frozen_inputs_before_after':430,'measurements':meas,'bottom_model_semantics':model,'methods':methods,'tests':{'focused':31,'entry':5,'protection':23,'total':59,'errors':0,'failures':0},'native':{'board_sha256':H(P/'04_kicad/crow_audio_carrier_v1.kicad_pcb'),'byte_identical_frozen_candidate':True,'violations':0,'unconnected_items':499,'schematic_parity':0,'exit_code':5,'per_item_evidence':'raw/unconnected-classification.json'},'visual_review':{'viewed':['manufacturer-page1.png','top-north.png','top-south.png','bottom-north.png','bottom-south.png','top-service-north.png','top-service-south.png'],'bottom_view':'Native SVG --mirror; readable bottom reference labels confirmed','functional_legend_verdict':'PASS'},'source_findings':[],'limitations':['Source selection only, no schematic/placement/routing/assembly/release adoption','Nominal shell land margin, no tolerance/physical qualification','499 unrouted same-net connections remain','Existing broader reference-ownership warnings remain owning-gate work','13.2 V functional card corner remains held','23 carrier and 9 pod physical unknowns unchanged'],'execution':{'runtime':'pipeline_runtime.run_stage','max_subprocess_seconds':180,'cwd':str(S),'python':'/usr/bin/python3 -B','env':{'PYTHONDONTWRITEBYTECODE':'1','PATH':'/home/mouse9911/.bun/bin:/usr/bin:/bin'},'bounded_not_hermetic':True}}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2))
(O/'result.json').write_text(json.dumps({'subject':subject,'checks':{k:'PASS' for k in env['completion']['checks']},'unresolved':[]},indent=2))
entries={}
def add(path,data):
    assert path not in entries and not PurePosixPath(path).is_absolute() and '..' not in PurePosixPath(path).parts
    entries[path]=data
for f in sorted((S/'raw').glob('*')):
    if f.is_file() and not f.name.startswith('package-final'):add('raw/'+f.name,f.read_bytes())
for f in S.glob('*.py'):add('methods/review/'+f.name,f.read_bytes())
for row in methods:add(row['archive_path'],Path(row['path']).read_bytes())
for row in delta['changed']:add('source_candidate/'+row['path'],(Q/'candidate'/row['path']).read_bytes())
for ext in ['kicad_pcb','kicad_pro','kicad_dru']:add('native/crow_audio_carrier_v1.'+ext,(P/'04_kicad'/('crow_audio_carrier_v1.'+ext)).read_bytes())
add('input-envelope.json',(S.parent/'envelope.json').read_bytes());add('review-report.md',report.encode());add('review-evidence.json',(O/'evidence.json').read_bytes())
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
    for name,data in sorted(entries.items()):
        info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;t.addfile(info,io.BytesIO(data))
# Independently reopen every actual member; no links/directories/duplicates/traversal.
reopened=[];seen=set()
with tarfile.open(archive,'r:gz') as t:
    for m in t:
        assert m.isfile() and not m.issym() and not m.islnk() and m.name not in seen and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts
        seen.add(m.name);data=t.extractfile(m).read();assert data==entries[m.name] and len(data)==m.size
        reopened.append({'path':m.name,'size':m.size,'sha256':hashlib.sha256(data).hexdigest()})
assert seen==set(entries)
(O/'evidence-manifest.json').write_text(json.dumps({'archive_sha256':H(archive),'archive_size':archive.stat().st_size,'member_count':len(reopened),'members':reopened},indent=2))
print(json.dumps({'verdict':'SOUND','outputs':sorted(p.name for p in O.iterdir()),'archive_sha256':H(archive),'archive_size':archive.stat().st_size,'member_count':len(reopened)}))
