# Pod connector orientation — current top-only board

Please check J1’s mouth faces out across the north board edge, its housing mounts on top, and its visible latch/keying and cable approach suit the intended use. Review all five current views below.

All 31 fitted SMD components are on top. This approval covers connector orientation; physical cable fit, latch testing, routing and release acceptance remain separate.

Exact subject: `54ff09c6c9f55e8d467b35ad346f3dfdd715c9a1a5aa7029ebe9dab931e200b6`.

![Top and outward cable direction](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-mic-pod-v3/06_build/pre_route/orientation/views/J1_top.png)

![Mouth and keying from the cable side](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-mic-pod-v3/06_build/pre_route/orientation/views/J1_outside.png)

![Rear of connector](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-mic-pod-v3/06_build/pre_route/orientation/views/J1_inside.png)

![First side profile](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-mic-pod-v3/06_build/pre_route/orientation/views/J1_profile_a.png)

![Opposite side profile](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-mic-pod-v3/06_build/pre_route/orientation/views/J1_profile_b.png)
