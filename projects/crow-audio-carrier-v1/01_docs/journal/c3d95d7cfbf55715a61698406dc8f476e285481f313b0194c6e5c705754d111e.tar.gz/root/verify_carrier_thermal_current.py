from pathlib import Path
from collections import Counter
import json,hashlib,pcbnew
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;P=R/'projects/crow-audio-carrier-v1';bp=P/'04_kicad/crow_audio_carrier_v1.kicad_pcb';gp=P/'06_build/drc/gate.json';pre=P/'06_build/drc/pre_route.json';g=json.loads(gp.read_text());old=json.loads(pre.read_text());key=lambda x:json.dumps(x,sort_keys=True)
for group in ['violations','unconnected_items','schematic_parity']:assert Counter(map(key,g[group]))==Counter(map(key,old[group]))
assert len(g['violations'])==1 and len(g['unconnected_items'])==499 and not g['schematic_parity'];b=pcbnew.LoadBoard(str(bp));objects={};counts=Counter()
for f in b.GetFootprints():
 for p in f.Pads():objects[p.m_Uuid.AsString()]=('pad',p)
for t in b.GetTracks():objects[t.m_Uuid.AsString()]=('via' if isinstance(t,pcbnew.PCB_VIA) else 'track',t)
for z in b.Zones():objects[z.m_Uuid.AsString()]=('zone',z)
rows=[]
for group in ['violations','unconnected_items']:
 for i,row in enumerate(g[group],1):
  ends=[]
  for raw in row['items']:
   kind,obj=objects[raw['uuid']];net=obj.GetNetname();assert '['+net+']' in raw['description'];pos={axis:getattr(obj.GetPosition(),axis)/1e6 for axis in ['x','y']};assert all(abs(pos[a]-raw['pos'][a])<.000002 for a in ['x','y']);counts[kind]+=1;ends.append({'kind':kind,'net':net,'uuid':raw['uuid'],'native_position_mm':pos,'raw':raw})
  rows.append({'group':group,'row':i,'endpoints':ends})
print('Measured endpoint kind census:',dict(counts));assert sum(counts.values())==1000 and counts['zone']>=1
out={'pcb_sha256':hashlib.sha256(bp.read_bytes()).hexdigest(),'gate_sha256':hashlib.sha256(gp.read_bytes()).hexdigest(),'pre_route_sha256':hashlib.sha256(pre.read_bytes()).hexdigest(),'counts':dict(counts),'total_endpoints':1000,'method':'Fresh all-severity/refill/parity DRC; complete raw-row equality to worker current pre_route classification; independent UUID/net and coordinate verification against unchanged native PCB. Every zone report coordinate equals its native anchor; full endpoint-kind census retained separately from pad/via positions.','rows':rows,'verdict':'FAIL P-DRC thermal defect; no route acceptance'};(N/'carrier-thermal-current-root-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(out['pcb_sha256'],out['counts'])
