from pathlib import Path
from datetime import datetime,timezone,timedelta
import sys,json,hashlib,shutil,tempfile
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt

def copy(src,dst):
 src=Path(src);dst=Path(dst)
 if src.is_dir():shutil.copytree(src,dst,ignore=shutil.ignore_patterns('__pycache__','*.pyc','node_modules','.git'))
 else:dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)

def open_task(name,task,copies,minutes=25,role='judgment'):
 probe=json.loads((N/'rj45-placement-thermal-availability-opened.json').read_text());assert json.loads((Path(probe['envelope']).parent/'attempt.json').read_text())['status']=='PASS'
 D=Path(tempfile.mkdtemp(prefix=name+'-'))
 for src,rel in copies:copy(src,D/rel)
 copy('/tmp/carrier-locator-implementation-availability-6c_4vwal/preflight.py',D/'preflight.py')
 now=datetime.now(timezone.utc);cut=now+timedelta(minutes=minutes);hard=cut+timedelta(minutes=7)
 (D/'TASK.md').write_text(task+f'''\n\nDelivery mechanics: Allocated scratch: {D}/06_build/task_runs/{name}/scratch . Final outputs: {D}/06_build/task_runs/{name}/outputs . Root sole live writer. Frozen packet read-only; make working copies under the allocated scratch dir only. No live writes, commits, children, background processes, or source adoption. Verify every envelope input before/after. Use /usr/bin/python3 -B and shared pipeline_runtime.run_stage for finite direct-argv subprocesses, explicit cwd/environment, raw stdout/stderr/runtime retained under scratch. Shared runtime is at {R}/skills/pcb-design/scripts. Images can be opened with view_image.\n\nWork cutoff {cut.isoformat()}, hard {hard.isoformat()}, zero replacements. Stop engineering at work cutoff and return actual FINAL promptly. Preserve honest INCOMPLETE if coverage absent; delivery PASS means complete honest handback, never engineering acceptance. Outputs exactly report.md, evidence.json, evidence-manifest.json, evidence.tar.gz, result.json. evidence.json requires verdict SOUND|DEFECTIVE|INCOMPLETE and exact envelope subject, methods, findings and measured counts. Archive all actual methods/raw evidence/runtime; manifest archive_sha256/archive_size/member_count/members with path,size,sha256; reopen every regular member, no symlink/traversal/duplicate/recursive archive. result.json exact subject, checks inputs-verified/review-complete/evidence-complete PASS only when factually complete delivery; unresolved [] for delivered honest findings. Use preflight.py with exact envelope after packaging to validate delivery. Final response gives domain verdict and unresolved findings, exact report and archive.\n''')
 items=[]
 for p in sorted(D.rglob('*')):
  if p.is_file():b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(D).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 subject=subject_identity('placement_review',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
 e=TaskEnvelope(schema=2,task_id=name,stage_id='KICAD-PLACEMENT',run_id=name,subject=subject,executor='reviewer' if role=='judgment' else 'agent',execution_class='review_wait' if role=='judgment' else 'local',recommended_agent_role=role,agent_role=role,role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']})
 o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),agent_id='/root/'+name.replace('-','_'),work_cutoff=cut.isoformat(),frozen_inputs=len(items));(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o));return o
