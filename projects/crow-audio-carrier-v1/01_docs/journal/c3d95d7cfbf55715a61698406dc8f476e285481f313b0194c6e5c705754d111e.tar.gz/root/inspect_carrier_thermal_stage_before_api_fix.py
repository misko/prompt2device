from pathlib import Path
import pcbnew,json,hashlib
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;S=Path('/tmp/rj45-coherent-top-only-source1-dz0edoky/06_build/task_runs/rj45-coherent-top-only-source1/scratch')
paths={'current':R/'projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb','candidate4_placement':S/'native-placement/crow-audio-carrier-v1/crow_audio_carrier_v1.kicad_pcb','candidate4_prepared':S/'work/projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb'};out={}
for label,p in paths.items():
 b=pcbnew.LoadBoard(str(p));pads=[];tracks=[];zones=[]
 for fp in b.GetFootprints():
  for pad in fp.Pads():
   q=pad.GetPosition();x,y=q.x/1e6,q.y/1e6
   if abs(x-90.52)<2 and abs(y-71.5)<2:
    pads.append({'ref':fp.GetReference(),'pin':pad.GetNumber(),'net':pad.GetNetname(),'xy':[x,y],'size':[pad.GetSize().x/1e6,pad.GetSize().y/1e6],'orientation':pad.GetOrientationDegrees(),'connection':pad.GetZoneConnection(),'gap':pad.GetLocalThermalGap(),'spoke':pad.GetLocalThermalSpokeWidth()})
 for t in b.GetTracks():
  a,z=t.GetStart(),t.GetEnd()
  if min(a.x,z.x)/1e6<92.5 and max(a.x,z.x)/1e6>88.5 and min(a.y,z.y)/1e6<73.5 and max(a.y,z.y)/1e6>69.5:tracks.append({'net':t.GetNetname(),'layer':b.GetLayerName(t.GetLayer()),'start':[a.x/1e6,a.y/1e6],'end':[z.x/1e6,z.y/1e6],'width':t.GetWidth()/1e6,'via':isinstance(t,pcbnew.PCB_VIA)})
 for z in b.Zones():
  if z.GetLayerSet().Contains(pcbnew.F_Cu):
   bb=z.GetBoundingBox()
   if bb.Contains(pcbnew.VECTOR2I(pcbnew.FromMM(90.52),pcbnew.FromMM(71.5))):zones.append({'uuid':z.m_Uuid.AsString(),'net':z.GetNetname(),'rule_area':z.GetIsRuleArea(),'priority':z.GetAssignedPriority(),'clearance':z.GetLocalClearance()/1e6,'gap':z.GetThermalReliefGap()/1e6,'spoke':z.GetThermalReliefSpokeWidth()/1e6,'min_thickness':z.GetMinThickness()/1e6,'pad_connection':z.GetPadConnection(),'bounds':[bb.GetX()/1e6,bb.GetY()/1e6,bb.GetWidth()/1e6,bb.GetHeight()/1e6]})
 out[label]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'nearby_pads':pads,'nearby_tracks':tracks,'overlapping_F_zone_bboxes':zones}
(N/'carrier-thermal-stage-census.json').write_text(json.dumps(out,indent=2)+'\n')
for k,v in out.items():print(k, v['sha256'], len(v['nearby_pads']),'pads',len(v['nearby_tracks']),'tracks',len(v['overlapping_F_zone_bboxes']),'zones')
