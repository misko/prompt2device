from placement_review_common import *
import tarfile
name='rj45-locator-startup-repair'
c=json.loads((N/(name+'-closeout-summary.json')).read_text());assert c['delivery_status']=='PASS' and c['engineering_verdict']=='SOUND'
m=json.loads((N/(name+'-opened.json')).read_text());O=Path(m['output_dir']);e=json.loads((O/'evidence.json').read_text())
V=N/'mixed-side-repaired-source';assert not V.exists();V.mkdir()
copy(N/'mixed-side-integration-source/repo',V/'repo')
rows=e['source_manifest'];assert len(rows)==13
with tarfile.open(O/'evidence.tar.gz') as t:
 for row in rows:
  rel=row['path'];assert hashlib.sha256((R/rel).read_bytes()).hexdigest()==row['before_sha256'];assert hashlib.sha256((V/'repo'/rel).read_bytes()).hexdigest()==row['before_sha256']
  b=t.extractfile('proposal/'+rel).read();assert hashlib.sha256(b).hexdigest()==row['after_sha256'];p=V/'proposal'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
(V/'source-manifest.json').write_text(json.dumps({'files':rows,'author_closeout':c,'scope':'Exact combined13 files after locator candidate2; no live adoption.'},indent=2)+'\n')
for f in ['report.md','evidence.json','evidence-manifest.json','evidence.tar.gz']:copy(O/f,V/'repair-evidence'/f)
previous=json.loads((N/'rj45-mixed-side-source-integrity-opened.json').read_text());Q=Path(previous['output_dir'])
for f in ['report.md','evidence.json','evidence-manifest.json','evidence.tar.gz']:copy(Q/f,V/'previous-review'/f)
copy(N/'rj45-mixed-side-source-integrity-closeout-summary.json',V/'previous-review/root-closeout.json')
task='''# Fresh exact-source integrity review: mixed-side tooling, corrected startup

Root has not adopted any proposal. Review all13 exact source postimages in source-manifest.json, with candidate2 repairing F-STARTUP-SIDE from the completed independent DEFECTIVE review. Read full prior report and new author's report, exact source and contracts. Their full archives remain digest-bound frozen inputs. Do not inherit a verdict: verify exact original/postimage identity and the minimal candidate1-to2 delta; unchanged portions may use explicitly cited prior independently reproduced evidence ONLY after verifying identical files, tests, primary/native inputs and actual evidence binding. Fresh source verdict covers exact13 after hashes, not a subset. No source edits or children; discovered defect is DEFECTIVE, coverage gap INCOMPLETE.

Independently exercise HTML startup in FRESH DOM/browser contexts: default/empty fragment, valid top, valid bottom, nonexistent reference, valid URI encoding, malformed escape sequences, and transition to a valid selection afterward. Verify truthful single-side or explicitly unselected geometry, exact mounted-side filtering, readable convention, selected identity/crosshair, and full native census preserved. Also retain side switching, unknown after valid, empty-side behavior. Reproduce the new property RED on exact reviewed candidate1 and GREEN on exact candidate2, without simply calling the author's custom script as the independent method. Inspect actual rendered valid/invalid startup screenshots in Firefox (available cached browser). No arbitrary source variants or repairs.

Run maintained locator suite, public CLI and pin suite on exact combined candidate. Independently verify their preserved old controls and added new test. Fresh actual carrier export/check must retain333references317top16bottom/1043pads/25top exceptions/300CPL rows284top16bottom,33off-BOM context refs; board bytes unchanged. Retain independent native-projection and wrong-side/unmirrored rejection evidence: you may reuse the immediately prior independently measured evidence after exact source/input identity proof because those generator/checker bytes are unchanged, and state this provenance rather than pretending fresh reruns. Likewise pin frame was independently unmounted across384footprints1163pads and64asymmetric native instances with32physical mirrors retained; validate exact pin3files remain unchanged and inspect actual independent evidence and TI primary U3 comparison. No footprint/pin/net changes are proposed. Source code cannot use expected winding to hide physical mirror.

All governing source/release templates and combined README must describe actual semantics/tests. Root owes full-checkout authority/docs/contracts after source acceptance. Prior frozen corpus contract deficits are known, not a reason to waive or claim full green. No need repeat unrelated model/physical/route campaigns. Candidate2 exhausts original locator budget; no resets/replacements. Source SOUND permits root exact adoption/qualification then normal downstream renewal, never direct placement/route/release acceptance. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.

Delivery must retain your actual independent methods/raw/runtime/screenshots, exact source coverage and findings. Do NOT duplicate the424MB prior review archive, unchanged primary PDFs or full frozen source trees into your output; reference their verified SHA and exact relevant members, and retain only actual new evidence plus necessary extracted original failure controls. Reopen all original archive members to verify claimed provenance. Report measured versus inherited exact-bound results clearly. Return actual FINAL promptly.
'''
open_task('rj45-mixed-side-repaired-integrity',task,[(V/p,p) for p in ['repo','proposal','source-manifest.json','repair-evidence','previous-review']],minutes=20)
