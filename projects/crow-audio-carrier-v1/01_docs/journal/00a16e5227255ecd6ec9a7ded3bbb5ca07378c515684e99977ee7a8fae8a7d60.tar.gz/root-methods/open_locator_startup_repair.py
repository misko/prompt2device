from placement_review_common import *
V=N/'mixed-side-integration-source'
M=json.loads((N/'rj45-mixed-side-source-integrity-opened.json').read_text())
O=Path(M['output_dir'])
copies=[(V/p,p) for p in ['repo','proposal','source-manifest.json']]
copies += [(O/p,'failed-review/'+p) for p in ['report.md','evidence.json','evidence-manifest.json','evidence.tar.gz']]
opened=open_task('rj45-locator-startup-repair', '''# Continue existing locator owner: candidate 2 of 2, F-STARTUP-SIDE

The independent exact combined source review found F-STARTUP-SIDE: unknown initial URL fragment renders both sides under Top side up. Read the complete failed report and reproduce its actual fresh-DOM failure before correcting. This is candidate TWO of the original TWO; no reset, no replacements. Continue only the existing locator correction. Root remains sole live writer.

Copy frozen repo into allocated scratch; apply the exact13 proposal postimages after verifying before/after hashes. Preserve this candidate1 baseline. Fix truthful initial viewing state and add a maintained fresh-DOM unknown-fragment startup property regression. Preserve valid empty/default, top, bottom, unknown-after-valid, side switching and empty-side behavior. Assess malformed URL decoding as part of the same initial-state class; no unrelated redesign. Test RED against exact reviewed candidate1, GREEN against candidate2. Use native mixed-side actual carrier export, meaningful initial-state browser checks and maintained locator/public CLI suites. The independent review's method and Firefox screenshot are archived; inspect them, do not simply inherit their counts. No need rerun unchanged pin methods or alter pin files, geometry, source exceptions, checker limits or native board bytes. Preserve all successful scope and original tests. Update test catalog only as needed for the new property. Full-checkout contracts belong to root after independent source acceptance; honestly preserve frozen-corpus limitations.

Deliver exact combined13-file source-manifest with original live before hashes and final after hashes, plus proposal/<relative path> for ALL13 files and candidate1-vs-candidate2 diff. Unchanged files remain byte-identical. Archive original versus candidate source and all raw finite runtime evidence, actual screenshots and startup controls. evidence.json source_manifest must be an array of path,before_sha256,after_sha256,before_size,after_size. SOURCE SOUND here means ready for fresh independent exact review only; no source adoption or downstream acceptance. If not correct within this candidate and deadline, return precise DEFECTIVE/INCOMPLETE and stop. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.
''',copies,minutes=20,role='authoring')
# Same implementation owner, new bounded envelope after closed candidate1.
opened['agent_id']='/root/rj45_current_locator_author'
(N/'rj45-locator-startup-repair-opened.json').write_text(json.dumps(opened,indent=2)+'\n')
print(json.dumps(opened))
