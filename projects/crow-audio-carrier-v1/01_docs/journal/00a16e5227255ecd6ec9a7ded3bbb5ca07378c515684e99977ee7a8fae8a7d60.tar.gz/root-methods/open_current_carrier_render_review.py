from placement_review_common import *
sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'))
from pre_route_review_check import design_rules_digest,digest
P=R/'projects/crow-audio-carrier-v1';files=[]
for rel in ['02_parts','03_src','04_kicad','03_tscircuit/build/circuit.json','01_docs/BRIEF.md','06_build/drc','08_reviews/connector_orientation.yaml','06_build/pre_route/model_registration.md','06_build/pre_route/model_registration.stage.json','06_build/pre_route/model_registration_bundle','06_build/pre_route/native_registration','06_build/pre_route/orientation','06_build/pre_route/orientation-supplement','06_build/pre_route/approved_native_bottom.png']:
 if (P/rel).exists():files.append((P/rel,'project/'+rel))
for rel in ['CLAUDE.md','skills/kicad-pcb/SKILL.md','skills/kicad-pcb/references','skills/kicad-pcb/scripts','skills/jlcpcb-fab/scripts','skills/jlcpcb-fab/references/digital-twin.md','skills/pcb-design/scripts','skills/pcb-design/references/review-and-publication.md','skills/pcb-design/references/execution-runtime.md']:
 files.append((R/rel,'context/'+rel))
for suffix in ['command.json','runtime.json','log']:
 p=Path('/tmp/carrier-connector-integration-20260911')/('carrier-approved-full-bottom-render'+('-' if suffix!='log' else '.')+suffix)
 assert p.exists();files.append((p,'root-render/'+p.name))
fields={'board_sha256':digest(next((P/'04_kicad').glob('*.kicad_pcb'))),'design_rules_sha256':design_rules_digest(P)}
task='''# Fresh independent carrier pre-route render review

Read exact frozen current native carrier board/source/parts and current registered native full-scene images. Root sole live writer. No historical reviews/session rationale. PRE-ROUTE native render judgment only: catalog-twin A-RENDER/locator assembly checks remain separately owed. Do not substitute native model6/6 for catalog-twin fidelity or user P-ORIENT for independent full-board render judgment.

Reopen same-board model_registration.md, accepted bundle/receipt and all6 group evidence/imagery before relying on geometry. Inspect actual full native top image and all current orientation views in pre_route/orientation; bottom full native image approved_native_bottom.png is freshly produced with333/333 resolved model paths. Independently verify bound native scene, source body/footprint correspondence, mounted sides, visible polarity/connector mouths/latch/keying/labels, actual body interactions, board holes and edges, underboard fuses/ESDdevices, exact declared reference omissions and nominal mechanical interpretation. Do not rely on pixels alone for occluded side/datum facts; measure native source as needed. All8RJ45jacks+J9powerconnector+J10/J11headers in scope, plus full board body/population census.

User orientation approval already exists for exact current9 connectors; inspect images independently without requesting another approval. Native Fab sampling limitations and full finger nominal extent remain explicitly declared by source; fullscene real occlusion must remain visible. At most2additional camera recipes if a specific undecidable finding requires them, via supported render_board.py in isolated scratch. No removal of parts to fabricate visibility. No model/placement/source/routing campaign. Report unjudgeable coverage honestly and actionably; physical tolerance/service qualification stays first-article hold, not a new design prerequisite.

Factory Cat6A/RJ45 carries custom analog/DC, NOT Ethernet/PoE; power-off mating. FIRST-ARTICLE-ONLY / DO-NOT-ORDER. Native board remains unrouted; no source/checkpoint rerun or route acceptance. Keep raw evidence, current viewed images or their exact bound identities, methods and finite runtime. Do not copy whole unchanged input trees or nested original archives into delivery.

report.md flat fields review_stage: pre-route, review_kind: render, reviewer: actual fresh identity, context: FRESH, design_verdict: SOUND|DEFECTIVE|INCOMPLETE, order_verdict: DO-NOT-ORDER plus exact subjects below. Semantic rules digest uses frozen pre_route_review_check.design_rules_digest(project), not single-file hash. Derive counts, findings severity/ref/coordinate and owner, and explicitly distinguish whole-board native render from catalog twin. Preserve measurement limits and rendered visibility limitations.
'''+''.join(f'{k}: {v}\n' for k,v in fields.items())
open_task('rj45-carrier-render-approved',task,files,minutes=25)
