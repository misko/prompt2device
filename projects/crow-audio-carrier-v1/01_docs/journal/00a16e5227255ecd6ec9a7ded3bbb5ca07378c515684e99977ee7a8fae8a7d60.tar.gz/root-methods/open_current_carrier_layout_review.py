from placement_review_common import *
sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'))
from pre_route_review_check import design_rules_digest,digest
P=R/'projects/crow-audio-carrier-v1';files=[]
for rel in ['02_parts','03_src','04_kicad','03_tscircuit/build/circuit.json','03_tscircuit/build/schematic.pdf','03_tscircuit/manifest.yaml','03_tscircuit/src','01_docs/DETAIL_DESIGN.md','01_docs/BRIEF.md','01_docs/first_power.md','01_docs/FIRST_POWER.md','06_build/route/r0.kicad_pcb','06_build/route/r0.kicad_pro','06_build/route/r0.kicad_dru','06_build/drc','06_build/placement_policy_audit.md','06_build/placement_routability_preflight.json','08_reviews/connector_orientation.yaml']:
 if (P/rel).exists():files.append((P/rel,'project/'+rel))
for p in sorted((P/'06_build/verification').glob('*')):
 if p.is_file():files.append((p,'project/'+p.relative_to(P).as_posix()))
for rel in ['CLAUDE.md','skills/kicad-pcb/SKILL.md','skills/kicad-pcb/references','skills/kicad-pcb/scripts','skills/pcb-design/scripts','skills/pcb-design/references/review-and-publication.md','skills/pcb-design/references/execution-runtime.md']:
 files.append((R/rel,'context/'+rel))
fields={'board_sha256':digest(next((P/'04_kicad').glob('*.kicad_pcb'))),'design_rules_sha256':design_rules_digest(P),'prepared_board_sha256':digest(P/'06_build/route/r0.kicad_pcb')}
task='''# Fresh independent carrier pre-route layout review

Review exact frozen current carrier project native board and deterministic prepared r0 against current source rules and primary manufacturer facts. No historical reviews or session rationale. Root remains sole live writer. This is full-board PRE-ROUTE placement judgment; unreached routing/assembly gates remain separately owed. Shared evidence tooling is being corrected in isolated scratch and is not part of this layout subject. Do not use stale locator/twin or pin dossiers as physical authority. Independently derive actual native component/pad/side/net/width/clearance census from immutable native board, source and primary documents.

Examine electrical proximity and decoupling to served pins, power and hold-up/buck/current-return paths, input clamps and connector-to-clamp ordering, quiet analog/ADC/reference versus digital/clock separation, bottom fuses/ESD devices and opposite-side physical interactions, all9connector service mouths, pad/edge/courtyard/keepout/drill interactions and mechanical attachment, fanout and deterministic prepared copper. Apply every applicable current placement policy and source-owned launch constraint. Cross-check the intended populated/bare/board-only census and all source placement anchors. Required manufacturer guidance needs actual primary diagram inspection or source-cited evidence, not generic intuition. No native mutation; use allocated scratch for supported native DRC/read-only geometry methods.

Retain full severity-all/refill/parity DRC and classify EACH violation AND open by its actual ref/pad/net/UUID endpoint, distinguishing expected unrouted edges from physical placement faults and prepared dangling launches. No generalized congestion summary substitutes endpoint classification. r0 is preparation only. No router, promoted historical chain, source edit, rebuild or checkpoint mutation. If incomplete within the bound, give exact uncovered scope rather than inventing full-board SOUND.

Current factory Cat6A/RJ45 carries custom analog/DC, NOT Ethernet or PoE. Power-off mating, exact physical first-article obligations and DO-NOT-ORDER remain. Nominal CAD clearance is not tolerance fit or hand-access proof. Separate legitimate first-article holds from actionable design placement defects; no new physical-measurement prerequisite before an honest design release.

report.md flat fields review_stage: pre-route, review_kind: layout, reviewer: actual fresh agent, context: FRESH, design_verdict: SOUND|DEFECTIVE|INCOMPLETE, order_verdict: DO-NOT-ORDER, plus immutable subject metadata below. design_rules_sha256 uses the frozen pre_route_review_check.design_rules_digest(project) semantic algorithm, not one file's bytes. Derive all coverage counts; each finding severity, exact ref/pad/coordinate and next owner. Preserve actual methods/raw evidence/runtime and inspected primary figures; no copying unchanged whole frozen input trees or nested original archives into output. Hash-reference exact frozen inputs and retain your actual measurements. No route/release acceptance.
'''+''.join(f'{k}: {v}\n' for k,v in fields.items())
open_task('rj45-carrier-layout-approved',task,files,minutes=35)
