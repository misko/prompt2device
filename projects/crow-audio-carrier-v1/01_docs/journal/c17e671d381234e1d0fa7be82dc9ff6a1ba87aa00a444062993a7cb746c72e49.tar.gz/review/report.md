review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_logic_clockground1 (actual fresh independent agent)
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: e85b1461a82f3d3853c19fae694693816e31570d23d37019ef187d6428bea4ae
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: e6d5b0b89efd79051b082f70b283ec7e85e1170ed11ddb94581744d26904c9c7

Coverage is limited to U_DUMP, U_LDO_EN, U_OE, U_TDM, U_TDM_SCH and their dossier-visible pin/package mappings. No whole-board acceptance or order authorization. Bindings above are commissioned metadata, not separate engineering conclusions. No live schematic, board, author rationale, or prior review was consulted. Dossier verification-note prose was not adopted as evidence.

Manufacturer derivation preceded opening native dossiers. Actual PDF figure images were rendered with pdftoppm at120dpi and inspected with view_image. Nexperia GV/SOT753 diagrams show pin1 upper left, pin2 middle left, pin3 lower left, pin4 lower right, pin5 upper right. These wind CCW, with three leads left and two right. Their mechanical top projection puts pin1 lower left and differs by rotation only. SC-74A is a five-lead package with no EP or fused leads. TI DBV explicitly labels TOP VIEW and has the same geometry; its pin1 is active-low OE rather than NC. Unrelated bottom-view package variants were excluded.

All dossiers specify front mounting, zero rotation, component-top +x right/+y down. No reflection applies. All five native tables reproduce the expected geometry with pin1(-1.1375,-0.95), pin2(-1.1375,0), pin3(-1.1375,0.95), pin4(1.1375,0.95), pin5(1.1375,-0.95)mm. Measured signed polygon area is -4.3225mm², corresponding to visual CCW for y-down coordinates. Native coordinates equal the given origin plus local coordinates for all25 pins. Five separate pad identities per instance,25 total; zero absent/duplicate/fused identities and zero EPs. No aliases are needed or declared. Manufacturer exposed-center terminals in other package options are inapplicable.

U_DUMP VERDICT: PASS
Measured native pads:5; physical identities:5; distinct positions:5; expected pins:5; EP:0; aliases:0.
Primary: projects/crow-audio-carrier-v1/02_parts/74LVC1G14GV,125/74LVC1G14_Rev19.pdf
SHA256: b8f37c700d0fc8374de6d14f0e2caf310c34b480ffab9d63c69bb3b6defbebbf
Figure: PDF p3 section7.1 GV figure aaa-035749/Table3; p11 Fig13 SOT753.
U_DUMP pin 1 (NC): expected unconnected terminal; observed unconnected-(U_DUMP-NC-Pad1) on physical pin1 at [-1.1375, -0.95], matching the manufacturer function and position.
U_DUMP pin 2 (A): expected logic data input; observed DUMP_RC on physical pin2 at [-1.1375, 0.0], matching the manufacturer function and position.
U_DUMP pin 3 (GND): expected ground (0V); observed GND on physical pin3 at [-1.1375, 0.95], matching the manufacturer function and position.
U_DUMP pin 4 (Y): expected logic output; observed DUMP_GATE on physical pin4 at [1.1375, 0.95], matching the manufacturer function and position.
U_DUMP pin 5 (VCC): expected supply rail; observed 5V_LDO_HOLD on physical pin5 at [1.1375, -0.95], matching the manufacturer function and position.

U_LDO_EN VERDICT: PASS
Measured native pads:5; physical identities:5; distinct positions:5; expected pins:5; EP:0; aliases:0.
Primary: projects/crow-audio-carrier-v1/02_parts/74LVC1G14GV,125/74LVC1G14_Rev19.pdf
SHA256: b8f37c700d0fc8374de6d14f0e2caf310c34b480ffab9d63c69bb3b6defbebbf
Figure: PDF p3 section7.1 GV figure aaa-035749/Table3; p11 Fig13 SOT753.
U_LDO_EN pin 1 (NC): expected unconnected terminal; observed unconnected-(U_LDO_EN-NC-Pad1) on physical pin1 at [-1.1375, -0.95], matching the manufacturer function and position.
U_LDO_EN pin 2 (A): expected logic data input; observed DUMP_GATE on physical pin2 at [-1.1375, 0.0], matching the manufacturer function and position.
U_LDO_EN pin 3 (GND): expected ground (0V); observed GND on physical pin3 at [-1.1375, 0.95], matching the manufacturer function and position.
U_LDO_EN pin 4 (Y): expected logic output; observed LDO_EN on physical pin4 at [1.1375, 0.95], matching the manufacturer function and position.
U_LDO_EN pin 5 (VCC): expected supply rail; observed 5V_LDO_HOLD on physical pin5 at [1.1375, -0.95], matching the manufacturer function and position.

U_OE VERDICT: PASS
Measured native pads:5; physical identities:5; distinct positions:5; expected pins:5; EP:0; aliases:0.
Primary: projects/crow-audio-carrier-v1/02_parts/74LVC1G14GV,125/74LVC1G14_Rev19.pdf
SHA256: b8f37c700d0fc8374de6d14f0e2caf310c34b480ffab9d63c69bb3b6defbebbf
Figure: PDF p3 section7.1 GV figure aaa-035749/Table3; p11 Fig13 SOT753.
U_OE pin 1 (NC): expected unconnected terminal; observed unconnected-(U_OE-NC-Pad1) on physical pin1 at [-1.1375, -0.95], matching the manufacturer function and position.
U_OE pin 2 (A): expected logic data input; observed TDM_SENSE_G on physical pin2 at [-1.1375, 0.0], matching the manufacturer function and position.
U_OE pin 3 (GND): expected ground (0V); observed GND on physical pin3 at [-1.1375, 0.95], matching the manufacturer function and position.
U_OE pin 4 (Y): expected logic output; observed TDM_OE_N on physical pin4 at [1.1375, 0.95], matching the manufacturer function and position.
U_OE pin 5 (VCC): expected supply rail; observed 3V3_ADC on physical pin5 at [1.1375, -0.95], matching the manufacturer function and position.

U_TDM VERDICT: PASS
Measured native pads:5; physical identities:5; distinct positions:5; expected pins:5; EP:0; aliases:0.
Primary: projects/crow-audio-carrier-v1/02_parts/SN74LVC1G125DBVR/SN74LVC1G125_SCES223U.pdf
SHA256: 65afa3f9d879b37cb8be507caf84804b24bceeb2e0782ba449fff72160994e4c
Figure: PDF p3 section4 DBV TOP VIEW and Pin Functions table.
U_TDM pin 1 (OE_N): expected active-low output-enable input; observed TDM_OE_N on physical pin1 at [-1.1375, -0.95], matching the manufacturer function and position.
U_TDM pin 2 (A): expected logic data input; observed TDM_CLEAN on physical pin2 at [-1.1375, 0.0], matching the manufacturer function and position.
U_TDM pin 3 (GND): expected ground (0V); observed GND on physical pin3 at [-1.1375, 0.95], matching the manufacturer function and position.
U_TDM pin 4 (Y): expected logic output; observed TDM_BUFFERED on physical pin4 at [1.1375, 0.95], matching the manufacturer function and position.
U_TDM pin 5 (VCC): expected supply rail; observed 3V3_ADC on physical pin5 at [1.1375, -0.95], matching the manufacturer function and position.

U_TDM_SCH VERDICT: PASS
Measured native pads:5; physical identities:5; distinct positions:5; expected pins:5; EP:0; aliases:0.
Primary: projects/crow-audio-carrier-v1/02_parts/74LVC1G17GV,125/74LVC1G17.pdf
SHA256: 3db133d57486306950ba1140ac13a8a0ea95509dcefb88db36c08423a819b163
Figure: PDF p3 section6.1 GV figure aaa-035749/Table3; p11 Fig11 SOT753.
U_TDM_SCH pin 1 (NC): expected unconnected terminal; observed unconnected-(U_TDM_SCH-NC-Pad1) on physical pin1 at [-1.1375, -0.95], matching the manufacturer function and position.
U_TDM_SCH pin 2 (A): expected logic data input; observed TDM_RAW on physical pin2 at [-1.1375, 0.0], matching the manufacturer function and position.
U_TDM_SCH pin 3 (GND): expected ground (0V); observed GND on physical pin3 at [-1.1375, 0.95], matching the manufacturer function and position.
U_TDM_SCH pin 4 (Y): expected logic output; observed TDM_CLEAN on physical pin4 at [1.1375, 0.95], matching the manufacturer function and position.
U_TDM_SCH pin 5 (VCC): expected supply rail; observed 3V3_ADC on physical pin5 at [1.1375, -0.95], matching the manufacturer function and position.

Nexperia NC pads carry the per-pad autogenerated unconnected-(REF-NC-Pad1) identifier, not a functional circuit net; these are treated as explicit unconnected markers in this dossier. This review does not infer broader board connectivity from net names.

Symmetry: U_DUMP/U_LDO_EN/U_OE all preserve NC,input,GND,output,VCC on pins1..5. U_DUMP and U_LDO_EN use the same 5V_LDO_HOLD rail; U_OE uses3V3_ADC, the same supply function. U_DUMP.Y=DUMP_GATE feeds U_LDO_EN.A=DUMP_GATE; U_OE.Y=TDM_OE_N feeds U_TDM.OE_N=TDM_OE_N. U_TDM_SCH.Y=TDM_CLEAN feeds U_TDM.A=TDM_CLEAN. The inspected mappings have no swapped input/output/power/ground identities. These checks establish pin-function sanity, not analog thresholds, timing, drive strength, power sequencing, or external gate/load counts, which are outside this pin-review packet.

Unresolved engineering findings: none within commissioned pin-review scope. All five commissioned refs PASS, hence scoped SOUND. DO-NOT-ORDER remains mandatory for this pre-route review.
