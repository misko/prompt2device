from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib,json,shutil,tarfile

S=Path(__file__).parent
R=S.parents[3]
O=S.parent/'outputs'
E=json.loads((S.parent/'envelope.json').read_text())
digest=lambda b:hashlib.sha256(b).hexdigest()
checks=[]
for row in E['input_packet']:
    b=(R/row['path']).read_bytes()
    checks.append({'path':row['path'],'size':len(b),'sha256':digest(b),'pass':len(b)==row['size'] and digest(b)==row['sha256']})
assert all(row['pass'] for row in checks)
(S/'inputs-after.json').write_text(json.dumps(checks,indent=2)+'\n')
for name in ['TASK.md','pin-review-protocol.md','preflight.py']:
    shutil.copyfile(R/name,S/name)
shutil.copyfile(S.parent/'envelope.json',S/'envelope.json')
findings=json.loads((S/'measured-findings.json').read_text())
primary={'path':E['input_packet'][-1]['path'],'sha256':E['input_packet'][-1]['sha256'],'size':E['input_packet'][-1]['size'],'pages':{'3':'Section 5 DRL Package, 5-Pin SOT, Top View and Pin Functions','4':'Section 6.3 recommended operating conditions; section 6.5 asymmetric clamp characteristics','8':'Section 7.2 Functional Block Diagram','17':'DRL0005A PACKAGE OUTLINE 4220753/E 11/2024','18':'DRL0005A EXAMPLE BOARD LAYOUT 4220753/E 11/2024'}}
methods=[
 'Verified every envelope input by exact SHA-256 and size before engineering and after engineering; evidence retains both receipts.',
 'Used /usr/bin/pdftotext -layout on exact selected PDF for page location and support. Engineering pinout derived from actual rendered images, not text.',
 'Rendered PDF physical pages 3,8,17,18 at 120 DPI with /usr/bin/pdftoppm -png -r 120 -f P -l P PDF PREFIX and inspected each with view_image before reading dossiers. Recorded independent-datasheet-derivation.json before dossier access. Rendered and inspected p.4 after identifying audio-range question.',
 'Inspected all native dossiers. Ignored the dossier verification-note author conclusions as evidence; compared actual tabulated pads against independent primary derivation.',
 'Ran measure.py through shared pipeline_runtime.run_stage, finite 60-second direct argv /usr/bin/python3 -B, explicit scratch cwd and PATH=/usr/bin:/bin LANG=C.UTF-8 LC_ALL=C.UTF-8. PDF tools used same runner, timeout, cwd and environment. Raw stdout/stderr and runtime receipts retained.',
 'Recomputed all back-mount native-to-component-top coordinates and signed polygon area. Native top projection is mirrored by the required mount transform once only; manufacturer p.3 is explicitly TOP VIEW and receives zero further reflection.',
 'Native pad census is measured from the supplied native dossier tables, not independently re-extracted from a board; no live board, schematic, author rationale or other project file was inspected.',
 'Packaged retained images, dossiers, derivation, scripts, text, logs, runtime and input receipts. Reopened and hashed every regular archive member and rejected unsafe paths, duplicates, links and nested archives. Delivery preflight separately validates exact envelope.'
]
evidence={'review_stage':'pre-route','review_kind':'pin','reviewer':'/root/rj45_pin_carrier_esd_mountedframe1 (actual fresh agent)','context':'FRESH','verdict':'INCOMPLETE','order_verdict':'DO-NOT-ORDER','subject':E['subject'],'primary':primary,'methods':methods,'findings':findings,'measured_counts':{'refs':8,'native_pads':40,'unique_physical_identities':40,'exposed_pads':0,'aliases':0,'PASS':0,'FAIL':0,'QUESTION':8},'coverage':'U_ESD1,U_ESD2,U_ESD3,U_ESD4,U_ESD5,U_ESD6,U_ESD7,U_ESD8 only; no whole-board acceptance','engineering_finished_at':datetime.now(timezone.utc).isoformat(),'unresolved_findings':[{'ref':f['ref'],'detail':f['question']} for f in findings]}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
lines=[
 'review_stage: pre-route','review_kind: pin','reviewer: /root/rj45_pin_carrier_esd_mountedframe1 (actual fresh agent)','context: FRESH','design_verdict: INCOMPLETE','order_verdict: DO-NOT-ORDER',
 'board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de',
 'parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2',
 'design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7','',
 'Scope: U_ESD1 through U_ESD8 only. This is a pre-route pin review, not whole-board acceptance or an order authorization. Immutable hashes above are supplied subject bindings, not separately reviewed design conclusions.',
 '',f"Envelope subject: raw_sha256={E['subject']['raw_sha256']}; semantic_sha256={E['subject']['semantic_sha256']}.",
 '',f"Primary: TI TPD2E2U06 SLLSEG9C, exact supplied PDF SHA-256 {primary['sha256']}. Physical PDF pages 3, 4, 8, 17 and 18 were rendered and visually inspected; the appended DRL0005A package drawing is 4220753/E, 11/2024.",
 '', 'Independent package derivation: p.3 section 5 explicitly shows DRL top view: pin 1 upper-left, pin 2 middle-left, pin 3 lower-left, pin 4 lower-right, pin 5 upper-right; numerical order winds CCW. Three terminals lie on the left and two on the right. Pins 1/2 are NC, pin 3 IO1, pin 4 GND, pin 5 IO2. The manufacturer expressly allows NC floating, grounded or connected to VCC. Pages 17/18 show five distinct leads/lands, no exposed pad and no fused identities. The p.3 top view governs orientation; no bottom-view mirror was applied. The p.17 lower seating detail supports physical-lead census only. Page 8 section 7.2 shows equivalent protected IO channels with a distinct ground return.',
 '', 'Observed common geometry: all eight instances are explicitly back mounted on B.Cu. After undoing native rotation then applying y -> -y once, all five native positions reproduce each component-top table to floating-point tolerance. Component-top pin 1=(-0.7125,-0.5), 2=(-0.7125,0), 3=(-0.7125,+0.5), 4=(+0.7125,+0.5), 5=(+0.7125,-0.5) mm, with +x right/+y down. Area=-1.425 mm² in this screen-coordinate convention establishes physical CCW winding. Manufacturer top view matches without reflection. U_ESD1–4 have native rotation 0 degrees; U_ESD5–8 have 180 degrees. Rotation does not change the channel/pin mapping.',
 '', 'Land geometry observation: dossier lands are 0.68 x 0.35 mm with 1.425 mm opposing-center spacing and 0.5 mm pitch. Manufacturer p.18 example is 0.67 x 0.30 mm, 1.48 mm opposing-center spacing and 0.5 mm pitch. The small land-pattern differences do not change numbering or collapse identities; no claim of exact replication of the optional manufacturer example is made. Solder-process acceptance is outside this pin review.',
 '', 'Electrical limitation: page 4 section 6.3 specifies recommended IO voltage 0 to 5.5 V relative to GND. Page 8 section 7.2 and page 4 section 6.5 show an asymmetric ground-referenced clamp. AUDIO_P/AUDIO_N names establish audio-signal intent but supply no common-mode or full signal excursion. I cannot establish IO electrical compatibility solely from those names. This is a QUESTION, not evidence that the audio is bipolar or that a voltage limit is violated.',
 '', 'Measured total: eight instances, 40 native dossier pad rows, 40 distinct physical identities, zero exposed pads, zero aliases; 0 PASS / 0 FAIL / 8 QUESTION overall. Geometry, pin identity and structural instance symmetry pass individually for all refs. The missing operating-range fact keeps the commissioned domain INCOMPLETE.',''
]
for f in findings:
    ref=f['ref']; n=ref.replace('U_ESD','')
    lines += [f'{ref} — VERDICT: QUESTION',f"Measured native pads=5; distinct physical identities=5; exposed pads=0; aliases=0. Primary SHA-256 {primary['sha256']}; p.3 section 5 top-view figure and functions; p.17 DRL0005A outline; p.18 land example; p.4 section 6.3 and p.8 section 7.2.",f'{ref} pins 1..5 (package): expected five separate identities, 3 west/2 east, pin 1 upper-left, CCW top view, no EP; observed exactly these, with native/back-frame conversion verified.',f'{ref} pin 1 (NC): expected floating, GND or VCC permitted; observed isolated unconnected-({ref}-NC1-Pad1).',f'{ref} pin 2 (NC): expected floating, GND or VCC permitted; observed isolated unconnected-({ref}-NC2-Pad2).',f'{ref} pin 3 (IO1): expected protected signal within supported ground-referenced range; observed AUDIO_P{n}, signal type plausible but range unspecified — QUESTION.',f'{ref} pin 4 (GND): expected ground; observed GND — PASS.',f'{ref} pin 5 (IO2): expected protected signal within supported ground-referenced range; observed AUDIO_N{n}, signal type plausible but range unspecified — QUESTION.',f'{ref} symmetry: same ordered function/net kinds as all seven peers (NC, NC, AUDIO_Pn, GND, AUDIO_Nn); no per-instance divergence.',f"Missing fact: {f['question']}",'']
lines += ['Methods and evidence:'] + ['- '+m for m in methods] + ['','Delivery completion is separate from engineering acceptance: all eight refs received honest verdicts and retained evidence. result.json unresolved=[] denotes a complete handback; it does not close the electrical questions above.']
(O/'report.md').write_text('\n'.join(lines)+'\n')
(O/'result.json').write_text(json.dumps({'subject':E['subject'],'checks':{c:'PASS' for c in E['completion']['checks']},'unresolved':[]},indent=2)+'\n')
shutil.copyfile(O/'report.md',S/'report.md')
shutil.copyfile(O/'evidence.json',S/'evidence.json')
(S/'methods.json').write_text(json.dumps({'methods':methods,'primary':primary,'subprocess_commands':['/usr/bin/pdftotext -layout EXACT_PDF scratch/datasheet.txt']+[f'/usr/bin/pdftoppm -png -r 120 -f {p} -l {p} EXACT_PDF scratch/page{p}' for p in [3,8,17,18,4]]+['/usr/bin/python3 -B scratch/measure.py'],'bootstrap_reads':'TASK.md, envelope.json, supplied preflight.py and protocol were read directly through exec_command; shared runtime/artifact implementation was inspected only for delivery mechanics. Subsequent engineering subprocesses used run_stage.'},indent=2)+'\n')
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
    for p in sorted(S.rglob('*')):
        if not p.is_file() or p.name.startswith('preflight-final'):
            continue
        assert not p.is_symlink() and not p.name.endswith(('.tar','.tar.gz','.tgz'))
        tf.add(p,arcname=p.relative_to(S).as_posix(),recursive=False)
members=[];seen=set()
with tarfile.open(archive,'r:gz') as tf:
    for m in tf.getmembers():
        path=PurePosixPath(m.name)
        assert m.isfile() and not path.is_absolute() and '..' not in path.parts and m.name not in seen
        seen.add(m.name)
        b=tf.extractfile(m).read();assert len(b)==m.size
        members.append({'path':m.name,'size':len(b),'sha256':digest(b)})
ab=archive.read_bytes()
(O/'evidence-manifest.json').write_text(json.dumps({'archive_sha256':digest(ab),'archive_size':len(ab),'member_count':len(members),'members':members},indent=2)+'\n')
print(json.dumps({'verdict':'INCOMPLETE','archive_sha256':digest(ab),'members':len(members),'outputs':sorted(p.name for p in O.iterdir())}))
