review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_esd_mountedframe1 (actual fresh agent)
context: FRESH
design_verdict: INCOMPLETE
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

Scope: U_ESD1 through U_ESD8 only. This is a pre-route pin review, not whole-board acceptance or an order authorization. Immutable hashes above are supplied subject bindings, not separately reviewed design conclusions.

Envelope subject: raw_sha256=59988d7deb13ad8885e22a22a043d41f2d4ff57ee766d0e8a8f1c87268008dee; semantic_sha256=02b7c533a9467481a0b088934527333d82450198f8b2655af219e5ee71270669.

Primary: TI TPD2E2U06 SLLSEG9C, exact supplied PDF SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed. Physical PDF pages 3, 4, 8, 17 and 18 were rendered and visually inspected; the appended DRL0005A package drawing is 4220753/E, 11/2024.

Independent package derivation: p.3 section 5 explicitly shows DRL top view: pin 1 upper-left, pin 2 middle-left, pin 3 lower-left, pin 4 lower-right, pin 5 upper-right; numerical order winds CCW. Three terminals lie on the left and two on the right. Pins 1/2 are NC, pin 3 IO1, pin 4 GND, pin 5 IO2. The manufacturer expressly allows NC floating, grounded or connected to VCC. Pages 17/18 show five distinct leads/lands, no exposed pad and no fused identities. The p.3 top view governs orientation; no bottom-view mirror was applied. The p.17 lower seating detail supports physical-lead census only. Page 8 section 7.2 shows equivalent protected IO channels with a distinct ground return.

Observed common geometry: all eight instances are explicitly back mounted on B.Cu. After undoing native rotation then applying y -> -y once, all five native positions reproduce each component-top table to floating-point tolerance. Component-top pin 1=(-0.7125,-0.5), 2=(-0.7125,0), 3=(-0.7125,+0.5), 4=(+0.7125,+0.5), 5=(+0.7125,-0.5) mm, with +x right/+y down. Area=-1.425 mm² in this screen-coordinate convention establishes physical CCW winding. Manufacturer top view matches without reflection. U_ESD1–4 have native rotation 0 degrees; U_ESD5–8 have 180 degrees. Rotation does not change the channel/pin mapping.

Land geometry observation: dossier lands are 0.68 x 0.35 mm with 1.425 mm opposing-center spacing and 0.5 mm pitch. Manufacturer p.18 example is 0.67 x 0.30 mm, 1.48 mm opposing-center spacing and 0.5 mm pitch. The small land-pattern differences do not change numbering or collapse identities; no claim of exact replication of the optional manufacturer example is made. Solder-process acceptance is outside this pin review.

Electrical limitation: page 4 section 6.3 specifies recommended IO voltage 0 to 5.5 V relative to GND. Page 8 section 7.2 and page 4 section 6.5 show an asymmetric ground-referenced clamp. AUDIO_P/AUDIO_N names establish audio-signal intent but supply no common-mode or full signal excursion. I cannot establish IO electrical compatibility solely from those names. This is a QUESTION, not evidence that the audio is bipolar or that a voltage limit is violated.

Measured total: eight instances, 40 native dossier pad rows, 40 distinct physical identities, zero exposed pads, zero aliases; 0 PASS / 0 FAIL / 8 QUESTION overall. Geometry, pin identity and structural instance symmetry pass individually for all refs. The missing operating-range fact keeps the commissioned domain INCOMPLETE.

U_ESD1 — VERDICT: QUESTION
Measured native pads=5; distinct physical identities=5; exposed pads=0; aliases=0. Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; p.3 section 5 top-view figure and functions; p.17 DRL0005A outline; p.18 land example; p.4 section 6.3 and p.8 section 7.2.
U_ESD1 pins 1..5 (package): expected five separate identities, 3 west/2 east, pin 1 upper-left, CCW top view, no EP; observed exactly these, with native/back-frame conversion verified.
U_ESD1 pin 1 (NC): expected floating, GND or VCC permitted; observed isolated unconnected-(U_ESD1-NC1-Pad1).
U_ESD1 pin 2 (NC): expected floating, GND or VCC permitted; observed isolated unconnected-(U_ESD1-NC2-Pad2).
U_ESD1 pin 3 (IO1): expected protected signal within supported ground-referenced range; observed AUDIO_P1, signal type plausible but range unspecified — QUESTION.
U_ESD1 pin 4 (GND): expected ground; observed GND — PASS.
U_ESD1 pin 5 (IO2): expected protected signal within supported ground-referenced range; observed AUDIO_N1, signal type plausible but range unspecified — QUESTION.
U_ESD1 symmetry: same ordered function/net kinds as all seven peers (NC, NC, AUDIO_Pn, GND, AUDIO_Nn); no per-instance divergence.
Missing fact: What are minimum and maximum operating voltages relative to GND, including common-mode and full audio excursion, on AUDIO_P1 and AUDIO_N1? The dossier supplies names only; primary recommended VIO is 0 to 5.5 V (PDF p.4 section 6.3), with asymmetric ground-referenced clamp shown on p.8 section 7.2. Confirm compatibility before accepting IO1/IO2 electrical sanity. This is missing context, not a proved overvoltage or bipolar signal.

U_ESD2 — VERDICT: QUESTION
Measured native pads=5; distinct physical identities=5; exposed pads=0; aliases=0. Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; p.3 section 5 top-view figure and functions; p.17 DRL0005A outline; p.18 land example; p.4 section 6.3 and p.8 section 7.2.
U_ESD2 pins 1..5 (package): expected five separate identities, 3 west/2 east, pin 1 upper-left, CCW top view, no EP; observed exactly these, with native/back-frame conversion verified.
U_ESD2 pin 1 (NC): expected floating, GND or VCC permitted; observed isolated unconnected-(U_ESD2-NC1-Pad1).
U_ESD2 pin 2 (NC): expected floating, GND or VCC permitted; observed isolated unconnected-(U_ESD2-NC2-Pad2).
U_ESD2 pin 3 (IO1): expected protected signal within supported ground-referenced range; observed AUDIO_P2, signal type plausible but range unspecified — QUESTION.
U_ESD2 pin 4 (GND): expected ground; observed GND — PASS.
U_ESD2 pin 5 (IO2): expected protected signal within supported ground-referenced range; observed AUDIO_N2, signal type plausible but range unspecified — QUESTION.
U_ESD2 symmetry: same ordered function/net kinds as all seven peers (NC, NC, AUDIO_Pn, GND, AUDIO_Nn); no per-instance divergence.
Missing fact: What are minimum and maximum operating voltages relative to GND, including common-mode and full audio excursion, on AUDIO_P2 and AUDIO_N2? The dossier supplies names only; primary recommended VIO is 0 to 5.5 V (PDF p.4 section 6.3), with asymmetric ground-referenced clamp shown on p.8 section 7.2. Confirm compatibility before accepting IO1/IO2 electrical sanity. This is missing context, not a proved overvoltage or bipolar signal.

U_ESD3 — VERDICT: QUESTION
Measured native pads=5; distinct physical identities=5; exposed pads=0; aliases=0. Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; p.3 section 5 top-view figure and functions; p.17 DRL0005A outline; p.18 land example; p.4 section 6.3 and p.8 section 7.2.
U_ESD3 pins 1..5 (package): expected five separate identities, 3 west/2 east, pin 1 upper-left, CCW top view, no EP; observed exactly these, with native/back-frame conversion verified.
U_ESD3 pin 1 (NC): expected floating, GND or VCC permitted; observed isolated unconnected-(U_ESD3-NC1-Pad1).
U_ESD3 pin 2 (NC): expected floating, GND or VCC permitted; observed isolated unconnected-(U_ESD3-NC2-Pad2).
U_ESD3 pin 3 (IO1): expected protected signal within supported ground-referenced range; observed AUDIO_P3, signal type plausible but range unspecified — QUESTION.
U_ESD3 pin 4 (GND): expected ground; observed GND — PASS.
U_ESD3 pin 5 (IO2): expected protected signal within supported ground-referenced range; observed AUDIO_N3, signal type plausible but range unspecified — QUESTION.
U_ESD3 symmetry: same ordered function/net kinds as all seven peers (NC, NC, AUDIO_Pn, GND, AUDIO_Nn); no per-instance divergence.
Missing fact: What are minimum and maximum operating voltages relative to GND, including common-mode and full audio excursion, on AUDIO_P3 and AUDIO_N3? The dossier supplies names only; primary recommended VIO is 0 to 5.5 V (PDF p.4 section 6.3), with asymmetric ground-referenced clamp shown on p.8 section 7.2. Confirm compatibility before accepting IO1/IO2 electrical sanity. This is missing context, not a proved overvoltage or bipolar signal.

U_ESD4 — VERDICT: QUESTION
Measured native pads=5; distinct physical identities=5; exposed pads=0; aliases=0. Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; p.3 section 5 top-view figure and functions; p.17 DRL0005A outline; p.18 land example; p.4 section 6.3 and p.8 section 7.2.
U_ESD4 pins 1..5 (package): expected five separate identities, 3 west/2 east, pin 1 upper-left, CCW top view, no EP; observed exactly these, with native/back-frame conversion verified.
U_ESD4 pin 1 (NC): expected floating, GND or VCC permitted; observed isolated unconnected-(U_ESD4-NC1-Pad1).
U_ESD4 pin 2 (NC): expected floating, GND or VCC permitted; observed isolated unconnected-(U_ESD4-NC2-Pad2).
U_ESD4 pin 3 (IO1): expected protected signal within supported ground-referenced range; observed AUDIO_P4, signal type plausible but range unspecified — QUESTION.
U_ESD4 pin 4 (GND): expected ground; observed GND — PASS.
U_ESD4 pin 5 (IO2): expected protected signal within supported ground-referenced range; observed AUDIO_N4, signal type plausible but range unspecified — QUESTION.
U_ESD4 symmetry: same ordered function/net kinds as all seven peers (NC, NC, AUDIO_Pn, GND, AUDIO_Nn); no per-instance divergence.
Missing fact: What are minimum and maximum operating voltages relative to GND, including common-mode and full audio excursion, on AUDIO_P4 and AUDIO_N4? The dossier supplies names only; primary recommended VIO is 0 to 5.5 V (PDF p.4 section 6.3), with asymmetric ground-referenced clamp shown on p.8 section 7.2. Confirm compatibility before accepting IO1/IO2 electrical sanity. This is missing context, not a proved overvoltage or bipolar signal.

U_ESD5 — VERDICT: QUESTION
Measured native pads=5; distinct physical identities=5; exposed pads=0; aliases=0. Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; p.3 section 5 top-view figure and functions; p.17 DRL0005A outline; p.18 land example; p.4 section 6.3 and p.8 section 7.2.
U_ESD5 pins 1..5 (package): expected five separate identities, 3 west/2 east, pin 1 upper-left, CCW top view, no EP; observed exactly these, with native/back-frame conversion verified.
U_ESD5 pin 1 (NC): expected floating, GND or VCC permitted; observed isolated unconnected-(U_ESD5-NC1-Pad1).
U_ESD5 pin 2 (NC): expected floating, GND or VCC permitted; observed isolated unconnected-(U_ESD5-NC2-Pad2).
U_ESD5 pin 3 (IO1): expected protected signal within supported ground-referenced range; observed AUDIO_P5, signal type plausible but range unspecified — QUESTION.
U_ESD5 pin 4 (GND): expected ground; observed GND — PASS.
U_ESD5 pin 5 (IO2): expected protected signal within supported ground-referenced range; observed AUDIO_N5, signal type plausible but range unspecified — QUESTION.
U_ESD5 symmetry: same ordered function/net kinds as all seven peers (NC, NC, AUDIO_Pn, GND, AUDIO_Nn); no per-instance divergence.
Missing fact: What are minimum and maximum operating voltages relative to GND, including common-mode and full audio excursion, on AUDIO_P5 and AUDIO_N5? The dossier supplies names only; primary recommended VIO is 0 to 5.5 V (PDF p.4 section 6.3), with asymmetric ground-referenced clamp shown on p.8 section 7.2. Confirm compatibility before accepting IO1/IO2 electrical sanity. This is missing context, not a proved overvoltage or bipolar signal.

U_ESD6 — VERDICT: QUESTION
Measured native pads=5; distinct physical identities=5; exposed pads=0; aliases=0. Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; p.3 section 5 top-view figure and functions; p.17 DRL0005A outline; p.18 land example; p.4 section 6.3 and p.8 section 7.2.
U_ESD6 pins 1..5 (package): expected five separate identities, 3 west/2 east, pin 1 upper-left, CCW top view, no EP; observed exactly these, with native/back-frame conversion verified.
U_ESD6 pin 1 (NC): expected floating, GND or VCC permitted; observed isolated unconnected-(U_ESD6-NC1-Pad1).
U_ESD6 pin 2 (NC): expected floating, GND or VCC permitted; observed isolated unconnected-(U_ESD6-NC2-Pad2).
U_ESD6 pin 3 (IO1): expected protected signal within supported ground-referenced range; observed AUDIO_P6, signal type plausible but range unspecified — QUESTION.
U_ESD6 pin 4 (GND): expected ground; observed GND — PASS.
U_ESD6 pin 5 (IO2): expected protected signal within supported ground-referenced range; observed AUDIO_N6, signal type plausible but range unspecified — QUESTION.
U_ESD6 symmetry: same ordered function/net kinds as all seven peers (NC, NC, AUDIO_Pn, GND, AUDIO_Nn); no per-instance divergence.
Missing fact: What are minimum and maximum operating voltages relative to GND, including common-mode and full audio excursion, on AUDIO_P6 and AUDIO_N6? The dossier supplies names only; primary recommended VIO is 0 to 5.5 V (PDF p.4 section 6.3), with asymmetric ground-referenced clamp shown on p.8 section 7.2. Confirm compatibility before accepting IO1/IO2 electrical sanity. This is missing context, not a proved overvoltage or bipolar signal.

U_ESD7 — VERDICT: QUESTION
Measured native pads=5; distinct physical identities=5; exposed pads=0; aliases=0. Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; p.3 section 5 top-view figure and functions; p.17 DRL0005A outline; p.18 land example; p.4 section 6.3 and p.8 section 7.2.
U_ESD7 pins 1..5 (package): expected five separate identities, 3 west/2 east, pin 1 upper-left, CCW top view, no EP; observed exactly these, with native/back-frame conversion verified.
U_ESD7 pin 1 (NC): expected floating, GND or VCC permitted; observed isolated unconnected-(U_ESD7-NC1-Pad1).
U_ESD7 pin 2 (NC): expected floating, GND or VCC permitted; observed isolated unconnected-(U_ESD7-NC2-Pad2).
U_ESD7 pin 3 (IO1): expected protected signal within supported ground-referenced range; observed AUDIO_P7, signal type plausible but range unspecified — QUESTION.
U_ESD7 pin 4 (GND): expected ground; observed GND — PASS.
U_ESD7 pin 5 (IO2): expected protected signal within supported ground-referenced range; observed AUDIO_N7, signal type plausible but range unspecified — QUESTION.
U_ESD7 symmetry: same ordered function/net kinds as all seven peers (NC, NC, AUDIO_Pn, GND, AUDIO_Nn); no per-instance divergence.
Missing fact: What are minimum and maximum operating voltages relative to GND, including common-mode and full audio excursion, on AUDIO_P7 and AUDIO_N7? The dossier supplies names only; primary recommended VIO is 0 to 5.5 V (PDF p.4 section 6.3), with asymmetric ground-referenced clamp shown on p.8 section 7.2. Confirm compatibility before accepting IO1/IO2 electrical sanity. This is missing context, not a proved overvoltage or bipolar signal.

U_ESD8 — VERDICT: QUESTION
Measured native pads=5; distinct physical identities=5; exposed pads=0; aliases=0. Primary SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; p.3 section 5 top-view figure and functions; p.17 DRL0005A outline; p.18 land example; p.4 section 6.3 and p.8 section 7.2.
U_ESD8 pins 1..5 (package): expected five separate identities, 3 west/2 east, pin 1 upper-left, CCW top view, no EP; observed exactly these, with native/back-frame conversion verified.
U_ESD8 pin 1 (NC): expected floating, GND or VCC permitted; observed isolated unconnected-(U_ESD8-NC1-Pad1).
U_ESD8 pin 2 (NC): expected floating, GND or VCC permitted; observed isolated unconnected-(U_ESD8-NC2-Pad2).
U_ESD8 pin 3 (IO1): expected protected signal within supported ground-referenced range; observed AUDIO_P8, signal type plausible but range unspecified — QUESTION.
U_ESD8 pin 4 (GND): expected ground; observed GND — PASS.
U_ESD8 pin 5 (IO2): expected protected signal within supported ground-referenced range; observed AUDIO_N8, signal type plausible but range unspecified — QUESTION.
U_ESD8 symmetry: same ordered function/net kinds as all seven peers (NC, NC, AUDIO_Pn, GND, AUDIO_Nn); no per-instance divergence.
Missing fact: What are minimum and maximum operating voltages relative to GND, including common-mode and full audio excursion, on AUDIO_P8 and AUDIO_N8? The dossier supplies names only; primary recommended VIO is 0 to 5.5 V (PDF p.4 section 6.3), with asymmetric ground-referenced clamp shown on p.8 section 7.2. Confirm compatibility before accepting IO1/IO2 electrical sanity. This is missing context, not a proved overvoltage or bipolar signal.

Methods and evidence:
- Verified every envelope input by exact SHA-256 and size before engineering and after engineering; evidence retains both receipts.
- Used /usr/bin/pdftotext -layout on exact selected PDF for page location and support. Engineering pinout derived from actual rendered images, not text.
- Rendered PDF physical pages 3,8,17,18 at 120 DPI with /usr/bin/pdftoppm -png -r 120 -f P -l P PDF PREFIX and inspected each with view_image before reading dossiers. Recorded independent-datasheet-derivation.json before dossier access. Rendered and inspected p.4 after identifying audio-range question.
- Inspected all native dossiers. Ignored the dossier verification-note author conclusions as evidence; compared actual tabulated pads against independent primary derivation.
- Ran measure.py through shared pipeline_runtime.run_stage, finite 60-second direct argv /usr/bin/python3 -B, explicit scratch cwd and PATH=/usr/bin:/bin LANG=C.UTF-8 LC_ALL=C.UTF-8. PDF tools used same runner, timeout, cwd and environment. Raw stdout/stderr and runtime receipts retained.
- Recomputed all back-mount native-to-component-top coordinates and signed polygon area. Native top projection is mirrored by the required mount transform once only; manufacturer p.3 is explicitly TOP VIEW and receives zero further reflection.
- Native pad census is measured from the supplied native dossier tables, not independently re-extracted from a board; no live board, schematic, author rationale or other project file was inspected.
- Packaged retained images, dossiers, derivation, scripts, text, logs, runtime and input receipts. Reopened and hashed every regular archive member and rejected unsafe paths, duplicates, links and nested archives. Delivery preflight separately validates exact envelope.

Delivery completion is separate from engineering acceptance: all eight refs received honest verdicts and retained evidence. result.json unresolved=[] denotes a complete handback; it does not close the electrical questions above.
