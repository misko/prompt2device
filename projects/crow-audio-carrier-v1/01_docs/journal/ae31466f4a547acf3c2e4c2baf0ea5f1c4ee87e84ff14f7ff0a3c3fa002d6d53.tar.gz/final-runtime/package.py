from pathlib import Path,PurePosixPath
import sys,json,hashlib,tarfile
sys.path.insert(0,"/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts")
from pipeline_execution import TaskEnvelope,verify_input_packet
S=Path(__file__).parent;R=S.parents[3];O=S.parent/'outputs'
e=TaskEnvelope.from_json((S.parent/'envelope.json').read_text())
v=verify_input_packet(e,R);assert v[0],v
(S/'inputs-after.json').write_text(json.dumps({'verification':v,'inputs':json.loads((S.parent/'envelope.json').read_text())['input_packet']},indent=2))
result={'subject':e.subject.to_mapping(),'checks':{'inputs-verified':'PASS','review-complete':'PASS','evidence-complete':'PASS'},'unresolved':[]}
(O/'result.json').write_text(json.dumps(result,indent=2))
files=[]
for p in sorted(S.rglob('*')):
 if p.is_symlink():raise ValueError('symlink')
 if p.is_file() and not p.name.startswith('final_preflight') and p.suffix not in ('.gz','.tar'):
  files.append((p,p.relative_to(S).as_posix()))
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p,n in files:t.add(p,arcname=n,recursive=False)
records=[];seen=set()
with tarfile.open(archive,'r:gz') as t:
 for member in t.getmembers():
  n=member.name;p=PurePosixPath(n)
  assert member.isfile() and not member.issym() and not member.islnk()
  assert not p.is_absolute() and '..' not in p.parts and n not in seen
  assert not n.endswith(('.tar','.tar.gz','.tgz','.zip'))
  seen.add(n);data=t.extractfile(member).read();assert len(data)==member.size
  original=(S/n).read_bytes();assert data==original
  records.append({'path':n,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
assert len(records)==len(files)
manifest={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_size':archive.stat().st_size,'member_count':len(records),'members':records}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2))
assert verify_input_packet(e,R)[0]
print(json.dumps({'archive':str(archive),'sha256':manifest['archive_sha256'],'member_count':len(records),'input_verification':'PASS','all_members_reopened':'PASS'}))
