review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_headers_mountedframe1 (actual fresh agent)
context: FRESH
design_verdict: INCOMPLETE
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

Coverage is limited to commissioned J10, J11, and J9. This is not whole-board acceptance. Subject bindings above are immutable metadata, not independently reviewed conclusions. No electrical/package defect is demonstrated; missing physical and mating-interface evidence prevents SOUND.

Method: verified all eight envelope inputs, rendered the two exact digest-selected primary PDFs using pdftoppm, inspected their actual figure images with view_image, and recorded primary-first-derivation.json before reading dossiers. Compared the manufacturer-derived identities against every native dossier row; computed row counts, component-top rotation, and native coordinate transforms in measurements.json. No schematic, design history, other sources, or live project engineering files were consulted. These are counts measured from frozen native dossiers, not a fresh parse of the PCB.

Primary documents:
- Samtec TMM-Series_RevAS.pdf, SHA-256 66d9ffaa15ef8ff9b1614640d81fd2d1c2c6629b522df0cddc64acac3e73efc3; PDF page 1, printed sheet 1 of 2, FIG. 1 upper plan and post/tail elevation, -D end view and ordering field. The supplied PDF contains this one page.
- Molex Molex_436501000_SD_revD8.pdf, SHA-256 b8942b95bc3fe4c02171de9e714d99b2688055e249ba1524e3c2a8c3cf78eaa3; PDF page 1, SD-43650-001 revision D8, PCB LAYOUT: COMPONENT SIDE, PCB LAYOUT: 2 CKT, front mating view, 02-circuit order-code row.

All three dossiers explicitly state front mounting and component-top coordinates (+x right, +y down). No mounting reflection is required. The native board transform for the stated KiCad 90-degree rotations is (X,Y)=(originX+localY, originY-localX); every one of 26 electrical rows agrees.

J10 VERDICT: QUESTION
J10 package subcheck: PASS. Expected 12 separate electrical terminals (six positions, double row); observed 12 native numbered pad rows, 12 unique identities 1..12, 12 distinct locations. Expected/observed EP=0; no fused pin aliases or collapsed identities.
J10 pins 1..12 (physical identity): FIG. 1 upper mating-post plan places double-row pin 1 at lower left, pin 2 immediately above, pin 3 one 2 mm column to the right of pin 1, continuing odd/even pairs. The adjacent elevation distinguishes mating posts above the housing from PCB tails below; the lower opposite plan is not used as a top view. With pin 1 as origin, manufacturer odd/even coordinates are (2k,0)/(2k,-2). A clockwise 90-degree rotation gives (0,2k)/(2,2k), exactly the dossier for all six pairs. No mirror is applied. The dossier's computed CW is not a valid perimeter-winding characterization of zigzag connector numbering; identity-by-identity comparison establishes the match. Dossier N/S labels split the long array and are not manufacturer package-side designations.
J10 pins 1,3,4,5,6,7,8 (passive contacts): expected independently usable terminals; observed individual unconnected-(J10-NC*-Pad*) nets. These are application-unused contacts, not manufacturer NC pins; no manufacturer NC prohibition is violated.
J10 pin 2 (ROW1_COL2): expected a passive contact with no manufacturer ADC assignment; observed ADC_TDM. QUESTION: supplied sources do not establish the mating module's physical contact-to-signal allocation.
J10 pin 9 (ROW5_COL1): expected a passive contact with no manufacturer clock assignment; observed MCH_MCLK. Same missing mating-interface evidence.
J10 pin 10 (ROW5_COL2): expected a passive contact with no manufacturer clock assignment; observed MCH_BCLK. Same missing mating-interface evidence.
J10 pin 11 (ROW6_COL1): expected a passive contact with no manufacturer ground assignment; observed GND. Same missing mating-interface evidence.
J10 pin 12 (ROW6_COL2): expected a passive contact with no manufacturer clock assignment; observed MCH_FSYNC. Same missing mating-interface evidence.
Required fact: authoritative mating-module connector pinout for this header, with mating/view orientation and explicit physical pin identities.

J11 VERDICT: QUESTION
J11 package subcheck: PASS. Expected 12 separate terminals; observed 12 native numbered pad rows, 12 unique identities 1..12, 12 distinct locations. Expected/observed EP=0; no fused aliases or collapsed identities. The same manufacturer-derived clockwise 90-degree rotation matches all 12 local pad positions. Same front-mounted frame and zigzag-numbering qualification as J10.
J11 pin 1 (ROW1_COL1): expected a passive contact with no manufacturer ground allocation; observed GND. QUESTION: supplied sources do not establish the mating module's physical contact-to-signal allocation.
J11 pin 2 (ROW1_COL2): expected a passive contact with no manufacturer supply/sense allocation; observed MCH_3V3_SENSE. Same missing mating-interface evidence; the rail-like name alone does not prove the counterpart contact or voltage direction.
J11 pins 3..12 (passive contacts): expected separate usable terminals; observed individually unconnected-(J11-NC*-Pad*) nets. No physical pin is deleted and no manufacturer NC prohibition applies.
J10/J11 symmetry: all same-numbered pins have identical local geometry and generic ROW functions. Net roles diverge at pins 1,2,9,10,11,12: unused/GND, ADC_TDM/MCH_3V3_SENSE, MCH_MCLK/unused, MCH_BCLK/unused, GND/unused, MCH_FSYNC/unused respectively. Such differences can be valid for two independent connector ports, but a component drawing cannot demonstrate that intended port mapping. QUESTION is retained rather than assuming symmetry or declaring a defect.
Required fact: authoritative mating-module pinouts identifying both port roles and their corresponding physical header pins.

J9 VERDICT: QUESTION
J9 count subcheck: expected 2 distinct electrical terminals and one separate locating peg for 43650-0200; observed 2 native numbered rows, 2 unique identities 1 and 2, 2 distinct electrical positions, and a textual count of 1 unnumbered paste/mechanical pad with no position, size, drill, or physical identity shown. Expected/observed EP=0; no fused electrical aliases. Total reported pad objects=3; only 2 have inspectable geometry. The unnumbered count does not prove the required peg hole exists correctly.
J9 pins 1,2 (physical contacts): the primary drawing explicitly labels its PCB layout COMPONENT SIDE. Its 2 CKT layout has circuit 1 on the right, circuit 2 on the left, 3.00 mm apart, and a single central locating hole below the contact row. With primary circuit 1 at (0,0), circuit 2=(-3,0) and peg=(-1.50,+4.32). A permitted 180-degree rotation predicts dossier pin 1=(0,0), pin 2=(+3,0), peg=(+1.50,-4.32). The electrical rows match this rotation, but an impermissible mirror could also match those two collinear points while putting the peg at (+1.50,+4.32). Because the dossier omits the mechanical geometry, the alternatives cannot be distinguished. Two collinear pins establish no winding; this is QUESTION, not a proven mirror FAIL.
J9 pin 1 (+12V_IN): expected an independent passive circuit 1 contact, with no manufacturer voltage assignment; observed function +12V_IN on net 12V_IN. Internally sensible, but harness polarity is not independently established by this drawing.
J9 pin 2 (GND): expected an independent passive circuit 2 contact, with no manufacturer ground assignment; observed function GND on net GND. Internally sensible, but harness polarity is not independently established by this drawing.
Required facts: native component-top coordinates and physical type/drill for the omitted locating pad, plus connector housing/mating direction tied to that geometry; authoritative harness contact/polarity mapping to confirm electrical allocation.

Final domain verdict: INCOMPLETE. J10 QUESTION; J11 QUESTION; J9 QUESTION. Engineering questions are delivered findings, not missing handback outputs. Delivery PASS, if validated, does not authorize manufacture or establish electrical correctness.
