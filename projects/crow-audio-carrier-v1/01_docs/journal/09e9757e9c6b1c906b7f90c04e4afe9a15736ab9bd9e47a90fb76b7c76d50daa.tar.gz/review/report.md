# RJ45 jack land and edge-silk source handback

**Local source proof succeeds. Candidate native pod DRC is 0 violations / 58 unconnected / 0 parity; all six intrinsic jack defects disappear under unchanged rules.** This is an unadopted source proposal, not routing, release or spending approval.

Exact envelope subject: raw `a73058f96dd6dd5fcf0a8c357d04292832fc166d061f6ef16b9ebb2efffe370c`, semantic `20ef52dd83c524880c61c74ea2af9db35294d63d6cc6f41c9967f5f515195b2a`. All 779 frozen inputs were SHA-256/size verified before work and reopened before packaging. Root remains sole live writer. Eight candidate files are under `source_candidate/` in the archive, with exact before images and full pre/post digests. Both footprint copies have candidate SHA-256 `71ddc2085058b171a232326aec8adfe5d13ea40cf5c974b4aa9bfd0fea528ec0`; prior SHA-256 `f3e61e214c92f7174cb1d608f9e1ae5d887262bece330875b2757f6c9a492d0f`.

## Manufacturer authority and project derivation

Visually read drawing p1: Wurth615008160221 revision001.003,2025-07-09. It specifies eight0.8mm signal drills, two3.18mm NPTH, two1×2mm shield slots, signal row spacing4mm/same-row pitch2.04mm/stagger1.02mm, NPTH spacing13.7mm and shield spacing14.8mm. The source-coordinate shell/NPTH centre differences are0.55mm across and3.05mm along the slot. The complete hole/slot pattern, orientations and centres, signal pads1–8, shell pin mapping9/10, nets, F.Fab body, courtyard, model/path/registration and locked0.50mm mouth exposure are unchanged. Both model byte hashes remain `3f902b89d4bd756b121be056782deff312efb127c9c48f2c798ebd6db0e59f49`. Native pad records and preserved source blocks independently establish these invariants.

Shell copper ovals9/10 change from3×1.5mm to2.5×1.5mm at270°, around the same2×1mm oval slots. Copper and slot capsules now have equal1.0mm centreline length; their radii differ by0.25mm, so the nominal annulus is uniformly0.25mm. The previous minimum0.25mm remains, while long-end annulus falls0.50→0.25mm. Automatic mask openings follow the pad lands; no separate mask override changes. This derived land is expressly project-owned; the drawing does not publish it.

Nominal NPTH-to-land gap = sqrt(0.55² + [3.05 − (L−1.5)/2]²) −0.75−1.59mm. Original L=3 gives0.024846718mm; candidate L=2.5 gives0.268639492mm. Candidate nominal margin above existing0.25mm floor is0.018639492mm. Independent native effective-shape collision bisection returns original[0.024846,0.024847]mm and candidate[0.268639,0.268640]mm for both physical pairs. Native collision at0.25mm changes true→false. These are nominal artwork distances, not a claim of manufactured tolerance or qualified solder strength.

At local boardedge y=−5.86mm, forward side-silk endpoints stop at−5.50mm. With0.12mm strokes, ink remains0.30mm inside the edge. The horizontal outboard mouth line at−6.47mm and marker at−6.945mm are omitted. Rear/side silk remains; full body/pin-one F.Fab and courtyard remain. The generated pinmap and pin1 rectangular land provide identity. `raw/land-silk-comparison.png` shows intended geometry. Reference placement still uses the stock generator. No connector/caption/anchor/exposure change was made by this owner.

## Exact local proof

The frozen current pod source was copied into isolated workspaces; only the accepted-for-local-proof frozen floorplan proposal was overlaid, followed by the candidate footprint and dossier. A board was generated normally from the current netlist, then stock rules were generated and native `kicad-cli pcb drc --severity-all --refill-zones --schematic-parity --format json` ran. No old PCB was copied. Both boards have0tracks. Stock rules retire an old unused pad_rescue_stubs rule automatically in both fixtures; the final DRU files and complete board design settings, severity map and exclusions are identical between known-bad and candidate. The hole floor stays0.25mm; hole-to-hole0.5mm; minimum native silk clearance stays0.0mm and severity-all includes warnings.

| Check | Observed result |
|---|---|
| Fresh original known-bad generation and native DRC |6violations/58unconnected/0parity;4hole-clearance rows from2pairs×2layers, plus2edge-silk rows|
| Unchanged placement_drc_check on known-bad |FAIL, correctly detects0.0248mm against0.25mm and both crossing silk lines|
| Candidate1 generation |PASS28asserts;40parts/4holes;109copperpads;0pad/courtyard collisions;32/32owned silk refs;0crowded captions|
| Candidate native DRC and placement checker |0violations/58unconnected/0parity; P-DRC PASS|
| Count/parity and pinmap |4/4source pairs over40refs;38declared physical pins on4multi-pin refs|
| Placement feasibility |7/7PASS or N-A, local receipt only|
| Model coverage |32/32 fitted footprints have resolvable models|
| Pad separation |PASS0.127mm floor,5224inter-footprint pad pairs/7822paste-copper pairs|
| Placement policy and RF |4PASS/1N-A;RF explicit N-A|

Every native violation and all58unconnected rows from each fixture are individually preserved with native UUIDs, endpoint descriptions and coordinates in `raw/drc-classification.json`. No row is summarized as congestion or waived. Native CLI rc0 denotes report generation; the zero-track candidate is not final DRC0/0/0. No carrier board was regenerated: its independently changing fuse placement is outside this task. Identical footprint bytes and unchanged model/body/hole authority transfer the intrinsic source correction; full carrier DRC still requires integration.

Only one footprint source revision was required. Initial frozen-script invocations failed because the input snapshot lacks fab_tiers.yaml. Their logs and outcomes, including downstream missing-board invocations, are retained. Stock live shared methods were read-only/hash-recorded and all frozen method matches were identical; that dependency repair reran the same source candidate successfully. An initial geometry figure helper lacked matplotlib; it was corrected to installed Pillow and retained. Its second schematic drawing represented pin1 as circular; the final picture now reads native rectangular pad shape, without any source/board change. Geometry measurements and native DRC were unaffected. The native API inspection command passed; its outer receipt serialization failed on a Path object, so the raw log is retained and the packaging report records that delivery-only error. Every engineering/native subprocess ran finite pipeline_runtime.run_stage with explicit cwd/environment and /usr/bin/python3 -B/PYTHONDONTWRITEBYTECODE=1 for Python.

## Source bindings and owed gates

Both part.yaml layout source/notes, primary-source-record.md and wurth/provenance.md now distinguish manufacturer hole/body/model authority from project-derived copper/silk, and record the calculation and exact candidate footprint/model hashes. Current connector_assemblies.yaml binds those cards by path only; current model_registration.yaml hashes the unchanged model. Search of current source/docs finds no old changed-file digest binding requiring an additional source edit. Generated checkpoint/review subjects necessarily become stale and must renew normally; historical sealed source is untouched. No additional source binding proposal is needed.

- Root review and adoption of eight exact source candidates into both projects as one integrated source batch with independently owned carrier fuse/solid U_ESD ground/pod endpoint proposals.
- Normal integrated generation and fresh electrical/human schematic/independent placement reviews on exact artifact; this local authoring geometry proof confers no downstream spend authority.
- Carrier full regeneration and native DRC with its independent fuse placement correction; only identical footprint-source geometry was proved here.
- Every one of 58 individually enumerated pod unconnected rows remains an unexecuted routing obligation after placement adoption.
- Routing acceptance, clamp-first prefixes, realized route lengths, final native DRC 0 violations/0 unconnected/0 parity, fabrication and release gates, and existing first-article qualification/order restrictions remain owed.

Evidence package prepared at 2026-09-12T22:08:05.513690+00:00. Final delivery checks certify complete honest handback separately from the engineering scope. Archive manifest records SHA-256, size and every regular member, and packaging independently reopens every member while rejecting symlinks, duplicates, traversal and nested archives. Provided preflight runs after packaging; its exact log is retained beside the allocated scratch. All child processes have ended. Scratch is retained for root review; no live repository/generated board, routing, git, release, checkpoint or review-adoption write occurred. LAYOUT001and the unrelated fuse search were not reopened.
