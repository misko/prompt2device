# Pin-review preparation

PREPARED, NOT REVIEWED. Exact source component identities projected into source-identity-index.csv solely to drive the maintained pin_audit.py extractor. This is not a fabrication/order BOM. Explicit --refs covers all333actual components, including default-skipped two/three-pin parts. Every58unique MPN resolved uniquely against the full live dossier tree, with its PDF selected by the declared SHA256. Board/source/part/PDF/output identities are in manifest.json.

No gate verdict, user orientation approval, review adoption or route permission is supplied. After the human orientation checkpoint, group fresh pin reviewers by a few part types per task, provide only the protocol/dossiers/exact PDFs, and retain all actual refs in the denominator. Other placement lenses remain separate.
