# pin dossier: U_ISO8  (TMUX2821DSGR)

- footprint: crow_audio_carrier:TI_DSG0008A_Exact
- board position: (136.5, 85.9) rot 180
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/TMUX2821DSGR/TMUX28xx_SCDS488.pdf
- part.yaml verification note: Primary pin-function table and exact orderable suffix; package land drawing visually inspected2026-09-07. See ADR0009 for modeled versus measured distinction.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-0.95,-0.75) | W | 0.5x0.25 | S1 | FILTER8P |
| 2 | (-0.95,-0.25) | W | 0.5x0.25 | D1 | ADC8P |
| 3 | (-0.95,+0.25) | W | 0.5x0.25 | SEL2 | AUDIO_EN |
| 4 | (-0.95,+0.75) | W | 0.5x0.25 | GND | GND |
| 5 | (+0.95,+0.75) | E | 0.5x0.25 | S2 | FILTER8N |
| 6 | (+0.95,+0.25) | E | 0.5x0.25 | D2 | ADC8N |
| 7 | (+0.95,-0.25) | E | 0.5x0.25 | SEL1 | AUDIO_EN |
| 8 | (+0.95,-0.75) | E | 0.5x0.25 | VDD | 5V_LDO_HOLD |
| 9 | (+0.00,+0.00) | center | 0.9x1.6 | GND | GND |

(2 unnumbered paste/mechanical pads not shown)
