# pin dossier: C_VMID1_470N  (CL10B474KA8NFNC)

- footprint: Capacitor_SMD:C_0603_1608Metric
- board position: (90.6, 65.7) rot 180
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/CL10B474KA8NFNC/Samsung_CL10B474KA8NFN_specsheet.pdf
- part.yaml verification note: CITED: exact CL10B474KA8NFNC/C318640 selection is 470nF +/-10%, 25V X7R in 0603; selected 2026-09-01.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-0.78,+0.00) | W | 0.9x0.95 | A | VMID1 |
| 2 | (+0.78,+0.00) | E | 0.9x0.95 | B | GND |
