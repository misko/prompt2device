# pin dossier: D_IN  (SMBJ15A)

- footprint: crow_audio_carrier:Littelfuse_SMBJ15A_SMB_Exact
- board position: (32.8, 82.3) rot 0
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/SMBJ15A/Littelfuse_SMBJ_v4_2025-07-04.pdf
- part.yaml verification note: CITED: official Littelfuse SMBJ table exact SMBJ15A row gives 15.0V VR, 16.7-18.5V VBR at 1mA, 24.4V VC and 24.6A IPP; read 2026-09-01.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-2.15,+0.00) | W | 2.5x2.3 | K | 12V_PROTECTED |
| 2 | (+2.15,+0.00) | E | 2.5x2.3 | A | GND |
