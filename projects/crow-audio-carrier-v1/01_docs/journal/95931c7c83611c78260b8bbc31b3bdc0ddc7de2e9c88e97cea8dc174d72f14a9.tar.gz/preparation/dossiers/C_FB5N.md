# pin dossier: C_FB5N  (GCM1555C1H681JA16D)

- footprint: Capacitor_SMD:C_0402_1005Metric
- board position: (36.0, 93.0) rot -90
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/GCM1555C1H681JA16D/Murata_GCM1555C1H681JA16-01A-EN.pdf
- part.yaml verification note: Exact Murata MPN/code/value/50V/C0G/0402 match read from the LCSC exact-product record on 2026-09-01.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-0.48,+0.00) | W | 0.56x0.62 | A | FB_N5 |
| 2 | (+0.48,+0.00) | E | 0.56x0.62 | B | OPA_N5 |
