# pin dossier: C_VMID2_4U7  (GRM188Z71C475KE21D)

- footprint: Capacitor_SMD:C_0603_1608Metric
- board position: (90.7, 76.1) rot 180
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/GRM188Z71C475KE21D/Murata_GRM188Z71C475KE21-01A.pdf
- part.yaml verification note: CITED: exact GRM188Z71C475KE21D/C389010 selection is 4.7uF +/-10%, 16V X7R in 0603; selected 2026-09-01.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-0.78,+0.00) | W | 0.9x0.95 | A | VMID2 |
| 2 | (+0.78,+0.00) | E | 0.9x0.95 | B | GND |
