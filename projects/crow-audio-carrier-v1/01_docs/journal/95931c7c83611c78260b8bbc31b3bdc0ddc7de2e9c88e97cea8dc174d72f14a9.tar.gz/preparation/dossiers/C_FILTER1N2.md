# pin dossier: C_FILTER1N2  (GRM2195C1H153JA01D)

- footprint: Capacitor_SMD:C_0805_2012Metric
- board position: (46.3, 53.5) rot 0
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/GRM2195C1H153JA01D/Murata_GRM2195C1H153JA01-01A-EN.pdf
- part.yaml verification note: Exact Murata MPN/code/value/50V/C0G/0805 match read from the LCSC exact-product record on 2026-09-01.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-0.95,+0.00) | W | 1.0x1.45 | A | FILTER1N |
| 2 | (+0.95,+0.00) | E | 1.0x1.45 | B | GND |
