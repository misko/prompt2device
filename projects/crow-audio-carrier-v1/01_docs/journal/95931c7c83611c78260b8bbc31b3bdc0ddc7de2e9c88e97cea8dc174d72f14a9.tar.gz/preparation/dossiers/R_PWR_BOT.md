# pin dossier: R_PWR_BOT  (RT0603BRD0710KL)

- footprint: Resistor_SMD:R_0603_1608Metric
- board position: (30.0, 56.7) rot 180
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/RT0603BRD0710KL/Yageo_RT_v17_20260212.pdf
- part.yaml verification note: Exact manufacturer/MPN/code/value/package identified from public catalog2026-09-07; public identity not allocation. Primary series evidence and applied deratings are stated in ADR0009.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-0.82,+0.00) | W | 0.8x0.95 | A | PWR_SENSE |
| 2 | (+0.82,+0.00) | E | 0.8x0.95 | B | GND |
