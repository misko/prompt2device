# pin dossier: C_HOLD1  (EEEFK1A471P)

- footprint: crow_audio_carrier:Panasonic_EEEFK1A471P_8x10.2_Exact
- board position: (59.0, 83.9) rot 0
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/EEEFK1A471P/Panasonic_FK_ABA0000C1181_20260210.pdf
- part.yaml verification note: CITED: official Panasonic FK catalog exact standard-product row EEEFK1A471P gives 470uF +/-20%, 10V, 8.0x10.2 mm size F, 47uA leakage, 160mohm maximum impedance and 600mArms ripple; standard land a=3.1, b=4.0, c=2.0 mm; reviewed 2026-09-01.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-3.55,+0.00) | W | 4.0x2.0 | POSITIVE | 5V_LDO_HOLD |
| 2 | (+3.55,+0.00) | E | 4.0x2.0 | NEGATIVE | GND |
