# pin dossier: Q_PRE_EN  (2N7002K-7)

- footprint: Package_TO_SOT_SMD:SOT-23
- board position: (39.9, 57.9) rot 0
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/2N7002K-7/2N7002K_DS30896_Rev20-2.pdf
- part.yaml verification note: CITED: Diodes DS30896 Rev. 20-2 pin configuration and equivalent-circuit top-view figures, PDF p.1, independently fix pin 1=G, pin 2=S, pin 3=D; re-read 2026-09-01.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-0.94,-0.95) | N | 1.48x0.6 | G | PWR_EN |
| 2 | (-0.94,+0.95) | S | 1.48x0.6 | S | GND |
| 3 | (+0.94,+0.00) | E | 1.48x0.6 | D | PRE_GATE |
