# pin dossier: R_CFG2  (RC0402FR-070RL)

- footprint: Resistor_SMD:R_0402_1005Metric
- board position: (84.5, 70.4) rot 180
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/RC0402FR-070RL/Yageo_RC0402FR-070RL_20260908.pdf
- part.yaml verification note: Exact YAGEO FR-series zero-ohm MPN/code/package match selected 2026-09-01; the JR suffix is not authored.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-0.51,+0.00) | W | 0.54x0.64 | A | CFG2 |
| 2 | (+0.51,+0.00) | E | 0.54x0.64 | B | 3V3_ADC |
