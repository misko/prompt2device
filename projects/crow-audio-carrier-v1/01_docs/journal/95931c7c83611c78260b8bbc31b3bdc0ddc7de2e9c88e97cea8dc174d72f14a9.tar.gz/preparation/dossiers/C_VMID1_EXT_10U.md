# pin dossier: C_VMID1_EXT_10U  (C0805C106K8RACTU)

- footprint: Capacitor_SMD:C_0805_2012Metric
- board position: (72.8, 78.2) rot 180
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/C0805C106K8RACTU/C0805C106K8RACTU_specsheet.pdf
- part.yaml verification note: CITED: exact active KEMET C0805C106K8RACTU is 10uF +/-10%, 10V X7R in 0805; selected 2026-09-01.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-0.95,+0.00) | W | 1.0x1.45 | A | VMID1_EXT |
| 2 | (+0.95,+0.00) | E | 1.0x1.45 | B | GND |
