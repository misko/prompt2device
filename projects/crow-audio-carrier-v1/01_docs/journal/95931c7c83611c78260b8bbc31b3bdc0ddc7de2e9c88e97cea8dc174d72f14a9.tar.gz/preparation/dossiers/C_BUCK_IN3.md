# pin dossier: C_BUCK_IN3  (12105C106K4Z2A)

- footprint: Capacitor_SMD:C_1210_3225Metric
- board position: (37.3, 69.5) rot 180
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/12105C106K4Z2A/Kyocera_AVX_12105C106K4Z2A_20260908.pdf
- part.yaml verification note: Exact Kyocera AVX MPN/code/package/value/voltage/dielectric match read from the LCSC exact-product record on 2026-09-01; effective capacitance remains governed by power_tree.yaml.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-1.48,+0.00) | W | 1.15x2.7 | A | 12V_BUCK_IN |
| 2 | (+1.48,+0.00) | E | 1.15x2.7 | B | GND |
