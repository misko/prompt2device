# pin dossier: C_BUCK_O3  (GRM32ER71A476KE15L)

- footprint: Capacitor_SMD:C_1210_3225Metric
- board position: (51.9, 72.9) rot 0
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/GRM32ER71A476KE15L/Murata_GRM32ER71A476KE15-04CA-EN.pdf
- part.yaml verification note: CITED: official Murata exact page reports in-production GRM32ER71A476KE15L, 47uF +/-10%, 10V, X7R, -55C to +125C and EIA 1210; read 2026-09-02.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-1.48,+0.00) | W | 1.15x2.7 | A | 5V_BUCK |
| 2 | (+1.48,+0.00) | E | 1.15x2.7 | B | GND |
