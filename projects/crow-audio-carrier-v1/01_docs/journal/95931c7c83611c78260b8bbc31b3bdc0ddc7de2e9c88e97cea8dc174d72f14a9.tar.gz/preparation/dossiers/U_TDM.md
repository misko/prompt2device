# pin dossier: U_TDM  (SN74LVC1G125DBVR)

- footprint: Package_TO_SOT_SMD:SOT-23-5
- board position: (154.0, 54.0) rot 0
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/SN74LVC1G125DBVR/SN74LVC1G125_SCES223U.pdf
- part.yaml verification note: CITED: TI SCES223U DBV top-view drawing and Pin Functions table, PDF p.3, fix pins 1=OE, 2=A, 3=GND, 4=Y and 5=VCC; Features, PDF p.1, and the Electrical Characteristics table, PDF p.6, fix Ioff partial-power-down/back-drive behavior. Physical behavior remains a first-article power-state test.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-1.14,-0.95) | W | 1.32x0.6 | OE_N | TDM_OE_N |
| 2 | (-1.14,+0.00) | W | 1.32x0.6 | A | TDM_CLEAN |
| 3 | (-1.14,+0.95) | W | 1.32x0.6 | GND | GND |
| 4 | (+1.14,+0.95) | E | 1.32x0.6 | Y | TDM_BUFFERED |
| 5 | (+1.14,-0.95) | E | 1.32x0.6 | VCC | 3V3_ADC |
