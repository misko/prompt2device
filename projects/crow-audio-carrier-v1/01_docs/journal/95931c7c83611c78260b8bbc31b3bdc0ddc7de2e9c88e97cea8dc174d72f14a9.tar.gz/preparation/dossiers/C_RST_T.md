# pin dossier: C_RST_T  (CL10B224KA8NNNC)

- footprint: Capacitor_SMD:C_0603_1608Metric
- board position: (122.6, 73.2) rot 90
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/CL10B224KA8NNNC/Samsung_CL10B224KA8NNN_specsheet.pdf
- part.yaml verification note: Exact MPN/code/value/package match selected 2026-09-01. A deliberately conservative screening allocation of -10% tolerance, -50% DC-bias loss, and -15% temperature loss leaves 84.15nF; this is not a manufacturer curve or a release performance claim.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-0.78,+0.00) | W | 0.9x0.95 | A | RESET_C |
| 2 | (+0.78,+0.00) | E | 0.9x0.95 | B | RESET_RC |
