# pin dossier: D_QIN_GS  (BZT52C12-7-F)

- footprint: Diode_SMD:D_SOD-123
- board position: (42.4, 71.0) rot 0
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/BZT52C12-7-F/BZT52_DS18004_Rev38-2.pdf
- part.yaml verification note: CITED part identity and polarity; exact clamp spread/current is retained as first-article screening.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-1.65,+0.00) | W | 0.9x1.2 | K | 12V_PROTECTED |
| 2 | (+1.65,+0.00) | E | 0.9x1.2 | A | Q_IN_GATE |
