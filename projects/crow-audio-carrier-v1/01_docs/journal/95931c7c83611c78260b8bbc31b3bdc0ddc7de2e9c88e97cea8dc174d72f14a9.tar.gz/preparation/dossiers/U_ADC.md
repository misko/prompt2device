# pin dossier: U_ADC  (CS5308P-DN)

- footprint: crow_audio_carrier:Cirrus_CS5308P_QFN48_6x6_P0.4_EP4.6
- board position: (96.0, 70.0) rot 0
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/CS5308P-DN/CS5308P_DS1314F1.pdf
- part.yaml verification note: CITED: Cirrus Logic DS1314F1 Figure 1-1 and Table 1-1, PDF pp.4-5, independently fix pins 1-48 and exposed paddle 49; re-read 2026-09-01.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-2.95,-2.20) | W | 0.8x0.2 | ADC_VMID1 | VMID1 |
| 2 | (-2.95,-1.80) | W | 0.8x0.2 | CONFIG1 | CFG1 |
| 3 | (-2.95,-1.40) | W | 0.8x0.2 | CONFIG2/HGC_SCK | CFG2 |
| 4 | (-2.95,-1.00) | W | 0.8x0.2 | CONFIG3/HGC_SDO | GND |
| 5 | (-2.95,-0.60) | W | 0.8x0.2 | VDD_A1 | 3V3_ADC |
| 6 | (-2.95,-0.20) | W | 0.8x0.2 | GND_A | GND |
| 7 | (-2.95,+0.20) | W | 0.8x0.2 | LDO_A_FILT | LDO_A_FILT |
| 8 | (-2.95,+0.60) | W | 0.8x0.2 | GND_A | GND |
| 9 | (-2.95,+1.00) | W | 0.8x0.2 | VDD_A2 | 3V3_ADC |
| 10 | (-2.95,+1.40) | W | 0.8x0.2 | CONFIG4/HGC_CS | CFG4 |
| 11 | (-2.95,+1.80) | W | 0.8x0.2 | CONFIG5 | CFG5 |
| 12 | (-2.95,+2.20) | W | 0.8x0.2 | ADC_VMID2 | VMID2 |
| 13 | (-2.20,+2.95) | S | 0.2x0.8 | IN5N | ADC5N |
| 14 | (-1.80,+2.95) | S | 0.2x0.8 | IN5P | ADC5P |
| 15 | (-1.40,+2.95) | S | 0.2x0.8 | IN6N | ADC6N |
| 16 | (-1.00,+2.95) | S | 0.2x0.8 | IN6P | ADC6P |
| 17 | (-0.60,+2.95) | S | 0.2x0.8 | ADC_FILT2N | GND |
| 18 | (-0.20,+2.95) | S | 0.2x0.8 | ADC_FILT2P | FILT2P |
| 19 | (+0.20,+2.95) | S | 0.2x0.8 | IN7N | ADC7N |
| 20 | (+0.60,+2.95) | S | 0.2x0.8 | IN7P | ADC7P |
| 21 | (+1.00,+2.95) | S | 0.2x0.8 | IN8N | ADC8N |
| 22 | (+1.40,+2.95) | S | 0.2x0.8 | IN8P | ADC8P |
| 23 | (+1.80,+2.95) | S | 0.2x0.8 | RESET | ADC_RESET_N |
| 24 | (+2.20,+2.95) | S | 0.2x0.8 | ASP_FSYNC | ADC_FSYNC |
| 25 | (+2.95,+2.20) | E | 0.8x0.2 | ASP_DOUT1 | TDM_RAW |
| 26 | (+2.95,+1.80) | E | 0.8x0.2 | ASP_DOUT2 | unconnected-(U_ADC-ASP_DOUT2_NC-Pad26) |
| 27 | (+2.95,+1.40) | E | 0.8x0.2 | ASP_DOUT3 | unconnected-(U_ADC-ASP_DOUT3_NC-Pad27) |
| 28 | (+2.95,+1.00) | E | 0.8x0.2 | ASP_DOUT4 | unconnected-(U_ADC-ASP_DOUT4_NC-Pad28) |
| 29 | (+2.95,+0.60) | E | 0.8x0.2 | ASP_BCLK | ADC_BCLK |
| 30 | (+2.95,+0.20) | E | 0.8x0.2 | GND_D | GND |
| 31 | (+2.95,-0.20) | E | 0.8x0.2 | VDD_IO | 3V3_ADC |
| 32 | (+2.95,-0.60) | E | 0.8x0.2 | LDO_D_FILT | LDO_D_FILT |
| 33 | (+2.95,-1.00) | E | 0.8x0.2 | VDD_D | LDO_D_FILT |
| 34 | (+2.95,-1.40) | E | 0.8x0.2 | MCLK | ADC_MCLK |
| 35 | (+2.95,-1.80) | E | 0.8x0.2 | SPI_SDO/I2C_SCL | GND |
| 36 | (+2.95,-2.20) | E | 0.8x0.2 | SPI_SCK | GND |
| 37 | (+2.20,-2.95) | N | 0.2x0.8 | SPI_SDI/I2C_SDA | GND |
| 38 | (+1.80,-2.95) | N | 0.2x0.8 | SPI_CS | 3V3_ADC |
| 39 | (+1.40,-2.95) | N | 0.2x0.8 | IN1N | ADC1N |
| 40 | (+1.00,-2.95) | N | 0.2x0.8 | IN1P | ADC1P |
| 41 | (+0.60,-2.95) | N | 0.2x0.8 | IN2N | ADC2N |
| 42 | (+0.20,-2.95) | N | 0.2x0.8 | IN2P | ADC2P |
| 43 | (-0.20,-2.95) | N | 0.2x0.8 | ADC_FILT1P | FILT1P |
| 44 | (-0.60,-2.95) | N | 0.2x0.8 | ADC_FILT1N | GND |
| 45 | (-1.00,-2.95) | N | 0.2x0.8 | IN3N | ADC3N |
| 46 | (-1.40,-2.95) | N | 0.2x0.8 | IN3P | ADC3P |
| 47 | (-1.80,-2.95) | N | 0.2x0.8 | IN4N | ADC4N |
| 48 | (-2.20,-2.95) | N | 0.2x0.8 | IN4P | ADC4P |
| 49 | (+0.00,+0.00) | center | 4.6x4.6 | EP | GND |

(9 unnumbered paste/mechanical pads not shown)
