# pin dossier: R_DUMP  (CRCW12061R00FKEAHP)

- footprint: Resistor_SMD:R_1206_3216Metric
- board position: (69.5, 78.5) rot 90
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/CRCW12061R00FKEAHP/CRCW_HP_20043_20260317.pdf
- part.yaml verification note: Primary pp1-3: CRCW1206 / 1R00 / F=1% / K=100ppm/K / EA reel / HP pulse-proof high-power. Public exact C844653 identity checked 2026-09-07; no stock/allocation or assembled-board pulse qualification claimed.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-1.46,+0.00) | W | 1.12x1.75 | A | 3V3_ADC |
| 2 | (+1.46,+0.00) | E | 1.12x1.75 | B | ADC_DUMP |
