# pin dossier: C_A2P  (R82DC4100DQ60J)

- footprint: Capacitor_THT:C_Rect_L7.2mm_W5.0mm_P5.00mm
- board position: (68.0, 36.4) rot -90
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/R82DC4100DQ60J/R82DC4100DQ60J_specsheet.pdf
- part.yaml verification note: CITED: official KEMET exact spec identifies active AEC-Q200 R82DC4100DQ60J as 1uF +/-5%, 63V stacked metallized PET, 5.00mm-pitch radial THT, body and lead dimensions above; read 2026-09-01.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (+0.00,+0.00) | W | 1.5x1.5 THT | A | AUDIO_P2 |
| 2 | (+5.00,+0.00) | E | 1.5x1.5 THT | B | BIAS_P2 |
