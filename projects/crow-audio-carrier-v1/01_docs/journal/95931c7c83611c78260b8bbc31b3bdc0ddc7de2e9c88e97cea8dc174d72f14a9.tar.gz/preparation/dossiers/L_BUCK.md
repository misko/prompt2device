# pin dossier: L_BUCK  (XGL4020-332MEC)

- footprint: crow_audio_carrier:Coilcraft_XGL4020_Exact
- board position: (47.0, 66.0) rot 0
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/XGL4020-332MEC/XGL4020_Document1529-3.pdf
- part.yaml verification note: CITED: Coilcraft Document 1529-1 exact row gives 3.3uH +/-20%, 34.0mOhm maximum DCR, 3.5A at 20% inductance drop and 6.6A at 40C rise; Document 1529-3 fixes the unchanged 2.37mm pad pitch with 0.98 x 3.4mm lands. Worst-case calculated AP63205 ripple is 0.856A and peak current is 2.428A at a 2A load.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-1.19,+0.00) | W | 0.98x3.4 | SW_DOT | BUCK_SW |
| 2 | (+1.19,+0.00) | E | 0.98x3.4 | OUT | 5V_BUCK |
