# pin dossier: F_IN  (2920L260/33DR)

- footprint: Fuse:Fuse_2920_7451Metric
- board position: (32.5, 77.0) rot 0
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/2920L260-33DR/Littelfuse_2920L_Promelec.pdf
- part.yaml verification note: CITED: Littelfuse 2025 electrical row and thermal table fix the numeric limits above; assembly suffix allocation remains OWED.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-3.39,+0.00) | W | 1.93x5.45 | PTC1 | 12V_IN |
| 2 | (+3.39,+0.00) | E | 1.93x5.45 | PTC2 | 12V_FUSED |
