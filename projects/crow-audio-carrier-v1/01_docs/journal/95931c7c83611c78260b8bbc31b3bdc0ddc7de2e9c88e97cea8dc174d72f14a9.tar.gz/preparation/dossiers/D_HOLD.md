# pin dossier: D_HOLD  (B340A-13-F)

- footprint: Diode_SMD:D_SMA
- board position: (50.4, 58.1) rot 0
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/B340A-13-F/B340A_DS30891_Rev19-2.pdf
- part.yaml verification note: Primary exact ordering, pin assignment and electrical table reopened2026-09-07; catalog exact identity only, not allocation.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-2.00,+0.00) | W | 2.5x1.8 | K | 5V_LDO_FEED |
| 2 | (+2.00,+0.00) | E | 2.5x1.8 | A | 5V_BUCK |
