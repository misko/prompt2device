# pin dossier: U_TDM_SCH  (74LVC1G17GV,125)

- footprint: Package_TO_SOT_SMD:SOT-23-5
- board position: (147.5, 52.0) rot 0
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/74LVC1G17GV,125/74LVC1G17.pdf
- part.yaml verification note: CITED: exact local Rev16 p3 GV/SOT753 figure aaa-035749 and Table3 visually reopened2026-09-08:1NC,2A,3GND,4Y,5VCC. p4Table4 L-to-L/H-to-H; p1 unlimited input rise/fall; p5-6 full-temperature static limits and discrete thresholds; p8-9 timing test conditions. Physical source acceptance remains owed.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-1.14,-0.95) | W | 1.32x0.6 | NC | unconnected-(U_TDM_SCH-NC-Pad1) |
| 2 | (-1.14,+0.00) | W | 1.32x0.6 | A | TDM_RAW |
| 3 | (-1.14,+0.95) | W | 1.32x0.6 | GND | GND |
| 4 | (+1.14,+0.95) | E | 1.32x0.6 | Y | TDM_CLEAN |
| 5 | (+1.14,-0.95) | E | 1.32x0.6 | VCC | 3V3_ADC |
