# pin dossier: C_ADC_CM5P  (GRM1555C1H102JA01D)

- footprint: Capacitor_SMD:C_0402_1005Metric
- board position: (93.0, 77.3) rot -90
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/GRM1555C1H102JA01D/GRM1555C1H102JA01-01A.pdf
- part.yaml verification note: Exact manufacturer/MPN/code/value/package identified from public catalog2026-09-07; public identity not allocation. Primary series evidence and applied deratings are stated in ADR0009.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-0.48,+0.00) | W | 0.56x0.62 | A | ADC5P |
| 2 | (+0.48,+0.00) | E | 0.56x0.62 | B | GND |
