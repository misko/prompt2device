# pin dossier: Q_DUMP  (AO3400A)

- footprint: Package_TO_SOT_SMD:SOT-23
- board position: (65.9, 76.9) rot 0
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/AO3400A/AO3400A_Rev3.1.pdf
- part.yaml verification note: AO3400A Rev3.1 page1 SOT23 Top View/Bottom View drawings: marked gate-side lead=G1, other paired lead=S2, single opposite lead=D3; page2 Electrical Characteristics table. Reopened exact retained PDF2026-09-10; pin/value mapping unchanged. Catalog identity is not allocation.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-0.94,-0.95) | N | 1.48x0.6 | G | DUMP_GATE |
| 2 | (-0.94,+0.95) | S | 1.48x0.6 | S | GND |
| 3 | (+0.94,+0.00) | E | 1.48x0.6 | D | ADC_DUMP |
