# pin dossier: R_PRE  (CRCW120622R0FKEAHP)

- footprint: Resistor_SMD:R_1206_3216Metric
- board position: (47.9, 61.7) rot 0
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/CRCW120622R0FKEAHP/CRCW_HP_20043_20260317.pdf
- part.yaml verification note: Exact manufacturer/MPN/code/value/package identified from public catalog2026-09-07; public identity not allocation. Primary series evidence and applied deratings are stated in ADR0009.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-1.46,+0.00) | W | 1.12x1.75 | A | 5V_LDO_FEED |
| 2 | (+1.46,+0.00) | E | 1.12x1.75 | B | 5V_LDO_HOLD |
