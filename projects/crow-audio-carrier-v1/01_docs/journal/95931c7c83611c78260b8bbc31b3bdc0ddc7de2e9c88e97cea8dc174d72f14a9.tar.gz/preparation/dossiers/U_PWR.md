# pin dossier: U_PWR  (TPS389001DSER)

- footprint: crow_audio_carrier:TI_DSE0006A_Exact
- board position: (33.0, 56.7) rot 0
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/TPS389001DSER/TPS3890_SLVSD65A.pdf
- part.yaml verification note: Primary pin-function table and exact orderable suffix; package land drawing visually inspected2026-09-07. See ADR0009 for modeled versus measured distinction.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-0.55,-0.50) | W | 0.8x0.25 | SENSE | PWR_SENSE |
| 2 | (-0.60,+0.00) | W | 0.7x0.25 | GND | GND |
| 3 | (-0.60,+0.50) | W | 0.7x0.25 | MR_N | 5V_LDO_HOLD |
| 4 | (+0.60,+0.50) | E | 0.7x0.25 | VDD | 5V_LDO_HOLD |
| 5 | (+0.60,+0.00) | E | 0.7x0.25 | CT | PWR_CT |
| 6 | (+0.60,-0.50) | E | 0.7x0.25 | RESET_N | PWR_EN |
