# pin dossier: U_ESD4  (TPD2E2U06DRLR)

- footprint: Package_TO_SOT_SMD:SOT-553
- board position: (138.0, 33.8) rot 0
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/TPD2E2U06DRLR/TPD2E2U06_SLLSEG9C.pdf
- part.yaml verification note: CITED: TI SLLSEG9C DRL top view and Pin Functions table, PDF p.3, independently fix 1=NC, 2=NC, 3=IO1, 4=GND, 5=IO2; electrical/ESD tables PDF pp.3-5 fix the stated limits; re-read 2026-09-01.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-0.71,-0.50) | W | 0.68x0.35 | NC | unconnected-(U_ESD4-NC1-Pad1) |
| 2 | (-0.71,+0.00) | W | 0.68x0.35 | NC | unconnected-(U_ESD4-NC2-Pad2) |
| 3 | (-0.71,+0.50) | W | 0.68x0.35 | IO1 | AUDIO_P4 |
| 4 | (+0.71,+0.50) | E | 0.68x0.35 | GND | GND |
| 5 | (+0.71,-0.50) | E | 0.68x0.35 | IO2 | AUDIO_N4 |
