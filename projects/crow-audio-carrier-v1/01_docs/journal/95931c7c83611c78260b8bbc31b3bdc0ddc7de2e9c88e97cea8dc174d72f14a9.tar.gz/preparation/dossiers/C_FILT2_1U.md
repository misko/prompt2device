# pin dossier: C_FILT2_1U  (C0603C105K4RACTU)

- footprint: Capacitor_SMD:C_0603_1608Metric
- board position: (96.6, 75.4) rot 0
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/C0603C105K4RACTU/C0603C105K4RACTU_specsheet.pdf
- part.yaml verification note: CITED: exact KEMET C0603C105K4RACTU is 1uF +/-10%, 16V X7R in 0603; selected 2026-09-01.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-0.78,+0.00) | W | 0.9x0.95 | A | FILT2P |
| 2 | (+0.78,+0.00) | E | 0.9x0.95 | B | GND |
