# pin dossier: R_VMID1_TOP  (RT0603BRD071KL)

- footprint: Resistor_SMD:R_0603_1608Metric
- board position: (72.0, 74.6) rot 90
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/RT0603BRD071KL/RT0603BRD071KL_primary.pdf
- part.yaml verification note: Exact manufacturer specification and public catalog identity; unchanged0603 footprint from prior10k reference divider. Source only, not installed drift/noise qualification.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-0.82,+0.00) | W | 0.8x0.95 | A | 3V3_ADC |
| 2 | (+0.82,+0.00) | E | 0.8x0.95 | B | VMID1_EXT |
