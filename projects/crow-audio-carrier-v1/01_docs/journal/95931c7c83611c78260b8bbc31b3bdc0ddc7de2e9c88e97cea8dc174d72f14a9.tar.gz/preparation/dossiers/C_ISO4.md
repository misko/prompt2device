# pin dossier: C_ISO4  (CL05B104KO5NNNC)

- footprint: Capacitor_SMD:C_0402_1005Metric
- board position: (139.2, 53.3) rot 0
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/CL05B104KO5NNNC/Samsung_CL05B104KO5NNN_specsheet.pdf
- part.yaml verification note: Exact MPN/code/value/package match selected 2026-09-01; order-time availability remains separate.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-0.48,+0.00) | W | 0.56x0.62 | A | 5V_LDO_HOLD |
| 2 | (+0.48,+0.00) | E | 0.56x0.62 | B | GND |
