# pin dossier: R_ADC_PD6N  (RC0402FR-0710KL)

- footprint: Resistor_SMD:R_0402_1005Metric
- board position: (69.8, 85.1) rot 180
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/02_parts/RC0402FR-0710KL/Yageo_RC0402FR-0710KL_20260908.pdf
- part.yaml verification note: Exact YAGEO MPN/code/value/package match selected 2026-09-01.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-0.51,+0.00) | W | 0.54x0.64 | A | ADC6N |
| 2 | (+0.51,+0.00) | E | 0.54x0.64 | B | GND |
