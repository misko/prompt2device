from pathlib import Path
import sys,os,json,csv,hashlib,shutil,collections
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=P/'06_build/pre_route/pin_preparation';D.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(R/'skills/pcb-design/scripts'));sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'))
from pipeline_runtime import run_stage
from pin_audit import part_authority,datasheet_path
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
board=P/'04_kicad/crow_audio_carrier_v1.kicad_pcb';circuit=P/'03_tscircuit/build/circuit.json';before=sha(board)
rows=sorted([x for x in json.loads(circuit.read_text()) if x.get('type')=='source_component'],key=lambda x:x['name']);assert len(rows)==333 and len({x['name'] for x in rows})==333;assert all(x.get('manufacturer_part_number') for x in rows)
groups=collections.defaultdict(list)
for row in rows:groups[row['manufacturer_part_number']].append(row['name'])
authorities=[]
for mpn,refs in sorted(groups.items()):
 directory,part=part_authority(P/'02_parts',mpn);pdf=Path(datasheet_path(directory,part.get('datasheet')))
 authorities.append({'mpn':mpn,'refs':refs,'part_yaml':str(directory/'part.yaml'),'part_sha256':sha(directory/'part.yaml'),'datasheet':str(pdf),'datasheet_sha256':sha(pdf)})
index=D/'source-identity-index.csv'
with index.open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['Designator','MPN']);w.writeheader();w.writerows({'Designator':x['name'],'MPN':x['manufacturer_part_number']} for x in rows)
cmd=['/usr/bin/python3',str(R/'skills/kicad-pcb/scripts/pin_audit.py'),str(board),str(index),str(P/'02_parts'),str(D/'dossiers'),'--refs',','.join(x['name'] for x in rows)]
(D/'command.json').write_text(json.dumps({'argv':cmd,'cwd':str(P)},indent=2)+'\n')
result=run_stage({'id':'prepare_pin_dossiers','work_class':'local','timeout_s':180},cmd,log_path=D/'pin-audit.log',cwd=P,env={'PATH':os.environ['PATH'],'HOME':os.environ['HOME'],'LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'},console_line_limit=4,console_tail_lines=3)
(D/'runtime.json').write_text(json.dumps(result.to_mapping(),indent=2)+'\n');assert result.status=='PASS'
generated={x.stem for x in (D/'dossiers').glob('*.md')};assert generated=={x['name'] for x in rows},generated.symmetric_difference(x['name'] for x in rows)
assert sha(board)==before
for row in authorities:assert sha(Path(row['part_yaml']))==row['part_sha256'] and sha(Path(row['datasheet']))==row['datasheet_sha256']
manifest={'schema':1,'status':'PREPARED_NOT_REVIEWED','board_sha256':before,'circuit_json_sha256':sha(circuit),'components':len(rows),'unique_parts':len(groups),'identity_index_sha256':sha(index),'identity_index_scope':'Source-component MPN projection for review preparation only; not fabrication or order BOM','authority':authorities,'dossiers':{f.name:{'size':f.stat().st_size,'sha256':sha(f)} for f in sorted((D/'dossiers').glob('*.md'))},'review_scope':'All333 actual components, including 2/3pin devices; no independent judgment performed. Fresh grouped reviewers must derive expectations from exact PDFs before consulting tables.'}
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(D/'README.md').write_text('# Pin-review preparation\n\nPREPARED, NOT REVIEWED. Exact source component identities projected into source-identity-index.csv solely to drive the maintained pin_audit.py extractor. This is not a fabrication/order BOM. Explicit --refs covers all333actual components, including default-skipped two/three-pin parts. Every58unique MPN resolved uniquely against the full live dossier tree, with its PDF selected by the declared SHA256. Board/source/part/PDF/output identities are in manifest.json.\n\nNo gate verdict, user orientation approval, review adoption or route permission is supplied. After the human orientation checkpoint, group fresh pin reviewers by a few part types per task, provide only the protocol/dossiers/exact PDFs, and retain all actual refs in the denominator. Other placement lenses remain separate.\n')
print('Prepared',len(generated),'dossiers;',len(authorities),'exact manufacturer PDF identities; board unchanged')
