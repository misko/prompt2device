from pathlib import Path, PurePosixPath
import json, hashlib, shutil, tarfile, io
from run_review import ROOT,RUN,S,E,verify
O=RUN/'outputs';O.mkdir(exist_ok=True)
verify('inputs-final')
measured=json.loads((S/'measurements.json').read_text())
primary=E['input_packet'][-1]
for name in ['TASK.md','pin-review-protocol.md','preflight.py']:
    shutil.copyfile(ROOT/name,S/name)
shutil.copyfile(RUN/'envelope.json',S/'envelope.json')
header='''review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent /root/rj45_pin_carrier_jacks_mountedframe1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7
'''
report=header+'\nSubject (exact envelope):\n'+json.dumps(E['subject'],sort_keys=True)+'\n\nCoverage: J1–J8 only. This is a pre-route pin review, not whole-board acceptance or an order authorization.\n\n'
report+='Primary for every ref: '+primary['path']+'; SHA-256 '+primary['sha256']+'; revision 001.003; page 1, Dimensions and Recommended Hole Pattern; page 2, Article Properties and Electrical Properties. Actual inspected page images are in the archive.\n\n'
report+=(S/'engineering-methods.md').read_text()+'\n\n'
findings=[]
for inst in measured['instances']:
    ref=inst['ref']
    report+=f"## {ref}\n\nVERDICT: PASS\n\nMeasured: 10 numbered native pads / 10 distinct physical electrical identities = 8 contacts + 2 shield terminals; 0 EP. Dossier reports 2 additional unnumbered mechanical pads, omitted from its coordinate table; reported native total 12, measured electrical total 10. Mounted front, rotation {inst['rotation_degrees']:g} degrees. Primary: SHA-256 {primary['sha256']}, page 1 Recommended Hole Pattern / Dimensions and page 2 Article Properties.\n\n"
    report+='| Pin / function | Expected from primary physical map (mm) | Observed local / native (mm) | Observed net / result |\n|---|---|---|---|\n'
    ref_findings=[]
    for p in inst['pads']:
        meaning='passive contact; no manufacturer-prescribed application net' if int(p['pin'])<=8 else 'separate shell terminal; chassis-type net'
        report+=f"| {p['pin']} / {p['function']} | {p['expected_local']}; {meaning} | {p['local']} / {p['native']} | {p['net']}; PASS |\n"
        ref_findings.append({'pin':p['pin'],'function':p['function'],'verdict':'PASS','expected':{'local_mm':p['expected_local'],'electrical_role':meaning},'observed':{'local_mm':p['local'],'native_mm':p['native'],'net':p['net']},'native_frame_verified':p['native_transform_matches']})
    report+='\nPin 1, all eight individual contact positions, both separate shield identities, native/component-top conversion, and instance net-kind symmetry match. No fused alias is used. Perimeter winding is inapplicable to the staggered contact rows; the dossier CCW label is not an acceptance criterion.\n\n'
    findings.append({'ref':ref,'verdict':'PASS','primary_sha256':primary['sha256'],'primary_pages':[1,2],'figures':['Dimensions','Recommended Hole Pattern','Article Properties'],'measured_counts':{k:v for k,v in inst.items() if k.startswith('measured_') or k.startswith('reported_')},'pins':ref_findings,'questions':[],'failures':[]})
report+='Unresolved pin-review findings: none. All eight refs PASS. No claim is made about external cable assignment, remote equipment compatibility, full drill/peg geometry, load current, or whole-board acceptance.\n'
(O/'report.md').write_text(report)
evidence={'verdict':'SOUND','subject':E['subject'],'review_stage':'pre-route','review_kind':'pin','reviewer':'actual fresh agent /root/rj45_pin_carrier_jacks_mountedframe1','context':'FRESH','order_verdict':'DO-NOT-ORDER','coverage':[r['ref'] for r in findings],'methods':{'record':'engineering-methods.md','rendered_figures':['primary-1.png','primary-2.png','detail-1.png'],'native_measurement_method':'measure.py','runtime_method':'run_review.py','comparison':'Image-derived primary top-view pattern; translate at pin 1 and rotate 180 degrees only; independently compare every native row and instance.','winding':'N/A for staggered connector rows; compare individual positions','execution_bootstrap':'Read-only shell bootstrap recorded in engineering-methods.md; engineering subprocesses thereafter use bounded shared runtime.'},'primary_document':primary,'measured_counts':{'instances':8,'numbered_native_pads':80,'distinct_electrical_identities_across_instances':80,'contacts':64,'shield_terminals':16,'reported_unnumbered_mechanical_pads':16,'reported_total_native_pad_objects':96,'measured_exposed_pads':0},'findings':findings,'limitations':['Limited group pin review; no whole-board acceptance.','Mechanical pad coordinates/drills are omitted from dossiers and not measured.','Manufacturer defines passive contact identities, not external system cable net assignment.'],'unresolved_findings':[],'inputs_verification':'inputs-before.json, inputs-after-render.json, inputs-after-measure.json, inputs-final.json; all exact envelope inputs match.'}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(O/'result.json').write_text(json.dumps({'subject':E['subject'],'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]},indent=2)+'\n')
shutil.copyfile(O/'report.md',S/'report.md');shutil.copyfile(O/'evidence.json',S/'evidence.json')
# Archive finite, actual evidence and method bytes; never the output archive or itself.
files=sorted(p for p in S.rglob('*') if p.is_file() and p.suffix not in ('.gz',) and not p.name.startswith('final-preflight') and not p.name.startswith('package-stage'))
assert not any(p.is_symlink() for p in files)
with tarfile.open(O/'evidence.tar.gz','w:gz') as tf:
    for p in files: tf.add(p,arcname=p.relative_to(S).as_posix(),recursive=False)
members=[];seen=set()
with tarfile.open(O/'evidence.tar.gz','r:gz') as tf:
    for m in tf.getmembers():
        assert m.isfile() and not m.issym() and not m.islnk()
        pp=PurePosixPath(m.name)
        assert not pp.is_absolute() and '..' not in pp.parts and m.name not in seen
        assert not m.name.endswith(('.tar','.tar.gz','.tgz'))
        seen.add(m.name); b=tf.extractfile(m).read(); assert len(b)==m.size
        members.append({'path':m.name,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
blob=(O/'evidence.tar.gz').read_bytes()
(O/'evidence-manifest.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(blob).hexdigest(),'archive_size':len(blob),'member_count':len(members),'members':members},indent=2)+'\n')
verify('inputs-final')
print(json.dumps({'domain_verdict':'SOUND','refs':8,'archive_member_count':len(members),'archive_size':len(blob),'archive_sha256':hashlib.sha256(blob).hexdigest(),'outputs':sorted(p.name for p in O.iterdir())}))
