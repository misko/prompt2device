review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent /root/rj45_pin_carrier_jacks_mountedframe1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

Subject (exact envelope):
{"raw_sha256": "b9a3e763c4e522fa2453377aa96a2350b105cbefb43c1d0cb3ca6580da806c9e", "semantic_sha256": "63c1c9cc96c5a65f34d385ec2da4e46f4acd29258bccb38781c332da2620f776"}

Coverage: J1–J8 only. This is a pre-route pin review, not whole-board acceptance or an order authorization.

Primary for every ref: projects/crow-audio-carrier-v1/02_parts/615008160221/Wurth_615008160221_rev001003.pdf; SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048; revision 001.003; page 1, Dimensions and Recommended Hole Pattern; page 2, Article Properties and Electrical Properties. Actual inspected page images are in the archive.

# Independent pin review methods and figure observations

Reviewer: actual fresh agent /root/rj45_pin_carrier_jacks_mountedframe1. Engineering sources were only the supplied protocol, J1–J8 dossiers, and the exact primary PDF. The dossier author verification note was not used as evidence. No schematic, live design, historical review, manufacturer CAD, web material, or other project sources were consulted. Runtime/validator infrastructure was read only to implement the handback.

Primary: Wurth 615008160221, revision 001.003, 2025-07-09. SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048.

Actual figure inspections: page 1 complete at 120 dpi, page 2 complete at 120 dpi, page 1 complete at 240 dpi, all rendered using pdftoppm and opened with view_image. These actual PNGs are retained. Text extraction only supplements the images; it is not winding evidence.

Page 1 has unnumbered figures titled Dimensions and Recommended Hole Pattern. Page 2 Article Properties specifies 8P8C. The part is a horizontal shielded passive jack, with eight individual contact tails, two separate shield mounting terminals, and two non-electrical locating pegs. No EP, IC power pin, NC pin, internal magnetics, or polarity marking is present in these figures.

View derivation from page 1 images: the center-left view is the mating face, latch opening up; the solid metal roof with two spring tabs is the lower-left projection and is confirmed by the isometric view. The exposed underside/contact-tail projection is above the mating face. The mouth faces upward on that underside projection and downward on the roof projection. The leftmost terminal end in the underside projection is in the row farther from the mouth; its rightmost terminal end is in the row nearer the mouth. In the recommended board-hole pattern, the mouth side is downward (the shield slots and peg positions correspond to the side/roof geometry); the leftmost contact is likewise farther from the mouth and the rightmost nearer. Thus the board-hole drawing corresponds to the component-top projection. This conclusion uses the asymmetric staggering and the three-dimensional body, not an assumed generic 'hole pattern means top' rule. The underside projection and board-hole pattern have the expected y reversal. No mirror is applied to the board-hole drawing when comparing it to the component-top dossier.

Read directly in the manufacturer's recommended pattern, with +x right and +y down: upper/back row is 8,6,4,2 from left to right; lower/front row is 7,5,3,1 from left to right. Pin 1 is the rightmost contact in the near-mouth row. The x increment between consecutive contact identities is -1.02 mm; adjacent same-row contacts are 2.04 mm apart; rows are 4.00 mm apart; the full contact x span is 7.14 mm. Center the drawing on pin 1 and rotate it 180 degrees: expected dossier coordinates are pin n = (1.02*(n-1), 0 for odd n or 4 for even n). The mouth then faces negative local y. This is a proper rotation with determinant +1, not a mirror.

The eight contacts zigzag across two staggered rows; they do not number around a perimeter. The signed polygon area of contact identities 1–8 is zero. A package winding label is therefore not applicable. Including artifact shield numbers 9 and 10 can generate a numerical 'CCW' label, but the manufacturer does not number those tabs and the result does not establish correct contact handedness. Individual positions provide the relevant evidence. The computed W/N/S/E labels are centroid sectors, not manufacturer package-side names.

The shield mounting slot centers are separated by 14.8 mm. Their horizontal center is 3.57 mm left of pin 1 in the manufacturer drawing, giving offsets -10.97 and +3.83 mm. Their y offset from the near-mouth contact row is 3.30+3.05-4.00=2.35 mm toward the mouth. Following the same 180-degree rotation, they are at (+10.97,-2.35) and (-3.83,-2.35). The dossier calls these separate physical terminals pads 9/SHIELD_S1 and 10/SHIELD_S2. These are artifact names, not manufacturer contact numbers. Both physical terminals survive as distinct pads on CHASSIS; no fused alias or identity collapse is used.

Counts measured from each native dossier: 10 numbered coordinate rows, 10 distinct pad identities, 8 contacts, 2 shields. Each dossier separately reports 2 unnumbered mechanical/paste pads that it omits from its coordinate table, so the reported total is 12 native pad objects. Their geometry and drill dimensions are not measured by this pin dossier. The primary figure has two locating pegs; full mechanical/drill footprint validation is outside this pin-identity review. No exposed copper pad is required.

Electrical interpretation: manufacturer CONTACT_1 through CONTACT_8 are passive insulated contacts, not prescribed Ethernet/POD power or audio signals. No prescribed application net assignment exists in this PDF. The dossiers retain each contact independently: 1/3/7 to the same instance's 12V_PODn; 2/6/8 to GND; 4 to AUDIO_Nn; 5 to AUDIO_Pn; both shields to CHASSIS. These are compatible net kinds for the device's actual contact and shield functions. This pin review does not establish the external cable or remote equipment assignment, delivered current, audio polarity end-to-end, or permission to connect Ethernet equipment. Those are separate system-interface checks, not facts established by this passive-jack datasheet.

All eight full native coordinate tables were read and parsed. The independent expected coordinate map above was compared to every numbered native pad. Front mounting requires no reflection. For J1–J4 the native coordinate is origin plus local coordinate at 0 degrees. For J5–J8 the native coordinate is origin minus local coordinate at 180 degrees. All 80 numbered pads satisfy their declared frame conversion, all 80 preserve the expected physical identity, and all eight instances have the same function/net-kind pattern with their own instance suffix. The mechanical omission described above is retained explicitly, not counted as a measured geometry check.

Engineering conclusion: all commissioned refs PASS for the defined pin-review domain. No electrical/package pin error or required pin-context question was found. This is limited group coverage only and gives no whole-board or order acceptance. Order verdict remains DO-NOT-ORDER because this is a pre-route pin review.

Execution record: initial task/protocol/J1/envelope and runtime signature bootstrap reads used exec_command read-only shell commands; subsequent engineering rendering, extraction, full-dossier read, and measurement used finite direct argv under shared pipeline_runtime.run_stage, with explicit cwd/environment and retained raw combined stdout/stderr plus runtime JSON. Bootstrap did not run an engineering validator or mutate an input. Shared task inputs are digest-verified before rendering, after rendering, after measurement, and at packaging/preflight. Only the allocated scratch and outputs directories were written.


## J1

VERDICT: PASS

Measured: 10 numbered native pads / 10 distinct physical electrical identities = 8 contacts + 2 shield terminals; 0 EP. Dossier reports 2 additional unnumbered mechanical pads, omitted from its coordinate table; reported native total 12, measured electrical total 10. Mounted front, rotation 0 degrees. Primary: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Recommended Hole Pattern / Dimensions and page 2 Article Properties.

| Pin / function | Expected from primary physical map (mm) | Observed local / native (mm) | Observed net / result |
|---|---|---|---|
| 1 / CONTACT_1 | [0.0, 0.0]; passive contact; no manufacturer-prescribed application net | [0.0, 0.0] / [36.0, 25.86] | 12V_POD1; PASS |
| 2 / CONTACT_2 | [1.02, 4.0]; passive contact; no manufacturer-prescribed application net | [1.02, 4.0] / [37.02, 29.86] | GND; PASS |
| 3 / CONTACT_3 | [2.04, 0.0]; passive contact; no manufacturer-prescribed application net | [2.04, 0.0] / [38.04, 25.86] | 12V_POD1; PASS |
| 4 / CONTACT_4 | [3.06, 4.0]; passive contact; no manufacturer-prescribed application net | [3.06, 4.0] / [39.06, 29.86] | AUDIO_N1; PASS |
| 5 / CONTACT_5 | [4.08, 0.0]; passive contact; no manufacturer-prescribed application net | [4.08, 0.0] / [40.08, 25.86] | AUDIO_P1; PASS |
| 6 / CONTACT_6 | [5.1, 4.0]; passive contact; no manufacturer-prescribed application net | [5.1, 4.0] / [41.1, 29.86] | GND; PASS |
| 7 / CONTACT_7 | [6.12, 0.0]; passive contact; no manufacturer-prescribed application net | [6.12, 0.0] / [42.12, 25.86] | 12V_POD1; PASS |
| 8 / CONTACT_8 | [7.14, 4.0]; passive contact; no manufacturer-prescribed application net | [7.14, 4.0] / [43.14, 29.86] | GND; PASS |
| 9 / SHIELD_S1 | [10.97, -2.35]; separate shell terminal; chassis-type net | [10.97, -2.35] / [46.97, 23.51] | CHASSIS; PASS |
| 10 / SHIELD_S2 | [-3.83, -2.35]; separate shell terminal; chassis-type net | [-3.83, -2.35] / [32.17, 23.51] | CHASSIS; PASS |

Pin 1, all eight individual contact positions, both separate shield identities, native/component-top conversion, and instance net-kind symmetry match. No fused alias is used. Perimeter winding is inapplicable to the staggered contact rows; the dossier CCW label is not an acceptance criterion.

## J2

VERDICT: PASS

Measured: 10 numbered native pads / 10 distinct physical electrical identities = 8 contacts + 2 shield terminals; 0 EP. Dossier reports 2 additional unnumbered mechanical pads, omitted from its coordinate table; reported native total 12, measured electrical total 10. Mounted front, rotation 0 degrees. Primary: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Recommended Hole Pattern / Dimensions and page 2 Article Properties.

| Pin / function | Expected from primary physical map (mm) | Observed local / native (mm) | Observed net / result |
|---|---|---|---|
| 1 / CONTACT_1 | [0.0, 0.0]; passive contact; no manufacturer-prescribed application net | [0.0, 0.0] / [68.0, 25.86] | 12V_POD2; PASS |
| 2 / CONTACT_2 | [1.02, 4.0]; passive contact; no manufacturer-prescribed application net | [1.02, 4.0] / [69.02, 29.86] | GND; PASS |
| 3 / CONTACT_3 | [2.04, 0.0]; passive contact; no manufacturer-prescribed application net | [2.04, 0.0] / [70.04, 25.86] | 12V_POD2; PASS |
| 4 / CONTACT_4 | [3.06, 4.0]; passive contact; no manufacturer-prescribed application net | [3.06, 4.0] / [71.06, 29.86] | AUDIO_N2; PASS |
| 5 / CONTACT_5 | [4.08, 0.0]; passive contact; no manufacturer-prescribed application net | [4.08, 0.0] / [72.08, 25.86] | AUDIO_P2; PASS |
| 6 / CONTACT_6 | [5.1, 4.0]; passive contact; no manufacturer-prescribed application net | [5.1, 4.0] / [73.1, 29.86] | GND; PASS |
| 7 / CONTACT_7 | [6.12, 0.0]; passive contact; no manufacturer-prescribed application net | [6.12, 0.0] / [74.12, 25.86] | 12V_POD2; PASS |
| 8 / CONTACT_8 | [7.14, 4.0]; passive contact; no manufacturer-prescribed application net | [7.14, 4.0] / [75.14, 29.86] | GND; PASS |
| 9 / SHIELD_S1 | [10.97, -2.35]; separate shell terminal; chassis-type net | [10.97, -2.35] / [78.97, 23.51] | CHASSIS; PASS |
| 10 / SHIELD_S2 | [-3.83, -2.35]; separate shell terminal; chassis-type net | [-3.83, -2.35] / [64.17, 23.51] | CHASSIS; PASS |

Pin 1, all eight individual contact positions, both separate shield identities, native/component-top conversion, and instance net-kind symmetry match. No fused alias is used. Perimeter winding is inapplicable to the staggered contact rows; the dossier CCW label is not an acceptance criterion.

## J3

VERDICT: PASS

Measured: 10 numbered native pads / 10 distinct physical electrical identities = 8 contacts + 2 shield terminals; 0 EP. Dossier reports 2 additional unnumbered mechanical pads, omitted from its coordinate table; reported native total 12, measured electrical total 10. Mounted front, rotation 0 degrees. Primary: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Recommended Hole Pattern / Dimensions and page 2 Article Properties.

| Pin / function | Expected from primary physical map (mm) | Observed local / native (mm) | Observed net / result |
|---|---|---|---|
| 1 / CONTACT_1 | [0.0, 0.0]; passive contact; no manufacturer-prescribed application net | [0.0, 0.0] / [100.0, 25.86] | 12V_POD3; PASS |
| 2 / CONTACT_2 | [1.02, 4.0]; passive contact; no manufacturer-prescribed application net | [1.02, 4.0] / [101.02, 29.86] | GND; PASS |
| 3 / CONTACT_3 | [2.04, 0.0]; passive contact; no manufacturer-prescribed application net | [2.04, 0.0] / [102.04, 25.86] | 12V_POD3; PASS |
| 4 / CONTACT_4 | [3.06, 4.0]; passive contact; no manufacturer-prescribed application net | [3.06, 4.0] / [103.06, 29.86] | AUDIO_N3; PASS |
| 5 / CONTACT_5 | [4.08, 0.0]; passive contact; no manufacturer-prescribed application net | [4.08, 0.0] / [104.08, 25.86] | AUDIO_P3; PASS |
| 6 / CONTACT_6 | [5.1, 4.0]; passive contact; no manufacturer-prescribed application net | [5.1, 4.0] / [105.1, 29.86] | GND; PASS |
| 7 / CONTACT_7 | [6.12, 0.0]; passive contact; no manufacturer-prescribed application net | [6.12, 0.0] / [106.12, 25.86] | 12V_POD3; PASS |
| 8 / CONTACT_8 | [7.14, 4.0]; passive contact; no manufacturer-prescribed application net | [7.14, 4.0] / [107.14, 29.86] | GND; PASS |
| 9 / SHIELD_S1 | [10.97, -2.35]; separate shell terminal; chassis-type net | [10.97, -2.35] / [110.97, 23.51] | CHASSIS; PASS |
| 10 / SHIELD_S2 | [-3.83, -2.35]; separate shell terminal; chassis-type net | [-3.83, -2.35] / [96.17, 23.51] | CHASSIS; PASS |

Pin 1, all eight individual contact positions, both separate shield identities, native/component-top conversion, and instance net-kind symmetry match. No fused alias is used. Perimeter winding is inapplicable to the staggered contact rows; the dossier CCW label is not an acceptance criterion.

## J4

VERDICT: PASS

Measured: 10 numbered native pads / 10 distinct physical electrical identities = 8 contacts + 2 shield terminals; 0 EP. Dossier reports 2 additional unnumbered mechanical pads, omitted from its coordinate table; reported native total 12, measured electrical total 10. Mounted front, rotation 0 degrees. Primary: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Recommended Hole Pattern / Dimensions and page 2 Article Properties.

| Pin / function | Expected from primary physical map (mm) | Observed local / native (mm) | Observed net / result |
|---|---|---|---|
| 1 / CONTACT_1 | [0.0, 0.0]; passive contact; no manufacturer-prescribed application net | [0.0, 0.0] / [132.0, 25.86] | 12V_POD4; PASS |
| 2 / CONTACT_2 | [1.02, 4.0]; passive contact; no manufacturer-prescribed application net | [1.02, 4.0] / [133.02, 29.86] | GND; PASS |
| 3 / CONTACT_3 | [2.04, 0.0]; passive contact; no manufacturer-prescribed application net | [2.04, 0.0] / [134.04, 25.86] | 12V_POD4; PASS |
| 4 / CONTACT_4 | [3.06, 4.0]; passive contact; no manufacturer-prescribed application net | [3.06, 4.0] / [135.06, 29.86] | AUDIO_N4; PASS |
| 5 / CONTACT_5 | [4.08, 0.0]; passive contact; no manufacturer-prescribed application net | [4.08, 0.0] / [136.08, 25.86] | AUDIO_P4; PASS |
| 6 / CONTACT_6 | [5.1, 4.0]; passive contact; no manufacturer-prescribed application net | [5.1, 4.0] / [137.1, 29.86] | GND; PASS |
| 7 / CONTACT_7 | [6.12, 0.0]; passive contact; no manufacturer-prescribed application net | [6.12, 0.0] / [138.12, 25.86] | 12V_POD4; PASS |
| 8 / CONTACT_8 | [7.14, 4.0]; passive contact; no manufacturer-prescribed application net | [7.14, 4.0] / [139.14, 29.86] | GND; PASS |
| 9 / SHIELD_S1 | [10.97, -2.35]; separate shell terminal; chassis-type net | [10.97, -2.35] / [142.97, 23.51] | CHASSIS; PASS |
| 10 / SHIELD_S2 | [-3.83, -2.35]; separate shell terminal; chassis-type net | [-3.83, -2.35] / [128.17, 23.51] | CHASSIS; PASS |

Pin 1, all eight individual contact positions, both separate shield identities, native/component-top conversion, and instance net-kind symmetry match. No fused alias is used. Perimeter winding is inapplicable to the staggered contact rows; the dossier CCW label is not an acceptance criterion.

## J5

VERDICT: PASS

Measured: 10 numbered native pads / 10 distinct physical electrical identities = 8 contacts + 2 shield terminals; 0 EP. Dossier reports 2 additional unnumbered mechanical pads, omitted from its coordinate table; reported native total 12, measured electrical total 10. Mounted front, rotation 180 degrees. Primary: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Recommended Hole Pattern / Dimensions and page 2 Article Properties.

| Pin / function | Expected from primary physical map (mm) | Observed local / native (mm) | Observed net / result |
|---|---|---|---|
| 1 / CONTACT_1 | [0.0, 0.0]; passive contact; no manufacturer-prescribed application net | [0.0, 0.0] / [45.0, 114.14] | 12V_POD5; PASS |
| 2 / CONTACT_2 | [1.02, 4.0]; passive contact; no manufacturer-prescribed application net | [1.02, 4.0] / [43.98, 110.14] | GND; PASS |
| 3 / CONTACT_3 | [2.04, 0.0]; passive contact; no manufacturer-prescribed application net | [2.04, 0.0] / [42.96, 114.14] | 12V_POD5; PASS |
| 4 / CONTACT_4 | [3.06, 4.0]; passive contact; no manufacturer-prescribed application net | [3.06, 4.0] / [41.94, 110.14] | AUDIO_N5; PASS |
| 5 / CONTACT_5 | [4.08, 0.0]; passive contact; no manufacturer-prescribed application net | [4.08, 0.0] / [40.92, 114.14] | AUDIO_P5; PASS |
| 6 / CONTACT_6 | [5.1, 4.0]; passive contact; no manufacturer-prescribed application net | [5.1, 4.0] / [39.9, 110.14] | GND; PASS |
| 7 / CONTACT_7 | [6.12, 0.0]; passive contact; no manufacturer-prescribed application net | [6.12, 0.0] / [38.88, 114.14] | 12V_POD5; PASS |
| 8 / CONTACT_8 | [7.14, 4.0]; passive contact; no manufacturer-prescribed application net | [7.14, 4.0] / [37.86, 110.14] | GND; PASS |
| 9 / SHIELD_S1 | [10.97, -2.35]; separate shell terminal; chassis-type net | [10.97, -2.35] / [34.03, 116.49] | CHASSIS; PASS |
| 10 / SHIELD_S2 | [-3.83, -2.35]; separate shell terminal; chassis-type net | [-3.83, -2.35] / [48.83, 116.49] | CHASSIS; PASS |

Pin 1, all eight individual contact positions, both separate shield identities, native/component-top conversion, and instance net-kind symmetry match. No fused alias is used. Perimeter winding is inapplicable to the staggered contact rows; the dossier CCW label is not an acceptance criterion.

## J6

VERDICT: PASS

Measured: 10 numbered native pads / 10 distinct physical electrical identities = 8 contacts + 2 shield terminals; 0 EP. Dossier reports 2 additional unnumbered mechanical pads, omitted from its coordinate table; reported native total 12, measured electrical total 10. Mounted front, rotation 180 degrees. Primary: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Recommended Hole Pattern / Dimensions and page 2 Article Properties.

| Pin / function | Expected from primary physical map (mm) | Observed local / native (mm) | Observed net / result |
|---|---|---|---|
| 1 / CONTACT_1 | [0.0, 0.0]; passive contact; no manufacturer-prescribed application net | [0.0, 0.0] / [77.0, 114.14] | 12V_POD6; PASS |
| 2 / CONTACT_2 | [1.02, 4.0]; passive contact; no manufacturer-prescribed application net | [1.02, 4.0] / [75.98, 110.14] | GND; PASS |
| 3 / CONTACT_3 | [2.04, 0.0]; passive contact; no manufacturer-prescribed application net | [2.04, 0.0] / [74.96, 114.14] | 12V_POD6; PASS |
| 4 / CONTACT_4 | [3.06, 4.0]; passive contact; no manufacturer-prescribed application net | [3.06, 4.0] / [73.94, 110.14] | AUDIO_N6; PASS |
| 5 / CONTACT_5 | [4.08, 0.0]; passive contact; no manufacturer-prescribed application net | [4.08, 0.0] / [72.92, 114.14] | AUDIO_P6; PASS |
| 6 / CONTACT_6 | [5.1, 4.0]; passive contact; no manufacturer-prescribed application net | [5.1, 4.0] / [71.9, 110.14] | GND; PASS |
| 7 / CONTACT_7 | [6.12, 0.0]; passive contact; no manufacturer-prescribed application net | [6.12, 0.0] / [70.88, 114.14] | 12V_POD6; PASS |
| 8 / CONTACT_8 | [7.14, 4.0]; passive contact; no manufacturer-prescribed application net | [7.14, 4.0] / [69.86, 110.14] | GND; PASS |
| 9 / SHIELD_S1 | [10.97, -2.35]; separate shell terminal; chassis-type net | [10.97, -2.35] / [66.03, 116.49] | CHASSIS; PASS |
| 10 / SHIELD_S2 | [-3.83, -2.35]; separate shell terminal; chassis-type net | [-3.83, -2.35] / [80.83, 116.49] | CHASSIS; PASS |

Pin 1, all eight individual contact positions, both separate shield identities, native/component-top conversion, and instance net-kind symmetry match. No fused alias is used. Perimeter winding is inapplicable to the staggered contact rows; the dossier CCW label is not an acceptance criterion.

## J7

VERDICT: PASS

Measured: 10 numbered native pads / 10 distinct physical electrical identities = 8 contacts + 2 shield terminals; 0 EP. Dossier reports 2 additional unnumbered mechanical pads, omitted from its coordinate table; reported native total 12, measured electrical total 10. Mounted front, rotation 180 degrees. Primary: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Recommended Hole Pattern / Dimensions and page 2 Article Properties.

| Pin / function | Expected from primary physical map (mm) | Observed local / native (mm) | Observed net / result |
|---|---|---|---|
| 1 / CONTACT_1 | [0.0, 0.0]; passive contact; no manufacturer-prescribed application net | [0.0, 0.0] / [109.0, 114.14] | 12V_POD7; PASS |
| 2 / CONTACT_2 | [1.02, 4.0]; passive contact; no manufacturer-prescribed application net | [1.02, 4.0] / [107.98, 110.14] | GND; PASS |
| 3 / CONTACT_3 | [2.04, 0.0]; passive contact; no manufacturer-prescribed application net | [2.04, 0.0] / [106.96, 114.14] | 12V_POD7; PASS |
| 4 / CONTACT_4 | [3.06, 4.0]; passive contact; no manufacturer-prescribed application net | [3.06, 4.0] / [105.94, 110.14] | AUDIO_N7; PASS |
| 5 / CONTACT_5 | [4.08, 0.0]; passive contact; no manufacturer-prescribed application net | [4.08, 0.0] / [104.92, 114.14] | AUDIO_P7; PASS |
| 6 / CONTACT_6 | [5.1, 4.0]; passive contact; no manufacturer-prescribed application net | [5.1, 4.0] / [103.9, 110.14] | GND; PASS |
| 7 / CONTACT_7 | [6.12, 0.0]; passive contact; no manufacturer-prescribed application net | [6.12, 0.0] / [102.88, 114.14] | 12V_POD7; PASS |
| 8 / CONTACT_8 | [7.14, 4.0]; passive contact; no manufacturer-prescribed application net | [7.14, 4.0] / [101.86, 110.14] | GND; PASS |
| 9 / SHIELD_S1 | [10.97, -2.35]; separate shell terminal; chassis-type net | [10.97, -2.35] / [98.03, 116.49] | CHASSIS; PASS |
| 10 / SHIELD_S2 | [-3.83, -2.35]; separate shell terminal; chassis-type net | [-3.83, -2.35] / [112.83, 116.49] | CHASSIS; PASS |

Pin 1, all eight individual contact positions, both separate shield identities, native/component-top conversion, and instance net-kind symmetry match. No fused alias is used. Perimeter winding is inapplicable to the staggered contact rows; the dossier CCW label is not an acceptance criterion.

## J8

VERDICT: PASS

Measured: 10 numbered native pads / 10 distinct physical electrical identities = 8 contacts + 2 shield terminals; 0 EP. Dossier reports 2 additional unnumbered mechanical pads, omitted from its coordinate table; reported native total 12, measured electrical total 10. Mounted front, rotation 180 degrees. Primary: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Recommended Hole Pattern / Dimensions and page 2 Article Properties.

| Pin / function | Expected from primary physical map (mm) | Observed local / native (mm) | Observed net / result |
|---|---|---|---|
| 1 / CONTACT_1 | [0.0, 0.0]; passive contact; no manufacturer-prescribed application net | [0.0, 0.0] / [141.0, 114.14] | 12V_POD8; PASS |
| 2 / CONTACT_2 | [1.02, 4.0]; passive contact; no manufacturer-prescribed application net | [1.02, 4.0] / [139.98, 110.14] | GND; PASS |
| 3 / CONTACT_3 | [2.04, 0.0]; passive contact; no manufacturer-prescribed application net | [2.04, 0.0] / [138.96, 114.14] | 12V_POD8; PASS |
| 4 / CONTACT_4 | [3.06, 4.0]; passive contact; no manufacturer-prescribed application net | [3.06, 4.0] / [137.94, 110.14] | AUDIO_N8; PASS |
| 5 / CONTACT_5 | [4.08, 0.0]; passive contact; no manufacturer-prescribed application net | [4.08, 0.0] / [136.92, 114.14] | AUDIO_P8; PASS |
| 6 / CONTACT_6 | [5.1, 4.0]; passive contact; no manufacturer-prescribed application net | [5.1, 4.0] / [135.9, 110.14] | GND; PASS |
| 7 / CONTACT_7 | [6.12, 0.0]; passive contact; no manufacturer-prescribed application net | [6.12, 0.0] / [134.88, 114.14] | 12V_POD8; PASS |
| 8 / CONTACT_8 | [7.14, 4.0]; passive contact; no manufacturer-prescribed application net | [7.14, 4.0] / [133.86, 110.14] | GND; PASS |
| 9 / SHIELD_S1 | [10.97, -2.35]; separate shell terminal; chassis-type net | [10.97, -2.35] / [130.03, 116.49] | CHASSIS; PASS |
| 10 / SHIELD_S2 | [-3.83, -2.35]; separate shell terminal; chassis-type net | [-3.83, -2.35] / [144.83, 116.49] | CHASSIS; PASS |

Pin 1, all eight individual contact positions, both separate shield identities, native/component-top conversion, and instance net-kind symmetry match. No fused alias is used. Perimeter winding is inapplicable to the staggered contact rows; the dossier CCW label is not an acceptance criterion.

Unresolved pin-review findings: none. All eight refs PASS. No claim is made about external cable assignment, remote equipment compatibility, full drill/peg geometry, load current, or whole-board acceptance.
