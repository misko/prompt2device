import json,hashlib,tarfile,io
from pathlib import Path
S=Path(__file__).parent;R=S.parents[3];O=S.parent/'outputs';E=json.loads((S.parent/'envelope.json').read_text());h=lambda b:hashlib.sha256(b).hexdigest()
checks=[{'path':i['path'],'ok':(R/i['path']).stat().st_size==i['size'] and h((R/i['path']).read_bytes())==i['sha256']} for i in E['input_packet']];assert all(i['ok'] for i in checks)
(S/'input-after.json').write_text(json.dumps(checks,indent=2));hashes=json.loads((S/'hashes.json').read_text())
head={'review_stage':'pre-route','review_kind':'topology','reviewer_identity':'carrier_rj45_native_carrier_topology_mixedside1','reviewer':'independent Codex carrier topology reviewer','context':'FRESH','date':'2026-09-13','design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER',**hashes}
(O/'report.md').write_text('\n'.join(k+': '+v for k,v in head.items())+'\n\n'+(S/'report-body.md').read_text())
evidence={'schema':1,'review_kind':'topology','design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','subject':E['subject'],'hashes':hashes,'input_count':len(checks),'input_before_verified':True,'input_after_verified':True,'counts':{'components':333,'terminals':985,'connected_terminals':943,'NC_terminals':42,'connected_nets':179,'component_additions':0,'component_removals':0,'component_deltas':0,'terminal_deltas':0,'invariants_passed':205,'invariants_total':205,'source_connected_pins':943,'source_traces':1475,'parts_dossiers':89,'used_dossiers':58,'used_primary_PDF_digests':58,'source_MPN_value_footprint_matches':333,'fitted_card_refs':333,'PDF_pages':19,'PDF_body_pixel_equal_pages':19,'source_assemblies':3,'source_instances':11,'full_physical_obligations':23,'ERC_errors':0,'ERC_warnings':2637,'full_checkpoint_supplied_verified':318,'full_checkpoint_total':612},'methods':['Frozen before/after SHA256+size packet verification','Complete accepted/current file and parsed route YAML delta','Frozen owning seven-subject hashes and accepted receipt authentication','Independent S-expression full component/node graph; fresh native export and embedded symbol census','Direct JSX evaluation and independent CircuitJSON trace union-find','Independent native evaluation of maintained205 invariant rows','Current native maps supplied to maintained analog/protection/clock validators','58 used primary PDF digests plus fresh Wurth1/2 and LT3041 7/8 page images','All19 PDF bodies exact2200px RGB comparison; fresh contact-sheet/integrated/header visual judgment'], 'findings':[],'limitations':['No live router checkout/source outside frozen packet inspected; same pinned commit and checkout cleanliness are coordinator provenance','294 full checkpoint source entries absent from frozen packet explicitly enumerated','Pod graph/population excluded by coordinator; separate exact pod reviewer owns it','Prior unchanged-source coverage reused only after exact measured equality; current header/date/diagnostic bytes judged now','Physical source/full, allocation, first-article, routing and release boundaries remain separate','Bootstrap stdlib inspect shadowing failed; accepted measurements rerun bounded; diagnostic retained'], 'equivalence':'file-delta.json,graph.json,circuit-delta.json,image-equality.json,provenance-checks.json', 'delivery_acceptance_is_domain_acceptance':False}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
# Snapshot all completed review methods/results, excluding this currently-open packaging runtime log.
files={p.name:p.read_bytes() for p in S.iterdir() if p.is_file() and not p.name.startswith(('package.log','package.runtime','preflight'))}
for rel in ['TASK.md','accepted-receipts/topology/report.md','accepted-receipts/readability/report.md','context/skills/kicad-pcb/scripts/pre_route_review_check.py']:
 files['frozen/'+rel]=(R/rel).read_bytes()
files['envelope.json']=(S.parent/'envelope.json').read_bytes();files['report.md']=(O/'report.md').read_bytes();files['evidence.json']=(O/'evidence.json').read_bytes()
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,b in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(b))
# Independently reopen all regular members, validate names/types and compare actual extracted bytes.
seen=set();members=[]
with tarfile.open(archive,'r:gz') as tar:
 for m in tar.getmembers():
  assert m.isfile() and not m.issym() and not m.islnk();assert not m.name.startswith('/') and '..' not in Path(m.name).parts and m.name not in seen and not m.name.endswith(('.tar.gz','.tgz','.tar'));seen.add(m.name)
  b=tar.extractfile(m).read();assert b==files[m.name] and len(b)==m.size
  members.append({'path':m.name,'size':len(b),'sha256':h(b)})
assert seen==set(files)
manifest={'schema':1,'archive_sha256':h(archive.read_bytes()),'archive_size':archive.stat().st_size,'member_count':len(members),'members':members}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(O/'result.json').write_text(json.dumps({'subject':E['subject'],'checks':{k:'PASS' for k in E['completion']['checks']},'unresolved':[]},indent=2)+'\n')
print(json.dumps({'outputs':sorted(p.name for p in O.iterdir()),'archive_size':manifest['archive_size'],'member_count':manifest['member_count'],'archive_sha256':manifest['archive_sha256'],'report_sha256':h((O/'report.md').read_bytes())}))
