import json,hashlib,tarfile,shutil,sys,io,contextlib,runpy
from pathlib import Path
sys.dont_write_bytecode=True
S=Path(__file__).parent; B=S.parent;R=S.parents[3];P=R/'project';O=B/'outputs'
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_execution import TaskEnvelope,verify_input_packet,writer_scope_receipt
from pipeline_runtime import _tree_snapshot,_changed_paths,_snapshot_sha256
env=json.loads((B/'envelope.json').read_text());e=TaskEnvelope.from_json((B/'envelope.json').read_text());ad=json.loads((B/'admission.json').read_text())
assert verify_input_packet(e,R)[0]
after=_tree_snapshot(R,ignored=frozenset(ad['ignored']))
scope=writer_scope_receipt(e.writer_scope,_changed_paths(ad['before'],after),before_sha256=_snapshot_sha256(ad['before']),after_sha256=_snapshot_sha256(after),protected_paths=tuple(sorted((e.output_path,ad['claim']))))
assert scope['status']=='PASS'
m=json.loads((S/'measurements.json').read_text());f=json.loads((S/'fidelity-geometry.json').read_text());h=m['hashes']
identity={'subject':env['subject'],'envelope_sha256':hashlib.sha256((B/'envelope.json').read_bytes()).hexdigest(),'verified_input_count':len(env['input_packet']),'writer_scope':scope}
(S/'frozen-input-receipt.json').write_text(json.dumps(identity,indent=2))
(S/'frozen-input-manifest.json').write_text(json.dumps(env['input_packet'],indent=2))
shutil.copyfile(B/'envelope.json',S/'allocated-envelope.json')
report='''review_stage: pre-route
review_kind: schematic_render
reviewer: Codex independent agent /root/carrier_rj45_native_pod_readability_corrected
context: FRESH
date: 2026-09-12
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
'''+''.join(f'subject_{k}: {v}\n' for k,v in env['subject'].items())+''.join(f'{k}: {v}\n' for k,v in h.items())+'''
The corrected delivered schematic is readable. Original P1 POD-RJ45-READ-001 remains a valid DEFECTIVE finding against the original PDF; it is resolved in the exact corrected PDF reviewed here. No current P0/P1/P2 schematic-render defects were found. This verdict does not accept architecture prose, placement, physical qualification, or an order.

MEASURED: inspected all 4/4 actual PDF pages rendered by Poppler at 120 dpi, plus J1 at 360 dpi, U1/C10/C11 at 300 dpi, U2 at 240 dpi, U3 at 360 dpi and the tight U1 ground area at 600 dpi. These are images of the delivered PDF, not source descriptions or manufacturer drawings. All 40/40 component references appear exactly once: page census 7/11/10/12. Four landscape pages measure 900 x 607.5 pt; extracted word census is 94/87/70/121, 372 total, with 0/372 outside page bounds. Extraction is supplemental, not visual acceptance. A separate page-2 header crop confirms the full title is present; the multi-image display initially appeared clipped.

Page 1: J1 10/10 pins and their names are individually legible. Power is 1/3/7 -> 12V_POD, return is 2/6/8 -> GND, 5 -> AUDIO_P, 4 -> AUDIO_N, shell 9/10 -> POD_SHIELD. Native POD_SHIELD has exactly J1.9 and J1.10, separate from GND. The shell label plate, two shell-pin numbers, power fanout and return fanout are clear. F1 IN/OUT, D1/D2 K/A and their four physical pin numbers are legible. The fused-input wire to D1 anode and protected-node TVS/bleed circuit are followable. TP1/TP2 and both repeated power labels are clear.

Page 2: U2 9/9 pins are legible, including IN8, EN5, OUT1, FB2, NR_SS6, GND4 and EP_GND9; NC3 and DNC7 are visibly open and named. C1/C2 and C5/C6 remain next to the regulator. The feedback, feed-forward, noise-reduction and ground-return paths can be followed; bypass supply/ground crossings have jump arcs. R1/R2 values and TP3/TP7 are clear.

Page 3: all 10/10 component references, MK1 POS/NEG and their pin numbers are legible. R3/C7 bias filter, R4 capsule bias, R6/R7 half-rail divider and C9 reservoir, C8 coupling, R5 bias and TP4 reference path are followable. Sheet continuations use explicit named nets. All capacitors are ceramic; absent electrolytic polarity markings are appropriate.

Page 4: U1 14/14 and U3 5/5 pin numbers/functions are readable. U1 reference/value clear the VPLUS pin and its 5V_QUIET label plate. C10/C11 refdes, values, capacitor plates, ground glyph and supply label are clear. The single C11 supply/GND crossing has a visible jump arc, not a junction dot; both capacitors still connect between 5V_QUIET and GND. U1A reference buffer, U1B preamp, U1C polarity-restoration path and U1D local follower are traceable. PRE_FB/OUTP_FB/SPARE_BUF plates and wires clear neighboring pin numbers. R12/R13 identify the two 100-ohm legs, and U3 NC1/NC2 are visibly open. U1's GND text is close to the adjacent OUTD return conductor, but enlarged direct inspection shows separation: the thresholded 600-dpi crop contains one blank pixel column between black glyph and green conductor (0.12 pt sampling result, not a general minimum-clearance rule).

Correction verification: independent authored-source diff is exactly two schY edits, C10 and C11 from 2mm to 3mm, at source lines 245 and 247. The PDF U1 reference box remains x411.128906..419.351549, y285.555051..294.150016 pt. Its nearest straight green segment, including half-stroke width, is now 32.1404 pt away across 56 measured page-4 linear segments. An injected horizontal wire through that reference box correctly fails the distance predicate. Actual curved crossings were separately inspected visually. This geometry measurement is deliberately scoped, not a claim of exhaustive automated occlusion coverage. The abandoned local-ground-label candidates are absent from the current source.

Representation fidelity: independently parsed old/current native netlists agree on 40/40 components, 103/103 pins and 24/24 net groups. Independent CircuitJSON connectivity partitions agree with the current native netlist across 103/103 pins and 24/24 groups, including four singleton NC groups. All 20/20 functional net names agree after the generator's explicit N12V_POD/N12V_FUSED/N5V_QUIET spelling normalization. The negative control moving J1.5 to AUDIO_N is detected. Native census is 120 wires, 49 global labels, 6 junctions, 64 symbol instances including power symbols, and 4 no-connect markers. These checks support visual fidelity and do not replace the separate topology/ratings review. Gate subject fields were independently recomputed with the frozen pre_route_review_check.py, including all 34 part dossiers; all seven expected fields match.

Out-of-lens P2 documentation drift DOC-RJ45-POD-001: frozen 01_docs/ARCHITECTURE.md:6 still names Micro-Fit; line16 maps AUDIO+ to J1.3; lines25-26 call J1.2 the sole return and say shields are not connector pins; lines104-112 retain the superseded Cat5e/Belden7939A/WAGO proposal. Synchronize that live architecture prose to the adopted factory RJ45 contract. This is an actionable document finding explicitly outside the schematic_render verdict. Root was notified; no frozen or live design file was edited by this reviewer.

Inherited authority and limits: source acceptance at 8a2d3620 and native/ERC/full-check green results are context, not readability acceptance. Frozen connector source gate is PASS; full gate is authentically INCOMPLETE with 9 pod physical unknowns. Carrier's 23 unknowns are inherited context, not remeasured here. ADR-0005 FIRST-ARTICLE-ONLY / DO-NOT-ORDER prototype progression remains valid; physical PASS, assembly allocation, ordering and deployment are not asserted. Custom analog audio and power over factory Cat6A RJ45 is not Ethernet/PoE, and power-off mating remains required. Cable/contacts/loop resistance, noise/stability/polarity, fit/service/tolerances, shield-isolation measurement, UV qualification and U3 underside DFM remain owed. Placement, routing, layout/render, DRC, fabrication and release are separate stages; LAYOUT001's inherited 3/3 closure is unchanged.

Runtime: all engineering/native subprocesses used /usr/bin/python3 pipeline_runtime.run_stage, direct argv, explicit scratch cwd/environment and finite 60-second deadlines, with raw logs and runtime records retained. The initial supplied preflight verified input bytes/writer scope, then failed only because outputs did not yet exist. A supplemental fidelity helper initially hit absent connectivity keys on intentional NC ports; the retained raw failure was corrected by modeling each as its own singleton, then all 103 pins matched. This was review-method completion, not a design replacement. Final input verification covers all 174/174 frozen packet files with READ_ONLY scope PASS. The archive includes exact input manifest, exact reviewed PDF/source/native/netlist/CircuitJSON, original reports, methods, images and runtime evidence, and every regular archive member is reopened and hashed.
'''
(O/'report.md').write_text(report)
ev={'schema':1,'review_stage':'pre-route','review_kind':'schematic_render','reviewer':'/root/carrier_rj45_native_pod_readability_corrected','context':'FRESH','date':'2026-09-12','design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER',**identity,'expected_subject_independently_computed':h,'methods':['Actual 4-page Poppler raster inspection with six enlarged details','Independent XML word-bounds census','Independent native S-expression and CircuitJSON connectivity partitions','Scoped PDF SVG wire-distance and raster gap measurements','Source diff and corrected reference collision negative controls'],'measurements':m,'fidelity_geometry':f,'findings':[],'historical_finding':{'id':'POD-RJ45-READ-001','severity':'P1','original_verdict':'DEFECTIVE','current_disposition':'RESOLVED in corrected exact PDF; original report retained unchanged'},'out_of_lens_findings':[{'id':'DOC-RJ45-POD-001','severity':'P2','file':'project/01_docs/ARCHITECTURE.md','lines':[6,16,25,26,104,106,107,108,109,110,111,112],'description':'Stale Micro-Fit/audio pin3/sole return/no connector shield/Cat5e-WAGO prose','action':'Root synchronize live architecture to adopted factory RJ45 interface; not part of schematic_render acceptance'}],'physical_limits':{'pod_full_unknowns':9,'carrier_unknowns_inherited':23,'source_gate':'PASS','full_gate':'INCOMPLETE','allocation':'ABSENT','order':'DO-NOT-ORDER'}}
(O/'evidence.json').write_text(json.dumps(ev,indent=2))
(O/'result.json').write_text(json.dumps({'subject':env['subject'],'checks':{x:'PASS' for x in env['completion']['checks']},'unresolved':[]},indent=2))
exact=S/'exact-inputs';exact.mkdir(exist_ok=True)
for name,path in {'schematic.pdf':P/'03_tscircuit/build/schematic.pdf','circuit.json':P/'03_tscircuit/build/circuit.json','current.tsx':P/'03_tscircuit/src/crow_mic_pod_v3.tsx','current.kicad_sch':P/'04_kicad/crow_mic_pod_v3.kicad_sch','current.net':P/'06_build/netlists/crow_mic_pod_v3.net','previous.tsx':R/'previous-source/03_tscircuit/src/crow_mic_pod_v3.tsx','previous.net':R/'previous-source/06_build/netlists/crow_mic_pod_v3.net','original-readability-report.md':R/'original-rj45-reviews/readability/report.md','original-topology-report.md':R/'original-rj45-reviews/topology/report.md','ARCHITECTURE.md':P/'01_docs/ARCHITECTURE.md','pre_route_review_check.py':R/'context/skills/kicad-pcb/scripts/pre_route_review_check.py','preflight.py':R/'preflight.py'}.items():shutil.copyfile(path,exact/name)
def pack():
 paths=[p for p in sorted(S.rglob('*')) if p.is_file() and p.name not in ('package.log','package.runtime.json')]
 with tarfile.open(O/'evidence.tar.gz','w:gz') as tf:
  for p in paths:
   assert not p.is_symlink();tf.add(p,arcname='scratch/'+str(p.relative_to(S)),recursive=False)
  for name in ('report.md','evidence.json'):tf.add(O/name,arcname=name,recursive=False)
 members=[];seen=set()
 with tarfile.open(O/'evidence.tar.gz','r:gz') as tf:
  for item in tf.getmembers():
   assert item.isfile() and item.name not in seen and not item.name.startswith('/') and '..' not in Path(item.name).parts;seen.add(item.name)
   data=tf.extractfile(item).read();assert len(data)==item.size
   members.append({'path':item.name,'size':item.size,'sha256':hashlib.sha256(data).hexdigest()})
 arc=(O/'evidence.tar.gz').read_bytes();manifest={'archive_sha256':hashlib.sha256(arc).hexdigest(),'archive_size':len(arc),'member_count':len(members),'members':members}
 (O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2));return manifest
pack()
sys.argv=[str(R/'preflight.py'),str(B/'envelope.json')]
with contextlib.redirect_stdout(io.StringIO()) as out:runpy.run_path(str(R/'preflight.py'),run_name='__main__')
(S/'final-preflight-receipt.json').write_text(out.getvalue())
manifest=pack()
assert verify_input_packet(e,R)[0]
print(json.dumps({'design_verdict':'SOUND','writer_scope':scope['status'],'inputs':len(env['input_packet']),'archive':manifest['archive_sha256'],'members':manifest['member_count'],'output_dir':str(O)}))
