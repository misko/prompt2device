review_stage: pre-route
review_kind: pin
reviewer: rj45-pin-carrier-clock-reset-toponly1 fresh judgment agent
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 92a4e2fc0fecde845f2dfa0d9e2f5bfbd943372962fb449d699a98d957fc5633
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: 7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c

# Fresh independent pin review: carrier-clock-reset

Coverage is explicitly limited to U_CLK, U_RST1, and U_RST2. This is not whole-board acceptance. All commissioned references and all supplied instances were checked.

## U_CLK — SN74LVC3G34DCUR

VERDICT: PASS

Measured native pads: 8. Measured physical pin identities: 8. Declared aliases/fused identities: 0. Exposed pad: none. Mounted side: front. Dossier frame: component-top, +x right/+y down. Primary document: SHA-256 d541afbccf6270522f5ba33b86ca31da0ec6bbf497c0d1f8ba265e9ac2e1faec, PDF page 3, DCU Package 8-Pin VSSOP Top View and Pin Functions table.

The datasheet top-view image independently establishes pin 1 at the upper-left; pins 1–4 descend the left side and pins 5–8 ascend the right side, giving CCW top-view winding and four pins per side. The dossier shows the same pin-1 corner, sides, and CCW winding without reflection.

U_CLK pin 1 (1A): expected buffer input on a source clock net vs observed MCH_MCLK; PASS.
U_CLK pin 2 (3Y): expected buffer output on a buffered signal net vs observed FSYNC_BUF; PASS.
U_CLK pin 3 (2A): expected buffer input on a source clock net vs observed MCH_BCLK; PASS.
U_CLK pin 4 (GND): expected ground vs observed GND; PASS.
U_CLK pin 5 (2Y): expected buffer output on a buffered signal net vs observed BCLK_BUF; PASS.
U_CLK pin 6 (3A): expected buffer input on a source sync net vs observed MCH_FSYNC; PASS.
U_CLK pin 7 (1Y): expected buffer output on a buffered clock net vs observed MCLK_BUF; PASS.
U_CLK pin 8 (VCC): expected supply rail vs observed 3V3_ADC; PASS.

## U_RST1 — TPS3839K33DBZR

VERDICT: PASS

Measured native pads: 3. Measured physical pin identities: 3. Declared aliases/fused identities: 0. Exposed/thermal pad: none for DBZ SOT-23-3. Mounted side: front. Dossier frame: component-top, +x right/+y down. Primary document: SHA-256 5f9a9581d1b8df7f0b2a480a71dac6993c9aba3b05767ad22641d151434f5dd3, PDF page 5, TPS3839 DBZ Package SOT23-3 Top View and Pin Functions table.

The datasheet top-view image independently establishes pin 1 at the upper-left, pin 2 at the lower-left, and pin 3 at the right, giving CCW top-view winding. The dossier shows those same three physical positions and CCW winding without reflection.

U_RST1 pin 1 (GND): expected ground vs observed GND; PASS.
U_RST1 pin 2 (RESET#): expected active-low reset output on a reset-control net vs observed POR_N; PASS.
U_RST1 pin 3 (VDD): expected supply rail vs observed 3V3_ADC; PASS.

## U_RST2 — SN74LVC1G123DCTR

VERDICT: PASS

Measured native pads: 8. Measured physical pin identities: 8. Declared aliases/fused identities: 0. Exposed pad: none. Mounted side: front. Dossier frame: component-top, +x right/+y down. Primary document: SHA-256 7248ef0ff62af4d2da172bb2900f0f1f136a6ae90109a6485228e01269fa1c1d, PDF page 3, Figure 4-1 DCT Package 8-Pin SSOP Top View and Table 4-1 Pin Functions.

The datasheet top-view image independently establishes pin 1 at the upper-left; pins 1–4 descend the left side and pins 5–8 ascend the right side, giving CCW top-view winding and four pins per side. The dossier shows the same pin-1 corner, sides, and CCW winding without reflection.

U_RST2 pin 1 (A): expected active-low timing input held low for B/CLR rising-edge operation vs observed GND; PASS.
U_RST2 pin 2 (B): expected timing input held high for CLR rising-edge operation vs observed 3V3_ADC; PASS.
U_RST2 pin 3 (CLR#): expected active-low clear/rising-edge timing input on a reset-control net vs observed POR_N; PASS.
U_RST2 pin 4 (GND): expected ground vs observed GND; PASS.
U_RST2 pin 5 (Q): expected pulse output on a pulse signal net vs observed RESET_PULSE_H; PASS.
U_RST2 pin 6 (Cext): expected net dedicated to the external timing capacitor vs observed RESET_C; PASS.
U_RST2 pin 7 (Rext/Cext): expected timing resistor/capacitor junction net vs observed RESET_RC; PASS.
U_RST2 pin 8 (VCC): expected supply rail vs observed 3V3_ADC; PASS.

Pairwise same-part instance symmetry is not applicable: the supplied group contains one instance of each distinct part. Cross-part reset-chain roles are structurally consistent (U_RST1 RESET# and U_RST2 CLR# share POR_N; U_RST2 A/B are strapped for a POR_N rising-edge pulse).

No unresolved findings were identified within the commissioned group. The immutable order verdict remains DO-NOT-ORDER as required by the review envelope.
