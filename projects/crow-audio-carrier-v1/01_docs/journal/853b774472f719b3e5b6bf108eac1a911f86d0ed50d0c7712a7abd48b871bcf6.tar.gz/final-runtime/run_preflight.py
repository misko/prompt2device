from pathlib import Path
import os
import sys

sys.path.insert(0, "/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts")
from pipeline_runtime import run_stage

scratch = Path(__file__).resolve().parent
packet = scratch.parents[3]
log_name = sys.argv[1]
spec = {"id": "pin_delivery_preflight", "work_class": "local", "timeout_s": 120.0, "produces": []}
outcome = run_stage(
    spec,
    ["/usr/bin/python3", "-B", str(packet / "preflight.py"), str(scratch.parent / "envelope.json")],
    log_path=scratch / "logs" / log_name,
    cwd=packet,
    env=dict(os.environ),
    console=sys.stdout,
    run_id=f"pin-preflight-{log_name}",
)
if outcome.status != "PASS":
    raise SystemExit(f"preflight failed: {outcome.status} {outcome.exit_code}")
