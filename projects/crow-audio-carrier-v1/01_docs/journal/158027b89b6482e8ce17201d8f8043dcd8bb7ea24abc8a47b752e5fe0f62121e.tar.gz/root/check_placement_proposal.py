from pathlib import Path
import sys,json,math,copy,hashlib
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent
sys.path.insert(0,str(P/'03_src/tests'))
import yaml,pcbnew
import test_shared_rail_placement as shared
from test_digital_launch_source import load_source,native_geometry,vec,segment_rows
from placement_gates import _poly_gap_mm
floor,route,nets,*_=load_source();proposal=json.loads(Path('/tmp/carrier-placement-change-vw0sdfkg/06_build/task_runs/placement-change/scratch/proposal.json').read_text());targets={m['ref'] for m in proposal['moves']};shared.TARGETS=targets
for m in proposal['moves']:
 assert floor['placement']['anchors'][m['ref']]==m['before'];floor['placement']['anchors'][m['ref']]=m['after']
g=native_geometry(floor);bad,counts=shared.inspect(floor,route,g);fps=dict(zip(sorted({ref for ref,_ in g['pins']}),g['footprints']));pads={p['id']:p for p in g['pads']};short=[];court=[]
for ref in targets:
 for other,fp in fps.items():
  if ref==other:continue
  gap=_poly_gap_mm(fps[ref].GetCourtyard(pcbnew.F_CrtYd),fp.GetCourtyard(pcbnew.F_CrtYd),.15)
  if gap<.15-1e-6:court.append({'ref':ref,'other':other,'gap_mm':gap})
for p in (P/'02_parts').glob('*/part.yaml'):
 for row in yaml.safe_load(p.read_text()).get('layout',{}).get('keep_short',[]):
  partners=set(row.get('partner_refs',[]))&targets
  if not partners:continue
  owners=[ref for ref,(fpid,val) in __import__('source_inventory').inventory()[0].items() if val==p.parent.name]
  # Relevant current target budgets are explicitly owned by U_ADC.
  if p.parent.name!='CS5308P-DN':continue
  for pin in row['anchor_pins']:
   a=pads['U_ADC.'+str(pin)];bs=[b for b in pads.values() if b['id'].rsplit('.',1)[0] in partners and b['net']==row['net']];assert bs
   span=min(math.dist(a['at'],b['at']) for b in bs)
   short.append({'pin':a['id'],'partners':sorted(partners),'span_mm':span,'max_mm':row['max_span_mm'],'pass':span<=row['max_span_mm']+1e-6})
via_bad=[]
for net,at in proposal['destination_vias'].items():
 shape=pcbnew.SHAPE_CIRCLE(vec(at),250000)
 for pad in g['pads']:
  if pad['net']!=net and pcbnew.SHAPE.Collide(shape,pad['shape'],199998):via_bad.append({'net':net,'other':pad['id'],'kind':'pad'})
 for row in segment_rows(route):
  if row['net']!=net and pcbnew.SHAPE.Collide(shape,row['shape'],199998):via_bad.append({'net':net,'other':row['id'],'kind':'seed'})
r={'method':'Root independent exact native footprint source instantiation; no board emission, no live source changes, one delivered proposal only','moved':len(targets),'native_pads':len(pads),'checks':counts,'all_local_failures':bad,'courtyard_under_0_15':court,'keep_short':short,'proposed_via_failures':via_bad,'limits':'Existing FILT1 seeds intentionally stale under proposal, but physical courtyard/pad/budget failures cannot be cured by seed migration alone.'}
(D/'placement-proposal-native-check.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
