from pathlib import Path
import json,hashlib,tarfile,io,sys,subprocess,shutil
D=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';I=Path('/tmp/carrier-connector-integration-20260911');sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/pcb-design/scripts'));from pipeline_execution import TaskEnvelope,verify_input_packet
sha=lambda b:hashlib.sha256(b).hexdigest();files={};refs={};seen={};commit='b436d612c8d2d325204ebd253f4c885bd66943ee';tracked=set(subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0'));counts=[]
def add(n,p,root=None):
 b=p.read_bytes();h=sha(b);rel=p.relative_to(root).as_posix() if root and p.is_relative_to(root) else ''
 gp='projects/crow-audio-carrier-v1/'+rel[len('project/'):] if rel.startswith('project/') else rel[len('authority/current/'):] if rel.startswith('authority/current/') else None
 if gp in tracked:
  old=subprocess.check_output(['git','show',commit+':'+gp],cwd=R)
  if sha(old)==h:refs[n]={'git_commit':commit,'path':gp,'sha256':h,'size':len(b)};return
 if h in seen:refs[n]={'archive_member':seen[h],'sha256':h,'size':len(b)}
 else:files[n]=p;seen[h]=n
for name in ['placement-change','channel-authority']:
 j=json.loads((D/(name+'-opened.json')).read_text())[0];Q=Path(j['project']);e=TaskEnvelope.from_json(Path(j['envelope']).read_text());a=json.loads(Path(j['attempt']).read_text());assert a['status']=='PASS' and verify_input_packet(e,Q)[0]
 for x in e.input_packet:add(name+'/inputs/'+x.path,Q/x.path,Q)
 for p in Path(j['attempt']).parent.rglob('*'):
  if p.is_file() and p.name!='.closing':add(name+'/runtime/'+p.relative_to(Path(j['attempt']).parent).as_posix(),p,Q)
 counts.append({'name':name,'inputs':len(e.input_packet),'outputs':len(a['output']['completion']['outputs'])})
for n in ['placement-change-reopening.json','channel-authority-reopening.json','placement-proposal-native-check.json','check_placement_proposal.py','check_placement_proposal_initial.py','commission_channel_authority.py','preserve_channel_decision.py']:add('root/'+n,D/n)
for prefix in ['placement-proposal-native','method-fix-']:
 for p in I.glob(prefix+'*'):
  if p.is_file():add('root/'+p.name,p)
for p in (D/'channel-system-supplement').rglob('*'):
 if p.is_file():add('root/system-supplement/'+p.relative_to(D/'channel-system-supplement').as_posix(),p)
manifest=json.loads((D/'channel-system-supplement/manifest.json').read_text())
for row in manifest:
 b=(D/'channel-system-supplement'/row['path']).read_bytes();assert len(b)==row['size'] and sha(b)==row['sha256']
(D/'channel-decision-references.json').write_text(json.dumps(refs,indent=2)+'\n');files['root/references.json']=D/'channel-decision-references.json';m={n:{'size':p.stat().st_size,'sha256':sha(p.read_bytes())} for n,p in files.items()};tmp=D/'channel-decision-preserved.tar.gz'
with tarfile.open(tmp,'w:gz',compresslevel=3) as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
 b=(json.dumps({'members':m},indent=2)+'\n').encode();x=tarfile.TarInfo('MANIFEST.json');x.size=len(b);t.addfile(x,io.BytesIO(b))
h=sha(tmp.read_bytes());out=P/'01_docs/journal'/(h+'.tar.gz');assert not out.exists();shutil.copyfile(tmp,out)
with tarfile.open(out) as t:
 assert set(t.getnames())==set(m)|{'MANIFEST.json'}
 for n,x in m.items():b=t.extractfile(n).read();assert sha(b)==x['sha256'] and len(b)==x['size']
r={'archive':str(out),'sha256':h,'size':out.stat().st_size,'members':len(m),'references':len(refs),'packets':counts,'supplement':len(manifest)};(D/'channel-decision-preservation-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
