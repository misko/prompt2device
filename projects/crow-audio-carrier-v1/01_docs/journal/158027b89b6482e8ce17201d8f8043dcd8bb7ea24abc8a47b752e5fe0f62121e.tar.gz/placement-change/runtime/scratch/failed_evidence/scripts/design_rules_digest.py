#!/usr/bin/env python3
import importlib.util, json, sys
from pathlib import Path
sys.dont_write_bytecode = True
module_path=Path(sys.argv[1]).resolve(); project=Path(sys.argv[2]).resolve(); out=Path(sys.argv[3]).resolve()
spec=importlib.util.spec_from_file_location("owning_pre_route_review_check",module_path)
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
payload={"api":str(module_path),"project":str(project),"design_rules_sha256":m.design_rules_digest(project)}
out.write_text(json.dumps(payload,indent=2,sort_keys=True)+"\n")
print(json.dumps(payload,sort_keys=True))
