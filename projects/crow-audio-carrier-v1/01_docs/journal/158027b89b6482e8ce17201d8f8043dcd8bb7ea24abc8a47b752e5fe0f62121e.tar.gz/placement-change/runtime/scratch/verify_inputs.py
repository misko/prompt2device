#!/usr/bin/env python3
import hashlib, json, pathlib, sys
root=pathlib.Path(sys.argv[1]); env=json.loads((root/'06_build/task_runs/placement-change/envelope.json').read_text())
rows=[]; ok=True
for ent in env['input_packet']:
 p=root/ent['path']; b=p.read_bytes(); h=hashlib.sha256(b).hexdigest(); good=len(b)==ent['size'] and h==ent['sha256']; ok &= good
 rows.append({'path':ent['path'],'expected_size':ent['size'],'actual_size':len(b),'expected_sha256':ent['sha256'],'actual_sha256':h,'status':'PASS' if good else 'FAIL'})
out={'count':len(rows),'pass_count':sum(r['status']=='PASS' for r in rows),'status':'PASS' if ok else 'FAIL','rows':rows}
print(json.dumps(out,indent=2))
raise SystemExit(0 if ok else 1)
