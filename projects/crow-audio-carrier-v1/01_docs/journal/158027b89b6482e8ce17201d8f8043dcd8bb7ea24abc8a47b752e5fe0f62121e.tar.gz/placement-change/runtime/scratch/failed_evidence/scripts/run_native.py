#!/usr/bin/env python3
import json, os, sys
sys.dont_write_bytecode = True
from pathlib import Path

runtime_dir=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
sys.path.insert(0,str(runtime_dir))
from pipeline_runtime import run_stage

scratch=Path(sys.argv[1]).resolve()
command=sys.argv[2:]
name=os.environ.get('STAGE_NAME','native-extract')
out=run_stage({"id":"KICAD-PLACEMENT","work_class":"local","timeout_s":120},command,
              log_path=scratch/f"{name}.raw.log",cwd=scratch,console=None)
(scratch/f"{name}.runtime.json").write_text(json.dumps(out.to_mapping(),indent=2,sort_keys=True)+"\n")
print(json.dumps(out.to_mapping(),sort_keys=True))
raise SystemExit(0 if out.status=='PASS' else 1)
