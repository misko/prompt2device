#!/usr/bin/env python3
import json, math, sys
sys.dont_write_bytecode = True
from pathlib import Path
import pcbnew

board_path = Path(sys.argv[1]).resolve()
out_path = Path(sys.argv[2]).resolve()
b = pcbnew.LoadBoard(str(board_path))

def mm(v): return pcbnew.ToMM(v)
def xy(v): return [round(mm(v.x), 6), round(mm(v.y), 6)]
def bbox(item):
    bb = item.GetBoundingBox()
    return [round(mm(bb.GetX()),6), round(mm(bb.GetY()),6),
            round(mm(bb.GetRight()),6), round(mm(bb.GetBottom()),6)]
def layerset(ls):
    return [pcbnew.LayerName(i) for i in range(pcbnew.PCB_LAYER_ID_COUNT) if ls.Contains(i)]

pads=[]
for fp in b.GetFootprints():
    ref=fp.GetReference()
    for p in fp.Pads():
        drill=p.GetDrillSize()
        pads.append({
            "id":f"{ref}.{p.GetNumber()}","ref":ref,"pad":p.GetNumber(),
            "net":p.GetNetname(),"pos":xy(p.GetPosition()),"size":xy(p.GetSize()),
            "shape":str(p.GetShape()),"attribute":str(p.GetAttribute()),
            "layers":layerset(p.GetLayerSet()),"bbox":bbox(p),
            "drill":[round(mm(drill.x),6),round(mm(drill.y),6)],
        })

tracks=[]
vias=[]
for t in b.GetTracks():
    if isinstance(t, pcbnew.PCB_VIA):
        vias.append({"net":t.GetNetname(),"pos":xy(t.GetPosition()),
                     "diameter":round(mm(t.GetWidth(pcbnew.F_Cu)),6),"drill":round(mm(t.GetDrillValue()),6),
                     "layers":[pcbnew.LayerName(t.TopLayer()),pcbnew.LayerName(t.BottomLayer())],"bbox":bbox(t)})
    else:
        tracks.append({"net":t.GetNetname(),"start":xy(t.GetStart()),"end":xy(t.GetEnd()),
                       "width":round(mm(t.GetWidth()),6),"layer":pcbnew.LayerName(t.GetLayer()),"bbox":bbox(t)})

zones=[]
for z in b.Zones():
    if not z.GetIsRuleArea(): continue
    zones.append({"name":z.GetZoneName(),"layers":layerset(z.GetLayerSet()),"bbox":bbox(z),
                  "no_tracks":bool(z.GetDoNotAllowTracks()),"no_vias":bool(z.GetDoNotAllowVias()),
                  "no_pads":bool(z.GetDoNotAllowPads()),"no_footprints":bool(z.GetDoNotAllowFootprints())})

payload={"board":str(board_path),"bbox":bbox(b),"census":{"pads":len(pads),"tracks":len(tracks),"vias":len(vias),"rule_areas":len(zones)},
         "pads":pads,"tracks":tracks,"vias":vias,"rule_areas":zones}
out_path.write_text(json.dumps(payload,indent=2,sort_keys=True)+"\n")
print(json.dumps(payload["census"],sort_keys=True))
