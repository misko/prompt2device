#!/usr/bin/env python3
import json, math, sys
from pathlib import Path
sys.dont_write_bytecode = True

geom=json.loads(Path(sys.argv[1]).read_text())
out=Path(sys.argv[2])
svg_path=Path(sys.argv[3])

WIDTH=.20; CLEAR=.20; VIA_D=.50; VIA_DRILL=.20; VIA_LEN=1.4858
NETS=[f"ADC{c}{p}" for c in range(1,5) for p in "PN"]
LANES={"ADC1P":55.50,"ADC1N":56.20,"ADC2P":56.90,"ADC2N":57.60,
       "ADC3P":58.30,"ADC3N":59.00,"ADC4P":59.70,"ADC4N":60.40}
ADC_PAD={"ADC1P":"U_ADC.40","ADC1N":"U_ADC.39","ADC2P":"U_ADC.42","ADC2N":"U_ADC.41",
         "ADC3P":"U_ADC.46","ADC3N":"U_ADC.45","ADC4P":"U_ADC.48","ADC4N":"U_ADC.47"}

pads_by_id={p["id"]:p for p in geom["pads"] if p["pad"]}
def pad(pid):
    if pid not in pads_by_id: raise RuntimeError(f"missing pad {pid}")
    return pads_by_id[pid]
def plen(pts): return sum(math.hypot(b[0]-a[0],b[1]-a[1]) for a,b in zip(pts,pts[1:]))

def point_rect_dist(p,r):
    dx=max(r[0]-p[0],0,p[0]-r[2]); dy=max(r[1]-p[1],0,p[1]-r[3])
    return math.hypot(dx,dy)
def orient(a,b,c): return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def onseg(a,b,p): return min(a[0],b[0])-1e-9<=p[0]<=max(a[0],b[0])+1e-9 and min(a[1],b[1])-1e-9<=p[1]<=max(a[1],b[1])+1e-9
def seg_inter(a,b,c,d):
    o1,o2,o3,o4=orient(a,b,c),orient(a,b,d),orient(c,d,a),orient(c,d,b)
    if ((o1>0 and o2<0) or (o1<0 and o2>0)) and ((o3>0 and o4<0) or (o3<0 and o4>0)): return True
    return any(abs(o)<1e-9 and onseg(x,y,p) for o,x,y,p in ((o1,a,b,c),(o2,a,b,d),(o3,c,d,a),(o4,c,d,b)))
def point_seg_dist(p,a,b):
    dx=b[0]-a[0]; dy=b[1]-a[1]; den=dx*dx+dy*dy
    if den==0:return math.hypot(p[0]-a[0],p[1]-a[1])
    t=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/den))
    q=(a[0]+t*dx,a[1]+t*dy); return math.hypot(p[0]-q[0],p[1]-q[1])
def seg_seg_dist(a,b,c,d):
    if seg_inter(a,b,c,d): return 0.0
    return min(point_seg_dist(a,c,d),point_seg_dist(b,c,d),point_seg_dist(c,a,b),point_seg_dist(d,a,b))
def seg_rect_dist(a,b,r):
    corners=[(r[0],r[1]),(r[2],r[1]),(r[2],r[3]),(r[0],r[3])]
    if r[0]<=a[0]<=r[2] and r[1]<=a[1]<=r[3]: return 0.0
    if r[0]<=b[0]<=r[2] and r[1]<=b[1]<=r[3]: return 0.0
    return min(seg_seg_dist(a,b,corners[i],corners[(i+1)%4]) for i in range(4))

routes=[]; windows=[]; graphs=[]; paths=[]
for c in range(1,5):
  for pol in "PN":
    net=f"ADC{c}{pol}"; y=LANES[net]
    source=pad(f"U_ISO{c}.{'2' if pol=='P' else '6'}")
    bias=pad(f"R_ADC_PD{c}{pol}.1"); cm=pad(f"C_ADC_CM{c}{pol}.1"); adc=pad(ADC_PAD[net])
    sx,sy=source["pos"]; ax,ay=adc["pos"]; cmx,cmy=cm["pos"]
    lx=round(sx+(-.65 if pol=='P' else .65),2)
    sv=[lx,y]; dv=[ax,y]; seed=[ax,66.05]
    edge_defs=[
      {"id":f"{net}:source_escape","kind":"proposed_track","layer":"F.Cu","points":[[sx,sy],[lx,sy],[lx,y]]},
      {"id":f"{net}:source_via","kind":"proposed_via","at":sv,"layers":["F.Cu","B.Cu"]},
      {"id":f"{net}:trunk","kind":"proposed_track","layer":"B.Cu","points":[sv,dv]},
      {"id":f"{net}:destination_via","kind":"proposed_via","at":dv,"layers":["B.Cu","F.Cu"]},
      {"id":f"{net}:main_launch","kind":"proposed_track","layer":"F.Cu","points":[dv,seed]},
      {"id":f"{net}:retained_seed","kind":"retained_source_seed","layer":"F.Cu","points":[seed,[ax,ay]],"width_mm":.20},
      {"id":f"{net}:common_mode_branch","kind":"proposed_track","layer":"F.Cu","points":[dv,[ax,cmy],[cmx,cmy]]},
      {"id":f"{net}:bias_branch","kind":"proposed_track","layer":"F.Cu","points":[[sx,sy],bias["pos"]]},
    ]
    for e in edge_defs:
      e["net"]=net
      if e["kind"] in ("proposed_track","retained_source_seed"):
        e.setdefault("width_mm",WIDTH); e["length_mm"]=round(plen(e["points"]),6); routes.append(e)
      elif e["kind"]=="proposed_via":
        e["diameter_mm"]=VIA_D; e["drill_mm"]=VIA_DRILL
    windows += [
      {"id":f"{net}:source_window","net":net,"layers":["F.Cu","B.Cu"],"polygon":[[lx-.4,y-.4],[lx+.4,y-.4],[lx+.4,y+.4],[lx-.4,y+.4]],"contains_via":f"{net}:source_via"},
      {"id":f"{net}:destination_window","net":net,"layers":["F.Cu","B.Cu"],"polygon":[[ax-.4,y-.4],[ax+.4,y-.4],[ax+.4,y+.4],[ax-.4,y+.4]],"contains_via":f"{net}:destination_via"},
    ]
    graphs.append({"net":net,"group":f"ANALOG_CH{c}_ADC","polarity":pol,
      "terminals":{"source":source["id"],"main":adc["id"],"common_mode":cm["id"],"bias":bias["id"]},
      "nodes":{"source":source["pos"],"source_via":sv,"destination_via":dv,"seed_terminus":seed,
               "main":adc["pos"],"common_mode":cm["pos"],"bias":bias["pos"]},"edges":edge_defs})
    common_ids=[f"{net}:source_escape",f"{net}:source_via",f"{net}:trunk",f"{net}:destination_via"]
    path_defs={
      "main":common_ids+[f"{net}:main_launch",f"{net}:retained_seed"],
      "common_mode":common_ids+[f"{net}:common_mode_branch"],
      "bias":[f"{net}:bias_branch"],
    }
    lookup={e["id"]:e for e in edge_defs}
    for kind,ids in path_defs.items():
      length=sum((e.get("length_mm",VIA_LEN) if e["kind"]=="proposed_via" else e["length_mm"]) for e in (lookup[i] for i in ids))
      paths.append({"id":f"ANALOG_CH{c}_ADC:{pol}:{kind}","group":f"ANALOG_CH{c}_ADC","polarity":pol,
                    "kind":kind,"net":net,"from":source["id"],"to":graphs[-1]["terminals"][kind if kind!='main' else 'main'],
                    "edge_ids":ids,"length_mm":round(length,6)})

# Verify exact denominator and source-owned endpoint identities.
endpoint_ids=sorted({v for g in graphs for v in g["terminals"].values()})
assert len(graphs)==8 and len(endpoint_ids)==32 and len(paths)==24

# Existing native/r0 obstacles. Pads use native effective bounding boxes (exact for unrotated rectangles,
# conservative for other shapes); this proposal therefore cannot self-accept a marginal clearance.
obs=[]
for p in geom["pads"]:
  for layer in ("F.Cu","B.Cu"):
    if layer in p["layers"]:
      obs.append({"id":f"pad:{p['id']}:{layer}","type":"pad","net":p["net"],"layer":layer,"bbox":p["bbox"]})
  if max(p["drill"])>0:
    obs.append({"id":f"hole:{p['id']}","type":"hole","net":p["net"],"center":p["pos"],"radius":max(p["drill"])/2,"layers":["F.Cu","B.Cu"]})
for i,t in enumerate(geom["tracks"]):
  obs.append({"id":f"seed:{i}:{t['net']}:{t['layer']}","type":"seed","net":t["net"],"layer":t["layer"],"a":t["start"],"b":t["end"],"width":t["width"]})
for i,v in enumerate(geom["vias"]):
  obs.append({"id":f"via:{i}:{v['net']}","type":"via","net":v["net"],"center":v["pos"],"radius":v["diameter"]/2,"layers":["F.Cu","B.Cu"]})
for i,z in enumerate(geom["rule_areas"]):
  if z["no_tracks"] or z["no_vias"]:
    obs.append({"id":f"keepout:{i}:{z['name']}","type":"keepout","net":"","bbox":z["bbox"],"layers":z["layers"],"no_tracks":z["no_tracks"],"no_vias":z["no_vias"]})

tests=[]
for e in routes:
  if e["kind"]=="retained_source_seed": continue
  for o in obs:
    if o.get("net")==e["net"]: continue
    if o["type"]=="keepout" and not o["no_tracks"]: continue
    if e["layer"] not in (o.get("layers") or [o.get("layer")]): continue
    for si,(a,b) in enumerate(zip(e["points"],e["points"][1:])):
      if o["type"] in ("pad","keepout"):
        d=seg_rect_dist(a,b,o["bbox"]); req=WIDTH/2+(0 if o["type"]=="keepout" else CLEAR)
      elif o["type"]=="seed":
        d=seg_seg_dist(a,b,o["a"],o["b"]); req=WIDTH/2+o["width"]/2+CLEAR
      else:
        d=point_seg_dist(o["center"],a,b); req=WIDTH/2+o["radius"]+CLEAR
      tests.append({"subject":e["id"],"segment":si,"obstacle":o["id"],"distance_mm":round(d,6),"required_mm":round(req,6),"status":"PASS" if d+1e-9>=req else "FAIL"})

proposal_vias=[e for g in graphs for e in g["edges"] if e["kind"]=="proposed_via"]
for v in proposal_vias:
  for o in obs:
    if o.get("net")==v["net"]: continue
    if o["type"]=="keepout" and not o["no_vias"]: continue
    if not any(l in o.get("layers",[o.get("layer")]) for l in v["layers"]): continue
    if o["type"] in ("pad","keepout"):
      d=point_rect_dist(v["at"],o["bbox"]); req=VIA_D/2+(0 if o["type"]=="keepout" else CLEAR)
    elif o["type"]=="seed":
      d=point_seg_dist(v["at"],o["a"],o["b"]); req=VIA_D/2+o["width"]/2+CLEAR
    else:
      d=math.hypot(v["at"][0]-o["center"][0],v["at"][1]-o["center"][1]); req=VIA_D/2+o["radius"]+CLEAR
    tests.append({"subject":v["id"],"obstacle":o["id"],"distance_mm":round(d,6),"required_mm":round(req,6),"status":"PASS" if d+1e-9>=req else "FAIL"})

# Transition-window polygons are source reservations, so enumerate their full
# footprint against every applicable foreign native obstacle as a separate denominator.
for w in windows:
  xs=[p[0] for p in w["polygon"]]; ys=[p[1] for p in w["polygon"]]
  wr=[min(xs),min(ys),max(xs),max(ys)]
  for o in obs:
    if o.get("net")==w["net"]: continue
    if not any(l in (o.get("layers") or [o.get("layer")]) for l in w["layers"]): continue
    if o["type"] in ("pad","keepout"):
      r=o["bbox"]
      separation=max(wr[0]-r[2],r[0]-wr[2],0,wr[1]-r[3],r[1]-wr[3])
      overlap=not (wr[2] <= r[0] or r[2] <= wr[0] or wr[3] <= r[1] or r[3] <= wr[1])
      d=0.0 if overlap else separation; req=0.0
      status="FAIL" if overlap and (o["type"]!="keepout" or o.get("no_tracks") or o.get("no_vias")) else "PASS"
    elif o["type"]=="seed":
      d=seg_rect_dist(o["a"],o["b"],wr); req=o["width"]/2
      status="PASS" if d+1e-9>=req else "FAIL"
    else:
      d=point_rect_dist(o["center"],wr); req=o["radius"]
      status="PASS" if d+1e-9>=req else "FAIL"
    tests.append({"subject":w["id"],"obstacle":o["id"],"distance_mm":round(d,6),"required_mm":round(req,6),"status":status})

# Proposal-to-proposal foreign-net checks.
newtracks=[e for e in routes if e["kind"]=="proposed_track"]
for i,e in enumerate(newtracks):
  for f in newtracks[i+1:]:
    if e["net"]==f["net"] or e["layer"]!=f["layer"]: continue
    d=min(seg_seg_dist(a,b,c,d) for a,b in zip(e["points"],e["points"][1:]) for c,d in zip(f["points"],f["points"][1:]))
    tests.append({"subject":e["id"],"obstacle":"proposal:"+f["id"],"distance_mm":round(d,6),"required_mm":.4,"status":"PASS" if d+1e-9>=.4 else "FAIL"})
for i,v in enumerate(proposal_vias):
  for w in proposal_vias[i+1:]:
    if v["net"]==w["net"]: continue
    d=math.hypot(v["at"][0]-w["at"][0],v["at"][1]-w["at"][1])
    tests.append({"subject":v["id"],"obstacle":"proposal:"+w["id"],"distance_mm":round(d,6),"required_mm":.7,"status":"PASS" if d+1e-9>=.7 else "FAIL"})

pair_spreads=[]
for c in range(1,5):
  for kind in ("main","common_mode","bias"):
    a=next(p for p in paths if p["id"]==f"ANALOG_CH{c}_ADC:P:{kind}")
    b=next(p for p in paths if p["id"]==f"ANALOG_CH{c}_ADC:N:{kind}")
    spread=abs(a["length_mm"]-b["length_mm"])
    pair_spreads.append({"group":f"ANALOG_CH{c}_ADC","kind":kind,"p_mm":a["length_mm"],"n_mm":b["length_mm"],
                         "spread_mm":round(spread,6),"limit_mm":1.0,"status":"PASS" if spread<=1.0 else "FAIL"})

failures=[t for t in tests if t["status"]=="FAIL"]
proposal={
 "schema":"north_adc_typed_corridor_proposal/v1","proposal_id":"north-adc-fixed-pose-hypothesis-1",
 "authority":"producer proposal only; independent acceptance required","engineering_verdict":"INCOMPLETE" if failures or any(x['status']=='FAIL' for x in pair_spreads) else "PROPOSAL-CLEAR",
 "rules":{"track_width_mm":WIDTH,"clearance_mm":CLEAR,"via_diameter_mm":VIA_D,"via_drill_mm":VIA_DRILL,
          "layers":["F.Cu","B.Cu"],"retained_fine_pitch_seed_width_mm":.20,"max_within_group_spread_mm":1.0},
 "denominators":{"nets":{"covered":len(graphs),"required":8},"native_pads":{"covered":len(endpoint_ids),"required":32},
                 "declared_paths":{"covered":len(paths),"required":24},"pn_groups":{"covered":4,"required":4}},
 "endpoint_ids":endpoint_ids,"lane_order":[{"net":n,"layer":"B.Cu","y_mm":LANES[n]} for n in NETS],
 "transition_windows":windows,"net_graphs":graphs,"declared_paths":paths,"paired_path_spreads":pair_spreads,
 "obstacle_model":{"source":geom["board"],"native_counts":geom["census"],"foreign_objects_enumerated":len(obs),
   "pad_geometry":"native effective bounding box; exact for axis-aligned rectangular pads and conservative otherwise",
   "seed_geometry":"native segment centerline and native width","via_geometry":"native center and diameter",
   "hole_geometry":"native drill center and maximum drill radius","keepouts":"all native restrictive rule areas by layer and prohibition flag"},
 "measurement_summary":{"tests":len(tests),"passes":sum(t['status']=='PASS' for t in tests),"failures":len(failures),
   "failing_subjects":sorted({t['subject'] for t in failures}),"minimum_margin_mm":round(min(t['distance_mm']-t['required_mm'] for t in tests),6)},
 "measurement_failures":failures,"all_measurements":tests,
 "plane_continuity":{"status":"OWED","reason":"Track-free native/r0 zones are unfilled evidence for this proposed copper; exact emitted board fill and independent In1.Cu/In2.Cu continuity review required."}
}
out.write_text(json.dumps(proposal,indent=2,sort_keys=True)+"\n")

# Vector plan: F.Cu and B.Cu geometry over obstacle boxes in the focused region.
colors={n:c for n,c in zip(NETS,["#e41a1c","#ff7f00","#377eb8","#4daf4a","#984ea3","#a65628","#f781bf","#00a6a6"])}
X0,X1,Y0,Y1=34,142,52,68; scale=8
W=(X1-X0)*scale; H=(Y1-Y0)*scale
def sx(x):return (x-X0)*scale
def sy(y):return (y-Y0)*scale
parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H*2+45}" viewBox="0 0 {W} {H*2+45}">',
       '<rect width="100%" height="100%" fill="white"/>']
for panel,layer,oy in (("F.Cu","F.Cu",20),("B.Cu","B.Cu",H+40)):
  parts.append(f'<text x="4" y="{oy-5}" font-size="12" font-family="monospace">{panel} proposal, native obstacle bboxes</text>')
  parts.append(f'<g transform="translate(0,{oy})"><rect width="{W}" height="{H}" fill="#f7f7f7" stroke="#222"/>')
  for o in obs:
    if o["type"] not in ("pad","keepout") or layer not in (o.get("layers") or [o.get("layer")]):continue
    r=o["bbox"]
    if r[2]<X0 or r[0]>X1 or r[3]<Y0 or r[1]>Y1:continue
    fill="#555" if o["type"]=="pad" else "#000"
    parts.append(f'<rect x="{sx(r[0]):.2f}" y="{sy(r[1]):.2f}" width="{(r[2]-r[0])*scale:.2f}" height="{(r[3]-r[1])*scale:.2f}" fill="{fill}" opacity=".22"/>')
  for e in routes:
    if e["layer"]!=layer:continue
    pts=' '.join(f'{sx(p[0]):.2f},{sy(p[1]):.2f}' for p in e["points"])
    dash=' stroke-dasharray="3 2"' if e["kind"]=='retained_source_seed' else ''
    parts.append(f'<polyline points="{pts}" fill="none" stroke="{colors[e["net"]]}" stroke-width="2"{dash}/>')
  for v in proposal_vias:
    x,y=v["at"]; parts.append(f'<circle cx="{sx(x):.2f}" cy="{sy(y):.2f}" r="2.2" fill="white" stroke="{colors[v["net"]]}" stroke-width="1.5"/>')
  parts.append('</g>')
parts.append('</svg>')
svg_path.write_text('\n'.join(parts)+"\n")
print(json.dumps({"verdict":proposal["engineering_verdict"],"paths":len(paths),"pads":len(endpoint_ids),"tests":len(tests),"failures":len(failures),"failing_subjects":proposal["measurement_summary"]["failing_subjects"]},sort_keys=True))
