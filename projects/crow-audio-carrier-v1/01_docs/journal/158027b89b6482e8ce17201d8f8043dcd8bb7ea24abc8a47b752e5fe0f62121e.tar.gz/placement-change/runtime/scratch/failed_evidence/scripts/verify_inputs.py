#!/usr/bin/env python3
import hashlib, json, sys
from datetime import datetime, timezone
from pathlib import Path
sys.dont_write_bytecode = True
root=Path(sys.argv[1]).resolve(); env_path=Path(sys.argv[2]).resolve(); out=Path(sys.argv[3]).resolve()
env=json.loads(env_path.read_text()); rows=[]
for item in env["input_packet"]:
    p=root/item["path"]
    if p.is_file():
        data=p.read_bytes(); actual_size=len(data); actual_sha=hashlib.sha256(data).hexdigest()
    else:
        actual_size=None; actual_sha=None
    rows.append({"name":item["name"],"path":item["path"],"expected_size":item["size"],"actual_size":actual_size,
                 "expected_sha256":item["sha256"],"actual_sha256":actual_sha,
                 "status":"PASS" if actual_size==item["size"] and actual_sha==item["sha256"] else "FAIL"})
payload={"verified_at_utc":datetime.now(timezone.utc).isoformat(),"root":str(root),"total":len(rows),
         "passed":sum(r["status"]=="PASS" for r in rows),"failed":sum(r["status"]=="FAIL" for r in rows),"rows":rows}
out.write_text(json.dumps(payload,indent=2,sort_keys=True)+"\n")
print(json.dumps({k:payload[k] for k in ("verified_at_utc","total","passed","failed")},sort_keys=True))
raise SystemExit(0 if payload["failed"]==0 else 1)
