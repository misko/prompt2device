#!/usr/bin/env python3
import gzip, hashlib, io, json, tarfile, sys
from datetime import datetime, timezone
from pathlib import Path
sys.dont_write_bytecode=True
base=Path(sys.argv[1]).resolve(); scratch=Path(sys.argv[2]).resolve(); outputs=Path(sys.argv[3]).resolve()
env_path=base/'06_build/task_runs/source-corridor/envelope.json'; env=json.loads(env_path.read_text())
proposal=json.loads((scratch/'north_adc_corridor_proposal.json').read_text())
before=json.loads((scratch/'input_verification_before.json').read_text())
after=json.loads((scratch/'input_verification_after.json').read_text())
validation=json.loads((scratch/'proposal_validation.json').read_text())
report_validation=json.loads((scratch/'report_validation.json').read_text())
digest=json.loads((scratch/'design_rules_digest.json').read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
copies={
 "native_copy.kicad_pcb":{"source":"project/04_kicad/crow_audio_carrier_v1.kicad_pcb","sha256":sha(scratch/'native_copy.kicad_pcb')},
 "native_copy.kicad_pro":{"source":"project/04_kicad/crow_audio_carrier_v1.kicad_pro","sha256":sha(scratch/'native_copy.kicad_pro')},
 "native_copy.kicad_dru":{"source":"project/04_kicad/crow_audio_carrier_v1.kicad_dru","sha256":sha(scratch/'native_copy.kicad_dru')},
 "r0_copy.kicad_pcb":{"source":"project/06_build/route/r0.kicad_pcb","sha256":sha(scratch/'r0_copy.kicad_pcb')},
 "r0_copy.kicad_pro":{"source":"project/06_build/route/r0.kicad_pro","sha256":sha(scratch/'r0_copy.kicad_pro')},
 "r0_copy.kicad_dru":{"source":"project/06_build/route/r0.kicad_dru","sha256":sha(scratch/'r0_copy.kicad_dru')},
}
expected={i["path"]:i["sha256"] for i in env["input_packet"]}
for row in copies.values():
    if row["sha256"]!=expected[row["source"]]: raise RuntimeError(f"copy hash mismatch: {row}")

native_runs=[]
run_names=['native-geometry','r0-geometry','native-geometry-2','r0-geometry-2','native-copy-geometry','r0-copy-geometry']
commands={
 'native-geometry':['/usr/bin/python3',str(scratch/'extract_geometry.py'),str(base/'project/04_kicad/crow_audio_carrier_v1.kicad_pcb'),str(scratch/'native_geometry.json')],
 'r0-geometry':['/usr/bin/python3',str(scratch/'extract_geometry.py'),str(base/'project/06_build/route/r0.kicad_pcb'),str(scratch/'r0_geometry.json')],
 'native-geometry-2':['/usr/bin/python3',str(scratch/'extract_geometry.py'),str(base/'project/04_kicad/crow_audio_carrier_v1.kicad_pcb'),str(scratch/'native_geometry.json')],
 'r0-geometry-2':['/usr/bin/python3',str(scratch/'extract_geometry.py'),str(base/'project/06_build/route/r0.kicad_pcb'),str(scratch/'r0_geometry.json')],
 'native-copy-geometry':['/usr/bin/python3',str(scratch/'extract_geometry.py'),str(scratch/'native_copy.kicad_pcb'),str(scratch/'native_geometry.json')],
 'r0-copy-geometry':['/usr/bin/python3',str(scratch/'extract_geometry.py'),str(scratch/'r0_copy.kicad_pcb'),str(scratch/'r0_geometry.json')],
}
for name in run_names:
    runtime=json.loads((scratch/f'{name}.runtime.json').read_text())
    native_runs.append({"name":name,"bounded_by":"pipeline_runtime.run_stage","argv":commands[name],"cwd":str(scratch),
                        "returncode":runtime["returncode"],"status":runtime["status"],"started_at":runtime["started_at"],
                        "finished_at":runtime["finished_at"],"elapsed_s":runtime["elapsed_s"],
                        "runtime_receipt":f"runtime/{name}.runtime.json","raw_stdout_stderr":f"logs/{name}.raw.log"})

evidence={
 "schema":1,"subject":env["subject"],"task_id":"source-corridor","stage_id":"KICAD-PLACEMENT",
 "producer":{"id":"/root/carrier_source_corridor","role":"judgment","context_mode":"FRESH","self_acceptance":"FORBIDDEN"},
 "engineering_verdict":"INCOMPLETE","order_verdict":"DO-NOT-ORDER",
 "scope":{"hypotheses":1,"poses":"fixed","pin_maps":"fixed","live_source_edits":0,"router_invocations":0,
          "candidate_boards_saved":0,"fourth_diagnostic":0,"network_calls":0},
 "input_verification":{"before":before,"after":after,"scratch_copy_binding":copies},
 "design_rules_digest":digest,
 "native_processes":native_runs,
 "commands":[
   {"argv":["/usr/bin/python3",str(scratch/'verify_inputs.py'),str(base),str(env_path),str(scratch/'input_verification_before.json')],"cwd":str(scratch),"rc":0},
   {"argv":["/usr/bin/python3",str(scratch/'design_rules_digest.py'),str(base/'authority/current/skills/kicad-pcb/scripts/pre_route_review_check.py'),str(base/'project'),str(scratch/'design_rules_digest.json')],"cwd":str(scratch),"rc":0},
   *[{"argv":["/usr/bin/cp",str(base/row["source"]),str(scratch/name)],"cwd":str(scratch),"rc":0} for name,row in copies.items()],
   {"argv":["/usr/bin/sha256sum",*[str(scratch/name) for name in copies]],"cwd":str(scratch),"rc":0,"result":"all six copies equal their envelope-bound source hashes"},
   *[{"argv":["/usr/bin/python3",str(scratch/'run_native.py'),str(scratch),*commands[n]],"cwd":str(scratch),"rc":json.loads((scratch/f'{n}.runtime.json').read_text())["returncode"]} for n in run_names],
   {"argv":["/usr/bin/python3",str(scratch/'build_proposal.py'),str(scratch/'r0_geometry.json'),str(scratch/'north_adc_corridor_proposal.json'),str(scratch/'north_adc_corridor.svg')],"cwd":str(scratch),"rc":0},
   {"argv":["/usr/bin/rsvg-convert","-o",str(scratch/'north_adc_corridor.png'),str(scratch/'north_adc_corridor.svg')],"cwd":str(scratch),"rc":0},
   {"argv":["/usr/bin/python3",str(scratch/'validate_proposal.py'),str(base/'project/03_src/rules/nets.yaml'),str(scratch/'north_adc_corridor_proposal.json'),str(scratch/'r0_geometry.json'),str(scratch/'proposal_validation.json')],"cwd":str(scratch),"rc":0},
   {"argv":["/usr/bin/python3",str(scratch/'validate_report.py'),str(outputs/'report.md'),str(scratch/'report_validation.json')],"cwd":str(scratch),"rc":0},
   {"argv":["/usr/bin/python3",str(scratch/'verify_inputs.py'),str(base),str(env_path),str(scratch/'input_verification_after.json')],"cwd":str(scratch),"rc":0}
 ],
 "actual_coverage":{
   "source_identity_validation":validation,
   "proposal_denominators":proposal["denominators"],"transition_windows":{"covered":len(proposal["transition_windows"]),"required":16},
   "native_r0_obstacles":proposal["obstacle_model"],"measurements":proposal["measurement_summary"],
   "paired_path_spreads":proposal["paired_path_spreads"],"plane_continuity":proposal["plane_continuity"],
   "report_header_validation":report_validation
 },
 "visual_inspection":[
   {"artifact":"project/06_build/pre_route/locator_native_top.png","method":"actual image view","finding":"four fixed north channel cells and the central ADC/filter field corroborate the native coordinate extraction; no routed-copper credit taken"},
   {"artifact":"figures/north_adc_corridor.png","method":"actual image view after SVG rasterization","finding":"eight separated B.Cu trunks are visibly simultaneous; the F.Cu terminal convergence overlays the dense ADC/filter obstacle field, consistent with measured failures"}
 ],
 "limitations":["producer proposal cannot independently accept itself","F.Cu terminal capsules fail 87 comparisons","8/12 paired path kinds exceed 1.0 mm","filled In1.Cu/In2.Cu reference continuity is owed","no emitted or routed board exists"],
 "generated_at_utc":datetime.now(timezone.utc).isoformat()
}
(outputs/'evidence.json').write_text(json.dumps(evidence,indent=2,sort_keys=True)+"\n")

members={
 'evidence/evidence.json':outputs/'evidence.json','evidence/report.md':outputs/'report.md',
 'data/north_adc_corridor_proposal.json':scratch/'north_adc_corridor_proposal.json','data/source_delta_plan.json':scratch/'source_delta_plan.json',
 'data/native_geometry.json':scratch/'native_geometry.json','data/r0_geometry.json':scratch/'r0_geometry.json',
 'data/design_rules_digest.json':scratch/'design_rules_digest.json','data/input_verification_before.json':scratch/'input_verification_before.json',
 'data/input_verification_after.json':scratch/'input_verification_after.json','data/proposal_validation.json':scratch/'proposal_validation.json',
 'data/report_validation.json':scratch/'report_validation.json','figures/north_adc_corridor.svg':scratch/'north_adc_corridor.svg',
 'figures/north_adc_corridor.png':scratch/'north_adc_corridor.png',
}
for name in ('extract_geometry.py','run_native.py','build_proposal.py','verify_inputs.py','design_rules_digest.py','validate_proposal.py','validate_report.py','build_delivery.py'):
    members['scripts/'+name]=scratch/name
for name in run_names:
    members[f'logs/{name}.raw.log']=scratch/f'{name}.raw.log'; members[f'runtime/{name}.runtime.json']=scratch/f'{name}.runtime.json'
for name,p in members.items():
    if not p.is_file():raise RuntimeError(f"missing archive member {name}: {p}")

archive=outputs/'evidence.tar.gz'
with archive.open('wb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
    with tarfile.open(fileobj=gz,mode='w') as tf:
      for name,p in sorted(members.items()):
        data=p.read_bytes(); ti=tarfile.TarInfo(name); ti.size=len(data); ti.mtime=0; ti.uid=ti.gid=0; ti.uname=ti.gname=''; ti.mode=0o644
        tf.addfile(ti,io.BytesIO(data))
rows=[{"path":name,"size":p.stat().st_size,"sha256":sha(p)} for name,p in sorted(members.items())]
manifest={"schema":1,"subject":env["subject"],"archive":{"path":"evidence.tar.gz","size":archive.stat().st_size,"sha256":sha(archive)},
          "member_count":len(rows),"members":rows}
(outputs/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+"\n")
(outputs/'result.json').write_text(json.dumps({"subject":env["subject"],"checks":{"evidence-complete":"PASS","inputs-verified":"PASS","review-complete":"PASS"},"unresolved":[]},separators=(',',':'))+"\n")
print(json.dumps({"archive":manifest["archive"],"members":len(rows),"evidence_bytes":(outputs/'evidence.json').stat().st_size},sort_keys=True))
