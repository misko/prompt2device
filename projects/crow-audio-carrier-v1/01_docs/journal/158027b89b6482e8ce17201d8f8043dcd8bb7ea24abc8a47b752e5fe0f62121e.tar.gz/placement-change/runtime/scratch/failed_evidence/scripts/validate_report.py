#!/usr/bin/env python3
import json,re,sys
from pathlib import Path
sys.dont_write_bytecode=True
p=Path(sys.argv[1]); out=Path(sys.argv[2]); fields={}; duplicates=[]
for line in p.read_text().splitlines():
    if line.startswith('# '): break
    m=re.match(r'^([a-z][a-z0-9_-]*):\s*(.*)$',line,re.I)
    if not m: continue
    k=m.group(1).lower()
    if k in fields: duplicates.append(k)
    fields[k]=m.group(2)
required={"subject","date","reviewer","context-given","source_commit","review_stage","review_kind","design_verdict","order_verdict",
          "board_sha256","design_rules_sha256","task_identity","envelope_sha256","reviewer_id","reviewer_provenance","context_mode",
          "raw_subject_sha256","semantic_subject_sha256","completed_at_utc","blocking_finding_ids","layout_finding","layout_finding_state",
          "layout_finding_class","diagnostic_request","diagnostic_nets","diagnostic_pad_denominator","diagnostic_path_denominator",
          "diagnostic_pn_groups","diagnostic_max_spread_mm","diagnostic_layers","diagnostic_track_width_mm","diagnostic_clearance_mm",
          "diagnostic_via_mm","diagnostic_reference_plane_proof","diagnostic_promotion","proposal_id","proposal_status","proposal_scope"}
missing=sorted(required-set(fields)); unknown_verdict=[]
if fields.get("design_verdict") not in {"SOUND","DEFECTIVE","INCOMPLETE"}: unknown_verdict.append("design_verdict")
if fields.get("order_verdict") not in {"ORDER","DO-NOT-ORDER","BLOCKED-SOURCING"}: unknown_verdict.append("order_verdict")
payload={"field_count":len(fields),"required_count":len(required),"duplicates":duplicates,"missing":missing,"unknown_verdict":unknown_verdict,
         "status":"PASS" if not duplicates and not missing and not unknown_verdict else "FAIL"}
out.write_text(json.dumps(payload,indent=2,sort_keys=True)+"\n"); print(json.dumps(payload,sort_keys=True))
raise SystemExit(0 if payload["status"]=="PASS" else 1)
