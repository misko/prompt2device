#!/usr/bin/env python3
import json, sys, yaml
from pathlib import Path
sys.dont_write_bytecode=True
nets=yaml.safe_load(Path(sys.argv[1]).read_text())
proposal=json.loads(Path(sys.argv[2]).read_text())
geom=json.loads(Path(sys.argv[3]).read_text())
out=Path(sys.argv[4])
groups=nets["length_match"]
expected=[]
for c in range(1,5):
    name=f"ANALOG_CH{c}_ADC"; g=groups[name]
    for pol in ("P","N"):
        for row in g["paths"][pol]:
            seg=row["segments"][0]
            expected.append({"id":f"{name}:{pol}:{row['id']}","group":name,"polarity":pol,
                             "kind":row["id"],"net":seg["net"],"from":seg["from"],"to":seg["to"]})
observed=[{k:p[k] for k in ("id","group","polarity","kind","net","from","to")} for p in proposal["declared_paths"]]
pad_net={p["id"]:p["net"] for p in geom["pads"] if p["pad"]}
endpoint_errors=[]
for g in proposal["net_graphs"]:
    for role,pid in g["terminals"].items():
        if pad_net.get(pid)!=g["net"]:
            endpoint_errors.append({"net":g["net"],"role":role,"pad":pid,"native_net":pad_net.get(pid)})
source_order=sorted(range(1,5),key=lambda c: next(g["nodes"]["source"][0] for g in proposal["net_graphs"] if g["net"]==f"ADC{c}P"))
adc_order=sorted(range(1,5),key=lambda c: next(g["nodes"]["main"][0] for g in proposal["net_graphs"] if g["net"]==f"ADC{c}P"))
channel_inversions=sum(1 for i,a in enumerate(source_order) for b in source_order[i+1:] if adc_order.index(a)>adc_order.index(b))
checks={
 "exact_source_path_identities":"PASS" if sorted(expected,key=lambda x:x["id"])==sorted(observed,key=lambda x:x["id"]) else "FAIL",
 "native_endpoint_nets":"PASS" if not endpoint_errors else "FAIL",
 "net_denominator":"PASS" if proposal["denominators"]["nets"]=={"covered":8,"required":8} else "FAIL",
 "pad_denominator":"PASS" if proposal["denominators"]["native_pads"]=={"covered":32,"required":32} else "FAIL",
 "path_denominator":"PASS" if proposal["denominators"]["declared_paths"]=={"covered":24,"required":24} else "FAIL",
 "group_denominator":"PASS" if proposal["denominators"]["pn_groups"]=={"covered":4,"required":4} else "FAIL",
 "transition_window_denominator":"PASS" if len(proposal["transition_windows"])==16 else "FAIL",
 "single_hypothesis":"PASS" if proposal["proposal_id"]=="north-adc-fixed-pose-hypothesis-1" else "FAIL"
}
payload={"checks":checks,"errors":{"endpoint_errors":endpoint_errors,"source_path_mismatch":[] if checks["exact_source_path_identities"]=="PASS" else {"expected":expected,"observed":observed}},
 "channel_order_proof":{"source_left_to_right":source_order,"adc_left_to_right":adc_order,"channel_pair_inversions":channel_inversions,
                         "cross_channel_conductor_inversions":channel_inversions*4},
 "status":"PASS" if set(checks.values())=={"PASS"} else "FAIL"}
out.write_text(json.dumps(payload,indent=2,sort_keys=True)+"\n")
print(json.dumps(payload,sort_keys=True))
raise SystemExit(0 if payload["status"]=="PASS" else 1)
