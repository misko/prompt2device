subject: crow-audio-carrier-v1 upstream north ADC placement-source comparison
date: 2026-09-12
reviewer: Codex judgment agent /root/carrier_placement_change
context-given: FRESH; frozen input packet; independent upstream source-change recommendation
source_commit: b436d612c8d2d325204ebd253f4c885bd66943ee
board_sha256: 9aa1c2c821a31129176a8b519b9a211d78dfc011adb997a64470c03d0726891f
design_verdict: RECOMMEND-A-FOR-SOURCE-IMPLEMENTATION
order_verdict: DO-NOT-ORDER
scope: noncanonical upstream source-placement recommendation; not layout acceptance or route evidence
reviewer_provenance: independent judgment over frozen exact geometry; cannot accept later implementation
blocking_finding_ids: [LAYOUT-001]

# Upstream north ADC placement-source comparison

## Judgment

Adopt **A, a ten-footprint local satellite move**, as the smallest justified next source change. Keep `U_ADC`, `J1..J8`, `U_AFE1..8`, `U_ISO1..8`, all eight pin maps, all south placements, and the clock/reset/reference/supply IC poses fixed. Move the two north FILT1 ceramics and all eight north common-mode capacitors into two wings, then replace the failed long vertical terminal launches with one source-owned 0.70 mm-pitch via row. This directly removes the objects responsible for the failed F.Cu terminal geometry while retaining the broad B.Cu corridor that already passed 2,036/2,036 trunk comparisons.

This is a source-feasibility recommendation. The coordinates below are concrete enough to implement and regenerate, but no modified board was emitted and no routed copper exists. `LAYOUT-001` remains open until a different independent reviewer checks the regenerated exact board.

## Why A is smaller than B or C

The fixed-pose hypothesis failed 87 of 113,044 comparisons. Every failure was an F.Cu `main_launch`, `common_mode_branch`, or four tiny north N bias branches; all eight B.Cu trunks, sixteen vias, and sixteen transition windows passed. The physical main-launch obstacles were `C_FILT1_1U`, `C_FILT1_10U`, `C_ADC_CM3N`, `C_ADC_CM4N`, one local GND seed/via, and proposed-track self-conflicts. A local rearrangement therefore responds to the measured failure.

Option B, reversing north physical pod-to-ADC assignment, is not expressly forbidden by BRIEF G1: a documented fixed permutation can still be deterministic and hardware mode does not itself require project-authored firmware. It does, however, reopen the current exact connector→AFE→isolation→ADC→TDM mapping in `rules/nets.yaml`, the schematic, netlist, analog-path tests, pin review, labels, and channel/slot qualification. More importantly, changing net identity does not move the two FILT1 footprints or the local common-mode bodies that blocked the terminal fanout. B can remove the six bundle inversions and 24 conductor inversions, but cannot by itself clear the failed terminal field. It is therefore a larger electrical change without being a complete geometric fix.

Option C, rotating `U_ADC`, is unjustified while A remains viable. Rotation changes both north and south analog launches and also reopens the FILT1/FILT2, VMID1/VMID2, LDO_A/LDO_D, clock, TDM, reset, configuration, paddle-gap, and thermal-via relationships. It is the fallback only if regenerated option A fails exact placement review.

## Exact before/after source delta

All coordinates are millimetres in the existing board datum. Side remains F.Cu.

| Reference | Before x,y,rot | After x,y,rot | Owning reason |
|---|---|---|---|
| C_FILT1_1U | 96.60,64.60,0 | 98.60,64.80,270 | clears ADC1/2 vertical terminal field; FILT1 pin43 copper gap 2.31 mm <=2.5 and pin-centre span 3.44 mm <=5 |
| C_FILT1_10U | 96.75,62.55,0 | 100.80,64.20,0 | moves beyond terminal bay; FILT1 copper gap 3.86 mm <=4 and pin-centre span 4.56 mm <=5 |
| C_ADC_CM4P | 93.00,62.65,90 | 90.80,63.40,180 | west wing; matching ADC48-pad copper gap 3.64 mm <=4 |
| C_ADC_CM4N | 94.25,62.65,90 | 90.80,64.70,180 | west wing; ADC47 gap 3.02 mm <=4 |
| C_ADC_CM3P | 93.00,64.80,90 | 92.30,64.70,180 | west wing; ADC46 gap 2.18 mm <=2.5 |
| C_ADC_CM3N | 94.25,64.80,90 | 92.30,66.00,180 | west wing; ADC45 gap 1.87 mm <=2.0 |
| C_ADC_CM2P | 99.40,64.80,90 | 99.80,66.00,0 | east wing; ADC42 gap 2.76 mm <=3.5 |
| C_ADC_CM2N | 100.65,64.80,90 | 101.10,66.00,0 | east wing; ADC41 gap 3.66 mm <=4.5 |
| C_ADC_CM1P | 102.35,66.60,0 | 102.40,67.00,0 | east wing; ADC40 gap 4.54 mm <=5 |
| C_ADC_CM1N | 102.35,65.30,0 | 102.40,65.70,0 | east wing; ADC39 gap 4.19 mm <=5 |

The gap arithmetic translates the exact native pad bounding boxes and rotates the exact 0402/0603/0805 pad geometry; it uses the source's 0.15 mm courtyard target and the 0.20/0.20 mm routing rule. The narrowest proposed component-to-component courtyard separation is 0.20 mm (between the relocated FILT ceramics), above the source's 0.15 mm local acceptance floor. The narrowest track-centre-to-foreign-pad boundary in the terminal bay is 0.34 mm, above the required 0.30 mm capsule distance. These are algebraic source checks, not a regenerated native DRC result.

Replace the eight failed destination-via locations with this ordered row at y=63.00: `ADC4P` (93.40), `ADC4N` (94.10), `ADC3P` (94.80), `ADC3N` (95.50), `ADC2P` (96.20), `ADC2N` (96.90), `ADC1P` (97.60), `ADC1N` (98.30). Each via is 0.50/0.20 mm. Adjacent edges are 0.20 mm apart, exactly the rule. Retain each existing one-millimetre, 0.20 mm ADC-pin launch and fan it monotonically to this row; no net-order crossing occurs. Tee each common-mode branch from its corresponding pin launch before the layer transition. The four existing N bias branches remain at their current resistors and receive a short outward dogleg around `U_ISO*.5`; moving those resistors would break the deliberate north/south repeated-cell symmetry for a 0.053094 mm route-only deficit.

`floorplan.yaml` changes only the ten anchors above. `route.yaml` must replace the eight failed north terminal destination-via/launch seeds, preserve the eight already-cleared B.Cu lane owners, add the exact terminal-bay/via-row reservation, and add four B.Cu compensation boxes: CH1 [38.5,54.8]-[47.0,59.0], CH2 [70.5,56.0]-[79.0,60.2], CH3 [101.0,57.4]-[109.5,61.6], CH4 [130.0,58.8]-[138.5,63.0]. Each 8.5 x 4.2 mm box can hold two 0.40 mm-pitch return legs, providing 5.6 mm of deterministic added centreline—enough to absorb the failed hypothesis's worst 5.0 mm P/N difference while retaining the <=1 mm final ceiling. Actual copper lengths still must be measured after route realization.

## Channel, pin, and path accounting

No mapping changes under A. The complete ADC-side graph remains:

| Channel | External chain | P ADC pin / CM / bias | N ADC pin / CM / bias | placement |
|---|---|---|---|---|
| 1 | J1→U_AFE1→U_ISO1 | U_ADC.40 / C_ADC_CM1P.1 / R_ADC_PD1P.1 | U_ADC.39 / C_ADC_CM1N.1 / R_ADC_PD1N.1 | north, satellites moved |
| 2 | J2→U_AFE2→U_ISO2 | U_ADC.42 / C_ADC_CM2P.1 / R_ADC_PD2P.1 | U_ADC.41 / C_ADC_CM2N.1 / R_ADC_PD2N.1 | north, satellites moved |
| 3 | J3→U_AFE3→U_ISO3 | U_ADC.46 / C_ADC_CM3P.1 / R_ADC_PD3P.1 | U_ADC.45 / C_ADC_CM3N.1 / R_ADC_PD3N.1 | north, satellites moved |
| 4 | J4→U_AFE4→U_ISO4 | U_ADC.48 / C_ADC_CM4P.1 / R_ADC_PD4P.1 | U_ADC.47 / C_ADC_CM4N.1 / R_ADC_PD4N.1 | north, satellites moved |
| 5 | J5→U_AFE5→U_ISO5 | U_ADC.14 / C_ADC_CM5P.1 / R_ADC_PD5P.1 | U_ADC.13 / C_ADC_CM5N.1 / R_ADC_PD5N.1 | unchanged south |
| 6 | J6→U_AFE6→U_ISO6 | U_ADC.16 / C_ADC_CM6P.1 / R_ADC_PD6P.1 | U_ADC.15 / C_ADC_CM6N.1 / R_ADC_PD6N.1 | unchanged south |
| 7 | J7→U_AFE7→U_ISO7 | U_ADC.20 / C_ADC_CM7P.1 / R_ADC_PD7P.1 | U_ADC.19 / C_ADC_CM7N.1 / R_ADC_PD7N.1 | unchanged south |
| 8 | J8→U_AFE8→U_ISO8 | U_ADC.22 / C_ADC_CM8P.1 / R_ADC_PD8P.1 | U_ADC.21 / C_ADC_CM8N.1 / R_ADC_PD8N.1 | unchanged south |

For each of north channels 1–4, the six declared paths are `P.main` ISO.2→ADC, `P.common_mode` ISO.2→CM.1, `P.bias` ISO.2→PD.1, `N.main` ISO.6→ADC, `N.common_mode` ISO.6→CM.1, and `N.bias` ISO.6→PD.1. That is 24/24 paths and the 32/32 unique north terminal pads. The four groups remain `ANALOG_CH1_ADC` through `ANALOG_CH4_ADC`; all eight nets remain owned together. Channels 5–8 retain the same six-path structure (24 unchanged south paths), so the whole connector-to-AFE-to-ADC denominator is 48 paths across eight groups.

The six north bundle inversions and 24 conductor inversions remain under A; no improvement is claimed by merely moving an inversion upstream. The recommendation instead clears a simultaneous two-layer terminal bay and reserves explicit P/N compensation space. The existing <=1 mm rule remains unchanged for main, common-mode, and bias paths.

## Dependencies and gate ordering

The source change does not alter VMID1/2, FILT2, LDO_A/D, VDDA/VDDIO, clock, TDM, reset, CFG, exposed-paddle, or thermal-via connectivity. FILT1 ceramic placement changes, so its pin43-to-1uF/10uF short budgets and ground returns must renew. All ten moved footprints remain fitted and locatable; their assembly population attributes do not change.

There is no circular requirement to demonstrate a complete routed board before placement acceptance. Source implementation must emit the ten exact poses, the eight existing 1 mm pin seeds, the eight new source-owned vias/fanout seeds, and review-visible net-specific corridor/compensation reservations into a regenerated native board. Fill its existing GND zones and independently inspect courtyard, terminal capsules, via legality, and unbroken In1.Cu/In2.Cu around those **source-owned transition vias**. That is legitimate pre-route placement evidence; it is source regeneration and independent placement review, not a fourth route candidate. It proves the board admits the reserved geometry without claiming that absent trunks are connected.

After placement acceptance, ordinary authorized routing may realize the reserved trunks. The routed-board gate must then refill zones and repeat connectivity, DRC, 32-pad/24-path/four-group length, <=1 mm matching, and filled-reference continuity on the actual copper. The pre-route proof does not transfer those routed results, and the routed gate does not weaken the pre-route clearance checks.

## Remaining uncertainty

Implementation/regeneration, exact KiCad pin and courtyard validation, source-test updates, route-source contract updates, exact render/locator review, independent layout review, and actual filled-copper proof are owed. The algebra establishes a reviewable source hypothesis with specific coordinates; it is not self-acceptance. If exact regeneration disproves any claimed clearance, stop A and reopen the comparison before considering ADC rotation. Board release and ordering remain blocked.
