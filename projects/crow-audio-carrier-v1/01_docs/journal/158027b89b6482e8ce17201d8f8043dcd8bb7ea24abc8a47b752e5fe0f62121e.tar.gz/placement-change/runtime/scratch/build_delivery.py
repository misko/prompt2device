#!/usr/bin/env python3
import datetime, hashlib, io, json, pathlib, tarfile
R=pathlib.Path('/tmp/carrier-placement-change-vw0sdfkg')
S=R/'06_build/task_runs/placement-change/scratch'; O=R/'06_build/task_runs/placement-change/outputs'
O.mkdir(parents=True,exist_ok=True)
env=json.loads((R/'06_build/task_runs/placement-change/envelope.json').read_text())
before=json.loads((S/'input-verification-before.json').read_text()); after=json.loads((S/'input-verification-after.json').read_text())
commands=[
 {'argv':['sed','-n','1,260p',str(R/'TASK.md')],'cwd':'/home/mouse9911/gits/circuits','rc':0,'purpose':'read complete task contract'},
 {'argv':['python3',str(S/'verify_inputs.py'),str(R)],'cwd':'/home/mouse9911/gits/circuits','rc':0,'purpose':'verify frozen inputs before analysis'},
 {'argv':['tar','-xzf',str(R/'failed-fixed-pose/evidence.tar.gz'),'-C',str(S/'failed_evidence')],'cwd':'/home/mouse9911/gits/circuits','rc':0,'purpose':'read prior exact geometry evidence'},
 {'argv':['rg','-n','C_ADC_CM|R_ADC_PD|U_ADC|C_FILT',str(R/'project/03_src/floorplan.yaml')],'cwd':'/home/mouse9911/gits/circuits','rc':0,'purpose':'locate source-owned placements'},
 {'argv':['/usr/bin/rsvg-convert','-o',str(S/'placement_delta.png'),str(S/'placement_delta.svg')],'cwd':str(S),'rc':0,'purpose':'bounded visual render','runtime_record':'render-placement.runtime.json','raw_log':'render-placement.raw.log'},
 {'argv':['python3',str(S/'verify_inputs.py'),str(R)],'cwd':'/home/mouse9911/gits/circuits','rc':0,'purpose':'verify frozen inputs after analysis'}]
evidence={
 'schema':'upstream-placement-comparison-evidence/v1','subject':env['subject'],'task_id':'placement-change',
 'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z'),
 'scope':'noncanonical upstream source-placement recommendation; no live writes, router, search, candidate copper, or promotion',
 'commands':commands,
 'input_verification':{'before':{'count':before['count'],'pass_count':before['pass_count'],'status':before['status']},'after':{'count':after['count'],'pass_count':after['pass_count'],'status':after['status']},'full_rows':['data/input-verification-before.json','data/input-verification-after.json']},
 'authority_read':['TASK.md','reassessment/report.md','failed-fixed-pose/report.md','project/01_docs/BRIEF.md','project/01_docs/decisions/0001-single-cs5308p-tdm8.md','project/01_docs/decisions/0013-adc-source-exits.md','project/01_docs/decisions/0018-adc-analog-launches.md','project/03_src/floorplan.yaml','project/03_src/rules/nets.yaml','project/02_parts/CS5308P-DN/part.yaml'],
 'actual_coverage':{
   'options_compared':['A local satellites','B north physical channel assignment reversal','C ADC rotation'],
   'recommended':'A local satellites','moved_footprints':10,'fixed_hardware_poses':'all other footprints',
   'whole_graph':{'channels':8,'north_nets':8,'north_unique_pads':32,'north_declared_paths':24,'north_pn_groups':4,'south_declared_paths_unchanged':24,'all_adc_paths':48},
   'failed_exact_geometry':{'comparisons':113044,'failures':87,'bcu_trunk_passes':2036,'vias_passed':16,'windows_passed':16},
   'proposal_rules_mm':{'track_width':0.2,'clearance':0.2,'via':'0.50/0.20','pn_max_spread':1.0},
   'native_geometry_basis':'translated/rotated exact native pad bounding boxes from frozen native_geometry.json; no modified PCB emitted',
   'placement_acceptance':'OWED on regenerated exact board','routed_copper_acceptance':'OWED after ordinary authorized routing'
 },
 'visual_inspection':{'artifact':'figures/placement_delta.png','performed':True,'finding':'Viewed the rendered overlay at original detail; the proposed green satellite wings flank the purple 0.70 mm-pitch terminal-via row and fixed blue U_ADC. Figure is explanatory, not a native render or clearance acceptance.'},
 'engineering_verdict':'RECOMMEND-A-FOR-SOURCE-IMPLEMENTATION','order_verdict':'DO-NOT-ORDER',
 'unresolved_engineering':['exact regenerated courtyard/DRC check','independent exact-board placement acceptance','actual routed lengths and <=1 mm spreads','post-route filled-plane continuity']
}
(O/'report.md').write_text((S/'report.md').read_text())
(O/'evidence.json').write_text(json.dumps(evidence,indent=2,sort_keys=True)+'\n')
(O/'result.json').write_text(json.dumps({'subject':env['subject'],'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]},separators=(',',':'))+'\n')
members=[
 ('data/proposal.json',S/'proposal.json'),('data/input-verification-before.json',S/'input-verification-before.json'),('data/input-verification-after.json',S/'input-verification-after.json'),
 ('figures/placement_delta.svg',S/'placement_delta.svg'),('figures/placement_delta.png',S/'placement_delta.png'),
 ('logs/render-placement.raw.log',S/'render-placement.raw.log'),('runtime/render-placement.runtime.json',S/'render-placement.runtime.json'),
 ('scripts/verify_inputs.py',S/'verify_inputs.py'),('scripts/build_delivery.py',S/'build_delivery.py'),('evidence/evidence.json',O/'evidence.json'),('evidence/report.md',O/'report.md')]
manifest_members=[]
with tarfile.open(O/'evidence.tar.gz','w:gz',compresslevel=9) as tf:
 for arc,p in members:
  b=p.read_bytes(); info=tarfile.TarInfo(arc); info.size=len(b); info.mtime=0; info.mode=0o644
  tf.addfile(info,io.BytesIO(b)); manifest_members.append({'path':arc,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
ab=(O/'evidence.tar.gz').read_bytes()
manifest={'schema':'evidence-manifest/v1','members':manifest_members,'archive':{'path':'evidence.tar.gz','size':len(ab),'sha256':hashlib.sha256(ab).hexdigest()}}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps({'outputs':sorted(p.name for p in O.iterdir()),'archive':manifest['archive'],'inputs':after['status']}))
