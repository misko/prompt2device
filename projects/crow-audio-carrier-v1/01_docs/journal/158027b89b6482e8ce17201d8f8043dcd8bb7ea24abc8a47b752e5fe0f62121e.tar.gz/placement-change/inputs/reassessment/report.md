# D-BACK judgment — exhausted north-ADC corridor pilot

## Verdict

**REASSESS the method boundary and return to source-owned placement/corridor design. Do not dispatch a fourth route attempt. Do not move hardware now.**

The third guarded attempt was admitted correctly through the typed diagnostic gate, prepared the exact `r0`, and then stopped before KiCadRoutingTools (KRT) launched. Its owning cause is a root-runner/config-location integration defect: `current_pilot_runner.py` copied the route configuration to `06_build/route/north_adc_pilot/runner_logs/pilot-config.yaml`; `route_and_stitch_generic.py --root` accepted that location for its own project resolution, but `_route_ownership_gate()` invoked `route_ownership_preflight.py` with the copied config path and no project-root argument. The checker independently requires a `03_src` ancestor and returned `ROUTE-OWNERSHIP INCOMPLETE: route config must live below 03_src`. The route stage exited after 0.577 s. No KRT process, route candidate, candidate receipt, or routed copper exists.

This is not evidence that the present placement is unroutable. It also is not a free setup repair: the method explicitly charges a failed dispatch, and the durable reservation is spent.

## Exact diagnosis and evidence coverage

The closed execution establishes the following coverage:

- Native qualification: **PASS, 4/4**.
- Typed diagnostic admission: **PASS**. The schematic-side canonical review passed; the placement-side canonical review returned the expected single failure because the exact layout review is `INCOMPLETE` for `LAYOUT-001`; locator and render bindings were sound; diagnostic admission was true while engineering, production-routing, and promotion admission remained false.
- Pilot binding: **PASS**. The copied config differs from `03_src/route.yaml` only in `project.build_dir`, `prep.waves.groups`, and `route.waves`. The wave is exactly eight nets (`ADC1P/N` through `ADC4P/N`) on F.Cu/B.Cu at 0.20 mm width/clearance with 0.50/0.20 mm vias; ownership, candidate grade, and exploration guard remain enforce-mode.
- Native preparation: **PASS**. The exact `r0` sidecars were reproduced; 105 seed banks placed 253 primitives/vias before KRT.
- Tier preflight: **PASS with 2 warnings and 0 failures**.
- Route ownership: **INCOMPLETE**, solely because the copied config is under `06_build` and the owning checker has no propagated project-root argument.
- KRT/candidate/physical coverage: **0**. No KRT launch, no changed board, no candidate receipt, no connectivity result, no 32-pad census, no 24-path measurements, no four-group matching result, no legal-via result, and no filled-reference-plane continuity proof.

The actual owning call chain is visible in the immutable code. `route_and_stitch_generic.load_cfg(path, root)` accepts an explicit root and stores it in `cfg["_root"]`. `_route_ownership_gate()` then calls `route_ownership_preflight.py cfg["_path"] --json ...`. The checker resolves the config and searches its parents for `03_src`; it has no `--root` option and rejects when that ancestor is absent. Thus outer `--root` does not reach the checker. The failure is current-tool behavior, not an earlier stale snapshot.

## Lifecycle and cumulative cap

The stable `LAYOUT-001-corridor-evidence` investigation has two assessed custom probes plus the third reserved dispatch:

1. custom attempt 1: outside the valid board model, no saved geometry;
2. custom attempt 2: outside the valid board model, no saved geometry;
3. `launch-ece923e4057841aab71d02bfc16ec934`: admitted and dispatched, then stopped at the owning preflight before KRT.

The third reservation therefore makes the cumulative spend **3/3**. Under `lifecycle-and-backtrack.md`, a failed dispatch must be assessed under the same reservation and counts toward the total cap. `REASSESS` stops further launches under this investigation; it does not stop unrelated project work or upstream design work.

The following are not authorized continuations: correcting the copied config and rerunning it; enlarging either cap; renaming/copying the finding or ledger; using a different candidate ID; routing directly; skipping ownership preflight; adding an owner-JSON exception; branching from an old attempt; or calling the same candidate a new subject. A shared-tool correction may be made and tested as infrastructure work, but it cannot retroactively produce corridor evidence or restore an attempt slot for this board.

Root subsequently reported that the same reservation has been assessed in both owning worktrees, with 3/3 spent, no pending launch, and evaluator state `REASSESS`. That coordinator report is consistent with this independent reading; it is not used as geometric evidence because it postdates the frozen packet.

## Source geometry judgment

The current source itself proves a real ordering problem that the failed route did not test. `floorplan.yaml` places the four north analog banks left-to-right at x = 40.5, 72.5, 104.5, and 136.5 mm for channels 1, 2, 3, and 4. Their isolation centers are at y = 54.1 mm. `route.yaml` places the north ADC launch centers left-to-right at x = 94.0, 94.8, 96.4, and 97.2 mm for channels 4, 3, 2, and 1. The source order is therefore `[1,2,3,4]` and the ADC order `[4,3,2,1]`.

All six channel pairs are inverted. With two conductors per channel, those six bundle inversions contribute **24 cross-channel conductor inversions**. The required evidence denominator remains eight nets, 32 pads, 24 declared paths, and four P/N groups. The rendered exact board visually agrees with the source placement: four fixed north channel cells span the top half while the ADC sits centrally below their inner edges; it does not show routed copper or establish a corridor.

A simple reorder of the four complete north banks is not a justified fix. The north connectors are also ordered channel 1 through 4 from left to right. With connector order `[1,2,3,4]` and ADC order `[4,3,2,1]`, any linear bank permutation merely moves the six bundle inversions between the connector-to-bank and bank-to-ADC halves; it cannot remove the endpoint-order reversal while logical ADC and pod pin maps remain fixed. Such a move would change a large, already reviewed placement without responding to any measured physical failure. Rotation or relocation of the ADC would also disturb the south-bank, reference, supply, clock, and reset geometry and has no present evidence basis.

## Concrete authorized next workpacket

Commission one fresh **KICAD-PLACEMENT / source-corridor reassessment**, with no KRT invocation and no route candidate. It has two bounded, ordered parts.

First, correct the reusable integration defect in the shared tools. Update `authority/skills/kicad-pcb/scripts/route_ownership_preflight.py` to accept an explicit project root, and update `_route_ownership_gate()` in `authority/skills/kicad-pcb/scripts/route_and_stitch_generic.py` to pass `cfg["_root"]`. The checker must continue loading route intent from the exact supplied config while resolving the board and `03_src/rules/nets.yaml` from the explicit project root; it must reject roots outside the config's admitted project and must retain the current `03_src` behavior when no root is supplied. Add hostile and positive tests for a canonical `03_src/route.yaml`, an admitted `06_build` diagnostic copy with explicit root, a diagnostic copy without root, and a mismatched root. Update the governing skill contract because this changes a gate interface. Closure is checker PASS on both legal locations plus hostile failures. This work is prevention only; its completion does not authorize another `LAYOUT-001` pilot.

Second, retain all current hardware poses and compare one source-defined simultaneous two-layer corridor against the present unreserved placement. The board-side source delta should be limited to:

- `project/03_src/route.yaml`: declare one named north-ADC corridor reservation that owns all eight nets together, with explicit F.Cu/B.Cu lane order, legal transition windows, 0.20 mm width/clearance, 0.50/0.20 mm vias, the 32-pad/24-path/four-group denominators, and claim order ahead of flexible analog routing;
- `project/03_src/floorplan.yaml`: add only the geometric reservation/keep-clear polygons or transition-window rectangles required to keep later waves out of those lanes; leave `J1..J4`, `U_AFE1..4`, `U_ISO1..4`, `R_ADC_PD1..4`, `U_ADC`, ADC support parts, and all south-bank poses unchanged in the first hypothesis;
- `project/03_src/tests/test_route_source_contract.py` and the relevant source-geometry test: prove exact net membership, lane/window containment, no overlap with holes/keepouts/seed copper, and full denominator coverage. If the repository has no typed net-specific corridor-reservation schema, add the minimal shared schema/emitter/checker support and its contract/tests rather than encoding the reservation as comments or global keepouts.

The geometric comparison must enumerate every one of the 24 declared `ANALOG_CH1_ADC` through `ANALOG_CH4_ADC` paths, not just eight source-to-ADC trunks. It must show simultaneous legal capsules for eight tracks, every F.Cu/B.Cu transition, and unbroken In1.Cu/In2.Cu GND under and around each transition. It must preserve the current 1.0 mm P/N path-spread ceiling and demonstrate that no other owned seed, ADC supply/reference/reset geometry, hole, or keepout consumes a reserved lane. A static channel-order proof should remain in the evidence so reviewers can see why bank permutation alone cannot eliminate the reversal.

Only if that deterministic source reservation cannot be expressed with legal capsules should a later placement packet compare larger changes. That later comparison must evaluate the full connector→AFE→ADC path and the south ADC banks together; it may not claim improvement from moving the 24 inversions out of the north-ADC region. Logical channel identity, ADC pin map, and pod connector pin map remain unchanged unless separately reopened by explicit electrical authority.

## Gates that must renew and closure boundary

A corridor-source change makes downstream placement artifacts stale. Regenerate the board from source and renew source tests, route-source contract, native qualification, exact placement/layout review, exact render review, locator/route-base integrity, and the canonical pre-route review binding. Any shared gate-interface change must pass its own positive/hostile tests and contract audit. If hardware poses remain unchanged and only source reservation metadata/copper-exclusion geometry changes, schematic topology and pin identity may be transferred only through their existing exact-subject equivalence mechanism; do not assume transfer.

`LAYOUT-001` stays open until a fresh independent review of the regenerated exact board and its exact source reservation accepts all eight nets, 32 pads, 24 paths, four P/N groups, via legality, matching, and filled-reference continuity. A checker PASS, tool fix, route-process exit, or declared reservation alone is insufficient. Once that source/placement evidence is accepted and the placement gate is green, ordinary global routing can begin under a new stage authorization; it is not a fourth diagnostic attempt and must not reuse the exhausted pilot reservation or candidate.

Still unknown: whether an exact legal two-layer corridor exists through the current obstacle field; exact transition-window coordinates and lane assignment; the realized 24 path lengths and P/N spreads; filled-plane continuity after copper realization; final DRC/connectivity; and all physical/first-article evidence already excluded by the review. `LAYOUT-001` therefore remains open and board release remains blocked.
