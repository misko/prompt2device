subject: crow-audio-carrier-v1 fixed-pose north ADC source-corridor producer proposal
date: 2026-09-12
reviewer: Codex producer judgment agent /root/carrier_source_corridor
context-given: FRESH; exact immutable current source/native/r0 packet; closed D-BACK supplied as upstream authority
source_commit: b436d612c8d2d325204ebd253f4c885bd66943ee
review_stage: pre-route
review_kind: layout
design_verdict: INCOMPLETE
order_verdict: DO-NOT-ORDER
board_sha256: 9aa1c2c821a31129176a8b519b9a211d78dfc011adb997a64470c03d0726891f
design_rules_sha256: 0637fdb2d3f5ab247c301147ad6ed875343674c225e5036a2bb1935bd025cec3
r0_board_sha256: 8b7e13e1816618b5908c76f19562c7530cb700b1d03d9c6dedaec88d9c9bd609
task_identity: task_id=source-corridor; run_id=source-corridor; input_handoff_id=source-corridor; stage_id=KICAD-PLACEMENT
envelope_sha256: f153e2dd25b051fb74f356c27b98aadc991b475904ab5d3929cd5ab9c8ffaa16
reviewer_id: /root/carrier_source_corridor
reviewer_provenance: producer-proposal; cannot self-accept
context_mode: FRESH
raw_subject_sha256: e1b1b4ac9f2c63b480117ae4ad84926593449be87376aad890d63ab9fc4e980e
semantic_subject_sha256: 4209bc332780ab4a69daa7a4cf7e0c066805648d1bfc14ab10ee69814da7fcde
completed_at_utc: 2026-09-12T01:55:37.199320Z
blocking_finding_ids: ["LAYOUT-001"]
layout_finding: LAYOUT-001
layout_finding_state: OPEN
layout_finding_class: missing_simultaneous_corridor_evidence
diagnostic_request: simultaneous_source_corridor_reservation
diagnostic_nets: ADC1P,ADC1N,ADC2P,ADC2N,ADC3P,ADC3N,ADC4P,ADC4N
diagnostic_pad_denominator: 32
diagnostic_path_denominator: 24
diagnostic_pn_groups: ANALOG_CH1_ADC,ANALOG_CH2_ADC,ANALOG_CH3_ADC,ANALOG_CH4_ADC
diagnostic_max_spread_mm: 1.0
diagnostic_layers: F.Cu,B.Cu
diagnostic_track_width_mm: 0.20
diagnostic_clearance_mm: 0.20
diagnostic_via_mm: 0.50/0.20
diagnostic_reference_plane_proof: OWED
diagnostic_promotion: FORBIDDEN
proposal_id: north-adc-fixed-pose-hypothesis-1
proposal_status: INCOMPLETE
proposal_scope: one analytically constructed fixed-pose geometry hypothesis; no route search and no emitted copper board

# North ADC fixed-pose source-corridor proposal

## Verdict

**INCOMPLETE. Keep LAYOUT-001 open and do not admit routing or ordering from this proposal.**

One explicit two-layer geometry hypothesis was constructed for all eight north ADC nets with all hardware poses and logical, pod, and ADC pin maps fixed. The B.Cu lane trunks and all proposed via/window locations clear the exact prepared-r0 obstacle field under the stated 0.20 mm width, 0.20 mm clearance, and 0.50/0.20 mm via rules. The F.Cu destination launches and common-mode branches do not: 87 exact comparisons fail, and eight of twelve paired declared-path comparisons exceed the 1.0 mm spread ceiling. This is useful upstream evidence that the broad B.Cu corridor is available but the proposed fixed vertical terminal fanout is not an admissible source reservation.

This is the producer's proposal and measurement of its own geometry. It is not independent acceptance, a saved routing candidate, or a fourth diagnostic attempt.

## Authority and method

The closed D-BACK was read as final upstream authority: the prior reservation is 3/3 spent, no fourth route probe is authorized, current poses remain fixed for this comparison, and `route.ownership.corridors` currently proves only claim order. No KRT, custom router, stochastic search, candidate copper, board synthesis, or live source edit was performed.

All 341 immutable packet inputs passed exact byte-size and SHA-256 verification before analysis. The packet's current placement/review/ledger state is commit `b436d612c8d2d325204ebd253f4c885bd66943ee`. The canonical exact-board reviews carry the earlier accepted schematic checkpoint `4793527e8645e2e58dd3061bb2eb64b591e69ccb`; the supplied equivalence record says these do not represent different carrier electrical geometry or fitted-part pin projection. The current board hash, r0 hash, route/floorplan/rules sources, canonical layout review, and closed D-BACK are bound in the evidence. The semantic `design_rules_sha256` above was recomputed through the supplied owning `pre_route_review_check.design_rules_digest(project)` API; it is not the raw `.kicad_dru` byte hash.

Native geometry extraction used pcbnew 10.0.4 only inside bounded `pipeline_runtime.run_stage` executions. The native board contains 1,002 pads, zero track segments, eleven vias, and 77 rule areas. Prepared r0 contains 1,002 pads, 235 source-owned seed segments, 29 vias, and 77 rule areas. The measurement model enumerated 1,454 applicable pad/seed/via/hole/restrictive-keepout objects. Pad copper uses native effective bounding boxes, exact for the axis-aligned rectangular pads that dominate this corridor and conservative for other shapes; marginal bbox results therefore cannot self-accept the geometry.

## Proposed typed geometry

The source record is `north_adc_typed_corridor_proposal/v1`, proposal `north-adc-fixed-pose-hypothesis-1`. Each net has a typed endpoint graph with four native terminal identities: isolation source, ADC pad, common-mode capacitor pad, and bias resistor pad. Each graph declares `main`, `common_mode`, and `bias` paths, yielding exactly 8/8 nets, 32/32 unique native pads, 24/24 declared paths, and 4/4 P/N groups. The complete graph, edge coordinates, per-path identities, centerline lengths, transition polygons, and all measurement rows are in `north_adc_corridor_proposal.json` in the evidence archive.

The normal corridor is eight net-specific B.Cu horizontal capsules. F.Cu source escapes feed one source via per net; one destination via per net returns to the retained source-owned F.Cu ADC launch seed. Every transition window is a 0.80 mm square centered on its via. The eight existing ADC seed segments from y=67.05 to y=66.05 remain exactly 0.20 mm wide; no existing 0.18 mm fine-pitch rule or other source seed was widened or replaced.

| Net | B.Cu lane y (mm) | Source via (mm) | Destination via (mm) | Trunk length (mm) |
|---|---:|---:|---:|---:|
| ADC1P | 55.50 | (38.90, 55.50) | (97.00, 55.50) | 58.10 |
| ADC1N | 56.20 | (42.10, 56.20) | (97.40, 56.20) | 55.30 |
| ADC2P | 56.90 | (70.90, 56.90) | (96.20, 56.90) | 25.30 |
| ADC2N | 57.60 | (74.10, 57.60) | (96.60, 57.60) | 22.50 |
| ADC3P | 58.30 | (102.90, 58.30) | (94.60, 58.30) | 8.30 |
| ADC3N | 59.00 | (106.10, 59.00) | (95.00, 59.00) | 11.10 |
| ADC4P | 59.70 | (134.90, 59.70) | (93.80, 59.70) | 41.10 |
| ADC4N | 60.40 | (138.10, 60.40) | (94.20, 60.40) | 43.90 |

## Measured obstacle and simultaneity results

The proposal was checked simultaneously, net by net and layer by layer, against every applicable foreign native pad, all 235 r0 seed segments, all 29 r0 vias, every drilled hole, all 77 rule areas with prohibition semantics, and every foreign-net proposed track/via. Same-net terminal pads and retained same-net seeds were treated as intended contacts, not foreign obstacles.

- All eight B.Cu trunk subjects pass 2,036 comparisons. Their minimum measured clearance margin is 0.300 mm beyond the required capsule distance.
- All sixteen proposed 0.50/0.20 mm vias pass 23,296 comparisons. Their minimum measured margin is 0.106226 mm.
- All sixteen net-specific 0.80 mm transition-window polygons pass 23,184 occupancy comparisons. Their minimum measured margin is 0.125 mm.
- The full simultaneous set produces 112,957 passing and 87 failing comparisons out of 113,044. The worst margin is -0.450 mm. Failures are confined to F.Cu bias, main-launch, and common-mode branch subjects; no B.Cu trunk, proposed via, transition window, or source escape is a failing subject.

The principal fixed-pose terminal deficits are concrete. ADC1P/N and ADC2P launches intersect the existing north filter capacitor/seed field; ADC3P/N and ADC4P/N launches conflict with common-mode pads and a local GND via/seed; several common-mode branches cross foreign ADC branches or fine-pitch seeds. The four N bias straight-line branches also miss the adjacent `U_ISO*.5` pad by 0.053094 mm under the 0.30 mm centerline-to-pad-bbox requirement. The archive retains every failing subject/obstacle identity and distance.

The declared path-length comparison also fails this hypothesis:

| Group | Path kind | P length (mm) | N length (mm) | Spread (mm) | 1.0 mm gate |
|---|---|---:|---:|---:|---|
| ANALOG_CH1_ADC | main | 74.9216 | 71.6216 | 3.3000 | FAIL |
| ANALOG_CH1_ADC | common_mode | 79.341599 | 74.3416 | 4.999999 | FAIL |
| ANALOG_CH1_ADC | bias | 1.298692 | 1.402355 | 0.103663 | PASS |
| ANALOG_CH2_ADC | main | 42.1216 | 38.8216 | 3.3000 | FAIL |
| ANALOG_CH2_ADC | common_mode | 43.5516 | 41.1016 | 2.4500 | FAIL |
| ANALOG_CH2_ADC | bias | 1.298692 | 1.402355 | 0.103663 | PASS |
| ANALOG_CH3_ADC | main | 25.1216 | 27.4216 | 2.3000 | FAIL |
| ANALOG_CH3_ADC | common_mode | 24.9516 | 26.4016 | 1.4500 | FAIL |
| ANALOG_CH3_ADC | bias | 1.298692 | 1.402355 | 0.103663 | PASS |
| ANALOG_CH4_ADC | main | 57.9216 | 60.2216 | 2.3000 | FAIL |
| ANALOG_CH4_ADC | common_mode | 54.8016 | 56.3516 | 1.5500 | FAIL |
| ANALOG_CH4_ADC | bias | 1.298692 | 1.402355 | 0.103663 | PASS |

These are proposal centerline lengths including two identical 1.4858 mm F.Cu-to-B.Cu transitions on each main/common-mode path. No meander was invented after measurement; doing so would turn this bounded source hypothesis into iterative route tuning.

## Reference-plane boundary

The exact native and r0 sources declare GND zones on F.Cu, In1.Cu, In2.Cu, and B.Cu, but this proposed copper was never emitted and the resulting zones were never refilled. Track-free or unfilled geometry cannot prove later reference continuity. Unbroken In1.Cu/In2.Cu GND around all sixteen transitions remains OWED on the exact emitted, filled board, followed by independent inspection. No plane-continuity credit is claimed here.

## Narrow source and contract delta

The current `route.ownership.corridors` checker accepts only `claim_order`, `why`, and `allow_flexible_first`; it has no geometry or net-specific reservation semantics. The minimum reusable extension is a typed `route.ownership.typed_corridors[]` record containing exact nets, layers, rule dimensions, net-specific lane centerlines, net-specific transition polygons, endpoint graphs, the 8/32/24/4 required denominators, group-spread limit, and claim order. Unknown keys, duplicate nets/paths, absent endpoints, zero denominators, wrong layers/rules, and foreign-object overlap must fail closed.

The board generator must parse the typed declaration and emit review-visible reservation geometry without converting the proposal into candidate copper. `floorplan.yaml` should receive only the accepted keep-clear geometry needed to protect those typed lanes/windows from later flexible owners; global keepouts cannot stand in for net ownership. Existing poses and pin maps remain unchanged. The route-source contract and a narrow source-geometry test must independently reload the exact native board, resolve all endpoints, enforce every denominator, and measure the emitted reservation. `route_ownership_preflight.py` should consume the typed record and report source declaration/emission status separately from routed-board acceptance. The evidence archive's `source_delta_plan.json` names these exact integration points and hostile checks.

This hypothesis should not be copied into source as accepted geometry because its F.Cu terminal capsules and path-spread checks fail. A later upstream placement packet may compare a larger placement change only under new authority; simple bank permutation still only moves the connector-to-ADC inversions upstream and is not established as an improvement.

## Gates that must renew

Any adopted corridor-source change makes downstream placement artifacts stale. Renew source tests, route-source contract, native qualification, exact placement/layout review, exact render review, locator/route-base integrity, and canonical pre-route review binding. The exact regenerated board must then be independently checked for all 8 nets, 32 pads, 24 paths, four P/N groups, via legality, <=1.0 mm spread, connectivity, DRC, and filled In1.Cu/In2.Cu reference continuity. Only a fresh independent acceptance of that exact emitted board can close LAYOUT-001 and admit ordinary routing under a new stage authorization.

## Limits

No live source, board, or route artifact was changed. No candidate board was saved. No routing process, KRT process, custom search, fourth diagnostic, or promotion action was run. The vector figure is an analytical overlay generated from native obstacle positions and was visually inspected; it shows the clear parallel B.Cu trunks and the congested F.Cu terminal fanout. Manufacturing, first-article, thermal, routed SI, final DRC/connectivity, and release readiness remain outside this proposal and unproved.
