subject: crow-audio-carrier-v1 fixed north pod-to-ADC channel permutation authority reassessment
date: 2026-09-11
reviewer: Codex judgment agent /root/carrier_channel_authority
context-given: FRESH; immutable 375-file packet plus separately hash-verified five-file system supplement
source_commit: b436d612c8d2d325204ebd253f4c885bd66943ee
review_stage: pre-route
review_kind: electrical-architecture source proposal
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 9aa1c2c821a31129176a8b519b9a211d78dfc011adb997a64470c03d0726891f
design_rules_sha256: 0637fdb2d3f5ab247c301147ad6ed875343674c225e5036a2bb1935bd025cec3
r0_board_sha256: 8b7e13e1816618b5908c76f19562c7530cb700b1d03d9c6dedaec88d9c9bd609
task_identity: task_id=channel-authority; run_id=channel-authority; input_handoff_id=channel-authority; stage_id=KICAD-PLACEMENT
envelope_subject_raw_sha256: 5c0d57cc45cce383864e5cf515f81c43965035792047805493e42db8741fee7d
envelope_subject_semantic_sha256: 1ba093c7aaab0d74e64e5482a177d7772ff21c824eba2f00419d2a0f1d00c3e0
reviewer_provenance: independent judgment of architectural source proposal; no implementation or board acceptance
authority_verdict: SUFFICIENT_UNDER_A2_P_DELEGATION
proposal_id: north-fixed-channel-permutation-v1
proposal_status: SOUND_FOR_SOURCE_IMPLEMENTATION
layout_finding: LAYOUT-001
layout_finding_state: OPEN
layout_finding_class: missing_simultaneous_corridor_evidence
diagnostic_request: simultaneous_source_corridor_reservation
diagnostic_nets: ADC1P,ADC1N,ADC2P,ADC2N,ADC3P,ADC3N,ADC4P,ADC4N
diagnostic_pad_denominator: 32
diagnostic_path_denominator: 24
diagnostic_pn_groups: ANALOG_CH1_ADC,ANALOG_CH2_ADC,ANALOG_CH3_ADC,ANALOG_CH4_ADC
diagnostic_max_spread_mm: 1.0
diagnostic_layers: F.Cu,B.Cu
diagnostic_track_width_mm: 0.20
diagnostic_clearance_mm: 0.20
diagnostic_via_mm: 0.50/0.20
diagnostic_reference_plane_proof: OWED
diagnostic_promotion: FORBIDDEN
north_current_channel_inversions: 6
north_current_cross_channel_conductor_inversions: 24
north_proposed_channel_inversions: 0
north_proposed_cross_channel_conductor_inversions: 0
south_current_channel_inversions: 0
south_proposed_channel_inversions: 0
completed_at_utc: 2026-09-12T02:10:00Z

# Electrical-authority reassessment — fixed north channel permutation

## Verdict

**SOUND as an electrical source proposal under existing A2/P authority.** Adopt the fixed mapping `pod1→ADC4/slot3`, `pod2→ADC3/slot2`, `pod3→ADC2/slot1`, `pod4→ADC1/slot0`, with pods 5–8 unchanged. No user escalation is required. This verdict authorizes a source/contract delta and regeneration; it does not accept the current or future board, close `LAYOUT-001`, admit routing, prove planes, or authorize ordering.

G1 requires every active-balanced spoke to map *deterministically* to the eight ADC channels and TDM slots on exact reviewed artifacts. It does not require pod `n` to equal ADC channel `n` or slot `n-1`. A2 is explicitly an agent assumption made under P electrical-architecture delegation: one hardware-controlled CS5308P, one vendor receive network per channel, hardware reset, and one MCHStreamer-mastered TDM8 lane. The current identity mapping is therefore an agent-owned implementation choice, not a user-locked product identity.

The five-file system supplement reinforces that reading. The parent architecture locks eight synchronized channel roles and requires exact bit selection, data edge, channel order, simultaneous-impulse slot proof, and a frozen channel-order contract. It expressly leaves exact channel order as a bench obligation. The user’s identity requirement is an anonymous stationary-source signature within one 120-second file. It needs a stable, documented pod-coordinate-to-stream mapping; it does not require ordinal equality. The project has no current release, and this packet contains no immutable release whose channel identity would be changed. The mapping must be frozen before first article and recorded in every capture’s channel-order contract identifier.

## Exact current and proposed mapping

CS5308P DS1314F1, local SHA-256 `6ca42cc09ac47ebdacacaee435f05e3f9c34b83d5692e52a2d8a26533e810e57`, section 4.7/Figure 4-15 states that in eight-slot TDM, ADC channels 1–8 occupy slots 0–7 on `ASP_DOUT1`. The packet’s source binds channel P/N terminals as shown below. The source uses `Jx.3=AUDIO+`, `Jx.4=AUDIO−`; `U_AFEx.3/5` are P/N inputs and `1/7` P/N outputs; `U_ISOx.1→2` is P and `5→6` is N. Power pins `Jx.1=+12V_PODx` and `Jx.2=GND` are untouched.

| Logical pod | Current ADC P/N pins | Current slot | Proposed ADC P/N pins | Proposed slot | VMID domain |
|---:|---|---:|---|---:|---|
| 1 | U_ADC.40 / .39 (ADC1 P/N) | 0 | U_ADC.48 / .47 (ADC4 P/N) | 3 | VMID1_EXT |
| 2 | U_ADC.42 / .41 (ADC2 P/N) | 1 | U_ADC.46 / .45 (ADC3 P/N) | 2 | VMID1_EXT |
| 3 | U_ADC.46 / .45 (ADC3 P/N) | 2 | U_ADC.42 / .41 (ADC2 P/N) | 1 | VMID1_EXT |
| 4 | U_ADC.48 / .47 (ADC4 P/N) | 3 | U_ADC.40 / .39 (ADC1 P/N) | 0 | VMID1_EXT |
| 5 | U_ADC.14 / .13 (ADC5 P/N) | 4 | unchanged | 4 | VMID2_EXT |
| 6 | U_ADC.16 / .15 (ADC6 P/N) | 5 | unchanged | 5 | VMID2_EXT |
| 7 | U_ADC.20 / .19 (ADC7 P/N) | 6 | unchanged | 6 | VMID2_EXT |
| 8 | U_ADC.22 / .21 (ADC8 P/N) | 7 | unchanged | 7 | VMID2_EXT |

For every row the complete signal chain remains `Jx.3/4 → C_AxP/N → R_INxP/N → U_AFEx.3/5 → U_AFEx.1/7 → R_OUTxP/N and same-leg filter/feedback → U_ISOx.1/5 → U_ISOx.2/6 → selected U_ADC P/N pins`. Thus all external connector identities, +12 V and ground, audio polarity, coupling/bias/filter topology, AFE pose, isolation pose, and enable behavior remain unchanged. P remains P and N remains N at every terminal.

The exact source implementation should retain `ADCxP/N` as the logical pod-x post-isolation nets and change the `U_ADC` terminal memberships according to the table. This makes the mapping explicit rather than hiding it in arbitrary net renames. `R_ADC_PDxP/N` remains with `U_ISOx` on logical net x. The identical 1 nF `C_ADC_CM` parts remain physically at the selected ADC terminals by exchanging only their logical reference-to-position assignments: logical `C_ADC_CM1P/N` takes the existing physical channel-4 capacitor positions, logical 2 takes existing channel-3 positions, logical 3 takes existing channel-2 positions, and logical 4 takes existing channel-1 positions. Pods 5–8 are unchanged. No fitted capacitor pose, value, ground return, or component population changes.

All four north paths remain inside `VMID1_EXT`; the south paths remain inside `VMID2_EXT`. The permutation therefore does not cross a reference domain. Every receive cell is nominally identical, so there is no topology or component-value mismatch introduced. ADC per-channel gain/offset/noise and realized path mismatch remain first-article and routed-board obligations, as before.

## Whole-path ordering proof

The north connector/AFE/ISO cells occur left-to-right as logical `[1,2,3,4]`. Current north ADC terminals occur left-to-right as physical `[4,3,2,1]`. That reversal has all `C(4,2)=6` channel-pair inversions. Each channel pair contains two conductors against two conductors, so it contributes four cross-channel conductor inversions: `6×4=24`. The proposed association labels those same left-to-right physical terminals with logical `[1,2,3,4]`, yielding zero channel-pair and zero cross-channel conductor inversions. Connector-to-AFE and AFE-to-ISO were already zero and stay zero.

The south cells and south ADC terminals both occur left-to-right as `[5,6,7,8]`; they have zero channel and zero cross-channel conductor inversions before and after. This is the control proving that the proposal is a north-only association change rather than an ADC pose or global channel-order change.

This removes the causal endpoint-order reversal that made the previous fixed-pose north corridor carry 6/24 inversions. It becomes inapplicable only after source implementation, regeneration, and independent exact review confirm the table. It does not prove legal capsules, path spread, via placement, reference continuity, or whole-board routability.

## Firmware and product identity

No project-authored firmware is required. Hardware-mode CS5308P assigns its physical channels to fixed slots; the analog permutation chooses which pod reaches each physical channel. The existing MCHStreamer image, clocking, configuration straps, ADC device, DOUT path, and eight-slot mode stay unchanged. Host-side runtime reordering is not required for electrical operation. The Pi/application contract must instead record the immutable lookup `stream slot 0→pod4`, `1→pod3`, `2→pod2`, `3→pod1`, `4→pod5`, `5→pod6`, `6→pod7`, `7→pod8`, bind it to surveyed pod coordinates, and verify it with the already-required eight-channel impulse map. If a later application specifically requires array index order to equal stream slot order, that would be new product authority and would require reopening this decision; no such requirement exists in the supplied authority.

## Required source and consumer migration

The implementation must be one coherent source change, preferably recorded by a new ADR that states the logical-pod/physical-ADC/slot table, the stable meaning of `ADCxP/N`, the common-mode reference reassignment, preserved polarity/reference domains, and the frozen capture-order identifier.

- Electrical source: update `03_tscircuit/src/crow_audio_carrier_v1.tsx` U_ADC pin memberships and any schematic labels/captions in `schematic_presentation.tsx`; keep connector, AFE, ISO, clock/configuration, and south connectivity exact. Update the manifest only if its expected semantics include the mapping.
- Constraints: update all 24 analog path declarations affected by the four post-isolation pairs in `03_src/rules/nets.yaml`; update the sixteen ADC launch net/pin bindings and analog-wave pair expectations in `03_src/route.yaml`; exchange the four north `C_ADC_CM` logical references across their existing physical positions in `03_src/floorplan.yaml`; bind the exact impulse/slot table in `rules/first_article.yaml`.
- Checkers/tests: parameterize the logical-to-physical map in `check_analog_filter_topology.py` and `check_analog_paths.py`; update their hostile tests plus `test_adc_analog_fanout.py`, `test_route_source_contract.py`, `test_local_placement_source.py`, and any exact ground/pad census fixtures. A single mapping constant/typed contract should feed producers, while independent tests rederive the expected pin table so checker and checked do not share a method.
- Documentation/system consumers: update G1 evidence and add the ADR; update the parent architecture and Raspberry Pi integration channel-order contract so slot numbers resolve to pod identities and surveyed coordinates. Retain the pod-v3 straight-through four-pin spoke contract unchanged.
- Regenerated artifacts: `circuit.json`, schematic PDF, native schematic/netlist/PCB, pre-route DRC, r0, locator render, and all topology/pin/schematic-render/layout/render reviews become stale and must be regenerated or independently renewed against exact hashes.

The evidence inventory lists 34 concrete consumers by category and retains line-level token hits. That list is deliberately conservative: generated artifacts are consumers to renew, not hand-edit targets.

## Gates and unresolved physical work

After implementation, rerun source topology, analog-path, fanout, route-contract, placement, and hostile mapping tests; regenerate the exact native artifacts; then obtain fresh independent schematic topology, pin, schematic-render, placement/layout, render, and canonical pre-route acceptance. The exact review must prove all eight post-isolation nets, 32 terminal pads, 24 declared north ADC paths, four P/N groups, the 1.0 mm path-spread ceiling, legal vias, connectivity, DRC/parity, and filled In1.Cu/In2.Cu GND reference continuity. It must also prove the south chain is byte/semantic-equivalent except for regenerated identities.

`LAYOUT-001` remains open. The prior 3/3 diagnostic reservation remains spent; this electrical source correction is not a fourth route attempt and creates no permission to bypass the canonical gates. The previous fixed-pose source-corridor proposal’s particular reversed-order burden becomes obsolete only on the new exact subject. Its negative F.Cu collision and mismatch results do not automatically transfer to the permuted subject, and the permutation does not establish that the new routes fit.

No live source, board, candidate, part, device pose, configuration mode, firmware, or release was changed in this review. One local manufacturer PDF was extracted only through bounded `pipeline_runtime.run_stage`; the existing locator render was actually viewed and visually confirms the north/south cell order and central ADC placement, while proving no copper. All 375 envelope inputs passed exact size/SHA verification; all five supplemental files were separately verified before and after copying into evidence. The semantic design-rules digest was recomputed with the supplied owning API. Manufacturing, orderability, routed SI, planes, thermal behavior, analog quality, and first-article operation remain unproved.
