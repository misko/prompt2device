from pathlib import Path
import hashlib, importlib.util, json, re, shutil, sys
sys.dont_write_bytecode=True
ROOT=Path('/tmp/carrier-channel-authority-ax__1y39')
SCR=ROOT/'06_build/task_runs/channel-authority/scratch'
ENV=json.loads((ROOT/'06_build/task_runs/channel-authority/envelope.json').read_text())
def stat_hash(p):
    b=p.read_bytes(); return {'size':len(b),'sha256':hashlib.sha256(b).hexdigest()}
rows=[]
for item in ENV['input_packet']:
    p=ROOT/item['path']; got=stat_hash(p)
    rows.append({'path':item['path'],'expected_size':item['size'],'expected_sha256':item['sha256'],**got,
                 'status':'PASS' if got['size']==item['size'] and got['sha256']==item['sha256'] else 'FAIL'})
assert all(x['status']=='PASS' for x in rows)
(SCR/'input_verification_before.json').write_text(json.dumps({'count':len(rows),'pass':len(rows),'fail':0,'rows':rows},indent=2)+'\n')

SUP=Path('/tmp/carrier-cat-renewal-20260912/channel-system-supplement')
smanifest=json.loads((SUP/'manifest.json').read_text()); srows=[]
for item in smanifest:
    src=SUP/item['path']; got=stat_hash(src); assert got=={k:item[k] for k in ('size','sha256')}
    dst=SCR/'supplement'/item['path']; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
    copied=stat_hash(dst); assert copied==got
    srows.append({'path':item['path'],**got,'copy_path':dst.relative_to(SCR).as_posix(),'copy_verified':True})
(SCR/'supplement_verification.json').write_text(json.dumps({'scope':'five-file supplement outside original envelope','count':len(srows),'rows':srows},indent=2)+'\n')

spec=importlib.util.spec_from_file_location('pr',ROOT/'authority/pre_route_review_check.py'); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
digest=mod.design_rules_digest(ROOT/'project'); assert digest=='0637fdb2d3f5ab247c301147ad6ed875343674c225e5036a2bb1935bd025cec3'
(SCR/'design_rules_digest.json').write_text(json.dumps({'api':'authority/pre_route_review_check.py:design_rules_digest','sha256':digest},indent=2)+'\n')

adc_p={'1':40,'2':42,'3':46,'4':48,'5':14,'6':16,'7':20,'8':22}; adc_n={'1':39,'2':41,'3':45,'4':47,'5':13,'6':15,'7':19,'8':21}
proposed={1:4,2:3,3:2,4:1,5:5,6:6,7:7,8:8}
table=[]
for pod in range(1,9):
    phys=proposed[pod]
    table.append({'logical_pod':pod,'connector':f'J{pod}','connector_pins':{'power':1,'ground':2,'audio_p':3,'audio_n':4},
      'afe':f'U_AFE{pod}','afe_input_p':3,'afe_input_n':5,'afe_output_p':1,'afe_output_n':7,
      'isolation':f'U_ISO{pod}','iso_source_p':1,'iso_drain_p':2,'iso_source_n':5,'iso_drain_n':6,
      'current_adc_channel':pod,'current_adc_p_pin':adc_p[str(pod)],'current_adc_n_pin':adc_n[str(pod)],'current_tdm_slot':pod-1,
      'proposed_adc_channel':phys,'proposed_adc_p_pin':adc_p[str(phys)],'proposed_adc_n_pin':adc_n[str(phys)],'proposed_tdm_slot':phys-1,
      'vmid_domain':'VMID1_EXT' if pod<=4 else 'VMID2_EXT','polarity_preserved':True})
def inv(order): return sum(order[i]>order[j] for i in range(len(order)) for j in range(i+1,len(order)))
counts={'north':{'current_channel_inversions':inv([4,3,2,1]),'current_conductor_inversions':4*inv([4,3,2,1]),
                 'proposed_channel_inversions':inv([1,2,3,4]),'proposed_conductor_inversions':4*inv([1,2,3,4])},
        'south_control':{'current_channel_inversions':inv([5,6,7,8]),'current_conductor_inversions':0,
                         'proposed_channel_inversions':inv([5,6,7,8]),'proposed_conductor_inversions':0}}
(SCR/'before_after_mapping.json').write_text(json.dumps({'mapping':table,'inversion_counts':counts,
 'manufacturer_authority':{'file':'project/02_parts/CS5308P-DN/CS5308P_DS1314F1.pdf','sha256':'6ca42cc09ac47ebdacacaee435f05e3f9c34b83d5692e52a2d8a26533e810e57','text_lines':[2296,2299,2314,2316,2330,2334]},
 'common_mode_reference_reassignment':{'logical1':'existing physical C_ADC_CM4P/N positions','logical2':'existing physical C_ADC_CM3P/N positions','logical3':'existing physical C_ADC_CM2P/N positions','logical4':'existing physical C_ADC_CM1P/N positions','logical5_to_8':'unchanged'},
 'net_semantics':'Retain ADCnP/N as the logical pod-n post-isolation net; change U_ADC terminal memberships according to the table and exchange only C_ADC_CM logical reference-to-position assignments for 1..4. R_ADC_PD n stays with U_ISO n.'},indent=2)+'\n')

consumers={
'source':['project/03_tscircuit/src/crow_audio_carrier_v1.tsx','project/03_tscircuit/src/schematic_presentation.tsx','project/03_tscircuit/manifest.yaml'],
'constraints':['project/03_src/rules/nets.yaml','project/03_src/route.yaml','project/03_src/floorplan.yaml','project/03_src/rules/first_article.yaml'],
'checkers_tests':['project/03_src/check_analog_filter_topology.py','project/03_src/check_analog_paths.py','project/03_src/tests/test_analog_filter_topology.py','project/03_src/tests/test_analog_paths.py','project/03_src/tests/test_adc_analog_fanout.py','project/03_src/tests/test_route_source_contract.py','project/03_src/tests/test_local_placement_source.py','project/03_src/tests/test_ground_connections.py'],
'docs_contracts':['project/01_docs/BRIEF.md','project/01_docs/decisions/0001-single-cs5308p-tdm8.md','project/01_docs/decisions/0018-adc-analog-launches.md','project/01_docs/decisions/0019-analog-path-matching.md','supplement/projects/crow-roof-array-v1/01_docs/ARCHITECTURE.md','supplement/projects/crow-roof-array-v1/01_docs/reports/2026-09-01-raspberry-pi-5-roof-appliance-integration.md'],
'regenerated_stale':['project/03_tscircuit/build/circuit.json','project/03_tscircuit/build/schematic.pdf','project/04_kicad/crow_audio_carrier_v1.kicad_sch','project/04_kicad/crow_audio_carrier_v1.kicad_pcb','project/06_build/netlists/crow_audio_carrier_v1.net','project/06_build/drc/pre_route.json','project/06_build/route/r0.kicad_pcb','project/06_build/pre_route/locator_native_top.png','project/08_reviews/pre-route_topology.md','project/08_reviews/pre-route_pin.md','project/08_reviews/pre-route_schematic_render.md','project/08_reviews/pre-route_layout.md','project/08_reviews/pre-route_render.md']}
(SCR/'source_consumer_inventory.json').write_text(json.dumps(consumers,indent=2)+'\n')

facts=[]
for rel in sum(consumers.values(),[]):
    p=(ROOT/rel) if not rel.startswith('supplement/') else (SCR/rel)
    if p.is_file() and p.suffix not in ('.pdf','.png'):
        text=p.read_text(errors='replace')
        hits=[{'line':i,'text':line.strip()} for i,line in enumerate(text.splitlines(),1) if re.search(r'(ADC[1-8][PN]|U_ADC|U_ISO|C_ADC_CM|R_ADC_PD|TDM|slot|channel order|impulse map)',line,re.I)]
        facts.append({'path':rel,**stat_hash(p),'hit_count':len(hits),'hits':hits[:80]})
(SCR/'source_consumer_hits.json').write_text(json.dumps(facts,indent=2)+'\n')
print(json.dumps({'inputs':len(rows),'supplement':len(srows),'design_rules_sha256':digest,'mapping_rows':len(table),'consumer_files':sum(len(v) for v in consumers.values())}))
