from pathlib import Path
import json, os, sys
sys.dont_write_bytecode = True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
sys.path.insert(0,str(R))
from pipeline_runtime import run_stage
s=Path(__file__).resolve().parent
pdf=Path('/tmp/carrier-channel-authority-ax__1y39/project/02_parts/CS5308P-DN/CS5308P_DS1314F1.pdf')
out=s/'CS5308P_DS1314F1.txt'
log=s/'pdf_extract.raw.log'
spec={'id':'PDF-AUTHORITY-EXTRACT','work_class':'review_wait','timeout_s':30,'produces':[]}
env=dict(os.environ); env['PYTHONDONTWRITEBYTECODE']='1'
r=run_stage(spec,['/usr/bin/pdftotext','-layout',str(pdf),str(out)],log_path=log,cwd=s,env=env,console=None)
(s/'pdf_extract.runtime.json').write_text(json.dumps(r.to_mapping(),indent=2,sort_keys=True)+'\n')
print(json.dumps(r.to_mapping(),sort_keys=True))
