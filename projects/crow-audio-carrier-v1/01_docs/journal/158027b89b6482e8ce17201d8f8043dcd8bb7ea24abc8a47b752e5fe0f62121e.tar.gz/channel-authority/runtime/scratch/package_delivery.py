from pathlib import Path
import hashlib, json, tarfile, sys
from datetime import datetime, timezone
sys.dont_write_bytecode=True
ROOT=Path('/tmp/carrier-channel-authority-ax__1y39'); RUN=ROOT/'06_build/task_runs/channel-authority'; SCR=RUN/'scratch'; OUT=RUN/'outputs'
ENV=json.loads((RUN/'envelope.json').read_text())
def hs(p):
 b=p.read_bytes(); return {'size':len(b),'sha256':hashlib.sha256(b).hexdigest()}
rows=[]
for item in ENV['input_packet']:
 p=ROOT/item['path']; got=hs(p); status='PASS' if got=={'size':item['size'],'sha256':item['sha256']} else 'FAIL'
 rows.append({'path':item['path'],'expected_size':item['size'],'expected_sha256':item['sha256'],**got,'status':status})
assert all(r['status']=='PASS' for r in rows)
(SCR/'input_verification_after.json').write_text(json.dumps({'count':len(rows),'pass':len(rows),'fail':0,'rows':rows},indent=2)+'\n')
pdf_rt=json.loads((SCR/'pdf_extract.runtime.json').read_text())
evidence={
 'schema':1,'subject':ENV['subject'],'review_scope':'independent electrical authority reassessment of fixed north pod-to-ADC channel permutation; no board acceptance',
 'engineering_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','completed_at':datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),
 'input_verification':{'original_packet_count':len(rows),'before':'scratch/input_verification_before.json','after':'scratch/input_verification_after.json','status':'PASS'},
 'supplement_verification':json.loads((SCR/'supplement_verification.json').read_text()),
 'design_rules_digest':json.loads((SCR/'design_rules_digest.json').read_text()),
 'commands':[
  {'purpose':'read frozen task and authority','argv':['sed/rg','packet text sources'],'cwd':'/home/mouse9911/gits/circuits','returncode':0,'class':'read-only shell inspection'},
  {'purpose':'extract local CS5308P manufacturer PDF','argv':['/usr/bin/pdftotext','-layout',str(ROOT/'project/02_parts/CS5308P-DN/CS5308P_DS1314F1.pdf'),str(SCR/'CS5308P_DS1314F1.txt')],'cwd':str(SCR),'returncode':pdf_rt['returncode'],'started_at':pdf_rt['started_at'],'finished_at':pdf_rt['finished_at'],'elapsed_s':pdf_rt['elapsed_s'],'raw_stdout_stderr':'scratch/pdf_extract.raw.log','runtime_receipt':'scratch/pdf_extract.runtime.json','bounded_by':'pipeline_runtime.run_stage'},
  {'purpose':'verify inputs, copy/verify supplement, compute semantic rule digest, derive mapping/inversions, inventory consumers','argv':['/usr/bin/python3',str(SCR/'analyze_authority.py')],'cwd':'/home/mouse9911/gits/circuits','returncode':0},
  {'purpose':'package exact delivery','argv':['/usr/bin/python3',str(SCR/'package_delivery.py')],'cwd':'/home/mouse9911/gits/circuits','returncode':0}
 ],
 'actual_coverage':{
  'authority':{'G1':'read exact wording','A2':'read exact wording and escalation condition','system_supplement_files':5,'conclusion':'identity mapping is delegated implementation; deterministic documented permutation is authorized'},
  'mapping':{'rows':8,'north_channels':4,'north_signal_nets':8,'north_terminal_pads':32,'north_declared_paths':24,'north_pn_groups':4,'current_channel_inversions':6,'current_cross_channel_conductor_inversions':24,'proposed_channel_inversions':0,'proposed_cross_channel_conductor_inversions':0,'south_control_channels':4,'south_inversions_before_after':[0,0]},
  'chain':'J1..J8 pins 3/4 through C_A, R_IN, U_AFE, R_OUT/filter, U_ISO to exact U_ADC P/N pins; pins 1/2 power/ground unchanged',
  'source_consumers':{'inventory':'scratch/source_consumer_inventory.json','line_hits':'scratch/source_consumer_hits.json','files':34},
  'manufacturer':'CS5308P DS1314F1 section 4.7/Figure 4-15: physical channels 1-8 occupy slots 0-7 in eight-slot TDM on DOUT1',
  'firmware':'no custom firmware; physical wiring selects fixed hardware channel/slot; MCH image and hardware mode unchanged',
  'physical_limit':'no routing, candidate, source write, plane proof, DRC, or board acceptance'
 },
 'visual_inspection':{'artifact':'project/06_build/pre_route/locator_native_top.png','sha256':hs(ROOT/'project/06_build/pre_route/locator_native_top.png')['sha256'],'method':'actual view_image inspection at original detail (application displayed resized copy)','observed':'north J1-J4/AFE1-4/ISO1-4 left-to-right and south J5-J8 counterpart around central U_ADC; no routed-copper proof','scope_limit':'placement/order corroboration only'},
 'artifacts':{'mapping':'scratch/before_after_mapping.json','consumer_inventory':'scratch/source_consumer_inventory.json','consumer_hits':'scratch/source_consumer_hits.json','pdf_text':'scratch/CS5308P_DS1314F1.txt'},
 'preserved_finding':{'id':'LAYOUT-001','state':'OPEN','attempt_spend':'3/3 remains spent','next':'implement source delta, regenerate, independent exact schematic/pin/render/layout review; no fourth diagnostic'},
 'unresolved_engineering':['legal simultaneous routes on regenerated subject','realized P/N path spread','filled reference-plane continuity','DRC/parity/connectivity','bench impulse slot map and stream order','first-article analog/thermal/system behavior']
}
(OUT/'evidence.json').write_text(json.dumps(evidence,indent=2,sort_keys=True)+'\n')
(OUT/'result.json').write_text(json.dumps({'subject':ENV['subject'],'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]},separators=(',',':'))+'\n')

# Canonical header is a duplicate-free exact-key set for this review lens.
header=[]
for line in (OUT/'report.md').read_text().splitlines():
 if not line.strip(): break
 assert ':' in line, line
 header.append(line.split(':',1)[0])
required={'subject','date','reviewer','context-given','source_commit','review_stage','review_kind','design_verdict','order_verdict','board_sha256','design_rules_sha256','r0_board_sha256','task_identity','envelope_subject_raw_sha256','envelope_subject_semantic_sha256','reviewer_provenance','authority_verdict','proposal_id','proposal_status','layout_finding','layout_finding_state','layout_finding_class','diagnostic_request','diagnostic_nets','diagnostic_pad_denominator','diagnostic_path_denominator','diagnostic_pn_groups','diagnostic_max_spread_mm','diagnostic_layers','diagnostic_track_width_mm','diagnostic_clearance_mm','diagnostic_via_mm','diagnostic_reference_plane_proof','diagnostic_promotion','north_current_channel_inversions','north_current_cross_channel_conductor_inversions','north_proposed_channel_inversions','north_proposed_cross_channel_conductor_inversions','south_current_channel_inversions','south_proposed_channel_inversions','completed_at_utc'}
validation={'status':'PASS','duplicate_keys':sorted({k for k in header if header.count(k)>1}),'missing_keys':sorted(required-set(header)),'extra_keys':sorted(set(header)-required),'required_count':len(required),'actual_count':len(header)}
assert not validation['duplicate_keys'] and not validation['missing_keys'] and not validation['extra_keys'], validation
(SCR/'report_field_validation.json').write_text(json.dumps(validation,indent=2,sort_keys=True)+'\n')

# Archive every supporting scratch member with deterministic names and metadata.
members=[p for p in sorted(SCR.rglob('*')) if p.is_file()]
archive=OUT/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in members: tf.add(p,arcname='scratch/'+p.relative_to(SCR).as_posix(),recursive=False)
mrows=[{'path':'scratch/'+p.relative_to(SCR).as_posix(),**hs(p)} for p in members]
(OUT/'evidence-manifest.json').write_text(json.dumps({'schema':1,'archive':{'path':'evidence.tar.gz',**hs(archive)},'member_count':len(mrows),'members':mrows},indent=2,sort_keys=True)+'\n')
print(json.dumps({'inputs':len(rows),'archive_members':len(mrows),'archive':hs(archive)}))
