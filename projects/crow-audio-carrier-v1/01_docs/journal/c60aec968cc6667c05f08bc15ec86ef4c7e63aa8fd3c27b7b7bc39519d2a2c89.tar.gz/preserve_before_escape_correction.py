from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,tarfile,io,shutil
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest()
old=json.loads((P/'06_build/checkpoints/prelayout-inputs.json').read_text());files={}
for key in old['explicit']:
 f=R/key.removeprefix('repo:');b=f.read_bytes();assert sha(b)==old['files'][key]['sha256'],key;files[f.relative_to(P).as_posix()]=f
names=['06_build/checkpoints/prelayout-inputs.json','06_build/checkpoints/prelayout.json','06_build/checkpoints/schematic.json','06_build/sourcing/prelayout_request.json','06_build/sourcing/prelayout_response.csv','06_build/sourcing/prelayout_receipt.json']
for n in names:
 f=P/n;assert not f.is_symlink(),n
 if f.exists():files[n]=f
for folder in ['04_kicad']:
 for f in (P/folder).iterdir():
  if f.is_file():files[f.relative_to(P).as_posix()]=f
for n in ['08_reviews/pre-route_topology.md','08_reviews/pre-route_schematic_render.md','08_reviews/pre-route_pin.md','08_reviews/pre-route_render.md','06_build/route/r0.kicad_pcb','06_build/route/r0.kicad_pro','06_build/route/r0.kicad_dru','08_reviews/connector_orientation.yaml']:
 f=P/n
 if f.is_file():files[n]=f
files['preserve_before_escape_correction.py']=Path(__file__)
for prefix in ['owned-placement-preflight','owned-layout-decision','owned-layout-source-checkpoint','owned-layout-handoff','owned-layout-validate']:
 for f in Path('/tmp/carrier-connector-integration-20260911').glob(prefix+'*'):
  if f.is_file():files['validation/'+f.name]=f
for n in ['layout-finding-closure.json','layout-finding-before.yaml','owned-layout-preservation-result.json','owned-layout-adoption.json','escape-dossier-availability-opened.json']:
 files['root/'+n]=D/n
meta=json.loads((D/'escape-dossier-availability-opened.json').read_text())[0]
assert json.loads(Path(meta['attempt']).read_text())['status']=='PASS'
for f in Path(meta['project']).rglob('*'):
 if f.is_file():files['availability/'+f.relative_to(meta['project']).as_posix()]=f
for n in ['01_docs/STATUS.md','01_docs/findings.yaml','06_build/agent_handoff.yaml','02_parts/TPS7A9201DSKR/part.yaml','08_reviews/pre-route_layout.md']:
 files[n]=P/n
m={n:{'size':f.stat().st_size,'sha256':sha(f.read_bytes())} for n,f in sorted(files.items())};doc={'members':m,'guard_paths':names,'absent_guard_paths':[n for n in names if not (P/n).exists()],'scope':'Preservation only. No generated guards retired; no source checkpoint renewed.'};tmp=D/'before-escape-correction.tar.gz'
with tarfile.open(tmp,'w:gz',compresslevel=3) as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 b=(json.dumps(doc,indent=2)+'\n').encode();x=tarfile.TarInfo('MANIFEST.json');x.size=len(b);t.addfile(x,io.BytesIO(b))
h=sha(tmp.read_bytes());out=P/'01_docs/journal'/(h+'.tar.gz');assert not out.exists();shutil.copyfile(tmp,out)
with tarfile.open(out) as t:
 assert set(t.getnames())==set(m)|{'MANIFEST.json'}
 for n,row in m.items():b=t.extractfile(n).read();assert len(b)==row['size'] and sha(b)==row['sha256'],n
result={'archive':str(out),'sha256':h,'size':out.stat().st_size,'payload_members':len(m),'checkpoint_companions_verified':len(old['explicit']),'guards_retired':False,'time':datetime.now(timezone.utc).isoformat()};(D/'before-escape-correction-preservation-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
with (P/'01_docs/journal/contracts.md').open('a') as f:f.write(f'\n## Allowed pre-escape-correction canonical preservation\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Exact outgoing canonical board/schematic, checkpoint-bound generated companions, all present prelayout guards and native prepared sidecars plus current independent reviews. Preservation only; no guard retirement or renewal claimed |\n')
