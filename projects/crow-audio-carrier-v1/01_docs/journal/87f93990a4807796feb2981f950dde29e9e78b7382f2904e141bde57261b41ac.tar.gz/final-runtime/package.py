from pathlib import Path,PurePosixPath
import json,hashlib,tarfile
s=Path(__file__).parent; out=s.parent/'outputs';e=json.loads((s.parent/'envelope.json').read_text())
excluded={'package.log','package.runtime.json','preflight.log','preflight.runtime.json'}
files=[]
for p in sorted(s.rglob('*')):
 assert not p.is_symlink()
 if p.is_file() and p.name not in excluded: files.append((p,'review/'+p.relative_to(s).as_posix()))
for n in ('report.md','evidence.json'):files.append((out/n,n))
archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p,n in files:t.add(p,arcname=n,recursive=False)
rows=[];seen=set()
with tarfile.open(archive,'r:gz') as t:
 for m in t.getmembers():
  assert m.isfile() and not m.issym() and not m.islnk()
  pp=PurePosixPath(m.name);assert not pp.is_absolute() and '..' not in pp.parts
  assert m.name not in seen;seen.add(m.name)
  assert not m.name.endswith(('.tar','.tar.gz','.tgz'))
  b=t.extractfile(m).read();assert len(b)==m.size
  original=next(p for p,n in files if n==m.name).read_bytes();assert b==original
  rows.append({'path':m.name,'size':m.size,'sha256':hashlib.sha256(b).hexdigest()})
a=archive.read_bytes();manifest={'archive_sha256':hashlib.sha256(a).hexdigest(),'archive_size':len(a),'member_count':len(rows),'members':rows}
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(out/'result.json').write_text(json.dumps({'subject':e['subject'],'checks':{'inputs-verified':'PASS','review-complete':'PASS','evidence-complete':'PASS'},'unresolved':[]},indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='members'}));print('Every regular archive member reopened, digested, and compared byte-for-byte; all five output files present.')
assert set(p.name for p in out.iterdir())=={'report.md','evidence.json','evidence-manifest.json','evidence.tar.gz','result.json'}
