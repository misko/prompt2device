review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_control_fets_mountedframe1 (actual fresh agent)
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

Limited coverage: Q_DUMP, Q_PRE_EN, Q_RST1 only. All commissioned instances PASS. This is a pre-route pin review, not whole-board acceptance or permission to order. The three immutable board/parts/rules hashes above are supplied metadata, not independent whole-board conclusions. Exact envelope subject: raw_sha256 baf61fd144636e9501c421cf98df3320e4b654477ac5dd8dbe9f662a9b1eeda8; semantic_sha256 9d07cd194850ea56dcf7a03831c97dbf6dab374b7a97cee52d6cbe83d158e05a.

Method and independent physical expectation

The actual primary PDF page images were rendered with pdftoppm and visually inspected with view_image before opening the native dossiers. The physical expectations were recorded in independent-before-dossiers.txt first. The dossiers' historical verification notes were not used as engineering evidence. Only the supplied protocol, exact primary PDFs, and native dossiers informed judgment; no schematic, live board, project history, or external source was consulted.

AO3400A Rev3.1 page 1, unnumbered SOT23 Top View/Bottom View and equivalent-circuit figures: the top-view white-dot corner is adjacent to G; S is the other paired lead, D the lone opposite lead. The bottom view is explicitly a different view and was not used for direct footprint comparison. 2N7002K DS30896 Rev20-2 page 1, unnumbered Top View and Equivalent Circuit: G is lower left, S lower right, D upper centre. Rotate this top-view drawing 90 degrees clockwise to obtain G upper left, S lower left, D middle right. The AO top view has the same functional handedness after planar rotation. Both devices have three discrete terminals; no EP and no fused physical identities. Diodes page 7 Package Outline Dimensions and Suggested Pad Layout independently show three lands and no EP.

The inspected figures label terminals G/S/D rather than printing numeric pin IDs. Consequently 1/2/3 below are dossier pad identifiers checked against independently derived physical G/S/D locations; no manufacturer numeric labels were invented. The physically relevant pin-1 position is the dossier's G pad at upper left (AO's marked G corner). The G->S->D cycle is CCW. No mirrored top-view comparison or extra mounting reflection was applied.

All three dossiers explicitly state front F.Cu mount and component-top +x right/+y down, translation/rotation undone. Rotation is zero; native positions minus each origin reproduce the component-top coordinates to 0.000001 mm. The three surviving positions are noncollinear, so winding is determinate. Numeric 1->2->3 signed areas in x-right/y-down coordinates are -1.781250 mm² for Q_DUMP and -1.900000 mm² for each Diodes device, consistent with CCW.

Q_DUMP — VERDICT: PASS

Primary: AO3400A_Rev3.1.pdf, SHA-256 9c60d0b6c1ddc7609a4b788a91181468d8ffe6c3e9ba425c3d8ffc5ba88c5033, PDF page 1 SOT23 Top View/Bottom View and equivalent-circuit figures.
Measured native dossier census: 3 pad rows, 3 unique pad numbers, 3 distinct native positions, 3 physical G/S/D identities, 0 EPs, 0 fused aliases. Each identity maps one-to-one.
Q_DUMP pin 1 (G): expected upper-left paired control terminal, at the marked G corner, vs observed (-0.937500,-0.950000), function G, DUMP_GATE. PASS.
Q_DUMP pin 2 (S): expected other paired terminal and grounded reference for a low-side switch, vs observed (-0.937500,+0.950000), function S, GND. PASS.
Q_DUMP pin 3 (D): expected lone opposite switched terminal, vs observed (+0.937500,0), function D, ADC_DUMP. PASS.
The table's N/S labels for pads 1/2 correspond to their small numerical predominance in |y|; both coordinates are on the left paired-lead side. The coordinate geometry, not a compass label alone, establishes the package comparison. No winding or pin-1 mismatch.

Q_PRE_EN — VERDICT: PASS

Primary: 2N7002K_DS30896_Rev20-2.pdf, SHA-256 669e5d68d6458e0879d7396416bdcdb3ef9966ea60f054773d4c891d735aa818, PDF page 1 Top View/Equivalent Circuit; page 7 Package Outline Dimensions/Suggested Pad Layout.
Measured native dossier census: 3 pad rows, 3 unique pad numbers, 3 distinct native positions, 3 physical G/S/D identities, 0 EPs, 0 fused aliases. Each identity maps one-to-one.
Q_PRE_EN pin 1 (G): expected upper-left paired control terminal, vs observed (-1.000000,-0.950000), W, G, PWR_EN. PASS.
Q_PRE_EN pin 2 (S): expected lower-left paired reference terminal, vs observed (-1.000000,+0.950000), W, S, GND. PASS.
Q_PRE_EN pin 3 (D): expected lone right-side switched terminal, vs observed (+1.000000,0), E, D, PRE_GATE. A grounded-source N-channel drain can pull down another gate net; the net name does not require this terminal itself to be G. PASS.

Q_RST1 — VERDICT: PASS

Primary: 2N7002K_DS30896_Rev20-2.pdf, SHA-256 669e5d68d6458e0879d7396416bdcdb3ef9966ea60f054773d4c891d735aa818, PDF page 1 Top View/Equivalent Circuit; page 7 Package Outline Dimensions/Suggested Pad Layout.
Measured native dossier census: 3 pad rows, 3 unique pad numbers, 3 distinct native positions, 3 physical G/S/D identities, 0 EPs, 0 fused aliases. Each identity maps one-to-one.
Q_RST1 pin 1 (G): expected upper-left paired control terminal, vs observed (-1.000000,-0.950000), W, G, RESET_PULSE_H. PASS.
Q_RST1 pin 2 (S): expected lower-left paired reference terminal, vs observed (-1.000000,+0.950000), W, S, GND. PASS.
Q_RST1 pin 3 (D): expected lone right-side switched terminal, vs observed (+1.000000,0), E, D, ADC_RESET_N. A grounded-source N-channel device can assert an active-low reset by sinking its drain. PASS.

Instance symmetry and limits

Q_PRE_EN and Q_RST1 have identical package geometry, functions, and electrical roles: pin 1 control; pin 2 GND; pin 3 controlled sink node. Q_DUMP uses a different N-channel part but preserves the same structural roles. The body-diode direction is S to D in each manufacturer's circuit, consistent with grounded sources and switched drains. Aggregate census is 9 native pads, 9 physical terminal identities, no missing or collapsed identities, no EP, no fused aliases.

No FAIL or QUESTION remains in the commissioned pin scope. Net-role sanity is assessed from the supplied names and physical transistor functions; this review does not validate circuit timing, downstream fanout, voltage/current margins, land-pattern manufacture, routing, or operation of the whole design. Evidence retains actual rendered figures, dossiers, methods, calculations, raw tool logs, runtime receipts, and before/after input digests. The missing /usr/bin/rg launch is retained as a tooling incident; the same document-location operation completed through a bounded Python read. This did not substitute a reviewer or primary source.
