# Rule-area predicate provenance — 2026-09-13

Read-only reference for the ADC1 source-scope reassessment, not native evidence.

Official KiCad 10.0 PCB Editor manual:
https://docs.kicad.org/10.0/en/pcbnew/pcbnew.html#custom_design_rules

The expression-function table distinguishes whole-object enclosure from any
object overlap. `insideArea` is a deprecated alias with intersection semantics;
`intersectsArea` is its recommended replacement. `enclosedByArea` requires the
entire object to lie in the area. Root opened the English 10.0 manual through
the web tool on 2026-09-13 at approximately21:56UTC (table lines5513,5522,5528).

Local generate_rules_generic.py emits A.insideArea for scoped floors, while
the carrier's ADC_WEST_LOCAL source rationale explicitly requires whole-capsule
extents. A generated DRC result that accepts an intersecting item therefore
cannot by itself discharge that stronger authored extent obligation. This is
a source/consumer distinction, not evidence that native DRC reported a width
violation. The saved candidate4 DRC remains its original result.
