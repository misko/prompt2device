from pathlib import Path
import json
import thermal_review_common as common
source=Path(common.__file__).read_text().replace('rj45-placement-thermal-availability-opened.json','rj45-adc2-source-review-availability-opened.json')
ns={'__file__':common.__file__};exec(compile(source,'<source-commission>','exec'),ns)
R,N=common.R,common.N;P=R/'projects/crow-audio-carrier-v1'
copies=[(P/'03_src','project/03_src'),(P/'03_tscircuit/src','project/03_tscircuit/src'),
        (P/'01_docs/decisions','project/01_docs/decisions'),
        (P/'01_docs/STATUS.md','current-handoff/STATUS.md'),
        (P/'01_docs/findings.yaml','current-handoff/findings.yaml'),
        (P/'06_build/netlists/crow_audio_carrier_v1.net','project/06_build/netlists/crow_audio_carrier_v1.net'),
        (R/'skills/kicad-pcb/scripts','shared/skills/kicad-pcb/scripts'),
        (R/'skills/pcb-design/scripts','shared/skills/pcb-design/scripts'),
        (R/'tests/README.md','canon/testing.md'),(R/'CLAUDE.md','canon/CLAUDE.md'),
        (R/'skills/kicad-pcb/references/source-to-prep-authority.md','canon/source-to-prep-authority.md')]
for name in ['diagnose_adc2_baseline_shadow.py','diagnose_adc2_baseline_shadow.json','census_route_contract_assertions.py','census_route_contract_assertions.json']:
    copies.append((N/name,'diagnostics/'+name))
for p in (P/'02_parts').glob('*/part.yaml'):copies.append((p,'project/'+p.relative_to(P).as_posix()))
task='''# Isolated source owner: complete baseline route-contract correction

Root retains sole LIVE writer and handles separate ADC2 reservation proposal
and native placement workflow. This fresh source handoff owns only new finding
CARRIER-ROUTE-SOURCE-BASELINE-001. Prepare SOURCE postimages in scratch; do not
change any live/frozen file, commit, generate/load/save/fill any board, run DRC,
prep/router, or consume native candidate. Cumulative top-only native4/4 is closed.
Analytical footprint/SHAPE operations and source_inventory TSX evaluation allowed.

Read current-handoff and diagnostics. Ordinary unmodified source contract suite
has13/19PASS with6failingmethods on unchanged source; diagnostic assertion observer
ran all19bodies and retained10assertion failures, NOT a passing test run. Root
shadow compiler independently identifies W-CLASS-UNKNOWN for CHASSIS_SHIELD.
Source stackup.yaml explicitly SHADOW ONLY; floorplan physical stack and actual
route class_layers/nets already own execution and must remain unchanged.

Prepare the smallest coherent proposal, preferably ONLY two existing files:
03_src/rules/stackup.yaml and03_src/tests/test_route_source_contract.py.
1. Reconcile shadow CHASSIS_SHIELD routing class with existing exact route/nets
   outer-layer shell interconnect intent. Never add inner GND routing, bond
   CHASSIS to signal GND, invent a required shield reference plane, change
   physical stack or promote shadow receipt to execution authority. Read actual
   compiler reference resolution semantics; inferred adjacent plane metadata is
   not a DC connection. Preserve every existing class/reference/width/floor.
2. Reconcile all source census assertions from current explicit accepted intent:
   class CHASSIS1, native221/178non-GND functional,173 generic wave members,
   154seed banks,20via-spec records versus old220/177/172/105/19. Do not just copy
   counts from implementation into tests: retain exact membership/bijection and
   current-owner checks and meaningful hostile mutations. Existing333refs985pins
   and42NC remain unchanged.
3. Diagnose the TWO real capsule-extent assertions hidden behind old seed count
   in test_exact_seed_identity_scope_extent_and_no_high_current_vias. Derive exact
   offending segments and current accepted ADC supply permissive scopes from
   floorplan/route/ADR0015/ADC feed tests. Preserve real full-width capsule
   coverage and power/return floors. Do not widen physical regions, silently
   skip failed endpoints, reduce track radius, delete geometry checks or accept
   arbitrary region coverage. Minimal test representation correction must be
   supported by the actual source consumers and known-bad coverage controls.
4. Show original normal six failures as baseline, actual new/updated tests RED
   against exact pre-fix owning shadow/test representation and GREEN proposed.
   Preserve every existing hostile case. Run the full normal route-contract
   suite, not the diagnostic assertion observer. Related ADC source tests only
   if your shared test helper changes. No broad unrelated tests.

Do not edit floorplan.yaml, route.yaml, test_adc_feed_source.py, ADR0015 or any
other pending ADC2 proposal file. Do not raise any electrical or native limit.
If full census cannot be coherently repaired within these source owners,
return INCOMPLETE with exact additional dependency; no trial or silent scope
extension. A third documentation file needs precise justification before edit.

All TSX imports and source/part metadata are frozen here. Use scratch/work/
projects/crow-audio-carrier-v1 and frozen shared/skills in scratch/work/skills.
Historical controls may read immutable real R Git object store via explicit
GIT_DIR, recording actual commits/blobs. Standard installed libraries are
read-only dependencies; no tool installs. Inspect native API names before use.

Return exact before/after manifest and postimages under scratch/after/<repo-relative>
plus minimaldiff, full baseline/RED/GREEN raw methods/runtime, source invariance
and cause/consumer analysis in required archive. Proposal SOUND is not independent
acceptance. Root will independently review the exact patch and compose it with
separately reviewed ADC2 reservation before live source renewal where possible.
'''
ns['open_task']('rj45-baseline-route-contract-source1',task,copies,minutes=17,role='authoring')
