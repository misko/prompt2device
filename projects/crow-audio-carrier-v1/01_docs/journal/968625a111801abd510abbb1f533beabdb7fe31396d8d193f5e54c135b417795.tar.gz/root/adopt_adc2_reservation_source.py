from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
N=Path(__file__).parent
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
author=json.loads((N/'rj45-adc2-reservation-source1-opened.json').read_text())
review=json.loads((N/'rj45-adc2-exact-source-review1-opened.json').read_text())
close=json.loads((N/'rj45-adc2-exact-source-review1-closeout-summary.json').read_text())
assert close['delivery_status']=='PASS' and close['engineering_verdict']=='SOUND'
assert close['frozen_inputs_reverified']==354 and close['review_archive_members_reopened']==315
rows=json.loads((Path(author['output_dir'])/'evidence.json').read_text())['proposed_sources']
report=(Path(review['output_dir'])/'report.md').read_text()
native={}
for slug,stem in [('crow-audio-carrier-v1','crow_audio_carrier_v1'),('crow-mic-pod-v3','crow_mic_pod_v3')]:
 p=R/'projects'/slug/'04_kicad'/(stem+'.kicad_pcb');native[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
payload=[]
for row in rows:
 assert row['before_sha256'] in report and row['after_sha256'] in report
 dst=R/row['path'];src=Path(author['scratch_dir'])/'after'/row['path']
 assert hashlib.sha256(dst.read_bytes()).hexdigest()==row['before_sha256']
 data=src.read_bytes();assert hashlib.sha256(data).hexdigest()==row['after_sha256']
 payload.append((dst,data))
assert len(payload)==3
for dst,data in payload:dst.write_bytes(data)
for p,h in native.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
record={'adopted_at':datetime.now(timezone.utc).isoformat(),'sources':rows,
        'independent_review_archive':close['sha256'],'native_unchanged':native,
        'scope':'Exact independently SOUND3file ADC2 source only. Full source/checkpoint/native renewal owed. Baseline contract/ADC1 return-width concern open; cumulative4/4 remains closed; no candidate5 admission.'}
(N/'adc2-reservation-source-adoption.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
