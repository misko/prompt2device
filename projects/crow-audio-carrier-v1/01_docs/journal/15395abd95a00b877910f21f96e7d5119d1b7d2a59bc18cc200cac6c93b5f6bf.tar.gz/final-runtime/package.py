import json,hashlib,tarfile,io
from pathlib import Path,PurePosixPath
s=Path(__file__).parent;o=s.parent/'outputs'
def sha(b):return hashlib.sha256(b).hexdigest()
# Packaging/preflight logs remain outside archive to avoid self-referential archive content.
files=[p for p in s.rglob('*') if p.is_file() and not p.name.startswith(('delivery-pack','delivery-preflight','delivery-reopen'))]
files += [o/'report.md',o/'evidence.json',o/'result.json']
rows=[]
with tarfile.open(o/'evidence.tar.gz','w:gz') as t:
 for p in sorted(files):
  assert not p.is_symlink() and p.suffix not in ['.gz','.zip','.tar'];b=p.read_bytes();n='review/'+p.relative_to(s).as_posix() if p.is_relative_to(s) else 'handback/'+p.name
  i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b));rows.append({'path':n,'size':len(b),'sha256':sha(b)})
a=(o/'evidence.tar.gz').read_bytes();manifest={'archive_sha256':sha(a),'archive_size':len(a),'member_count':len(rows),'members':rows};(o/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2))
expected={q['path']:q for q in rows};seen=set()
with tarfile.open(o/'evidence.tar.gz','r:gz') as t:
 for q in t.getmembers():
  p=PurePosixPath(q.name);assert q.isfile() and not q.issym() and not q.islnk() and not p.is_absolute() and '..' not in p.parts and q.name not in seen;seen.add(q.name);b=t.extractfile(q).read();assert len(b)==expected[q.name]['size'] and sha(b)==expected[q.name]['sha256']
assert seen==set(expected)
print(json.dumps({'status':'PASS','safe_members_reopened':len(seen),'archive_size':len(a),'archive_sha256':sha(a)}))
