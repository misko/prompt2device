# Scoped primary-layout continuation — SOUND

All13 commissioned families and18 native instances are covered. This verdict addresses only the previously uncovered primary application/layout applicability. It is not whole-board acceptance, route closure, fabrication approval or permission to order. **DO-NOT-ORDER.** The original INCOMPLETE review is preserved.

Native SHA256: `d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de`  
Prepared r0 SHA256: `b75acca754b864d8c69df51b8343f21cf01ec9640325216c5e96f466f83861b1`  
Design-rules digest: `ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7`

## Evidence and limits

All569 envelope file sizes/SHA256 before and after; exact native/prepared/rules hashes bound in inheritance-receipt.json. No live engineering inputs.

Safe prior archive enumeration323 members and cryptographic verification of six selected reopened members. Explicitly inherit only exact-board native identities and61 selected proximity rows; no repeated full DRC/census, no prior verdict promotion.

Read selected13 part dossiers and source component mapping. pdftotext14 exact supplied primary PDFs; inspected26 actual pdftoppm page images with view_image. Figure provenance/hashes in figures.json. No secondary web authority or invented missing vendor layout figure.

Fresh pcbnew read-only exact native andprepared boards;18 poses and pad geometries;10 physical supply and10 ground-return endpoint pairs;11 timing/clamp/signal pairs;4 inductor pairs;31 hot-node pad separations;3 input-bias pairs;2 header geometries. Effective native shape clearance and Euclidean center spacing recorded separately. Not route-length/connectivity proof.

Finite direct argv via shared pipeline_runtime.run_stage, explicit cwd/environment, raw log+runtime+command retained. Failed initial prepare (console-tail bound, YAML date serialization) and measurement (API name, mistaken capacitor terminal query) retained; corrected measurement asserts matching actual nets and completed successfully. No source or board mutation.

26 actual primary page images from14 PDFs were opened, not merely generated. Fresh geometry covers18 instances;61 exact-board proximity rows are inherited,60 passing and one existing policy metric discrepancy. All bypass capacitors measured below are100nF and on the same side as their IC. Distances are placement measurements, not proof of low-impedance routed returns.

| IC | Bypass | Supply gap mm | Supply center mm | IC GND–cap GND center mm |
|---|---|---:|---:|---:|
| U_PWR | C_PWR | 0.790000 | 1.420000 | 3.614748 |
| U_AUDIO | C_AUDIO | 1.820080 | 2.452835 | 3.881546 |
| U_TDM_SCH | C_TDM_SCH | 0.690000 | 1.632500 | 5.225185 |
| U_DUMP | C_DUMP_LOGIC | 3.074509 | 4.069927 | 2.808079 |
| U_LDO_EN | C_LDO_EN | 1.040009 | 1.776177 | 3.610375 |
| U_OE | C_OE | 0.690000 | 1.632500 | 5.225185 |
| U_TDM | C_TDM | 0.690000 | 1.633266 | 5.243573 |
| U_RST2 | C_RST2 | 0.740000 | 1.821545 | 6.503309 |
| U_RST1 | C_RST1 | 0.715000 | 1.732500 | 4.665250 |
| U_CLK | C_CLK | 0.734457 | 1.681339 | 5.722491 |

## AO3401A — Q_PRE

AO3401A Rev3.1 pp1–2 and AOS PO-00001N SOT23 p1; full supplied catalog text inspected.

No dedicated application PCB layout or numerical placement maximum. G/S/D terminal identity is mandatory. Suggested land pattern is a package recommendation. Thermal numbers are conditional test results, not a universal required board stackup.

Q_PRE at (44.02,58.10),180deg F.Cu: gate1 PRE_GATE, source2 5V_LDO_FEED, drain3 hold path. Verified inherited copper gaps to D_HOLD 1.461054, R_PRE 3.419296, R_PRE_G 1.694709, Q_PRE_EN 2.968268 mm satisfy fixed 2/4/2.5/3.5 mm source budgets. The loop is a local load-switch/precharge arrangement; short broad power copper remains source engineering practice.

Remaining: Final power copper and pulse/thermal qualification remain due. The datasheet 1in² FR4/2oz thermal test fixture is not evidence this board achieves that rating.

## AO3400A — Q_DUMP

AO3400A Rev3.1 pp1–2; supplied catalog text.

No dedicated application PCB layout. Terminal identity mandatory; thermal fixture conditions qualify ratings. No invented vendor millimetre cap.

Q_DUMP at (65.9,76.9),0deg F.Cu: local discharge switch, drain3 to R_DUMP gap1.100000 mm; gate1 to R_DUMP_PD gap1.630000 mm, within source2/2.5 mm budgets.

Remaining: Discharge pulse/thermal behavior and completed current-return copper remain separate electrical/route obligations; catalog current headline is not a board current guarantee.

## 74LVC1G17GV,125 — U_TDM_SCH

Nexperia 74LVC1G17 pp3,11 and supplied complete text.

Selected GV is SOT753/SC-74A, not GW SOT353. Pin1 NC; pins2 A,3 GND,4 Y,5 VCC. No dedicated PCB layout figure or quantitative bypass placement in this exact catalog; local100nF is source engineering practice.

U_TDM_SCH (147.5,52) F.Cu. Physical VCC5-to-C_TDM_SCH supply gap0.690000 mm, input2-to-R_TDM_PD gap0.705883 mm; Y4 to U_TDM A2 gap2.986715 mm / center4.353519 mm. NC1 remains NC.

Remaining: Maintain short direct TDM route and local ground reference during routing; proximity does not establish route length or ground impedance.

## TPS389001DSER — U_PWR, U_AUDIO

TI TPS3890 SLVSD65A p17 §11 and Fig27.

Low-impedance VDD connection applies. Nearby0.1uF is recommended good analog design practice. Minimizing CT capacitance when CT is unconnected is conditional and does not describe these fitted-cap instances. Exact DSE6 has no exposed pad; generic dossier thermal-pad wording cannot create one.

U_PWR (33,56.7) and U_AUDIO (33,61.1), F.Cu. Physical VDD4 bypass gaps0.790000/1.820080 mm; GND2 endpoints individually measured. U_PWR CT5-to-C_PWR_CT1 gap1.263058 mm; U_AUDIO CT5-to-C_AUDIO_CT1/2 gaps2.457329/2.025000 mm. Sense1 hot-node gaps12.229799/10.494917 mm and CT5 gaps11.031872/9.286898 mm to existing prepared SW/BST primitives. These are explicit physical pins, not same-net MR aliases.

Remaining: Existing U_PWR.6 pull-up budget discrepancy remains policy finding P1 below. Existing U_AUDIO.2 and U_PWR.2 GND open components remain route obligations. No claim that bypass endpoint distance proves closed low-impedance return.

## DMP6023LFG-13 — Q_IN

Diodes DMP6023LFG DS37204 Rev2-2 pp1,2,5.

PowerDI3333-8 terminal banks mandatory; recommended land pattern is not a dedicated reverse-input application drawing. Thermal note5 minimum-layout condition and note6 2oz/thermal-via/1in² copper condition must not be conflated. No vendor numerical gate-clamp placement maximum in supplied catalog.

Q_IN (40,74.8) F.Cu: gate4 Q_IN_GATE, sources1–3 12V_PROTECTED, common drain5 12V_FUSED; fused drain representation is present. Native gate4-to-D_QIN_GS anode2 gap6.322324 mm / center7.321416; source1-to-clamp cathode1 gap2.614049 mm / center3.611527. Gate clamp and gate resistor satisfy inherited source7/4 mm gaps; input fuse gap2.75 mm satisfies3.5. This is local protection, not an inferred vendor application layout.

Remaining: Complete broad protected-power copper and clamp loop; thermal current/temperature validation remains. Do not assume2oz fixture thermal performance on35um copper. Full land/pin ownership review is inherited/separate, not rerun here.

## 74LVC1G14GV,125 — U_DUMP, U_LDO_EN, U_OE

Nexperia 74LVC1G14 Rev19 pp3,9,11.

Selected GV SOT753 pin1 NC,2 A,3 GND,4 Y,5 VCC. Fig relaxation oscillator is an example for an oscillator, not a required RC feedback network for all inverters. No dedicated application PCB drawing or numerical decoupler maximum in supplied catalog.

All three F.Cu instances covered individually: U_DUMP (57.1,75.3) uses5V_LDO_HOLD, discharge threshold; C_DUMP_LOGIC supply gap3.074509 mm within source4 mm, timing C/R gaps2.803611/3.867785/3.331866 within3.5/4.5/4. U_LDO_EN (57.1,70.8), same5V hold supply, converts DUMP_GATE to LDO_EN; bypass gap1.040009 within2. U_OE (149,65.5),3V3_ADC, module-presence control; bypass0.69, sense series1.74, pulldown1.108287 mm within source limits. U_OE Y-to-U_TDM OE endpoint center13.674269 mm is explicitly not claimed a routed length. Dossier phrases powered from3V3 and next toU_TDM apply only U_OE, not the two other instances.

Remaining: Maintain defined inputs, local bypass return and avoid switching noise on RC thresholds. Broad family prose must be interpreted per instance, not used to change the two correct hold-rail bindings.

## SN74LVC1G125DBVR — U_TDM

TI SCES223U pp14–15 §§8.3–8.4, Figs8-3 through8-7.

Nearby bypass, same-side whenever possible, short/wide ground and continuous reference are applicable recommendations.8–12mil signal width and <12cm length are layout guidance; no authorization to replace fixed source widths. Parallel spacing at least3x dielectric thickness is stated as must in the layout guidance and remains a routed-geometry requirement. Longer traces require controlled impedance/source damping.

U_TDM (154,54) F.Cu;100nF C_TDM same side, physical VCC5 gap0.69 mm / center1.633266. Y4-to-source damping R_TDM1 gap0.720111 / center1.689158 mm, supporting source termination locality. Clean input from U_TDM_SCH is4.353519 mm center. Output placement is adjacent the module header, but total routed length, branches and spacing are not inferred from endpoints.

Remaining: Postroute verify reference continuity, spacing against actual dielectric, route length, corner/branch guidance and appropriate fixed-width/SI profile; no width relaxation or route waiver. Ground return remains to be completed.

## SN74LVC1G123DCTR — U_RST2

TI SCES586E p14 Fig8-1, p16 §§9–10 layout example, p17; pin/functional supplied text.

Timing capacitor must bridge CEXT6 and REXT/CEXT7; resistor connects7 toVCC, never direct-short7 torail. Unused logic inputs must be defined.0.1uF near actualVCC is recommended. Fig8-1 switch debounce is an application example, not an obligation to implement a mechanical switch here; route-corner figure is guidance.

U_RST2 (118,72) F.Cu. PhysicalVCC8 (not B2 alias) to100nF C_RST2 gap0.74 mm; GND4 return endpoint measured. A1=GND, B2=3V3_ADC, CLR3=POR_N, Q5=RESET_PULSE_H; timing C_RST_T=220nF bridges6 RESET_C and7 RESET_RC, R_RST_T=100kohm goes from7 junction to3V3_ADC. Fresh gaps6-to-C1 2.021803,7-to-C2 1.662624,7-to-R2 3.880983 mm satisfy source2.5/2.5/4.5 mm. Timing pins are >72.69 mm from current SW/BST copper.

Remaining: Keep timing loop local and referenced; final return/routed lengths and reset timing qualification remain.100nF is bypass value, not mistaken for selected220nF timing capacitor.

## 2N7002K-7 — Q_PRE_EN, Q_RST1

Diodes DS30896 Rev20-2 pp1,7 and supplied catalog text.

SOT23 terminal identity and selected package fit apply; p7 is suggested land pattern, not a circuit application PCB layout. No catalog numerical gate-resistor placement rule.

Q_PRE_EN (39.86,57.9) and Q_RST1 (109.5,73.5), both F.Cu: low-current gate/reset pulls. Q_PRE_EN drain3 toQ_PRE gate gap2.968268 mm is verified via AO3401A fixed budget. Its gate1 has6.646 mm minimum gap from existing BUCK_SW/BST copper. Q_RST1 drain3-to-R_RESET_PU2 gap1.853781 and gate1-to-R_RESET_GPD1 gap0.97 mm satisfy2.5/1.5 mm; its gate is61.912006 mm from switch copper.

Remaining: Preserve defined gate bias and low-impedance source GND when routed. Catalog land and ESD diagrams are not numerical circuit-proximity requirements.

## XGL4020-332MEC — L_BUCK

Coilcraft Document1529 supplied PDF pp1,3, revised February19,2026.

Marked short/start terminal should connect high-dV/dt side for lowest EMI: explicit recommendation. Recommended land geometry .98x3.4 mm pads on2.37 mm centers. Temperature-rise/current table is fixture dependent, not a universal board limit. No fabricated application PCB figure.

L_BUCK (47,66) F.Cu,0deg: pads .98x3.4 mm, pitch2.37 mm, marked pad1 BUCK_SW faces U_BUCK and pad2 is5V_BUCK. Pad1-to-U_BUCK5 gap1.525 mm within source3 mm; pad2-to-output C_BUCK_O1/O2/O3 supply gaps1.175/1.327330/4.117728 mm. This is the desired short switch-node launch and output-cap side orientation.

Remaining: Final SW copper area, power-return loop and thermal/current qualification remain. The separate regulator inductance-selection decision is not reopened by this placement task.

## TPS3839K33DBZR — U_RST1

TI SBVS193D p15 §§10–11 Fig18.

VDD source must have sufficiently low impedance for15uA sampling pulses.0.1uF bypass is conditional if sampling droop is excessive; fitted local bypass satisfies conservative placement. No manufacturer numerical maximum distance.

U_RST1 (110,68) F.Cu physical VDD3-to100nF C_RST1 gap0.715 / center1.7325 mm, GND1 endpoint separately measured; RESET2 and VDD3 have61.972528/63.811511 mm minimum gap from current switch copper. Pins are not inferred from generic SOT23 transistor numbering.

Remaining: Complete local ground return and verify power-up/reset behavior in first article; these are existing route/bringup obligations, not a newly invented fabrication prerequisite.

## TMM-106-01-L-D — J10, J11

Samtec TMM-Series RevAS supplied sheet1 (PDF one raster page), actually visually inspected.

Manufacturer supplies mechanical/order drawing, not a PCB application-layout guide. Selected double-row2mm pitch,6 positions, -01 post/tail geometry apply. Optional MW/RC details on other sheet are not selected. Passive connector has no decoupling/return-loop requirement of its own.

J10 (158,49) andJ11 (158,80), F.Cu90deg: each12 through-hole pads; native same-row and cross-row pitch2mm, drill.8mm, rectangular pad1. Distinct visible front legends MCH TDM/MCH SENSE and explicit J10=MCH J1 TDM J11=MCH J3 SENSE DO NOT SWAP;31mm origin separation. Unshrouded2x6 headers are not claimed mechanically keyed.

Remaining: Maintain mapping and correct mating orientation. Existing first-article cable fit/assembly checks remain separate from design-only fabrication; no new physical test prerequisite. Full final silk-ownership policy is separate review scope.

## SN74LVC3G34DCUR — U_CLK

TI SCES366L p10 §§10–11 and layout corner figure.

Each VCC terminal must have good bypass;0.1uF recommended for single-supply device. Unused inputs must not float; here all3 channels are used and each has defined input bias. Corner drawing is recommendation.

U_CLK (147,59), F.Cu. PhysicalVCC8-to100nF C_CLK gap0.734457 mm / center1.681339, GND4 return endpoint measured. Input1 MCH_MCLK,3 MCH_BCLK,6 MCH_FSYNC bias resistor gaps1.700859/.980127/2.513429 mm; output7/5/2 source damping resistor gaps2.232864/.695/.695 mm. All seven source adjacency and seven keep-short rows pass, with no channel-index assumption. Minimum selected pin-to-existingSW/BST gap98.783375 mm.

Remaining: Complete short clock routes over continuous reference and local supply returns; no claim of final skew/route length or EMI closure.

## Individually classified findings and opens

- **P1 — INHERITED_POLICY_METRIC_WARNING_NOT_WAIVED / OPEN_OWNER_DISPOSITION:** Native effective copper gap U_PWR.6→R_PWR_PU.2 is2.511520 mm against authored2.5 mm; prior source-box metric2.472473 mm. This continuation does not change the budget, waive the discrepancy or relabel it a vendor requirement; separate policy owner resolves it.
- **R1 — EXISTING_SOURCE_PREP_ROUTE_OBLIGATION / OPEN:** Known prepared GND open component includes U_PWR.2 and R_PWR_BOT.2; bypass placement does not close it.
- **R2 — EXISTING_SOURCE_PREP_ROUTE_OBLIGATION / OPEN:** Known prepared U_AUDIO.2 GND open remains. No return closure inferred from endpoint proximity.
- **R3 — EXISTING_SOURCE_PREP_ROUTE_OBLIGATION / OPEN:** All12 inherited starved thermal findings remain unclosed. They are not repeated or waived by this primary-family continuation.
- **R4 — FUTURE_ROUTE_VERIFICATION_OBLIGATION / OPEN:** All10 selected bypass supply pairs are100nF and same-side, but physical cap-GND to IC-GND center distances range2.808079–6.503309 mm. Final low-impedance return, signal reference continuity, current copper and TI1G125 length/parallel-spacing guidance must be verified on routed board. These are not fulfilled by native endpoint geometry.
- **A1 — APPLICABILITY_CLARIFICATION / RESOLVED_FOR_THIS_REVIEW:** 74LVC1G14 family prose about3V3/TDM applies U_OE only. U_DUMP/U_LDO_EN have correct source-specific5V_LDO_HOLD roles. TPS3890 DSE6 has no exposed thermal pad despite generic dossier prose. This review uses exact selected package and instance bindings; no source edits or waiver.
- **B1 — EXISTING_FIRST_ARTICLE_OBLIGATION / OPEN_SEPARATE_FROM_DESIGN_FABRICATION:** Thermal, pulse/reset behavior and cable fit remain first-article obligations; no new physical-test prerequisite to design-only fabrication is introduced.

No commissioned family remains uncovered. Existing findings have not been waived; separate ADC-return and policy reviews retain their own authority. All input files are verified before and after, and the delivery archive is reopened member-by-member. `result.json` PASS checks certify an honest complete handback, not whole-board engineering acceptance.
