from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,shutil
S=Path(__file__).resolve().parent; P=S.parents[3]; O=S.parent/'outputs'
sha=lambda b:hashlib.sha256(b).hexdigest()
env=json.loads((S.parent/'envelope.json').read_text()); ids=json.loads((S/'identities.json').read_text())
after=[]
for row in env['input_packet']:
 b=(P/row['path']).read_bytes(); assert len(b)==row['size'] and sha(b)==row['sha256'],row['path'];after.append(row['path'])
(S/'inputs-after.json').write_text(json.dumps({'verified_count':len(after),'paths':after},indent=2))
header={'review_stage':'pre-route','review_kind':'schematic_render','reviewer_identity':'Codex /root/carrier_rj45_native_carrier_readability_policy23','context':'FRESH','date':'2026-09-13','design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER',**ids['current']}
(O/'report.md').write_text(''.join(k+': '+v+'\n' for k,v in header.items())+'\n'+(S/'report-body.txt').read_text())
evidence={'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','subject':env['subject'],'review_kind':'schematic_render','context':'FRESH','hashes':ids['current'],'methods':['all-input SHA-256 verification before and after','frozen owning seven-hash algorithms','independent all-page Poppler 144 dpi RGB comparison','host view_image inspection of all 19 current full pages plus headers','independent native S-expression component/pin census','independent CircuitJSON source_trace union-find partitions','exact policy/locator reference and native pin membership','regular archive member reopen and hash check'],'counts':{'frozen_inputs':750,'part_dossiers':89,'current_pages':19,'previous_pages':19,'visually_inspected_current_pages':19,'body_pixels_compared':37589400,'body_pixels_changed':0,'native_components':333,'native_nets':221,'native_pin_assignments':985,'source_traces':1475,'first_power_installed':333,'policy_locator_references':23,'locator_pin_net_rows':46,'erc_errors':0,'erc_warnings':2637},'findings':[],'source_changes':json.loads((S/'source-delta.json').read_text())['source_changes'],'coverage_provenance':{'prior_receipt':'preceding-receipts/readability/report.md','prior_receipt_sha256':sha((P/'preceding-receipts/readability/report.md').read_bytes()),'prior_receipt_use':'unchanged visual coverage after independently measured all-page pixel equality; no acceptance restamp','prior_subject':ids['previous']},'limitations':['schematic presentation acceptance only','no PCB or locator-atlas render waiver activation','no pod native population review','no layout/route/release/order acceptance','144 dpi equality measurement','physical qualification remains owed at accepted prototype boundary']}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(O/'result.json').write_text(json.dumps({'subject':env['subject'],'checks':{k:'PASS' for k in env['completion']['checks']},'unresolved':[]},indent=2)+'\n')
archive=O/'evidence.tar.gz'; entries=[]
sources=[(p,'scratch/'+p.name) for p in sorted(S.iterdir()) if p.is_file() and p.name not in {'package.log','package.runtime.json','preflight.log','preflight.runtime.json','archive-reopen.json'}]
sources += [(P/'preceding-receipts/readability/report.md','provenance/previous-readability-report.md'),(P/'preceding-receipts/readability/evidence-manifest.json','provenance/previous-evidence-manifest.json'),(S.parent/'envelope.json','provenance/envelope.json'),(P/'expected-subject.json','provenance/expected-subject.json')]
with tarfile.open(archive,'w:gz') as t:
 for p,name in sources:
  assert p.is_file() and not p.is_symlink(); b=p.read_bytes();entries.append({'path':name,'size':len(b),'sha256':sha(b)});t.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers();assert len(members)==len(entries);seen=set()
 for m,e in zip(members,entries):
  pp=PurePosixPath(m.name);assert m.isfile() and not pp.is_absolute() and '..' not in pp.parts and m.name not in seen and not m.name.endswith(('.tar.gz','.tgz','.tar'));seen.add(m.name)
  b=t.extractfile(m).read();assert {'path':m.name,'size':len(b),'sha256':sha(b)}==e and m.size==len(b)
manifest={'archive_sha256':sha(archive.read_bytes()),'archive_size':archive.stat().st_size,'member_count':len(entries),'members':entries}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(S/'archive-reopen.json').write_text(json.dumps({'status':'PASS','regular_members_reopened':len(entries),'duplicate_members':0,'symlink_members':0,'traversal_members':0,'recursive_archives':0,'archive_sha256':manifest['archive_sha256']},indent=2))
assert {p.name for p in O.iterdir()}=={'report.md','evidence.json','evidence-manifest.json','evidence.tar.gz','result.json'}
print(json.dumps({'status':'PASS','outputs':sorted(p.name for p in O.iterdir()),'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'members':len(entries),'inputs_reverified':len(after)},indent=2))
