from pathlib import Path
from datetime import datetime,timezone,timedelta
import sys,json,hashlib,shutil,tempfile
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;slug='crow-mic-pod-v3';P=R/'projects'/slug;name='rj45-pod-seed-residual-source';D=Path(tempfile.mkdtemp(prefix=name+'-'))
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
cp=json.loads((P/'06_build/checkpoints/prelayout-inputs.json').read_text());paths={R/k.removeprefix('repo:') for k in cp['files']}
for rel in ['CLAUDE.md','tests/README.md','skills/pcb-design/SKILL.md','skills/pcb-design/references/lifecycle-and-backtrack.md','skills/pcb-design/references/execution-runtime.md','skills/kicad-pcb/references/design-policies.md','skills/kicad-pcb/references/source-to-prep-authority.md','skills/kicad-pcb/references/placement-and-proximity.md','skills/kicad-pcb/references/routing-pipeline.md']:
 paths.add(R/rel)
paths.update((P/'04_kicad').glob('*.kicad_*'));paths.update((P/'06_build/netlists').glob('*.net'));paths.update((P/'03_src/tests').glob('*.py'))
for rel in ['01_docs/STATUS.md','01_docs/findings.yaml','06_build/agent_handoff.yaml','06_build/drc/gate.json','06_build/drc/pre_route.json','06_build/build_provenance.json']:
 paths.add(P/rel)
for p in sorted(paths):
 assert p.is_file() and not p.is_symlink(),p;q=D/'input'/p.relative_to(R);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
m=json.loads((N/'rj45-pod-clamp-seed-source-opened.json').read_text());assert json.loads((Path(m['envelope']).parent/'attempt.json').read_text())['status']=='PASS';O=Path(m['output_dir'])
for filename in ['report.md','evidence.json','evidence-manifest.json']:
 q=D/'failure'/filename;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(O/filename,q)
shutil.copy2('/tmp/carrier-locator-implementation-availability-6c_4vwal/preflight.py',D/'preflight.py')
import tarfile
proof=json.loads((N/'pod-seed-residual-diagnosis.json').read_text());(D/'failure/root-native-diagnosis.json').write_bytes((N/'pod-seed-residual-diagnosis.json').read_bytes())
manifest=json.loads((O/'evidence-manifest.json').read_text());matches=[x for x in manifest['members'] if x['sha256']==proof['board_sha256'] and x['path'].endswith('.kicad_pcb')];assert matches
with tarfile.open(O/'evidence.tar.gz') as t:
 member=t.getmember(matches[0]['path']);assert member.isfile();raw=t.extractfile(member).read();assert hashlib.sha256(raw).hexdigest()==proof['board_sha256'];(D/'failure/seed_r0.kicad_pcb').write_bytes(raw)

now=datetime.now(timezone.utc);cut=now+timedelta(minutes=20);hard=now+timedelta(minutes=30)
(D/'TASK.md').write_text((N/'pod_seed_residual_task.txt').read_text().format(cut=cut.isoformat(),hard=hard.isoformat(),repo=str(R)))

items=[]
for p in sorted(D.rglob('*')):
 if p.is_file():b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(D).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
s=subject_identity('pod_clamp_seed_correction',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())]);e=TaskEnvelope(schema=2,task_id=name,stage_id='KICAD-PLACEMENT',run_id=name,subject=s,executor='agent',execution_class='local',recommended_agent_role='authoring',agent_role='authoring',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=2,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']});o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),agent_id='/root/carrier_rj45_pod_seed_residual_source',work_cutoff=cut.isoformat());(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2));print(len(items),'frozeninputs')
