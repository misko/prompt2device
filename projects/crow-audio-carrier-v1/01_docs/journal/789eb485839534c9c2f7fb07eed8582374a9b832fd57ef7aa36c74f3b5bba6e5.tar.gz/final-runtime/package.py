from pathlib import Path
import json,hashlib,tarfile,shutil,collections,re,sys
s=Path(__file__).parent;r=s.parents[3];out=s.parent/'outputs';out.mkdir(exist_ok=True);env=json.loads((s.parent/'envelope.json').read_text());final=s/'candidate3/projects/crow-audio-carrier-v1';repo_rel=Path('projects/crow-audio-carrier-v1');bundle=s/'delivery_bundle';bundle.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(src,dst):
 assert src.is_file() and not src.is_symlink(),src
 dst=bundle/dst;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
verify=[]
for x in env['input_packet']:
 p=r/x['path'];verify.append({'path':x['path'],'size':p.stat().st_size,'sha256':sha(p),'ok':p.stat().st_size==x['size'] and sha(p)==x['sha256']})
assert len(verify)==635 and all(x['ok'] for x in verify)
(s/'input-verification-after.json').write_text(json.dumps(verify,indent=2))
changes=[]
for f in ['03_src/floorplan.yaml','03_src/rules/assembly.yaml','03_src/rules/first_article.yaml']:
 before=r/'input'/repo_rel/f;after=final/f
 changes.append({'path':str(repo_rel/f),'pre_sha256':sha(before),'post_sha256':sha(after)})
 copy(after,Path('source_candidate')/repo_rel/f);copy(before,Path('beforeimages')/repo_rel/f)
# Full numeric DRC rows are retained and independently classified, including repeated per-layer rows.
reason={'hole_clearance':('UPSTREAM_FOOTPRINT','64 native rows: 16 shell-pad/NPTH pairs repeated across four copper layers; authored jack geometry gives 0.0248mm vs unchanged0.25mm hole clearance. Coordinate translation or fuse move cannot alter same-footprint pair.'),'silk_edge_clearance':('UPSTREAM_FOOTPRINT_OR_EDGE_LEGEND','16 native rows: two existing jack silk segments per connector clip board edge at fixed mouth datum. Do not move jack datum to hide source silk overrun.'),'starved_thermal':('UPSTREAM_GROUND_RETURN_INTENT','8 native rows: fixed underside U_ESD1-U_ESD8 pad4 GND has one thermal spoke vs minimum2. Source positions/nets unchanged; no baseline DRC was run in this handoff, so unchanged geometry is not claimed as prior measured DRC. Proposed ground-only solid local zone connection is unapplied.')}
classes={}
for n in [2,3]:
 d=json.loads((s/f'candidate{n}/projects/crow-audio-carrier-v1/06_build/drc/candidate{n}.json').read_text());rows=[]
 for group in ['violations','unconnected_items','schematic_parity']:
  for idx,v in enumerate(d[group]):
   if group=='violations':cat,why=reason[v['type']]
   elif group=='unconnected_items':cat,why='UNROUTED_CONNECTION','Observed unrouted-board connectivity; no routing/import performed. Placement allows ratsnest but final routed DRC remains owed.'
   else:cat,why='SCHEMATIC_PARITY','Each parity row is blocking.'
   rows.append({'group':group,'index':idx,'category':cat,'disposition':why,'native_row':v})
 classes[f'candidate{n}']={'counts':{k:len(d[k]) for k in ['violations','unconnected_items','schematic_parity']},'violation_types':dict(collections.Counter(x['type'] for x in d['violations'])),'rows':rows}
 assert len(rows)==sum(len(d[k]) for k in ['violations','unconnected_items','schematic_parity'])
(s/'drc-complete-classification.json').write_text(json.dumps(classes,indent=2))
# Record all authorizations as scope evidence; no claim to authenticate host state here.
(s/'scope-clarifications.json').write_text(json.dumps({'assembly':{'root_message':'Authorize concrete companion assembly.yaml source consistency: bottom_population and order-time rows must include F1-F8; no physical/purchase authorization or limits change.','applied_in':'candidate2 and candidate3'},'clamp_ground':{'root_message':'Solid U_ESD1..8 pad4/GND local zone connection authorized only if still within third candidate; subsequent root agreed preserve already-completed third candidate, no fourth.','applied':False,'owed':'next distinct upstream source handoff'},'candidate_limit':3,'no_children':True,'live_writer':'root only'},indent=2))
geometry=json.loads((s/'geometry-proof-exact.json').read_text());proof=json.loads((s/'source-proof-exact.json').read_text());suite=json.loads((s/'suite3-results.json').read_text())
# Preserve all admitted candidates, native results, and their source images; no historical compressed archives.
for n in [1,2,3]:
 p=s/f'candidate{n}/projects/crow-audio-carrier-v1'
 for f in ['03_src/floorplan.yaml','03_src/rules/assembly.yaml','03_src/rules/first_article.yaml']:
  copy(p/f,Path('attempts')/f'candidate{n}'/f)
 for subtree in ['04_kicad','06_build']:
  for f in sorted((p/subtree).rglob('*')):
   if f.is_file() and not f.is_symlink() and not f.name.endswith('.tar.gz'):
    copy(f,Path('attempts')/f'candidate{n}'/f.relative_to(p))
for f in sorted((s/'baseline-native').iterdir()):
 if f.is_file():copy(f,Path('beforeimages/native')/f.name)
for f in sorted(s.iterdir()):
 if f.is_file():copy(f,Path('method_and_raw')/f.name)
# Conservative source-support census, not a read-trace or hermeticity claim.
live=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');extra=[]
for sub in ['skills/kicad-pcb/scripts','skills/pcb-design/scripts','skills/kicad-pcb/references']:
 for p in sorted((live/sub).rglob('*')):
  if p.is_file() and not p.is_symlink() and p.suffix in ['.py','.yaml','.json'] and '__pycache__' not in p.parts:
   extra.append({'path':str(p),'size':p.stat().st_size,'sha256':sha(p)});copy(p,Path('shared_method_snapshot')/p.relative_to(live))
for p in [Path('/usr/bin/python3').resolve(),Path('/usr/bin/kicad-cli').resolve(),Path('/usr/lib/python3/dist-packages/pcbnew.py'),Path('/usr/lib/python3/dist-packages/_pcbnew.so')]:
 if p.is_file():extra.append({'path':str(p),'size':p.stat().st_size,'sha256':sha(p)})
(bundle/'shared_method_census.json').write_text(json.dumps({'scope':'conservative support superset; exact native qualification hashes in retained qualification receipt; no syscall read-set trace claimed','files':extra},indent=2))
# All changed F source-dependent references are left observable for the integrator.
patterns=[]
for p in sorted((r/'input'/repo_rel/'03_src').rglob('*')):
 if p.is_file() and p.suffix in ['.yaml','.json','.py','.sh']:
  for lineno,line in enumerate(p.read_text(errors='replace').splitlines(),1):
   if re.search(r'\bF[1-8]\b|F\{i\}|bottom_population',line):patterns.append({'path':str(p.relative_to(r/'input')),'line':lineno,'text':line})
(bundle/'dependent-source-reference-census.json').write_text(json.dumps(patterns,indent=2))
report='''# Carrier RJ45 source-owner handback

**MEASURED: fuse adjacency and first-power population are corrected in candidate3. Overall placement remains FAIL; this is a reviewable source proposal, not placement acceptance.**

The final candidate changes only `projects/crow-audio-carrier-v1/03_src/floorplan.yaml`, `03_src/rules/first_article.yaml`, and the explicitly root-authorized assembly population companion `03_src/rules/assembly.yaml`. All 635 frozen inputs verify before and after. Live project and frozen inputs stayed read-only; all new work is in the allocated scratch/output directories. No routing, conductor, checkpoint refresh, signature transfer, public admission, or live integration occurred. No child agents were used.

## Source correction and exact geometry

All eight original F#.2-to-J#.1 power-pad gaps are **8.836020mm** against **4.5mm**. Final gaps are **3.315000mm**, each with **1.185000mm margin**. Native rotation-aware pad bounding boxes and the same integer-unit Euclidean box-gap method as `policy_audit.py` establish these numbers. Full pad, Fab/body, courtyard, clamp and AFE envelopes for all eight cells are retained in `geometry-proof-exact.json`.

North fuses move from [29.15+32k,36.5] top to [32.2+32k,31.4] bottom; south from [51.85+32k,103.5] top to [48.8+32k,108.6] bottom. Source rotations account for KiCad's bottom flip: north180, south0 produce the intended pad2 direction. Every non-fuse footprint's position, side, orientation, pad/net and body geometry is identical to the frozen board, including all jacks, AFEs and exact underside clamps. Factory Wurth/Weidmuller identities, 1/3/7 power, 2/6/8 GND, 5 audio+, 4 audio-, 9/10 shell, shared rail/VMID and CHASSIS/POD_SHIELD separation remain unchanged. P-PINMAP and independent 8/8 spoke checks were rerun.

For an axis-aligned top-side fuse beside the fixed north jack, its closest lateral copper edge is at least0.255mm inside its courtyard, yielding an infimum4.685mm gap from jack pin1. This explains the underside remedy; it is not an exhaustive proof over arbitrary rotated placements. The native generator and independent P-PADSEP validate the actual underside candidate rather than relying on that inference.

First-power installed population is corrected from316/333 to333/333 with exactly **D_BUCK_IN and R_IN1P/N through R_IN8P/N**. No extras/duplicates remain. Independent circuit.json census and stock S-COUNT reconcile board, schematic, manifest and netlist over333 references. All other parsed first-power fields, including every rail/voltage/current limit, are unchanged. No measured first-article record was fabricated; that physical gate remains owed.

The assembly companion states U_ESD1-U_ESD8 and F1-F8 underside population and extends the existing stencil/paste/rotation/THT-tail/rework qualification sentence to those fuses. It grants no purchase or physical approval. Final F# BOT captions clear each fuse bounding box by0.477350mm; native visible mirrored B.Silk refdes are present8/8. These geometric observations do not prove physical soldering/rework access.

## Retained attempts and unchanged gate results

1. Candidate1 moved fuses underside, improving8.836020mm to5.895325mm maximum, but bottom-flip handedness left all8 adjacency failures. Generator passed. The initial copied-generator launch failed before generation because the frozen tool packet lacked fab_tiers.yaml; its raw failure is retained. The same unmodified shared generator was then invoked from its complete live method installation, read-only, with hashes recorded. This setup failure is not improvement credit.
2. Candidate2 corrected source fuse rotations and the assembly companion. All8 gaps became3.315000mm; placement policy5/5 passed. New F# BOT captions were crowded8/8. Full native DRC reported88 violations,499 unconnected,0 parity.
3. Candidate3 moved only those eight captions0.6mm. All8 newly crowded caption warnings disappear; footprint and copper geometry is identical to candidate2. Existing CH1-CH8 crowded caption warnings remain8/8 and native generator silk ownership remains153/338 owned,160 degraded,25 unplaced. No fourth candidate was run.

Final stock checks: generator P-COLLIDE/polarity/body assertions PASS; S-COUNT4/4 pairs over333 refs; spoke8/8; P-PINMAP411 identities over47 multipin refs; placement feasibility7/7 PASS-or-N-A; models333/333; P-PADSEP461080 copper pairs and750048 paste pairs at unchanged0.090mm floor; placement policy5/5 including all124/124 measurable adjacency budgets and180/180 total layout budgets; native rule generation PASS; P-LAND709/988 pads graded,0 unreached,0 failing. Remaining pads are classified in its complete raw report. The native CLI rc0 is process completion, not a clean DRC verdict.

Final **P-DRC FAIL:88/88 violations classified,499/499 unconnected rows retained,0 parity**:

-64 `hole_clearance`: Wurth J1-J8 shell pads9/10 against same-footprint NPTH,0.0248mm actual vs0.2500mm. Sixteen physical pairs are reported on four copper layers. Owning footprint/source correction is owed; no footprint or threshold changes are in this candidate.
-16 `silk_edge_clearance`: two jack F.Silk segments per connector cross the fixed edge. Owning footprint/legend correction is owed; exact jack mouth datums remain fixed.
-8 `starved_thermal`: U_ESD1-U_ESD8 pad4/GND on B.Cu have1 spoke vs required2. All eight nets and unchanged clamp placements were independently verified. Root's proposal is a floorplan pattern matching those eight clamps with `pad_overrides: [{pads: ["4"], on_net: GND, zone_connection: full}]`. This is a distinct source return-intent proposal, **not applied**: authorization arrived after candidate3 executed, and root explicitly required preserving it without a fourth revision. No thermal threshold or waiver is relaxed. A baseline native DRC was not run here, so prior DRC equivalence is not claimed.
-499 `unconnected_items`: unrouted connectivity, retained individually;0 schematic-parity rows. No route feasibility or finished copper claim follows.

Every raw violation and unconnected item, including repeated layer rows, is stored with its classification. Preliminary isolated-copper allowance remains unchanged and unused. The final suite reaches each finding group directly using stock commands in the disposable source proof; no upstream acceptance is bypassed and no resulting receipt promotes live authority.

## Owed gates and handback

Root must review and integrate the concrete source proposal together with the distinct footprint/ground-return corrections, then archive old guards and perform normal full regeneration. Electrical/readability renewal, fresh independent placement acceptance, connector geometry/service evidence at its proper boundary, routing and post-route copper/thermal verification remain owed. First-article-only/DO-NOT-ORDER and all physical/order qualifications remain unchanged. LAYOUT001 remains closed3/3; this work is no fourth diagnostic or model reset.

The five outputs are report.md, evidence.json, evidence-manifest.json, evidence.tar.gz and exact-subject result.json. The archive holds source_candidate paths, every candidate/source/native result, all methods/raw logs, original source/native beforeimages and per-member hashes. Every regular member is reopened; no symlinks, traversal, duplicate paths or recursive archives are allowed. Final preflight is run after packaging. Runtime process groups ended normally; all scratch and failure evidence is retained, with no live cleanup or deletion.
'''
# Correct any denominators directly from the generated final policy, never infer them.
policy=(final/'06_build/policy_audit.md').read_text()
(bundle/'final-policy-verbatim.md').write_text(policy)
report=report.replace('-64 ', '- 64 ').replace('-16 ', '- 16 ').replace('-8 ', '- 8 ').replace('-499 ', '- 499 ')
(out/'report.md').write_text(report)
owed=['root source review/integration','distinct jack footprint hole/silk correction','clamp pad4 GND return-intent source correction','normal full regeneration and current electrical/readability renewal','fresh independent placement acceptance','routing and realized thermal/return verification','connector/source service and order-time physical qualifications','measured first-article record']
evidence={'domain_result':'LOCAL_SOURCE_CORRECTIONS_PROVED; PLACEMENT_FAIL','subject':env['subject'],'exactsubject':env['subject'],'changedfiles':changes,'input_verification':{'before':{'count':635,'pass':True},'after':{'count':635,'pass':True}},'candidate_attempts':[{'id':k,'gaps_mm':[x['measured_gap_mm'] for x in v['rows']],'board_sha256':v['raw_board_sha256']} for k,v in geometry.items() if k!='baseline'],'baseline':geometry['baseline'],'source_proof':proof,'final_suite':suite,'native_drc':{k:{a:b for a,b in v.items() if a!='rows'} for k,v in classes.items()},'complete_native_row_classification':'method_and_raw/drc-complete-classification.json','owed_gates':owed,'independent_engineering_acceptance':False,'delivery_checks_scope':'Honest complete source-owner handback; does not assert engineering PASS or physical measurement.','runtime_cleanup':'All engineering children completed; all candidate/failure evidence retained. Root alone writes live project.','native_qualification':'PASS4/4; exact receipt and raw cache retained','live_read_only':True,'no_routing':True,'source_revision_count':3}
(out/'evidence.json').write_text(json.dumps(evidence,indent=2))
copy(out/'report.md',Path('report.md'));copy(out/'evidence.json',Path('evidence.json'))
archive=out/'evidence.tar.gz';members=[]
with tarfile.open(archive,'w:gz') as tf:
 for p in sorted(bundle.rglob('*')):
  if p.is_dir():continue
  assert p.is_file() and not p.is_symlink();name=str(p.relative_to(bundle));assert '..' not in Path(name).parts and not name.startswith('/') and not name.endswith('.tar.gz')
  members.append({'path':name,'size':p.stat().st_size,'sha256':sha(p)});tf.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 actual=tf.getmembers();assert len(actual)==len(members)==len({x.name for x in actual})
 for m,row in zip(actual,members):
  assert m.isfile() and m.name==row['path'] and m.size==row['size'];data=tf.extractfile(m).read();assert len(data)==row['size'] and hashlib.sha256(data).hexdigest()==row['sha256']
manifest={'archive_sha256':sha(archive),'archive_size':archive.stat().st_size,'member_count':len(members),'members':members,'verification':'every regular archive member reopened and hash/size compared; no symlink/traversal/duplicatepath/recursivearchive'}
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2))
(out/'result.json').write_text(json.dumps({'subject':env['subject'],'checks':{k:'PASS' for k in env['completion']['checks']},'unresolved':[]},indent=2))
print(json.dumps({'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'member_count':manifest['member_count'],'outputs':str(out)},indent=2))
