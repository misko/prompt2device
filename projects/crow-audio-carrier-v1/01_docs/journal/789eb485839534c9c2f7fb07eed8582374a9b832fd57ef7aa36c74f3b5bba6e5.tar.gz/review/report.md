# Carrier RJ45 source-owner handback

**MEASURED: fuse adjacency and first-power population are corrected in candidate3. Overall placement remains FAIL; this is a reviewable source proposal, not placement acceptance.**

The final candidate changes only `projects/crow-audio-carrier-v1/03_src/floorplan.yaml`, `03_src/rules/first_article.yaml`, and the explicitly root-authorized assembly population companion `03_src/rules/assembly.yaml`. All 635 frozen inputs verify before and after. Live project and frozen inputs stayed read-only; all new work is in the allocated scratch/output directories. No routing, conductor, checkpoint refresh, signature transfer, public admission, or live integration occurred. No child agents were used.

## Source correction and exact geometry

All eight original F#.2-to-J#.1 power-pad gaps are **8.836020mm** against **4.5mm**. Final gaps are **3.315000mm**, each with **1.185000mm margin**. Native rotation-aware pad bounding boxes and the same integer-unit Euclidean box-gap method as `policy_audit.py` establish these numbers. Full pad, Fab/body, courtyard, clamp and AFE envelopes for all eight cells are retained in `geometry-proof-exact.json`.

North fuses move from [29.15+32k,36.5] top to [32.2+32k,31.4] bottom; south from [51.85+32k,103.5] top to [48.8+32k,108.6] bottom. Source rotations account for KiCad's bottom flip: north180, south0 produce the intended pad2 direction. Every non-fuse footprint's position, side, orientation, pad/net and body geometry is identical to the frozen board, including all jacks, AFEs and exact underside clamps. Factory Wurth/Weidmuller identities, 1/3/7 power, 2/6/8 GND, 5 audio+, 4 audio-, 9/10 shell, shared rail/VMID and CHASSIS/POD_SHIELD separation remain unchanged. P-PINMAP and independent 8/8 spoke checks were rerun.

For an axis-aligned top-side fuse beside the fixed north jack, its closest lateral copper edge is at least0.255mm inside its courtyard, yielding an infimum4.685mm gap from jack pin1. This explains the underside remedy; it is not an exhaustive proof over arbitrary rotated placements. The native generator and independent P-PADSEP validate the actual underside candidate rather than relying on that inference.

First-power installed population is corrected from316/333 to333/333 with exactly **D_BUCK_IN and R_IN1P/N through R_IN8P/N**. No extras/duplicates remain. Independent circuit.json census and stock S-COUNT reconcile board, schematic, manifest and netlist over333 references. All other parsed first-power fields, including every rail/voltage/current limit, are unchanged. No measured first-article record was fabricated; that physical gate remains owed.

The assembly companion states U_ESD1-U_ESD8 and F1-F8 underside population and extends the existing stencil/paste/rotation/THT-tail/rework qualification sentence to those fuses. It grants no purchase or physical approval. Final F# BOT captions clear each fuse bounding box by0.477350mm; native visible mirrored B.Silk refdes are present8/8. These geometric observations do not prove physical soldering/rework access.

## Retained attempts and unchanged gate results

1. Candidate1 moved fuses underside, improving8.836020mm to5.895325mm maximum, but bottom-flip handedness left all8 adjacency failures. Generator passed. The initial copied-generator launch failed before generation because the frozen tool packet lacked fab_tiers.yaml; its raw failure is retained. The same unmodified shared generator was then invoked from its complete live method installation, read-only, with hashes recorded. This setup failure is not improvement credit.
2. Candidate2 corrected source fuse rotations and the assembly companion. All8 gaps became3.315000mm; placement policy5/5 passed. New F# BOT captions were crowded8/8. Full native DRC reported88 violations,499 unconnected,0 parity.
3. Candidate3 moved only those eight captions0.6mm. All8 newly crowded caption warnings disappear; footprint and copper geometry is identical to candidate2. Existing CH1-CH8 crowded caption warnings remain8/8 and native generator silk ownership remains153/338 owned,160 degraded,25 unplaced. No fourth candidate was run.

Final stock checks: generator P-COLLIDE/polarity/body assertions PASS; S-COUNT4/4 pairs over333 refs; spoke8/8; P-PINMAP411 identities over47 multipin refs; placement feasibility7/7 PASS-or-N-A; models333/333; P-PADSEP461080 copper pairs and750048 paste pairs at unchanged0.090mm floor; placement policy5/5 including all353/353 measurable adjacency budgets and415/415 total layout budgets; native rule generation PASS; P-LAND709/988 pads graded,0 unreached,0 failing. Remaining pads are classified in its complete raw report. The native CLI rc0 is process completion, not a clean DRC verdict.

Final **P-DRC FAIL:88/88 violations classified,499/499 unconnected rows retained,0 parity**:

- 64 `hole_clearance`: Wurth J1-J8 shell pads9/10 against same-footprint NPTH,0.0248mm actual vs0.2500mm. Sixteen physical pairs are reported on four copper layers. Owning footprint/source correction is owed; no footprint or threshold changes are in this candidate.
- 16 `silk_edge_clearance`: two jack F.Silk segments per connector cross the fixed edge. Owning footprint/legend correction is owed; exact jack mouth datums remain fixed.
- 8 `starved_thermal`: U_ESD1-U_ESD8 pad4/GND on B.Cu have1 spoke vs required2. All eight nets and unchanged clamp placements were independently verified. Root's proposal is a floorplan pattern matching those eight clamps with `pad_overrides: [{pads: ["4"], on_net: GND, zone_connection: full}]`. This is a distinct source return-intent proposal, **not applied**: authorization arrived after candidate3 executed, and root explicitly required preserving it without a fourth revision. No thermal threshold or waiver is relaxed. A baseline native DRC was not run here, so prior DRC equivalence is not claimed.
- 499 `unconnected_items`: unrouted connectivity, retained individually;0 schematic-parity rows. No route feasibility or finished copper claim follows.

Every raw violation and unconnected item, including repeated layer rows, is stored with its classification. Preliminary isolated-copper allowance remains unchanged and unused. The final suite reaches each finding group directly using stock commands in the disposable source proof; no upstream acceptance is bypassed and no resulting receipt promotes live authority.

## Owed gates and handback

Root must review and integrate the concrete source proposal together with the distinct footprint/ground-return corrections, then archive old guards and perform normal full regeneration. Electrical/readability renewal, fresh independent placement acceptance, connector geometry/service evidence at its proper boundary, routing and post-route copper/thermal verification remain owed. First-article-only/DO-NOT-ORDER and all physical/order qualifications remain unchanged. LAYOUT001 remains closed3/3; this work is no fourth diagnostic or model reset.

The five outputs are report.md, evidence.json, evidence-manifest.json, evidence.tar.gz and exact-subject result.json. The archive holds source_candidate paths, every candidate/source/native result, all methods/raw logs, original source/native beforeimages and per-member hashes. Every regular member is reopened; no symlinks, traversal, duplicate paths or recursive archives are allowed. Final preflight is run after packaging. Runtime process groups ended normally; all scratch and failure evidence is retained, with no live cleanup or deletion.
