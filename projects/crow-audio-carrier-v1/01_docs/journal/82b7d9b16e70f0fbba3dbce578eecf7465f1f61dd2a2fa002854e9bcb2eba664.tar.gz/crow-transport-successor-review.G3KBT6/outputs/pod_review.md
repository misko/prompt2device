subject_release: crow-mic-pod-v3 v0.2.1-2026-09-16
source_commit: 2f16225630637955b43f3446419cad2f8797e17b
exact_board_sha256: 2685281fdb8dac636e16334c2d4eca679300bfa5322a368ac2685b59f48e3dd1
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
sourcing_verdict: BLOCKED-SOURCING
qualification: FIRST-ARTICLE-ONLY
review_scope: docs-only transport successor of v0.2.0-2026-09-15
packet_integrity: PASS
payload_identity: PASS-WITH-REVIEW-REBIND
transport_evidence: PASS
hidden_file_census: PASS

# Independent docs-only release review

## Changed-file census

- Final candidate tree: 297 regular files, 0 symlinks/special files, 0 hidden files.
- Final prior-to-candidate byte comparison: exactly 6 changed files: `MANIFEST.txt`, `ORDER_README.md`, `verification/pin_review.md`, `verification/render_review.md`, `verification/redteam_topology.md`, and `verification/redteam_layout.md`. The other 291 files are byte-identical.
- Immutable engineering payload: `fab/` 17/17 files identical, `source/` 178/178 identical, `3d/` 1/1 identical, and PDF 3/3 identical. Verification retains 92/96 byte-identical files; the other four are fresh canonical review rebindings only.
- Final payload census remains 296 listed files plus the self-describing `MANIFEST.txt`; no listed file is absent and no other file is unlisted. Five payload digests change: `ORDER_README.md` and the four canonical verification reports. `MANIFEST.txt` changes separately to record the successor identity, source commit, predecessor, and final payload digests.
- The four verification changes introduce no board, schematic, source, fabrication, 3D, render, PDF, BOM, CPL, receipt, measurement, or manufacturing change. They re-express the same lens-specific SOUND judgments against the exact unchanged board while binding the transport-safe source commit.

## Inherited exact review evidence

The four v0.2.0 exact-board reports were independently verified before rebinding and all bind board SHA-256 `2685281fdb8dac636e16334c2d4eca679300bfa5322a368ac2685b59f48e3dd1`:

- pin: `verification/pin_review.md`, SHA-256 `3338906db41085f256c07eddad0eb93b65623440b71ade3bdea8be194612df99`, design SOUND, order DO-NOT-ORDER.
- render: `verification/render_review.md`, SHA-256 `a9712c2f08fc39c7380417c47691888c4223ac8941d70d7da8d3b40b1ac5bf9a`, design SOUND, order DO-NOT-ORDER.
- topology: `verification/redteam_topology.md`, SHA-256 `037a19f564010e26b3eb575759bc113024d6fb67a806f16d5d44b387e72a6e1b`, design SOUND, order DO-NOT-ORDER.
- layout: `verification/redteam_layout.md`, SHA-256 `0ffc5a4349fc60632e1d203168ce2facbb2c7628cc385d051000a8f12c3577b2`, design SOUND, order DO-NOT-ORDER.

Their original v0.2.0 subject and `3fe3beb3fb221d73ea825644cdd5f2f5506dc6a2` source provenance cannot serve as canonical ancestry on the clean transport line. Four fresh lens-specific fix-pass reports therefore replace them. The replacements explicitly record each inherited report hash and unchanged scope, bind subject `crow-mic-pod-v3/v0.2.1-2026-09-16` and source commit `2f16225630637955b43f3446419cad2f8797e17b`, preserve the exact board hash, return SOUND / DO-NOT-ORDER, and retain every first-article and order hold.

Fresh canonical report SHA-256 values:

- pin: `ae8d81b2ee23cd612cb3c28bd3d62a6ca12dfab5bb56ec4faf2f2b5c8d87c9dc`.
- render: `c559de15eabd28350edd62fe19d214636ac5726922ca3f529fb6fbef480ffbce`.
- topology: `48daf1b6f115ab19f217e3839d00f3f29dac64cb4fd255543e2c6df30fa0c184`.
- layout: `9a4ba69b84c5cf2dee02ff34ad043eefec29db0bfe3bdd4f4bf6a54432e1f127`.

## Source and transport binding

- The candidate MANIFEST binds `git_sha` to `2f16225630637955b43f3446419cad2f8797e17b`; the checked-out HEAD is the same commit.
- The frozen `source-commit.txt` is byte-for-byte the output of `git show --stat --oneline` for that commit.
- Live remote inspection matches `remote-refs.txt`: `refs/heads/codex/crow-transport-stage-lfs-20260916` is `2f16225630637955b43f3446419cad2f8797e17b`; `refs/heads/main` is `2b32184a9e1d343a0b13b459d101ef04c7f902bf`.
- The RED evidence demonstrates that the pre-fix transport checker let both an oversized blob and an over-aggregate outgoing population escape. The GREEN evidence demonstrates both known-bad cases are rejected. A fresh run independently reproduced 4 passed, 0 failed, including 2 known-bad fixtures caught as required.
- The transport statement refers to repository-level retention of oversized durable evidence through Git LFS. It does not alter the pod's engineering, manufacturing, sourcing, or order conclusions.

## Holds retained

- FIRST-ARTICLE-ONLY and DO-NOT-ORDER remain explicit.
- Authenticated exact-BOM JLCPCB assembly allocation, pricing/economics, fees, and capability remain incomplete. Public catalog stock is advisory and does not authorize ordering.
- Supplier uploader BOM/code resolution, substitutions, all 31 top-side rotations, and fabrication/process interpretation remain order-interface gates.
- J1 and MK1 remain manual assembly items; J1 contact/shield integrity, cable continuity/isolation, plug/boot/latch/service fit, MK1 polarity/strain relief, and U2 exposed-pad soldering require physical inspection.
- Rail/noise/gain/clipping, 4 m and 15 m cable behavior, thermal, EMC/ESD, capsule mounting, condensation, drainage, enclosure fit, and rooftop environmental behavior remain first-article obligations.

## Findings

- No engineering, fabrication, source, 3D, render, PDF, BOM, CPL, receipt, or measurement byte changed. The four changed verification reports are fresh review rebinding only; no engineering or order claim was strengthened.
- No hidden or unlisted candidate payload was found. The current worktree has only the two expected successor directories as untracked content, no unrelated untracked files, and no ignored files within either prior or candidate release tree.
- The inherited documentation-only deficiency remains: the D1 invariant rationale still names 1N4007 instead of S1M, while the executable identity and actual S1M selection are correct. This remains deferred and grants no order authority.
- Non-blocking documentation observation: the first heading in `ORDER_README.md` still says `v0.2.0`. The appended transport-successor section and MANIFEST identify v0.2.1 unambiguously, and the stale heading grants no additional engineering or order authority.
- Verdict: SOUND for the preserved exact engineering design and docs-only transport succession. Ordering remains prohibited.
