from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,io,shutil
from datetime import datetime,timezone
s=Path(__file__).parent;r=s.parents[3];o=s.parent/'outputs';p=r/'project';env=json.loads((s.parent/'envelope.json').read_text())
H=lambda b:hashlib.sha256(b).hexdigest()
verified=[]
for x in env['input_packet']:
 f=r/x['path'];assert f.is_file() and not f.is_symlink();assert f.stat().st_size==x['size'] and H(f.read_bytes())==x['sha256'];verified.append(x['path'])
(s/'inputs-after.json').write_text(json.dumps({'verified':len(verified),'paths':verified,'at':datetime.now(timezone.utc).isoformat()},indent=2))
sub=json.loads((s/'subjects.json').read_text())['current'];pix=json.loads((s/'pixel-equivalence.json').read_text());graphs=json.loads((s/'graph-and-circuit.json').read_text());fm=json.loads((s/'final-measurements.json').read_text())
report='''review_stage: pre-route
review_kind: schematic_render
reviewer_identity: Codex /root/carrier_rj45_native_carrier_readability_fabfeatures1
context: FRESH
date: 2026-09-13
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
'''+''.join(f'{k}: {v}\n' for k,v in sub.items())+'''
Fresh exact-subject readability review is complete. No actionable schematic readability defect was found.

MEASURED: 748/748 frozen inputs verified before and after; canonical envelope b235d22f0e6e291e5216741908b2e84b20a84c904910d59c1b0a92e3a7353547 verified. All seven current subject hashes were independently recomputed with the frozen owning algorithm, including 89 part dossiers. Schematic checkpoint files verify 7/7 and prelayout checkpoint files 11/11; these checks bind the supplied subjects and do not grant prelayout acceptance.

Independent Poppler/Pillow comparison proves 19/19 current PDF drawing bodies are RGB-byte-identical to the immediately accepted orientation1 delivered PDF at 120 dpi, excluding only y<100 pixels. All full-page pixel differences are confined to y=83..97 inclusive in the generated identity caption. Body coverage is 26,117,900 pixels per subject, with zero changed drawing bodies. Current/accepted per-page body hashes and full difference bounding boxes are archived.

I opened and visually inspected all 19 current page images, including every current header and integrated input/protection, buck, held LDO, supervision/dump, eight analog channels, ADC, VMID/reference, clock/TDM and reset page. Every header has the current CircuitJSON prefix a3fdcd5dbad16cbb, correct page index and component count; counts sum to333. All333 references also occur in extracted PDF text, used only as a supplemental census. The ten RJ45 contact labels on each of eight symbols are distinguishable, as are green wires/junctions, power and shield labels, capacitor/diode polarity, filter shunts and NC stubs. All80 pin/net assertions confirm power1/3/7, return2/6/8, audio+5, audio-4 and shell9/10. CHASSIS contains16 shell contacts and remains distinct fromGND.

Independent complete native S-expression parsing finds333 current and333 accepted components,985 pin/net rows and221 nets including42 NC nets. Components, values/footprints, pin mappings and nets have zero additions, removals or changed rows. The entire native schematic is identical after UUID-string substitution only. Independent CircuitJSON trace unioning agrees with943/943 connected native ports, with42/42 intentional unconnected ports separately checked; the only net-name transform is the explicit authored N() prefix for digit-leading names. Manifest, CircuitJSON, native graph and fully-populated-first-power card agree on333 references. Maintained E-INV freshly passes205/205.

Source delta:314 supplied files have accepted counterparts; eight differ, comprising four source/dossier files and four regenerated artifacts. Of310 common source/dossier files,306 are byte-identical. All four source changes were inspected: part.yaml adds comments only (parsed YAML remains identical), two provenance documents append nominal spring-finger derivation and limitations, and the footprint adds18 F.Fab paths. Electrical TSX, presentation TSX, route/rules, floorplan, physical models, pad/drill/copper geometry, courtyard and transforms are unchanged. No voltage/current limit increases. Full nominal extent is not manufacturing tolerance or physical-fit evidence. The accepted source-adoption receipt supports only that limited Fab source claim.

CircuitJSON electrical, schematic, PCB and CAD record groups are exactly equal. Actual generated deltas are source filesystem metadata and supplier diagnostics: part-not-found warnings46 current versus55 accepted, footprint-mismatch warnings152 versus145. Export UUID/metadata and PDF identity captions changed. Current-only documents, manifest and generated checkpoint/gate files in the packet lack accepted counterparts; this packet-membership difference is not evidence of a component addition.

Frozen ERC has0 errors and2637 classified warnings:569 lib_symbol_issues and2068 endpoint_off_grid. Four ignored classes remain explicitly preserved: singleton global labels, four-way connections, SPICE issues and footprint-filter mismatch. Zero errors is not all-severity clean. No unrelated checker battery was repeated. Accepted orientation1 readability report SHA00de3c7853a8e6a1dd65bc11bc91e05c3c3474de56da789269cc971534fb0f11 supplies unchanged historical visual provenance and names no unresolved readability finding; the fresh pixel measurement and actual current image inspection are the basis of this verdict, not a restamp.

Boundaries: carrier SOURCE PASS and authentic FULL INCOMPLETE with23 physical obligations were reopened. Pod9 obligations remain commission context; no pod population or schematic is graded by this carrier-only lens. Preserve factoryCat6A custom analog/power RJ45, NOT Ethernet/PoE, power-off mating, carrierCHASSIS/podPOD_SHIELD isolated fromGND, FIRST-ARTICLE-ONLY / DO-NOT-ORDER. Public catalog design-only admission and blank operator response are not allocated stock or an order. No additional physical-measurement prerequisite is imposed before prototype fabrication. LAYOUT001 closed3/3 remains unchanged commission context. This verdict grants no placement, routing, human orientation, physical, release or ordering acceptance.

Limitations: equality is measured at120dpi alongside actual image inspection; arbitrary print-size/resolution equivalence is not claimed. A bootstrap scratch filename shadowed Python inspect and caused an import failure before bounded execution; the exploratory output is excluded as acceptance evidence, the diagnostic is retained, and all accepted subject measurements were rerun through the shared bounded runtime. Optional PyMuPDF was unavailable; Poppler performed both successful full renders. Methods and raw bounded engineering logs/runtime receipts, all38 rendered pages and independent graph/equivalence evidence are archived. Packaging and provided preflight records remain alongside the scratch runtime files to avoid self-reference. Delivery completeness is distinct from engineering acceptance.
'''
(o/'report.md').write_text(report)
e={'schema':1,'verdict':'SOUND','design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','subject':env['subject'],'exact_subject_hashes':sub,'canonical_envelope_sha256':'b235d22f0e6e291e5216741908b2e84b20a84c904910d59c1b0a92e3a7353547','context':'FRESH','methods':['frozen input verification before/after','frozen owning seven-hash calculation','independent Poppler 120dpi rendering of both exact PDFs','independent Pillow all-page body equality/full diff bounds','actual view_image inspection of all19 current pages','independent native S-expression component/net/pin census','CircuitJSON trace union vs native netlist','fresh maintained E-INV','source/dossier full common-file delta inspection'],'counts':{'frozen_inputs_before':748,'frozen_inputs_after':748,'parts':89,'pdf_current_pages':19,'pdf_accepted_pages':19,'page_bodies_equal':19,'actual_current_pages_inspected':19,'body_pixels_per_subject':26117900,'components':333,'nets':221,'pin_rows':985,'connected_source_ports':943,'intentional_nc_ports':42,'rj45_pins_asserted':80,'first_power_population':333,'electrical_invariants_pass':205,'electrical_invariants_total':205,'erc_errors':0,'erc_warnings':2637,'carrier_physical_obligations':23},'findings':[],'limitations':['120dpi measured pixel equality; visual review covers delivered current pages','Carrier lens only; pod schematic/population not graded','Prototype physical obligations remain; no orientation, routing, release or order acceptance','Bootstrap tool import diagnostic retained; accepted measurements subsequently executed through bounded runtime'],'accepted_visual_provenance':{'report_sha256':'00de3c7853a8e6a1dd65bc11bc91e05c3c3474de56da789269cc971534fb0f11','pdf_sha256':'66348208a8d947d7171a5b01cec3988510aa7a04605b5d5dc9a368041baec2b5','no_unresolved_readability_findings':True},'evidence_files':{'pixel_equivalence':'scratch/pixel-equivalence.json','visual_observations':'scratch/visual-observations.md','native_graph':'scratch/graph-and-circuit.json','source_native':'scratch/source-native-parity.json','delta':'scratch/source-delta.diff','electrical_invariants':'scratch/electrical-invariants.log','input_verification':'scratch/inputs-after.json'}}
(o/'evidence.json').write_text(json.dumps(e,indent=2)+'\n');(o/'result.json').write_text(json.dumps({'subject':env['subject'],'checks':{k:'PASS' for k in env['completion']['checks']},'unresolved':[]},indent=2)+'\n')
members={}
for f in sorted(s.iterdir()):
 if f.is_file() and not f.name.startswith(('package-review.','preflight.')):members['scratch/'+f.name]=f
for k in ['TASK.md','expected-subject.json','preflight.py','context/skills/kicad-pcb/scripts/pre_route_review_check.py','accepted-receipts/readability/report.md','accepted-receipts/readability/delivery-attempt.json','accepted-receipts/readability/evidence-manifest.json','decision-context/jack-fab-source-adoption.json','decision-context/rj45-jack-fab-source-review-closeout-summary.json']:members['frozen/'+k]=r/k
for q in ['project','accepted-subject']:
 for k in ['03_tscircuit/build/schematic.pdf','03_tscircuit/build/circuit.json','04_kicad/crow_audio_carrier_v1.kicad_sch','06_build/netlists/crow_audio_carrier_v1.net','02_parts/615008160221/part.yaml','02_parts/615008160221/primary-source-record.md','03_src/lib/crow_audio_carrier.pretty/Wurth_615008160221_RJ45.kicad_mod','03_tscircuit/src/crow_audio_carrier_v1.tsx','03_tscircuit/src/schematic_presentation.tsx']:members['frozen/'+q+'/'+k]=r/q/k
members['frozen/envelope.json']=s.parent/'envelope.json'
for k in ['pipeline_runtime.py','pipeline_execution.py']:
 members['runtime-source/'+k]=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')/k
members['method-source/electrical_invariants.py']=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/kicad-pcb/scripts/electrical_invariants.py')
for k in ['report.md','evidence.json','result.json']:members['witness/'+k]=o/k
tarpath=o/'evidence.tar.gz'
with tarfile.open(tarpath,'w:gz') as tar:
 for name,f in sorted(members.items()):
  assert f.is_file() and not f.is_symlink();data=f.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
rows=[];seen=set()
with tarfile.open(tarpath,'r:gz') as tar:
 for m in tar.getmembers():
  assert m.isfile() and not m.issym() and not m.islnk();assert not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts and m.name not in seen and not m.name.endswith('.tar.gz');seen.add(m.name)
  data=tar.extractfile(m).read();assert len(data)==m.size and data==members[m.name].read_bytes();rows.append({'path':m.name,'size':len(data),'sha256':H(data)})
manifest={'archive_sha256':H(tarpath.read_bytes()),'archive_size':tarpath.stat().st_size,'member_count':len(rows),'members':rows,'independently_reopened_regular_members':len(rows)}
(o/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k!='members'},indent=2));print('Five outputs:',sorted(f.name for f in o.iterdir()))
