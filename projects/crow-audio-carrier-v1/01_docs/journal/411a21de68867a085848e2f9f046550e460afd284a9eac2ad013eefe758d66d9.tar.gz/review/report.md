# Repaired assembly-side source review: SOUND

This verdict binds the seven exact before/candidate source pairs listed in `candidate/source-identity.json`. Subject raw SHA-256: `4718d23ef3f1931ef75ea23b0325680c0dfc39e6056ea1620cd23a23fcc2f133`. Subject semantic SHA-256: `6f56c5620903bdbe8298cb6d142ba720aee35b8f86dbb760c1fbb23c21e805b3`. Candidate `skills/jlcpcb-fab/scripts/assembly_coverage.py` SHA-256: `44b2e11314b9abdbe0693bf6d167e4f85d7906c96240df7c2a675a593a22a0e0`.

No unresolved concrete defect was established in this exact assembly-side change. This is source-review acceptance, not acceptance of either physical board, placement, routing, release or order.

## Original finding F1 is repaired

The original independent review found an exit-zero false pass when a manually fitted bottom-side J9 acquired an additional contradictory DNP declaration. Any DNP row could erase the fitted reference and falsely report a zero denominator. That original DEFECTIVE report and its archive identity are retained; the stopped same-reviewer/FRESH misdispatch contributed no acceptance or repaired-candidate testing.

MEASURED again using the original independent constructor: J9 has two numbered B.Cu SMD lands, no `attr smd`, and no CPL row. With top-only policy, the manual-fit control exits **1**, reports `SMD-SIDE-NOT-ALLOWED`, and grades **1** fitted SMD. Both **DNP then manual** and **manual then DNP** now exit **1**, report `ASSEMBLY-POPULATION-DUPLICATE` plus the side violation, and retain **1** fitted SMD with native histogram `bottom: 1`. All other fixture bytes remain fixed across these row-order cases. Exact per-call inputs, commands, output JSON, raw logs and runtime records are under `scratch/hostile/` in the archive.

The repair scans every `not_assembled` reference for repetition, rejects duplicates, and subtracts those ambiguous references from the nonpopulation exemption. Order no longer controls acceptance or the denominator. Existing population findings still reject simultaneous consigned/not-assembled declarations and DNP references that remain on the CPL.

## Measured review coverage

All **67/67** envelope inputs passed byte-size/SHA-256 verification before and after review. All **7/7** before/candidate identities matched; the scratch candidate remained byte-identical. The complete checker source and complete seven-file diff were reviewed, with the supplied prior report used explicitly for unchanged-source context. The assembly procedure, template, A-POS policy and governing rules contract agree on the new behavior. This does not claim a fresh line-by-line re-audit of unrelated unchanged policy and historical test prose.

The eight authored public-CLI regression tests passed **8/8**, including **5** known-bad families; **41** older tests were unselected. The driver preserves the candidate test and checker bytes and assertions, replacing only the subprocess capture seam with shared `pipeline_runtime.run_stage` and adding Python `-B`. It captured **24/24** expected checker outcomes: **16** rejected, **8** accepted. Each call retains the raw merged stdout/stderr stream, command, explicit environment/cwd, runtime receipt and fixture/output bytes.

All **6/6** original independent cases now meet the intended contract: the manual-bottom control, both conflict orders, exempt-prefix bottom SMD and DNP still on CPL reject; absent legacy policy remains explicitly ungraded. The latter exits zero for population coverage while reporting `UNDECLARED_OR_INVALID`, side-graded denominator **0**, and an observed native bottom census of **1**. It cannot establish a top-only assembly claim.

Four additional hostile public-CLI cases passed **4/4**:

- Repeating J9 twice inside one DNP `refs` list rejects, grades **1** SMD, and reports both duplicate and side violations.
- Two identical DNP rows likewise reject and retain **1** SMD; repetition need not use different reason strings to be detected.
- A mixed board with one top CPL-mounted R1 and one conflicting bottom J9 rejects, grades **2** SMD with `top: 1, bottom: 1`, and independently grades **1** correct CPL side.
- A bottom native J9 whose CPL claims top rejects solely for `CPL-SIDE-MISMATCH` even with legacy side policy absent. CPL denominator is **1**; allowed-side grading stays explicitly absent.

The implementation counts actual **numbered SMD copper** regardless of footprint SMD attributes. Bare unnumbered fiducials remain outside fitted SMD coverage. Manual/mechanical SMD lands remain covered; explicit DNP/test-point nonpopulation off CPL is excluded. Native mounting layer and CPL side are checked independently. Through-hole process qualification remains separate and unchanged. Existing summary keys are preserved, with new population histogram and graded-denominator fields added.

## Inherited evidence and remaining project obligations

INHERITED and reopened: root's corrected full assembly suite reports **49 passed / 0 failed**, including **25** known-bad tests. The older fleet fixtures were not independently rerun here. Root's actual original RED contains four known-bad families whose checker calls wrongly exited zero, plus two clean tests failing on absent summary fields. The original `0 passed, 0 failed, 47 skipped` diagnostic is **not** RED evidence. Root's later duplicate regression is genuinely RED against the first side-check candidate: its public checker exited zero and falsely graded zero fitted SMD. Historical RED does not cover every later-added test variant; the independently rerun current coverage is enumerated above.

INHERITED supporting checks: skill authority PASS; documentation **15/15**; disclosure **14/14**, retaining its **2** declared blind spots. The supplied contracts suite is **16 passed / 1 failed**, with the untracked-files ratchet breached. This review does not waive that failure or certify an after-staging rerun; root still owes its final repository audit outside this exact source-review verdict.

INHERITED native gap: carrier **306 SMD = 290 top + 16 bottom**; pod **31 = 30 top + 1 bottom**. These observations establish why the existing layouts violate the top-only requirement. They do not establish that a corrected layout exists or has been accepted.

## Scope and delivery

The reviewer used the PCB design/JLC fabrication skills and bounded runtime, wrote only allocated scratch/output files, and spawned no child agents. No candidate/live source mutation, geometry edits, source adoption, commits, seal or order occurred. One runtime console-parameter diagnostic occurred before any subprocess launch; it is retained in `scratch/setup-diagnostic.json` and earned no engineering result. Authorized shared-runtime sources are archived and hash-recorded after execution; no hermetic or pre-execution runtime-pinning claim is made.

No physical component, body clearance, paste access or solderability claim follows from this offline check. A consistently declared DNP cannot be physically verified here. Missing legacy side policy remains ungraded. Delivery checks certify a completed honest review; they do not promote a board or release.

The archive contains exact source pairs, complete diff, methods, authored and independent fixtures, all test logs and runtime records, and the supplied root evidence. The original prior archive is referenced by its input-packet identity rather than recursively embedded. Packaging reopens every regular member and checks path safety, uniqueness, size and SHA-256. Final delivery is validated by packet `preflight.py` against the exact allocated envelope.
