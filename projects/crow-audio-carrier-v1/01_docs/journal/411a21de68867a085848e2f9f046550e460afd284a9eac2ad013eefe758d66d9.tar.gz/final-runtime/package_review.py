from pathlib import Path,PurePosixPath
import json,hashlib,tarfile
S=Path(__file__).parent; R=S.parent; P=R.parents[2]; O=R/'outputs'
env=json.loads((R/'envelope.json').read_text())
def digest(b): return hashlib.sha256(b).hexdigest()
rows=[]
for i in env['input_packet']:
    b=(P/i['path']).read_bytes()
    assert len(b)==i['size'] and digest(b)==i['sha256'],i['path']
    rows.append({'path':i['path'],'size':len(b),'sha256':digest(b)})
(S/'inputs-after.json').write_text(json.dumps(rows,indent=2)+'\n')
ids=json.loads((P/'candidate/source-identity.json').read_text())
for i in ids:
    assert digest((S/'repo'/i['path']).read_bytes())==i['after_sha256']
    assert digest((S/'before'/i['path']).read_bytes())==i['before_sha256']
evidence={
    'subject':env['subject'],'verdict':'SOUND','scope':'Seven exact source pairs from candidate/source-identity.json; source review only, no board or release acceptance',
    'source_identity':ids,
    'methods':['Full checker and complete seven-file diff review; unchanged context inherited explicitly from original completed review','Frozen input verification before and after','Eight original authored tests executed with byte-identical candidate source and capture-only run seam','Six original independent CLI cases reexecuted and asserted','Four additional hostile public CLI cases independently constructed and asserted','Shared finite direct-argv pipeline_runtime.run_stage, explicit cwd/environment, retained merged stdout/stderr and runtime receipts','Root historical raw evidence reopened and explicitly inherited','Archive every regular member reopened and validated; final exact-envelope preflight'],
    'findings':[],
    'resolved_findings':[{'id':'prior-F1','status':'CLOSED','reason':'Both original contradictory DNP/manual row orders now exit 1 and retain J9 in fitted denominator 1. Duplicate rows are rejected and excluded from nonpopulation exemptions.','evidence':['scratch/hostile/conflict_dnp_then_manual/coverage.json','scratch/hostile/conflict_manual_then_dnp/coverage.json']}],
    'measured_counts':{'input_packet_verified_before':67,'input_packet_verified_after':67,'exact_source_pairs':7,'authored_tests_passed':8,'authored_tests_failed':0,'authored_known_bad_families':5,'older_tests_unselected':41,'authored_cli_calls':24,'authored_cli_rejected':16,'authored_cli_accepted':8,'original_independent_cases_passed':6,'additional_independent_cases_passed':4,'total_independent_cases':10,'independent_cli_rejected':9,'independent_cli_accepted_legacy_ungraded':1},
    'inherited':{'full_assembly_suite':{'passed':49,'failed':0,'known_bad':25,'source':'scratch/root-evidence/assembly-sides-repaired-full.log'},'supporting_checks':{'authority':'PASS','documentation_passed':15,'disclosure_passed':14,'disclosure_declared_blind_spots':2,'contracts_passed':16,'contracts_failed':1},'native_gap':{'carrier':{'smd':306,'top':290,'bottom':16},'pod':{'smd':31,'top':30,'bottom':1}},'prior_review':'Original DEFECTIVE preserved; stopped same-reviewer FRESH misdispatch supplies no acceptance'},
    'limitations':['No physical component/clearance/paste/solderability or board acceptance','Consistently declared DNP cannot be physically verified offline','Missing legacy sides explicitly ungraded','Root final repository contract audit remains owed outside exact source review','Older 41 fleet-dependent tests inherited, not rerun','Shared runtime source dependencies hash-recorded after tests; no hermetic execution claim'],
    'delivery_unresolved':[]}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(O/'result.json').write_text(json.dumps({'subject':env['subject'],'checks':{c:'PASS' for c in env['completion']['checks']},'unresolved':[]},indent=2)+'\n')
files=[(f,'scratch/'+f.relative_to(S).as_posix()) for f in sorted(S.rglob('*')) if f.is_file()]
files += [(O/name,'delivery/'+name) for name in ['report.md','evidence.json','result.json']]
members=[]
for f,name in files:
    assert not f.is_symlink() and not name.endswith(('.tar','.tar.gz','.tgz'))
    b=f.read_bytes();members.append({'path':name,'size':len(b),'sha256':digest(b)})
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
    for f,name in files: t.add(f,arcname=name,recursive=False)
observed=[];seen=set()
with tarfile.open(archive,'r:gz') as t:
    for m in t:
        pp=PurePosixPath(m.name)
        assert m.isfile() and not pp.is_absolute() and '..' not in pp.parts and m.name not in seen
        seen.add(m.name);b=t.extractfile(m).read();observed.append({'path':m.name,'size':len(b),'sha256':digest(b)})
assert observed==members
b=archive.read_bytes()
manifest={'archive_sha256':digest(b),'archive_size':len(b),'member_count':len(members),'members':members}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'member_count':manifest['member_count'],'inputs_verified':len(rows),'verdict':'SOUND'}))
