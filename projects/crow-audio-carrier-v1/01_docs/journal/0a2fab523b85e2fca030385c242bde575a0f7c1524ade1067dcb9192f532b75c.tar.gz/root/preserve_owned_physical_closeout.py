from pathlib import Path
import sys, json, hashlib, tarfile, io, shutil
sys.dont_write_bytecode = True
R = Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
P = R / 'projects/crow-audio-carrier-v1'
D = Path(__file__).parent
I = Path('/tmp/carrier-connector-integration-20260911')
sys.path.insert(0, str(R / 'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope, verify_input_packet
files = {}
for prefix in ['owned-physical-handoff', 'owned-physical-validate',
               'owned-physical-contracts', 'owned-physical-present-contracts',
               'owned-pin-render-handoff', 'owned-pin-render-validate',
               'owned-pin-render-contracts', 'owned-pin-render-preserve']:
    for source in I.glob(prefix + '*'):
        if source.is_file():
            files['validation/' + source.name] = source
meta = json.loads((D / 'owned-layout-availability-opened.json').read_text())[0]
root = Path(meta['project'])
envelope = TaskEnvelope.from_json(Path(meta['envelope']).read_text())
assert json.loads(Path(meta['attempt']).read_text())['status'] == 'PASS'
assert verify_input_packet(envelope, root)[0]
for source in root.rglob('*'):
    if source.is_file():
        assert not source.is_symlink()
        files['fresh-layout-availability/' + source.relative_to(root).as_posix()] = source
for source in [Path(__file__), D / 'open_owned_layout_availability.py',
               D / 'owned-layout-availability-opened.json',
               D / 'owned-pin-render-preservation-result.json',
               P / '06_build/agent_handoff.yaml', P / '01_docs/STATUS.md']:
    files['root/' + source.name] = source
sha = lambda b: hashlib.sha256(b).hexdigest()
manifest = {n: {'size': p.stat().st_size, 'sha256': sha(p.read_bytes())}
            for n, p in sorted(files.items())}
temporary = D / 'owned-physical-closeout.tar.gz'
assert not temporary.exists()
with tarfile.open(temporary, 'w:gz', compresslevel=6) as archive:
    for name, source in sorted(files.items()):
        archive.add(source, arcname=name, recursive=False)
    raw = (json.dumps({'members': manifest}, indent=2) + '\n').encode()
    item = tarfile.TarInfo('MANIFEST.json')
    item.size = len(raw)
    archive.addfile(item, io.BytesIO(raw))
digest = sha(temporary.read_bytes())
destination = P / '01_docs/journal' / (digest + '.tar.gz')
assert not destination.exists()
shutil.copyfile(temporary, destination)
assert sha(destination.read_bytes()) == digest
with tarfile.open(destination) as archive:
    assert set(archive.getnames()) == set(manifest) | {'MANIFEST.json'}
    assert len(archive.getnames()) == len(set(archive.getnames()))
    for name, item in manifest.items():
        raw = archive.extractfile(name).read()
        assert len(raw) == item['size'] and sha(raw) == item['sha256']
result = {'archive': str(destination), 'sha256': digest,
          'size': destination.stat().st_size, 'payload_members': len(manifest),
          'scope': 'Accepted current pin/render owning checks, validated handoff, honest shared versus project contract-audit coverage and fresh closed layout reviewer availability.'}
(D / 'owned-physical-closeout-result.json').write_text(json.dumps(result, indent=2) + '\n')
with (P / '01_docs/journal/contracts.md').open('a') as out:
    out.write('\n## Allowed current physical-review acceptance closeout\n\n| Pattern | What |\n|---|---|\n| `' + destination.name + '` | Exact current physical-review handoff/validation and project contract audits, complete fresh layout reviewer availability and closure; reopen every manifest member |\n')
print(json.dumps(result, indent=2))
