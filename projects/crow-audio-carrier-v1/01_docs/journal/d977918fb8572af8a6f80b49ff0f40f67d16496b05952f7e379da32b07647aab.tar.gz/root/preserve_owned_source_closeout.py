from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,tarfile,io,shutil
D=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911');P=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1');sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((I/'silk-owned-source-full-runtime.json').read_text());assert r['status']=='PASS' and r['returncode']==0
assert 'Ran 337 tests' in (I/'silk-owned-source-full.log').read_text()
files={}
for prefix in ['silk-owned-source-full','silk-owned-source-handoff']:
 for f in I.glob(prefix+'*'):
  if f.is_file():files['validation/'+f.name]=f
for n in ['owned-source-adoption.json','owned-source-preservation.json','preserve_owned_source_closeout.py']:files['root/'+n]=D/n
files['handoff.yaml']=P/'06_build/agent_handoff.yaml'
members={n:{'size':f.stat().st_size,'sha256':sha(f.read_bytes())} for n,f in files.items()};tmp=D/'owned-source-closeout.tar.gz'
with tarfile.open(tmp,'w:gz',compresslevel=3) as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 b=(json.dumps({'members':members},indent=2)+'\n').encode();m=tarfile.TarInfo('MANIFEST.json');m.size=len(b);t.addfile(m,io.BytesIO(b))
h=sha(tmp.read_bytes());dst=P/'01_docs/journal'/(h+'.tar.gz');assert not dst.exists();shutil.copyfile(tmp,dst)
with tarfile.open(dst) as t:
 assert len(t.getnames())==len(set(t.getnames())) and set(t.getnames())==set(members)|{'MANIFEST.json'}
 assert all(x.isfile() and not Path(x.name).is_absolute() and '..' not in Path(x.name).parts for x in t.getmembers())
 for n,m in members.items():b=t.extractfile(n).read();assert len(b)==m['size'] and sha(b)==m['sha256']
with (P/'01_docs/journal/contracts.md').open('a') as f:f.write(f'\n## Allowed owned-label source acceptance closeout\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Full337 source-suite raw output and runtime, exact source-adoption receipt, compact validated handoff and producer script; all {len(members)} members reopened. No native or routing acceptance |\n')
now=datetime.now(timezone.utc).isoformat()
with (P/'01_docs/journal/schematic.md').open('a') as f:f.write(f"\n- Source acceptance closeout {now}: full337/337 project tests PASS in{r['elapsed_s']:.3f}s. Exact adoption receipt/full raw logs and compact validated handoff archived {h}, {dst.stat().st_size}bytes/{len(members)}members, all reopened. Next source/evidence commit and exact archived guard retirement, then fresh exclusive normal canonical renewal; no checkpoint rewrite.\n")
result={'archive':str(dst),'sha256':h,'size':dst.stat().st_size,'members':len(members),'source_tests':337,'elapsed_s':r['elapsed_s']};(D/'owned-source-closeout.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
