review_stage: pre-route
review_kind: pin
reviewer: rj45-pin-carrier-supply-toponly1 fresh independent agent
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 92a4e2fc0fecde845f2dfa0d9e2f5bfbd943372962fb449d699a98d957fc5633
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: 7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c

# Fresh independent pin review — carrier-supply

Limited coverage: only commissioned refs `U_AUDIO`, `U_BUCK`, and `U_PWR` were reviewed. This is not whole-board acceptance. `DO-NOT-ORDER` is retained exactly as commissioned metadata despite the SOUND verdict for this limited domain.

## U_AUDIO — TPS389001DSER

VERDICT: PASS

Measured native identity count: 6 numbered physical identities, 6 native pads, 6 distinct copper lands, 0 exposed-pad identities, 0 aliases/fusions.

Primary document: SHA-256 `ee79599730e7606ba9718d9820b411020e3dcd9ff7d44572f8ee63fead15b9d0`; PDF page 3, “DSE Package, 6-Pin WSON, Top View” and Pin Functions; PDF pages 24–25, package outline DSE0006A drawing 4220552/B and Example Board Layout.

- U_AUDIO pin 1 (SENSE): expected top-left identity on the three-pad left side and a monitored analog-voltage net vs observed W/top at `(-0.55,-0.50)` on `ADC_SENSE`; matches.
- U_AUDIO pin 2 (GND): expected left-middle identity on ground vs observed W/middle on `GND`; matches.
- U_AUDIO pin 3 (MR_N): expected bottom-left active-low manual-reset input on a logic/control net vs observed W/bottom on `PWR_EN`; matches.
- U_AUDIO pin 4 (VDD): expected bottom-right supply input on a supply rail vs observed E/bottom on `5V_LDO_HOLD`; matches.
- U_AUDIO pin 5 (CT): expected right-middle timing-capacitor node vs observed E/middle on `AUDIO_CT`; matches.
- U_AUDIO pin 6 (RESET_N): expected top-right open-drain reset output on a controlled-enable net vs observed E/top on `AUDIO_EN`; matches.
- Package/winding: manufacturer figure is explicitly TOP VIEW, with 1→2→3 down the left and 4→5→6 up the right, hence CCW. The front-mounted component-top table has the same winding and pin-1 corner without reflection.
- EP: the DSE0006A outline and land-pattern figures show six perimeter terminals and no exposed pad; the dossier likewise has no EP.

## U_BUCK — AP63205WU-7

VERDICT: PASS

Measured native identity count: 6 numbered physical identities, 6 native pads, 6 distinct copper lands, 0 exposed-pad identities, 0 aliases/fusions.

Primary document: SHA-256 `ef99daa3789d835bc025dfcb4c605c5c2e6d3e7223e86d40b33e6b497ea5a722`; PDF page 16, TSOT26 Marking Information (Top View); PDF page 2, Figure 1 Typical Application Circuit and Pin Descriptions; PDF pages 12–13, Setting the Output Voltage and Table 3 for AP63205; PDF page 17, TSOT26 Package Outline Dimensions and Suggested Pad Layout.

- U_BUCK pin 1 (FB): expected pin 1 at the marked TSOT26 corner and, for fixed-5-V AP63205, direct output-voltage feedback vs observed W/top on rail `5V_BUCK`; matches Figure 1 and the fixed-output text/Table 3.
- U_BUCK pin 2 (EN): expected enable input on a valid input/control rail vs observed W/middle on `12V_BUCK_IN`; matches the datasheet’s explicit permission to drive EN high and its 32 V tolerance.
- U_BUCK pin 3 (VIN): expected power input on the buck input rail vs observed W/bottom on `12V_BUCK_IN`; matches.
- U_BUCK pin 4 (GND): expected power ground vs observed E/bottom on `GND`; matches.
- U_BUCK pin 5 (SW): expected switching node between regulator and inductor vs observed E/middle on `BUCK_SW`; matches.
- U_BUCK pin 6 (BST): expected bootstrap-capacitor node referenced to SW vs observed E/top on `BUCK_BST`; matches.
- Package/winding: the manufacturer TOP VIEW places pins 1–3 along one row and 4–6 back along the opposite row. Rotating that view 90 degrees clockwise gives the dossier’s 1→2→3 down W and 4→5→6 up E, with CCW winding and no mirror.
- EP: the TSOT26 outline and suggested layout show six terminals and no exposed pad; the dossier likewise has no EP.

## U_PWR — TPS389001DSER

VERDICT: PASS

Measured native identity count: 6 numbered physical identities, 6 native pads, 6 distinct copper lands, 0 exposed-pad identities, 0 aliases/fusions.

Primary document: SHA-256 `ee79599730e7606ba9718d9820b411020e3dcd9ff7d44572f8ee63fead15b9d0`; PDF page 3, “DSE Package, 6-Pin WSON, Top View” and Pin Functions; PDF pages 24–25, package outline DSE0006A drawing 4220552/B and Example Board Layout.

- U_PWR pin 1 (SENSE): expected top-left identity on the three-pad left side and a monitored analog-voltage net vs observed W/top at `(-0.55,-0.50)` on `PWR_SENSE`; matches.
- U_PWR pin 2 (GND): expected left-middle identity on ground vs observed W/middle on `GND`; matches.
- U_PWR pin 3 (MR_N): expected bottom-left active-low manual-reset input; tying it to the supply keeps manual reset deasserted vs observed W/bottom on `5V_LDO_HOLD`, the same rail as VDD; matches.
- U_PWR pin 4 (VDD): expected bottom-right supply input on a supply rail vs observed E/bottom on `5V_LDO_HOLD`; matches.
- U_PWR pin 5 (CT): expected right-middle timing-capacitor node vs observed E/middle on `PWR_CT`; matches.
- U_PWR pin 6 (RESET_N): expected top-right open-drain reset output on a controlled-enable net vs observed E/top on `PWR_EN`; matches.
- Package/winding: manufacturer figure is explicitly TOP VIEW, with 1→2→3 down the left and 4→5→6 up the right, hence CCW. The front-mounted component-top table has the same winding and pin-1 corner without reflection.
- EP: the DSE0006A outline and land-pattern figures show six perimeter terminals and no exposed pad; the dossier likewise has no EP.

## Instance symmetry

The two TPS389001DSER instances preserve the same physical identity, side, and function kind on every pin: pin 1 analog sense, pin 2 ground, pin 3 active-low manual-reset control, pin 4 supply, pin 5 timing node, and pin 6 open-drain reset/enable output. Their distinct net names reflect their distinct monitored/control domains and do not create a structural divergence.

No unresolved findings.
