review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_power_fets_clockground1 (same independent reviewer continuing original review)
context: Independent original review continued with requested native/primary facts; not a fresh-agent reset
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
release_limit: FIRST-ARTICLE-ONLY
board_sha256: e85b1461a82f3d3853c19fae694693816e31570d23d37019ef187d6428bea4ae
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: e6d5b0b89efd79051b082f70b283ec7e85e1170ed11ddb94581744d26904c9c7

Q_IN and Q_PRE both PASS this limited group pin review. No whole-board, routing, release or order acceptance is implied. Immutable board/parts/rules bindings are supplied subject metadata; the supplement's board hash matches the original binding.

Continuation provenance: original completed report SHA-256 44b8d57dab4b4b6130410e0d8630e1fba3c5f61edfe07f6054536d95973b5503 remains unchanged. Its original figure-derived pin functions, mounted-frame transforms, identity counts, gate/rail sanity and Q_PRE PASS are inherited against identical dossier and primary-PDF hashes. Its Q_IN QUESTION is resolved only by the newly inspected native F.Cu primitives below. The envelope's generic context_mode=FRESH does not describe this reviewer's actual history; this report explicitly records continuation.

Q_IN — VERDICT: PASS
Primary: DMP6023LFG DS37204 Rev. 2-2, SHA-256 1ea244be5e0fe4195ad20cb2da0960ac622b6efc19cf9e579c9eb8ef5777fa27; PDF p.1 Bottom View/Top View and Equivalent Circuit, p.5 Package Outline Dimensions and Suggested Pad Layout. Actual p.1/p.5 images were inspected independently before the original dossier; retained p.5 figure image was reopened in this continuation.
Manufacturer bottom outline converts once to top view. Rotating the suggested top landing view clockwise 90 degrees yields left column pins 1,2,3,4 top-to-bottom and right drain contacts 8,7,6,5 top-to-bottom. Full physical numbering is CCW, pin 1 at upper-left. The continuous drain leadframe and suggested copper comb explicitly support fusion of pins 5–8 into one numbered land; the exposed drain is not a ninth independent EP. Front mounting and rotation 0 require no mirror.
Measured native inventory: 13 pad features = 5 numbered identities + 8 anonymous paste-only features. Aliases 6/7/8 -> 5 retain 8 physical identities. Newly measured custom pad 5 contains one rectangular anchor and four filled polygon primitives, 16 primitive vertices. The native raw subtree and all-feature JSON agree in pad count and identity inventory.
Q_IN pin 1 (SOURCE): expected left upper source; observed (-1.500,-0.975), 12V_PROTECTED.
Q_IN pin 2 (SOURCE): expected second left source; observed (-1.500,-0.325), 12V_PROTECTED.
Q_IN pin 3 (SOURCE): expected third left source; observed (-1.500,+0.325), 12V_PROTECTED.
Q_IN pin 4 (GATE): expected left lower gate; observed (-1.500,+0.975), Q_IN_GATE.
Q_IN pins 5–8 (DRAIN): expected common exposed copper with contacts at x=+1.500 and y=+0.975,+0.325,-0.325,-0.975 respectively; observed native custom pad 5 on F.Cu/F.Mask and net 12V_FUSED, with the exact filled polygons described next.

New physical-copper proof: raw pad 5 is smd custom, at (0.455,0), size (1.71,2.37), anchor rect, layers F.Cu/F.Mask, net 12V_FUSED. Its anchor covers x=-0.400..+1.310 and y=-1.185..+1.185. The four gr_poly primitives have fill=yes and width=0; adding the pad offset converts their pad-local x=0.855..1.395 to component-top x=1.310..1.850. Their component-top y intervals are:

| Physical contact | y interval (mm) | Center (mm) |
|---|---|---|
| 5 | +0.765..+1.185 | (+1.500,+0.975) |
| 6 | +0.115..+0.535 | (+1.500,+0.325) |
| 7 | -0.535..-0.115 | (+1.500,-0.325) |
| 8 | -1.185..-0.765 | (+1.500,-0.975) |

Each polygon shares an entire 0.420-mm edge at x=1.310 with the same copper anchor. Their union covers the full 0.700 x 0.420-mm contact lands x=1.150..1.850 at all four expected y positions. Thus the copper is continuous and reaches all four physical contacts; paste apertures are not used as proof. Overall drain copper bounds are 2.250 x 2.370 mm, matching manufacturer p.5 Y1=2.250 and X=2.370 after rotation. Finger width 0.420 and pitch 0.650 match X2 and C. Central exposed drain coverage is retained. All custom material inherits the same native pad-5 net, 12V_FUSED.
Supplement raw subtree SHA-256: 4f40ca0501c9c41771b649a10930f875544774e6e03736a1a11e8b937dec7d62. All-feature JSON SHA-256: 9fe03141bc0df4ab3484f619ca406044baf2d0d3576159ec691d02d2a7f96ebe. The subtree hash matches the extraction record, and its board hash matches the unchanged board binding. Producer and runtime are retained as provenance; the producer was read, not rerun against any live board.
The original dossier's winding n/a follows from collinear surviving numbered perimeter pins 1–4. It was not a failure. Individual contacts plus newly confirmed fused drain geometry establish the manufacturer top-view ordering.
Function/net sanity: source=12V_PROTECTED, drain=12V_FUSED and dedicated Q_IN_GATE are consistent with input protection; body diode points fused -> protected. No function or rail-net substitution was found.

Q_PRE — VERDICT: PASS (inherited unchanged physical proof)
Primary: AO3401A Rev. 3.1, SHA-256 0d8e3261ae280e007b5837fff60c55142f2d92af71edc4d02aee6f7a760a785c; PDF p.1 SOT23 Top View/Bottom View and equivalent circuit. Those actual images were inspected originally; p.5 test-circuit image is retained as inspected evidence but is not pinout proof.
Measured native inventory: 3 numbered pads and 3 physical terminals; no aliases, anonymous features or EP. Manufacturer top view, rotated without mirroring, has gate at the marked upper-left corner, source lower-left and drain alone right-middle. The figure prints functional labels rather than numeric 1/2/3, so the physical functional arrangement is the direct proof.
Q_PRE pin 1 (G): expected marked gate corner; observed (-0.9375,-0.9500), PRE_GATE.
Q_PRE pin 2 (S): expected other paired lead; observed (-0.9375,+0.9500), 5V_LDO_FEED.
Q_PRE pin 3 (D): expected single opposite lead; observed (+0.9375,0), 5V_LDO_HOLD.
Top-view G/S/D winding is CCW, measured signed area -1.78125 mm² in +y-down coordinates. Native rotation 180 degrees at (44.02,58.1) and front mounting correctly reproduce every dossier board coordinate. Source feed/drain hold/dedicated gate are plausible P-channel supply-switch net kinds; body diode points HOLD -> FEED. Absent system off-state requirements are not asserted.

Symmetry: the scope contains one instance of each package, so no same-part duplicate pair exists. Both retain separate gate nets and rail source/drain nets. Their different rail ordering is consistent with their distinct protection/switch roles and does not alter package assignments. Every scoped native instance and physical identity has been covered.

Methods and limits: all 13 envelope input hashes/sizes verified before and after. Original independent figure proof is retained with actual inspected PNGs and original render receipts. New native subtree parsed with an independent S-expression parser; filled copper rectangles, layers, net, full contact coverage, common-edge connectivity and hash/count consistency measured directly. No live board was read or changed, no source adoption occurred, and no subagent was used. Requested geometry gap is resolved; no outstanding pin finding remains in this two-ref scope. Full PDFs remain in the digest-bound frozen packet. Final packaging/preflight receipts are retained in allocated scratch; archive contains prior completed runtime and preflight receipts without recursive self-archiving.
