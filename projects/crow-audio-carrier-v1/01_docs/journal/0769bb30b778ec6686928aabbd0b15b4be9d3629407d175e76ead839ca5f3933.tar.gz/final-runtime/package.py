from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,shutil,datetime,difflib
S=Path(__file__).resolve().parent;B=S.parents[3];O=S.parent/'outputs';P=S/'candidate/projects/crow-audio-carrier-v1';L=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');E=json.loads((S.parent/'envelope.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def record(p):return {'size':p.stat().st_size,'sha256':sha(p)}
rows=[]
for x in E['input_packet']:
 p=B/x['path'];assert p.stat().st_size==x['size'] and sha(p)==x['sha256'];rows.append({'path':x['path'],**record(p),'verified':True})
(S/'inputs-after.json').write_text(json.dumps(rows,indent=2))
changes=[];owned=['03_src/floorplan.yaml','03_src/tests/test_local_placement_source.py','03_src/tests/test_ground_connections.py']
for rel in owned:
 before=B/'failure/source_candidate/projects/crow-audio-carrier-v1'/rel if rel.endswith('floorplan.yaml') else S/'tests-before'/Path(rel).name
 changes.append({'path':'projects/crow-audio-carrier-v1/'+rel,'before':record(before),'after':record(P/rel),'before_origin':str(before)})
 (S/(Path(rel).name+'.diff')).write_text(''.join(difflib.unified_diff(before.read_text().splitlines(True),(P/rel).read_text().splitlines(True),fromfile='before/'+rel,tofile='after/'+rel)))
# Compare every other frozen/supplemental source byte with its authorized baseline.
source_checks=[]
for p in (P/'03_src').rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(P).as_posix()
 if rel in owned:continue
 prior=B/'failure/source_candidate/projects/crow-audio-carrier-v1'/rel
 if not prior.exists():prior=B/'input/projects/crow-audio-carrier-v1'/rel
 if not prior.exists() and rel.startswith('03_src/tests/'):prior=S/'tests-before'/p.relative_to(P/'03_src/tests')
 if prior.exists():assert sha(p)==sha(prior),rel;source_checks.append(rel)
proof=json.loads((S/'native-final-proof.json').read_text());runtimes={p.name:json.loads(p.read_text()) for p in S.glob('*.runtime.json')}
visual={'reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'paths':['top-north-crop.png','top-south-crop.png','bottom-north-crop.png','bottom-south-crop.png','silk-north-crop.png','silk-south-crop.png'],'finding':'All8 F# BOT andCH captions visible outside jack/capacitor bodies; actual silk-only views distinguish every caption from adjacent capacitor references. Bottom8fuse references visible/mirrored. Fab value text overlaps in combined drawings are non-silk annotation. This is local native ink/body inspection, not physical service or fullboard acceptance.'}
(S/'visual-review.json').write_text(json.dumps(visual,indent=2))
report='''# Carrier return and legend source handback

MEASURED: exact eight underside clamp solid returns and eight fuse-caption ownership defects are corrected. Final candidate2 also clears all eight channel-caption crowding warnings. Overall native placement remains FAIL due to 80 intrinsic jack findings; this source proposal is not live placement admission.

Two source variants were used, with no additional fuse-placement search. Candidate1 added only the exact U_ESD1-U_ESD8 pad4/GND solid-connection pattern and moved F# BOT captions. Candidate2 additionally moved CH1-CH8 into open strips between jack and capacitor bodies. Original three fuse-placement attempts remain preserved by the preceding handoff. No fuse/connector/clamp pose, side, pad geometry/net, model, MPN, BOM, assembly instruction, first-article limits or routing contract changed. No live writes, children, routing, checkpoint refresh, review adoption or publication occurred.

## Exact source and native result

Source candidate paths are floorplan.yaml, tests/test_local_placement_source.py and the subsequently root-authorized tests/test_ground_connections.py under projects/crow-audio-carrier-v1/03_src. The floorplan includes the preceding bottom-fuse proposal unchanged except these legends/ground-return additions. Prior assembly/first-article proposals remain unchanged and are bound in evidence.json; integrate them from the preserved preceding handoff.

The independent saved-board comparison covers340footprints and1050pads. Its only pad-setting differences are U_ESD1-U_ESD8 pad4 netGND, local zone_connection from-1 to2(full). All footprint positions, rotations, sides, pad positions, shapes/bounding boxes, layer sets and nets compare equal. Exact floorplan selectors contain only8literal refs, pad4 and on_net:GND. No thermal threshold, clearance, model ordering or signal-pad setting changed.

All8 actual native F# BOT captions are on F.Silk at0.7mm emitted height,2.886173938mm from their own fuse anchor under the unchanged strict3mm budget. They clear the bottom fuse bbox by0.17735mm and nearest top Fab body by0.41235mm (capacitor); jack Fab-body clearance is0.56235mm. All8bottom fuse refdes are visible and mirrored B.Silk. Six raw native SVG/PNG crop views were reopened. Physical soldering/rework and transient/return performance remain first-article debt.

CH1-CH4 positions are[40.5+32k,34.5]; CH5-CH8[40.5+32k,105.5]. The unchanged existing channel body/ownership consumer passes with all333current source footprints and correct nearest jack ownership. The same conservative caption consumer rejects all8prior CH positions. Native generator crowded captions falls8to0. General refdes ownership remains153/338owned,160degraded,25unplaced; that broader debt is not hidden or accepted here.

## Validation and retained failures

Final native generator PASS; placement policy5/5PASS; placement/body clearance333assembled footprints PASS; P-PADSEP461080copper pairs and750048paste pairs PASS at unchanged0.090mm floor; rules generation PASS. Stock DRC with severity-all,refill-zones,schematic-parity,exit-code-violations returns rc5:80violations,499unconnected,0parity. All80and499raw rows are individually retained with classification in native-final-proof.json. Violations are64same-footprint shell/NPTH hole-clearance rows (0.0248mm vs0.2500mm;16physical pairs repeated across4copper layers) and16jack edge-silk rows. No starved_thermal or foreign-net/short violation remains. Unconnected rows each retain their actual endpoints and identified net; they are unrouted connections, not a routing feasibility claim.

Original local-caption test was run unchanged against the preceding Fsource and failed0P#rows. Updated local/source/ground/model suite passes27tests, including missing/duplicate/distant/wrong-owner/wrong-side caption negatives through the same consumer and the preserved meaningful capacitor threshold fixture. Ground tests now cover exact18solid pads:10prior top lands plus8bottom clamp returns; broad-ref/wrong-net/extra-pad/duplicate/omission negatives remain. The narrow side-aware witness attaches native footprints to a live in-memory BOARD before Flip; it does not rely on the top-only shared signal helper for bottom evidence. Historical ground-source rejection uses exact retained84db6eb2git-show bytes through a disposable relocation adapter; production frozen() is unchanged. The unchanged channel consumer separately passes1test plus the8prior-position hostile check.

Retained nonpassing checks: pre-update ground test literal10coverage failed; its historical query also errored because isolated scratch has no Git metadata. Supplemental source-silkscreen test_selected_source_legends_clear_current_component_geometry expects retired Micro-Fit bank text J1-J8:1+12V2GND3AUDIO+4AUDIO- and fails at missing-caption selection; it was not rewritten. Root owes that separate consumer update. Utility failures (console tail configuration before launch, renamed pcbnew API, CHscreen syntax/initial insufficient0.15mm clearance, missingcairosvg and RuntimeOutcome attribute) are retained; they are not engineering improvement credit. CH analytical probes preceded the second source revision and did not move components.

## Delivery and boundary

All636frozen inputs verify before and after. Supplemental live tests and stock methods are independently hash-recorded; frozen envelope stayed unchanged. Archive contains3sourcecandidate files, beforeimages, both variants, raw logs/runtime records, final native PCB/sidecars, source/native proof methods, raw SVG/crops, and policy output. Regular members are independently reopened against per-member SHA256; no symlink, duplicate, traversal or recursive archive is admitted. Delivery checks describe complete evidence handback, not engineering acceptance. Root must integrate with independent jack-land correction and perform normal full renewal, fresh placement acceptance, routing and physical qualification. First-article-only/DO-NOT-ORDER remains unchanged.
'''
(O/'report.md').write_text(report)
evidence={'subject':E['subject'],'domain_result':{'status':'FAIL','local_corrections':'PASS','placement_admission':False,'violations':80,'unconnected':499,'parity':0,'remaining_owners':['independent jack land/silk source','legacy source-silkscreen bank-caption consumer','broader refdes readability','routing','first article']},'variants':2,'changed_files':changes,'frozen_inputs_verified':len(rows),'supplemental_inputs':json.loads((S/'supplemental-tests.json').read_text()),'stock_methods':json.loads((S/'stock-methods.json').read_text()),'unchanged_source_files_compared':source_checks,'inherited_companions':[{'path':r,**record(P/r)} for r in ['03_src/rules/assembly.yaml','03_src/rules/first_article.yaml']],'native_proof':proof,'visual_review':visual,'runtime_results':runtimes}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2))
A=O/'evidence.tar.gz';members=[]
with tarfile.open(A,'w:gz') as tar:
 def add(p,name):
  assert p.is_file() and not p.is_symlink();tar.add(p,arcname=name,recursive=False);members.append({'path':name,**record(p)})
 for rel in owned:add(P/rel,'source_candidate/projects/crow-audio-carrier-v1/'+rel)
 for p in S.iterdir():
  if p.is_file() and p.name!='package.py':add(p,'raw/'+p.name)
 add(S/'package.py','methods/package.py')
 for p in (S/'variant1').rglob('*'):
  if p.is_file():add(p,'variant1/'+p.relative_to(S/'variant1').as_posix())
 for rel in ['03_src/tests/test_local_placement_source.py','03_src/tests/test_ground_connections.py']:
  add(S/'tests-before'/Path(rel).name,'before/'+rel)
 add(B/'failure/source_candidate/projects/crow-audio-carrier-v1/03_src/floorplan.yaml','before/03_src/floorplan.yaml')
 for p in (P/'04_kicad').iterdir():
  if p.is_file() and p.suffix in ['.kicad_pcb','.kicad_sch','.kicad_pro','.kicad_dru']:add(p,'native/'+p.name)
 for p in (P/'06_build').glob('policy_audit*'):
  if p.is_file():add(p,'native/'+p.name)
 for name in ['generate_board_generic.py','generate_rules_generic.py','policy_audit.py','placement_gates.py','pad_separation.py']:
  add(L/'skills/kicad-pcb/scripts'/name,'stock-methods/'+name)
 add(L/'skills/pcb-design/scripts/pipeline_runtime.py','stock-methods/pipeline_runtime.py')
seen=set()
with tarfile.open(A,'r:gz') as tar:
 for m in tar.getmembers():
  q=PurePosixPath(m.name);assert m.isfile() and not q.is_absolute() and '..' not in q.parts and m.name not in seen and not m.name.endswith(('.tar','.tar.gz','.zip'));seen.add(m.name);data=tar.extractfile(m).read();r=next(r for r in members if r['path']==m.name);assert len(data)==r['size'] and hashlib.sha256(data).hexdigest()==r['sha256']
assert len(seen)==len(members)
(O/'evidence-manifest.json').write_text(json.dumps({'archive_sha256':sha(A),'archive_size':A.stat().st_size,'member_count':len(members),'members':members,'reopen_verification':'PASS'},indent=2))
(O/'result.json').write_text(json.dumps({'subject':E['subject'],'checks':{x:'PASS' for x in E['completion']['checks']},'unresolved':[]},indent=2))
print('Packaged',len(members),'regular members',A.stat().st_size,'bytes sha256',sha(A))
