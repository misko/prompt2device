review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 92a4e2fc0fecde845f2dfa0d9e2f5bfbd943372962fb449d699a98d957fc5633
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: 7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c

Limited coverage: this review covers only U_AFE1, U_AFE2, U_AFE3, U_AFE4, U_AFE5, U_AFE6, U_AFE7, and U_AFE8. It is not whole-board acceptance. The immutable order verdict remains DO-NOT-ORDER.

Primary source independently inspected first: Texas Instruments OPA320/OPA2320/OPA320S/OPA2320S datasheet SBOS513F, SHA-256 `1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc`, PDF page 4, section 5 figure “OPA2320 D and DGK Packages — 8-Pin SOIC and VSSOP — Top View” and the adjacent “Pin Functions: OPA2320” table. The figure is explicitly TOP VIEW. For the D-package SOIC, pin 1 is the upper-left corner, pins 1–4 descend the left side, and pins 5–8 ascend the right side: counterclockwise winding in the dossier component-top convention (+x right, +y down), four pins per side. The D package has eight physical pins and no exposed pad. The DRG SON figure’s exposed thermal pad does not apply to the ordered OPA2320AIDR D package.

Expected source-derived function map: 1=OUTA, 2=-INA, 3=+INA, 4=V-, 5=+INB, 6=-INB, 7=OUTB, 8=V+.

U_AFE1 VERDICT: PASS
Measured native pad count: 8; measured physical identity count: 8; aliases/fused identities: 0; exposed pad: not applicable/absent. Expected top-view CCW winding, pin 1 upper-left, W-side pins 1/2/3/4, E-side pins 5/6/7/8, and the source-derived function map. Observed front-mounted component-top coordinates exactly match that geometry. Observed nets are 1 OPA_P1, 2 FB_P1, 3 AIN_P1, 4 GND, 5 AIN_N1, 6 FB_N1, 7 OPA_N1, 8 3V3_ADC; each net kind is electrically sane for its function.

U_AFE2 VERDICT: PASS
Measured native pad count: 8; measured physical identity count: 8; aliases/fused identities: 0; exposed pad: not applicable/absent. Expected the same package geometry and functions. Observed front-mounted component-top geometry matches. Observed nets are 1 OPA_P2, 2 FB_P2, 3 AIN_P2, 4 GND, 5 AIN_N2, 6 FB_N2, 7 OPA_N2, 8 3V3_ADC; each net kind is sane.

U_AFE3 VERDICT: PASS
Measured native pad count: 8; measured physical identity count: 8; aliases/fused identities: 0; exposed pad: not applicable/absent. Expected the same package geometry and functions. Observed front-mounted component-top geometry matches. Observed nets are 1 OPA_P3, 2 FB_P3, 3 AIN_P3, 4 GND, 5 AIN_N3, 6 FB_N3, 7 OPA_N3, 8 3V3_ADC; each net kind is sane.

U_AFE4 VERDICT: PASS
Measured native pad count: 8; measured physical identity count: 8; aliases/fused identities: 0; exposed pad: not applicable/absent. Expected the same package geometry and functions. Observed front-mounted component-top geometry matches. Observed nets are 1 OPA_P4, 2 FB_P4, 3 AIN_P4, 4 GND, 5 AIN_N4, 6 FB_N4, 7 OPA_N4, 8 3V3_ADC; each net kind is sane.

U_AFE5 VERDICT: PASS
Measured native pad count: 8; measured physical identity count: 8; aliases/fused identities: 0; exposed pad: not applicable/absent. Expected the same package geometry and functions. Observed front-mounted component-top geometry matches; the 180-degree board rotation changes only native board coordinates. Observed nets are 1 OPA_P5, 2 FB_P5, 3 AIN_P5, 4 GND, 5 AIN_N5, 6 FB_N5, 7 OPA_N5, 8 3V3_ADC; each net kind is sane.

U_AFE6 VERDICT: PASS
Measured native pad count: 8; measured physical identity count: 8; aliases/fused identities: 0; exposed pad: not applicable/absent. Expected the same package geometry and functions. Observed front-mounted component-top geometry matches; the 180-degree board rotation changes only native board coordinates. Observed nets are 1 OPA_P6, 2 FB_P6, 3 AIN_P6, 4 GND, 5 AIN_N6, 6 FB_N6, 7 OPA_N6, 8 3V3_ADC; each net kind is sane.

U_AFE7 VERDICT: PASS
Measured native pad count: 8; measured physical identity count: 8; aliases/fused identities: 0; exposed pad: not applicable/absent. Expected the same package geometry and functions. Observed front-mounted component-top geometry matches; the 180-degree board rotation changes only native board coordinates. Observed nets are 1 OPA_P7, 2 FB_P7, 3 AIN_P7, 4 GND, 5 AIN_N7, 6 FB_N7, 7 OPA_N7, 8 3V3_ADC; each net kind is sane.

U_AFE8 VERDICT: PASS
Measured native pad count: 8; measured physical identity count: 8; aliases/fused identities: 0; exposed pad: not applicable/absent. Expected the same package geometry and functions. Observed front-mounted component-top geometry matches; the 180-degree board rotation changes only native board coordinates. Observed nets are 1 OPA_P8, 2 FB_P8, 3 AIN_P8, 4 GND, 5 AIN_N8, 6 FB_N8, 7 OPA_N8, 8 3V3_ADC; each net kind is sane.

Pairwise symmetry: PASS. Across all eight instances, each pin maps to the same kind of indexed channel net: OUTA→OPA_Pn, -INA→FB_Pn, +INA→AIN_Pn, V-→GND, +INB→AIN_Nn, -INB→FB_Nn, OUTB→OPA_Nn, V+→3V3_ADC. No structural divergence was found.

Unresolved findings: none.
