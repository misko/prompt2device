#!/usr/bin/python3
import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path, PurePosixPath

base = Path(__file__).resolve().parent
source = base / "evidence"
output = base.parent / "outputs"
archive = output / "evidence.tar.gz"
manifest_path = output / "evidence-manifest.json"

files = sorted(p for p in source.rglob("*") if p.is_file())
if not files:
    raise SystemExit("empty evidence tree")
if any(p.is_symlink() for p in source.rglob("*")):
    raise SystemExit("symlink in evidence tree")

records = []
with archive.open("wb") as raw:
    with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode="w") as tar:
            for path in files:
                rel = path.relative_to(source).as_posix()
                data = path.read_bytes()
                info = tarfile.TarInfo(rel)
                info.size = len(data)
                info.mtime = 0
                info.mode = 0o644
                info.uid = 0
                info.gid = 0
                info.uname = ""
                info.gname = ""
                tar.addfile(info, io.BytesIO(data))
                records.append({"path": rel, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()})

seen = set()
reopened = []
with tarfile.open(archive, "r:gz") as tar:
    for member in tar.getmembers():
        path = PurePosixPath(member.name)
        if member.name in seen or path.is_absolute() or ".." in path.parts:
            raise SystemExit(f"unsafe or duplicate member: {member.name}")
        seen.add(member.name)
        if not member.isfile() or member.issym() or member.islnk():
            raise SystemExit(f"non-regular member: {member.name}")
        stream = tar.extractfile(member)
        if stream is None:
            raise SystemExit(f"cannot reopen member: {member.name}")
        data = stream.read()
        reopened.append({"path": member.name, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()})
if reopened != records:
    raise SystemExit("reopened archive members differ from source records")

archive_bytes = archive.read_bytes()
manifest = {
    "archive_sha256": hashlib.sha256(archive_bytes).hexdigest(),
    "archive_size": len(archive_bytes),
    "member_count": len(records),
    "members": records,
}
manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
print(json.dumps(manifest, indent=2, sort_keys=True))
