# Model-frame orientation judgment

## Decision

The D-BACK hypothesis is supported. `P-ORIENT` was comparing an exact
native-model direction directly with a KiCad footprint-local direction. Those
frames have opposite Y conventions on F.Cu, and KiCad applies stored model
rotations with negative angles. The correction is limited to the direction
transform and the human-view lighting/board-strip calibration it exposed.

For a direction vector (translation is irrelevant), KiCad 10.0.4 constructs
the model portion as `Rz(-rz) Ry(-ry) Rx(-rx) S`. GLM post-multiplication means
the native vector encounters positive/nonuniform scale first, then negative X,
Y, and Z rotations. Converting renderer-local Y-up back to KiCad footprint-local
Y-down gives:

`v_fp = normalize(D_side Rz(-rz) Ry(-ry) Rx(-rx) S v_model)`

where `D_front = diag(1,-1,1)` and `D_back = diag(-1,1,1)`. The back expression
follows from KiCad's later `Ry(pi) Rz(pi)` footprint flip together with the
existing footprint-to-board X/Z mirror. The unchanged footprint-to-board gate
still independently handles actual 0/90/180/270-degree footprint placement.

The exact source authority is the supplied KiCad 10.0.4 `create_scene.cpp`, SHA
`54c3e3faf5c0c4d158f6584ee34021ef42145e11a240bc0e7c4a528be956f0f4`:
lines 1939-1948 show board-Y reflection and footprint +Z rotation; lines
1951-1956 show the back-side rotations; lines 2006-2024 show translate,
negative stored Z/Y/X rotations, then scale.

## Native observations

The frozen Molex model is asymmetric and its mouth roof/floor extend toward
native +Y while the intended footprint mouth is -Y. Its exact SHA is
`1871a5528738166fef7339e7e8bb83c0477749d654b355d56cc37369fbb25bea`.
The retained native matrix mounts that body at footprint 0/90/180/270 degrees
on both F.Cu and B.Cu, first with identity attachment and again with stored
rotation `[31,23,47]` and nonuniform positive scale `[1.7,0.8,1.3]`. Actual
KiCad top/front/right renders show the asymmetric bodies quarter-turning with
the footprints, front/back bodies on opposite board faces, and the combined
rotation/scale cases rolled and stretched as the source transform predicts.
These are actual renderer outputs; no pixel coordinate is presented as a
native-axis measurement. The exact transform is established by the renderer
source and checked against these representative native renders.

The regression covers front native-Y reflection, back X reflection, each
stored rotation sign, combined X-then-Y-then-Z application order, nonuniform
positive scale, and actual footprint 90/270 behavior from pcbnew pad positions.
Deliberately wrong native mouth, inverted up/roll, negative-scale mirror, and
reversed-footprint controls all fail. Against the original checker the suite
was RED (6 passed, 5 failed), including a false machine PASS for the wrong
native mouth. Against the correction it is GREEN (11 passed, 0 failed; 2
known-bad controls).

The fixed high-quality lighting makes the frozen candidate's dark cavity
openings visible. It also changed the rendered board strip from the prior
grey-blue range to measured olive RGB `(137,145,96)`; the crop calibration now
admits both while still rejecting the `(164,164,188)` background. A retained
intermediate run failed on exactly this strip before the calibration was
updated.

## Replay and scope

The truthful nine-reference replay now records machine `PASS`, 9/9 refs, nine
model alignments of `1.0`, no failures, and no approval. Human state remains
`REQUIRED` (`approval is absent or unreadable`). The complete J1-J9 denominator,
signed edge checks, exact model hashes, keyed pads, and physical scale-mirror
rejection remain intact. The semantic engine identity changed, so earlier
orientation approval evidence is stale by design.

Direct-consumer inspection found that `jlc_twin.py`/`P-MATE-REG` consumes the
footprint access axis, not the native model axis; it therefore needs no frame
reinterpretation. Its full suite passes 40/40. Connector assembly contract
tests pass 23/23, native model-registration tests 8/8, contract tests 17/17,
schema-reader tests 28/28, and the repository contract audit grades 650 files
with zero violations.

The 13-file source candidate remains immutable forensic input and was not
adopted. Its prior `P-MODEL-REG` 3/3 groups, 11 refs, and 75 centres is separate
evidence; this judgment does not reopen human approval or claim placement
acceptance. The frozen Molex body still omits contact detail, end-cavity lower
chamfers, locking features, and a proved mating fit, so its images cannot close
keying/fit/service review. A newer root-owned model candidate was explicitly
outside this frozen review and is not judged here. First-article physical fit
and service remain governed by ADR-0007 rather than being invented as a new
pre-route machine blocker.

The exploratory GLB route was abandoned after three parser failures on a
custom marker; a subsequent exact frozen-model GLB check established that the
GLB exporter rejects this VRML while the authoritative raytracing renderer
loads it. All failures and the successful renderer path are retained. No live
project, generated board, release, review, approval, commit, or push was
modified.
