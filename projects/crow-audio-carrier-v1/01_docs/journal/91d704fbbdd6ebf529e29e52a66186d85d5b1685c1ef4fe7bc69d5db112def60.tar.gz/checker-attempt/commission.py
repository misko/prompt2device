from pathlib import Path
from datetime import datetime,timezone,timedelta
import sys,json,hashlib,shutil,subprocess
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;W=D/'work/repo';I=D/'input'
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True,timeout=30).strip().startswith('72bc4bd6')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True,timeout=30).strip()
O=Path('/tmp/carrier-model-source-20260911/06_build/task_runs/connector-model-source/outputs')
for p in O.iterdir():shutil.copyfile(p,I/p.name)
for name in ['envelope.json','attempt.json']:
 shutil.copyfile(O.parent/name,I/('source-'+name))
for name in ['reopen.json','validation.json']:
 shutil.copyfile(Path('/tmp/carrier-model-source-closeout-20260911')/name,I/('root-'+name))
for name in ['create_scene-10.0.4.cpp','kicad-source-fetch.json','molex-drawing.png']:
 shutil.copyfile(Path('/tmp/carrier-molex-primary-cad-20260911')/name,I/name)
for rel in ['01_docs/STATUS.md','06_build/agent_handoff.yaml','06_build/task_runs/qualify-98da241ced304529ae35696df1dd9208/qualification.json']:
 shutil.copyfile(P/rel,I/Path(rel).name)
now=datetime.now(timezone.utc);cut=now+timedelta(minutes=28);hard=now+timedelta(minutes=30)
(D/'TASK.md').write_text(f'''# Fresh D-BACK owner: qualify and correct model-frame orientation

Agent-role judgment, standard/full effort, fresh context/no children. You own only {D}/work. Live repository {R} remains root-owned and READ_ONLY to you. Exact isolated checkout {W}, base72bc4bd6. Current source author attempt is terminalINCOMPLETE for writing scratch/helpers outside declaredwork, not accepted. Its 13-file model candidate is immutable forensic INPUT, not design authority. The source author is closed; this is a different upstream checker diagnosis and implementation task, not a replacement source-author attempt or allowance reset.

Read TASK, allocated envelope, inputSTATUS/compacthandoff, inputsource-report/attempt and relevant CLAUDE/pcb-design skill, execution-runtime, lifecycle, compute, connector-orientation, designpolicies, testsREADME in isolatedcheckout before acting. Keep original failed input immutable. Verify EVERY envelope packet and candidate tar exact SHA/member manifest before use. Copy/extract forensic content underwork only. Never modify live tree, input, TASK, setup/commission files, originalattempt, projectsource, generatedboard or anyreview/approval. The isolated checkout can be changed ONLY for minimal orientation checker code, applicable native/known-bad tests and directly owning docs/contracts. No gate bypass, broad waiver, producer narrowing, unrelatedrefactor, commits orpush.

Measured premise for independent judgment: source exporter nativeY=-footprintY. Correct Molex mouth is native+Y/footprint-Y. With truthful axes, unchangedP-ORIENT fails9/9 atalignment-1. Earlier falsemodel-Y declared in footprint frame passes9/9 but is rejected. Exact KiCad10.0.4 renderer source ininput SHA54c3e3faf5c0c4d158f6584ee34021ef42145e11a240bc0e7c4a528be956f0f4, actuallines1939–1944 boardYreflection and2006–2024 storedmodelrotation signs. Read whole relevanttransform context; root inference is a hypothesis, not authority. The independent modelregistration3/3groups11refs75centres passed; candidate geometry/keying remains separately incomplete. Root independently finishes modelsource in another isolated workspace; do not touch those source files.

Work:
1. Establish exact native-model -> footprint -> board transform using independent native evidence. Include non-symmetric marker/geometry, actual modelY reflection, stored model rotation signs/order, nonuniformpositive scale, front/backmount, and actual footprint0/90/180/270 rotations. Derive from exact KiCad code and verify representative actual native renders/exportedgeometry, not merely a Python model duplicating proposedchecker. Supply truepositive and deliberatelywrong-axis/roll/mirror controls. Do not claim a native measurement when only algebra was checked.
2. If hypothesis is supported, implement the minimal coherent orientation-gate correction. Keep exact-model-local semantic truthful. Inspect all direct consumers (including fabrication mating datum path) and update shared convention consistently where required. No silent reinterpretation of old receipts; existing toolidentity must stale affected evidence. Address current exactcounterexample without moving parts or declaring false axes. Preserve completeJ denominator, signedsideprerequisite, humanapproval requirement, physical modelidentity and clearance obligations. If a requiredmethod/authority is unavailable, report precise limitation, no forcedPASS.
3. Test checker with independently grounded native fixture. Required meaningful regression must fail against originalchecker then pass correctedchecker, retaining rawRED/GREEN; allold relevant connector/native/mating tests must pass or explicit reasonedremainingfailure reported. Do not edit expectedvalues solely to fit newimplementation: qualify actualmodel-frame axes behind existing fixtures. Read testsREADME. Run required applicable contract/skill/doc suites iftheirsourcechanges. No need unrelatedfullreleasebattery yet.
4. Replay the 9ref truthful candidate inisolatedscratch with correctedchecker, using exactdeclaredaxes/modelbindings andsource-generatedboard (providedcandidateboard is diagnostic only). P-MODEL-REG/signedside evidence may be rebound/reopened only attrueowninghashes. Expected terminal is machinePASS/humanREQUIRED, neverhumanapproval. If rendering/bodydetaildoesnotallowhumanreview reportthat independently. Do not claimplacementaccepted.

All commands via unchanged pipeline_runtime.run_stage or owningboundedadapter, /usr/bin/python3 forpcbnew, explicit actualHOME/PATH/LANG/PYTHONDONTWRITEBYTECODE. Nativequalification4/4 isprovided withexactmethods; verify applicableidentities. Bound eachchild normally120s; composed native/tests up to600s onlyifremainingtimepermits. Keepall helper scripts, downloads, extractedarchives, nativefiles, logs inside {D}/work or ALLOCATED attempt scratch. No {D}/scratch or root helperfiles. Max3consecutive nonimproving samefindings; retain everyfailedexperiment. Work/finalcutoff {cut.isoformat()}, hard rootclose {hard.isoformat()}; reserve last3workminutes forpackaging/preflight. No extension/replacement; return immediatelywhenfinished.

Deliver exactly judgment.md, changes.json, evidence.tar.gz, evidence-manifest.json, result.json inallocatedoutputs. judgment describescausaldecision, actualnativeobservations, exactfixscope, residualrisks and sourcecandidate status. changes listsrepo-relativebefore/afterSHA andreason for everyauthoredfile. Tar regularfiles only: source/<repo-relative> changedimplementation/tests/docs; evidence/ allnativefixtures/models/render/exportoutputs, sourceauthority, scripts/fullprocesslogs/receipts, originalRED andcorrectedGREEN. Manifest exact {{archive:{{sha256,size}},members:{{name:{{sha256,size}}}}}}; rejectduplicate/link/traversal/extra members. Finalresult exact {{"subject":envelope.subject,"checks":{{"inputs-verified":"PASS","judgment-complete":"PASS","processes-closed":"PASS"}},"unresolved":[]}} forcomplete truthfuldelivery; engineeringFAIL goesinjudgment, not fabricatedPASS.

BeforeFINAL executeprovidedpreflight.py withallocatedenvelope. It checks actualoutputshape AND originalwriter snapshotusingtheunchangedruntime receiptfunction. Saveitsoutputlog onlyinallocatedscratch, neverinsidearchivebeingvalidated. A redpreflightrequirescorrectionwithintheoriginaldeadline orhonestINCOMPLETEdelivery. Donot closeyour ownagentattempt. Rootmustobserve actualhostFINAL, closeonce, independentlyreopenandadjudicate.\n''')
(D/'preflight.py').write_text('''from pathlib import Path
import sys,json
R=Path("/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901");sys.path.insert(0,str(R/"skills/pcb-design/scripts"))
from pipeline_execution import TaskEnvelope,verify_input_packet,writer_scope_receipt
from pipeline_runtime import _tree_snapshot,_changed_paths,_snapshot_sha256
from pipeline_artifacts import validate_task_outputs
p=Path(sys.argv[1]);e=TaskEnvelope.from_json(p.read_text());a=json.loads((p.parent/"admission.json").read_text());root=Path(a["root"])
assert verify_input_packet(e,root)[0]
after=_tree_snapshot(root,ignored=frozenset(a["ignored"]))
scope=writer_scope_receipt(e.writer_scope,_changed_paths(a["before"],after),before_sha256=_snapshot_sha256(a["before"]),after_sha256=_snapshot_sha256(after),protected_paths=tuple(sorted((e.output_path,a["claim"]))))
assert scope["status"]=="PASS",scope
v=validate_task_outputs(p.parent/"outputs",e.completion["outputs"],subject=e.subject.to_mapping(),checks=e.completion["checks"])
print(json.dumps({"writer_scope":scope,"delivery":v}))
''')
items=[]
for p in sorted([D/'TASK.md',D/'preflight.py',*I.rglob('*')]):
 if not p.is_file():continue
 b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(D).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
subject=subject_identity('native_orientation_frame',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
e=TaskEnvelope(schema=2,task_id='orientation-frame',stage_id='KICAD-PLACEMENT',run_id='orientation-frame',subject=subject,executor='agent',execution_class='local',recommended_agent_role='judgment',agent_role='judgment',role_escalation_reason=None,context_mode='FRESH',input_handoff_id='orientation-frame',input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=3,replacement_limit=0,writer_scope={'mode':'EXCLUSIVE','paths':['work']},output_path='06_build/task_runs/orientation-frame/attempt.json',completion={'outputs':['changes.json','evidence-manifest.json','evidence.tar.gz','judgment.md'],'checks':['inputs-verified','judgment-complete','processes-closed']})
o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(D/'06_build/task_runs/orientation-frame/envelope.json'),work_cutoff=cut.isoformat());Path('/tmp/carrier-orientation-frame-opened.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2))
