# Connector model/orientation source candidate

## Result

This is a reviewable source candidate, not an adopted board, placement approval,
full-board model-registration claim, or physical-fit result. It accounts for all
11 realised connectors and preserves the required human orientation stop.

- `P-MODEL-REG`: PASS, 3/3 groups, 11 instances and 75/75 drilled centres.
  J1-J8 maximum measured centre delta was 0.051342 mm; J9 was 0.009243 mm;
  J10/J11 were 0.021089/0.000178 mm. Every group measured 0.000 mm beyond
  F.Fab and courtyard in the native receipts.
- Signed mounting side: final Molex 43650-0400 front fraction 0.960061, Molex
  43650-0200 0.967976, and an explicit exact-board native J10/J11 run 0.830808;
  each exceeds the declared 0.75 minimum. The aggregate gate cannot request
  signed-side evidence for a vertical connector without also treating it as a
  planar edge connector, so the unchanged native engine was run directly for
  J10/J11 and its full receipt is retained.
- `P-ORIENT`: FAIL, 9/9 refs measured and 9 model-axis findings. The truthful
  encoded model mouth axis is VRML +Y because the source exporter maps
  footprint -Y to native +Y. The unchanged checker compares that raw vector
  directly with footprint -Y and reports -1.000000 for every side-entry ref;
  it omits KiCad's native-Y reflection and also uses stored model-rotation
  angles with the opposite sign from KiCad's renderer. Retained exact KiCad
  10.0.4 `create_scene.cpp` line 1942 and lines 2006-2024 establish those
  transforms (SHA-256 `54c3e3faf5c0c4d158f6584ee34021ef42145e11a240bc0e7c4a528be956f0f4`).
  The earlier forced footprint-frame `model_access_axis_local: [0,-1,0]`
  experiment produced machine 9/9 PASS and images, but it was rejected and is
  retained only as a counterexample. J1-J4 are intended north, J5-J8 south,
  and J9 west; realised rotations are 0, 180 and 90 degrees, with no
  270-degree side-entry instance. J10/J11 are explicitly
  exempt only from planar-edge orientation because their mating axis is +Z.
- Source checks: package-model tests 8/8 PASS; local placement-source tests
  11/11 PASS; all 13 model/library SHA entries PASS. The isolated contract
  audit passed its 5 project rule-file pairs but scanned 0 repository gate
  scripts, so no broader contract-audit claim is made.
- Inputs: all 336 packet members and all 173 method-manifest entries matched
  the designated live repository before the final native runs. The retained
  prior archive reopened 115/115 manifest members. Final verification after
  native work is retained in the package.

## Source decisions

`03_src/rules/model_registration.yaml` binds three exact model SHA groups.
The side-entry groups use drilled centres, explicit attachment/F.Fab/courtyard
tolerances, front mounting, pin 1, independent model/footprint axes, and the
Molex D8 locating-peg datum. The mating plane is 8.92 mm from the pin row:
4.32 mm pin-row-to-peg plus 4.60 mm peg-to-mouth. The allowed signed edge range
[-5.91, 4.95] mm is derived from 4.60 +/-0.35 mm and the drawing's 0..10.16 mm
peg-centre-to-edge bound. It is not copied from current coordinates. Current
nominal results remain -2.08 mm for J1-J8 and +0.92 mm for J9. Enclosure and
solder-seating tolerance stacks remain open.

The Molex models retain the drawing-derived 9.65/15.65 mm width, 9.90 mm depth,
5.57 mm conservative height, -8.92 mm front datum, +0.98 mm rear datum, exact
pitch and known board-entry tails. Their open rectangular face uses explicitly
undimensioned visual estimates (0.60 mm walls/roof, 1.18 mm cavity half-width,
rear Y=-2.25 mm and latch plan). The drawing establishes separate pitch-aligned
cavities and a central roof latch; those qualitative features are represented.
The depicted end-cavity lower chamfers, internal contacts, markings and locking
pegs remain omitted. The model does not prove latch/keying, mating fit, cable
service, or enclosure access. Exact manufacturer STEP retrieval remains
`FETCH_FAILED`, not `NO_CAD`. Independent root research also found the
exact-product Mouser primary-3D PDF and Molex IGES endpoints, but HTTP/2 failed
and explicit HTTP/1 attempts timed out after 30 seconds with zero bytes. Those
receipts are retained; no further retry was made.

The Samtec model exactly reproduces the previously qualified candidate SHA
`3a9f0dd56986b0a8b9fa5229f8fcd12451cb9b857a472bb36f87992f8f086737`.
It uses the selected style-01 drawing facts: 3.94 x 12 x 1.50 mm reference
body, 0.50 mm square pins, post A 3.20 mm, tail B 3.50 mm REF, total L 8.20 mm
REF and contact C 2.54 mm REF. The primary record now removes the incorrect
minimum wording for A/C. Grooves, chamfers, flash, bow, tilt and socket fit are
unmodeled. The exact footprint owns the model attachment; no circuit, netlist,
pad, TSX, or placement coordinate changed.

## Complete connector accounting

| Refs | Part/model | Registration | Orientation status |
|---|---|---|---|
| J1-J4 | Molex 43650-0400 | 4 instances / 24 centres, front-side PASS | north, 0-degree transforms; checker frame mismatch blocks P-ORIENT and human review |
| J5-J8 | Molex 43650-0400 | 4 instances / 24 centres, front-side PASS | south, 180-degree transforms; checker frame/sign mismatch blocks P-ORIENT and human review |
| J9 | Molex 43650-0200 | 1 instance / 3 centres, front-side PASS | west, 90-degree transform; checker frame/sign mismatch blocks P-ORIENT and human review |
| J10-J11 | Samtec TMM-106-01-L-D | 2 instances / 24 centres; direct signed-side PASS | top-entry +Z; planar-edge exemption only; pin1, labels, cable fit and simultaneous seating remain owed |

The prior archive's deliberately inverted Samtec control is retained in full.
It preserves XY/pin registration but fails the signed mounting-side channel at
0.534720 below 0.75, while the good prior control measured 0.825968. This is a
valid hostile control for the native channel, not evidence of current-board
physical fit.

## Preserved unsuccessful work and next action

The package retains initial setup errors (wrong SHA-check cwd, wrong isolated
test import path, and expected-count failures before the Samtec model moved to
its connector subdirectory) as well as all corrected runs. These were setup or
source-organization findings; no engineering failure was relabeled.

Next, independently review the proposed source bytes and native receipts. The
orientation checker owner must first reconcile native-model Y reflection and
stored rotation signs with KiCad's renderer using this retained counterexample;
this candidate does not authorize a checker edit. If the source is accepted,
adopt only the listed source members into the live project, regenerate the
board, rerun affected canonical source/model/orientation gates, and inspect
every registered image. Do not write human approval until the actual Molex
mouth/keying and cable approach are judged adequate; exact manufacturer CAD or
additional primary geometry is still needed for that predicate. J10/J11 still
require pin-1/label review and physical TCSD/miniDSP fit and simultaneous-seating
qualification. Routing and release remain blocked by their existing owners.
