from pathlib import Path
import sys,os,json
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');D=Path(__file__).parent;sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
r=run_stage({'id':'isolated-orientation-checkout','work_class':'local','timeout_s':120},['git','worktree','add','--detach',str(D/'work/repo'),'72bc4bd6'],log_path=D/'setup.log',cwd=R,env={'PATH':os.environ['PATH'],'HOME':os.environ['HOME'],'LANG':'C.UTF-8'},console_line_limit=3,console_tail_lines=2);(D/'setup.json').write_text(json.dumps(r.to_mapping(),indent=2)+'\n');assert r.status=='PASS'
