#!/usr/bin/env python3
"""Generate an asymmetric VRML marker and KiCad transform matrix coupons."""
import sys
from pathlib import Path
import pcbnew

out = Path(sys.argv[1]).resolve()
out.mkdir(parents=True, exist_ok=True)
model = out / "axis-marker.wrl"

def cube(cx, cy, cz, sx, sy, sz, color):
    pts=[]
    for z in (cz-sz/2, cz+sz/2):
        for y in (cy-sy/2, cy+sy/2):
            for x in (cx-sx/2, cx+sx/2):
                pts.append((x,y,z))
    faces=((0,1,3,2),(4,6,7,5),(0,4,5,1),(2,3,7,6),(0,2,6,4),(1,5,7,3))
    coord="\n   ".join(f"{x:.6f} {y:.6f} {z:.6f}," for x,y,z in pts)
    idx="\n   ".join(", ".join(map(str,f))+", -1," for f in faces)
    return f'''Shape {{
 appearance Appearance {{ material Material {{ diffuseColor {color} }} }}
 geometry IndexedFaceSet {{ solid TRUE
  coord Coordinate {{ point [
   {coord}
  ] }}
  coordIndex [
   {idx}
  ]
 }}
}}'''

# Units are KiCad VRML units (0.1 inch). Three unequal, offset markers make
# every model axis and handedness independently observable in exported meshes.
model.write_text("#VRML V2.0 utf8\n" + "\n".join([
    cube(0,0,0.25,0.4,0.4,0.5,"0.7 0.7 0.7"),
    cube(2,0,0.5,1.2,0.5,0.7,"1 0 0"),
    cube(0,3,0.7,0.5,1.5,0.9,"0 1 0"),
    cube(0,0,4,0.6,0.8,1.7,"0 0 1"),
]), encoding="utf-8")

board=pcbnew.BOARD()
board.SetFileName(str(out/"orientation-native.kicad_pcb"))
for a,b in [((0,0),(140,0)),((140,0),(140,100)),((140,100),(0,100)),((0,100),(0,0))]:
    s=pcbnew.PCB_SHAPE(board); s.SetLayer(pcbnew.Edge_Cuts); s.SetShape(pcbnew.SHAPE_T_SEGMENT)
    s.SetStart(pcbnew.VECTOR2I_MM(*a)); s.SetEnd(pcbnew.VECTOR2I_MM(*b)); s.SetWidth(pcbnew.FromMM(0.05)); board.Add(s)

rows=[]
for side, y in (("front",25),("back",75)):
  for i, angle in enumerate((0,90,180,270)):
    fp=pcbnew.FOOTPRINT(board); fp.SetReference(("F" if side=="front" else "B")+str(angle))
    fp.SetPosition(pcbnew.VECTOR2I_MM(20+i*33,y)); fp.SetOrientationDegrees(angle)
    if side=="back": fp.SetLayer(pcbnew.B_Cu)
    pad=pcbnew.PAD(fp); pad.SetNumber("1"); pad.SetAttribute(pcbnew.PAD_ATTRIB_NPTH)
    pad.SetShape(pcbnew.PAD_SHAPE_CIRCLE); pad.SetSize(pcbnew.VECTOR2I_MM(1,1)); pad.SetDrillSize(pcbnew.VECTOR2I_MM(1,1)); fp.Add(pad)
    m=pcbnew.FP_3DMODEL(); m.m_Filename=str(model); m.m_Scale=pcbnew.VECTOR3D(1.7,0.8,1.3); m.m_Rotation=pcbnew.VECTOR3D(31,23,47); fp.Models().append(m)
    board.Add(fp); rows.append(fp.GetReference())
pcbnew.SaveBoard(str(out/"orientation-native.kicad_pcb"),board)
print("generated", ",".join(rows))
