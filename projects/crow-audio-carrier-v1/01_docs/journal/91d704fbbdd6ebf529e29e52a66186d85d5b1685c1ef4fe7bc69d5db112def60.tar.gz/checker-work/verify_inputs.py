#!/usr/bin/env python3
import hashlib
import json
import tarfile
from pathlib import Path

root = Path("/tmp/carrier-orientation-frame-20260911")
envelope = json.loads((root / "06_build/task_runs/orientation-frame/envelope.json").read_text())
packet = []
for row in envelope["input_packet"]:
    path = root / row["path"]
    actual = {"size": path.stat().st_size,
              "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    assert actual == {"size": row["size"], "sha256": row["sha256"]}, row["name"]
    packet.append({"name": row["name"], "path": row["path"], **actual})

archive = root / "input/candidate.tar.gz"
manifest = json.loads((root / "input/candidate-manifest.json").read_text())
members = {}
with tarfile.open(archive, "r:gz") as stream:
    for info in stream.getmembers():
        assert info.isfile() and not info.name.startswith("/")
        assert ".." not in Path(info.name).parts and info.name not in members
        data = stream.extractfile(info).read()
        members[info.name] = {"size": len(data),
                              "sha256": hashlib.sha256(data).hexdigest()}
assert members == manifest["members"]
result = {"input_packet": {"graded": len(packet), "total": len(packet), "verdict": "PASS"},
          "candidate_archive": {"graded": len(members), "total": len(manifest["members"]),
                                "regular_unique_safe": True, "verdict": "PASS"},
          "packet": packet}
qualification = json.loads((root / "input/qualification.json").read_text())
deps = qualification["dependencies"]["files"]
verified_deps = 0
for name, expected in deps.items():
    path = Path(name)
    if not path.is_file():
        continue
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, name
    verified_deps += 1
result["native_qualification_dependencies"] = {
    "verified_present": verified_deps, "declared": len(deps),
    "coverage": qualification["coverage"], "verdict": "PASS"}
(Path(__file__).parent / "input-verification.json").write_text(
    json.dumps(result, indent=2, sort_keys=True) + "\n")
print(f"PASS inputs {len(packet)}/{len(packet)}; archive {len(members)}/{len(members)}")
