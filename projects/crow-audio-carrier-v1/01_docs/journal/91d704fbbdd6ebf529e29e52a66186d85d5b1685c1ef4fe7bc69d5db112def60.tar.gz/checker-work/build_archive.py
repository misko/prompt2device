#!/usr/bin/env python3
import hashlib
import json
import tarfile
from pathlib import Path

work = Path("/tmp/carrier-orientation-frame-20260911/work")
root = work / "archive-root"
archive = work / "delivery/evidence.tar.gz"
members = {}
with tarfile.open(archive, "w:gz") as stream:
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.is_symlink():
            continue
        name = path.relative_to(root).as_posix()
        data = path.read_bytes()
        members[name] = {"sha256": hashlib.sha256(data).hexdigest(),
                         "size": len(data)}
        info = stream.gettarinfo(str(path), arcname=name)
        assert info.isfile()
        with path.open("rb") as src:
            stream.addfile(info, src)
blob = archive.read_bytes()
manifest = {"archive": {"sha256": hashlib.sha256(blob).hexdigest(),
                         "size": len(blob)}, "members": members}
(work / "delivery/evidence-manifest.json").write_text(
    json.dumps(manifest, indent=2, sort_keys=True) + "\n")
print(f"PASS archive {len(members)} regular members {len(blob)} bytes")
