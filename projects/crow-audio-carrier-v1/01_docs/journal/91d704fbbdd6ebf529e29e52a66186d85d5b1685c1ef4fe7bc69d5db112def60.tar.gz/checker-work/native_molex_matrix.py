#!/usr/bin/env python3
"""Build a real-render matrix from the frozen asymmetric Molex model."""
import sys
from pathlib import Path
import pcbnew

out = Path(sys.argv[1]).resolve()
out.mkdir(parents=True, exist_ok=True)
model = Path("/tmp/carrier-orientation-frame-20260911/work/forensic/source/03_src/lib/3dmodels/derived/Molex_43650-0400_conservative-envelope.wrl")
board = pcbnew.BOARD()
board.SetFileName(str(out / "molex-transform-matrix.kicad_pcb"))
for a, b in [((0, 0), (180, 0)), ((180, 0), (180, 120)),
             ((180, 120), (0, 120)), ((0, 120), (0, 0))]:
    shape = pcbnew.PCB_SHAPE(board)
    shape.SetLayer(pcbnew.Edge_Cuts)
    shape.SetShape(pcbnew.SHAPE_T_SEGMENT)
    shape.SetStart(pcbnew.VECTOR2I_MM(*a))
    shape.SetEnd(pcbnew.VECTOR2I_MM(*b))
    shape.SetWidth(pcbnew.FromMM(0.05))
    board.Add(shape)

rows = []
for row, (side, model_rotation, scale) in enumerate((
        ("front", (0, 0, 0), (1, 1, 1)),
        ("back", (0, 0, 0), (1, 1, 1)),
        ("front", (31, 23, 47), (1.7, 0.8, 1.3)),
        ("back", (31, 23, 47), (1.7, 0.8, 1.3)))):
    for col, angle in enumerate((0, 90, 180, 270)):
        fp = pcbnew.FOOTPRINT(board)
        ref = ("F" if side == "front" else "B") + ("T" if row >= 2 else "") + str(angle)
        fp.SetReference(ref)
        fp.SetPosition(pcbnew.VECTOR2I_MM(24 + col * 44, 18 + row * 29))
        fp.SetOrientationDegrees(angle)
        if side == "back":
            fp.SetLayer(pcbnew.B_Cu)
        pad = pcbnew.PAD(fp)
        pad.SetNumber("1")
        pad.SetAttribute(pcbnew.PAD_ATTRIB_NPTH)
        pad.SetShape(pcbnew.PAD_SHAPE_CIRCLE)
        pad.SetSize(pcbnew.VECTOR2I_MM(1, 1))
        pad.SetDrillSize(pcbnew.VECTOR2I_MM(1, 1))
        fp.Add(pad)
        attachment = pcbnew.FP_3DMODEL()
        attachment.m_Filename = str(model)
        attachment.m_Rotation = pcbnew.VECTOR3D(*model_rotation)
        attachment.m_Scale = pcbnew.VECTOR3D(*scale)
        fp.Models().append(attachment)
        board.Add(fp)
        rows.append({"ref": ref, "side": side, "footprint_rotation_deg": angle,
                     "model_rotation_deg": model_rotation, "scale": scale})

pcbnew.SaveBoard(str(out / "molex-transform-matrix.kicad_pcb"), board)
import json
(out / "matrix-cases.json").write_text(json.dumps(rows, indent=2) + "\n")
print(f"generated {len(rows)} asymmetric native-model cases")
