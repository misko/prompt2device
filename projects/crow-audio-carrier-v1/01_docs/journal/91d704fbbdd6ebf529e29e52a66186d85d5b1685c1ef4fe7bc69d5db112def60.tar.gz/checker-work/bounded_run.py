#!/usr/bin/env python3
import json
import os
import sys
from pathlib import Path
from types import SimpleNamespace

repo = Path("/tmp/carrier-orientation-frame-20260911/work/repo")
sys.path.insert(0, str(repo / "skills/pcb-design/scripts"))
from pipeline_runtime import run_stage

timeout = float(sys.argv[1])
log = Path(sys.argv[2])
cwd = Path(sys.argv[3])
command = sys.argv[4:]
spec = SimpleNamespace(id="ORIENTATION-NATIVE", work_class="local", timeout_s=timeout)
env = dict(os.environ)
env.update({
    "HOME": os.environ["HOME"],
    "PATH": os.environ["PATH"],
    "LANG": "C.UTF-8",
    "LC_ALL": "C.UTF-8",
    "PYTHONDONTWRITEBYTECODE": "1",
})
outcome = run_stage(spec, command, log_path=log, cwd=cwd, env=env,
                    heartbeat_s=10, console_line_limit=200)
receipt = outcome.to_mapping()
receipt["argv"] = command
receipt["cwd"] = str(cwd.resolve())
receipt["environment"] = {
    "HOME": env["HOME"], "PATH": env["PATH"], "LANG": env["LANG"],
    "LC_ALL": env["LC_ALL"],
    "PYTHONDONTWRITEBYTECODE": env["PYTHONDONTWRITEBYTECODE"],
}
log.with_name(log.name + ".runtime.json").write_text(
    json.dumps(receipt, indent=2, sort_keys=True) + "\n")
print(json.dumps(receipt, sort_keys=True))
raise SystemExit(0 if outcome.status == "PASS" else 1)
