#!/usr/bin/env python3
import hashlib
import json
import tarfile
from pathlib import Path

work = Path("/tmp/carrier-orientation-frame-20260911/work")
delivery = work / "delivery"
manifest = json.loads((delivery / "evidence-manifest.json").read_text())
archive = delivery / "evidence.tar.gz"
assert {"sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
        "size": archive.stat().st_size} == manifest["archive"]
observed = {}
with tarfile.open(archive, "r:gz") as stream:
    for info in stream.getmembers():
        assert info.isfile() and not info.issym() and not info.islnk()
        assert not info.name.startswith("/") and ".." not in Path(info.name).parts
        assert info.name not in observed
        data = stream.extractfile(info).read()
        observed[info.name] = {"sha256": hashlib.sha256(data).hexdigest(),
                               "size": len(data)}
assert observed == manifest["members"]
changes = json.loads((delivery / "changes.json").read_text())
for row in changes:
    member = "source/" + row["path"]
    assert observed[member]["sha256"] == row["after_sha256"], member
result = json.loads((delivery / "result.json").read_text())
assert set(result) == {"subject", "checks", "unresolved"}
print(f"PASS delivery archive {len(observed)} members; {len(changes)} source changes")
