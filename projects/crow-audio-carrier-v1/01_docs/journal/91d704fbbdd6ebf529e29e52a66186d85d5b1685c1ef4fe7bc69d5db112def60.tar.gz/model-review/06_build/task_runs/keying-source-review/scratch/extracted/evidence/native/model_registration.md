# Project native model physical registration

board_sha256: 7765810d8f9734f0ff893f7411ae80628ccddf5e78a78ee920a3303e9d2a8631
a-render_verdict: PASS
registration_kind: P-MODEL-REG
config_sha256: 9a86f163d286ce8809e0cca523cd23dacae3017b0b688f8022ae5ea5617c1217
stage_receipt: 06_build/pre_route/model_registration.stage.json
accepted_bundle: 06_build/pre_route/model_registration_bundle/bundle.json

This aggregate is independent physical-registration evidence. Each group uses an origin-centred coupon and compares native-model pixels with F.Fab, F.CrtYd, and each group's declared drilled-centre or all-pad-centre datum. Catalog-twin renderer fidelity is a separate gate.

| group | refs | tuple cache key | group report | result |
|---|---|---|---|---|
| molex-43650-0400-side-entry | J1,J2,J3,J4,J5,J6,J7,J8 | `4c5695e1c42eebb6613a5ef9b23b34614afd1ac51b8c6044efaf1f705fff288e` | `06_build/pre_route/native_registration/molex-43650-0400-side-entry/native_model_registration.md` | PASS |
| molex-43650-0200-side-entry | J9 | `b5170ee09bcf5876c469b8569cd364e7f199839ac29c826af534cf98213b3082` | `06_build/pre_route/native_registration/molex-43650-0200-side-entry/native_model_registration.md` | PASS |
| samtec-tmm-106-01-l-d-top-entry | J10,J11 | `ce7b1d813edbf5fa3b8ebd5ac769adddb920e5a866b1ca6d291cdb544c4b8f25` | `06_build/pre_route/native_registration/samtec-tmm-106-01-l-d-top-entry/native_model_registration.md` | PASS |
