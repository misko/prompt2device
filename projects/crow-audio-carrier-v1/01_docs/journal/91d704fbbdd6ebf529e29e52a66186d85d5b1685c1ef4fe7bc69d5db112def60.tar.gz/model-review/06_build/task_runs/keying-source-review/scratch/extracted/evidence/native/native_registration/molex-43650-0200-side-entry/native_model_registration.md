# Native model physical registration — `native_top.png`

board_sha256: 7765810d8f9734f0ff893f7411ae80628ccddf5e78a78ee920a3303e9d2a8631
coupon_sha256: aeb04c8d252b2de830c2b6556306f962a34b95ada35cf665dbfb22bfa0006862
a-render_verdict: PASS
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 301488732bd715060f80583e9cc8936bbbbd584dbe14055705d89d0d37442ffb
footprint_registration_datum_sha256: 6a5bf2c9f358f7f1fcdbf41f0880f537919665e7370490df5af969cd68431aa3
model_transform_sha256: 6cf53f0e2e5e9c07c31120b0a7392007f28e50daeb9d9b4fabcff69a71234dd2
registration_contract_sha256: b7c94d70d41f27db0a5b2ba21ffcffbac2d4378d5d6db72bbc07041e5414d740
tuple_cache_key: b5170ee09bcf5876c469b8569cd364e7f199839ac29c826af534cf98213b3082
calibration_px_per_mm: 58.5526 x, 58.5683 y
anisotropy: 0.9997
fit_tolerance_mm: 0.350
courtyard_containment_tolerance_mm: 0.350
registration_datum: drilled_centres
mount_side: front
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 0.967920
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected drilled_centres field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | registration centres inside | min pad margin mm |
|---|---:|---:|---:|---:|---:|
| J9 | 0.009 | 0.000 | 0.000 | 3/3 | 0.986 |

## Failures

- none
