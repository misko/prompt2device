# Native model physical registration — `native_top.png`

board_sha256: 7765810d8f9734f0ff893f7411ae80628ccddf5e78a78ee920a3303e9d2a8631
coupon_sha256: bd2d7c7f960082342faa83d43c23be023b0a4a3d6e799d7539e8cd5976a68cc6
a-render_verdict: PASS
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 3a9f0dd56986b0a8b9fa5229f8fcd12451cb9b857a472bb36f87992f8f086737
footprint_registration_datum_sha256: e94002f06e208e0d26e6dba6fab90fe1be1b8ce399e837ff3575288a64ab6247
model_transform_sha256: 6cf53f0e2e5e9c07c31120b0a7392007f28e50daeb9d9b4fabcff69a71234dd2
registration_contract_sha256: f5fec085c4befa81b6d7cd26fda3fa337699acf60e5f65bef6896624bf7c899d
tuple_cache_key: ce7b1d813edbf5fa3b8ebd5ac769adddb920e5a866b1ca6d291cdb544c4b8f25
calibration_px_per_mm: 47.8215 x, 47.7960 y
anisotropy: 1.0005
fit_tolerance_mm: 0.150
courtyard_containment_tolerance_mm: 0.250
registration_datum: drilled_centres
mount_side: not-graded
mount_side_min_fraction: 0.750
mount_side_measured_fraction: N/A
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected drilled_centres field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | registration centres inside | min pad margin mm |
|---|---:|---:|---:|---:|---:|
| J10 | 0.021 | 0.000 | 0.000 | 12/12 | 0.945 |
| J11 | 0.000 | 0.000 | 0.000 | 12/12 | 0.965 |

## Failures

- none
