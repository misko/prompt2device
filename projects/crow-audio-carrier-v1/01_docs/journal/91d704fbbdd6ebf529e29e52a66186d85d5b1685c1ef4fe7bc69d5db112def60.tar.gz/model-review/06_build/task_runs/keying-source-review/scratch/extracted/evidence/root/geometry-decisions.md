# Drawing-derived connector keying revision

Root owns this isolated candidate only. Base is the unadopted 13-file source candidate from terminal INCOMPLETE attempt, archive6d6fa595ed5cc253b3cbd1aa5a69ad05e014a45de980c77389a2f431ae0a989a. No live source adoption.

MEASURED visual inspection of exact SD43650001/D8 sheet1 establishes separate pitch-aligned cavity profiles, two lower outer end chamfers, contact pins and front roof latch. The prior candidate omitted the chamfers and placed its latch by the rear pin row; both are corrected here. Specified outer extents, pitch and tails are retained. Undimensioned internal/locating profiles are explicitly illustrative, not scaled from NTS drawing pixels and not mating-fit authority. Native registration/render evidence follows. Truthful model mouth axis remains native+Y versus footprint-Y; checker correction is separately owned.
