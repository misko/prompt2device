# Native model physical registration — `native_top.png`

board_sha256: 7765810d8f9734f0ff893f7411ae80628ccddf5e78a78ee920a3303e9d2a8631
coupon_sha256: c6c38069a77fa56e5063e839bbe333a7a054c527ac5c011b4599589bab92a052
a-render_verdict: PASS
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 3849c086f3e3f2ff66066be3093cc1d2405e7248d42501811832249367b5e878
footprint_registration_datum_sha256: a0a5174c9c64692eef61f02b6c5ad41bc97dd7b9c86140a19e16bffcb5ba5d27
model_transform_sha256: 6cf53f0e2e5e9c07c31120b0a7392007f28e50daeb9d9b4fabcff69a71234dd2
registration_contract_sha256: 4c5c826c188e11a940f16363d546f617f218ab0ef3f0918ca3dfd4b8f0e3224f
tuple_cache_key: 4c5695e1c42eebb6613a5ef9b23b34614afd1ac51b8c6044efaf1f705fff288e
calibration_px_per_mm: 18.7728 x, 18.7702 y
anisotropy: 1.0001
fit_tolerance_mm: 0.350
courtyard_containment_tolerance_mm: 0.350
registration_datum: drilled_centres
mount_side: front
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 0.960006
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected drilled_centres field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | registration centres inside | min pad margin mm |
|---|---:|---:|---:|---:|---:|
| J1 | 0.043 | 0.000 | 0.000 | 6/6 | 0.919 |
| J2 | 0.039 | 0.000 | 0.000 | 6/6 | 0.919 |
| J3 | 0.040 | 0.000 | 0.000 | 6/6 | 0.919 |
| J4 | 0.051 | 0.000 | 0.000 | 6/6 | 0.910 |
| J5 | 0.048 | 0.000 | 0.000 | 6/6 | 0.910 |
| J6 | 0.049 | 0.000 | 0.000 | 6/6 | 0.910 |
| J7 | 0.035 | 0.000 | 0.000 | 6/6 | 0.954 |
| J8 | 0.031 | 0.000 | 0.000 | 6/6 | 0.954 |

## Failures

- none
