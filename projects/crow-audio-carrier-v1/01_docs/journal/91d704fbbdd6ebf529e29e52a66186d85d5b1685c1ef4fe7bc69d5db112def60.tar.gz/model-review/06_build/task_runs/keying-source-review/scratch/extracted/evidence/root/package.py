from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,io
D=Path(__file__).parent;P=D/'project';R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');L=R/'projects/crow-audio-carrier-v1';sha=lambda b:hashlib.sha256(b).hexdigest()
changes=[];payload={}
for top in ['02_parts','03_src']:
 for p in sorted((P/top).rglob('*')):
  if not p.is_file() or p.is_symlink() or '__pycache__' in p.parts:continue
  rel=p.relative_to(P).as_posix();b=p.read_bytes();old=(L/rel).read_bytes() if (L/rel).exists() else None
  if b==old:continue
  changes.append({'path':rel,'before_sha256':sha(old) if old is not None else None,'after_sha256':sha(b)});payload['source/'+rel]=b
for p in (P/'06_build/pre_route').rglob('*'):
 if p.is_file() and not p.is_symlink():payload['evidence/native/'+p.relative_to(P/'06_build/pre_route').as_posix()]=p.read_bytes()
for p in (D/'samtec-signed-side').rglob('*'):
 if p.is_file() and not p.is_symlink():payload['evidence/samtec-signed-side/'+p.relative_to(D/'samtec-signed-side').as_posix()]=p.read_bytes()
for rel in ['02_parts/43650-0400/Molex_436501000_SD_revD8.pdf','02_parts/TMM-106-01-L-D/TMM-Series_RevAS.pdf','04_kicad/crow_audio_carrier_v1.kicad_pcb','04_kicad/crow_audio_carrier_v1.kicad_pro','03_src/floorplan.yaml']:
 payload['evidence/project/'+rel]=(P/rel).read_bytes()
for p in D.iterdir():
 if p.is_file() and p.suffix in ['.py','.md','.json','.log','.png'] and p.name not in ['candidate-manifest.json','changes.json']:
  payload['evidence/root/'+p.name]=p.read_bytes()
(D/'changes.json').write_text(json.dumps({'changes':changes},indent=2)+'\n')
payload['changes.json']=(D/'changes.json').read_bytes()
with tarfile.open(D/'candidate.tar.gz','w:gz') as t:
 for name,b in sorted(payload.items()):
  i=tarfile.TarInfo(name);i.size=len(b);i.mtime=0;t.addfile(i,io.BytesIO(b))
b=(D/'candidate.tar.gz').read_bytes();m={'archive':{'sha256':sha(b),'size':len(b)},'members':{name:{'sha256':sha(data),'size':len(data)} for name,data in sorted(payload.items())}}
(D/'candidate-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
with tarfile.open(D/'candidate.tar.gz','r:gz') as t:
 assert len(t.getmembers())==len(payload)
 for x in t.getmembers():assert x.isfile() and t.extractfile(x).read()==payload[x.name]
print(json.dumps({'archive':m['archive'],'members':len(payload),'source_changes':len(changes)}))
