# Molex 43650-0200 primary-source fact record

Accessed: 2026-09-01
Authority status: cited exact manufacturer product and drawing facts; raw PDF bytes still owed

Primary records:

- [Molex 43650-0200 exact product record](https://www.molex.com/en-us/products/part-detail/436500200)
- [Molex 43650 family sales drawing](https://www.molex.com/content/dam/molex/molex-dot-com/products/automated/en-us/salesdrawingpdf/436/43650/436500500_sd.pdf)
- [Molex Micro-Fit 3.0 product specification PS-43650-001](https://www.molex.com/content/dam/molex/molex-dot-com/products/automated/en-us/productspecificationpdf/436/43650/PS-43650-001.pdf)

Exact two-circuit facts used by J9:

- orderable part `43650-0200`, two circuits, right-angle through-hole header;
- 3.00 mm contact pitch, 1.02 +/-0.05 mm signal holes, and 1.60 mm
  recommended PCB thickness;
- two-circuit drawing dimension A = 9.65 mm and B = 3.00 mm;
- shrouded mating interface, polarized to the PCB, with the mating face at the
  carrier west edge;
- supported mating housing family `43645`, with 17.56 mm overall mated length;
- product current rating 8.5 A per contact and operating range -40 to +105 C.

The selected J9 harness draws 0.90 A maximum by design, below both the exact
contact rating and the conservative 5 A IEC family value used for screening.
The board admits only a protected, isolated 11.4-13.2 V appliance source at
J9. The connector does not create a PoE, safety-isolation, hot-plug,
overvoltage-cutoff, or reverse-polarity function.

This ordinary record closes source identity and a conservative body envelope.
It does not prove populated seating, enclosure exposure, latch access, or
mating reaction.
