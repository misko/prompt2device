# Project-local footprint authority

These footprints are copied into the carrier so regeneration and review do not
depend on an ambient KiCad library revision.

`Molex_43650-0400_RA_Exact` is not a generic four-hole row. It contains four
3.00 mm-pitch plated signal holes, the two 3.00 mm non-plated locating/retention
holes, the polarized shrouded body outline, courtyard, pin-1 feature and outward mating-face
geometry of the selected right-angle 43650-0400. The footprint is used only for
J1-J8 and no compatible-alternative MPN is authorized. Its copied KiCad source
hash is `fa8877b1c3d305e884b95425f71714a3fb8bfbb6de6a08eb5707748f90c16fb7`.

`Molex_43650-0200_RA_Exact` applies the same drawing-controlled 3.00 mm signal
pitch, locating holes, body/mouth geometry and pin-1 convention to J9. Its
source hash is
`80ce662b23a6fa57b22b1db345c1e86cdac68dcfa7d9f1a9becaae7cddace94f`.

`Samtec_TMM-106-01-L-D_2x06_P2.00mm_Vertical` freezes the twelve-pad 2.00 mm
TMM-106-01-L-D land pattern used for MCHStreamer J1/J3 breakouts J10/J11. Its
source hash is
`43053a5fb3a69bbf33366a5df001c4ce228d7d01883aa4b81ef5e389d2789cdb`.
The exact selected mate is Samtec `TCSD-06-D-04.50-01`, but footprint identity
does not close the cable-assembly contract: miniDSP's board-header MPN is not
published, so module-side post fit, one-to-one continuity, socket rotation,
strain relief and simultaneous J1/J3 service access remain physical-evidence
holds.

`Cirrus_CS5308P_QFN48_6x6_P0.4_EP4.6` freezes the 48 perimeter lands and single
4.6 x 4.6 mm exposed pad. It deliberately contains no thermal vias: a selective
via-in-pad process has not been authorized. Its copied KiCad source hash was
`3b4488a5d5251cff1f4c5a1cbc7355e90d478598e7de57dd9e0e03139b8bcaee`.

`Littelfuse_SMBJ15A_SMB_Exact` freezes cathode pad 1 and the 2.50 x 2.30 mm
lands at 4.30 mm centre spacing for the input shunt clamp. Its source hash is
`63dee0873b808ac7598ebc60e3f32e22b322d87edf7e9d9e9aadd90a8a9ee7dd`.

`Coilcraft_XGL4020_Exact` freezes the manufacturer's 0.98 x 3.40 mm lands at
2.37 mm centre spacing and the 4.0 x 4.0 mm body/start-lead orientation. Its
source hash is
`f7ba0a0852797b7d837c9f113f6403b215d540618a89bf52f20d0fe066cf96d3`.
No exact supplier XGL4020 CAD is vendored. The2026-09-08 model-source backtrack
adds a reproducible nominal drawing-derived body and terminal envelope;
registration and physical qualification remain separate placement holds.

Primary drawing/PDF identities are owned by the matching `02_parts` dossiers.
Where a dossier still declares a null local path or digest, retrieval remains
OWED and cannot support placement approval. Before placement review, compare
every pad, locating hole, body edge, courtyard, pin-1 mark and mating-axis
annotation to ordinary digest-selected authority bytes.

`Panasonic_EEEFK1A471P_8x10.2_Exact` is the standard-terminal Panasonic FK
size-F land, not the vibration-proof `V`-suffix land. The official FK catalog
gives `a=3.1`, `b=4.0`, `c=2.0 mm`; the resulting pad centres are
`+/-3.55 mm`, with pad 1 positive. KiCad 10 has no stock `CP_Elec_8x10.2`
module, and the nearby `CP_Elec_8x10.5` land is not footprint authority (its
3D envelope is reused only as a conservative model).

## Source-owned models — 2026-09-08

`3dmodels/provenance.md` owns the exact public URLs, immutable KiCad commit,
retained licence, PDF hashes/pages, nominal/conservative interpretation and
omitted detail for the47-reference/ten-family model-source backtrack.
`3dmodels/SHA256SUMS` pins every model and the unmodified upstream licence.
`../build_package_models.py` reproduces ten dimension-derived VRML files;
the eleventh model is an unmodified KiCad capacitor STEP. Stock capacitor/fuse
footprints use narrowly enumerated `floorplan.yaml` model overrides, while
seven existing custom footprints change model clauses only. No stock
footprint is copied and no pads, graphics or electrical identities change.

The Molex representations are intentionally conservative housings with known
board-entry tails, not exact supplier CAD; cavities, pegs and service/mating
details remain unmodeled. All current-board/checkpoint evidence is STALE for
the changed model source until the coordinator deliberately regenerates it.
Temporary package-coupon evidence never promotes the current board.

The2026-09-09 addition `Vishay_WSLP1206_50m_Exact` retains its original copper,
graphics and pin convention; only its model clause is added. The drawing-derived
model uses the exact50mOhm terminal row of Vishay30122, not a generic1206 body.
Its nominal3.20x1.60x.635mm envelope does not cover production maxima. The prior
nine generated VRML files remain byte-identical; provenance documents all
omissions. Native model attachment does not close the feed-loop electrical or
thermal analysis and is not current-board registration acceptance.
