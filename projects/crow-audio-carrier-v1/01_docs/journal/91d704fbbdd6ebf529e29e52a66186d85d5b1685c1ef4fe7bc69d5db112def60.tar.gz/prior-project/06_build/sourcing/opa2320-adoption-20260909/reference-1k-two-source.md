# Shopping list — reference-sourcing-candidate

Generated `2026-09-09 20:42 UTC` by `shopping_list.py` (scope `all`, 5 board set(s), stock floor `> 10`).

**Every number here is a dated OBSERVATION, not a fact.** Stock and price move; re-run before you pay. Each row carries its M-IMPORT grade: **CITED** = machine-readable API response or a product page read with its URL and date · **ESTIMATED** = volatile/unverifiable · **OWED** = nobody has this number yet.

## Coverage (Q-COVER)

- parts in `02_parts/`: **1**
- selected for this list (`all`): **1**
- **mouser**: graded **0/1**, sourceable **0/1**
- **digikey**: graded **1/1**, sourceable **1/1**
- **amazon**: graded **0/1**, sourceable **0/1**
- **jlc/lcsc snapshot**: graded **1/1**, sourceable **1/1**

## Composed authorized-pool gate (Q-2SOURCE)

Each exact manufacturer/MPN row must clear **2** of these independent authorized pools: jlc, mouser, digikey. Amazon is marketplace evidence and never counts. A JLC/LCSC catalog PASS is selection evidence, not proof that the assembly uploader will allocate stock.

| exact manufacturer / MPN | needed | qualifying pools | result |
|---|---:|---|---|
| YAGEO / `RC0402FR-071KL` | 10 | jlc, digikey | **PASS 2/2** |

**COMPOSED-POOLS PASS:** 1/1 exact rows meet the 2-pool requirement.

## Is there one distributor that has everything?

**Yes — digikey** covers all 1 selected lines at stock > 10.

## Mouser

*Method: Mouser Search API (search/partnumber). TWO searches per part: `Exact` on the authoritative MPN, then `None` on the suffix-stripped MPN — one part has several catalog records and they disagree. CITED.*

| MPN | qty | dist. part no. | stock | factory / lead | min/mult | lifecycle | unit @ break | extended | grade | status | link |
|---|---:|---|---:|---|---|---|---:|---:|---|---|---|
| `RC0402FR-071KL` | 10 | — | — | — | —/— | — | — | — | OWED | LOOKUP-FAILED | — |

**mouser total: INCOMPLETE — $0.00 covers only 0 of 1 lines.** A total over a partial list is not a total. Only SOURCEABLE lines are summed: pricing a line you cannot order at the quantity you need (0 stock, or an MOQ above the need) gives a number that is arithmetically right and operationally false. The missing lines are named below.

## Digikey

*Method: PRODUCT PAGE read by a human and recorded in 01_docs/sourcing/manual_quotes.yaml. No API key available (OAuth client credentials not provided). CITED from a product page; a search snippet is REFUSED.*

| MPN | qty | dist. part no. | stock | factory / lead | min/mult | lifecycle | unit @ break | extended | grade | status | link |
|---|---:|---|---:|---|---|---|---:|---:|---|---|---|
| `RC0402FR-071KL` | 10 | 311-1.00KLRCT-ND | 6348432 | — | 1/1 | Active | $0.0210 @ 10 | $0.21 | CITED | OK | [page](https://www.digikey.com/en/products/detail/yageo/RC0402FR-071KL/729460) |

**digikey total: $0.21** — all 1 lines sourceable and priced.

## Amazon

*Method: Direct product links only, hand-recorded. No usable API (PA-API needs an affiliate account). ESTIMATED, always — stock and price are volatile and unverifiable.*

| MPN | qty | dist. part no. | stock | factory / lead | min/mult | lifecycle | unit @ break | extended | grade | status | link |
|---|---:|---|---:|---|---|---|---:|---:|---|---|---|
| `RC0402FR-071KL` | 10 | — | — | — | —/— | — | — | — | OWED | NO-QUOTE | — |

**amazon total: INCOMPLETE — $0.00 covers only 0 of 1 lines.** A total over a partial list is not a total. Only SOURCEABLE lines are summed: pricing a line you cannot order at the quantity you need (0 stock, or an MOQ above the need) gives a number that is arithmetically right and operationally false. The missing lines are named below.

## Every Mouser catalog record seen, per part

One physical part has SEVERAL catalog records and they disagree — that is the expected case, not an anomaly, so every record is printed with its own numbers and the one this list picked is marked. A record whose manufacturer part number is not the authoritative MPN (modulo packaging/plating suffixes) is a **substitute proposal for a human**, never a sourced line (Q-IDENT).

| MPN asked | search | mfr part no. | Mouser no. | stock | lifecycle | factory / lead | same part? | used |
|---|---|---|---|---:|---|---|---|---|
| `RC0402FR-071KL` | `RC0402FR-071KL`/Exact + `RC0402FR-071KL`/None | — | — | — | — | — | — | **LOOKUP-FAILED** |

## Distributor gaps — every unavailable line and why

| MPN | qty | distributor | status | why |
|---|---:|---|---|---|
| `RC0402FR-071KL` | 10 | mouser | **LOOKUP-FAILED** | --offline and no cached/replayed response; --offline and no cached/replayed response |
| `RC0402FR-071KL` | 10 | amazon | **NO-QUOTE** | no amazon quote recorded. Open the PRODUCT PAGE (never a search snippet) and add an entry to 01_docs/sourcing/manual_quotes.yaml with its url and read_on date; Amazon has no usable API (PA-API needs an affiliate account) so this stays ESTIMATED even once recorded |

## What each line is, and why it is on this list

| MPN | mfr | qty | refs | why self-supplied |
|---|---|---:|---|---|
| `RC0402FR-071KL` | YAGEO | 10 | candidate: R_VMID1_ISO, R_VMID2_ISO | — |

## DigiKey: what would make these rows CITED

```
DigiKey HAS an API and this tool does not use it, because it needs OAuth 2.0
client credentials nobody has provided and an agent cannot create an account or
obtain a key. To promote every DigiKey row from ESTIMATED/OWED to CITED:

  1. Sign in at https://developer.digikey.com/ with a DigiKey account.
  2. Create an Organization, then a PRODUCTION app (Sandbox returns
     structurally-correct but incomplete data — do not source from it).
  3. Subscribe the app to **Product Information V4**.
  4. Copy the app's **Client ID** and **Client Secret**.
  5. Append them to `<repo>/.secrets/digikey.env` (mode 600; `.secrets/` is
     already gitignored):
         DIGIKEY_CLIENT_ID=...
         DIGIKEY_CLIENT_SECRET=...
  6. Tell me, and the 2-legged flow (POST client_id + client_secret +
     grant_type=client_credentials to https://api.digikey.com/v1/oauth2/token,
     then GET /products/v4/search/{mpn}/productdetails) becomes a peer of the
     Mouser path.

Until then DigiKey numbers come only from a PRODUCT PAGE a human opened,
recorded in `01_docs/sourcing/manual_quotes.yaml` with its URL and read date.
NEVER from a search-results snippet — that is the GHR-10V-S defect.
```
