Comment,Designator,Footprint,LCSC,qty,required_qty,stock_threshold,absolute_surplus,status,code,type,stock,mpn,manufacturer,pkg,price
1k,"R_VMID1_ISO,R_VMID2_ISO",0402,C106235,2,10,10,4461809,OK,C106235,expand,4461819,RC0402FR-071KL,YAGEO,0402,0.0044
