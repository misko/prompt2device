Comment,Designator,Footprint,LCSC,qty,required_qty,stock_threshold,absolute_surplus,status,code,type,stock,mpn,manufacturer,pkg,price
OPA2320AIDR,"U_AFE1,U_AFE2,U_AFE3,U_AFE4,U_AFE5,U_AFE6,U_AFE7,U_AFE8,U_AFE9",SOIC-8,C2863402,9,45,45,3056,OK,C2863402,expand,3101,OPA2320AIDR,Texas Instruments,SOIC-8,2.1038
