# Exact ADC2 reservation source review

**SOUND for the complete three-file source proposal.** The changed local return-reservation premise supports root consideration of **at most one cumulative native candidate5**, retaining all four prior observations and spend. This review does not admit that candidate, reopen the cap, approve placement, or close the six existing broad contract failures. No candidate6 or budget reset is supported.

Exact envelope canonical SHA256: `baf6ea13d7a739d989d8b15b9ed852d2d5b0dcc7faa74aedc0ed29f300ed4a48`. All 354 frozen inputs verified before and after. The 165-file project census confirms exactly these three postimages; all other project bytes remain equal to their frozen preimages.

| Reviewed file under projects/crow-audio-carrier-v1 | Before SHA256 | Proposed SHA256 |
|---|---|---|
| 03_src/floorplan.yaml | d0cb9930e75cbd4e58ebb6856743eb339db413ecb239d19e0203c781face3c39 | 0fd6d3e0f7c138f1dcfe49fc994fb66c676a46e1616b6a2e5b04c13c6e7b69cc |
| 03_src/tests/test_adc_feed_source.py | 84ee1d1704d4e3c65c5637fc5f08dcc1cc08f0340118d275cac40ea57651c951 | 4ad8a36ec64170a775f7415799bb0f2f7d87426f0efc40e36f270cc829bc9adf |
| 01_docs/decisions/0015-adc-supply-feeds.md | 667980af531aa36ad2ec321fe914a56627ca97195d32c1175937cd5f11f9bad6 | ee7846f6b7220a864d741d280ef8926cdccd354934369e497f7e00ff88a70fda |

The complete author archive was reopened: all 79 regular members match its declared size/hash manifest, including exact before/after postimages. No unsafe archive members were accepted.

## Independent geometric proof

`methods/geometry.py` uses Python Fraction arithmetic to split every old-polygon edge against every rectangle edge. It retains each subedge whose exact midpoint is outside the other polygon, rounds rational intersection coordinates to native nanometres, and compares every resulting undirected edge with the proposed polygon. This does not invoke KiCad BooleanAdd or import the author's union method. All 50 edges match. Graph degree and traversal prove one connected cycle; nonadjacent segment intersection checks find zero crossings. There are no holes. Independent old-only, rectangle-only and extra-region controls all fail the same boundary-equality predicate.

The rectangle is x89.99..91.05, y70.94..72.06mm. Native pad geometry independently gives C_VDDA2_10N.2 at (90.52,71.50), GND, with bbox x90.24..90.80, y71.19..71.81mm. Expanding that bbox by the unchanged 0.25mm GND zone clearance derives the exact rectangle and covers the whole rounded land. The resulting boundary is precisely the union at 1nm representation precision: no old protected branch is removed and no unrelated area is added. Old area is 6.112501286950mm², new area 6.836173067830mm²; their difference is 0.723671780880mm². Native subtraction's clipped added region reports 0.723671839675mm². The 5.8795e-8mm² difference is clipping at rounded slanted intersections, not a claim of exact real-coordinate set equality.

The actual consumer's pure simple-polygon validator passes. All 50 points round-trip through VECTOR2I_MM. Consumer source explicitly maps deny:pours to zone-fill prohibition, leaves tracks/vias permitted, and applies the F.Cu layer set before appending the polygon. No board-producing consumer method was invoked.

## Ownership, population and preserved floors

The complete inventory contains 985 source copper pads, 391 source segments, 43 source vias and all 83 source regions. Each existing native board contributes all 1009 F-layer pad records, including the 21 non-copper records excluded by a copper-only census. Every F-pad record is identical between retained placement and prepared stages. Native F-layer track/via inventories contain 11 and 444 items respectively. Full native-shape contact, not bbox overlap alone, grades affected copper.

Only C_VDDA2_10N.2 contacts the added region among all pads. Exactly two 0.18mm 3V3_ADC source/prepared segments contact added area: (91.48,71.5)→(91.1,72.02) and (91.1,72.02)→(90.6,72.3). No via does. The full rectangle also crosses existing GND return segments inside the old reservation; these are separately recorded and not mislabeled as newly obstructed copper. Pour prohibition does not prohibit those tracks.

Added-area overlaps occur with the permissive ADC_WEST_LOCAL, ADC_CFG_SOUTH_LOCAL, ADC_CFG_SOUTH_PITCH and ADC_FEED_SOUTH regions, and the owning pour reservation. The unchanged ADC_VMID2_RETURN_VIAS_1 has only a 4.26847e-7mm² clipped boundary fringe; VIA-reservation2 has zero-area boundary contact. No designated via is excluded. Every intersecting and nonintersecting row is retained in inventory.json.

The explicit contact graph from the target reaches exactly U_ADC.8, both VMID2 capacitor ground pads, and U_ADC.8:via0. It does not reach ADC6 or paddle49 through these explicit F.Cu primitives. U_ADC.8 remains GND_A2; its three-segment 0.18mm seed and 0.50/0.20mm drop at (89.8,71.5), together with both 0.30mm capacitor ground banks, retain exact dictionaries. Common GND membership alone was not treated as a physical path.

Replacing only the reviewed points in a deep copy makes the whole floorplan equal to its preimage. Thus placement, every separate via reservation, zones, rules, pad settings and all unrelated fields are preserved. Source exact full-GND targets remain 32, including the prior 14 additions; native full-GND remains 33 including inherited U_ADC.49. The target retains its inherited connection setting. Current project settings retain min_resolved_spokes=2, starved_thermal:error, and 0.50mm thermal gap/spoke. Every width, current, clearance, seed and drop authority is unchanged.

## Tests, primary authority and limits

Actual maintained property RED uses the proposed test against the exact before floorplan: one test runs and fails only with full-pad-clearance-coverage. Proposed GREEN passes all 11 ADC-feed tests. The remaining ADC-source, feed-invariant, thermal-source and five scoped ground tests pass 27/27: total 38/38. Existing ADC-feed class AST is preserved. Four added tests exercise coverage and ownership properties rather than a golden point list alone. Six independently constructed mutations additionally reject a partial extension, lost old branch, wrong layer, wrong denial, shifted seed and shifted designated drop. The historical polygon and bank constants exactly match frozen source obligations.

Both before and proposed broad route-contract suites run 19 tests and fail the same six assertions: CHASSIS_SHIELD class membership, 173/172 wave census, 154/105 seed census, shadow-compiler verdict, 221/220 net census and 20/19 via-spec census. **All six remain OPEN_UNCHANGED. The shadow-compiler cause remains unresolved.** Source SOUND neither repairs nor waives these failures; no diagnostic result may advance an owning gate that refuses.

Tests resolve the actual Git object store at /home/mouse9911/gits/circuits/.git/worktrees/crow-roof-array-v1-20260901. Immutable full commit and blob identities for 1b725986 and 84db6eb2 historical controls are in git-*.log; additional recorded revisions are not substituted for the frozen project. No missing-dependency import error is counted as RED.

Cirrus CS530x Schematic and Layout Guidelines July2025, §3.3–3.4/p10, supports close decoupling, VMID capacitor returns to the closest GND_A, each GND_A's own plane connection, and no direct paddle connection. §3.7/p12 separately addresses digital ground. These primary constraints support preserving this return owner; they do not establish that a 0.25mm exclusion resolves KiCad's thermal predicate. The ADR0015 append preserves the historical text byte prefix, correctly describes the source change, and explicitly leaves independent source review and separate native admission owed. It grants no placement, routing or first-article acceptance.

Retained ordinary placement evidence still has one starved_thermal (actual1/minimum2), 499 opens and zero parity rows. It is BEFORE prep. Candidate4's earlier driver prepares and fills before its DRC; that prepared result cannot replace the ordinary placement check. This review loaded only scratch copies of existing boards and ran source tests; no generation, save, fill, DRC, prep, routing, native trial or human witness occurred.

Native API setup failures, the initial runtime console-limit validation error, and corrected methods are preserved. They are observer/setup failures, not candidate replacements or engineering passes. Enum/image-handler diagnostics remain in raw logs. Geometry proves source reservation representation; it does not prove filled connectivity, resolved spokes, manufacturability, assembly or release safety.

## Separate bounded next-native recommendation

The reviewed changed reservation premise is a sufficient source basis for root to consider at most one cumulative native5 under a separately recorded admission. All four previous observations/spend remain; no native6, reset or automatic admission follows. Required predicates are:

Root's 21:54Z coordination update separately reports a baseline ADC1 scope concern: C_VMID1_470N.2 spec1, endpoints (89.45,68.7)/(89.45,69.17), width0.18mm, extends to x89.36 beyond ADC_WEST_LOCAL's x89.5 boundary, with no eligible GND0.18 scope reported. This outside-packet finding was not independently adjudicated here and is not attributed to the ADC2 change. Root must resolve its actual owning source/consumer semantics before any next-native admission. No native DRC failure is inferred from that report.

1. Preserve exact reviewed source authority and all existing obligations. Stop at any earlier actual owning refusal, including source-contract refusal; diagnostic work cannot authorize continuation.
2. Grade ordinary generated placement with full-severity, refill and schematic-parity DRC plus owning P-DRC BEFORE any prep. Resolve the complete failure population under existing floors; no prepared substitution or thermal waiver.
3. Only after prior owning gates pass, grade prepared/filled DRC and renew all four VMID return cuts, three LT quiet-return cuts, five F-paddle exclusions, ADC supply/ground paths and critical-path controls, with unchanged source authority.

All placement/orientation/routing/release and first-article evidence remains owed. FIRST-ARTICLE-ONLY / DO-NOT-ORDER. Delivery PASS means an honest complete source-review handback, not native or stage acceptance.
