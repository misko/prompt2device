"""Apply only the completed independent review's exact final source manifest."""
from pathlib import Path
from datetime import datetime,timezone
import sys,json,hashlib
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
name='rj45-coherent-top-only-review1'
meta=json.loads((N/(name+'-opened.json')).read_text())
closed=json.loads((N/(name+'-closeout-summary.json')).read_text())
assert closed['delivery_status']=='PASS' and closed['engineering_verdict']=='SOUND'
E=json.loads(Path(meta['envelope']).read_text());D=Path(meta['project']);O=Path(meta['output_dir'])
e=json.loads((O/'evidence.json').read_text());assert e['subject']==E['subject'] and e['verdict']=='SOUND'
assert hashlib.sha256(Path(closed['archive']).read_bytes()).hexdigest()==closed['sha256']
for row in E['input_packet']:
 p=D/row['path'];b=p.read_bytes();assert not p.is_symlink() and len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256']
supp=json.loads((N/'pod-probe-bound-review-supplement.json').read_text())
for row in supp['files']:
 b=Path(row['path']).read_bytes();assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256']
# The coordinator writes this normalized acceptance manifest only after reading
# the actual final report and matching its explicit per-file acceptance rows.
accepted=json.loads(Path(sys.argv[1]).read_text())
assert accepted['review_archive_sha256']==closed['sha256']
assert accepted['review_subject']==E['subject']
accepted_rows=accepted['files'];assert len(accepted_rows)==30
accepted_map={x['path']:x['sha256'] for x in accepted_rows};assert len(accepted_map)==30
S=Path('/tmp/rj45-coherent-top-only-source1-dz0edoky/06_build/task_runs/rj45-coherent-top-only-source1/scratch')
rows=json.loads((S/'source-pre-post-manifest.json').read_text());plan={}
for row in rows:plan[row['path']]={'before':row['before'],'after_path':row['after']['path'],'after_sha256':row['after']['sha256']}
for row in json.loads((S/'nongeometry-followup/manifest.json').read_text())['files']:
 rel='projects/crow-audio-carrier-v1/'+row['path'];assert rel not in plan
 plan[rel]={'before':{'sha256':row['before_sha256']},'after_path':row['proposal_path'],'after_sha256':row['after_sha256']}
addon=json.loads((N/'pod-probe-bound-addendum/manifest.json').read_text())
assert plan[addon['path']]['after_sha256']==addon['before_sha256']
plan[addon['path']].update(after_path=str(N/'pod-probe-bound-addendum/after.md'),after_sha256=addon['after_sha256'])
assert {p:x['after_sha256'] for p,x in plan.items()}==accepted_map
before={};after={}
for rel,row in plan.items():
 p=R/rel;assert not p.is_symlink() and not Path(rel).is_absolute() and '..' not in Path(rel).parts
 prior=row['before'];before[rel]=p.read_bytes() if p.exists() else None
 assert before[rel] is None if prior is None else before[rel] is not None and hashlib.sha256(before[rel]).hexdigest()==prior['sha256']
 b=Path(row['after_path']).read_bytes();assert hashlib.sha256(b).hexdigest()==row['after_sha256'];after[rel]=b
record={'created_at':datetime.now(timezone.utc).isoformat(),'review':closed,'acceptance':accepted,'files':plan,'scope':'Exact independently accepted30 source postimages; source-only adoption, no direct native write or downstream acceptance.'}
(N/'coherent-top-only-adoption-planned.json').write_text(json.dumps(record,indent=2)+'\n')
written=[]
try:
 for rel,b in after.items():
  p=R/rel;assert (p.read_bytes() if p.exists() else None)==before[rel]
  p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);written.append(rel);assert p.read_bytes()==b
except Exception:
 for rel in written:
  p=R/rel
  if before[rel] is None:p.unlink()
  else:p.write_bytes(before[rel])
 raise
(N/'coherent-top-only-adoption.json').write_text(json.dumps(record,indent=2)+'\n')
print('Adopted30 exact independently accepted source postimages. Ordinary conductor renewal remains owed.')
