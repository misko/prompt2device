from pathlib import Path
from datetime import datetime,timezone
import sys,json,yaml,subprocess
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
summary=json.loads((N/'rj45-coherent-top-only-source1-closeout-summary.json').read_text())
assert summary['delivery_status']=='PASS'
P=R/'projects/crow-audio-carrier-v1';F=P/'01_docs/findings.yaml';ledger=yaml.safe_load(F.read_text())
findings=ledger['findings'] if isinstance(ledger,dict) else ledger
f=next(x for x in findings if x['id']=='CAR-TOP-ONLY-SMD');i=f['investigation'];lid='launch-97510c398124407099ff928179829b8b'
assert len(i['history'])==3 and len(i['launches'])==1 and i['launches'][0]['id']==lid
i['history'].append({'id':lid,'subject_sha256':i['launches'][0]['subject_sha256'],'origin':'executed','hypothesis':i['next']['hypothesis'],'result':'Actual guarded candidate4 completed193.218s exit1. Both generators/prep/fill succeed. Carrier60 dangling/445 opens/0parity; pod7 dangling/33 opens/0parity. No other physical DRC violations. Top-only, prepared protection geometry, all ADC return controls and offpad R13 seed now measured. Full routing remains owed. Two separate nongeometry locator/test corrections pass ordinary export and root52 tests on identical native bytes. Missing release MANIFEST remains explicit. Exact independent source/native judgment and later placement acceptance remain owed; no source adopted or candidate5 admitted.','model_domain':'within','progress':[],'evidence':[{'path':'01_docs/journal/'+h+'.tar.gz','sha256':h} for h in [summary['sha256'],'48b249cb214fab88bd902e92b6d68581c9e41ed5884e291a86cb8717bbb8a1f3','b3ff6c18b32104bc56ecea37efb61982a11ef3f31dd23f2744ca201139d0e075']]})
i['next']={'action':'reassess','hypothesis':'Fresh independent exact assembled source/native review can determine adoption of candidate4 plus the two nongeometry follow-up files, with retained routing and current placement obligations.','on_support':'Adopt only exactly accepted source and complete ordinary source/schematic/placement renewal. Candidate4 remains the only fourth construction; no further exploratory trial is admitted.','on_reject':'Retain all four attempts and actual failures; return precise defects to their upstream source or protection owner. No local fifth geometry candidate or routing pilot.','uncertainty':'bounded'}
f['finding']='Both candidate4 native boards are top-only with corrected protection preparation and ADC returns; exact independent source/native acceptance and normal regenerated placement/assembly gates remain open. All four cumulative native candidates and earlier campaigns are preserved. Live boards remain obsolete mixed-side until accepted source and ordinary renewal.'
# Keep unchanged ledger formatting intact after the guard serialized it.
base=subprocess.check_output(['git','show','HEAD:projects/crow-audio-carrier-v1/01_docs/findings.yaml'],cwd=R,text=True)
marker='- id: CAR-TOP-ONLY-SMD\n';assert base.count(marker)==1
rendered=base.split(marker)[0]+yaml.safe_dump([f],sort_keys=False,allow_unicode=True,width=100)
assert yaml.safe_load(rendered)==ledger
F.write_text(rendered)
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from decision_progress import evaluate
decision=evaluate(P,'CAR-TOP-ONLY-SMD');assert decision['decision']=='REASSESS'
(N/'candidate4-completed-assessment.json').write_text(json.dumps(decision,indent=2)+'\n')
now=datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S')
entry=f'''

## {now} UTC — coherent top-only construction complete; exact acceptance handoff

MEASURED: sole guarded cumulative candidate4 launch {lid} completed193.218s with exit1, all failed stages retained. Both generators, preparation, fill and final rules complete. Actual carrier01ed49549238189a80d64e24a61832d6e9ca8826fd5bf107137243d2ea9b4240 has60 dangling warnings/445 unconnected/0 parity; podb79da76fd9057f592985163e3ba7572700a01cb6ee727c659b8b8fa7d8d9a85e has7/33/0. There are no other physical DRC violations. Every545 raw row is individually preserved with actual native UUID/net endpoints; initial and corrected ground-component attributions remain archived. Root direct native census finds no bottom SMD footprints. No routed-board or placement acceptance is claimed.

MEASURED: author actual FINAL closed deliveryPASS; exact1761 frozen inputs and all archive members reopened. Author archive{summary['sha256']} retains{summary['size']}bytes/{summary['regular_members']}outermembers. Original28 postimages and917 native-request input manifest remain separate from the two proposed nongeometry follow-up files. Carrier locator removes only now-visible R_ADC_PD1P/R_PWR_BOT exceptions; ordinary export has333refs/23exceptions. Scoped ADC-map tests retain actual migration negatives. Root complete composed52-test suite passes18.125s on638 unchanged scratch files. Fresh owning A-POS grades carrier306nativeSMD/300CPL and pod31/31 alltop; full A-POP still refuses missing release MANIFEST. Model coverage succeeds with explicit actual model directory; original environment failures remain. Native generation was not repeated for evidence or test repairs.

MEASURED by author native graph, pending fresh independent acceptance: carrier4VMID cuts,3quiet cuts,5paddle controls, supply closure and full-drop disk containment on4layers pass;14 newly full pads give32 authored targets, plus preexisting native U_ADC.49 paddle. Carrier U_PWR.2 and U_AUDIO.2 are separate singleton pads; R_PWR_BOT.2 and all15F-zone polygons belong to broad556-node GND component. Pod C10/U3 are broad-connected; actual residual is R7/C9 island. These named return routes and FILT feed-after-bulk remain owed.

Root guarded-run archive48b249cb214fab88bd902e92b6d68581c9e41ed5884e291a86cb8717bbb8a1f3 retains664267bytes/17members; root qualificationb3ff6c18b32104bc56ecea37efb61982a11ef3f31dd23f2744ca201139d0e075 retains538534bytes/18members. Actual reservation is assessed under its exact launch/source subject. The strict complete-protection-and-independent-placement milestone is not credited prematurely; cumulative4/4 cap now requires independent reassessment, not candidate5. Root sole live writer. Next fresh exact assembled source/native judgment before any source adoption; ordinary renewal and all later release gates remain. FIRST-ARTICLE-ONLY / DO-NOT-ORDER; neither new release minted.
'''
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 p=R/'projects'/slug/'01_docs/journal/placement.md';p.write_text(p.read_text()+entry)
print(json.dumps({'recorded_at':now,'decision':decision['decision'],'author_archive':summary['sha256']}))
