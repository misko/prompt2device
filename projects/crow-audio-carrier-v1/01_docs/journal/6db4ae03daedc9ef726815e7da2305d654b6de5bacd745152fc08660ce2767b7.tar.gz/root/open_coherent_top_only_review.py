from placement_review_common import *

name='rj45-coherent-top-only-review1'
probe=json.loads((N/'rj45-coherent-source-review-availability-opened.json').read_text())
assert json.loads(Path(probe['attempt']).read_text())['status']=='PASS'
author=json.loads((N/'rj45-coherent-top-only-source1-opened.json').read_text())
assert json.loads(Path(author['attempt']).read_text())['status']=='PASS'
D0=Path(author['project']);S=Path(author['scratch_dir']);O=Path(author['output_dir'])
copies=[(S/'work','candidate'),(D0/'input','original-input'),
        (D0/'live-preimages','live-preimages'),(D0/'governing','governing'),
        (D0/'decisions','decisions'),(S/'methods','author-methods'),
        (Path(probe['attempt']),'availability/attempt.json'),
        (Path(probe['output_dir']),'availability/outputs')]
for p in O.iterdir():
 if p.is_file():copies.append((p,'author-delivery/'+p.name))
for p in S.iterdir():
 if p.is_file():copies.append((p,'author-evidence/'+p.name))
for rel in ['logs','views','native-preimages','native-placement','supplements','nongeometry-followup','assembly-export']:
 p=S/rel
 if p.exists():copies.append((p,'author-evidence/'+rel))
for task in ['rj45-pod-return-reassessment1']:
 meta=json.loads((N/(task+'-opened.json')).read_text())
 for p in Path(meta['output_dir']).iterdir():
  if p.is_file():copies.append((p,'decisions/'+task+'/'+p.name))
for rel in ['candidate4-root-postrun-validation.json','candidate4-root-classification-binding.json','candidate4-root-native-population.json','candidate4-guarded-native-completion-summary.json','candidate4-root-composed-tests.log','candidate4-root-composed-tests-runtime.json','candidate4-root-composed-tests-integrity.json','candidate4-root-composed-qualification-summary.json','rj45-coherent-source-review-availability-opened.json','rj45-coherent-source-review-availability-host-final.json']:
 copies.append((N/rel,'root/'+rel))
for p in Path('/tmp/carrier-connector-integration-20260911').glob('coherent-top-only-native-candidate4*'):
 if p.is_file():copies.append((p,'root/'+p.name))
open_task(name,(N/'coherent_top_only_review_task.md').read_text(),copies,minutes=35,role='judgment')
