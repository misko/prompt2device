import sys,runpy
sys.argv=['/tmp/rj45-carrier-readability-review-top_only1-y5e6kd0s/preflight.py','/tmp/rj45-carrier-readability-review-top_only1-y5e6kd0s/06_build/task_runs/rj45-carrier-readability-review-top_only1/envelope.json']
runpy.run_path(sys.argv[0],run_name='__main__')
