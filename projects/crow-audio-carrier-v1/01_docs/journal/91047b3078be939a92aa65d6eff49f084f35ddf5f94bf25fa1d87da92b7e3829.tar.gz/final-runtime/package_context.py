from pathlib import Path
import json,hashlib,tarfile,shutil
root=Path('/tmp/rj45-pin-carrier-tvs-clockground1-context1-vhajetxk');t=root/'06_build/task_runs/rj45-pin-carrier-tvs-clockground1-context1';s=t/'scratch';o=t/'outputs';e=json.loads((t/'envelope.json').read_text())
old=Path('/tmp/rj45-pin-carrier-tvs-clockground1-ljz88bz3/06_build/task_runs/rj45-pin-carrier-tvs-clockground1')
inherit=s/'inherited';inherit.mkdir(exist_ok=True)
for p in (old/'scratch').rglob('*'):
 if p.is_file() and not p.name.startswith('packaging-') and p.name!='package_review.py':
  dest=inherit/p.relative_to(old/'scratch');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
text=(root/'previous-completed-report.md').read_text()
text=text.replace('reviewer: /root/rj45_pin_carrier_tvs_clockground1 (actual fresh agent)','reviewer: /root/rj45_pin_carrier_tvs_clockground1 (original independent reviewer, continued)')
text=text.replace('context: FRESH','context: independent original review continued with requested native/primary facts')
text=text.replace('design_verdict: INCOMPLETE','design_verdict: SOUND')
text=text.replace('Independent manufacturer derivation preceded reading the native dossier tables.','Inherited physical review: original independent manufacturer derivation preceded reading the native dossier tables. Original figure images and raw evidence are retained in inherited/. This continuation does not claim a new fresh agent; the envelope context_mode metadata does not reset reviewer context.')
text=text.replace('D_QIN_GS — VERDICT: QUESTION','D_QIN_GS — VERDICT: PASS')
start=text.index('QUESTION Q1:');end=text.index('\n\nInstance symmetry:',start)
text=text[:start]+'''Resolved Q1 using newly inspected primary figure images and actual supplementary native dossiers. Diodes DMP6023LFG DS37204 Rev.2-2, SHA-256 1ea244be5e0fe4195ad20cb2da0960ac622b6efc19cf9e579c9eb8ef5777fa27, page 1 POWERDI3333-8 bottom/top views and Equivalent Circuit, establishes a P-channel enhancement MOSFET with source pins 1–3, gate pin 4 and common drain pins 5–8. Page 5 Package Outline Dimensions labels the bottom-view 1/4 and 8/5 corners; its exposed metal matches page 1's common drain leadframe. Converting the bottom view to top by reflecting y and then rotating 90 degrees clockwise in +y-down coordinates places 1–3 source and 4 gate down the west edge, and drain on east. This is the single required bottom-to-top conversion, not an extra mirror of a mounted-side dossier.

Newly read Q_IN native dossier: front mounted, source pins 1–3 at local x=-1.5 and y=-0.975,-0.325,+0.325 all connect to 12V_PROTECTED; gate pin 4 at (-1.5,+0.975) connects to Q_IN_GATE. Composite drain pad 5 at (+0.455,0) connects to 12V_FUSED. Three explicit manufacturer-fused aliases 6/7/8 retain the other drain identities. Measured context census: 5 numbered native copper pad rows representing 8 terminal identities; 8 additional unnumbered paste-only features, no independent ninth EP identity. The exposed drain belongs to the common drain identity. Only four distinct surviving perimeter source/gate pads are collinear, so computed n/a winding is appropriate; no winding claim is made from that reduced set. This context inspection establishes actual source/gate/drain identity and nets; a complete Q_IN footprint manufacturing acceptance is not commissioned here.

Newly inspected YAGEO RC0402FR-07100KL primary SHA-256 e42aa2b39be7476fef25efbe4656acbbc246d2b9b625d64db6b46e0f5e34d7af, page 1 package dimension illustration and Specifications, establishes two nonpolar opposing terminations and 100 kOhms. R_QIN_G actual front-mounted dossier has 2 distinct native pads / 2 physical identities, no EP or aliases: pad 1 at local (-0.51,0), native (40,79.51), Q_IN_GATE; pad 2 at (+0.51,0), native (40,78.49), GND. Native 90-degree rotation accounts for the vertical board positions; no reflection is required. This is the gate pull-down.

D_QIN_GS pin 1 (K): expected cathode to the confirmed P-channel source; observed 12V_PROTECTED, exactly Q_IN source pins 1–3.
D_QIN_GS pin 2 (A): expected anode to the confirmed P-channel gate; observed Q_IN_GATE, exactly Q_IN gate pin 4 and the pull-down resistor terminal.
With the source above the pulled-down gate, reverse zener conduction runs source(K) to gate(A) and limits source-minus-gate voltage; equivalently it clamps negative VGS. Forward conduction clamps opposite gate-source polarity. The added source/channel/pull-down facts resolve Q1 without changing the original successful physical checks.''' + text[end:]
text=text.replace('with Q1 still unresolved.','with Q1 now resolved by the added native and primary evidence.')
text=text.replace('No electrical/package defect was demonstrated. Group verdict remains INCOMPLETE because Q1 prevents all commissioned refs from passing.','No electrical/package defect was demonstrated. Both commissioned diode refs now PASS; group verdict is SOUND for this limited pin-review scope. Q_IN and R_QIN_G are context evidence, not extra full-device acceptance commissions. FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains. No unresolved pin findings remain.')
(o/'report.md').write_text(text)
ev=json.loads((old/'outputs/evidence.json').read_text());ev['subject']=e['subject'];ev['verdict']='SOUND';ev['findings'][1]['verdict']='PASS';ev['findings'][1].pop('question',None);ev['findings'][1]['resolution']='Q1 resolved: actual Q_IN is P-channel, source1–3=12V_PROTECTED, gate4=Q_IN_GATE; 100k pull-down to GND confirms negative-VGS clamp K=source/A=gate.';ev['counts'].update(PASS=2,QUESTION=0);ev['unresolved_engineering']=[]
ev['context']='Continued original independent reviewer with requested native/primary facts; not a new fresh-agent review.'
ev['methods']['coverage']='Inherited diode physical checks bound to unchanged dossier/PDF hashes; new Q_IN/R_QIN_G contextual primary figure and native connection inspection.'
ev['methods']['new_figures']='DMP6023LFG page1 bottom/top views and equivalent circuit, page5 outline/land; YAGEO page1 dimensions/specifications. pdftoppm -png -r 130, viewed via view_image.'
ev['methods']['bottom_to_top']='Q_IN outline bottom view: reflect y once, then rotate 90 degrees clockwise to component-top west row1–4. Mounted front requires no further reflection.'
ev['supporting_context_counts']={'Q_IN':{'numbered_copper_rows':5,'physical_terminal_identities':8,'fused_aliases':3,'unnumbered_paste_features':8},'R_QIN_G':{'native_pads':2,'physical_identities':2}}
ev['primary_documents']=[f for f in e['input_packet'] if f['path'].endswith('.pdf')];ev['inspected_figures']=['inherited/bzt-1.png','inherited/bzt-4.png','inherited/smbj-1.png','inherited/smbj-5.png','inherited/smbj-6.png','q-1.png','q-5.png','r-1.png'];ev['original_report_sha256']=hashlib.sha256((root/'previous-completed-report.md').read_bytes()).hexdigest()
for f in e['input_packet']:
 b=(root/f['path']).read_bytes();assert len(b)==f['size'] and hashlib.sha256(b).hexdigest()==f['sha256']
(s/'inputs-after.json').write_text(json.dumps(e['input_packet'],indent=2));(s/'methods.json').write_text(json.dumps(ev['methods'],indent=2));(o/'evidence.json').write_text(json.dumps(ev,indent=2));shutil.copyfile(o/'report.md',s/'report.md');shutil.copyfile(o/'evidence.json',s/'evidence.json')
a=o/'evidence.tar.gz'
with tarfile.open(a,'w:gz') as z:
 for p in sorted(s.rglob('*')):
  if p.is_file() and not p.name.startswith('packaging-'):
   assert not p.is_symlink();z.add(p,arcname=p.relative_to(s).as_posix(),recursive=False)
members=[];seen=set()
with tarfile.open(a,'r:gz') as z:
 for m in z.getmembers():
  assert m.isfile() and not m.issym() and not m.islnk() and not m.name.startswith('/') and '..' not in Path(m.name).parts and m.name not in seen and not m.name.endswith(('.tar','.tar.gz'));seen.add(m.name);b=z.extractfile(m).read();assert len(b)==m.size;members.append({'path':m.name,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(o/'evidence-manifest.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'archive_size':a.stat().st_size,'member_count':len(members),'members':members},indent=2));(o/'result.json').write_text(json.dumps({'subject':e['subject'],'checks':{c:'PASS' for c in e['completion']['checks']},'unresolved':[]},indent=2));print('SOUND; Q1 resolved;',len(members),'verified archive members')
