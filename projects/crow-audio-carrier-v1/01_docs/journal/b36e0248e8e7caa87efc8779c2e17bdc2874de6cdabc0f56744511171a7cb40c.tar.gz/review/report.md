# Carrier source-correction handback — INCOMPLETE

FIRST-ARTICLE-ONLY / DO-NOT-ORDER. No source adoption, independent SOUND,
whole-board acceptance, route admission, release or ordering authority.

The user now requires every SMD component on one side on both boards, with
board expansion permitted. The coordinator stopped this mixed-side correction
before handback. Both bounded candidates are preserved. The current proposed
source is historical work for review/backtrack only: its16 bottom-side SMD
poses are superseded and it also has an unclosed local GND regression.
No third candidate, route search, conductor, live-project edit, part swap,
connector/mate/cable/model/approval change or threshold waiver occurred.

## Candidate history and measured results

Candidate1 added six F.Cu-only return reservations, moved R_PWR_PU +0.04mm
inY, moved eight CH captions, applied the twelve exact full-zone pad settings,
and supplied integration/ADR decisions. Its four VMID graph cuts improved,
but the first caption move chose the wrong ownership half-plane. It also
introduced two VMID470nF thermal artifacts and an isolated C_VDDA1_10N ground.
All first-candidate source, native artifacts and failed/raw processes remain.

Candidate2 is the second and final coherent revision. It reverses the caption
translation toward the correct half-plane, makes the two VMID470nF ground
lands full-zone while retaining their pour exclusion, and moves only VMID1's
return column fromx89.8 tox89.45 below its470nF pad. That widened the supply-cap
pocket but did not connect it to general ground. There is no third revision.

| Native exact subject | Physical errors excluding declared dangling seeds | Dangling tracks/vias | Opens | Parity |
|---|---:|---:|---:|---:|
| Frozen current |0|0/0|499|0|
| Frozen prepared r0 |12 starved thermals|39/5|469|0|
| Candidate2 current, before seed preparation |1 C_VDDA2_10N.2 thermal|0/0|499|0|
| Candidate2 prepared |0|39/5|470|0|

These are incomplete route-stage artifacts; zero physical violations in the
prepared candidate does not close470 opens. All3255 native rows from every
DRC launch are individually retained and classified, including the initial
candidate1 launch's199 missing-library rows and missing parity context.
The companion DRC launches copy unchanged prepared PCB bytes beside the exact
pinned schematic, generated project/rules and fp-lib-table context. They report
zero parity. The failed initial launch remains evidence, not a clean DRC claim.

## Return proof and remaining source defect

Fresh KiCad10.0.4 native fill/contact extraction covers all selected ground,
reference and ADC-supply copper across the full150x100mm board, including all
actual fill islands/holes and physical via layer edges. Baseline andcandidate
prepared graphs each have670 nodes,1065/1043 edges. Actual native effective
shape collision creates planar graph edges; equal netnames only filter
candidate pairs. General-plane targets are actual broad filled islands;
independent review must judge this author proof separately.

All4 baseline VMID paths bypass their designated GND_A junction/drop. Candidate2
has0 direct filled-zone contacts at those four pads; all4 intact return trees
reach their own nearest GND_A and general plane, and removing the owner pad
plus every layer of its designated drop disconnects all4 from general planes.
GND_A6 drop(91.6,69.5), GND_A8 drop(89.8,71.5), GND_D30 own drop and9paddle
vias remain. All5 GND_A/GND_D/FILTN-to-paddle queries have no F.Cu-only shortcut
and have a through-plane path after preparation. Canonical current lacks seed
tracks and is never claimed to prove these connected return trees.

C_LDO_NR4.2,C_LDO_NR5.2,R_LDO_SET.2 still have no direct pour contact; all3
reach C_LDO_OUT.2 first and lose general-plane access when that output pad is
cut from the native graph. The LT3041 quiet cell remains intact on these bytes.

**OPEN — NEW_C_VDDA1_GROUND_POCKET.** C_VDDA1_10N.2,
UUID0aebe923-80d1-4bae-b48f-b1aaba2fb3ec, center(90.52,68.5), copper
bounds[90.24,68.19,90.8,68.81], now contacts only F.Cu GND zone
b8eb10fd-90c4-4416-8fa6-e153f4efd8dd island6, whose bounds are
[89.696641,66.295,90.96777,68.96]. Its complete native connected component
is exactly that pad and that small island. Baseline connected directly to
broad island15. The VMID1 reservation closes the pocket's west/south exits;
the existing3V3_ADC source launch fences the east/top. Moving the return column
left widened the pocket without providing an exit. There is no existing seed
or barrel taking this supply-pad ground to a plane. See graph-matrix.json and
supply-open-closeup.png. The next source owner must give this supply return a
legal plane connection while preserving the VMID bank junction dominance;
neither shorting the VMID spine upstream nor allowing broad pour bypass is a
valid inferred repair. No repair geometry is accepted here.

U_PWR.2/R_PWR_BOT.2 and U_AUDIO.2 retain their known route obligations. The
new third GND open is not folded into those inherited obligations. Both FILTP
feed-after-bulk branches remain owed: resistor output must enter the470uF
reservoir side, then ceramics/ADC. No bulk move or FILTN resistor is introduced.

## Policy and identity observations

Candidate2 has333 fitted refs with identical parts/pad identity, side and net
assignments. All poses are unchanged except R_PWR_PU[32.4,53.9,90] to
[32.4,53.94,90]. Its true native rounded-copper gap toU_PWR.6 is2.472974mm,
27.026um below the fixed2.5mm ceiling. All local foreign-pad pairs within4mm
are recorded. P-PADSEP passed1009pads/461080inter-footprint pad comparisons
and750048paste comparisons at the unchanged0.090mm tier floor.
Placement policy graded62keep-short and353adjacency rows,415/415resolved.
That policy's bbox approximation is separately bounded by the native resistor
metric; its PASS is not claimed to replace actual copper-edge authority.

Fourteen exact GND pad connection settings differ: the commissioned12 and the
two VMID470nF grounds. Full native identity verification finds exactly the
commissioned12baseline starved pads and zero prepared candidate thermals.
The unprepared candidate's C_VDDA2_10N.2 thermal is retained explicitly.
No global thermal-spoke count, clearance or other limit changed.

Only four baseline seed tracks are replaced by five native tracks for the
VMID1 column change; the extra track is the previously idempotent opposite
25um segment at the capacitor junction. All other292prepared copper primitives
are exact by net/layer/endpoints/width/drill, including every via. No electrical
netlist or component-count change occurs. Full per-ref/pad/copper matrices
are archived; UUID churn from added rule areas is not geometric evidence.

The eight existing captions move+3mmX north and-3mmX south from their original
poses, with unchanged0.7mm text and0.13mm stroke. Native mixed-side ownership
and unchanged whole policy report20/20J/F/TP owners and P-SILK-REF/FN/OWN PASS.
Actual top silk was opened. The minimum native ink-to-pad gap is0.871991mm;
ink-to-footprint-silk gap0.172074mm; conservative F.Fab-body-envelope to text
bbox gap0.112350mm. No duplicate, side waiver or checker change was used.
The generator still calls all8captions crowded under its conservative whole
footprint envelope obstacle test; this diagnostic is retained. Positive native
ink/F.Fab gaps and visual legibility support the scoped caption correction,
not registered3D-body or whole-board silk acceptance. User steering supersedes
this mixed-side arrangement regardless of these results.

## Integration and primary decision handback

integration.yaml explicitly inventories U_BUCK's complete nine local external
supports across12V_PROTECTED/GND/5V_BUCK ports: D_BUCK_IN; three input caps;
bootstrap capacitor; L_BUCK; three output caps. No external switch, enable
resistor, compensation or fixed-output feedback divider is hidden. ADR0003
explicitly names shared upstream protection and downstream hold/regulator
loads outside those converter ports; they remain necessary with either choice.
Nine is below unchanged threshold10. The rationale retains the small fixed5V
integrated-switch/compensation implementation without asserting an unresearched
module fails a requirement. Exact AP63205 DS41326 Rev3-2 text and existing
architecture support those facts; no stock or module-market search occurred.

The ADC inventory conservatively counts all332other fitted carrier parts,
including shared and interface/protection parts, rather than implying all are
direct converter supports. U_ADC itself is excluded. The full-carrier accounting
avoids any selected-subset threshold argument; the existing MCHStreamer and
DC5308P evidenced exception remains above threshold10.

**OPEN — BUCK_TYPE_METADATA.** The unchanged module checker rejects the
explicit AP63205 entry because its dossier says type:synchronous_buck_converter;
the checker recognizes buck_controller/power_controller vocabulary, and so
never grades this selection. Its exact rejection is archived. This is an
actual metadata-applicability conflict with the P-MOD switching-power scope,
not authority to omit the selection. The next source owner should consider a
truthful dossier classification such as synchronous_buck_controller_with_integrated_mosfets,
matched independently to the primary description, and regrade the complete
integration entry. That dossier edit is outside this envelope. No shared
checker modification is proposed or performed and no machine P-MOD PASS claimed.

ADC ADR0013 explicitly preserves the exact §3.7 phrase “deprecated on all
ground layers” and does not change it to “duplicated.” Figure10 is a finite
top-layer drawing from an eight-layer evaluation board. The source decision
applies own-GND_D/no-direct-paddle intent and the existing finite F.Cu barrier,
retaining continuous inner ground planes rather than inventing an all-layer
moat. This resolves the source choice but does not assert literal all-layer
manufacturer conformance; stronger vendor-conformance language needs Cirrus
clarification. Primary guideline pp10/12 actual images andnative F.Cu/In1 views
were opened. No extra first-article prerequisite is created.

## Delivery and limits

Six proposed source paths and exact before/candidate1/candidate2 hashes are in
source-pre-postimages.json and evidence.json. Beforeimages and both native
candidate histories are archived. No source is adopted. Full policy's other
R-THERM(Q_IN.5),R-LEN and M-JRNL failures are retained; route copper and omitted
journal packet scope do not become accepted simply because this was bounded
source work. Existing full-review routing, current/ampacity, SI, body/model,
connector qualification and first-article claims remain at their owning gates.

All649original declared input files were size/SHA verified before and after.
Exact supplementary fab_tiers and native qualification identities are bound;
315dependencies/25native qualification files were reverified by coordinator
and copied/hash checked here. No qualification probe was repeated. Selected
old archive members were reopened/hash checked; old archives are not nested.

All substantive native/generator/check commands use shared run_stage with
explicit cwd/environment and finite deadlines; failed API/setup probes remain.
Bootstrap reads/script writes precede some runner calls. One wrong-cwd script
write failed before creating a file. The first source authoring interpreter
lacked shapely; the existing KRT environment supplied it without installation.
A runner import created Python bytecode under input; exact generated bytes
were preserved in scratch and only those new files were removed to restore
the admitted tree. Original frozen file bytes never changed. The transient
write and cleanup receipt are disclosed; final packaging/preflight uses-B.

The selected source candidate cannot proceed: single-side placement now owns
next work, and the local GND pocket plus dossier metadata handoff remain real.
Delivery-only PASS checks mean this complete honest INCOMPLETE handback is
packaged and input-bound. They grant no engineering acceptance.
