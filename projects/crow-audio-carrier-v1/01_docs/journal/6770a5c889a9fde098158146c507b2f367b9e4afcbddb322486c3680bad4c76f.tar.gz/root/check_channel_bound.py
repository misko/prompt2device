from pathlib import Path
import sys,json,copy,tempfile,shutil
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'));from adr_bound_provenance import parse_blocks,grade_bound
p=R/'projects/crow-audio-carrier-v1/01_docs/decisions/0027-fixed-north-adc-channel-map.md';rows,errors=parse_blocks(p.read_text(),str(p));assert not errors and len(rows)==1
results=[]
for name,value,chosen,should_pass in [('adopted',1.0,1.0,True),('relaxed',1.1,1.1,False)]:
 b=copy.deepcopy(rows[0]);b.update(value=value,chosen=chosen);b['standard_value']['explicit']=[chosen]
 fails,grade,notes=grade_bound(b,R,name,timeout=30);assert (not fails)==should_pass,(name,fails);results.append({'case':name,'grade':grade,'failures':fails,'notes':notes})
print(json.dumps(results,indent=2))
