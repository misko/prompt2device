from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,tarfile,io,shutil,subprocess
D=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';I=Path('/tmp/carrier-connector-integration-20260911');sha=lambda b:hashlib.sha256(b).hexdigest();files={}
for pattern in ['channel-bound-declaration*','channel-bound-hostile*']:
 for p in I.glob(pattern):
  if p.is_file():files['validation/'+p.name]=p
for n in ['check_channel_bound.py','channel-bound-failure-preservation-result.json','channel-source-live-adoption.json','preserve_bound_fix.py']:files['root/'+n]=D/n
adr='projects/crow-audio-carrier-v1/01_docs/decisions/0027-fixed-north-adc-channel-map.md';old=subprocess.check_output(['git','show','326be013:'+adr],cwd=R);(D/'bound-adr-before.md').write_bytes(old);files['before/0027.md']=D/'bound-adr-before.md';files['after/0027.md']=R/adr
note={'scope':'Only ADR declaration added; executable mapping/rules untouched. Failed canonical packet was fully reopened and archived before source correction. An attempted second packaging pass after the ADR change correctly refused its stale live input; no original archive or runtime was changed. Retain the first complete 81MB archive as authority. This second packaging assertion was tool-surface output, not a claimed preserved subprocess log.'};(D/'bound-preservation-note.json').write_text(json.dumps(note,indent=2)+'\n');files['root/preservation-note.json']=D/'bound-preservation-note.json'
m={n:{'size':p.stat().st_size,'sha256':sha(p.read_bytes())} for n,p in files.items()};tmp=D/'bound-fix.tar.gz'
with tarfile.open(tmp,'w:gz',compresslevel=3) as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
 b=(json.dumps({'members':m},indent=2)+'\n').encode();i=tarfile.TarInfo('MANIFEST.json');i.size=len(b);t.addfile(i,io.BytesIO(b))
h=sha(tmp.read_bytes());out=P/'01_docs/journal'/(h+'.tar.gz');assert not out.exists();shutil.copyfile(tmp,out)
with tarfile.open(out) as t:
 for n,row in m.items():b=t.extractfile(n).read();assert sha(b)==row['sha256'] and len(b)==row['size']
r={'sha256':h,'size':out.stat().st_size,'members':len(m)};(D/'bound-fix-preservation-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
