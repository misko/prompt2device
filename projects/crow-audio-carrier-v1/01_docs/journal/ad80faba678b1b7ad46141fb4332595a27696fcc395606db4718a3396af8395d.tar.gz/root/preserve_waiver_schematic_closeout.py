from pathlib import Path
import hashlib,json,tarfile,io,shutil,sys
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911');sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet
sha=lambda b:hashlib.sha256(b).hexdigest();files={}
for prefix in ['waiver-schematic-owning-review','waiver-schematic-handoff','waiver-canonical-source-checkpoint','waiver-schematic-contracts','waiver-schematic-validate']:
 for f in I.glob(prefix+'*'):
  if f.is_file():files['root/'+f.name]=f
for n in ['waiver-canonical-preservation-result.json','waiver-delta-adoption-result.json','waiver-delta-adoption-proof.json','waiver-root-visual.json','preserve_waiver_schematic_closeout.py','open_review.py']:
 files['root/'+n]=D/n
j=json.loads(Path('/tmp/carrier-waiver-schematic-delta-opened.json').read_text());
for f in Path(j['scratch_dir']).rglob('*preflight*'):
 if f.is_file():files['review/'+f.relative_to(Path(j['scratch_dir'])).as_posix()]=f
files['current/agent_handoff.yaml']=P/'06_build/agent_handoff.yaml'
manifest={n:{'size':f.stat().st_size,'sha256':sha(f.read_bytes())} for n,f in sorted(files.items())};tmp=D/'waiver-schematic-closeout.tar.gz'
with tarfile.open(tmp,'w:gz',compresslevel=3) as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 b=(json.dumps({'members':manifest},indent=2)+'\n').encode();m=tarfile.TarInfo('MANIFEST.json');m.size=len(b);t.addfile(m,io.BytesIO(b))
h=sha(tmp.read_bytes());out=P/'01_docs/journal'/(h+'.tar.gz');assert not out.exists();shutil.copyfile(tmp,out)
with tarfile.open(out) as t:
 assert set(t.getnames())==set(manifest)|{'MANIFEST.json'}
 for n,m in manifest.items():b=t.extractfile(n).read();assert len(b)==m['size'] and sha(b)==m['sha256'],n
result={'archive':str(out),'sha256':h,'size':out.stat().st_size,'payload_members':len(manifest),'scope':'Accepted schematic gate and handoff closeout; no unrecorded review or process result is inferred'};(D/'waiver-schematic-closeout-result.json').write_text(json.dumps(result,indent=2)+'\n')
with (P/'01_docs/journal/contracts.md').open('a') as f:f.write(f'\n## Allowed waiver-correction schematic acceptance closeout\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Exact owning schematic gate and compact handoff, root input/artifact reopening, final reviewer preflight and deduplicated evidence provenance; reopen every MANIFEST member |\n')
print(json.dumps(result,indent=2))
