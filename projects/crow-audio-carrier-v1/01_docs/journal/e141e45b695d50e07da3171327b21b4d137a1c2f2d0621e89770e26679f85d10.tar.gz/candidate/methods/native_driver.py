"""Unexecuted draft: one root-admitted coherent ADC2 reservation/ADC1 scope candidate.
Independent upstream recommendations and exact composed source preflight admit
construction only; fresh independent exact source/native acceptance is still owed.
"""
from pathlib import Path
import datetime, hashlib, json, os, shutil, sys

R = Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
sys.path.insert(0, str(R/'skills/pcb-design/scripts'))
from pipeline_runtime import run_stage

assert sys.argv[1:2] == ['--root-admitted-candidate5'] and len(sys.argv) == 3
S = Path(sys.argv[2]).resolve()
admission = json.loads((S/'admission.json').read_text())
assert admission['decision'] == 'ONE_CUMULATIVE_CANDIDATE5'
assert admission['prior_native_candidates'] == 4
assert admission['new_native_candidates_max'] == 1
assert admission['reviewed_upstream_repairs_supported'] is True
assert admission['composed_source_preflight'] == 'PASS'
assert admission['independent_exact_source_native_acceptance'] == 'OWED_AFTER_THIS_CANDIDATE'
for row in admission['decision_and_preflight_evidence']:
    data = Path(row['path']).read_bytes()
    assert hashlib.sha256(data).hexdigest() == row['sha256']
manifest = json.loads((S/'input-manifest.json').read_text())
for row in manifest['files']:
    p = S/row['path']
    data = p.read_bytes()
    assert len(data) == row['size'] and hashlib.sha256(data).hexdigest() == row['sha256']
with (S/'native-candidate5-started.json').open('x') as f:
    json.dump({'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'input_manifest_sha256': hashlib.sha256((S/'input-manifest.json').read_bytes()).hexdigest()}, f)

W = S/'work'
P = W/'projects/crow-audio-carrier-v1'
T = W/'skills/kicad-pcb/scripts'
bp = P/'04_kicad/crow_audio_carrier_v1.kicad_pcb'
r0 = P/'06_build/route/r0.kicad_pcb'
assert not bp.exists() and not r0.exists()
env = {k: os.environ[k] for k in ['PATH','HOME','LANG'] if k in os.environ}
env.update(PYTHONDONTWRITEBYTECODE='1', CIRCUITS_ROOT=str(W),
           KICAD10_FOOTPRINT_DIR='/usr/share/kicad/footprints',
           KICAD10_3DMODEL_DIR='/home/mouse9911/.local/share/kicad/10.0/3dmodels',
           GIT_DIR=(R/'.git').read_text().strip().split(': ',1)[1])
(S/'logs').mkdir(exist_ok=True)
results = []
def stage(name, argv, *, required=True, timeout=180, cwd=P):
    result = run_stage({'id':name,'work_class':'local','timeout_s':timeout},
                       argv, log_path=S/'logs'/(name+'.log'), cwd=cwd, env=env)
    record = {'stage':name,'argv':argv,'cwd':str(cwd),'required':required,
              'runtime':result.to_mapping()}
    results.append(record)
    (S/'native-stage-results.json').write_text(json.dumps(results,indent=2)+'\n')
    if required and result.status != 'PASS':
        raise SystemExit(result.returncode or 1)
    if not required and (result.status not in ['PASS','FAIL']
                         or result.returncode not in [0,5]):
        raise SystemExit(result.returncode or 1)
    return result
def py(path, *args):
    return ['/usr/bin/python3','-B',str(path),*map(str,args)]

stage('generate',py(T/'generate_board_generic.py','03_src/floorplan.yaml'))
stage('rules-before-placement-drc',py(T/'generate_rules_generic.py','.'))
placement = S/'placement'
placement.mkdir()
for p in (P/'04_kicad').iterdir():
    if p.is_file(): shutil.copy2(p,placement/p.name)
# Match the real conductor: grade the unprepared generated board first.
stage('ordinary-placement-drc',['kicad-cli','pcb','drc','--severity-all',
      '--refill-zones','--schematic-parity','--format','json','-o',
      str(S/'placement-drc.json'),str(bp)])
stage('owning-placement-drc',py(T/'placement_drc_check.py',S/'placement-drc.json'))
stage('pad-separation',py(T/'pad_separation.py',bp,'--project','.'))
stage('placement-feasibility',py(T/'placement_routability_preflight.py','grade','.',
      '--board',bp,'--placement-config','03_src/placement_gates.json',
      '--json',S/'placement-feasibility.json'))
stage('placement-policy',py(T/'policy_audit.py','.', '--board','crow_audio_carrier_v1',
      '--skip-drc','--phase','placement'))
stage('escape',py(T/'escape_check.py','--board',bp))
stage('tier',py(T/'tier_preflight.py','.'))
stage('prep',py(T/'route_and_stitch_generic.py','prep','03_src/route.yaml'))
assert r0.is_file()
shutil.copy2(r0,bp)
stage('fill',py(S/'methods/fill.py',bp))
stage('rules-last',py(T/'generate_rules_generic.py','.'))
stage('verify-fill',py(T/'route_and_stitch_generic.py','verify-fill','03_src/route.yaml'))
stage('prepared-full-drc',['kicad-cli','pcb','drc','--severity-all','--refill-zones',
      '--schematic-parity','--exit-code-violations','--format','json','-o',
      str(S/'prepared-drc.json'),str(bp)],required=False)
# Retain every prepared DRC row. Known unrouted opens/dangling seeds remain
# explicitly unaccepted; classify them independently after this one execution.
stage('prepared-source-binding',py(S/'methods/native_source_binding.py',P))
stage('prepared-return-graphs',py(S/'methods/native_returns.py',bp))
stage('analog-paths',py(P/'03_src/check_analog_paths.py','--board',bp,
      '--output',S/'analog-paths.json'))
stage('critical-paths',py(T/'critical_path_check.py',bp,'--config',
      '03_src/rules/critical_paths.yaml','--json',S/'critical-paths.json'))
stage('spoke-implementation',py(P/'03_src/check_spoke_implementation.py'))
stage('rules-full',py(T/'rules_audit.py','.', '--board',bp))
print('One native proof finished. No live adoption, route or release acceptance.')
