import pcbnew as k,json,pathlib,hashlib,math,sys
from collections import deque
S=pathlib.Path(__file__).resolve().parents[1];P=pathlib.Path(sys.argv[1]);before=hashlib.sha256(P.read_bytes()).hexdigest();b=k.LoadBoard(str(P));layers=list(b.GetEnabledLayers().CuStack());mm=k.ToMM
xy=lambda p:[mm(p.x),mm(p.y)]
v=lambda x,y:k.VECTOR2I(round(x*1e6),round(y*1e6))
def bounds(sh):
 bb=sh.BBox();return xy(bb.GetPosition())+xy(bb.GetEnd())
def gap(a,c):
 if k.SHAPE.Collide(a,c,0):return 0.
 lo,hi=0,200000000
 while hi-lo>1:
  mid=(lo+hi)//2
  if k.SHAPE.Collide(a,c,mid):hi=mid
  else:lo=mid
 return hi/1e6
print('loaded final candidate native',k.Version(),flush=True);stored=[z.GetFilledPolysList(l).OutlineCount() for z in b.Zones() if not z.GetIsRuleArea() for l in z.GetLayerSet().CuStack()]
k.ZONE_FILLER(b).Fill(b.Zones());print('analytical fill complete',flush=True)
objects=[];shapes=[];holes=[];pads=[];keep=[]
def add(o,l,kind,sh,**kw):
 d={'id':o.m_Uuid.AsString()+':'+b.GetLayerName(l)+(':'+str(kw['island']) if 'island' in kw else ''),'uuid':o.m_Uuid.AsString(),'net':o.GetNetname(),'layer':b.GetLayerName(l),'kind':kind,'bounds':bounds(sh),**kw};objects.append(d);shapes.append(sh)
for f in b.GetFootprints():
 for p in f.Pads():
  ps=p.GetDrillSize();
  if ps.x>0:holes.append({'id':f.GetReference()+'.'+p.GetNumber(),'xy':xy(p.GetPosition()),'drill':xy(ps)})
  for l in layers:
   if p.IsOnLayer(l):
    add(p,l,'pad',p.GetEffectiveShape(l),ref=f.GetReference(),pad=p.GetNumber(),xy=xy(p.GetPosition()),zone=p.GetLocalZoneConnection(),through=p.GetAttribute()==k.PAD_ATTRIB_PTH)
    pads.append(len(objects)-1)
for t in b.GetTracks():
 via=t.GetClass()=='PCB_VIA'
 if via:holes.append({'id':t.m_Uuid.AsString(),'xy':xy(t.GetPosition()),'drill':[mm(t.GetDrillValue())]*2})
 for l in layers:
  if t.IsOnLayer(l):add(t,l,'via' if via else 'track',t.GetEffectiveShape(l),xy=xy(t.GetPosition()),start=xy(t.GetStart()),end=xy(t.GetEnd()),width=mm(t.GetWidth(l)) if via else mm(t.GetWidth()),**({'drill':mm(t.GetDrillValue())} if via else {}))
def ring(c):return [xy(c.CPoint(i)) for i in range(c.PointCount())]
def area(p):return abs(sum(p[i][0]*p[(i+1)%len(p)][1]-p[(i+1)%len(p)][0]*p[i][1] for i in range(len(p)))/2)
for z in b.Zones():
 if z.GetIsRuleArea():
  keep.append(({'name':z.GetZoneName(),'layers':[b.GetLayerName(l) for l in z.GetLayerSet().CuStack()],'deny_vias':z.GetDoNotAllowVias(),'deny_tracks':z.GetDoNotAllowTracks(),'deny_pours':z.GetDoNotAllowZoneFills(),'uuid':z.m_Uuid.AsString()},z.Outline()));continue
 for l in z.GetLayerSet().CuStack():
  ps=z.GetFilledPolysList(l)
  for i in range(ps.OutlineCount()):
   sh=k.SHAPE_POLY_SET();sh.AddOutline(ps.Outline(i));hs=[]
   for h in range(ps.HoleCount(i)):sh.AddHole(ps.Hole(i,h),0);hs.append(ring(ps.Hole(i,h)))
   outer=ring(ps.Outline(i));add(z,l,'zone',sh,island=i,outer=outer,holes=hs,area=area(outer)-sum(area(x) for x in hs))
print('extracted',len(objects),'objects',flush=True)
gnd=[i for i,o in enumerate(objects) if o['net']=='GND'];adj={i:set() for i in gnd};edges=[];pairs=0
for pos,i in enumerate(gnd):
 a=objects[i]
 for j in gnd[:pos]:
  c=objects[j];contact=False;kind='contact'
  if a['uuid']==c['uuid'] and a['layer']!=c['layer'] and (a['kind']=='via' or a.get('through')):contact=True;kind='barrel'
  elif a['layer']==c['layer']:
   aa=a['bounds'];cc=c['bounds']
   if not (aa[2]<cc[0] or cc[2]<aa[0] or aa[3]<cc[1] or cc[3]<aa[1]):pairs+=1;contact=shapes[i].Collide(shapes[j],0)
  if contact:adj[i].add(j);adj[j].add(i);edges.append([i,j,kind])
def pid(ref,pad):return next(i for i in gnd if objects[i].get('ref')==ref and objects[i].get('pad')==str(pad) and objects[i]['layer']=='F.Cu')
planes={i for i in gnd if objects[i]['kind']=='zone' and objects[i]['area']>100}
def bfs(start,targets,forbid=set(),adjacency=adj):
 q=deque([start]);prev={start:None}
 while q:
  i=q.popleft()
  if i in targets:
   p=[]
   while i is not None:p.append(i);i=prev[i]
   return p[::-1]
  for j in sorted(adjacency[i]):
   if j not in prev and j not in forbid:prev[j]=i;q.append(j)
 return None
def summary(i):return {key:val for key,val in objects[i].items() if key not in ('outer','holes')}

carrier='carrier' in str(P);result={'board_path':str(P),'board_sha256':before,'stored_fill_counts':stored,'fill_method':'fresh in-memory fill of exact final saved candidate; no Save','objects':objects,'ground_edges':edges,'ground_nodes':len(gnd),'ground_pair_checks':pairs,'planes':sorted(planes)}
if carrier:
 vmid=[]
 for bank,pin,drop in [(1,6,[91.6,69.5]),(2,8,[89.8,71.5])]:
  owner=pid('U_ADC',pin);drops={i for i in gnd if objects[i]['kind']=='via' and math.dist(objects[i]['xy'],drop)<1e-6}
  for cap in ['470N','4U7']:
   a=pid(f'C_VMID{bank}_{cap}',2);vmid.append(dict(ref=f'C_VMID{bank}_{cap}',owner=summary(owner),drops=[summary(i) for i in drops],intact=bfs(a,planes),cut=bfs(a,planes,drops|{owner}),surface_owner=bfs(a,{owner},{i for i in gnd if objects[i]['layer']!='F.Cu' or objects[i]['kind']=='zone'}),direct_zone=[i for i in adj[a] if objects[i]['kind']=='zone']))
 outpad=pid('C_LDO_OUT',2);quiet=[]
 for ref in ['C_LDO_NR4','C_LDO_NR5','R_LDO_SET']:
  a=pid(ref,2);quiet.append(dict(ref=ref,to_output=bfs(a,{outpad}),intact=bfs(a,planes),cut=bfs(a,planes,{outpad}),direct_zone=[i for i in adj[a] if objects[i]['kind']=='zone']))
 paddle=pid('U_ADC',49);ground=[]
 for pin in [6,8,30,17,44]:
  a=pid('U_ADC',pin);ground.append(dict(pin=pin,surface=bfs(a,{paddle},{i for i in gnd if objects[i]['layer']!='F.Cu'}),through_plane=bfs(a,{paddle})))
 supply=pid('C_VDDA1_10N',2);drops=[i for i in gnd if objects[i]['kind']=='via' and math.dist(objects[i]['xy'],[90,67.5])<1e-6];contain=[]
 for i in drops:
  site=objects[i]['xy'];circ=shapes[i]
  for j in adj[i]:
   o=objects[j]
   if o['kind']!='zone':continue
   rings=[o['outer']]+o['holes'];boundary=[]
   for ring in rings:
    for aa,zz in zip(ring,ring[1:]+ring[:1]):boundary.append(k.SHAPE_SEGMENT(v(*aa),v(*zz),0))
   contain.append(dict(via=summary(i),zone=summary(j),center_inside=shapes[j].Contains(v(*site)),full_disk_margin=min(gap(circ,e) for e in boundary)))
 expected14={f'C_ISO{i}.2' for i in range(1,9)}|{'C_ADC_CM4P.2','C_ADC_CM4N.2','U_LDO_EN.3','C_VDDA1_10N.2','C_VMID1_470N.2','C_VMID2_470N.2'}
 settings=[summary(i) for i in gnd if objects[i]['kind']=='pad' and objects[i].get('ref','')+'.'+objects[i].get('pad','') in expected14]
 result.update(vmid=vmid,quiet=quiet,ground_queries=ground,supply_to_plane=bfs(supply,planes),supply_drop_containment=contain,additional_full_pads=settings)
 target=pid('C_VDDA2_10N',2);owner2=pid('U_ADC',8)
 drops2={i for i in gnd if objects[i]['kind']=='via' and math.dist(objects[i]['xy'],[89.8,71.5])<1e-6}
 surface_forbid={i for i in gnd if objects[i]['layer']!='F.Cu' or objects[i]['kind']=='zone'}
 result['adc2_bypass_return']={'target':summary(target),'owner':summary(owner2),'drops':[summary(i) for i in sorted(drops2)],'intact':bfs(target,planes),'surface_owner':bfs(target,{owner2},surface_forbid),'surface_caps':[bfs(target,{pid('C_VMID2_'+c,2)},surface_forbid) for c in ['470N','4U7']],'cut':bfs(target,planes,drops2|{owner2}),'direct_zone':[i for i in adj[target] if objects[i]['kind']=='zone']}
 result['checks']={'vmid4':len(vmid)==4 and all(r['intact'] and r['surface_owner'] and not r['cut'] and not r['direct_zone'] and len(r['drops'])==4 for r in vmid),'quiet3':len(quiet)==3 and all(r['to_output'] and r['intact'] and not r['cut'] and not r['direct_zone'] for r in quiet),'paddle5':len(ground)==5 and all(not r['surface'] and r['through_plane'] for r in ground),'supply_closure':bool(result['supply_to_plane']) and len(drops)==4,'supply_disk4':len(contain)==4 and all(r['center_inside'] and r['full_disk_margin']>0 for r in contain),'exact14_full_pads':len(settings)==14 and all(r['zone']==2 for r in settings)}
 r2=result['adc2_bypass_return']
 result['checks']['adc2_bypass_designated_return']=bool(r2['intact'] and r2['surface_owner'] and all(r2['surface_caps']) and not r2['cut'] and not r2['direct_zone'] and len(drops2)==4)
else:
 refs=sorted({objects[i]['ref'] for i in gnd if objects[i]['kind']=='pad'});pads_ground=[]
 for i in gnd:
  if objects[i]['kind']=='pad':pads_ground.append(dict(pad=summary(i),plane_path=bfs(i,planes)))
 result['ground_pads']=pads_ground
 result['checks']={'C10_broad_return':bool(bfs(pid('C10',2),planes)),'U3_broad_return':bool(bfs(pid('U3',4),planes))}
 result['R7_C9_remaining_island']=[r for r in pads_ground if r['pad']['ref'] in ['R7','C9']]
assert hashlib.sha256(P.read_bytes()).hexdigest()==before
(S/('carrier-return-graph.json' if carrier else 'pod-return-graph.json')).write_text(json.dumps(result,indent=2));print(result['checks'],flush=True)
sys.exit(0 if all(result['checks'].values()) else 1)
