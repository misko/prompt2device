import sys,pcbnew
from pathlib import Path
p=Path(sys.argv[1]);b=pcbnew.LoadBoard(str(p));b.BuildConnectivity();pcbnew.ZONE_FILLER(b).Fill(b.Zones());b.Save(str(p));print('Standard native zone fill/save',p)
