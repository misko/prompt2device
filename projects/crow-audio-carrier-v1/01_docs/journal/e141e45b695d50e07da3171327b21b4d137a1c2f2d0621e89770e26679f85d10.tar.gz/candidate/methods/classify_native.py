"""Read-only complete native row inventory; no DRC acceptance by counting."""
from pathlib import Path
from collections import Counter
import sys,json,hashlib,pcbnew as k
Q=Path(sys.argv[1]);out=[]
source_by_uuid={};components_by_uuid={}
binding=Q/'carrier-source-native-binding.json'
if binding.exists():
 for row in json.loads(binding.read_text())['all_seed_rows']:
  for uid in row['native_uuids']:source_by_uuid.setdefault(uid,[]).append(row)
graph=Q/'carrier-return-graph.json'
if graph.exists():
 data=json.loads(graph.read_text());adj={i:set() for i,o in enumerate(data['objects']) if o['net']=='GND'}
 for a,b,*rest in data['ground_edges']:adj[a].add(b);adj[b].add(a)
 seen=set();index=0
 for start in adj:
  if start in seen:continue
  group={start};queue=[start];seen.add(start)
  while queue:
   for node in adj[queue.pop()]:
    if node not in seen:seen.add(node);group.add(node);queue.append(node)
  for node in group:
   obj=data['objects'][node];components_by_uuid.setdefault(obj['uuid'],[]).append(dict(component=index,node=node,layer=obj['layer'],kind=obj['kind'],component_nodes=len(group)))
  index+=1
for label,board,report in [('placement',Q/'placement/crow_audio_carrier_v1.kicad_pcb',Q/'placement-drc.json'),('prepared',Q/'work/projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb',Q/'prepared-drc.json')]:
 if not report.exists():continue
 b=k.LoadBoard(str(board));raw=json.loads(report.read_text());items={}
 def add(o,kind,**extra):
  key=o.m_Uuid.AsString();v=o.GetPosition();items[key]=dict(uuid=key,kind=kind,anchor_mm=[k.ToMM(v.x),k.ToMM(v.y)],**extra)
  if hasattr(o,'GetNetname'):items[key]['net']=o.GetNetname()
  if label=='prepared':
   items[key]['declared_seed_owners']=source_by_uuid.get(key,[])
   items[key]['ground_component_memberships']=components_by_uuid.get(key,[])
 for fp in b.GetFootprints():
  add(fp,'footprint',ref=fp.GetReference());add(fp.Reference(),'reference_text',ref=fp.GetReference());add(fp.Value(),'value_text',ref=fp.GetReference())
  for p in fp.Pads():add(p,'pad',ref=fp.GetReference(),pin=p.GetNumber())
  for g in fp.GraphicalItems():add(g,'footprint_graphic',ref=fp.GetReference())
 for t in b.GetTracks():add(t,'via' if t.GetClass()=='PCB_VIA' else 'track')
 for z in b.Zones():add(z,'rule_area' if z.GetIsRuleArea() else 'zone',zone_name=z.GetZoneName(),filled_islands={b.GetLayerName(l):z.GetFilledPolysList(l).OutlineCount() for l in z.GetLayerSet().CuStack()} if not z.GetIsRuleArea() else {})
 for g in b.GetDrawings():add(g,'board_graphic')
 unresolved=[];rows=[]
 for collection in ['violations','unconnected_items','schematic_parity']:
  for index,row in enumerate(raw.get(collection,[])):
   endpoints=[]
   for pos,endpoint in enumerate(row.get('items',[])):
    uid=endpoint.get('uuid');native=items.get(uid)
    if native is None:unresolved.append(dict(collection=collection,index=index,item=pos,uuid=uid))
    endpoints.append(dict(raw=endpoint,native=native))
   nets=sorted({x['native']['net'] for x in endpoints if x['native'] and x['native'].get('net')})
   if collection=='unconnected_items':
    disposition='Missing routing between exact same-net native copper endpoints; this unrouted stage does not discharge the final connectivity gate.'
    if nets==['GND']:disposition='Ground connectivity remains owed between these exact native endpoints. A zone UUID may name several separate filled islands; its anchor alone does not identify which island. Use the separate filled graph for component attribution.'
    if len(nets)!=1:unresolved.append(dict(collection=collection,index=index,reason='Open-row native net identity is not exactly one net',nets=nets))
   elif row.get('type')=='track_dangling':disposition='Native dangling copper endpoint in prepared source copper; retained for source-owner attribution and eventual routed connectivity. Not waived or a clean full DRC result.'
   elif row.get('type')=='starved_thermal':disposition='Actual minimum-spoke violation; owning local return/zone connection requires upstream correction before advancing.'
   else:disposition='Specific native checker refusal retained verbatim; owning causal disposition is unresolved until root and independent review inspect it.';unresolved.append(dict(collection=collection,index=index,reason='Causal disposition owed',type=row.get('type')))
   rows.append(dict(collection=collection,index=index,nets=nets,disposition=disposition,endpoints=endpoints,raw=row))
 counts={x:len(raw.get(x,[])) for x in ['violations','unconnected_items','schematic_parity']}
 result=dict(stage=label,board_sha256=hashlib.sha256(board.read_bytes()).hexdigest(),report_sha256=hashlib.sha256(report.read_bytes()).hexdigest(),counts=counts,violation_types=dict(Counter(x['type'] for x in raw.get('violations',[]))),all_rows=rows,unresolved=unresolved,scope='Complete raw rows and native identities; no routing/DRC/release acceptance. Zone anchors and all possible filled islands are distinct.')
 assert sum(counts.values())==len(rows)
 (Q/(label+'-native-classification.json')).write_text(json.dumps(result,indent=2)+'\n');out.append(dict(stage=label,counts=counts,unresolved=len(unresolved),violation_types=result['violation_types']))
print(json.dumps(out,indent=2));sys.exit(0 if out and all(x['unresolved']==0 for x in out) else 1)
