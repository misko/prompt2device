from pathlib import Path
import sys,unittest,json,importlib
Q=Path(sys.argv[1]);W=Q/'work';P=W/'projects/crow-audio-carrier-v1'
sys.path[:0]=[str(P/'03_src/tests'),str(W/'skills/kicad-pcb/scripts')]
import pcbnew
for name in ['BOARD','LoadBoard','SaveBoard']:
 def forbidden(*a,_name=name,**kw):raise AssertionError('Source preflight forbids '+_name)
 setattr(pcbnew,name,forbidden)
modules=['test_route_source_contract','test_adc_feed_source','test_adc_source','test_adc_feed_invariants','test_thermal_source','test_ground_connections']
loader=unittest.TestLoader();suite=unittest.TestSuite()
for name in modules:
 m=importlib.import_module(name)
 if name=='test_ground_connections':
  for case in loader.getTestCaseNames(m.GroundConnectionTests):
   if case!='test_targets_are_real_smd_ground_lands_on_declared_sides':suite.addTest(m.GroundConnectionTests(case))
 else:suite.addTests(loader.loadTestsFromModule(m))
r=unittest.TextTestRunner(verbosity=2).run(suite)
(Q/'root-source-tests.json').write_text(json.dumps({'run':r.testsRun,'success':r.wasSuccessful(),'failures':[(str(t),s) for t,s in r.failures],'errors':[(str(t),s) for t,s in r.errors],'skipped':r.skipped,'excluded':'Only board-producing ground footprint test; existing native proof remains owed.'},indent=2)+'\n')
sys.exit(0 if r.wasSuccessful() else 1)
