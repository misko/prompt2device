"""Only after actual source FINAL: exact scratch composition, never live adoption."""
from pathlib import Path
from datetime import datetime,timezone
import sys,os,json,hashlib,ast,yaml,copy
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;Q=Path('/tmp/crow-adc2-native5-preparation-8jf47vo0');W=Q/'work';P=W/'projects/crow-audio-carrier-v1'
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
meta=json.loads((N/'rj45-final-return-scope-source1-opened.json').read_text());D=Path(meta['project']);S=Path(meta['scratch_dir']);O=Path(meta['output_dir'])
close=json.loads((N/'rj45-final-return-scope-source1-closeout-summary.json').read_text())
assert close['delivery_status']=='PASS' and close['engineering_verdict']=='SOUND'
assert not (Q/'native-candidate5-started.json').exists() and not (Q/'admission.json').exists()
expected={
 '03_src/floorplan.yaml','03_src/rules/stackup.yaml','03_src/rules/nets.yaml',
 '03_src/tests/test_route_source_contract.py','01_docs/decisions/0030-proposed-top-side-rj45-protection-geometry.md'}
after=S/'after/projects/crow-audio-carrier-v1'
assert {p.relative_to(after).as_posix() for p in after.rglob('*') if p.is_file()}==expected
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for rel in sorted(expected):
 live=R/'projects/crow-audio-carrier-v1'/rel;old=D/'project'/rel;dst=P/rel;new=after/rel
 assert sha(live)==sha(old)==sha(dst),(rel,'preimage')
 rows.append(dict(path='projects/crow-audio-carrier-v1/'+rel,before_sha256=sha(old),after_sha256=sha(new),size=new.stat().st_size))
def parsed(rel,base):return yaml.safe_load((base/rel).read_text())
oldbase=D/'project';a=parsed('03_src/floorplan.yaml',oldbase);b=parsed('03_src/floorplan.yaml',after);x=next(k for k in b['keepouts'] if k['name']=='ADC_WEST_LOCAL');assert x['rect']==[89.35,67.7,93.6,72.35];x['rect'][0]=89.5;assert a==b
old=parsed('03_src/rules/nets.yaml',oldbase);new=parsed('03_src/rules/nets.yaml',after);changed_why=[]
for key in ['scoped_floors','scoped_clearances']:
 aa=next(x for x in old[key] if x['zone']=='ADC_WEST_LOCAL');bb=next(x for x in new[key] if x['zone']=='ADC_WEST_LOCAL');assert aa['why']!=bb['why'];changed_why.append(dict(kind=key,before=aa['why'],after=bb['why']));bb['why']=aa['why']
assert old==new
partial=D/'partial-proposal/after/projects/crow-audio-carrier-v1'
assert (after/'03_src/rules/stackup.yaml').read_bytes()==(partial/'03_src/rules/stackup.yaml').read_bytes()
rel='01_docs/decisions/0030-proposed-top-side-rj45-protection-geometry.md';assert (after/rel).read_bytes().startswith((oldbase/rel).read_bytes())
rel='03_src/tests/test_route_source_contract.py';oldtree=ast.parse((partial/rel).read_text());newtree=ast.parse((after/rel).read_text())
functions=lambda tree:{n.name:ast.dump(n,include_attributes=False) for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
oldf,newf=functions(oldtree),functions(newtree);assert all(newf.get(k)==v for k,v in oldf.items()),'Existing partial functions changed'
# Copy only validated five files to the prepared disposable workspace.
for rel in expected:(P/rel).write_bytes((after/rel).read_bytes())
(Q/'composed-source-manifest.json').write_text(json.dumps({'files':rows,'source_review_archive':close['sha256'],'scope':'Exact root-reviewed source composition; independent source/native acceptance still owed.'},indent=2)+'\n')
cmd=['/usr/bin/python3','-B',str(Q/'methods/root_source_tests.py'),str(Q)]
env={k:os.environ[k] for k in ['PATH','HOME','LANG'] if k in os.environ};env.update(CIRCUITS_ROOT=str(W),PYTHONDONTWRITEBYTECODE='1',GIT_DIR=(R/'.git').read_text().strip().split(': ',1)[1],GIT_WORK_TREE=str(W),KICAD10_FOOTPRINT_DIR='/usr/share/kicad/footprints')
before={p.relative_to(W).as_posix():sha(p) for p in W.rglob('*') if p.is_file()}
result=run_stage({'id':'composed-root-source-preflight','work_class':'local','timeout_s':180},cmd,log_path=Q/'source-preflight.log',cwd=W,env=env)
(Q/'source-preflight-runtime.json').write_text(json.dumps(result.to_mapping(),indent=2)+'\n')
changed=[rel for rel,h in before.items() if not (W/rel).is_file() or sha(W/rel)!=h];assert not changed,changed
receipt={'created_at':datetime.now(timezone.utc).isoformat(),'status':result.status,'files':rows,'all_source_inputs_unchanged':len(before),'two_rationales':changed_why,'prior_partial_functions_preserved':len(oldf),'new_functions':sorted(set(newf)-set(oldf)),'runtime':result.to_mapping(),'native_generated':0,'live_adopted':0}
(Q/'root-source-preflight.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':result.status,'inputs_unchanged':len(before),'postimages':len(rows)}));sys.exit(0 if result.status=='PASS' else 1)
