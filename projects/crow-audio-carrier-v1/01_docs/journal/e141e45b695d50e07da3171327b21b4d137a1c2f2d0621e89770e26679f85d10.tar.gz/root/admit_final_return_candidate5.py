"""Run only after completed source handback, root preflight and full decision review."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,yaml,copy,sys
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;Q=Path('/tmp/crow-adc2-native5-preparation-8jf47vo0');P=R/'projects/crow-audio-carrier-v1'
assert not (Q/'admission.json').exists() and not (Q/'native-candidate5-started.json').exists()
pre=json.loads((Q/'root-source-preflight.json').read_text());assert pre['status']=='PASS' and pre['native_generated']==pre['live_adopted']==0
checks=json.loads((Q/'root-source-tests.json').read_text());assert checks['success'] and checks['run']>=61 and not checks['errors'] and not checks['failures'] and not checks['skipped']
author=json.loads((N/'rj45-final-return-scope-source1-closeout-summary.json').read_text());assert author['delivery_status']=='PASS' and author['engineering_verdict']=='SOUND'
review_paths=[N/'rj45-adc2-exact-source-review1-closeout-summary.json',N/'rj45-return-width-reassessment1-closeout-summary.json'];reviews=[json.loads(p.read_text()) for p in review_paths];assert [r['engineering_verdict'] for r in reviews]==['SOUND','DEFECTIVE'];assert all(r['delivery_status']=='PASS' for r in reviews)
for r in reviews:assert hashlib.sha256(Path(r['archive']).read_bytes()).hexdigest()==r['sha256']
for row in pre['files']:
 assert hashlib.sha256((R/row['path']).read_bytes()).hexdigest()==row['before_sha256']
 assert hashlib.sha256((Q/'work'/row['path']).read_bytes()).hexdigest()==row['after_sha256']
f=P/'01_docs/findings.yaml';before=f.read_text();d=yaml.safe_load(before);updated=copy.deepcopy(d);row=next(x for x in updated['findings'] if x['id']=='CAR-TOP-ONLY-SMD');iv=row['investigation'];assert iv['max_attempts']==4 and len(iv['history'])==4 and len(iv['launches'])==1
spent=set(x['id'] for x in iv['history'])|set(x['id'] for x in iv['launches']);assert len(spent)==4 and all(x['id'] in {h['id'] for h in iv['history']} for x in iv['launches'])
original_history=copy.deepcopy(iv['history']);original_launches=copy.deepcopy(iv['launches'])
evidence=[]
for path in [Q/'root-source-preflight.json',Q/'root-source-tests.json',Q/'composed-source-manifest.json',N/'rj45-final-return-scope-source1-closeout-summary.json',*review_paths]:evidence.append(dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
admission={'created_at':datetime.now(timezone.utc).isoformat(),'decision':'ONE_CUMULATIVE_CANDIDATE5','prior_native_candidates':4,'new_native_candidates_max':1,'cumulative_native_candidates_max':5,'replacements':0,'routing_pilots_max':0,'reviewed_upstream_repairs_supported':True,'composed_source_preflight':'PASS','independent_exact_source_native_acceptance':'OWED_AFTER_THIS_CANDIDATE','decision_and_preflight_evidence':evidence,'decision_scope':'Reviewed ADC2 full bypass-pad plus clearance reservation union, and independently supported ADC1 west whole-capsule permission reconciliation. Existing return routing, all floors and prior history remain exact. Source-author SOUND is a proposal, not independent acceptance.','prior_history':original_history,'prior_launches':original_launches,'on_failure':'Preserve complete result and return upstream; no candidate6 or local geometry retry.','required_native_order':'Ordinary placement P-DRC BEFOREprep, then prepared full DRC/all rows, changed-area source binding, ADC2 designated-return and all prior VMID/LT/paddle/drop controls.'}
# Freeze every prepared source/method file; runtime outputs and earlier labeled
# predecessor are included where present, with no transient symlink dependency.
files=[]
for p in sorted(Q.rglob('*')):
 if p.is_file():
  assert not p.is_symlink();b=p.read_bytes();files.append(dict(path=p.relative_to(Q).as_posix(),size=len(b),sha256=hashlib.sha256(b).hexdigest()))
assert not (Q/'work/projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb').exists()
assert not (Q/'work/projects/crow-audio-carrier-v1/06_build/route/r0.kicad_pcb').exists()
(Q/'input-manifest.json').write_text(json.dumps({'files':files,'scope':'Exact prepared local files. Qualified installed KiCad, standard libraries and system Python remain declared read-only external dependencies; not a hermetic-environment claim.'},indent=2)+'\n')
(Q/'admission.json').write_text(json.dumps(admission,indent=2)+'\n')
iv['max_attempts']=5
iv['next']={'action':'investigate','hypothesis':'The reviewed ADC2 full bypass-pad-clearance return reservation and coherent ADC1 full-capsule width-scope reconciliation can eliminate the ordinary placement thermal defect while retaining all designated return topology in one cumulative fifth construction.','on_support':'Preserve all four prior attempts and this single fifth candidate. Require fresh independent exact composed source/native acceptance, then ordinary source/schematic/placement renewal. No direct live geometry or release acceptance.','on_reject':'Preserve all five actual candidates and classify every real failed stage and DRC/open/parity item; hand the complete causal result upstream. No candidate6, reset, replacement or routing pilot.','uncertainty':'bounded'}
for r in reviews:
 ref='01_docs/journal/'+r['sha256']+'.tar.gz'
 if ref not in row['evidence']:row['evidence'].append(ref)
marker='- id: CAR-TOP-ONLY-SMD\n';a,b=before.split(marker,1);tail=b.find('\n- id: ');assert tail>=0
rendered=a+yaml.safe_dump([row],sort_keys=False,allow_unicode=True,width=110)+b[tail:]
assert yaml.safe_load(rendered)==updated
f.write_text(rendered)
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from decision_progress import evaluate
result=evaluate(P,'CAR-TOP-ONLY-SMD');assert result['decision']=='CONTINUE_BOUNDED',result
(N/'candidate5-prelaunch-decision.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'decision':result['decision'],'frozen_files':len(files),'prior_spend':4,'new_candidate_max':1,'native_launches_now':0}))
