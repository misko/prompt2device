from pathlib import Path
import json
import thermal_review_common as common
source=Path(common.__file__).read_text().replace('rj45-placement-thermal-availability-opened.json','rj45-final-source-native-availability-opened.json')
ns={'__file__':common.__file__};exec(compile(source,'<final-source-native-review>','exec'),ns)
R,N=common.R,common.N;Q=Path('/tmp/crow-adc2-native5-preparation-8jf47vo0');m=json.loads((N/'rj45-final-return-scope-source1-opened.json').read_text());D=Path(m['project']);O=Path(m['output_dir']);S=Path(m['scratch_dir'])
assert (N/'candidate5-completed-assessment.json').is_file()
assert json.loads(Path(m['attempt']).read_text())['status']=='PASS'
copies=[(D/'project','before-project'),(S/'after','after'),(O,'source-delivery'),
 (D/'decision','upstream-decision'),(D/'partial-proposal','partial-proposal'),
 (Q/'work/projects/crow-audio-carrier-v1','project'),(Q/'work/skills','shared/skills'),
 (Q/'source-supplement','root-test-supplement'),(Q/'methods','native/methods'),(Q/'logs','native/logs'),(Q/'placement','native/placement'),
 (D/'canon','canon'),(R/'projects/crow-audio-carrier-v1/01_docs/STATUS.md','current-handoff/STATUS.md'),
 (R/'projects/crow-audio-carrier-v1/01_docs/findings.yaml','current-handoff/findings.yaml'),
 (N/'candidate5-completed-assessment.json','current-handoff/candidate5-completed-assessment.json')]
for p in Q.iterdir():
 if p.is_file():copies.append((p,'native/'+p.name))
task='''# Fresh independent exact composed source and candidate5 judgment

Root owns all live A/P/shared files. This review is READ_ONLY with scratch-only
methods. Read current handoff and full source delivery. Candidate5 is spent;
no additional generation, prep, routing or native Save. Existing boards may be
loaded read-only and refilled IN MEMORY for independent graph analysis, no Save.
Use separately labeled ordinary placement board and prepared board; never grade
later prepared bytes as the earlier placement subject. No source/board adoption.

Exact source scope: original author five postimages PLUS separate root-test-supplement
(the same test file, so five final changed files). Preserve both exact subjects:
root added conflicting points/region/ref/polygon rejection with actual original
helper RED and all23 final route methods GREEN. Original61 single-run evidence
applies to original author bytes; unchanged focused38 plus final23 composes the
final qualification, not a restamped single61run. Independently review this
small supplement and both actual RED/GREENs. Current adopted ADC2 union and their
transitive combination with unchanged hardware/route/thermal/ground authority.
Independently verify every pre/postimage, sole floorplan xmin89.5→89.35, exact
partial CHASSIS shadow, only two appended nets rationales and append-onlyADR0030.
Review all maintained old20 plus3new route tests and whole-document narrow-GND
census/identity/capsule controls; exact ordinary limits, floors/net/layer/deny,
20primitives in10banks/10specs,17at0.18+3at0.20 must retain real authority. Re-run
actual RED on originalfloor and GREEN composedpostimages; reject testweakening,
missing-population vacuity or centerline-only coverage. Verify strong original
whole-capsule obligation and explicit width AND clearance geography rationale.
Independent current1290paired-clearance predicate membership comes from either
net authorized and both object areas overlapping; no false470both-netclaim.
Recheck exact CHASSIS outer-only isolation/reference metadata and all source
via/route/electrical/thermal invariants. Root61tests are evidence, not judgment.

Exact native scope: inspect actual stage logs and source-native bindings. Confirm
ordinary placement P-DRC was run BEFOREprep on the generated saved subject;
classify every actual violation, open and parity row by native UUID/net and real
cause. Prepared dangling/unconnected expected routing work remains unaccepted;
no mere count-summary classification or fake whole-board clean claim. Re-derive
source placements and all83 rule areas, especially complete new50vertexADC2
polygon and exactADC_WEST_LOCAL rectangle/deny/layer. Source roots must bind all
434source seedprimitives (391tracks/43vias), plus11thermalvias. Use actual
consumer3decimalrounding with explicitly measured tiny nm tolerance, not a
centerline argument. All306fittedSMD remain top, including position-excludedSMD.

Independently construct filled connectivity, not producer assertions proving
themselves. Retain fourVMID intended paths and owner/drop cut refusals; threeLT
quiet return-to-output cuts; fiveADC no-surface-paddle queries and fullplane
connectivity; independent ADC1supplydrop full-disk enclosure; source32/native33
fullground and14prior additions. New targetC_VDDA2_10N.2 must connect on F through
its designated ADC8/VMID2 return/drop, have no direct broad-zone contact, and
lose plane reach when that owner/drop is cut. Confirm minimum2resolvedspokes and
thermal0.50 parameters unchanged, full beforeprep thermal symptom closed on the
right stage. Groundzones can have multiple islands; never infer a component
from a raw reported zone anchor alone. U_PWR.2/U_AUDIO.2 residuals and all other
actual cuts/opens must remain separate. Independent known-bad controls must
prove meaningful source and graph assertions can fail. Read actual primary ADC
and existing ADR authority; no new all-layer vendor conformity or noise claim.

Assess actual pad/policy/escape/tier/prep/analog/critical/rules outcomes, prior
courtyard/critical-path/native-arc/source/prep refusals and every NOTRUN stage.
Return precise SOURCE verdict and NATIVE engineering verdict separately, with
bounded adoption recommendation only if exact relevant source/native scope is
SOUND. Later ordinary source/checkpoint/schematic/placement reviews, current
carrier orientation views, podhumanorientation, routing/assembly/fullDRC/release
remain owning gates; these cannot inherit this scoped acceptance. If any real
defect remains, state complete causes and upstream owner; no candidate6/reset.

All frozen files verify before/after, independent methods/rawlogs retained. No
installs, hidden tests or live writes. Installed KiCad/standardfootprints/model
roots are declared read-only external dependencies; inspect actual APIs first.
Five exact outputs and actualFINAL within the envelope. Domain may honestly be
DEFECTIVE/INCOMPLETE while deliveryPASS. No order/release/thermal-current claim.
'''
ns['open_task']('rj45-final-source-native-review1',task,copies,minutes=23)
