from pathlib import Path
import sys,os,hashlib,json,ast
from datetime import datetime,timezone
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;Q=Path('/tmp/crow-adc2-native5-preparation-8jf47vo0');W=Q/'work';P=W/'projects/crow-audio-carrier-v1';rel='projects/crow-audio-carrier-v1/03_src/tests/test_route_source_contract.py';p=W/rel;old=p.read_text();D=Q/'source-supplement';D.mkdir();(D/'before.py').write_text(old)
assert not (Q/'admission.json').exists()
anchor="        # A nonwest narrow owner must also be checked by full radius."
addition="""        # The native consumer gives points/region precedence over rect.
        # Mixed geometry must not be graded using the convenient rectangle.
        for key,value in [('points',[[0,0],[1,0],[1,1],[0,1]]),
                          ('region','another-area'),('ref','U_ADC'),
                          ('polygon',[[0,0],[1,0],[1,1]])]:
            bad=copy.deepcopy(self.floor);west(bad)[key]=value
            self.assertTrue(any(e[0]=='capsule-scope' for e in check(floor=bad)),key)
"""
assert anchor in old;red=old.replace(anchor,addition+anchor);p.write_text(red);(D/'red.py').write_text(red)
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/pcb-design/scripts'));from pipeline_runtime import run_stage
env={k:os.environ[k] for k in ['PATH','HOME','LANG'] if k in os.environ};env.update(CIRCUITS_ROOT=str(W),PYTHONDONTWRITEBYTECODE='1',GIT_DIR=(R/'.git').read_text().strip().split(': ',1)[1],GIT_WORK_TREE=str(W),KICAD10_FOOTPRINT_DIR='/usr/share/kicad/footprints')
results=[]
def run(label,args):
 result=run_stage({'id':label,'work_class':'local','timeout_s':120},['/usr/bin/python3','-B','-m','unittest','-v',*args],log_path=D/(label+'.log'),cwd=P/'03_src/tests',env=env);results.append(result.to_mapping());return result
r=run('shape-discriminator-red',['test_route_source_contract.RouteSourceContractTests.test_narrow_ground_scope_hostile_controls']);assert r.status=='FAIL' and r.returncode==1
log=(D/'shape-discriminator-red.log').read_text();assert 'AssertionError' in log and 'points' in log and 'Ran 1 test' in log and 'ERROR' not in log
fixed=red.replace("if not rect or 'polygon' in area: continue", "if not rect or any(key in area for key in ('points','region','ref','polygon')): continue");assert fixed!=red;ast.parse(fixed);p.write_text(fixed);(D/'after.py').write_text(fixed)
r=run('shape-discriminator-green',['test_route_source_contract']);assert r.status=='PASS'
record={'created_at':datetime.now(timezone.utc).isoformat(),'scope':'Root separate source-test supplement only: reject conflicting shape authority before rectangle containment. Author original proposal/evidence remains unchanged. No engineering geometry/source floor changes. Fresh independent exact combined source/native acceptance owed.','path':rel,'author_after_sha256':hashlib.sha256(old.encode()).hexdigest(),'final_after_sha256':hashlib.sha256(fixed.encode()).hexdigest(),'runtime':results,'red':'Actual old-helper failure to reject conflicting points shape; 1 test, assertion failure, no setup error.','green':'All23 normal route-contract methods pass with old20 preserved and four shape-discriminator controls. Original focused38 qualification still binds unchanged floor/ADC inputs; not rerun.'}
(D/'supplement.json').write_text(json.dumps(record,indent=2)+'\n')
manifest=json.loads((Q/'composed-source-manifest.json').read_text());row=next(x for x in manifest['files'] if x['path']==rel);assert row['after_sha256']==record['author_after_sha256'];row['after_sha256']=record['final_after_sha256'];row['size']=len(fixed.encode());manifest['root_test_supplement']=record
(Q/'composed-source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
pre=json.loads((Q/'root-source-preflight.json').read_text());pre['files']=manifest['files'];pre['root_test_supplement']=record;pre['status']='PASS';(Q/'root-source-preflight.json').write_text(json.dumps(pre,indent=2)+'\n')
print(json.dumps({'supplement':record['final_after_sha256'],'old23red_control':'reproduced','new23':'PASS','native_generated':0}))
