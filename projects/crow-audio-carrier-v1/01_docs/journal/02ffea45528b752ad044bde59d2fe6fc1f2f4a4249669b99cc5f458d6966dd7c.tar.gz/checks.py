from pathlib import Path
import sys,os,json
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
checks=[('checkpoint',['/usr/bin/python3',str(R/'projects/crow-roof-array-v1/03_src/prelayout_input_checkpoint.py'),'verify',str(P),'--repo-root',str(R),'--record',str(P/'06_build/checkpoints/prelayout-inputs.json')]),('contracts',['/usr/bin/python3',str(R/'scripts/contracts_audit.py'),'--projects','--present'])]
for name,argv in checks:
 r=run_stage({'id':'review_failure_'+name,'work_class':'local','timeout_s':120},argv,log_path=D/(name+'.log'),cwd=R,env={'PATH':os.environ['PATH'],'LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'},console_line_limit=3,console_tail_lines=3)
 (D/(name+'-runtime.json')).write_text(json.dumps(r.to_mapping(),indent=2)+'\n')
 assert r.status=='PASS',name
