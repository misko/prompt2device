from pathlib import Path
import json,hashlib,tarfile,shutil,datetime
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';J=P/'01_docs/journal';W=Path(__file__).parent;D=Path('/tmp/carrier-schematic-current-review-20260911');T=D/'06_build/task_runs/schematic-current-readability'
sha=lambda b:hashlib.sha256(b).hexdigest(); rec=lambda p:{'sha256':sha(p.read_bytes()),'size':p.stat().st_size}
items={}
for name in ['TASK.md','bindings.json','subject-manifest.json','render-result.json','render.log']:
 items['packet/'+name]=D/name
for name in ['envelope.json','admission.json','attempt.json','.closing']:
 items['attempt/'+name]=T/name
for p in sorted((T/'outputs').iterdir()):items['outputs/'+p.name]=p
for name in ['diagnose.py','run.py','diagnosis.json','diagnosis.log','diagnosis-runtime.json']:
 items['root-diagnosis/'+name]=W/name
items['root-diagnosis/hypothetical-result.json']=W/'hypothetical-corrected-copy/result.json'
A=W/'delivery-forensics.tar.gz'
with tarfile.open(A,'w:gz') as tf:
 for name,p in sorted(items.items()):tf.add(p,arcname=name,recursive=False)
record=rec(A); dest=J/(record['sha256']+'.tar.gz');assert not dest.exists();shutil.copyfile(A,dest)
subject=D/'subject.tar.gz';sdest=J/(sha(subject.read_bytes())+'.tar.gz');assert not sdest.exists();shutil.copyfile(subject,sdest)
manifest={'schema':1,'status':'FORENSIC_ONLY_INCOMPLETE','source_commit':'bad6b2db7ad063a2955e8bb2b1f7741160ed29ff','archive':{'path':dest.name,**record},'members':{n:rec(p) for n,p in sorted(items.items())},'subject_archive':{'path':sdest.name,**rec(sdest)},'subject_manifest_member':'packet/subject-manifest.json','original_attempt':'attempt/attempt.json','adoption':False}
mp=J/'schematic-current-delivery-20260911-manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(dest,'r:gz') as tf:
 assert set(tf.getnames())==set(items)
 for m in tf:
  b=tf.extractfile(m).read();assert {'sha256':sha(b),'size':len(b)}==manifest['members'][m.name]
assert rec(sdest)==rec(subject)
c=J/'contracts.md'
with c.open('a') as f:
 f.write('\n## Exact retained execution bundles — 2026-09-11\n\nThese closed forensic records are append-only and confer no review acceptance. They live with the stage diary; no source-evidence census or gate input is excluded or reclassified.\n\n| Pattern | What |\n|---|---|\n')
 for name,desc in [(dest.name,'Closed INCOMPLETE readability attempt, original five outputs, raw export archive, packet metadata and independent diagnosis'),(sdest.name,'Exact immutable 236-member review subject archive'),(mp.name,'Whole-archive and member size/SHA-256 inventory; independent reopen audit')]:f.write(f'| `{name}` | {desc} |\n')
 f.write('\nAudit: verify both whole-archive SHA-256/size records; reopen every regular member against its named manifest, reject duplicate/link/traversal entries. The delivery archive embeds the unchanged subject manifest for the second archive. Retain the failed terminal status and original result.json.\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (J/'schematic.md').open('a') as f:
 f.write(f'''\n\n## {now} — stuck: complete reviewer work, rejected delivery\n\n- MEASURED: host FINAL arrived, closure at2026-09-11T04:28:24.165601Z before harddeadline04:35:52.656640Z. READ_ONLY scope PASS with zerochangedpaths. Runtime terminal INCOMPLETE: `result.json needs exactly subject, checks, unresolved`. Original file has extra metadata keys and omits unresolved. No timeout and no adoption.\n- MEASURED: root reopened265/265packetitems,236/236subjectarchive members and115/115evidencearchive members. Reviewer reports SOUND/DO-NOT-ORDER,19PDFpages/19native regions333components; this remains forensic evidence until an admissible handback and owning gate pass. In an isolated diagnostic copy only, the exact three-key JSON passes3/3delivery checks. Original attempt, outputs, closure latch, canonical review and design bytes remain unchanged.\n- INFERENCE: coordinator commission described checks but omitted the exact result skeleton and producer preflight, despite the runtime reference supplying both contract and validator. This made a preventable packaging error terminal. Do not repair a closed attempt or relabel it PASS.\n- OWED: reviewer correction must also state actualpage dimensions (04and15are1013x1500; others1500x1013), label annotation-warning cause as inference unless diagnosed, and explicitly substantiate source-to-native node membership/NC agreement; current comparison scripts prove native-to-supplied connectivity and source-to-native values/MPNs plus counts. No topology defect is inferred from this evidence gap.\n- Durable raw evidence: `{mp.name}`, `{dest.name}`, `{sdest.name}`. Prior P2 presentation observations, source-investigation5/6assessments4milestones, physical/layout/order holds all retained.\n- NEXT: prepared one bounded reviewer-owned handback correction in `schematic-delivery-recovery.md`; not dispatched. Original envelope replacement_limit0 and repairnull require explicit revised authorization. After valid review adoption, PR-REVIEW then mandatory fresh placement owner. No full conductor regeneration is needed for a corrected witness. Root sole live writer; all agents closed.\n''')
(P/'01_docs/STATUS.md').write_text(f'''# STATUS beacon — crow audio carrier v1\n\nstage: schematic\nstep: "Current review delivered, runtime handback INCOMPLETE"\nmeasure: "MEASURED sourcebad6b2db current; original result.json malformed. Host timely;265/265packet,236/236subject,115/115evidence verified. Isolated schema-only diagnostic3/3; no adoption."\nstate: blocked\nnext: "Explicit authorization for one bounded reviewer handback correction; prepared in01_docs/journal/schematic-delivery-recovery.md. Retain closed failed attempt; after correction/adoption run PR-REVIEW then fresh placement."\nop_pid:\nupdated: {now}\n''')
print(json.dumps({'manifest':str(mp),'archive':record,'subject_archive':rec(sdest),'members':len(items)}))
