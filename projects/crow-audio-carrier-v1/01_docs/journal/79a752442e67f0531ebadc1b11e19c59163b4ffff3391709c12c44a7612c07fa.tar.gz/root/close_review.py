from pathlib import Path
import sys,json,hashlib
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');D=Path(__file__).parent;sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_runtime import close_agent_attempt
family,name=sys.argv[1:3];j=next(x for x in json.loads((D/(family+'-opened.json')).read_text()) if x['name']==name);e=TaskEnvelope.from_json(Path(j['envelope']).read_text())
r=close_agent_attempt(e,cwd=Path(j['project']),event={'host':'collaboration','agent_id':j['agent_id'],'state':'completed','envelope_sha256':j['envelope_sha256'],'cleanup':'confirmed','detail':'Root observed actual host FINAL. Delivery closure is separate from engineering adoption.'});print(name,r.status,r.unresolved)
