from pathlib import Path
from datetime import datetime,timezone,timedelta
import sys,json,csv,hashlib,tempfile,shutil
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';C=Path(__file__).parent;B=P/'06_build/pre_route/rotation_authority'
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
sha=lambda b:hashlib.sha256(b).hexdigest();rows={r['LCSC']:r for r in csv.DictReader((P/'06_build/pre_route/preliminary_assembly/rotations_unsourced.csv').open())};pin=json.loads((P/'06_build/pre_route/pin_preparation/manifest.json').read_text());groups={'logic':['C123302','C130024','C131093','C6076'],'control':['C1509297','C96333','C23654'],'power':['C154439','C2071056','C780842'],'analog':['C2863402','C53283916','C7452883']};opened=[]
def copy(src,dst):dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
for name,codes in groups.items():
 D=Path(tempfile.mkdtemp(prefix='carrier-rotations-'+name+'-'));refs=set()
 copy(P/'04_kicad/crow_audio_carrier_v1.kicad_pcb',D/'board.kicad_pcb');copy(Path('/tmp/carrier-keying-source-review-27x1olqz/preflight.py'),D/'preflight.py')
 for code in codes:
  refs.update(rows[code]['refs'].split(','))
  for f in (B/'easyeda'/code).rglob('*'):
   if f.is_file():copy(f,D/'easyeda'/code/f.relative_to(B/'easyeda'/code))
  for f in B.glob('*'+code+'*'):
   if f.is_file():copy(f,D/'measurement'/f.name)
 authorities=[]
 for a in pin['authority']:
  if refs.intersection(a['refs']):
   q=Path(a['part_yaml']);pdf=Path(a['datasheet']);assert sha(pdf.read_bytes())==a['datasheet_sha256'];copy(q,D/'parts'/q.parent.name/q.name);copy(pdf,D/'parts'/q.parent.name/pdf.name);authorities.append(a)
 for ref in refs:copy(P/'06_build/pre_route/pin_preparation/dossiers'/f'{ref}.md',D/'dossiers'/f'{ref}.md')
 (D/'scope.json').write_text(json.dumps({'codes':[rows[x] for x in codes],'refs':sorted(refs),'authority':authorities},indent=2)+'\n')
 for rel in ['skills/jlcpcb-fab/references/assembly-and-order.md','skills/jlcpcb-fab/scripts/jlc_rotation_measure.py','skills/jlcpcb-fab/scripts/jlc_rotation_resolve.py','skills/jlcpcb-fab/scripts/jlc_lcsc_rotations.csv']:
  copy(R/rel,D/'authority'/Path(rel).name)
 now=datetime.now(timezone.utc);cut=now+timedelta(minutes=20);hard=now+timedelta(minutes=22)
 (D/'TASK.md').write_text(f'''Independent A-ROT/A-POL judgment, agent-role judgment standard/full effort. Fresh context, no children. Read authority/assembly-and-order.md and scope.json. Review ONLY assigned exact codes/refs; unchanged board is the subject. Root-owned measurements are hypotheses, not conclusions. Derive supplier zero-orientation and physical pin/function mapping from exact supplied manufacturer PDFs, cached EasyEDA/JLC footprint/model and native board pad/graphics. Render and actually view manufacturer package/pin figures and relevant catalog/native geometry where needed. Preserve figures and raw evidence.

Check pad-number fit with pcbnew-verified operator, next-best/mirror ambiguity, package identity, every assigned repeat instance's footprint congruence, and numbering-free physical polarity/pin1 channels. Never use jlc_twin fitted offset as authority. Do not label IC pin-dot following numbering as independent physical polarity evidence without documenting its relation to manufacturer pin-1. For polarized 2-pad diode, band/function channel is mandatory; a 180-perfect number fit is insufficient. If only a permitted single-channel determination is justified, explicitly cite exact evidence and required final JLC preview gate in row, with polarity single-channel. No invented channel or relaxed fit threshold. Flag mismatched catalog package/pad geometry and missing authority as blocking findings. You may recommend no row for an unresolved code.

Deliver report.md with PASS/FAIL/QUESTION for each code, measured offset/residual/separation, actual evidence pages/figures/hashes, provenance of copied preliminary measurement, exact current board SHA, actual completionUTC and limits. proposed-rows.csv must use existing table header and ONLY evidence-supported rows; not live authority. Parent will independently reopen and adopt or reject later. evidence.json contains all command arrays,cwd,raw log paths,rc/timing,input verification,visual inspection, per-code/ref coverage. Use bounded pipeline_runtime.run_stage from {R}/skills/pcb-design/scripts (sys.dont_write_bytecode=True) for native/export processes; no installs/network needed. READ_ONLY isolated inputs: helpers/exports/logs only allocated scratch. Do not alter live board/source or copy proposed rows to live table. Do not follow absolute model paths outside packet; rebase only diagnostic scratch copies if necessary.

Delivery EXACT report.md, proposed-rows.csv, evidence.json, evidence-manifest.json, evidence.tar.gz, result.json in allocated outputs. Tar contains review scratch scripts/logs/figures only with per-member path/size/SHA and archiveSHA/size in evidence-manifest.json. All files required even if report is defective; CSV may contain only header when no supported row. result.json EXACT {{"subject": <envelope.subject>, "checks": {{"evidence-complete":"PASS","inputs-verified":"PASS","review-complete":"PASS"}}, "unresolved": []}} for complete delivered review regardless engineering verdict. Verify all inputs before/after. Preflight /usr/bin/python3 {D}/preflight.py <allocated envelope.json> BEFORE FINAL; correct routine packaging within same live attempt. Root closes once actual FINAL received. Work/FINAL cutoff {cut.isoformat()}, hardclose {hard.isoformat()}. Reserve2min packaging. One bounded attempt, do not silently expand scope.
''')
 items=[]
 for f in sorted(D.rglob('*')):
  if f.is_file():b=f.read_bytes();items.append({'name':f'input_{len(items):04d}','path':f.relative_to(D).as_posix(),'size':len(b),'sha256':sha(b)})
 s=subject_identity('placement_rotation_review',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())]);run='rotations-'+name
 e=TaskEnvelope(schema=2,task_id=run,stage_id='KICAD-PLACEMENT',run_id=run,subject=s,executor='reviewer',execution_class='review_wait',recommended_agent_role='judgment',agent_role='judgment',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=run,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{run}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','proposed-rows.csv','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']})
 o=open_agent_attempt(e,cwd=D);o.update(name=name,agent_id='/root/carrier_rotation_'+name,project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),work_cutoff=cut.isoformat());opened.append(o)
(C/'rotations-opened.json').write_text(json.dumps(opened,indent=2)+'\n')
for o in opened:print(o['name'],o['project'],o['envelope'])
