from pathlib import Path
import json,tarfile,hashlib,csv,yaml,sys
from PIL import Image,ImageChops,ImageStat
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;O=P/'06_build/pre_route/orientation';A=P/'01_docs/reports/assets/2026-09-11-connector-orientation';F=P/'08_reviews/connector_orientation.yaml'
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/jlcpcb-fab/scripts'))
from connector_orientation_gate import validate_approval
sha=lambda b:hashlib.sha256(b).hexdigest()
with tarfile.open(P/'01_docs/journal/2fe3d6466a783543b7d58f25553c8d279007f92d8fc0c5006ddd0a88fd74ba42.tar.gz') as t:
 olddata=t.extractfile('pre_route/orientation/orientation_receipt.json').read()
assert sha(olddata)=='089093f4b2cf8cc99d607f0286076d16047e0ec7634a8d326b3cfdd50d057842'
old=json.loads(olddata);new=json.loads((O/'orientation_receipt.json').read_text())
assert old.keys()==new.keys()
changes=[k for k in old if old[k]!=new[k]];assert changes==['evidence'],changes
assert sha((P/'04_kicad/crow_audio_carrier_v1.kicad_pcb').read_bytes())==old['observed_board_sha256']
rows=list(csv.DictReader((A/'image-manifest.csv').open()));idx={r['file']:r for r in rows};stats=[]
for rel,h in old['evidence'].items():
 f=A/Path(rel).name;assert sha(f.read_bytes())==h==idx[f.name]['sha256'];assert idx[f.name]['orientation_subject_sha256']==old['subject_sha256']
 d=ImageChops.difference(Image.open(f).convert('RGB'),Image.open(O/rel).convert('RGB'));stats.append({'file':rel,'old_sha256':h,'new_sha256':new['evidence'][rel],'difference_bbox':d.getbbox(),'channel_extrema':d.getextrema(),'mean_absolute_difference':ImageStat.Stat(d).mean})
# Retain the CLI-generated record as an unadopted diagnostic. Its image hashes
# describe rerendered images rather than the exact packet the user saw.
(D/'orientation-cli-record-unadopted.yaml').write_bytes(F.read_bytes());v=yaml.safe_load(F.read_text());assert v['subject_sha256']==old['subject_sha256'];assert v['refs']==old['refs']
# Existing schema-2 carry-forward retains ORIGINAL viewed evidence. No checker,
# source, board, model, denominator or threshold is modified.
v['schema']=2;v['approval_basis']='semantic-subject-unchanged';v['evidence_sha256']=old['evidence']
candidate=D/'orientation-approval-candidate.yaml';candidate.write_text(yaml.safe_dump(v,sort_keys=False));ok,why=validate_approval(candidate,new['subject_sha256'],new['refs'],new['evidence']);assert ok,why
F.write_bytes(candidate.read_bytes())
(D/'orientation-approval-proof.json').write_text(json.dumps({'old_receipt_sha256':sha(olddata),'new_receipt_sha256':sha((O/'orientation_receipt.json').read_bytes()),'changed_receipt_fields':changes,'board_sha256':old['observed_board_sha256'],'subject_sha256':old['subject_sha256'],'reviewed_images_verified':len(stats),'approval_sha256':sha(F.read_bytes()),'validation':why,'basis':'Existing schema-2 behavior from 9d7b6a03, regression-tested in t1_connector_orientation.py. Actual user quote applies to exact original 13-image packet. Board and all receipt fields other than rendered image hashes are byte-identical. Root viewed old/new J9 outside; no fresh approval inferred for changed geometry.','pixel_statistics':stats},indent=2)+'\n')
print('Recorded original reviewed image hashes; unchanged geometry, models, native tool, measurements and all9 refs. '+why)
for s in stats:print(s['file'],s['channel_extrema'],s['mean_absolute_difference'])
