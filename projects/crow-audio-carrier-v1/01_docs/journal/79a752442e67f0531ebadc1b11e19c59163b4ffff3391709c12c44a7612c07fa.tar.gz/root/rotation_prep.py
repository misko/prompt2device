from pathlib import Path
import sys,csv,json,os,time
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=P/'06_build/pre_route/rotation_authority';D.mkdir(parents=True,exist_ok=True)
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/jlcpcb-fab/scripts'));sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from jlc_twin import E2K,easyeda2kicad_command
from pipeline_runtime import run_stage
assert E2K
rows=list(csv.DictReader((P/'06_build/pre_route/preliminary_assembly/rotations_unsourced.csv').open()));receipts=[];deadline=time.monotonic()+550
for row in rows:
 code=row['LCSC'];d=D/'easyeda'/code;d.mkdir(parents=True,exist_ok=True);mods=list(d.rglob('*.kicad_mod'))
 for attempt in range(2):
  if mods:break
  if time.monotonic()>=deadline:break
  cmd=[*easyeda2kicad_command(E2K),'--full','--lcsc_id',code,'--output',str(d/'jlc.kicad_sym'),'--use-cache']
  stage=f'fetch-{code}-{attempt+1}';(D/(stage+'-command.json')).write_text(json.dumps({'argv':cmd,'cwd':str(D)},indent=2)+'\n')
  result=run_stage({'id':stage,'work_class':'network','timeout_s':min(45,deadline-time.monotonic())},cmd,cwd=D,log_path=D/(stage+'.log'),env={'PATH':os.environ['PATH'],'HOME':os.environ['HOME'],'LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'},console_line_limit=3,console_tail_lines=2);receipts.append(result.to_mapping());(D/(stage+'-runtime.json')).write_text(json.dumps(result.to_mapping(),indent=2)+'\n');mods=list(d.rglob('*.kicad_mod'))
  if not mods and attempt==0:time.sleep(4)
 if not mods:print('FETCH-FAILED',code,flush=True);continue
 ref=row['refs'].split(',')[0];cmd=['/usr/bin/python3',str(R/'skills/jlcpcb-fab/scripts/jlc_rotation_measure.py'),str(P/'04_kicad/crow_audio_carrier_v1.kicad_pcb'),ref+'='+code,'--cache',str(D),'--row'];stage='measure-'+code
 (D/(stage+'-command.json')).write_text(json.dumps({'argv':cmd,'cwd':str(D)},indent=2)+'\n');result=run_stage({'id':stage,'work_class':'local','timeout_s':30},cmd,cwd=D,log_path=D/(stage+'.log'),env={'PATH':os.environ['PATH'],'HOME':os.environ['HOME'],'LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'},console_line_limit=3,console_tail_lines=2);receipts.append(result.to_mapping());(D/(stage+'-runtime.json')).write_text(json.dumps(result.to_mapping(),indent=2)+'\n')
(D/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print('Done: review proposed measured rows; no authority table mutation.')
