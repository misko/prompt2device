from pathlib import Path
from datetime import datetime,timezone,timedelta
import sys,json,hashlib,tempfile,shutil
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';B=P/'06_build/pre_route/pin_preparation';C=Path(__file__).parent
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
m=json.loads((B/'manifest.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
groups={'connectors':[4,5,51],'switches':[3,8,9,23],'power':[10,30,57],'adc':[22],'analog':[31,52,53],'logic':[6,7,49,50],'supervision':[48,54,55],'diodes':[11,12,47,56],'fuses':[1,2],'capacitors_a':[0,13,14,24],'capacitors_b':[15,16,17,18],'capacitors_c':[19,25,26,27],'capacitors_d':[28,29,32],'resistors_a':[20,21,33,34],'resistors_b':[35,36,37,38],'resistors_c':[39,40,41,42],'resistors_d':[43,44,45,46]}
assert sorted(i for v in groups.values() for i in v)==list(range(58))
opened=[]
for name,indices in groups.items():
 D=Path(tempfile.mkdtemp(prefix='carrier-pins-'+name+'-'));rows=[]
 for i in indices:
  a=m['authority'][i];pdf=Path(a['datasheet']);data=pdf.read_bytes();assert sha(data)==a['datasheet_sha256'];dest=D/'datasheets'/f'{i:02d}.pdf';dest.parent.mkdir(exist_ok=True);dest.write_bytes(data)
  refs=a['refs'];rows.append({'mpn':a['mpn'],'refs':refs,'datasheet':dest.relative_to(D).as_posix(),'sha256':sha(data)})
  for ref in refs:
   dest=D/'dossiers'/f'{ref}.md';dest.parent.mkdir(exist_ok=True);dest.write_bytes((B/'dossiers'/dest.name).read_bytes())
 (D/'parts.json').write_text(json.dumps(rows,indent=2)+'\n')
 shutil.copyfile(R/'skills/kicad-pcb/references/pin-review-protocol.md',D/'protocol.md')
 shutil.copyfile('/tmp/carrier-keying-source-review-27x1olqz/preflight.py',D/'preflight.py')
 now=datetime.now(timezone.utc);cut=now+timedelta(minutes=22);hard=now+timedelta(minutes=24)
 (D/'TASK.md').write_text(f'''Fresh independent pin review; agent-role judgment, standard/full effort. No prior conversation, design rationale or children. Your ONLY engineering inputs are protocol.md, parts.json, dossiers/ and their exact hash-selected datasheets/. Read the protocol completely. Independently derive datasheet pin identities/winding BEFORE comparing dossiers, rendering relevant figures with pdftoppm and viewing actual PNGs. Do not take dossier verification notes as proof. Review EVERY listed instance, including two/three-pin and passive parts. Nonpolar/symmetric packages can be explicitly N/A for winding, never for physical pin count/coverage. Disambiguate top/bottom/mating views using manufacturer drawing. Net-name inference is limited: use QUESTION for any required missing context. Never use external project/schematic/history to answer it.

Frozen board SHA {m['board_sha256']}, compiled source SHA {m['circuit_json_sha256']}. Copied dossier content may mention original paths; use only supplied PDFs, not those external paths. Every MPN/ref must have explicit VERDICT PASS/FAIL/QUESTION plus protocol findings and datasheet page/figure, actual pin count/EP and per-instance mapping comparison. Report justified PASS or genuine defects/questions without softening or invention. Full report must list all actual refs and exact PDF/dossier hashes, actual reviewed figure images, source of top/bottom view and rotation/mirror reasoning. Engineering FAIL/QUESTION can still be a complete delivered review; do not turn it into false PASS.

READ_ONLY isolated input root. Helpers, exports, render images and lossless command logs only in allocated scratch (<envelope parent>/scratch). Read envelope/admission; verify every input size/SHA before and after work. Use bounded subprocesses with explicit argv/cwd/logs via pipeline_runtime.run_stage (import from {R}/skills/pcb-design/scripts; set sys.dont_write_bytecode=True); full command arrays, actual rc/time and rawstdout/stderr belong in evidence. No editing live project/source/reviews, no network required or new packages. No bytecode in immutable inputs. Every image supporting judgment must be actually viewed and retained.

Final outputs exactly report.md, evidence.json, evidence-manifest.json, evidence.tar.gz, result.json in <envelope parent>/outputs. Archive contains all your scratch-created scripts/logs/figures/evidence, with per-member path/size/SHA manifest; do not archive inputs again. evidence.json records coverage per MPN/ref, input verification, commands and actual visual inspection. result.json EXACT keys: {{"subject": <envelope.subject>, "checks": {{"evidence-complete":"PASS","inputs-verified":"PASS","review-complete":"PASS"}}, "unresolved": []}} when complete delivery, regardless engineering verdict. Routine packaging repair is allowed within this SAME live attempt before FINAL. Run /usr/bin/python3 {D}/preflight.py <allocated envelope.json> before FINAL and correct any delivery/scope mistake. Root closes actual attempt after your FINAL; do not self-close.

Work and FINAL cutoff {cut.isoformat()}; hard closure {hard.isoformat()}. Reserve last two work minutes for packaging. One attempt; promptly return truthful INCOMPLETE for actual unfinishable scope. Do not wait until deadline when finished.
''')
 items=[]
 for f in sorted(D.rglob('*')):
  if f.is_file():b=f.read_bytes();items.append({'name':f'input_{len(items):04d}','path':f.relative_to(D).as_posix(),'size':len(b),'sha256':sha(b)})
 subject=subject_identity('placement_pin_review',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())]);run='pins-'+name
 e=TaskEnvelope(schema=2,task_id=run,stage_id='KICAD-PLACEMENT',run_id=run,subject=subject,executor='reviewer',execution_class='review_wait',recommended_agent_role='judgment',agent_role='judgment',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=run,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{run}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']})
 o=open_agent_attempt(e,cwd=D);o.update(name=name,agent_id='/root/carrier_pin_'+name,project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),work_cutoff=cut.isoformat());opened.append(o)
(C/'pins-opened.json').write_text(json.dumps(opened,indent=2)+'\n')
for o in opened:print(o['name'],o['project'],o['envelope'])
