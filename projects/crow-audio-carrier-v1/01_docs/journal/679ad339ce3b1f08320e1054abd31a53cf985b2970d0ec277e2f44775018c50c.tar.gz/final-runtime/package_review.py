from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,shutil,datetime
S=Path(__file__).resolve().parent;T=S.parent;P=T.parents[2];A=S/'author-reopened';O=T/'outputs'
sha=lambda data:hashlib.sha256(data).hexdigest()
env=json.loads((T/'envelope.json').read_text())
canonical=sha(json.dumps(env,sort_keys=True,separators=(',',':')).encode())
assert canonical=='2f2a54d2d7314e426428d55809008c990a35c424620bcbd16db60addc1cd930a'
for row in env['input_packet']:
    data=(P/row['path']).read_bytes();assert len(data)==row['size'] and sha(data)==row['sha256']
author_manifest=json.loads((P/'author/evidence-manifest.json').read_text())
archive=P/'author/evidence.tar.gz';assert sha(archive.read_bytes())==author_manifest['archive_sha256'] and archive.stat().st_size==author_manifest['archive_size']
expected={row['path']:row for row in author_manifest['members']};seen=set()
with tarfile.open(archive) as tf:
    for member in tf:
        path=PurePosixPath(member.name)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts and member.name not in seen
        seen.add(member.name);data=tf.extractfile(member).read();row=expected[member.name]
        assert len(data)==row['size'] and sha(data)==row['sha256']
assert seen==set(expected) and len(seen)==1807
verification={'canonical_envelope_sha256':canonical,'input_count':len(env['input_packet']),
              'inputs':env['input_packet'],'author_archive_sha256':author_manifest['archive_sha256'],
              'author_archive_members_verified':len(seen),'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(S/'verification-final.json').write_text(json.dumps(verification,indent=2))
native=json.loads((S/'native-verification.json').read_text())
author=json.loads((P/'author/evidence.json').read_text())
finding={'id':'R1','priority':'P1','domain_result':'CORRECTION_REQUIRED',
         'file':'skills/jlcpcb-fab/scripts/connector_orientation_gate.py','lines':[731,752],
         'title':'Validate cached receipt content, not only its subject label',
         'reproduction':'A real nonconnector addition is refused until only the stale receipt subject label is updated; then the exact candidate approves unchanged old pixels while retaining a scene that omits that body. Independent producer/camera/measurement/origin metadata contradictions also pass.',
         'evidence':'hostile-reuse/results.json','correction':'Validate every cached semantic/producer/measurement field against freshly derived current expectations and preserve verifiable rendered versus observed origin; retain exact schema1 pixels and deliberate unchanged-semantic schema2 compatibility. No camera search or parser repair.'}
evidence={'domain_result':'CORRECTION_REQUIRED','delivery_result':'complete honest independent source-review handback',
          'subject':env['subject'],'envelope_sha256':canonical,'findings':[finding],
          'inputs_verified':650,'author_archive_members_verified':1807,
          'source_files':author['source_files'],'native':native,
          'independent_runs':{name:json.loads((S/'logs'/f'{name}.runtime.json').read_text()) for name in ['maintained-regressions','independent-native-carrier','hostile-reuse','native-population-control','native-verification']},
          'regressions':{'passed':18,'known_bad':6,'vacuity':1,'elapsed_s':20.766},
          'read_only_live_bindings':json.loads((S/'live-final-verification.json').read_text()),
          'reviewed_author_controls':['RED-before/GREEN-after orientation regressions','signed-Z inverted-native known-bad','mating-datum substitution and native-retention controls','authority/docs/contracts reports'],
          'limitations':['Current carrier evidence only: no product user approval, source adoption, routing or release acceptance.','Scene census proves declarations/resolution, not every rendered visible body.','Current31primary files verified; no generic transitive-resource completeness claim.','Local film capacitors hide lower J1/J5 rear portions; upper target rear shields are identifiable.','Future route-heavy invocation and full pod orientation bundle were not measured. Aggregate300s suite timeout is not a per-invocation result.','Auxiliary normal/DNP exact-pixel equality assertion failed; original failure/images retained and visibility property assessed from those same native images without rerender.'],
          'delivery_preflight':'Provided preflight must run after these exact five outputs are finalized.',
          'live_source_edits':False,'human_orientation_approval':'OWED','source_adoption':'NOT ACCEPTED',
          'fabrication_status':'FIRST-ARTICLE-ONLY / DO-NOT-ORDER'}
O.mkdir(exist_ok=True)
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
shutil.copy2(S/'report-draft.md',O/'report.md')
(O/'result.json').write_text(json.dumps({'subject':env['subject'],'checks':{key:'PASS' for key in env['completion']['checks']},'unresolved':[]},indent=2)+'\n')
files={}
def add_file(source,name):
    source=Path(source);path=PurePosixPath(name)
    assert source.is_file() and not source.is_symlink() and not path.is_absolute() and '..' not in path.parts and name not in files
    files[name]=source
def add_tree(source,prefix):
    for q in sorted(Path(source).rglob('*')):
        if '__pycache__' in q.parts: continue
        if q.is_file():add_file(q,str(PurePosixPath(prefix)/q.relative_to(source)))
for n in ['stage.py','hostile_reuse.py','native_population_control.py','verify_native.py','package_review.py']:
    add_file(S/n,'methods/'+n)
for n in ['verification-initial.json','verification-final.json','live-beforeimages.json','live-final-verification.json','supplemental-inputs.json','native-verification.json']:
    add_file(S/n,'bindings/'+n)
add_file(T/'envelope.json','bindings/review-envelope.json')
add_file(P/'author/evidence-manifest.json','bindings/author-evidence-manifest.json')
add_file(P/'TASK.md','bindings/TASK.md')
add_file(P/'preflight.py','methods/provided-preflight.py')
for source,prefix in [(S/'independent-native-carrier','independent-native-carrier'),(S/'hostile-reuse','hostile-reuse'),(S/'logs','independent-logs'),(S/'verified-models','models'),(A/'source_candidate','source_candidate'),(A/'beforeimages','beforeimages'),(A/'native-carrier-candidate-two','reviewed-author/native-carrier-candidate-two'),(A/'prior_orientation','reviewed-author/prior_orientation'),(A/'logs','reviewed-author/logs'),(A/'qualification','reviewed-author/qualification'),(A/'tmp/model_registration_gsps7z8p','reviewed-author/signed-z-fixture'),(S/'repo/skills','runtime-dependencies/skills'),(S/'repo/tests','runtime-dependencies/tests'),(S/'repo/archived_projects','runtime-dependencies/archived_projects')]:
    add_tree(source,prefix)
for n in ['candidate.diff']:
    add_file(A/n,'source_candidate/'+n)
for n in ['gate-contracts.json','signed-z-inputs.json','wrl-dependency-inspection.json','native-evidence-verification.json']:
    add_file(A/'methods'/n,'reviewed-author/methods/'+n)
for n in ['04_kicad/crow_audio_carrier_v1.kicad_pcb','03_src/rules/model_registration.yaml','03_src/floorplan.yaml']:
    add_file(S/'repo/projects/crow-audio-carrier-v1'/n,'native-inputs/'+n)
fixture=Path(json.loads((S/'hostile-reuse/results.json').read_text())['fixture'])
add_tree(fixture/'03_src','hostile-reuse/source-fixture/03_src')
records=[]
with tarfile.open(O/'evidence.tar.gz','w:gz') as tf:
    for name,source in sorted(files.items()):
        data=source.read_bytes();records.append({'path':name,'size':len(data),'sha256':sha(data)})
        tf.add(source,arcname=name,recursive=False)
manifest={'archive_sha256':sha((O/'evidence.tar.gz').read_bytes()),'archive_size':(O/'evidence.tar.gz').stat().st_size,'member_count':len(records),'members':records}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
expected={row['path']:row for row in records};seen=set()
with tarfile.open(O/'evidence.tar.gz') as tf:
    for member in tf:
        path=PurePosixPath(member.name)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts and member.name not in seen
        seen.add(member.name);data=tf.extractfile(member).read();row=expected[member.name]
        assert len(data)==row['size'] and sha(data)==row['sha256']
assert seen==set(expected) and set(q.name for q in O.iterdir())=={'report.md','evidence.json','evidence-manifest.json','evidence.tar.gz','result.json'}
(S/'archive-reopen-verification.json').write_text(json.dumps({'status':'PASS','archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'regular_members_reopened':len(seen),'duplicates':0,'unsafe_paths':0,'nonregular_members':0},indent=2))
print(json.dumps({'outputs':str(O),'domain_result':evidence['domain_result'],'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'members_reopened':len(seen)},indent=2))
