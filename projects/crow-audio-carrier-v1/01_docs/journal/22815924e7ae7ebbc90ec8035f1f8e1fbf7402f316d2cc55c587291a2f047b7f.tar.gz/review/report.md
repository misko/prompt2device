review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_jacks_clockground1 (fresh independent agent)
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: e85b1461a82f3d3853c19fae694693816e31570d23d37019ef187d6428bea4ae
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: e6d5b0b89efd79051b082f70b283ec7e85e1170ed11ddb94581744d26904c9c7

Limited coverage: J1–J8 pin identities, package orientation, contact/net sanity and instance symmetry only. No whole-board acceptance or order authorization. Subject bindings above are immutable metadata, not independently reviewed board conclusions. Dossier author-verification notes were not used as engineering evidence. No schematic, live board, historical review, or external model was inspected.

Primary document: Würth 615008160221, revision 001.003, 2025-07-09, SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048. Page 1 figures “Dimensions” and “Recommended Hole Pattern”; page 2 “Article Properties” and “Electrical Properties”. Images of all six pages inspected before dossiers and retained.

Independent geometric derivation: In the hole-pattern image, upper row reads 8,6,4,2 left to right and lower row reads 7,5,3,1. Pin 1 is lower-right; same-row pitch 2.04 mm, stagger 1.02 mm, row spacing 4.00 mm. This is a zigzag contact array, not a sequential perimeter winding. The drawing does not print a TOP/BOTTOM label. The upper-left mechanical view shows the underside, with visible individual contact tails and opposite lateral stagger; the recommended hole pattern is its opposite-side board/component-top projection. This establishes the view geometrically, rather than borrowing the dossier's winding assertion. Converting the underside to component-top requires one lateral reflection; the supplied recommended board pattern already has that reflection. It is compared with dossier component-top by 180-degree rotation only, with no further mirror.

Relative to pin 1, rotated expected coordinates are 1=(0,0), 2=(1.02,4), 3=(2.04,0), 4=(3.06,4), 5=(4.08,0), 6=(5.10,4), 7=(6.12,0), 8=(7.14,4) mm. Pin 1 is the upper-left signal contact in dossier local coordinates. Two separate shield lands are at (10.97,-2.35) and (-3.83,-2.35), separated 14.8 mm. Two 3.18-mm NPTH locators are at (-3.28,0.70) and (10.42,0.70), separated 13.7 mm. All eight dossiers match these identities and coordinates. The mechanical drawing does not assign shield numbers 9 and 10; these are distinct artifact identifiers for its two separate shell legs. No fused alias or collapsed physical identity is used. No exposed pad exists or is required.

All instances explicitly declare front mounting and +x right/+y down component-top coordinates. J1–J4 use native rotation 0°, J5–J8 use 180°. Every native pad and locator coordinate matches the stated translation/rotation. The dossier's CCW label is not an independently meaningful connector winding result, particularly when shell identities are appended to the zigzag contacts; the individual physical comparisons govern.

Electrical scope: This is a passive wired 8P8C jack, not a device assigning audio/power/ground functions to particular contacts. All eight contacts remain separate. Application nets on contacts are electrically plausible; CHASSIS on both shell legs matches their shielding role. No manufacturer-required signal polarity, NC, power-in or ground pin assignment is violated. The dossier maps contact 4 to AUDIO_N and 5 to AUDIO_P uniformly; this review does not establish a remote cable endpoint contract or operating current, which are outside this pin/package commission.

J1 VERDICT: PASS
Measured native inventory: 10 numbered THT copper pads = 8 contact identities + 2 separate shield identities; 2 unnumbered NPTH features; 12 total native pad/mechanical features; EP 0; fused aliases 0. Primary evidence: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Dimensions / Recommended Hole Pattern, page 2 Article Properties. Expected all 10 conductive positions and two locator positions as derived above; observed exact match, including native board transform at origin [38.0, 25.86] and rotation 0.0°.
J1 pin 1 (CONTACT_1): expected separate passive contact with matching physical number at [0.0, 0.0]; observed local [0.0, 0.0], native [38.0, 25.86], net 12V_POD1; PASS.
J1 pin 2 (CONTACT_2): expected separate passive contact with matching physical number at [1.02, 4.0]; observed local [1.02, 4.0], native [39.02, 29.86], net GND; PASS.
J1 pin 3 (CONTACT_3): expected separate passive contact with matching physical number at [2.04, 0.0]; observed local [2.04, 0.0], native [40.04, 25.86], net 12V_POD1; PASS.
J1 pin 4 (CONTACT_4): expected separate passive contact with matching physical number at [3.06, 4.0]; observed local [3.06, 4.0], native [41.06, 29.86], net AUDIO_N1; PASS.
J1 pin 5 (CONTACT_5): expected separate passive contact with matching physical number at [4.08, 0.0]; observed local [4.08, 0.0], native [42.08, 25.86], net AUDIO_P1; PASS.
J1 pin 6 (CONTACT_6): expected separate passive contact with matching physical number at [5.1, 4.0]; observed local [5.1, 4.0], native [43.1, 29.86], net GND; PASS.
J1 pin 7 (CONTACT_7): expected separate passive contact with matching physical number at [6.12, 0.0]; observed local [6.12, 0.0], native [44.12, 25.86], net 12V_POD1; PASS.
J1 pin 8 (CONTACT_8): expected separate passive contact with matching physical number at [7.14, 4.0]; observed local [7.14, 4.0], native [45.14, 29.86], net GND; PASS.
J1 pin 9 (SHIELD_S1): expected separate shielding leg on a shield/chassis net at [10.97, -2.35]; observed local [10.97, -2.35], native [48.97, 23.51], net CHASSIS; PASS.
J1 pin 10 (SHIELD_S2): expected separate shielding leg on a shield/chassis net at [-3.83, -2.35]; observed local [-3.83, -2.35], native [34.17, 23.51], net CHASSIS; PASS.

J2 VERDICT: PASS
Measured native inventory: 10 numbered THT copper pads = 8 contact identities + 2 separate shield identities; 2 unnumbered NPTH features; 12 total native pad/mechanical features; EP 0; fused aliases 0. Primary evidence: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Dimensions / Recommended Hole Pattern, page 2 Article Properties. Expected all 10 conductive positions and two locator positions as derived above; observed exact match, including native board transform at origin [70.0, 25.86] and rotation 0.0°.
J2 pin 1 (CONTACT_1): expected separate passive contact with matching physical number at [0.0, 0.0]; observed local [0.0, 0.0], native [70.0, 25.86], net 12V_POD2; PASS.
J2 pin 2 (CONTACT_2): expected separate passive contact with matching physical number at [1.02, 4.0]; observed local [1.02, 4.0], native [71.02, 29.86], net GND; PASS.
J2 pin 3 (CONTACT_3): expected separate passive contact with matching physical number at [2.04, 0.0]; observed local [2.04, 0.0], native [72.04, 25.86], net 12V_POD2; PASS.
J2 pin 4 (CONTACT_4): expected separate passive contact with matching physical number at [3.06, 4.0]; observed local [3.06, 4.0], native [73.06, 29.86], net AUDIO_N2; PASS.
J2 pin 5 (CONTACT_5): expected separate passive contact with matching physical number at [4.08, 0.0]; observed local [4.08, 0.0], native [74.08, 25.86], net AUDIO_P2; PASS.
J2 pin 6 (CONTACT_6): expected separate passive contact with matching physical number at [5.1, 4.0]; observed local [5.1, 4.0], native [75.1, 29.86], net GND; PASS.
J2 pin 7 (CONTACT_7): expected separate passive contact with matching physical number at [6.12, 0.0]; observed local [6.12, 0.0], native [76.12, 25.86], net 12V_POD2; PASS.
J2 pin 8 (CONTACT_8): expected separate passive contact with matching physical number at [7.14, 4.0]; observed local [7.14, 4.0], native [77.14, 29.86], net GND; PASS.
J2 pin 9 (SHIELD_S1): expected separate shielding leg on a shield/chassis net at [10.97, -2.35]; observed local [10.97, -2.35], native [80.97, 23.51], net CHASSIS; PASS.
J2 pin 10 (SHIELD_S2): expected separate shielding leg on a shield/chassis net at [-3.83, -2.35]; observed local [-3.83, -2.35], native [66.17, 23.51], net CHASSIS; PASS.

J3 VERDICT: PASS
Measured native inventory: 10 numbered THT copper pads = 8 contact identities + 2 separate shield identities; 2 unnumbered NPTH features; 12 total native pad/mechanical features; EP 0; fused aliases 0. Primary evidence: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Dimensions / Recommended Hole Pattern, page 2 Article Properties. Expected all 10 conductive positions and two locator positions as derived above; observed exact match, including native board transform at origin [102.0, 25.86] and rotation 0.0°.
J3 pin 1 (CONTACT_1): expected separate passive contact with matching physical number at [0.0, 0.0]; observed local [0.0, 0.0], native [102.0, 25.86], net 12V_POD3; PASS.
J3 pin 2 (CONTACT_2): expected separate passive contact with matching physical number at [1.02, 4.0]; observed local [1.02, 4.0], native [103.02, 29.86], net GND; PASS.
J3 pin 3 (CONTACT_3): expected separate passive contact with matching physical number at [2.04, 0.0]; observed local [2.04, 0.0], native [104.04, 25.86], net 12V_POD3; PASS.
J3 pin 4 (CONTACT_4): expected separate passive contact with matching physical number at [3.06, 4.0]; observed local [3.06, 4.0], native [105.06, 29.86], net AUDIO_N3; PASS.
J3 pin 5 (CONTACT_5): expected separate passive contact with matching physical number at [4.08, 0.0]; observed local [4.08, 0.0], native [106.08, 25.86], net AUDIO_P3; PASS.
J3 pin 6 (CONTACT_6): expected separate passive contact with matching physical number at [5.1, 4.0]; observed local [5.1, 4.0], native [107.1, 29.86], net GND; PASS.
J3 pin 7 (CONTACT_7): expected separate passive contact with matching physical number at [6.12, 0.0]; observed local [6.12, 0.0], native [108.12, 25.86], net 12V_POD3; PASS.
J3 pin 8 (CONTACT_8): expected separate passive contact with matching physical number at [7.14, 4.0]; observed local [7.14, 4.0], native [109.14, 29.86], net GND; PASS.
J3 pin 9 (SHIELD_S1): expected separate shielding leg on a shield/chassis net at [10.97, -2.35]; observed local [10.97, -2.35], native [112.97, 23.51], net CHASSIS; PASS.
J3 pin 10 (SHIELD_S2): expected separate shielding leg on a shield/chassis net at [-3.83, -2.35]; observed local [-3.83, -2.35], native [98.17, 23.51], net CHASSIS; PASS.

J4 VERDICT: PASS
Measured native inventory: 10 numbered THT copper pads = 8 contact identities + 2 separate shield identities; 2 unnumbered NPTH features; 12 total native pad/mechanical features; EP 0; fused aliases 0. Primary evidence: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Dimensions / Recommended Hole Pattern, page 2 Article Properties. Expected all 10 conductive positions and two locator positions as derived above; observed exact match, including native board transform at origin [134.0, 25.86] and rotation 0.0°.
J4 pin 1 (CONTACT_1): expected separate passive contact with matching physical number at [0.0, 0.0]; observed local [0.0, 0.0], native [134.0, 25.86], net 12V_POD4; PASS.
J4 pin 2 (CONTACT_2): expected separate passive contact with matching physical number at [1.02, 4.0]; observed local [1.02, 4.0], native [135.02, 29.86], net GND; PASS.
J4 pin 3 (CONTACT_3): expected separate passive contact with matching physical number at [2.04, 0.0]; observed local [2.04, 0.0], native [136.04, 25.86], net 12V_POD4; PASS.
J4 pin 4 (CONTACT_4): expected separate passive contact with matching physical number at [3.06, 4.0]; observed local [3.06, 4.0], native [137.06, 29.86], net AUDIO_N4; PASS.
J4 pin 5 (CONTACT_5): expected separate passive contact with matching physical number at [4.08, 0.0]; observed local [4.08, 0.0], native [138.08, 25.86], net AUDIO_P4; PASS.
J4 pin 6 (CONTACT_6): expected separate passive contact with matching physical number at [5.1, 4.0]; observed local [5.1, 4.0], native [139.1, 29.86], net GND; PASS.
J4 pin 7 (CONTACT_7): expected separate passive contact with matching physical number at [6.12, 0.0]; observed local [6.12, 0.0], native [140.12, 25.86], net 12V_POD4; PASS.
J4 pin 8 (CONTACT_8): expected separate passive contact with matching physical number at [7.14, 4.0]; observed local [7.14, 4.0], native [141.14, 29.86], net GND; PASS.
J4 pin 9 (SHIELD_S1): expected separate shielding leg on a shield/chassis net at [10.97, -2.35]; observed local [10.97, -2.35], native [144.97, 23.51], net CHASSIS; PASS.
J4 pin 10 (SHIELD_S2): expected separate shielding leg on a shield/chassis net at [-3.83, -2.35]; observed local [-3.83, -2.35], native [130.17, 23.51], net CHASSIS; PASS.

J5 VERDICT: PASS
Measured native inventory: 10 numbered THT copper pads = 8 contact identities + 2 separate shield identities; 2 unnumbered NPTH features; 12 total native pad/mechanical features; EP 0; fused aliases 0. Primary evidence: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Dimensions / Recommended Hole Pattern, page 2 Article Properties. Expected all 10 conductive positions and two locator positions as derived above; observed exact match, including native board transform at origin [43.0, 114.14] and rotation 180.0°.
J5 pin 1 (CONTACT_1): expected separate passive contact with matching physical number at [0.0, 0.0]; observed local [0.0, 0.0], native [43.0, 114.14], net 12V_POD5; PASS.
J5 pin 2 (CONTACT_2): expected separate passive contact with matching physical number at [1.02, 4.0]; observed local [1.02, 4.0], native [41.98, 110.14], net GND; PASS.
J5 pin 3 (CONTACT_3): expected separate passive contact with matching physical number at [2.04, 0.0]; observed local [2.04, 0.0], native [40.96, 114.14], net 12V_POD5; PASS.
J5 pin 4 (CONTACT_4): expected separate passive contact with matching physical number at [3.06, 4.0]; observed local [3.06, 4.0], native [39.94, 110.14], net AUDIO_N5; PASS.
J5 pin 5 (CONTACT_5): expected separate passive contact with matching physical number at [4.08, 0.0]; observed local [4.08, 0.0], native [38.92, 114.14], net AUDIO_P5; PASS.
J5 pin 6 (CONTACT_6): expected separate passive contact with matching physical number at [5.1, 4.0]; observed local [5.1, 4.0], native [37.9, 110.14], net GND; PASS.
J5 pin 7 (CONTACT_7): expected separate passive contact with matching physical number at [6.12, 0.0]; observed local [6.12, 0.0], native [36.88, 114.14], net 12V_POD5; PASS.
J5 pin 8 (CONTACT_8): expected separate passive contact with matching physical number at [7.14, 4.0]; observed local [7.14, 4.0], native [35.86, 110.14], net GND; PASS.
J5 pin 9 (SHIELD_S1): expected separate shielding leg on a shield/chassis net at [10.97, -2.35]; observed local [10.97, -2.35], native [32.03, 116.49], net CHASSIS; PASS.
J5 pin 10 (SHIELD_S2): expected separate shielding leg on a shield/chassis net at [-3.83, -2.35]; observed local [-3.83, -2.35], native [46.83, 116.49], net CHASSIS; PASS.

J6 VERDICT: PASS
Measured native inventory: 10 numbered THT copper pads = 8 contact identities + 2 separate shield identities; 2 unnumbered NPTH features; 12 total native pad/mechanical features; EP 0; fused aliases 0. Primary evidence: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Dimensions / Recommended Hole Pattern, page 2 Article Properties. Expected all 10 conductive positions and two locator positions as derived above; observed exact match, including native board transform at origin [75.0, 114.14] and rotation 180.0°.
J6 pin 1 (CONTACT_1): expected separate passive contact with matching physical number at [0.0, 0.0]; observed local [0.0, 0.0], native [75.0, 114.14], net 12V_POD6; PASS.
J6 pin 2 (CONTACT_2): expected separate passive contact with matching physical number at [1.02, 4.0]; observed local [1.02, 4.0], native [73.98, 110.14], net GND; PASS.
J6 pin 3 (CONTACT_3): expected separate passive contact with matching physical number at [2.04, 0.0]; observed local [2.04, 0.0], native [72.96, 114.14], net 12V_POD6; PASS.
J6 pin 4 (CONTACT_4): expected separate passive contact with matching physical number at [3.06, 4.0]; observed local [3.06, 4.0], native [71.94, 110.14], net AUDIO_N6; PASS.
J6 pin 5 (CONTACT_5): expected separate passive contact with matching physical number at [4.08, 0.0]; observed local [4.08, 0.0], native [70.92, 114.14], net AUDIO_P6; PASS.
J6 pin 6 (CONTACT_6): expected separate passive contact with matching physical number at [5.1, 4.0]; observed local [5.1, 4.0], native [69.9, 110.14], net GND; PASS.
J6 pin 7 (CONTACT_7): expected separate passive contact with matching physical number at [6.12, 0.0]; observed local [6.12, 0.0], native [68.88, 114.14], net 12V_POD6; PASS.
J6 pin 8 (CONTACT_8): expected separate passive contact with matching physical number at [7.14, 4.0]; observed local [7.14, 4.0], native [67.86, 110.14], net GND; PASS.
J6 pin 9 (SHIELD_S1): expected separate shielding leg on a shield/chassis net at [10.97, -2.35]; observed local [10.97, -2.35], native [64.03, 116.49], net CHASSIS; PASS.
J6 pin 10 (SHIELD_S2): expected separate shielding leg on a shield/chassis net at [-3.83, -2.35]; observed local [-3.83, -2.35], native [78.83, 116.49], net CHASSIS; PASS.

J7 VERDICT: PASS
Measured native inventory: 10 numbered THT copper pads = 8 contact identities + 2 separate shield identities; 2 unnumbered NPTH features; 12 total native pad/mechanical features; EP 0; fused aliases 0. Primary evidence: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Dimensions / Recommended Hole Pattern, page 2 Article Properties. Expected all 10 conductive positions and two locator positions as derived above; observed exact match, including native board transform at origin [107.0, 114.14] and rotation 180.0°.
J7 pin 1 (CONTACT_1): expected separate passive contact with matching physical number at [0.0, 0.0]; observed local [0.0, 0.0], native [107.0, 114.14], net 12V_POD7; PASS.
J7 pin 2 (CONTACT_2): expected separate passive contact with matching physical number at [1.02, 4.0]; observed local [1.02, 4.0], native [105.98, 110.14], net GND; PASS.
J7 pin 3 (CONTACT_3): expected separate passive contact with matching physical number at [2.04, 0.0]; observed local [2.04, 0.0], native [104.96, 114.14], net 12V_POD7; PASS.
J7 pin 4 (CONTACT_4): expected separate passive contact with matching physical number at [3.06, 4.0]; observed local [3.06, 4.0], native [103.94, 110.14], net AUDIO_N7; PASS.
J7 pin 5 (CONTACT_5): expected separate passive contact with matching physical number at [4.08, 0.0]; observed local [4.08, 0.0], native [102.92, 114.14], net AUDIO_P7; PASS.
J7 pin 6 (CONTACT_6): expected separate passive contact with matching physical number at [5.1, 4.0]; observed local [5.1, 4.0], native [101.9, 110.14], net GND; PASS.
J7 pin 7 (CONTACT_7): expected separate passive contact with matching physical number at [6.12, 0.0]; observed local [6.12, 0.0], native [100.88, 114.14], net 12V_POD7; PASS.
J7 pin 8 (CONTACT_8): expected separate passive contact with matching physical number at [7.14, 4.0]; observed local [7.14, 4.0], native [99.86, 110.14], net GND; PASS.
J7 pin 9 (SHIELD_S1): expected separate shielding leg on a shield/chassis net at [10.97, -2.35]; observed local [10.97, -2.35], native [96.03, 116.49], net CHASSIS; PASS.
J7 pin 10 (SHIELD_S2): expected separate shielding leg on a shield/chassis net at [-3.83, -2.35]; observed local [-3.83, -2.35], native [110.83, 116.49], net CHASSIS; PASS.

J8 VERDICT: PASS
Measured native inventory: 10 numbered THT copper pads = 8 contact identities + 2 separate shield identities; 2 unnumbered NPTH features; 12 total native pad/mechanical features; EP 0; fused aliases 0. Primary evidence: SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048, page 1 Dimensions / Recommended Hole Pattern, page 2 Article Properties. Expected all 10 conductive positions and two locator positions as derived above; observed exact match, including native board transform at origin [139.0, 114.14] and rotation 180.0°.
J8 pin 1 (CONTACT_1): expected separate passive contact with matching physical number at [0.0, 0.0]; observed local [0.0, 0.0], native [139.0, 114.14], net 12V_POD8; PASS.
J8 pin 2 (CONTACT_2): expected separate passive contact with matching physical number at [1.02, 4.0]; observed local [1.02, 4.0], native [137.98, 110.14], net GND; PASS.
J8 pin 3 (CONTACT_3): expected separate passive contact with matching physical number at [2.04, 0.0]; observed local [2.04, 0.0], native [136.96, 114.14], net 12V_POD8; PASS.
J8 pin 4 (CONTACT_4): expected separate passive contact with matching physical number at [3.06, 4.0]; observed local [3.06, 4.0], native [135.94, 110.14], net AUDIO_N8; PASS.
J8 pin 5 (CONTACT_5): expected separate passive contact with matching physical number at [4.08, 0.0]; observed local [4.08, 0.0], native [134.92, 114.14], net AUDIO_P8; PASS.
J8 pin 6 (CONTACT_6): expected separate passive contact with matching physical number at [5.1, 4.0]; observed local [5.1, 4.0], native [133.9, 110.14], net GND; PASS.
J8 pin 7 (CONTACT_7): expected separate passive contact with matching physical number at [6.12, 0.0]; observed local [6.12, 0.0], native [132.88, 114.14], net 12V_POD8; PASS.
J8 pin 8 (CONTACT_8): expected separate passive contact with matching physical number at [7.14, 4.0]; observed local [7.14, 4.0], native [131.86, 110.14], net GND; PASS.
J8 pin 9 (SHIELD_S1): expected separate shielding leg on a shield/chassis net at [10.97, -2.35]; observed local [10.97, -2.35], native [128.03, 116.49], net CHASSIS; PASS.
J8 pin 10 (SHIELD_S2): expected separate shielding leg on a shield/chassis net at [-3.83, -2.35]; observed local [-3.83, -2.35], native [142.83, 116.49], net CHASSIS; PASS.

Pairwise symmetry: all eight instances have contact 1/3/7 on their own 12V_PODn, contact 2/6/8 on GND, contact 4 on AUDIO_Nn, contact 5 on AUDIO_Pn, and both shield legs on CHASSIS. No cross-instance net-kind divergence or physical numbering reversal. Aggregate: 80 numbered copper pads / 80 conductive physical identities, 16 NPTH features, 96 total features.

Unresolved engineering findings: none within commissioned scope. Delivery validation PASS does not grant engineering acceptance beyond this group.
