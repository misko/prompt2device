from pathlib import Path
import json,hashlib,tarfile,shutil
p=Path("/tmp/rj45-pin-carrier-jacks-clockground1-np__xnqf");base=p/"06_build/task_runs/rj45-pin-carrier-jacks-clockground1";s=base/"scratch";o=base/"outputs";e=json.loads((base/"envelope.json").read_text());measure=json.loads((s/"measurements.json").read_text())
for x in e["input_packet"]:
 b=(p/x["path"]).read_bytes();assert len(b)==x["size"] and hashlib.sha256(b).hexdigest()==x["sha256"]
(s/"inputs-after.json").write_text(json.dumps(e["input_packet"],indent=2))
shutil.copyfile(base/"envelope.json",s/"envelope.json")
sha="6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048"
methods=["Verified all 12 envelope inputs byte sizes and SHA-256 before and after review.","Rendered SHA-selected manufacturer PDF pages 1–6 using pdftoppm at 130 dpi; visually inspected all six rendered pages before reading dossiers. Figure-first observations retained.","Derived each numbered contact coordinate from page 1 Recommended Hole Pattern, compared by 180-degree rotation only; inspected underside mechanical drawing to distinguish viewing frame.","Parsed all eight native dossiers; checked 80 numbered pad identities and their local/native coordinates, functions and nets, plus 16 separate mechanical NPTH positions. Retained originals and measurement script/output.","Applied connector-specific zigzag interpretation: computed CCW including shield identifiers is not perimeter winding evidence.","Reopened every regular archive member; checked path safety, absence of duplicates/symlinks/recursive archives, and exact bytes/hash/size."]
report="""review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_jacks_clockground1 (fresh independent agent)
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: e85b1461a82f3d3853c19fae694693816e31570d23d37019ef187d6428bea4ae
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: e6d5b0b89efd79051b082f70b283ec7e85e1170ed11ddb94581744d26904c9c7

Limited coverage: J1–J8 pin identities, package orientation, contact/net sanity and instance symmetry only. No whole-board acceptance or order authorization. Subject bindings above are immutable metadata, not independently reviewed board conclusions. Dossier author-verification notes were not used as engineering evidence. No schematic, live board, historical review, or external model was inspected.

Primary document: Würth 615008160221, revision 001.003, 2025-07-09, SHA-256 """+sha+""". Page 1 figures “Dimensions” and “Recommended Hole Pattern”; page 2 “Article Properties” and “Electrical Properties”. Images of all six pages inspected before dossiers and retained.

Independent geometric derivation: In the hole-pattern image, upper row reads 8,6,4,2 left to right and lower row reads 7,5,3,1. Pin 1 is lower-right; same-row pitch 2.04 mm, stagger 1.02 mm, row spacing 4.00 mm. This is a zigzag contact array, not a sequential perimeter winding. The drawing does not print a TOP/BOTTOM label. The upper-left mechanical view shows the underside, with visible individual contact tails and opposite lateral stagger; the recommended hole pattern is its opposite-side board/component-top projection. This establishes the view geometrically, rather than borrowing the dossier's winding assertion. Converting the underside to component-top requires one lateral reflection; the supplied recommended board pattern already has that reflection. It is compared with dossier component-top by 180-degree rotation only, with no further mirror.

Relative to pin 1, rotated expected coordinates are 1=(0,0), 2=(1.02,4), 3=(2.04,0), 4=(3.06,4), 5=(4.08,0), 6=(5.10,4), 7=(6.12,0), 8=(7.14,4) mm. Pin 1 is the upper-left signal contact in dossier local coordinates. Two separate shield lands are at (10.97,-2.35) and (-3.83,-2.35), separated 14.8 mm. Two 3.18-mm NPTH locators are at (-3.28,0.70) and (10.42,0.70), separated 13.7 mm. All eight dossiers match these identities and coordinates. The mechanical drawing does not assign shield numbers 9 and 10; these are distinct artifact identifiers for its two separate shell legs. No fused alias or collapsed physical identity is used. No exposed pad exists or is required.

All instances explicitly declare front mounting and +x right/+y down component-top coordinates. J1–J4 use native rotation 0°, J5–J8 use 180°. Every native pad and locator coordinate matches the stated translation/rotation. The dossier's CCW label is not an independently meaningful connector winding result, particularly when shell identities are appended to the zigzag contacts; the individual physical comparisons govern.

Electrical scope: This is a passive wired 8P8C jack, not a device assigning audio/power/ground functions to particular contacts. All eight contacts remain separate. Application nets on contacts are electrically plausible; CHASSIS on both shell legs matches their shielding role. No manufacturer-required signal polarity, NC, power-in or ground pin assignment is violated. The dossier maps contact 4 to AUDIO_N and 5 to AUDIO_P uniformly; this review does not establish a remote cable endpoint contract or operating current, which are outside this pin/package commission.

"""
for m in measure:
 ref=m['ref'];i=ref[1:]
 report+=f"{ref} VERDICT: PASS\nMeasured native inventory: 10 numbered THT copper pads = 8 contact identities + 2 separate shield identities; 2 unnumbered NPTH features; 12 total native pad/mechanical features; EP 0; fused aliases 0. Primary evidence: SHA-256 {sha}, page 1 Dimensions / Recommended Hole Pattern, page 2 Article Properties. Expected all 10 conductive positions and two locator positions as derived above; observed exact match, including native board transform at origin {m['origin']} and rotation {m['rotation']}°.\n"
 for row in m['rows']:
  expected='separate passive contact with matching physical number' if int(row['pin'])<=8 else 'separate shielding leg on a shield/chassis net'
  report+=f"{ref} pin {row['pin']} ({row['function']}): expected {expected} at {row['expected_local']}; observed local {row['local']}, native {row['native']}, net {row['net']}; PASS.\n"
 report+='\n'
report+="Pairwise symmetry: all eight instances have contact 1/3/7 on their own 12V_PODn, contact 2/6/8 on GND, contact 4 on AUDIO_Nn, contact 5 on AUDIO_Pn, and both shield legs on CHASSIS. No cross-instance net-kind divergence or physical numbering reversal. Aggregate: 80 numbered copper pads / 80 conductive physical identities, 16 NPTH features, 96 total features.\n\nUnresolved engineering findings: none within commissioned scope. Delivery validation PASS does not grant engineering acceptance beyond this group.\n"
(o/'report.md').write_text(report)
evidence={'verdict':'SOUND','subject':e['subject'],'coverage':[m['ref'] for m in measure],'methods':methods,'primary_documents':[{'path':e['input_packet'][-1]['path'],'sha256':sha,'pages_inspected':[1,2,3,4,5,6],'pin_figures':'Page 1 Dimensions / Recommended Hole Pattern; page 2 Article Properties'}],'findings':measure,'unresolved_engineering_findings':[],'measured_counts':{'numbered_native_pads':80,'physical_conductive_identities':80,'contacts':64,'shield_legs':16,'unnumbered_npth':16,'native_features_total':96,'exposed_pads':0,'fused_aliases':0},'limits':'Only J1-J8 pre-route pin review; no whole-board or order acceptance.'}
(o/'evidence.json').write_text(json.dumps(evidence,indent=2))
(s/'report.md').write_text(report);(s/'evidence.json').write_text(json.dumps(evidence,indent=2))
archive=o/'evidence.tar.gz'
files=sorted(x for x in s.rglob('*') if x.is_file() and not x.is_symlink())
with tarfile.open(archive,'w:gz') as t:
 for x in files:
  assert x.suffix not in ('.gz','.tar');t.add(x,arcname=x.relative_to(s).as_posix(),recursive=False)
rows=[];seen=set()
with tarfile.open(archive,'r:gz') as t:
 for member in t:
  assert member.isfile() and member.name not in seen and not member.name.startswith('/') and '..' not in Path(member.name).parts;seen.add(member.name)
  b=t.extractfile(member).read();assert b==(s/member.name).read_bytes();assert len(b)==member.size
  rows.append({'path':member.name,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
b=archive.read_bytes();manifest={'archive_sha256':hashlib.sha256(b).hexdigest(),'archive_size':len(b),'member_count':len(rows),'members':rows};(o/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2))
(o/'result.json').write_text(json.dumps({'subject':e['subject'],'checks':{k:'PASS' for k in e['completion']['checks']},'unresolved':[]},indent=2))
print('Packaged',len(rows),'members',len(b),'bytes',manifest['archive_sha256'])
