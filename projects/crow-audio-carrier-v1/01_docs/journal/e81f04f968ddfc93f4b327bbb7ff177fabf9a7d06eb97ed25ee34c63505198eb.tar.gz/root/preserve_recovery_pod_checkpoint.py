from pathlib import Path
import json,hashlib,tarfile,gzip,io
from datetime import datetime,timezone
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911');P=R/'projects/crow-mic-pod-v3';payload={}
def add(p,key):
 assert p.is_file() and not p.is_symlink() and key not in payload;payload[key]=p.read_bytes()
for name in ['recovery-user-authorization.json','crow-mic-pod-v3-recovery1-review-adoption.json','pod-recovery-current-parity-classification.json','open_authorized_recovery_availability.py','open_authorized_recovery_review.py','adopt_native_reviews.py','open_next_placement.py','preserve_recovery_pod_checkpoint.py']:
 add(N/name,'root/'+name)
for p in (N/'pod-recovery-prior-drc').iterdir():add(p,'prior-native/'+p.name)
add(P/'06_build/drc/gate.json','current-native/gate.json')
for prefix in ['pod-recovery-','pod-recovery1-','rj45-authorized-recovery-availability-close']:
 for p in I.glob(prefix+'*'):
  if p.is_file():add(p,'runtime/'+p.name)
name='rj45-authorized-recovery-availability';m=json.loads((N/(name+'-opened.json')).read_text());D=Path(m['project']);E=Path(m['envelope']);assert json.loads((E.parent/'attempt.json').read_text())['status']=='PASS'
for row in json.loads(E.read_text())['input_packet']:
 p=D/row['path'];b=p.read_bytes();assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256'];add(p,'availability/inputs/'+row['path'])
for p in E.parent.iterdir():
 if p.is_file():add(p,'availability/allocation/'+p.name)
for p in Path(m['output_dir']).iterdir():
 if p.is_file():add(p,'availability/outputs/'+p.name)
for suffix in ['-opened.json','-host-final.json']:add(N/(name+suffix),'root/'+name+suffix)
record={'created_at':datetime.now(timezone.utc).isoformat(),'scope':'User-authorized fresh pod schematic review acceptance:2/2 owning gate PASS, both timely deliveries PASS. Current historical PCB remains0violations/0unconnected/55parity, individually classified; no placement/release/order acceptance.','original_timeouts':'Preserved, not edited or adopted'};payload['CHECKPOINT.json']=(json.dumps(record,indent=2)+'\n').encode();payload['MANIFEST.json']=(json.dumps({'files':[{'path':k,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()} for k,b in sorted(payload.items())]},indent=2)+'\n').encode();tmp=N/'pod-recovery-checkpoint.tmp'
with tmp.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for k,b in sorted(payload.items()):
    x=tarfile.TarInfo(k);x.size=len(b);x.mode=0o644;t.addfile(x,io.BytesIO(b))
with tarfile.open(tmp) as t:
 assert len(t.getmembers())==len(payload)==len({x.name for x in t.getmembers()})
 for x in t.getmembers():assert x.isfile() and t.extractfile(x).read()==payload[x.name]
b=tmp.read_bytes();h=hashlib.sha256(b).hexdigest();J=R/'projects/crow-audio-carrier-v1/01_docs/journal';p=J/(h+'.tar.gz');assert not p.exists();p.write_bytes(b)
with (J/'contracts.md').open('a') as f:f.write(f'\n## Allowed authorized pod schematic recovery checkpoint\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Exact user authorization, successful live availability, current pod2/2 review adoption, preserved stale DRC and genuinely rerun historical-board parity measurement |\n\nAudit: SHA-256 equals filename; {len(b)} bytes / {len(payload)} regular members, all reopened against MANIFEST.json. The55 individual parity rows remain failed layout evidence; schematic acceptance is separate.\n')
summary={'sha256':h,'archive':str(p),'size':len(b),'members':len(payload),**record};(N/'pod-recovery-checkpoint-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
