from __future__ import annotations

import copy
import hashlib
import json
import sys
import tarfile
from pathlib import Path

sys.dont_write_bytecode = True
import pcbnew

ROOT = Path("/tmp/carrier-channel-pin-aggregate-ohphvgm6")
SCRATCH = ROOT / "06_build/task_runs/channel-pin-aggregate/scratch"
ENV = ROOT / "06_build/task_runs/channel-pin-aggregate/envelope.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_inputs() -> list[dict]:
    env = json.loads(ENV.read_text())
    rows = []
    for item in env["input_packet"]:
        path = ROOT / item["path"]
        observed = {"size": path.stat().st_size, "sha256": sha(path)}
        status = "PASS" if observed == {"size": item["size"], "sha256": item["sha256"]} else "FAIL"
        rows.append({"name": item["name"], "path": item["path"], "expected": {"size": item["size"], "sha256": item["sha256"]}, "observed": observed, "status": status})
    assert all(row["status"] == "PASS" for row in rows)
    return rows


def footprint_row(f):
    pads = []
    for p in f.Pads():
        pads.append({
            "number": p.GetNumber(), "position": [p.GetPosition().x, p.GetPosition().y],
            "size": [p.GetSize().x, p.GetSize().y], "net": p.GetNetname(),
            "rotation": p.GetOrientationDegrees(), "shape": int(p.GetShape()),
            "corner_radius": p.GetRoundRectCornerRadius(),
            "drill": [p.GetDrillSize().x, p.GetDrillSize().y], "type": int(p.GetAttribute()),
            "layers": [int(x) for x in p.GetLayerSet().Seq()],
            "mask_margin": p.GetLocalSolderMaskMargin(),
            "paste_margin": p.GetLocalSolderPasteMargin(),
            "paste_ratio": p.GetLocalSolderPasteMarginRatio(),
            "zone_connection": int(p.GetLocalZoneConnection()),
        })
    return {
        "position": [f.GetPosition().x, f.GetPosition().y],
        "rotation": f.GetOrientationDegrees(), "layer": int(f.GetLayer()),
        "value": f.GetValue(), "fpid": f"{f.GetFPID().GetLibNickname()}:{f.GetFPID().GetLibItemName()}",
        "attributes": int(f.GetAttributes()),
        "pads": sorted(pads, key=lambda p: (p["number"], p["position"])),
    }


before = verify_inputs()
old_path = ROOT / "previous/04_kicad/crow_audio_carrier_v1.kicad_pcb"
new_path = ROOT / "current/04_kicad/crow_audio_carrier_v1.kicad_pcb"
assert sha(old_path) == "9aa1c2c821a31129176a8b519b9a211d78dfc011adb997a64470c03d0726891f"
assert sha(new_path) == "0ab5b6dae425074f2515dc3c3d737e56f2292d83140590dca592b7b964e73090"
old = {f.GetReference(): footprint_row(f) for f in pcbnew.LoadBoard(str(old_path)).GetFootprints()}
new = {f.GetReference(): footprint_row(f) for f in pcbnew.LoadBoard(str(new_path)).GetFootprints()}
assert old.keys() == new.keys()
changed = sorted(ref for ref in old if old[ref] != new[ref])
caps = {f"C_ADC_CM{n}{leg}": f"C_ADC_CM{5-n}{leg}" for n in range(1, 5) for leg in "PN"}
net_map = {f"ADC{n}{leg}": f"ADC{5-n}{leg}" for n in range(1, 5) for leg in "PN"}
assert changed == sorted(["U_ADC", *caps])
expected = {}
for ref, row in old.items():
    row = copy.deepcopy(row)
    if ref == "U_ADC" or ref in caps:
        for pad in row["pads"]:
            pad["net"] = net_map.get(pad["net"], pad["net"])
    expected[caps.get(ref, ref)] = row
assert expected == new
assert old != new

board_only = sorted(ref for ref, row in new.items() if row["attributes"] & int(pcbnew.FP_EXCLUDE_FROM_BOM))
assert len(new) == 340 and sum(len(row["pads"]) for row in new.values()) == 1002
assert len(board_only) == 7, board_only

old_parts = {p.relative_to(ROOT / "previous").as_posix(): p for p in (ROOT / "previous/02_parts").glob("*/part.yaml")}
new_parts = {p.relative_to(ROOT / "current").as_posix(): p for p in (ROOT / "current/02_parts").glob("*/part.yaml")}
assert old_parts.keys() == new_parts.keys() and len(new_parts) == 87
part_delta = sorted(k for k in old_parts if old_parts[k].read_bytes() != new_parts[k].read_bytes())
assert part_delta == ["02_parts/CS5308P-DN/part.yaml"]
import yaml
old_adc = yaml.safe_load(old_parts[part_delta[0]].read_text())
new_adc = yaml.safe_load(new_parts[part_delta[0]].read_text())
assert {k: v for k, v in old_adc.items() if k != "layout"} == {k: v for k, v in new_adc.items() if k != "layout"}

sys.path.insert(0, str(ROOT / "authority/skills/kicad-pcb/scripts"))
from pre_route_review_check import design_rules_digest
project = ROOT / "current"
parts_hash = hashlib.sha256(b"".join(
    p.relative_to(project).as_posix().encode() + b"\0" + p.read_bytes() + b"\0"
    for p in sorted((project / "02_parts").glob("*/part.yaml"))
)).hexdigest()
rules_hash = design_rules_digest(project)

subject = json.loads((ROOT / "current-dossiers/subject.json").read_text())
for ref, record in subject["dossiers"].items():
    assert sha(ROOT / "current-dossiers" / f"{ref}.md") == record["sha256"]

measurement = {
    "schema": 1,
    "board_sha256": sha(new_path), "previous_board_sha256": sha(old_path),
    "footprints": len(new), "assembled_references": len(new) - len(board_only),
    "board_only_references": board_only, "pad_objects": sum(len(row["pads"]) for row in new.values()),
    "changed_pin_projections": changed, "unchanged_exact_footprints": len(new) - len(changed),
    "unchanged_assembled_references": (len(new) - len(board_only)) - len(changed),
    "fresh_references": changed, "expected_transformed_projection_equal": True,
    "untransformed_boards_equal": False, "cap_reference_exchange": caps, "net_exchange": net_map,
    "part_files": len(new_parts), "changed_part_files": part_delta,
    "manufacturer_identity_outside_layout_equal": True,
    "parts_sha256": parts_hash, "design_rules_sha256": rules_hash,
    "subject_binding": subject,
    "comparison_fields": ["footprint origin", "footprint angle", "footprint layer", "value", "FPID", "assembly attributes", "pad number", "pad position", "pad size", "pad net", "pad angle", "pad shape", "corner radius", "drill", "pad type", "layer set", "mask margin", "paste margin", "paste ratio", "local zone connection"],
}
(SCRATCH / "measurement.json").write_text(json.dumps(measurement, indent=2, sort_keys=True) + "\n")
(SCRATCH / "input-verification-before.json").write_text(json.dumps(before, indent=2) + "\n")

with tarfile.open(ROOT / "channel-adc-pin/evidence.tar.gz", "r:gz") as archive:
    for member_name in ("scratch/datasheet-page-04.png", "scratch/datasheet-page-05.png"):
        member = archive.getmember(member_name)
        member.name = "source-" + Path(member_name).name
        archive.extract(member, SCRATCH, filter="data")
with tarfile.open(ROOT / "channel-cm-pin/evidence.tar.gz", "r:gz") as archive:
    for member_name in ("datasheet-page-01.png", "datasheet-page-02.png"):
        member = archive.getmember(member_name)
        member.name = "source-cm-" + Path(member_name).name
        archive.extract(member, SCRATCH, filter="data")

print(json.dumps(measurement, indent=2, sort_keys=True))
