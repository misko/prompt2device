from __future__ import annotations

import hashlib
import json
import sys
import tarfile
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path("/tmp/carrier-channel-pin-aggregate-ohphvgm6")
RUN = ROOT / "06_build/task_runs/channel-pin-aggregate"
SCRATCH = RUN / "scratch"
OUTPUTS = RUN / "outputs"
ENV = json.loads((RUN / "envelope.json").read_text())


def digest(path: Path) -> dict:
    return {"size": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def verify_inputs() -> list[dict]:
    rows = []
    for item in ENV["input_packet"]:
        path = ROOT / item["path"]
        observed = digest(path)
        expected = {"size": item["size"], "sha256": item["sha256"]}
        rows.append({"name": item["name"], "path": item["path"], "expected": expected, "observed": observed, "status": "PASS" if expected == observed else "FAIL"})
    assert all(row["status"] == "PASS" for row in rows)
    return rows


before = json.loads((SCRATCH / "input-verification-before.json").read_text())
after = verify_inputs()
(SCRATCH / "input-verification-after.json").write_text(json.dumps(after, indent=2) + "\n")
measurement = json.loads((SCRATCH / "measurement.json").read_text())
now = datetime.now(timezone.utc).isoformat()

evidence = {
    "schema": 1,
    "subject": ENV["subject"],
    "scope": "Canonical pre-route physical-pin aggregate for exact current native board",
    "engineering_verdict": "SOUND",
    "order_verdict": "DO-NOT-ORDER",
    "completed_at": now,
    "commands": [
        {"argv": ["/usr/bin/python3", "-B", str(SCRATCH / "measure.py")], "cwd": str(SCRATCH), "returncode": 0, "status": "PASS", "raw_stdout_stderr": "scratch/measurement.stdout.log"},
        {"argv": ["view_image", str(SCRATCH / "source-datasheet-page-04.png")], "cwd": str(SCRATCH), "returncode": 0, "status": "PASS"},
        {"argv": ["view_image", str(SCRATCH / "source-datasheet-page-05.png")], "cwd": str(SCRATCH), "returncode": 0, "status": "PASS"},
        {"argv": ["view_image", str(SCRATCH / "source-cm-datasheet-page-01.png")], "cwd": str(SCRATCH), "returncode": 0, "status": "PASS"},
        {"argv": ["view_image", str(SCRATCH / "source-cm-datasheet-page-02.png")], "cwd": str(SCRATCH), "returncode": 0, "status": "PASS"},
        {"argv": ["/usr/bin/python3", "-B", str(SCRATCH / "package.py")], "cwd": str(SCRATCH), "returncode": 0, "status": "PASS"},
    ],
    "input_verification_before": before,
    "input_verification_after": after,
    "input_count": len(after),
    "input_verification_status": "PASS",
    "actual_coverage": {
        "assembled_references": "333/333",
        "inherited_assembled_references": "324/324",
        "fresh_references": "9/9",
        "native_footprints": "340/340",
        "native_pad_objects": "1002/1002",
        "unchanged_exact_footprints": 331,
        "board_only_references": measurement["board_only_references"],
        "u_adc_manufacturer_identities": "49/49",
        "u_adc_context_questions_disposed": "8/8",
        "cm_capacitor_terminals": "16/16",
        "part_records": "87/87",
        "unresolved": [],
    },
    "measurement": measurement,
    "question_disposition": {
        "original_report_verdict": "QUESTION",
        "original_report_preserved": True,
        "reason": "Blind manufacturer evidence established electrical suitability but lacked design identity intent; ADR0027 and adc_channel_map.json explicitly adopt the reversed north logical association with unchanged physical slots.",
        "pins": {
            "39/40": {"manufacturer": "IN1N/IN1P", "net": "ADC4N/ADC4P", "disposition": "PASS intentional"},
            "41/42": {"manufacturer": "IN2N/IN2P", "net": "ADC3N/ADC3P", "disposition": "PASS intentional"},
            "45/46": {"manufacturer": "IN3N/IN3P", "net": "ADC2N/ADC2P", "disposition": "PASS intentional"},
            "47/48": {"manufacturer": "IN4N/IN4P", "net": "ADC1N/ADC1P", "disposition": "PASS intentional"},
        },
        "unchanged_south": {"13/14": "ADC5N/ADC5P PASS", "15/16": "ADC6N/ADC6P PASS", "19/20": "ADC7N/ADC7P PASS", "21/22": "ADC8N/ADC8P PASS"},
    },
    "source_bindings": {
        "adc_blind_report": {"path": "channel-adc-pin/report.md", **digest(ROOT / "channel-adc-pin/report.md")},
        "cm_blind_report": {"path": "channel-cm-pin/report.md", **digest(ROOT / "channel-cm-pin/report.md")},
        "previous_canonical_transfer": {"path": "current/08_reviews/pre-route_pin.md", **digest(ROOT / "current/08_reviews/pre-route_pin.md")},
        "accepted_channel_map_review": {"path": "current/08_reviews/2026-09-12_channel-map_131e0dda_topology.md", **digest(ROOT / "current/08_reviews/2026-09-12_channel-map_131e0dda_topology.md")},
        "adr0027": {"path": "current/01_docs/decisions/0027-fixed-north-adc-channel-map.md", **digest(ROOT / "current/01_docs/decisions/0027-fixed-north-adc-channel-map.md")},
        "channel_map": {"path": "current/03_src/adc_channel_map.json", **digest(ROOT / "current/03_src/adc_channel_map.json")},
        "dossier_subject": {"path": "current-dossiers/subject.json", **digest(ROOT / "current-dossiers/subject.json")},
    },
    "visual_inspection": [
        {"artifact": "scratch/source-datasheet-page-04.png", "actual_view": True, "observed": "CS5308P top-view through-package drawing: pin 1 at upper-left west edge; CCW perimeter numbering; 48 leads plus center PAD; north physical channels appear IN4, IN3, IN2, IN1 left-to-right."},
        {"artifact": "scratch/source-datasheet-page-05.png", "actual_view": True, "observed": "CS5308P pin table confirms IN1 pins 39/40, IN2 41/42, IN3 45/46, IN4 47/48 and south IN5..8 pins 13..22 with P/N polarity."},
        {"artifact": "scratch/source-cm-datasheet-page-01.png", "actual_view": True, "observed": "Murata reference sheet title and scope visually inspected."},
        {"artifact": "scratch/source-cm-datasheet-page-02.png", "actual_view": True, "observed": "Murata dimensional drawing shows symmetric opposed end electrodes for 1005M/0402; part line confirms C0G, 1000 pF, 50 V."},
    ],
    "diagnostic_and_locator_metadata": {
        "hidden_assembly_locators_blocked": 27,
        "routing_investigation": "LAYOUT-001 3/3 spent",
        "route_admission": "BLOCKED",
        "order_admission": "DO-NOT-ORDER",
    },
    "limits": ["physical capture", "cables and installed continuity/keying", "component body and render/silkscreen clearance", "layout and routing", "DRC and fabrication", "first article and analog performance", "release and ordering"],
}
(OUTPUTS / "evidence.json").write_text(json.dumps(evidence, indent=2, sort_keys=True) + "\n")
(OUTPUTS / "result.json").write_text(json.dumps({"subject": ENV["subject"], "checks": {"evidence-complete": "PASS", "inputs-verified": "PASS", "review-complete": "PASS"}, "unresolved": []}, indent=2) + "\n")

archive_path = OUTPUTS / "evidence.tar.gz"
members = sorted(p for p in SCRATCH.rglob("*") if p.is_file())
with tarfile.open(archive_path, "w:gz") as archive:
    for path in members:
        archive.add(path, arcname="scratch/" + path.relative_to(SCRATCH).as_posix(), recursive=False)
manifest_members = [{"path": "scratch/" + p.relative_to(SCRATCH).as_posix(), **digest(p)} for p in members]
manifest = {"schema": 1, "archive": {"path": "evidence.tar.gz", **digest(archive_path)}, "members": manifest_members, "member_count": len(manifest_members)}
(OUTPUTS / "evidence-manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
print(json.dumps({"completed_at": now, "archive": manifest["archive"], "member_count": len(manifest_members), "inputs": len(after)}, indent=2))
