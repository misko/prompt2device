from pathlib import Path
import hashlib, json, sys
sys.dont_write_bytecode = True
import pcbnew

R=Path('/tmp/carrier-silk-slot-review-jamzq72_')
targets=['C_VDDA2_10N','R_FILT1P','R_VMID2_BOT']
boards={'previous':R/'previous/04_kicad/crow_audio_carrier_v1.kicad_pcb',
        'current':R/'current/04_kicad/crow_audio_carrier_v1.kicad_pcb',
        'priority_candidate':R/'candidate/04_kicad/crow_audio_carrier_v1.kicad_pcb'}
out={}
for key,path in boards.items():
    b=pcbnew.LoadBoard(str(path)); fps={f.GetReference():f for f in b.GetFootprints()}; rows={}
    for ref in targets:
        f=fps[ref]; t=f.Reference(); p=f.GetPosition(); q=t.GetPosition()
        rows[ref]={'visible':bool(t.IsVisible()),'footprint_xy_mm':[pcbnew.ToMM(p.x),pcbnew.ToMM(p.y)],
                   'text_xy_mm':[pcbnew.ToMM(q.x),pcbnew.ToMM(q.y)],
                   'offset_mm':[round(pcbnew.ToMM(q.x-p.x),6),round(pcbnew.ToMM(q.y-p.y),6)],
                   'rotation_deg':t.GetTextAngleDegrees(),'size_mm':pcbnew.ToMM(t.GetTextSize().x)}
    out[key]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'targets':rows}
print(json.dumps(out,indent=2))
