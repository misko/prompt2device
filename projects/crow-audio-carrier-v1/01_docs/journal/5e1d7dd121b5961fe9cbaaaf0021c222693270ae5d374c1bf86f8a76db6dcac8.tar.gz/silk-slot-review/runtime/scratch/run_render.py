from pathlib import Path
import json, sys
sys.dont_write_bytecode = True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
S=Path('/tmp/carrier-silk-slot-review-jamzq72_/06_build/task_runs/silk-slot-review/scratch')
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
cmd=['/usr/bin/python3','-B',str(R/'skills/kicad-pcb/scripts/render_board.py'),
     str(S/'current-copy.kicad_pcb'),str(S/'current-top.png'),'--width','1800','--height','1200','--side','top']
o=run_stage({'id':'silk-slot-current-render','work_class':'local','timeout_s':90},cmd,
            log_path=S/'render.log',cwd=R,heartbeat_s=10)
(S/'render-command.json').write_text(json.dumps({'argv':cmd,'cwd':str(R)},indent=2)+'\n')
(S/'render-runtime.json').write_text(json.dumps(o.to_mapping(),indent=2)+'\n')
print(json.dumps(o.to_mapping(),indent=2)); raise SystemExit(0 if o.status=='PASS' else 1)
