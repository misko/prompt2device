from pathlib import Path
import datetime, hashlib, json, tarfile, sys
sys.dont_write_bytecode=True
ROOT=Path('/tmp/carrier-silk-slot-review-jamzq72_'); RUN=ROOT/'06_build/task_runs/silk-slot-review'; S=RUN/'scratch'; O=RUN/'outputs'
env=json.loads((RUN/'envelope.json').read_text()); now=datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z')
checks=[]
for row in env['input_packet']:
    p=ROOT/row['path']; actual_sha=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None; actual_size=p.stat().st_size if p.is_file() else None
    checks.append({'name':row['name'],'path':row['path'],'expected_sha256':row['sha256'],'actual_sha256':actual_sha,'expected_size':row['size'],'actual_size':actual_size,'status':'PASS' if actual_sha==row['sha256'] and actual_size==row['size'] else 'FAIL'})
assert checks and all(x['status']=='PASS' for x in checks)

report='''subject: crow-audio-carrier-v1 focused exact-ref priority code review and preferred-offset measurement
date: 2026-09-11
reviewer: Codex independent judgment agent /root/carrier_silk_slot_review
context-given: FRESH; immutable 178-file packet; READ_ONLY source; scratch-only native measurements
source_commit: 5a8b8ca236e0969410da07fd470ecb2892900f77
board_sha256: 0ab5b6dae425074f2515dc3c3d737e56f2292d83140590dca592b7b964e73090
design_rules_sha256: 5891d8028d9864ea0503dc3f63c7520efca45ece640c9db65423680f85b88712
review_kind: noncanonical D-BACK focused shared-code review and native label-slot measurement
code_verdict: SOUND
physical_proposal_verdict: INCOMPLETE-NO-JUSTIFIED-PREFERRED-OFFSETS
engineering_verdict: CURRENT-BOARD-LOCATOR-BLOCKED
order_verdict: DO-NOT-ORDER
baseline_hidden_refs: 25
current_hidden_refs: 27
rejected_candidate_hidden_refs: 28
accepted_hidden_ceiling: 25

# Focused D-BACK judgment

## Shared-code verdict — SOUND

The optional `silk.refdes.priority_refs` implementation is sound for its stated ordering-only scope. It rejects non-lists, non-string or empty members, duplicates, wildcards/unknown refs, and hole refs. Exact entries retain authored list order. Every fallback entry carries the same prefix/TP and lexical keys as the old implementation, so absent or empty `priority_refs` preserves legacy order. The priority path still calls the unchanged four-pose, 84-offset `_place_owned` routine and therefore retains frame, pad/body/silk collision, ownership/degradation, text-size, rotation and stroke behavior; it cannot force placement. The shared template contract describes these limits. The supplied focused native fixture independently demonstrates a non-vacuous winner change, physical-geometry equality, omitted/empty equivalence, blocked-placement refusal, and all nine hostile inputs; GREEN is 3/3 after RED 1/3. Supplied broader evidence is generic 62/62 including 37 known-bad and schema 898/898. I found no concrete correction.

The project candidate is correctly rejected. Prioritizing `C_VDDA2_10N`, `R_FILT1P`, and `R_VMID2_BOT` made those three visible, but changed 14 reference fields and newly hid `R_CFG2`, `R_CFG5`, `R_FILT2P`, and `R_LDO_SET`. Hidden count therefore worsened from 27 to 28, above the unchanged ceiling of 25. No candidate DRC or visual acceptance is warranted.

## Physical proposal — incomplete; do not add preferred offsets

I found no justified per-ref `preferred_offsets` entry under the requested constraints. Against the exact current board, I exhaustively sampled a 0.1 mm grid inside an 11.0 mm radius for all three targets, with 0°/90° and 0.70/0.55 mm poses: 37,980 offsets per pose, 151,920 poses per reference, 455,760 total. The collision model used the production pad, fitted-body, front-silk, frame and centroid-ownership predicates and reserved every one of the 306 currently visible native references. Valid owned, collision-free slots were 0 for each target.

The old accepted positions were `C_VDDA2_10N` (-8.2,0.0) at 0.55 mm/0°, `R_FILT1P` (-6.0,+6.0) at 0.55 mm/0°, and `R_VMID2_BOT` (0.0,+3.6) at 0.55 mm/0°. The rejected priority candidate selected (-5.0,-5.0) at 0.55 mm, (-5.4,0.0) at 0.70 mm, and (0.0,-2.9) at 0.70 mm respectively, but those choices consumed four current-visible slots. The dense central silk seen in the native F.Silk plot is consistent with the zero-slot result. Because the search included arbitrary two-axis grid offsets beyond the ordinary axis/equal-diagonal 84-offset pattern, it directly tested the property ordinary search misses; none satisfies preservation. Inventing a preferred offset would merely hide another label or violate collision/ownership.

## Remaining validation

The locator blocker remains: current hidden 27 versus previous/ceiling 25. No source candidate, board mutation, DRC, parity, routing, fabrication, locator update, or release action was performed. A different repair needs a separately authorized source/layout hypothesis; it must still preserve the 25 ceiling and all visible identities, then receive native geometry/net/zone comparison, DRC/parity, exact omission census and visual acceptance.

## Evidence limits and visual inspection

I visually inspected the native 1800×1200 front-silkscreen plot from a hash-verified scratch copy; it shows the exceptionally dense ADC/filter/reference field where these labels compete. A 3D render attempt was preserved as an original FAIL because 49 of 333 model references were unresolved from the isolated copy (284/333 resolved); no 3D image or acceptance is claimed. The 2D native plot is sufficient only for density/context. Exact feasibility comes from native bounding boxes and the full measured denominator.
'''
(O/'report.md').write_text(report)
evidence={'schema':1,'subject':env['subject'],'completed_at':now,
 'scope':'noncanonical focused code review and READ_ONLY native slot measurement',
 'input_verification':{'status':'PASS','count':len(checks),'rows':checks,
   'verification_points':['178/178 checked before initial packaging','178/178 rechecked by mandatory preflight after initial packaging'],
   'envelope_canonical_sha256':'46cb254d698268ff85868abce0644e1234d71f25236872cb619e721281613ca6',
   'envelope_raw_file_sha256':hashlib.sha256((RUN/'envelope.json').read_bytes()).hexdigest()},
 'code_review':{'verdict':'SOUND','focused_green':'3/3','focused_red':'1/3','generic_suite':'62/62 including 37 known-bad','schema_suite':'898/898','corrections':[]},
 'candidate':json.loads((ROOT/'silk-priority-candidate-measurement.json').read_text()),
 'slot_search':{'status':'INCOMPLETE-NO-JUSTIFIED-PREFERRED-OFFSETS','grid_step_mm':0.1,'radius_mm':11.0,'offsets_per_pose':37980,'poses_per_ref':151920,'total_poses':455760,'pose_set':[{'size_mm':0.7,'rotation_deg':0},{'size_mm':0.7,'rotation_deg':90},{'size_mm':0.55,'rotation_deg':0},{'size_mm':0.55,'rotation_deg':90}],'preserved_visible_references':306,'valid_counts':{'C_VDDA2_10N':0,'R_FILT1P':0,'R_VMID2_BOT':0},'raw_log':'search_slots.log','pose_log':'inspect_poses.log'},
 'commands':[
  {'argv':['/usr/bin/python3','-B',str(S/'search_slots.py')],'cwd':'/home/mouse9911/gits/circuits','rc':0,'stdout_stderr':'search_slots.log'},
  {'argv':['/usr/bin/python3','-B',str(S/'inspect_poses.py')],'cwd':'/home/mouse9911/gits/circuits','rc':0,'stdout_stderr':'inspect_poses.log'},
  {'argv':['/usr/bin/python3','-B',str(S/'run_render.py')],'cwd':'/home/mouse9911/gits/circuits','rc':1,'stdout_stderr':'run_render_console.log','preserved_original_failure':True},
  {'argv':['/usr/bin/python3','-B',str(S/'run_plot.py')],'cwd':'/home/mouse9911/gits/circuits','rc':0,'stdout_stderr':'run_plot_console.log'},
  {'argv':['/usr/bin/python3','-B',str(S/'run_svg_convert.py')],'cwd':'/home/mouse9911/gits/circuits','rc':0,'stdout_stderr':'run_convert_white_console.log'}],
 'visual_inspection':{'performed':True,'artifact':'current-front-silk-white.png','dimensions_px':[1800,1200],'finding':'Dense central ADC/filter/reference silk corroborates slot competition; exact feasibility is native-box measurement.','three_d_render':'FAIL preserved; isolated copy resolved 284/333 models, so no 3D acceptance claimed.'},
 'mutations':{'live_or_source':False,'candidate_generations':0,'layout_budget_spent':0}}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(O/'result.json').write_text(json.dumps({'subject':env['subject'],'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]},indent=2)+'\n')

members=[]
for p in sorted(x for x in S.rglob('*') if x.is_file()):
    rel=p.relative_to(S).as_posix(); members.append({'path':rel,'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
with tarfile.open(O/'evidence.tar.gz','w:gz') as tf:
    for p in sorted(x for x in S.rglob('*') if x.is_file()): tf.add(p,arcname=p.relative_to(S).as_posix(),recursive=False)
archive=O/'evidence.tar.gz'
manifest={'schema':1,'members':members,'member_count':len(members),'archive':{'path':'evidence.tar.gz','size':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'inputs_verified':len(checks),'members':len(members),'outputs':sorted(p.name for p in O.iterdir())},indent=2))
