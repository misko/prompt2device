from pathlib import Path
import pcbnew, sys
sys.dont_write_bytecode = True
S=Path('/tmp/carrier-silk-slot-review-jamzq72_/06_build/task_runs/silk-slot-review/scratch')
b=pcbnew.LoadBoard(str(S/'current-copy.kicad_pcb'))
p=pcbnew.PLOT_CONTROLLER(b); o=p.GetPlotOptions(); o.SetOutputDirectory(str(S)); o.SetPlotFrameRef(False); o.SetAutoScale(False); o.SetScale(1); o.SetMirror(False); o.SetPlotValue(False); o.SetPlotReference(True)
p.SetLayer(pcbnew.F_SilkS)
assert p.OpenPlotfile('current-front-silk',pcbnew.PLOT_FORMAT_SVG,'current native front silkscreen')
assert p.PlotLayer(); p.ClosePlot()
print(S/'current-front-silk.svg')
