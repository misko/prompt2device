from pathlib import Path
import shutil,sys,tempfile,json
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent
root=Path(tempfile.mkdtemp(prefix='carrier-silk-slot-review-'));sys.path.insert(0,str(D));from open_review import open_review
for folder in ['skills/kicad-pcb/scripts','skills/pcb-design/scripts']:
 shutil.copytree(R/folder,root/'authority'/folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for n in ['tests/t1_generate_board.py','tests/harness.py','tests/README.md','skills/pcb-design/templates/contracts/03_src/contracts.md','skills/kicad-pcb/references/design-policies.md']:
 q=root/'authority'/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/n,q)
for label,base in [('current',P),('candidate',D/'silk-priority-candidate'),('previous',Path('/tmp/carrier-locator-omission-dback-nn4jv622/previous'))]:
 for n in ['03_src/floorplan.yaml','04_kicad/crow_audio_carrier_v1.kicad_pcb','04_kicad/refdes_waiver.json']:
  q=root/label/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(base/n,q)
for n in ['04_kicad/crow_audio_carrier_v1.kicad_pro','04_kicad/crow_audio_carrier_v1.kicad_dru','03_src/rules/assembly_locator.yaml']:
 q=root/'current'/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(P/n,q)
shutil.copyfile('/tmp/carrier-locator-omission-dback-nn4jv622/06_build/task_runs/locator-omission-dback/outputs/report.md',root/'prior-diagnosis.md')
for n in ['silk-priority-candidate-measurement.json','measure_silk_priority_candidate.py']:
 shutil.copyfile(D/n,root/n)
for f in (D/'priority-before').rglob('*'):
 if f.is_file():q=root/'before-code'/f.relative_to(D/'priority-before');q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,q)
for f in Path('/tmp/carrier-connector-integration-20260911').glob('silk-priority-*'):
 if f.is_file():q=root/'root-runs'/f.name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,q)
open_review(root,'silk-slot-review','''Agent-role judgment. Fresh independent D-BACK for source silkscreen blocker, plus focused shared-code review. Previous report proposed exact priority_refs, followed by preferred_offsets only if priority displaced other labels. Root implemented optional exact ordered refs (with templates/contracts/tests), demonstrated real producerRED 1pass/2fail, GREEN3/3, fullgeneric62/62including37known-bad, schema898/898. One isolated source candidate priorities[C_VDDA2_10N,R_FILT1P,R_VMID2_BOT] generated successfully6.55s but hidden27→28 (ceiling25); REJECTED beforeDRC/visual acceptance. Actualcurrentboard0ab unchanged. No priority field is in live projectfloorplan. Fullnative340/1002padprojectioncandidatevsactualcurrent exact; rawmeasurementprovided. Source correction exists ONLY in shared code/template/test right now, not accepted by fresh review yet.

Bounded tasks: (1) Independently review shared optional priority_refs implementation, malformed/unknown/duplicate/hole rejection, backward ordering equivalence, native regression nonvacuity and proposed source contract; report SOUND or concrete correction. No repeated whole62suite needed, run focused3 if useful copied authority/harness can need ROOT paths; imports only exactsuppliedauthority. (2) Diagnose why the onecandidate worsened and find a minimal source-owned label-position proposal. May inspect exact native geometry and independently search for collision-free bounded preferred offsets for the THREE currentlynewlyhidden refs C_VDDA2_10N,R_FILT1P,R_VMID2_BOT, preserving allcurrentvisiblelabels, or use exactpreviousacceptednative positions as hypotheses. Proposed optional per-ref preferred_offsets must retain currentcollision/body/pad/frame/size/stroke and ownership/degradation semantics and search limits; no forceplacing/no hiding newlyvisibleotherlabels/no raising25ceiling. New slot must demonstrate what property ordinary84offsetsearch missed and how the production_phase1/phase2 would actually select it. Prioritize meaningful measured slots over general algorithm advice; native diagrams actualview asneeded. Search bounded to existing11-ish mm neighborhoods (no global layout move), default0.7/min0.55 sizes and0/90deg. If independent search cannot find justifiedslots, sayso withcoverage, do not inventfeasibility.

This is measurement/proposal only. NO new source generation candidates, no mutation of native boards, no newsharedfeatureimplementation, no livefileedits. No source/electrical/footprint/pad/net/zone changes. No routing or fabrication. LAYOUT0013/3spentunchanged. Correct currenthidden27/previous25; candidate28. Root remainssolelivewriter. Deliver noncanonicalreport with separate codeverdict and physicalproposal/incomplete status; preservedrawmeasurements/images, exactidentities and remainingvalidation. Nochildren/network.''',14)
