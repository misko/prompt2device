from pathlib import Path
import json,hashlib,shutil,yaml
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent
Q=D/'silk-priority-candidate';assert not Q.exists();shutil.copytree('/tmp/carrier-locator-omission-dback-nn4jv622/project',Q)
for name in ['03_src/floorplan.yaml','06_build/netlists/crow_audio_carrier_v1.net']:
 shutil.copyfile(P/name,Q/name)
# Complete source clone; the only prospective design delta is explicit order.
p=Q/'03_src/floorplan.yaml';s=p.read_text();old='priority_prefixes: "JUQF"';assert s.count(old)==1
p.write_text(s.replace(old,old+', priority_refs: [C_VDDA2_10N, R_FILT1P, R_VMID2_BOT]'))
inputs={str(f):{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'size':f.stat().st_size} for base in [Q/'03_src',Q/'02_parts'] for f in base.rglob('*') if f.is_file()}
for f in [Q/'06_build/netlists/crow_audio_carrier_v1.net',*list((R/'skills/kicad-pcb/scripts').glob('*.py'))]:inputs[str(f)]={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'size':f.stat().st_size}
(D/'silk-priority-candidate-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
print('Prepared isolated candidate',Q,'inputs',len(inputs),'exact priority refs',yaml.safe_load(p.read_text())['silk']['refdes']['priority_refs'])
