from pathlib import Path
import json,hashlib,shutil,sys,re
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent
sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'));import pre_route_review_check as g
j=json.loads((D/'channel-pin-aggregate-opened.json').read_text())[0];root=Path(j['project']);a=json.loads(Path(j['attempt']).read_text());assert a['status']=='PASS';report=Path(j['output_dir'])/'report.md';f=g.fields(report);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Complete input-to-live check happens before replacing the old pointer.
checked=[]
for p in (root/'current').rglob('*'):
 if p.is_file():n=p.relative_to(root/'current');assert p.read_bytes()==(P/n).read_bytes(),str(n);checked.append(str(n))
for p in (root/'current-dossiers').iterdir():
 if p.is_file():assert p.read_bytes()==(D/'channel-current-pin-dossiers'/p.name).read_bytes()
parts=sorted((P/'02_parts').glob('*/part.yaml'));ph=hashlib.sha256(b''.join(p.relative_to(P).as_posix().encode()+b'\0'+p.read_bytes()+b'\0' for p in parts)).hexdigest();expected={'board_sha256':sha(P/'04_kicad/crow_audio_carrier_v1.kicad_pcb'),'parts_sha256':ph,'design_rules_sha256':g.design_rules_digest(P)}
assert f['design_verdict']=='SOUND' and f['order_verdict']=='DO-NOT-ORDER'
fields=[m.group(1).lower() for line in report.read_text().splitlines() if (m:=g.FIELD.match(line))];assert len(fields)==len(set(fields)),fields
for k,v in expected.items():assert f[k]==v,(k,f.get(k),v)
errors=[];assert g.check_review('pin',report,expected,errors) and not errors,errors
name='2026-09-12_0ab5b6da_aggregate_pin.md';dest=P/'08_reviews'/name;assert not dest.exists();shutil.copyfile(report,dest);shutil.copyfile(report,P/'08_reviews/pre-route_pin.md')
record={'live_current_files_matched':len(checked),'dossiers_matched':len(list((root/'current-dossiers').iterdir())),'owning_pin_check':'PASS 1/1','expected':expected,'report_sha256':sha(report),'dated_review':name,'scope':'Fresh integrated pin review only; no whole placement-stage PASS. Original blind QUESTION retained and contextually resolved by independent accepted-map comparison.'};(D/'channel-pin-adoption.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
