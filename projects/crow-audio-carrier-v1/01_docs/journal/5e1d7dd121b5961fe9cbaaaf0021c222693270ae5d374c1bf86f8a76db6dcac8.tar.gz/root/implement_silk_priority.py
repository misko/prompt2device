from pathlib import Path
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
p=R/'skills/kicad-pcb/scripts/generate_board_generic.py';s=p.read_text()
old='''        prio_first = rc.get("priority_prefixes", "UJDBQ")

        def prio(fp):
            r = fp.GetReference()
            return (0 if r[0] in prio_first or r.startswith("TP") else 1, r)
'''
new='''        prio_first = rc.get("priority_prefixes", "UJDBQ")
        priority_refs = rc.get("priority_refs", [])
        if not isinstance(priority_refs, list) or any(
                not isinstance(r, str) or not r for r in priority_refs):
            die("silk.refdes.priority_refs must be an ordered list of exact refdes")
        if len(set(priority_refs)) != len(priority_refs):
            die("silk.refdes.priority_refs contains duplicate refdes")
        eligible = {fp.GetReference() for fp in self.board.GetFootprints()} - set(self.hole_refs)
        unknown = sorted(set(priority_refs) - eligible)
        if unknown:
            die(f"silk.refdes.priority_refs names unknown or hole refdes: {unknown}")
        priority_rank = {r: i for i, r in enumerate(priority_refs)}

        def prio(fp):
            r = fp.GetReference()
            if r in priority_rank:
                return (0, priority_rank[r], r)
            # Empty/absent exact priority preserves the prior ordering.
            return (1, 0 if r[0] in prio_first or r.startswith("TP") else 1, r)
'''
assert s.count(old)==1;p.write_text(s.replace(old,new).replace('refdes {size, min_size, fab_copy, clearance}', 'refdes {size, min_size, fab_copy, clearance, priority_prefixes, priority_refs}'))
for n in ['skills/pcb-design/templates/contracts/03_src/contracts.md','projects/crow-audio-carrier-v1/03_src/contracts.md']:
 p=R/n;s=p.read_text();line='| `silk.refdes.priority_prefixes` | `generate_board_generic.py` | de-collision priority |'
 assert s.count(line)==1;p.write_text(s.replace(line,line+'\n| `silk.refdes.priority_refs` | `generate_board_generic.py` | optional ordered list of unique exact non-hole footprint references, placed before prefix/lexical fallback; malformed, duplicate, unknown or hole references fail. Empty/absent preserves prior order. Changes only search order, retaining native text, collision, frame and ownership checks; never forces a label into an invalid slot |'))
