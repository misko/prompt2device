from pathlib import Path
import hashlib,json,sys,re
sys.dont_write_bytecode=True
import pcbnew
D=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';Q=D/'silk-priority-candidate';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Reuse a field extraction only, not its old/new identity oracle or executable
# main: equality here is between the exact current board and the candidate.
s=(D/'verify_channel_pin_transfer.py').read_text();ns={'pcbnew':pcbnew};exec(s[s.index('def row(f):'):s.index("assert sha(current)")],ns)
a=pcbnew.LoadBoard(str(P/'04_kicad/crow_audio_carrier_v1.kicad_pcb'));b=pcbnew.LoadBoard(str(Q/'04_kicad/crow_audio_carrier_v1.kicad_pcb'))
rows=lambda board:{f.GetReference():ns['row'](f) for f in board.GetFootprints()}
ra,rb=rows(a),rows(b);diff=sorted(r for r in set(ra)|set(rb) if ra.get(r)!=rb.get(r));assert not diff,diff
hidden=lambda board: sorted(f.GetReference() for f in board.GetFootprints() if not f.Reference().IsVisible() and not f.GetAttributes()&pcbnew.FP_BOARD_ONLY)
x,y=hidden(a),hidden(b);inputs=json.loads((D/'silk-priority-candidate-inputs.json').read_text());assert all(sha(Path(n))==v['sha256'] and Path(n).stat().st_size==v['size'] for n,v in inputs.items())
def fields(board):
 return {f.GetReference():(f.Reference().IsVisible(),f.Reference().GetPosition().x,f.Reference().GetPosition().y,f.Reference().GetTextAngleDegrees(),f.Reference().GetTextSize().x,f.Reference().GetTextThickness()) for f in board.GetFootprints()}
fa,fb=fields(a),fields(b)
result={'board_sha256':sha(P/'04_kicad/crow_audio_carrier_v1.kicad_pcb'),'candidate_sha256':sha(Q/'04_kicad/crow_audio_carrier_v1.kicad_pcb'),'native_footprints':len(ra),'native_pads':sum(len(f['pads']) for f in ra.values()),'native_physical_pin_projection_equal':not diff,'inputs_verified':len(inputs),'before_hidden':x,'candidate_hidden':y,'new_hidden':sorted(set(y)-set(x)),'new_visible':sorted(set(x)-set(y)),'changed_reference_fields':sorted(r for r in fa if fa[r]!=fb[r]),'accepted_hidden_ceiling':25,'verdict':'REJECTED','reason':'28 hidden refs exceeds unchanged 25 ceiling; no live source adoption, no further candidate generation or DRC/visual acceptance claimed.'}
assert len(y)==28
(D/'silk-priority-candidate-measurement.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
