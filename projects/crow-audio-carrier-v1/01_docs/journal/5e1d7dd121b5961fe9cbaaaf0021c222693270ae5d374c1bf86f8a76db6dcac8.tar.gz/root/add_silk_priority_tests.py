from pathlib import Path
import shutil
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');D=Path(__file__).parent
for n in ['skills/kicad-pcb/scripts/generate_board_generic.py','tests/t1_generate_board.py','skills/pcb-design/templates/contracts/03_src/contracts.md','projects/crow-audio-carrier-v1/03_src/contracts.md']:
 q=D/'priority-before'/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/n,q)
p=R/'tests/t1_generate_board.py'
insert='''
# ------------------------------------------------ exact refdes priority
_PRIORITY_PROBE = r"""
import json, sys, pcbnew
sys.dont_write_bytecode = True
sys.path.insert(0, sys.argv[1])
from generate_board_generic import BoardBuilder, FloorplanError
from pathlib import Path

def build(options, name, blocked=False):
    # Two distinct native footprint positions compete for a narrow label
    # strip. Restrict the fixture's offset search, not the collision/ownership
    # predicates or the native text shape. Far-away refs expose fallback order.
    b = BoardBuilder.__new__(BoardBuilder)
    b.board = pcbnew.BOARD(); b.silk_cfg = {'refdes': dict(
        size=0.7, min_size=0.7, fab_copy=True, priority_prefixes='J', **options)}
    b.fps = {}; b.hole_refs = {'H1'}; b.tier = None
    b.waived = []; b.log = []; b.X0=b.Y0=0; b.X1=b.Y1=100
    b.OFF = [(0,-2)]
    for ref,x,y in [('R_FIRST',10,10),('R_LAST',10.1,10),
                    ('J1',30,30),('C1',50,50),('TP1',70,70),('H1',80,80)]:
        fp=pcbnew.FOOTPRINT(b.board); fp.SetReference(ref)
        fp.SetPosition(pcbnew.VECTOR2I_MM(x,y)); b.board.Add(fp); b.fps[ref]=fp
        pad=pcbnew.PAD(fp); pad.SetNumber('1'); pad.SetShape(pcbnew.PAD_SHAPE_RECT)
        pad.SetSize(pcbnew.VECTOR2I_MM(0.02,0.02)); pad.SetPosition(fp.GetPosition())
        fp.Add(pad)
    if blocked:
        # A real copper pad covers the only proposed label strip. Priority
        # must never turn collision rejection into force-placement.
        pad=pcbnew.PAD(b.fps['R_LAST']); pad.SetNumber('2')
        pad.SetShape(pcbnew.PAD_SHAPE_RECT); pad.SetSize(pcbnew.VECTOR2I_MM(15,3))
        pad.SetPosition(pcbnew.VECTOR2I_MM(10,8)); b.fps['R_LAST'].Add(pad)
    def geometry(board):
        return sorted((f.GetReference(),f.GetPosition().x,f.GetPosition().y,
                       f.GetOrientationDegrees(), sorted((p.GetNumber(),
                       p.GetPosition().x,p.GetPosition().y,p.GetSize().x,
                       p.GetSize().y,p.GetNetname()) for p in f.Pads()))
                      for f in board.GetFootprints())
    before=geometry(b.board); order=[]; place=b._place_owned
    def recording(*args, **kwargs):
        if args[5]=='refdes': order.append(args[4])
        return place(*args, **kwargs)
    b._place_owned=recording
    try: b.add_silk()
    except FloorplanError as e: return {'error':str(e)}
    out=Path(sys.argv[2])/(name+'.kicad_pcb'); pcbnew.SaveBoard(str(out),b.board)
    saved=pcbnew.LoadBoard(str(out))
    return {'order':order, 'hidden':sorted(f.GetReference() for f in saved.GetFootprints()
                if not f.Reference().IsVisible()), 'geometry_equal':before==geometry(saved),
            'fields':sorted((f.GetReference(),f.Reference().IsVisible(),
                f.Reference().GetPosition().x,f.Reference().GetPosition().y,
                f.Reference().GetTextAngleDegrees(),f.Reference().GetTextSize().x,
                f.Reference().GetTextThickness()) for f in saved.GetFootprints())}

results={'default':build({},'default'), 'empty':build({'priority_refs':[]},'empty'),
    'priority':build({'priority_refs':['R_LAST','C1']},'priority'),
    'blocked':build({'priority_refs':['R_LAST']},'blocked',True),
    'invalid':[build({'priority_refs':v},'bad'+str(i)) for i,v in enumerate(
        [None,'R_LAST',{},[3],[''],['R_LAST','R_LAST'],['R_*'],['UNKNOWN'],['H1']])]}
print('@@'+json.dumps(results))
"""


def _priority_probe():
    d=tmpdir('gbg_priority_')
    rr=must_pass(run([KPY, '-B', '-c', _PRIORITY_PROBE, SCRIPTS, d]),
                 'native refdes priority fixture')
    return json.loads(rr.out.split('@@',1)[1])


@test('exact silk priority changes the contested native label winner and preserves geometry')
def t_silk_exact_priority():
    # Run RED against the actual pre-feature producer before implementation;
    # the unrecognized field leaves R_LAST hidden while the default passes.
    p=_priority_probe()
    eq(p['default']['order'], ['J1','TP1','C1','R_FIRST','R_LAST'], 'legacy order')
    eq(p['priority']['order'], ['R_LAST','C1','J1','TP1','R_FIRST'], 'explicit order then fallback')
    check('R_LAST' in p['default']['hidden'], 'fixture has no contested label')
    check('R_LAST' not in p['priority']['hidden'] and
          'R_FIRST' in p['priority']['hidden'], 'priority did not change saved native winner')
    check(all(p[k]['geometry_equal'] for k in ['default','empty','priority','blocked']),
          'silk ordering changed physical geometry')


@test('omitted and empty silk priority preserve native fields; prioritized labels still collide', kind='known_bad')
def t_silk_exact_priority_preserves_checks():
    p=_priority_probe()
    eq(p['default']['fields'],p['empty']['fields'],'empty priority changes native fields')
    check('R_LAST' in p['blocked']['hidden'] and 'R_FIRST' in p['blocked']['hidden'],
          'explicit priority forced a label through copper')


@test('exact silk priority rejects malformed duplicate unknown wildcard and hole refs', kind='known_bad')
def t_silk_exact_priority_invalid():
    p=_priority_probe()
    eq(len(p['invalid']),9,'hostile denominator')
    for i,r in enumerate(p['invalid']):
        check('error' in r and 'silk.refdes.priority_refs' in r['error'],
              f'bad priority case {i} was accepted: {r}')

'''
s=p.read_text();assert '# ------------------------------------------------ exact refdes priority' not in s
p.write_text(s.replace('if __name__ == "__main__":',insert+'\nif __name__ == "__main__":'))
