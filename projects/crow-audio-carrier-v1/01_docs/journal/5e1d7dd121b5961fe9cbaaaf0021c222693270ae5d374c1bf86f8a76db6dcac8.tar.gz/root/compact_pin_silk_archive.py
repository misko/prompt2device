from pathlib import Path
import hashlib,json,tarfile,subprocess,io
D=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';sha=lambda b:hashlib.sha256(b).hexdigest()
j=json.loads((D/'pin-and-silk-diagnosis-preservation.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
with tarfile.open(j['archive']) as t:
 doc=json.load(t.extractfile('MANIFEST.json'));payload={n:t.extractfile(n).read() for n in doc['members']};refs=doc['references'];git_by_hash={}
 for n,b in payload.items():
  commit=head;rel=None
  if '/inputs/project/' in n:rel='projects/crow-audio-carrier-v1/'+n.split('/inputs/project/',1)[1]
  elif '/inputs/previous/' in n:commit='f2675b43';rel='projects/crow-audio-carrier-v1/'+n.split('/inputs/previous/',1)[1]
  elif '/inputs/authority/' in n:rel=n.split('/inputs/authority/',1)[1]
  elif n.endswith('.pdf') and '/inputs/' in n:
   found=list((P/'02_parts').rglob(Path(n).name))
   if len(found)==1:rel=found[0].relative_to(R).as_posix()
  elif n.endswith('/inputs/pin-review-protocol.md'):rel='skills/kicad-pcb/references/pin-review-protocol.md'
  if rel:
   p=subprocess.run(['git','show',commit+':'+rel],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   if p.returncode==0 and p.stdout==b:
    git_by_hash[sha(b)]={'git_commit':commit,'path':rel,'size':len(b),'sha256':sha(b)}
 for n,b in list(payload.items()):
  if sha(b) in git_by_hash:refs[n]=git_by_hash[sha(b)];del payload[n]
 # Flatten local aliases when their canonical member moved to Git.
 for n,m in list(refs.items()):
  if 'archive_member' in m and m['archive_member'] in refs:
   assert 'git_commit' in refs[m['archive_member']];refs[n]=refs[m['archive_member']]
 members={n:{'size':len(b),'sha256':sha(b)} for n,b in payload.items()};doc.update(members=members,references=refs)
 tmp=D/'compact-pin-silk.tar.gz'
 with tarfile.open(tmp,'w:gz',compresslevel=3) as out:
  for n,b in sorted(payload.items()):m=tarfile.TarInfo(n);m.size=len(b);out.addfile(m,io.BytesIO(b))
  b=(json.dumps(doc,indent=2)+'\n').encode();m=tarfile.TarInfo('MANIFEST.json');m.size=len(b);out.addfile(m,io.BytesIO(b))
 h=sha(tmp.read_bytes());dest=D/(h+'.tar.gz');assert not dest.exists();tmp.rename(dest)
 with tarfile.open(dest) as out:
  assert set(out.getnames())==set(members)|{'MANIFEST.json'} and len(out.getnames())==len(set(out.getnames()))
  assert all(x.isfile() and '..' not in Path(x.name).parts and not Path(x.name).is_absolute() for x in out.getmembers())
  for n,m in members.items():b=out.extractfile(n).read();assert len(b)==m['size'] and sha(b)==m['sha256']
  for n,m in refs.items():
   b=subprocess.check_output(['git','show',m['git_commit']+':'+m['path']],cwd=R) if 'git_commit' in m else out.extractfile(m['archive_member']).read()
   assert len(b)==m['size'] and sha(b)==m['sha256']
 result={**j,'archive':str(dest),'sha256':h,'size':dest.stat().st_size,'members':len(members),'references':len(refs),'git_references':sum('git_commit' in x for x in refs.values()),'unpublished_expanded_copy':j['sha256']}
 (D/'pin-and-silk-diagnosis-compact-preservation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
