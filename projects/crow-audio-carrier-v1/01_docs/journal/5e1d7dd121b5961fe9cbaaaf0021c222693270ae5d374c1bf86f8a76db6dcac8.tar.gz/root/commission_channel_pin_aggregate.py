from pathlib import Path
import json,shutil,tempfile,sys,subprocess
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;root=Path(tempfile.mkdtemp(prefix='carrier-channel-pin-aggregate-'));sys.path.insert(0,str(D));from open_review import open_review
for folder in ['skills/kicad-pcb/scripts','skills/pcb-design/scripts']:
 shutil.copytree(R/folder,root/'authority'/folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for folder in ['03_src/rules','02_parts']:
 for f in (P/folder).rglob('*.yaml'):
  q=root/'current'/f.relative_to(P);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,q)
for n in ['03_src/route.yaml','03_src/adc_channel_map.json','01_docs/decisions/0027-fixed-north-adc-channel-map.md','04_kicad/crow_audio_carrier_v1.kicad_pcb','08_reviews/2026-09-12_channel-map_131e0dda_topology.md','08_reviews/2026-09-12_thermal_9e00dcf2_topology.md','08_reviews/pre-route_pin.md']:
 q=root/'current'/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(P/n,q)
for n in ['04_kicad/crow_audio_carrier_v1.kicad_pcb',*['02_parts/'+f.parent.name+'/part.yaml' for f in (P/'02_parts').glob('*/part.yaml')]]:
 q=root/'previous'/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(subprocess.check_output(['git','show','f2675b43:projects/crow-audio-carrier-v1/'+n],cwd=R))
for name in ['channel-adc-pin','channel-cm-pin']:
 j=json.loads((D/(name+'-opened.json')).read_text())[0]
 shutil.copytree(j['output_dir'],root/name)
 shutil.copyfile(j['envelope'],root/(name+'-envelope.json'));shutil.copyfile(j['attempt'],root/(name+'-closed-attempt.json'));shutil.copyfile(D/(name+'-reopening.json'),root/(name+'-root-reopening.json'))
for n in ['channel-pin-transfer-proof.json','verify_channel_pin_transfer.py']:
 shutil.copyfile(D/n,root/n)
for f in (D/'channel-current-pin-dossiers').glob('*'):
 if f.is_file():q=root/'current-dossiers'/f.name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,q)
open_review(root,'channel-pin-aggregate','''Agent-role judgment. Fresh integrated pin-delta adjudication, NOT a replacement blind manufacturer review. Original fresh manufacturer reports are immutable. CurrentU_ADC reportQUESTION solely because IN1..4 use ADC4..1 netnames; all49manufactureridentities/winding/polarity/electricalkindsPASS. EightCMcaps16terminalsPASS. Inspect acceptedADR0027 and actualadc_channel_map.json/nativeboard to independently resolve orretain thecontextQUESTION. Explicitsourceauthorityintentisreversednorthchannelassociation, unchangedhardwaredefaultslots; do not infer physicalcapturevalidation. Verify each of8questionpinsP/N plus unchanged south8pins againstactualsource+manufacturerderivedreports.

For full333assembledrefaggregation, independently derive fullnative keyed pad/footprint comparison previous9aa versuscurrent0ab, including local zone modes; exact8caprefexchange+8ADCnetlabels across9refs should be solechangedphysicalpinprojections,331unchangedFP includes7boardonly hence324unchangedassembled+9fresh=333. Check all87part identities; onlyCS5308layoutguidancechanged. Prove preservation of allmanufactureridentityfields and exact sourceDossier bindings fromcurrent-dossiers/subject.json. OriginalmanufacturerPDFs are retained inside group evidence or underlying readonly packet references; no need rerender original pin drawings/reperformblind review, preserve theirtruthfuloriginalcoverage. No network/liveprojectreadwrites. suppliedoldroothelperhardcodeslivepath; inspectmethodbut writeindependentpacket-relativemeasurement rather than runningthatwholehelper.

Deliver COMPLETE canonical pre-route physical-pin aggregate report.md only if evidence justifiesSOUND, otherwiseverdictcorrectlylimited. Requiredheader subject,date,reviewer,context-given,source_commit24263dea (informational currentboard commit; liveunacceptedsharedsilkfeature notmaterial to pinboundboard), review_stage pre-route,review_kind pin, exactboardSHA0ab5b6dae425074f2515dc3c3d737e56f2292d83140590dca592b7b964e73090,parts_sha256,design_rules_sha256 computedwithsuppliedowningAPI currentroot,design_verdict SOUND|DEFECTIVE|INCOMPLETE,order_verdict DO-NOT-ORDER, completed_atactualUTC. Report333refs coverage split324inherited+9fresh,340FP/1002pads completeprojection; bindoriginalreports byfullSHAandexactquestiondispositionwithoutrewritingQUESTIONasoriginalPASS. Also bind previouscanonicalaggregate and acceptedchannelmapschematicreview. Keepgroup49ADC/16capcounts distinctfrom1002boardpadobjects, preservephysicalcapture/cable/body/render/layout/routing/release limits. Noassembly/twinorboardcandidategeneration. Currentboarditselfstill27hiddenlocatorblocked, routinginvestigation3/3spentunchanged; pinSOUNDdoesnotadmitroute. Rootwillreopenverbatimreport/outputs and independentlychecklivebindings. Nochildren. Fullhash sourcecommitusegit-reported full value if suppliedclosureheaders carryit; do not guessmissingdigits.''',12)
