from pathlib import Path
from datetime import datetime,timezone
import sys,os,json,hashlib,traceback
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';H=Path(__file__).parent
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet
from pipeline_runtime import run_stage
cfg=json.loads((H/'runner-config.json').read_text());e=TaskEnvelope.from_json(Path(cfg['envelope']).read_text());A=Path(cfg['envelope']).parent;O=A/'outputs';S=A/'scratch'
rows=[];error=None;complete=False
assert verify_input_packet(e,P)[0]
cut=datetime.fromisoformat(cfg['work_cutoff']);env={k:os.environ[k] for k in ['HOME','PATH']};env.update(LANG='C.UTF-8',PYTHONDONTWRITEBYTECODE='1')
def run(label,argv,limit):
 remaining=(cut-datetime.now(timezone.utc)).total_seconds()-90
 if remaining<30:raise RuntimeError('insufficient work time; no new child launched')
 timeout=min(limit,remaining);log=S/(label+'.log')
 rec={'stage':label,'argv':list(argv),'cwd':str(P),'environment_keys':sorted(env)}
 result=run_stage({'id':label,'work_class':'local','timeout_s':timeout},argv,log_path=log,cwd=P,env=env,console_line_limit=4,console_tail_lines=3)
 rec['runtime']=result.to_mapping();rows.append(rec)
 (S/(label+'-runtime.json')).write_text(json.dumps(rec,indent=2)+'\n')
 return rec,log.read_text(errors='replace')
try:
 for n in ['06_build/checkpoints/prelayout-inputs.json','06_build/checkpoints/prelayout.json','06_build/checkpoints/schematic.json','06_build/sourcing/prelayout_request.json','06_build/sourcing/prelayout_response.csv']:
  assert (P/n).is_file() and (P/n).stat().st_size>0,f'Missing exact checkpoint: {n}'
 q,_=run('qualify',['/usr/bin/python3',str(R/'skills/kicad-pcb/scripts/pcb_flow.py'),'qualify',str(P)],180)
 if q['runtime']['returncode']==0:
  run('placement',['/usr/bin/python3',str(R/'skills/kicad-pcb/scripts/pcb_flow.py'),'run',str(P),'--stage','placement_after_passive_review','--budget-s','600','--timeout-s','600','--','bash',str(P/'03_src/rebuild_all.sh'),'--resume-after-schematic-review'],600)
 complete=True
except Exception as exc:
 error=repr(exc);(S/'runner-error.txt').write_text(traceback.format_exc())
finally:
 complete = complete and all(r['runtime']['status'] in ('PASS', 'FAIL') for r in rows)
 checks={name:('PASS' if complete else 'FAIL') for name in ['inputs-verified','raw-run-recorded','processes-closed']}
 input_ok=verify_input_packet(e,P)[0];checks['inputs-verified']='PASS' if input_ok else 'FAIL'
 index=json.loads((H/'source-index.json').read_text());changed=[n for n,h in index.items() if not Path(n).is_file() or hashlib.sha256(Path(n).read_bytes()).hexdigest()!=h]
 if changed:checks['inputs-verified']='FAIL';error='authored inputs changed: '+repr(changed)
 artifacts={}
 for n in ['03_tscircuit/build/circuit.json','03_tscircuit/build/schematic.pdf','04_kicad/crow_audio_carrier_v1.kicad_sch','06_build/netlists/crow_audio_carrier_v1.net','04_kicad/crow_audio_carrier_v1.kicad_pcb']:
  p=P/n
  if p.is_file():artifacts[n]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size}
 evidence={'runs':rows,'complete':complete,'error':error,'source_unchanged_count':len(index)-len(changed),'source_total':len(index),'artifacts':artifacts,'limits':'Actual recorded stopping gate only; no design, placement, route or release acceptance.'}
 (O/'execution.json').write_text(json.dumps(evidence,indent=2)+'\n');(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
 with (O/'execution.log').open('wb') as out:
  for row in rows:
   out.write(('\nCOMMAND '+json.dumps(row['argv'])+'\nCWD '+str(P)+'\n').encode());out.write(Path(row['runtime']['log_path']).read_bytes())
  if error:out.write(('\nRUNNER ERROR: '+error+'\n').encode())
 lines=['# Recorded canonical attempt','',*['- '+r['stage']+': rc='+str(r['runtime']['returncode'])+', '+str(r['runtime']['elapsed_s'])+'s; full raw output execution.log' for r in rows],'- Authored input hashes: '+str(len(index)-len(changed))+'/'+str(len(index)),'- All generated identities are in execution.json.','- Stop at the last actual recorded gate. No routing or release acceptance.']
 if error:lines.append('- INCOMPLETE: '+error)
 (O/'report.md').write_text('\n'.join(lines)+'\n')
 (O/'result.json').write_text(json.dumps({'subject':e.subject.to_mapping(),'checks':checks,'unresolved':[] if complete and input_ok and not changed else [error or 'incomplete run']},indent=2)+'\n')
 print(json.dumps({'complete':complete,'error':error,'runs':[{k:r[k] for k in ['stage','runtime']} for r in rows]},indent=2))
raise SystemExit(0 if complete and input_ok and not changed else 1)
