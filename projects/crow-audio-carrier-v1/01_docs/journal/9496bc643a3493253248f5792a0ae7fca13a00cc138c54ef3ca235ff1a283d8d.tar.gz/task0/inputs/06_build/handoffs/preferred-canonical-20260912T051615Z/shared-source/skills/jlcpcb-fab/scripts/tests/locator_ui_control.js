// Exercise the actual shipped selection function with a minimal DOM surface.
// This is a state-transition test; visual usability remains a browser review.
const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const html = fs.readFileSync(process.argv[2], 'utf8');
class Element {
  constructor() {
    this.children = []; this.textContent = ''; this.value = ''; this.dataset = {};
    const values = new Set();
    this.classList = {
      toggle: (key, on) => on ? values.add(key) : values.delete(key),
      remove: key => values.delete(key), contains: key => values.has(key)
    };
  }
  append(...children) { this.children.push(...children); }
  replaceChildren(...children) { this.children = children; this.textContent = ''; }
  setAttribute() {}
  addEventListener() {}
}
const parts = [...html.matchAll(/<g class="part" data-ref="([^"]+)">/g)].map(match => {
  const node = new Element(); node.dataset.ref = match[1]; return node;
});
const ids = new Map(['query', 'error', 'ref', 'details', 'pads', 'cross', 'identity'].map(id => [id, new Element()]));
const context = {
  document: {
    querySelector: selector => ids.get(selector.slice(1)),
    querySelectorAll: selector => { assert.equal(selector, '.part'); return parts; },
    createElement: () => new Element(), createElementNS: () => new Element()
  },
  location: { hash: '' }, window: {}, console, Map, Object, String, Math,
  encodeURIComponent, decodeURIComponent
};
vm.createContext(context);
const script = html.match(/<script>([\s\S]*?)<\/script>/)[1];
vm.runInContext(script, context, {timeout: 5000});
const valid = parts[0].dataset.ref;
assert.equal(context.window.locator.select(valid), true);
assert.equal(ids.get('ref').textContent, valid);
assert.equal(parts.filter(p => p.classList.contains('selected')).length, 1);
assert.equal(context.window.locator.select('DOES_NOT_EXIST'), false);
assert.ok(ids.get('error').textContent.length > 0);
assert.equal(parts.filter(p => p.classList.contains('selected')).length, 0, 'unknown query retained a body selection');
assert.equal(ids.get('ref').textContent, '', 'unknown query retained the prior identity');
for (const id of ['cross', 'details', 'pads']) assert.equal(ids.get(id).children.length, 0, `unknown query retained ${id}`);
assert.equal(context.location.hash, '', 'unknown query retained prior URL identity');
console.log('PASS: valid → unknown clears highlight, identity, pads, crosshair and hash');
