#!/usr/bin/env python3
"""Fail closed unless both child boards implement the canonical spoke contract."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

import yaml


EXPECTED = {
    "schema": 1,
    "kind": "crow_roof_array_analog_spoke",
    "connector": {
        "manufacturer": "Molex",
        "family": "Micro-Fit 3.0",
        "pcb_header_mpn": "43650-0400",
        "positions": 4,
        "pitch_mm": 3.0,
        "orientation": "right_angle",
        "mounting": "through_hole",
        "rows": 1,
    },
    "mate": {
        "manufacturer": "Molex",
        "housing_mpn": "43645-0400",
        "quantity_per_cable": 2,
    },
    "terminals": {
        "manufacturer": "Molex",
        "contact_mpn": "43030-0007",
        "quantity_per_end": 4,
        "quantity_per_cable": 8,
    },
    "pins": [
        {"number": 1, "signal": "+12V_POD", "canonical_net": "12V_POD",
         "direction": "carrier_to_pod", "function": "power"},
        {"number": 2, "signal": "GND", "canonical_net": "GND",
         "direction": "return_to_carrier", "function": "power_return"},
        {"number": 3, "signal": "AUDIO+", "canonical_net": "AUDIO_P",
         "direction": "pod_to_carrier", "function": "active_balanced_positive"},
        {"number": 4, "signal": "AUDIO−", "canonical_net": "AUDIO_N",
         "direction": "pod_to_carrier", "function": "active_balanced_negative"},
    ],
    "cable": {'manufacturer': 'Belden',
     'mpn': '7939A',
     'nominal_array_radius_m': 4.0,
     'installed_length_per_port_status': 'OWED',
     'qualification_reference_length_m': 15.0,
     'maximum_design_length_m': 15.0,
     'qualified_maximum_length_m': None,
     'length_qualification_status': 'OWED',
     'topology': 'four_twisted_pairs_overall_foil_shield',
     'outer_diameter_nominal_mm': 7.49,
     'minimum_bend_radius_mm': 53.0,
     'pair_allocation': {'blue': ['AUDIO+', 'AUDIO−'],
                         'orange': ['+12V_POD', 'GND'],
                         'green': ['+12V_POD', 'GND'],
                         'brown': ['+12V_POD', 'GND']},
     'conductor_map': [{'cavity': 3, 'signal': 'AUDIO+', 'pair': 'blue', 'color': 'white_blue'},
                       {'cavity': 4, 'signal': 'AUDIO−', 'pair': 'blue', 'color': 'blue'},
                       {'cavity': 1,
                        'signal': '+12V_POD',
                        'pair': 'orange',
                        'color': 'white_orange'},
                       {'cavity': 2, 'signal': 'GND', 'pair': 'orange', 'color': 'orange'},
                       {'cavity': 1,
                        'signal': '+12V_POD',
                        'pair': 'green',
                        'color': 'white_green'},
                       {'cavity': 2, 'signal': 'GND', 'pair': 'green', 'color': 'green'},
                       {'cavity': 1,
                        'signal': '+12V_POD',
                        'pair': 'brown',
                        'color': 'white_brown'},
                       {'cavity': 2, 'signal': 'GND', 'pair': 'brown', 'color': 'brown'}],
     'end_housing_mpn': '43645-0400',
     'straight_pin_identity': True,
     'end_a': {'role': 'carrier', 'mating_face_cavity_order': [1, 2, 3, 4]},
     'end_b': {'role': 'pod', 'mating_face_cavity_order': [1, 2, 3, 4]},
     'cavity_numbering_drawing_status': 'OWED',
     'crimp_tool_and_strip_process_status': 'OWED',
     'continuity_test': '1-1; 2-2; 3-3; 4-4; verify all six power conductors individually before '
                        'joining; no cross-short; shield isolated from all cavities; finished '
                        'loop resistance <=2.2 ohm at maximum service temperature',
     'shield_drains': 'carrier_chassis_at_enclosure_entry_before_pcb_header; insulated_at_pod; '
                      'not_present_in_micro_fit',
     'construction': {'category': 'Cat5e',
                      'conductor_awg': 24,
                      'conductor_stranding': '7x32',
                      'conductor_material': 'bare_copper',
                      'shield': 'overall_foil_with_drain',
                      'jacket': 'PVC',
                      'order_variant': '7939A 0101000',
                      'outdoor_rating': 'CMX-Outdoor',
                      'manufacturer_stationary_bend_radius_mm': 15.0,
                      'operating_temperature_min_c': -40.0,
                      'operating_temperature_max_c': 75.0,
                      'installation_temperature_min_c': -25.0,
                      'maximum_conductor_dcr_ohm_per_km': 93.8,
                      'copper_clad_aluminum_permitted': False},
     'power_fan_in': {'manufacturer': 'WAGO',
                      'mpn': '221-415',
                      'quantity_per_end': 2,
                      'quantity_per_cable': 4,
                      'conductors_per_rail': 3,
                      'ports_per_join': 5,
                      'occupied_ports_per_join': 4,
                      'conductors_per_port': 1,
                      'unused_port': 'lever_closed_no_conductor',
                      'pigtail_manufacturer': 'Belden',
                      'pigtail_mpn': '8503',
                      'pigtail_awg': 22,
                      'pigtail_maximum_length_mm': 150.0,
                      'positive_pigtail_color': 'red',
                      'return_pigtail_color': 'black',
                      'location': 'inside_dry_enclosure_after_gland',
                      'qualification_status': 'OWED'},
     'termination_process': {'micro_fit_conductors_per_contact': 1,
                             'power': 'one_22_awg_8503_pigtail_per_contact',
                             'audio': 'one_24_awg_7939A_conductor_per_contact',
                             'audio_insulation_diameter_fit_status': 'OWED',
                             'maximum_contact_insulation_diameter_mm': 1.85,
                             'crimp_tool_mpn': '63819-0000',
                             'extraction_tool_mpn': '11-03-0043',
                             'bonded_pair_separation_process_status': 'OWED',
                             'multiple_wires_in_micro_fit_contact_permitted': False},
     'power_budget': {'reference_temperature_c': 20.0,
                      'maximum_service_temperature_c': 75.0,
                      'hot_resistance_multiplier': 1.25,
                      'pigtails_joins_contacts_loop_allowance_ohm': 0.3,
                      'allowance_status': 'DESIGN_ALLOCATION_MEASUREMENT_OWED'}},
    "electrical": {
        "supply_nominal_v": 12.0,
        "supply_plane": "carrier_header_pin_1_to_pin_2",
        "carrier_header_supply_min_v": 10.8,
        "carrier_header_supply_max_v": 13.2,
        "maximum_cable_and_contact_loop_resistance_ohm": 2.2,
        "pod_header_supply_min_v_at_max_current_and_length": 10.5,
        "hot_plug_permitted": False,
        "pod_input_capacitance_max_uf": 47.0,
        "inrush_qualification_status": "OWED",
        "maximum_continuous_pod_current_a": 0.10,
        "carrier_protection_hold_min_a_at_70c": 0.10,
        "carrier_protection_trip_max_a_at_25c": 0.70,
        "fault_clearing_requirement": (
            "carrier_limits_cable_and_pre_pod_faults_while_pod_protection_"
            "limits_downstream_board_faults_and_one_faulted_spoke_does_not_"
            "reset_other_seven"
        ),
        "audio_interface": "active_balanced_analog",
        "pod_output_coupling": "dc_coupled",
        "pod_audio_common_mode_nominal_v": 2.5,
        "pod_audio_common_mode_min_v": 2.35,
        "pod_audio_common_mode_max_v": 2.65,
        "pod_source_impedance_nominal_ohm_each_leg": 100.0,
        "pod_source_impedance_maximum_mismatch_ohm": 2.0,
        "pod_maximum_output_differential_vrms": 1.2,
        "carrier_input_coupling": "ac_coupled_each_leg",
        "carrier_input_coupling_capacitance_uf_each_leg": 1.0,
        "carrier_input_bias_resistance_ohm_each_leg": 100000,
        "receiver_full_scale_differential_vrms": 2.0,
        "acoustic_polarity_target": (
            "positive_pressure_drives_AUDIO+_positive_relative_to_AUDIO−"
        ),
        "acoustic_polarity_qualification_status": "OWED",
        "ethernet": False,
        "poe": False,
    },
    "straight_through": True,
}


class ContractError(ValueError):
    pass


CHILD_KIND = "crow-spoke-implementation-v1"
CHILD_TIMEOUT_S = 60
CHILDREN = {
    "carrier": {
        "root": "projects/crow-audio-carrier-v1",
        "checker": "03_src/check_spoke_implementation.py",
        "board": "04_kicad/crow_audio_carrier_v1.kicad_pcb",
        "schematic": "04_kicad/crow_audio_carrier_v1.kicad_sch",
        "refs": tuple(f"J{index}" for index in range(1, 9)),
        "footprint": "crow_audio_carrier:Molex_43650-0400_RA_Exact",
    },
    "pod": {
        "root": "projects/crow-mic-pod-v3",
        "checker": "03_src/check_spoke_implementation.py",
        "board": "04_kicad/crow_mic_pod_v3.kicad_pcb",
        "schematic": "04_kicad/crow_mic_pod_v3.kicad_sch",
        "refs": ("J1",),
        "footprint": (
            "crow_mic_pod_v3:"
            "Molex_Micro-Fit_3.0_43650-0400_1x04_P3.00mm_Horizontal"
        ),
    },
}


class StrictSafeLoader(yaml.SafeLoader):
    """Safe YAML loader that rejects duplicate mapping keys."""


def _construct_unique_mapping(loader: StrictSafeLoader, node: yaml.Node,
                              deep: bool = False) -> dict:
    mapping: dict = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        if key in mapping:
            raise yaml.constructor.ConstructorError(
                "while constructing a mapping",
                node.start_mark,
                f"duplicate key: {key!r}",
                key_node.start_mark,
            )
        mapping[key] = loader.construct_object(value_node, deep=deep)
    return mapping


StrictSafeLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
    _construct_unique_mapping,
)


def load_contract(path: Path) -> tuple[dict, bytes]:
    if path.is_symlink() or not path.is_file():
        raise ContractError(f"missing regular contract: {path}")
    try:
        raw = path.read_bytes()
        value = yaml.load(raw.decode("utf-8"), Loader=StrictSafeLoader)
    except (OSError, UnicodeError, yaml.YAMLError) as exc:
        raise ContractError(f"cannot read {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ContractError(f"contract must be a mapping: {path}")
    if value != EXPECTED:
        raise ContractError(f"contract differs from canonical spoke interface: {path}")
    return value, raw


def cable_power_budget(value: dict) -> dict:
    """Screen the complete hot loop; allocated contact resistance is not measured.

    The selected cable DCR is screened with a conservative 1.25 temperature
    factor. Physical acceptance still measures the entire finished harness.
    """
    cable = value["cable"]
    rows = cable["conductor_map"]
    positive = sum(row["cavity"] == 1 for row in rows)
    negative = sum(row["cavity"] == 2 for row in rows)
    if min(positive, negative) < 1:
        raise ContractError("power conductor population is empty")
    budget = cable["power_budget"]
    length = cable["maximum_design_length_m"]
    dcr = cable["construction"]["maximum_conductor_dcr_ohm_per_km"]
    hot_loop = (length / 1000 * dcr * (1 / positive + 1 / negative)
                * budget["hot_resistance_multiplier"]
                + budget["pigtails_joins_contacts_loop_allowance_ohm"])
    electrical = value["electrical"]
    drop = hot_loop * electrical["maximum_continuous_pod_current_a"]
    pod_voltage = electrical["carrier_header_supply_min_v"] - drop
    if (hot_loop > electrical["maximum_cable_and_contact_loop_resistance_ohm"]
            or pod_voltage < electrical["pod_header_supply_min_v_at_max_current_and_length"]):
        raise ContractError(f"hot harness loop fails: {hot_loop:.6f} ohm, {pod_voltage:.6f} V")
    return {"power_conductors": positive + negative,
            "design_hot_loop_ohm": round(hot_loop, 6),
            "design_drop_v": round(drop, 6),
            "design_pod_min_v": round(pod_voltage, 6),
            "physical_qualification": "OWED"}


def verify_contracts(repo_root: Path) -> dict:
    paths = [
        repo_root / "projects/crow-roof-array-v1/03_src/rules/spoke_interface.yaml",
        repo_root / "projects/crow-audio-carrier-v1/03_src/rules/spoke_interface.yaml",
        repo_root / "projects/crow-mic-pod-v3/03_src/rules/spoke_interface.yaml",
    ]
    loaded = [load_contract(path) for path in paths]
    values = [item[0] for item in loaded]
    payloads = [item[1] for item in loaded]
    if any(item != values[0] for item in values[1:]):
        raise ContractError("parent/carrier/pod spoke contract values disagree")
    if any(item != payloads[0] for item in payloads[1:]):
        raise ContractError("parent/carrier/pod spoke contract bytes disagree")
    return {
        "schema": 1,
        "kind": "crow-roof-array-spoke-interface-check-v1",
        "status": "PASS",
        "contracts": [str(path.relative_to(repo_root)) for path in paths],
        "contract_sha256": hashlib.sha256(payloads[0]).hexdigest(),
        "pins": 4,
        "straight_through": True,
        "cable_power_budget": cable_power_budget(values[0]),
    }


def _record(base: Path, path: Path) -> dict:
    if path.is_symlink() or not path.is_file():
        raise ContractError(f"expected ordinary file: {path}")
    payload = path.read_bytes()
    return {
        "path": path.relative_to(base).as_posix(),
        "sha256": hashlib.sha256(payload).hexdigest(),
        "size": len(payload),
    }


def _unique_json_pairs(pairs: list[tuple[str, object]]) -> dict:
    result: dict = {}
    for key, value in pairs:
        if key in result:
            raise ContractError(f"child receipt has duplicate JSON key {key!r}")
        result[key] = value
    return result


def _expected_nets(role: str, ref: str) -> dict[int, str]:
    suffix = str(int(ref[1:])) if role == "carrier" else ""
    return {
        1: f"12V_POD{suffix}",
        2: "GND",
        3: f"AUDIO_P{suffix}",
        4: f"AUDIO_N{suffix}",
    }


def _validate_binding(project_root: Path, binding: object,
                      expected_path: str, label: str) -> dict:
    if not isinstance(binding, dict) or set(binding) != {"path", "sha256", "size"}:
        raise ContractError(f"{label} binding must contain path/sha256/size exactly")
    if binding.get("path") != expected_path:
        raise ContractError(
            f"{label} path {binding.get('path')!r}, expected {expected_path!r}"
        )
    actual = _record(project_root, project_root / expected_path)
    if binding != actual:
        raise ContractError(f"{label} binding is stale: {binding!r} != {actual!r}")
    return actual


def _validate_child_receipt(repo_root: Path, role: str, receipt: object) -> dict:
    spec = CHILDREN[role]
    project_root = repo_root / spec["root"]
    if not isinstance(receipt, dict):
        raise ContractError(f"{role} checker did not emit a JSON mapping")
    required = {
        "schema", "kind", "role", "contract_sha256", "denominator",
        "board", "schematic", "connectors",
    }
    if set(receipt) != required:
        raise ContractError(
            f"{role} receipt fields differ: missing={sorted(required-set(receipt))}, "
            f"unknown={sorted(set(receipt)-required)}"
        )
    if (receipt.get("schema"), receipt.get("kind"), receipt.get("role")) != (
            1, CHILD_KIND, role):
        raise ContractError(f"{role} receipt schema/kind/role is invalid")
    contract_path = repo_root / spec["root"] / "03_src/rules/spoke_interface.yaml"
    contract_sha = hashlib.sha256(contract_path.read_bytes()).hexdigest()
    if receipt.get("contract_sha256") != contract_sha:
        raise ContractError(f"{role} receipt is bound to the wrong spoke contract")

    refs = tuple(spec["refs"])
    denominator = receipt.get("denominator")
    if denominator != {"expected": len(refs), "realized": len(refs)}:
        raise ContractError(f"{role} denominator is not closed: {denominator!r}")
    board = _validate_binding(
        project_root, receipt.get("board"), str(spec["board"]), f"{role} board"
    )
    schematic = _validate_binding(
        project_root, receipt.get("schematic"), str(spec["schematic"]),
        f"{role} schematic",
    )

    connectors = receipt.get("connectors")
    if not isinstance(connectors, list) or len(connectors) != len(refs):
        raise ContractError(
            f"{role} connector denominator is "
            f"{len(connectors) if isinstance(connectors, list) else 'invalid'}/"
            f"{len(refs)}"
        )
    by_ref: dict[str, dict] = {}
    for connector in connectors:
        if not isinstance(connector, dict) or set(connector) != {
                "ref", "mpn", "footprint", "pads"}:
            raise ContractError(f"{role} connector row has an invalid schema")
        ref = connector.get("ref")
        if not isinstance(ref, str) or ref in by_ref:
            raise ContractError(f"{role} connector ref is empty or duplicated: {ref!r}")
        by_ref[ref] = connector
    if set(by_ref) != set(refs):
        raise ContractError(
            f"{role} realized refs {sorted(by_ref)!r}, expected {list(refs)!r}"
        )
    for ref in refs:
        row = by_ref[ref]
        if row["mpn"] != EXPECTED["connector"]["pcb_header_mpn"]:
            raise ContractError(f"{role} {ref} uses the wrong connector MPN")
        if row["footprint"] != spec["footprint"]:
            raise ContractError(f"{role} {ref} uses the wrong exact footprint")
        pads = row["pads"]
        if not isinstance(pads, list) or any(
                not isinstance(pad, dict) or set(pad) != {"number", "net"}
                for pad in pads):
            raise ContractError(f"{role} {ref} pad rows have an invalid schema")
        actual_pads = {pad["number"]: pad["net"] for pad in pads}
        if len(actual_pads) != len(pads) or actual_pads != _expected_nets(role, ref):
            raise ContractError(
                f"{role} {ref} realized pad map {actual_pads!r}, "
                f"expected {_expected_nets(role, ref)!r}"
            )
    return {
        "role": role,
        "denominator": denominator,
        "board": board,
        "schematic": schematic,
        "connectors": len(connectors),
    }


def _run_child_checker(repo_root: Path, role: str) -> dict:
    spec = CHILDREN[role]
    project_root = repo_root / spec["root"]
    checker = project_root / spec["checker"]
    checker_record = _record(repo_root, checker)
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    try:
        completed = subprocess.run(
            [sys.executable, "-B", str(checker), str(project_root), "--json"],
            cwd=repo_root,
            env=env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
            timeout=CHILD_TIMEOUT_S,
        )
    except subprocess.TimeoutExpired as exc:
        raise ContractError(
            f"{role} implementation checker exceeded {CHILD_TIMEOUT_S}s"
        ) from exc
    if completed.returncode != 0:
        detail = (completed.stdout + completed.stderr)[-3000:]
        raise ContractError(f"{role} implementation checker failed: {detail}")
    try:
        receipt = json.loads(completed.stdout, object_pairs_hook=_unique_json_pairs)
    except (json.JSONDecodeError, ContractError) as exc:
        raise ContractError(f"{role} checker emitted invalid JSON: {exc}") from exc
    if _record(repo_root, checker) != checker_record:
        raise ContractError(f"{role} implementation checker changed while executing")
    result = _validate_child_receipt(repo_root, role, receipt)
    result["checker"] = checker_record
    return result


def verify(repo_root: Path) -> dict:
    """Verify the three contracts and both generated child implementations."""
    repo_root = Path(repo_root).resolve()
    contract_result = verify_contracts(repo_root)
    implementations = [
        _run_child_checker(repo_root, role) for role in ("carrier", "pod")
    ]
    return {
        **contract_result,
        "kind": "crow-roof-array-spoke-system-check-v1",
        "implementations": implementations,
        "realized_connectors": 9,
        "realized_straight_through_pin_paths": 32,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[3])
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    try:
        result = verify(args.root.resolve())
    except ContractError as exc:
        print(f"CROW-SPOKE FAIL: {exc}", file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(result, sort_keys=True))
    else:
        print("CROW-SPOKE PASS: 3/3 contracts; carrier 8/8 + pod 1/1 "
              "generated connectors; 32/32 straight-through pin paths")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
