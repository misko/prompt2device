# Recorded canonical attempt

- qualify: rc=0, 18.641168s; full raw output execution.log
- normal: rc=2, 91.790644s; full raw output execution.log
- public-continuation: rc=2, 1.620898s; full raw output execution.log
- Authored input hashes: 593/593
- All generated identities are in execution.json.
- Stop at the last actual recorded gate. No routing or release acceptance.
