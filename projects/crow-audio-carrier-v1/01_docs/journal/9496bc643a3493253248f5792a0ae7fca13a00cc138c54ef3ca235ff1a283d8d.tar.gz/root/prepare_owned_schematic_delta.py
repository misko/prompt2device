from pathlib import Path
import sys,json,hashlib,subprocess,tempfile,shutil
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';C=Path(__file__).parent;OLD=Path('/tmp/carrier-owned-schematic-delta-ejefg1lq');D=Path(tempfile.mkdtemp(prefix='carrier-owned-schematic-delta-'));head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();prev='9e00dcf23d03b244164476b51fc705ea0728d440';sha=lambda b:hashlib.sha256(b).hexdigest()
shutil.copytree(OLD/'current',D/'previous');shutil.copytree(OLD/'current',D/'current')
for p in (D/'current').rglob('*'):
 if p.is_file():
  live=P/p.relative_to(D/'current');assert live.is_file(),str(live);p.write_bytes(live.read_bytes())
for folder in ['authority','external_hardware','method']:shutil.copytree(OLD/folder,D/folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
shutil.copyfile(OLD/'preflight.py',D/'preflight.py');(D/'prior-accepted').mkdir()
for kind in ['topology','schematic_render']:shutil.copyfile(OLD/'06_build/task_runs/thermal-schematic-delta/outputs'/(kind+'.md'),D/'prior-accepted'/('pre-route_'+kind+'.md'))
j=json.loads((C/'owned-source-review-opened.json').read_text())[0];(D/'source-witnesses').mkdir();shutil.copyfile(Path(j['output_dir'])/'report.md',D/'source-witnesses/owned-label-source-review.md')
for n in ['skills/kicad-pcb/scripts/pre_route_review_check.py','skills/jlcpcb-fab/scripts/assembly_locator_check.py']:
 target=D/'authority'/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/n,target)
def inventory(side):return {p.relative_to(D/side).as_posix():sha(p.read_bytes()) for p in (D/side).rglob('*') if p.is_file()}
a,b=inventory('previous'),inventory('current');changes=[{'path':n,'previous_sha256':a.get(n),'current_sha256':b.get(n)} for n in sorted(a.keys()|b.keys()) if a.get(n)!=b.get(n)];(D/'changes.json').write_text(json.dumps(changes,indent=2)+'\n')
sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'));import pre_route_review_check as g
parts=sorted((P/'02_parts').glob('*/part.yaml'));bindings={'source_commit':head,'previous_source_commit':prev,'netlist_sha256':g.netlist_digest(P/'06_build/netlists/crow_audio_carrier_v1.net'),'parts_sha256':sha(b''.join(p.relative_to(P).as_posix().encode()+b'\0'+p.read_bytes()+b'\0' for p in parts)),'design_rules_sha256':g.design_rules_digest(P),'packet_counts':{'previous':len(a),'current':len(b),'changed':len(changes)}};(D/'bindings.json').write_text(json.dumps(bindings,indent=2)+'\n');(C/'owned-schematic-delta-prepared.json').write_text(json.dumps({'root':str(D),'bindings':bindings},indent=2)+'\n');print(json.dumps({'root':str(D),'bindings':bindings},indent=2))
