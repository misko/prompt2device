review_stage: pre-route
review_kind: topology
reviewer_identity: /root/carrier_rj45_native_carrier_topology_mediumfinal1
context: FRESH
date: 2026-09-16T02:23:25.796395+00:00
design_verdict: DEFECTIVE
order_verdict: DO-NOT-ORDER
netlist_sha256: 1a67c6e52fa59b14e390ee3a4739efd9864add4f352bf797f4edd952e6a9b1d5
parts_sha256: 7e43d5d63f3021d88fa96b12d4f5bd80048868bad8f66fd53bc1f112743950fd
design_rules_sha256: 5214217bd896a1c6a13719afda45bd6389e38f1d2ddc1851ca16c677d24b6f2f
schematic_pdf_sha256: 54719617418fea2d92d794d42d8f6fe93d36509462e24ae8c30dafef0577ed98
exact_netlist_sha256: 1c9c6ae6646415c272672c971f69fa5ab61ca61a026389c6b49cec1e8feee0a1
circuit_json_sha256: 47fd752f4203c191c737adb386535c45954f13219b00ae83c336e539c042ab0f
kicad_schematic_sha256: 0e9ff10faefcd886dc88a151aaaaad90a36a950703d9849ce376d5acdc91c6a8

Fresh independent judgment: DEFECTIVE for one authored route safety violation. The complete electrical topology, component identities, connected pins and supervisor footprint interpretation examined here are otherwise sound for the declared first-article scope. DO-NOT-ORDER remains mandatory. No native board or routing qualification is granted.

Blocking finding F1 — ADC_RESET_N through-via aspect ratio

The coordinator alerted me to this candidate defect during review; I independently reopened and calculated it from frozen inputs. `03_src/route.yaml`, `stitch.relocate_exact_vias.edits[14]`, replaces a 0.50/0.20mm via at (98.1,74.15) with a 0.25/0.15mm F.Cu-to-B.Cu through-via. `floorplan.yaml` declares nominal thickness1.6mm. The resulting nominal aspect ratio is1.6/0.15=10.6666667, exceeding the selected10:1 capability explicitly recorded in ADR0010 lines72–73. The existing source rule is not reduced; this target geometry violates it. Correct the authored target and rebind the affected review before acceptance. This is an actual source manufacturing defect under the commission's numeric-floor requirement, not a demand for premature prototype evidence. It does not assert that a saved board has already realized the bad target. Native final-board validation remains separately required.

Complete measured census

I evaluated TSX JSX declarations without invoking the circuit producer, tokenized native netlist and schematic S-expressions, and reconstructed circuit.json connectivity independently with union-find over source_trace edges. The 333 component sets agree across source, manifest, circuit.json, native netlist and schematic properties. All333 source values/MPNs and dossier footprints agree with native components;120 resistance strings differ only by unit spelling. All943 connected nodes agree across source, reconstructed circuit.json and native netlist. The native inventory also includes42 explicit NC nodes:985 nodes on221 nets. The988 dossier physical identities resolve through three documented Q_IN drain aliases6/7/8→5. This is a full inventory, not a sampled component check. Native schematic property agreement is not represented as another independently exported native wire netlist.

All205 invariants were independently evaluated against that inventory:152 pin assertions,51 values, one series chain and one capacitor census. All pass. The shared electrical-invariants gate also passes205/205. Its initial invocation used a schema-only option with the wrong mode and failed before checking; the corrected invocation and both logs are retained. No broad unit suite was repeated.

Current conditional arithmetic/topology screens applied to my independently parsed native inventory pass9/9 clock,7/7 TDM and10/10 protection checks. Analog coverage is8 channels/8 exact OPA2320 duals,16 current-limit resistors,16 same-leg feedback resistors,32 independent shunts,2 external half-supply dividers,2 direct reference-negative returns and2 polarized reference capacitors. These frozen calculations remain conditional engineering screens rather than measured transient, thermal or signal-integrity guarantees. Historical producer-oriented wording in the power receipt is not adopted as current native-review status.

Changed supervisor authority

I visually reopened TI TPS3890_SLVSD65A PDF pages25–26 and inspected both actual footprint S-expressions and current dossier. U_PWR and U_AUDIO both use `crow_audio_carrier:TI_DSE0006A_GNDToe018`. Pads1/3/4/5/6 copper geometry, courtyard, body model and pin1 marker match the retained baseline. Pad2 changes center from(-0.60,0) to(-0.69,0) and length0.70 to0.88mm; its inward edge stays at-0.25mm while the outside edge moves-0.95→-1.13mm: exactly0.18mm outward extension. All six paste apertures retain their original position/shape/dimensions: pad1 0.80x0.25mm, others0.70x0.25mm, R0.05mm.

TI page25's explicit lower detail names pads1–3 solder-mask-defined with0.05mm minimum copper overlap, while its upper green outlines appear expanded. The README accurately identifies this ambiguity. The implemented separate rectangular mask openings0.70x0.15mm for pad1 and0.60x0.15mm for pads2/3 follow the explicit lower detail, with pad2 mask centered on the former land. Pads4–6 explicitly expand mask0.05mm. These are engineering-derived dimensions, not falsely claimed printed TI mask dimensions. Page26 separately specifies the retained paste; overprinting the smaller SMD openings is disclosed. This is reasonable pre-route source authority with fresh footprint/pin/render, actual Gerber aperture verification and first-article solder inspection still owed. It is not measured assembly qualification.

Historical methods were reused; current acceptance was not inherited. Historical route/floorplan/nets/invariant/dossier files used for comparison were checked against that historical packet's declared hashes. Current full pin/net inventory equals the historical inventory, and the observed component-property changes are the two supervisor footprint references. The current nets.yaml and electrical invariants remain byte-identical to that historical packet. Route/floorplan and supervisor dossier changed. The current inventory was independently derived regardless of that comparison; no claim of a complete geometric delta or final adjacency acceptance follows.

Digital, connector and power review

Both governed digital groups explicitly retain no_vias:true over13 nets. Independent current seed census gives110 segments, allF.Cu, zero vias. Ten nets have seed copper; ADC_TDM, TDM_CLEAN and TDM_BUFFERED have none, so this is not a completed-route claim. Per-net minimum seed width remains0.18mm, subnominal count≤3 and accumulated length≤3mm. ADC_FSYNC is longest at2.827200mm. These digital contracts do not excuse F1 on the separate reset net.

R_FSYNC is22ohm, CRCW120622R0FKEAHP, Resistor_SMD:R_1206_3216Metric, C844025, between FSYNC_BUF and ADC_FSYNC. Its current dossier declares750mW,1%,100ppm/C and the retained primary Vishay20043 revision20260317. Three clock22ohm resistors, three input10k pulldowns, local100nF bypass and buffer pin mapping agree. Package identity does not establish parasitics or50ohm transmission-line impedance.

All80 RJ45 contacts were checked:1/3/7=12V_PODn;2/6/8=GND;5=AUDIO_Pn;4=AUDIO_Nn;9/10=CHASSIS. CHASSIS has exactly16 shell nodes and no GND connection. This is custom analog/power, not Ethernet/PoE. Factory-cord physical mating, chassis bond and prototype integration remain later obligations.

The input fuse→Q_IN drain→protected source bus, gate clamp orientation, gate pulldown and SMBJ15A cathode-to-bus/anode-toGND agree with the native inventory. Buck-reservoir isolation remains explicit; the adopted transient screen24.4V×1.2=29.28V is below32V buck and50V input ceramics. Sustained overvoltage cutoff and complete downstream backfeed blocking are not claimed. CS5308P, OPA2320 and LT3041 analog domains remain3V3_ADC; external1k/1k half-supply banks stay separate from ADC VMID outputs. Held supply, supervisors, analog isolation, discharge and hardware high-low-high reset endpoints remain consistent. Actual ramp timing, aging, charge injection, thermal, fault clearing and independent-power-state operation remain first-article work.

Visual and evidence limits

I visually inspected all19 delivered PDF pages as individual1600-pixel images, plus the two TI primary drawing images. Pages1–5 show protection/power/supervision,6–13 all10 contacts on each jack and every channel,14–16 ADC/NC/reference banks,17–19 clock/TDM/reset. Page17 is crowded but crossing bridges and labels remain distinguishable; all three22ohm clock resistors are legible. No lost contact, wrong polarity or topology-changing ground-bar conflict was found. This corroborates topology and does not replace the separately commissioned readability verdict.

All430 frozen input files and all seven subject hashes were independently checked before review and again after packaging inputs. Frozen ERC is inherited0-error/2637-warning evidence (2068 endpoint_off_grid,569 lib_symbol_issues), not a fresh ERC or zero-warning claim. No live edits, board generation/saves, adoption, commits or child agents occurred. The complete delivery records the engineering defect; result.json PASS fields mean delivery completeness, not design acceptance. Exact manufacturer allocation, physical qualification and production/orderability remain open.
