import sys,json,hashlib,tarfile,datetime,re
from pathlib import Path
sys.dont_write_bytecode=True
R=Path.cwd();S=Path(__file__).parent;O=S.parent/'outputs'
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_execution import TaskEnvelope,envelope_sha256
E=TaskEnvelope.from_json((S.parent/'envelope.json').read_text())
e=json.loads((S.parent/'envelope.json').read_text());h=json.loads((S/'hashes.json').read_text()); bad=[]
for x in e['input_packet']:
 b=(R/x['path']).read_bytes()
 if len(b)!=x['size'] or hashlib.sha256(b).hexdigest()!=x['sha256']:bad.append(x['path'])
assert not bad
(S/'inputs-after.json').write_text(json.dumps({'verified':430,'bad':bad,'canonical_envelope_sha256':envelope_sha256(E)},indent=2))
erc=(R/'project/06_build/erc.rpt').read_text();assert erc.count('[endpoint_off_grid]')==2068 and erc.count('[lib_symbol_issues]')==569
header={'review_stage':'pre-route','review_kind':'topology','reviewer_identity':'/root/carrier_rj45_native_carrier_topology_mediumfinal1','context':'FRESH','date':datetime.datetime.now(datetime.timezone.utc).isoformat(),'design_verdict':'DEFECTIVE','order_verdict':'DO-NOT-ORDER',**h}
(O/'report.md').write_text('\n'.join(f'{k}: {v}' for k,v in header.items())+'\n'+(S/'report-body.md').read_text())
proof={'verdict':'DEFECTIVE','design_verdict':'DEFECTIVE','order_verdict':'DO-NOT-ORDER','subject':e['subject'],'subject_hashes':h,'canonical_envelope_sha256':envelope_sha256(E),'methods':['Independent JSX declaration evaluation','Independent native S-expression inventory','Circuit source-trace union-find','Independent invariant evaluation plus shared gate','Frozen conditional analog/logic/power screens on independent native inventory','Current source digital census, supervisor copper/paste/mask comparison and independent aspect-ratio calculation','All19 actual PDF pages visually inspected'],'counts':{'inputs_before':430,'inputs_after':430,'hashes':7,'components':333,'native_nodes':985,'connected_nodes':943,'no_connect_nodes':42,'physical_pins':988,'fused_aliases':3,'invariants_pass':205,'invariants_total':205,'rj45_contacts':80,'digital_groups':2,'digital_nets':13,'digital_seed_segments':110,'visual_pages':19},'findings':[json.loads((S/'changed-authority.json').read_text())['numeric_safety_finding']],'limits':['Pre-route schematic only; no final board or routing acceptance','Historical source comparison is supporting evidence; current inventory and authority checked freshly','Manufacturer allocation and physical first article remain owed','Conditional screens are not measured guarantees']}
(O/'evidence.json').write_text(json.dumps(proof,indent=2))
files=[p for p in sorted(S.iterdir()) if p.is_file() and p.name not in ['package.log','package.runtime.json','preflight.log','preflight.runtime.json']];archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=p.name,recursive=False)
members=[];names=set()
with tarfile.open(archive,'r:gz') as t:
 for m in t.getmembers():
  assert m.isfile() and not m.issym() and not m.islnk() and m.name not in names and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and not m.name.endswith(('.tar','.tar.gz','.tgz','.zip'))
  names.add(m.name);b=t.extractfile(m).read();assert len(b)==m.size;assert b==(S/m.name).read_bytes();members.append({'path':m.name,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
b=archive.read_bytes();manifest={'archive_sha256':hashlib.sha256(b).hexdigest(),'archive_size':len(b),'member_count':len(members),'members':members};(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2))
(O/'result.json').write_text(json.dumps({'subject':e['subject'],'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]},indent=2))
print('DEFECTIVE / DO-NOT-ORDER; all five deliverables; reopened archive members',len(members),'bytes',len(b))
