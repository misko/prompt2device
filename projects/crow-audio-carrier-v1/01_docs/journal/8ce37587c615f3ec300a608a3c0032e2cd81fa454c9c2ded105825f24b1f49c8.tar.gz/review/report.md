review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_power_fets_clockground1 (fresh independent agent)
context: FRESH
design_verdict: INCOMPLETE
order_verdict: DO-NOT-ORDER
board_sha256: e85b1461a82f3d3853c19fae694693816e31570d23d37019ef187d6428bea4ae
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: e6d5b0b89efd79051b082f70b283ec7e85e1170ed11ddb94581744d26904c9c7

Coverage is limited to Q_IN and Q_PRE, the complete commissioned group. This is not whole-board acceptance. The three immutable bindings above are supplied metadata, not independently reviewed whole-artifact conclusions.

Q_IN — VERDICT: QUESTION
Primary: DMP6023LFG DS37204 Rev. 2-2, SHA-256 1ea244be5e0fe4195ad20cb2da0960ac622b6efc19cf9e579c9eb8ef5777fa27; PDF p.1 Bottom View/Top View and Equivalent Circuit, p.5 Package Outline Dimensions and Suggested Pad Layout (unnumbered package figures).
Measured inventory: 5 numbered native pad rows/identities, 3 declared fused aliases (6/7/8 -> 5 in schematic and footprint), 8 represented physical lead identities, 8 unnumbered paste/mechanical features; 13 native features total. All 8 physical identities were assessed. Manufacturer has 8 leads and a shared exposed drain, not a separately numbered ninth EP.

Manufacturer derivation preceded dossier reading. The p.1 bottom view has sources 1–3 followed by gate 4 on one row; drains 5–8 form the opposite row and continuous exposed drain leadframe. The p.5 bottom outline has 1..4 left-to-right above 8..5; reflect once to top view. The suggested pad layout independently shows bottom row 1..4 and top row 8..5 with a continuous drain comb. Rotate that landing view clockwise 90 degrees: left column 1/2/3/4 from top to bottom, right drain contacts 8/7/6/5 from top to bottom. Full physical numbering is CCW. Front mounting requires no extra mirror.

Q_IN pins 1,2,3 (SOURCE): expected left column upper three contacts; observed x=-1.500, y=-0.975/-0.325/+0.325, each 12V_PROTECTED. Geometry/functions agree.
Q_IN pin 4 (GATE): expected left-bottom contact; observed (-1.500,+0.975), Q_IN_GATE. Geometry/function agree.
Q_IN pins 5,6,7,8 (DRAIN): expected four right-side contacts and continuous exposed drain land, all electrically common; observed pad 5 DRAIN_COMMON on 12V_FUSED, with explicit fused aliases for 6–8. Manufacturer supports this identity fusion. Source=protected, drain=fused produces body-diode direction fused -> protected, consistent with an input protection rail path; gate uses a dedicated control net.
Q_IN pin 5 including aliases 6–8 (physical copper): expected the fused copper land to cover all four drain-contact sites; observed the table only supplies the pad-5 base rectangle, 1.71 x 2.37 mm at (+0.455,0), whose x extent is -0.400..+1.310 mm. The four outer features at x=+1.500, y=-0.975/-0.325/+0.325/+0.975 are inventoried as unnumbered paste/mechanical features, 0.7 x 0.42 mm, extending to x=+1.850. The alias prose says a composite copper pad includes the fingers, but no native custom copper primitives, copper outline, or equivalent native shape inventory is supplied. This is an evidence gap, not proof of absent copper. Needed fact: native numbered pad-5 copper geometry, including primitives/vertices and layer membership, demonstrating continuous copper reaching all four drain contacts. Do not use anonymous paste apertures alone as copper evidence.
The dossier's n/a winding is appropriate for the surviving numbered perimeter row 1–4: those points are collinear. Their individual ordering, pin-1 corner, and drain side agree with the manufacturer; the n/a statistic does not prove or disprove correct physical winding. The remaining QUESTION is the unresolved copper geometry above.

Q_PRE — VERDICT: PASS
Primary: AO3401A Rev. 3.1, SHA-256 0d8e3261ae280e007b5837fff60c55142f2d92af71edc4d02aee6f7a760a785c; PDF p.1 SOT23 Top View/Bottom View and equivalent MOSFET circuit (unnumbered figures). Page 5 was also inspected and is test circuits, not a package outline.
Measured inventory: 3 numbered native pad rows/identities, 3 physical terminal identities, no aliases, no unnumbered features, no EP. The figure labels functions rather than printing numeric 1/2/3; the dot identifies the gate-side corner. The functional top-view geometry directly establishes gate/source/drain assignments without assuming pin numbering from the dossier.
Manufacturer top view normalized by rotation: gate at upper-left marked corner, source lower-left, drain alone at right-middle. G/S/D traverse CCW. Observed pins 1/2/3 occupy exactly those positions and functions. Signed polygon area in the +y-down frame is -1.78125 mm² (CCW). The dossier's N/S side tags for pins 1/2 reflect their slightly larger |y| than |x|; both are geometrically the paired left column.
Q_PRE pin 1 (G): expected marked gate contact; observed (-0.9375,-0.9500), PRE_GATE.
Q_PRE pin 2 (S): expected other paired contact; observed (-0.9375,+0.9500), 5V_LDO_FEED.
Q_PRE pin 3 (D): expected single opposite contact; observed (+0.9375,0), 5V_LDO_HOLD.
Source feed, drain hold, and dedicated gate net are electrically plausible for a P-channel supply switch. Body diode points HOLD -> FEED. This pin review does not assert operating voltages or off-state isolation requirements absent from the packet.
Front mounting and native rotation 180 degrees correctly transform all three local pads to the recorded board-front coordinates; there is no mirror. Q_IN rotation 0 also checks exactly.

Instance symmetry: one instance of each package is commissioned; no same-part pair exists. Both use distinct gate nets and rail source/drain nets. Q_IN's opposite rail naming/order versus Q_PRE is consistent with input protection versus feed switching and does not swap package identities. No symmetry defect was found within supplied evidence.

Method: verified all seven envelope input sizes/hashes before and after; rendered actual primary PDF pages with bounded pdftoppm; viewed all four retained images; recorded manufacturer derivation before opening native dossiers; parsed/count-checked every native pad row and alias, and checked local-to-native transforms. No live project, schematic, historical review, other datasheet, or subagent was used. Raw scripts, logs/runtime receipts, inspected images, native dossiers, protocol, task, envelope, measurements and exact primary hashes are archived. Full PDFs remain in the digest-bound frozen input packet.

Delivery checks PASS means complete honest handback of this limited INCOMPLETE review, not engineering acceptance. Resolve Q_IN physical copper evidence before promoting this group to SOUND.
