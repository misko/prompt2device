from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,io,sys
root=Path('/tmp/rj45-pin-carrier-power-fets-clockground1-fvaqfmmj'); s=Path(__file__).parent; out=s.parent/'outputs'
e=json.loads((s.parent/'envelope.json').read_text())
files={}
for item in e['input_packet']:
 p=root/item['path']
 if p.suffix!='.pdf': files['inputs/'+item['path']]=p.read_bytes()
files['inputs/envelope.json']=(s.parent/'envelope.json').read_bytes()
for p in s.iterdir():
 if p.is_file() and p.name not in {'package-final.log','package-final.runtime.json','preflight-final.log','preflight-final.runtime.json'}: files['review/'+p.name]=p.read_bytes()
for name in ('report.md','evidence.json','result.json'): files['outputs/'+name]=(out/name).read_bytes()
archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name); info.size=len(data); info.mtime=0; info.mode=0o644; tf.addfile(info,io.BytesIO(data))
members=[]; seen=set()
with tarfile.open(archive,'r:gz') as tf:
 for m in tf:
  assert m.isfile() and not m.issym() and not m.islnk(); p=PurePosixPath(m.name)
  assert not p.is_absolute() and '..' not in p.parts and m.name not in seen and not m.name.endswith('.tar.gz'); seen.add(m.name)
  data=tf.extractfile(m).read(); assert len(data)==m.size and data==files[m.name]
  members.append({'path':m.name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
b=archive.read_bytes(); manifest={'archive_sha256':hashlib.sha256(b).hexdigest(),'archive_size':len(b),'member_count':len(members),'members':members}
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='members'}))
