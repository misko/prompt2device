# Recorded canonical attempt

- qualify: rc=0, 18.579608s; full raw output execution.log
- normal: rc=2, 99.523494s; full raw output execution.log
- public-continuation: rc=1, 3.933209s; full raw output execution.log
- Authored input hashes: 593/593
- All generated identities are in execution.json.
- Stop at the last actual recorded gate. No routing or release acceptance.
