from pathlib import Path
from datetime import datetime,timezone,timedelta
import json,sys,hashlib,shutil,subprocess
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent
sys.path.insert(0,str(R/'skills/pcb-design/scripts'));sys.path.insert(0,str(R/'projects/crow-roof-array-v1/03_src'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
from prelayout_input_checkpoint import authored_census
retirement=json.loads((D/'channel-canonical-guard-retirement.json').read_text())
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R).strip(), 'Commit corrected source/failure boundary first'
for n in [r['path'] for r in retirement['retired']]+retirement['absent']:
 assert not (P/n).exists() and not (P/n).is_symlink(),n
# Previous normal attempt stopped before generation. Its exact output and
# retired guards are retained; no invented replacement checkpoint is allowed.
previous=json.loads(Path('/tmp/carrier-channel-canonical-opened.json').read_text())
assert json.loads(Path(previous['attempt']).read_text())['status']=='PASS'
ev=json.loads((Path(previous['output_dir'])/'evidence.json').read_text())
assert len(ev['runs'])==2 and ev['runs'][-1]['runtime']['returncode']==1
assert 'GATE FAILED [0f] M-BOUND' in (Path(previous['output_dir'])/'execution.log').read_text()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();now=datetime.now(timezone.utc);cut=now+timedelta(minutes=18);hard=now+timedelta(minutes=20);rid='channel-canonical-bound-'+now.strftime('%Y%m%dT%H%M%SZ');H=P/'06_build/handoffs'/rid;H.mkdir(parents=True);ep=P/'06_build/task_runs'/rid/'envelope.json'
shutil.copyfile(D/'channel_canonical_runner.py',H/'runner.py');shutil.copyfile('/tmp/carrier-keying-source-review-27x1olqz/preflight.py',H/'preflight.py')
(H/'runner-config.json').write_text(json.dumps({'envelope':str(ep),'work_cutoff':cut.isoformat()},indent=2)+'\n')
(H/'TASK.md').write_text(f'''# Fresh logged canonical attempt

Agent-role mechanical, economy/low effort; fresh context, no children. Exclusive live project writer; root is READ_ONLY until actual FINAL and closure. Source {head}. Read CLAUDE.md, pcb-design skill and supplied runner. Execute exactly:

/usr/bin/python3 {H}/runner.py

This prebuilt runner verifies frozen inputs and absence of the already-retired guards, runs native qualification, one normal conductor, and only the precise expected fresh J-PCBA-PRELAYOUT rc2 pause permits one public continuation. All subprocesses use bounded runtime and preserve complete raw stdout/stderr, actualargv/cwd/rc/times in allocated scratch AND required execution.log/execution.json. It stops at the first other gate. Do not edit the runner or source, repeat it, delete/restore guards, route, alter reviews, commit or substitute ad hoc commands.

ADR0027 fixed north channel map source has been independently reviewed and committed at the exact source HEAD above. Source336/336 tests passed and all applicable source contracts remain enforce-mode. Logical pods1..8 map to physicalADC4,3,2,1,5,6,7,8 while external connector pins, COTS image, clock/configuration mode, all south connectivity and physical component-pose set remain unchanged. Cat5e7939A harness/source authority is unchanged. Current source/input checkpoints and schematic reviews are stale for this electrical change and must renew. The old generated guards were retired only after exact archive/companion reopening and source commit. The retirement record and closed failed attempt remain supplied by root. First canonical attempt stopped at M-BOUND before generation; only ADR0027 gained a typed ESTIMATED declaration of the unchanged1mm target. Full fleet bound gate now passes; source336/336 remains applicable because no executable electrical source changed. This new normal attempt retains that failure and never restores retired guards. No receipt exists. ADR0026 public distributor prelayout authority remains approved under userD7, and ADR0007 still separates design release from physical qualification. Stop at actual canonical PR-REVIEW. No source changes, route attempt, promotion, order or release authority in this task. Existing3/3spent north corridor history is unchanged.

After runner returns, inspect report, execution.json and tail of execution.log. Do not diagnose or fix unexpected engineering gates. Run mandatory delivery/writer preflight:
/usr/bin/python3 {H}/preflight.py {ep}

Deliver actual FINAL with exact last gate, childrc/duration and outputpaths. Runner creates required report.md,evidence.json,execution.log,execution.json,result.json. If runner itself fails, retain actual outputs and report INCOMPLETE; never fabricate a log/check. You may correct packaging only if source/runtime facts are retained; no change to original runtime/runner evidence. Work/FINAL cutoff{cut.isoformat()}, hardclose{hard.isoformat()}; reserve2minutes for preflight. Finish promptly after the first real gate. Send progress when the real run starts or stops.
''')
sources={R/key.removeprefix('repo:') for key in authored_census(P,R,[])}
for n in ['CLAUDE.md','skills/pcb-design/SKILL.md','skills/pcb-design/references/execution-runtime.md','skills/pcb-design/references/lifecycle-and-backtrack.md','skills/pcb-design/references/compute-tiers.md']:sources.add(R/n)
index={};inputs=[]
for p in sorted(sources):
 b=p.read_bytes();index[str(p)]=hashlib.sha256(b).hexdigest()
 if p.is_relative_to(P):inputs.append(p)
 else:
  target=H/'shared-source'/p.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
(H/'source-index.json').write_text(json.dumps(index,indent=2)+'\n');inputs.extend(p for p in H.rglob('*') if p.is_file());items=[]
for p in sorted(set(inputs)):
 b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(P).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
subject=subject_identity('channel_canonical_renewal',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())]);scope=sorted(['01_docs/STATUS.md','01_docs/journal/placement.md','03_tscircuit/build','03_tscircuit/dist','03_tscircuit/kicad','03_tscircuit/node_modules','03_tscircuit/verification','04_kicad','06_build'])
e=TaskEnvelope(schema=2,task_id=rid,stage_id='KICAD-SCHEMATIC',run_id=rid,subject=subject,executor='agent',execution_class='local',recommended_agent_role='mechanical',agent_role='mechanical',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=rid,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'EXCLUSIVE','paths':scope},output_path=f'06_build/task_runs/{rid}/attempt.json',completion={'outputs':sorted(['report.md','evidence.json','execution.log','execution.json']),'checks':sorted(['inputs-verified','raw-run-recorded','processes-closed'])})
o=open_agent_attempt(e,cwd=P);o.update(project=str(P),envelope=str(ep),task=str(H/'TASK.md'),preflight=str(H/'preflight.py'),work_cutoff=cut.isoformat(),agent_id='/root/carrier_channel_canonical_bound');Path('/tmp/carrier-channel-canonical-bound-opened.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2))
