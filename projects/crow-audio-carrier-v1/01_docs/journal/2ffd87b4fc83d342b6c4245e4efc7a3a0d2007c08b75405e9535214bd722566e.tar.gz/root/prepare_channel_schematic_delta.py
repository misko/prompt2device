from pathlib import Path
import sys,json,hashlib,subprocess,tempfile,shutil,tarfile,io
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';C=Path(__file__).parent;OLD=Path('/tmp/carrier-locator-schematic-delta-8r_8nxbc');D=Path(tempfile.mkdtemp(prefix='carrier-channel-schematic-delta-'));prev='f2675b431c4372a1a81d0fdfa0ca81f0a27ecd68';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();prefix=P.relative_to(R).as_posix()+'/'
def selected(n):return n.startswith(('02_parts/','03_src/')) or (n.startswith('03_tscircuit/') and not n.startswith(('03_tscircuit/build/','03_tscircuit/dist/','03_tscircuit/node_modules/','03_tscircuit/kicad/','03_tscircuit/verification/')))
def put(side,n,b):p=D/side/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
for side,rev in [('previous',prev),('current',head)]:
 payload=subprocess.check_output(['git','archive','--format=tar',rev,'--',prefix+'02_parts',prefix+'03_src',prefix+'03_tscircuit'],cwd=R,timeout=60)
 with tarfile.open(fileobj=io.BytesIO(payload)) as tar:
  for m in tar:
   if m.isfile() and m.name.startswith(prefix):
    n=m.name[len(prefix):]
    if selected(n):put(side,n,tar.extractfile(m).read())
archive=P/'01_docs/journal/f0bcccf4e9bf07972c142c530e11e4ca5a864dbf28f5a5b8b34f7ff8414ac337.tar.gz'
raw=['03_tscircuit/build/circuit.json','03_tscircuit/build/schematic.pdf','04_kicad/crow_audio_carrier_v1.kicad_sch','06_build/netlists/crow_audio_carrier_v1.net']
with tarfile.open(archive) as t:
 manifest=json.loads(t.extractfile('MANIFEST.json').read())['members']
 for n in raw:
  b=t.extractfile(n).read();assert hashlib.sha256(b).hexdigest()==manifest[n]['sha256'];put('previous',n,b);put('current',n,(P/n).read_bytes())
 for n in ['08_reviews/pre-route_topology.md','08_reviews/pre-route_schematic_render.md']:put('prior-accepted',Path(n).name,t.extractfile(n).read())
for side,root in [('previous',Path('/tmp/carrier-channel-source-review-65wvio93/project')),('current',P)]:
 n='06_build/netlists/net_aliases.txt'
 if (root/n).is_file():put(side,n,(root/n).read_bytes())
for folder in ['authority','external_hardware','method']:
 shutil.copytree(OLD/folder,D/folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
shutil.copyfile(OLD/'preflight.py',D/'preflight.py')
for n in ['CLAUDE.md','skills/kicad-pcb/scripts/pre_route_review_check.py','skills/jlcpcb-fab/scripts/assembly_locator_check.py','skills/jlcpcb-fab/references/assembly-and-order.md']:
 put('authority',n,(R/n).read_bytes())
put('source-witnesses','cat-harness-review.md',(P/'08_reviews/2026-09-12_827e7b96_independent_harness.md').read_bytes())
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 for n in ['connector_assembly_contract.json','connector_assembly_source_gate.json','connector_assembly_full_gate.json']:
  put('source-witnesses',slug+'/'+n,(R/'projects'/slug/'06_build/verification'/n).read_bytes())
put('source-witnesses','cat-harness-adr.md',(R/'projects/crow-roof-array-v1/01_docs/decisions/0012-cat5e-pod-harness.md').read_bytes())
correction=json.loads((C/'channel-source-correction-opened.json').read_text())[0]
for n in ['report.md','evidence.json','evidence-manifest.json']:
 put('source-witnesses','channel-source-correction/'+n,(Path(correction['output_dir'])/n).read_bytes())
for n in ['01_docs/decisions/0027-fixed-north-adc-channel-map.md','01_docs/ARCHITECTURE.md','01_docs/FIRST_ARTICLE_TEST_PLAN.md','01_docs/BRIEF.md']:
 put('current',n,(P/n).read_bytes())
 put('previous',n,subprocess.check_output(['git','show',prev+':'+prefix+n],cwd=R)) if n!='01_docs/decisions/0027-fixed-north-adc-channel-map.md' else None
def inventory(side):return {p.relative_to(D/side).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (D/side).rglob('*') if p.is_file()}
a,b=inventory('previous'),inventory('current');changes=[{'path':n,'previous_sha256':a.get(n),'current_sha256':b.get(n)} for n in sorted(a.keys()|b.keys()) if a.get(n)!=b.get(n)];(D/'changes.json').write_text(json.dumps(changes,indent=2)+'\n')
sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'));import pre_route_review_check as g
parts=sorted((P/'02_parts').glob('*/part.yaml'));bindings={'source_commit':head,'previous_source_commit':prev,'netlist_sha256':g.netlist_digest(P/raw[-1]),'parts_sha256':hashlib.sha256(b''.join(p.relative_to(P).as_posix().encode()+b'\0'+p.read_bytes()+b'\0' for p in parts)).hexdigest(),'design_rules_sha256':g.design_rules_digest(P),'packet_counts':{'previous':len(a),'current':len(b),'changed':len(changes)}};(D/'bindings.json').write_text(json.dumps(bindings,indent=2)+'\n');(C/'channel-schematic-delta-prepared.json').write_text(json.dumps({'root':str(D),'bindings':bindings},indent=2)+'\n');print(json.dumps({'root':str(D),'bindings':bindings},indent=2))
