review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_j9_complete1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 92a4e2fc0fecde845f2dfa0d9e2f5bfbd943372962fb449d699a98d957fc5633
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: 7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c
dossier_sha256: a7a3e19592980956624633e6b24a729f5b7209c0305eac2f0f45253519a6e2e1
datasheet_sha256: b8942b95bc3fe4c02171de9e714d99b2688055e249ba1524e3c2a8c3cf78eaa3

# J9 independent pin review

J9 VERDICT: PASS

Measured native feature counts: 2 numbered pads; 1 unnumbered mechanical feature.

Primary document: Molex `SD-43650-001`, revision D8, sheet 1 of 1, SHA-256 `b8942b95bc3fe4c02171de9e714d99b2688055e249ba1524e3c2a8c3cf78eaa3`. Inspected figure: `PCB LAYOUT: 2 CKT`, explicitly labeled `PCB LAYOUT: COMPONENT SIDE`, rendered at 200 dpi.

Manufacturer expected facts:

- Material number 43650-0200 is the 2-circuit member of the 43650 right-angle through-hole header family.
- The component-side 2-circuit PCB layout contains two signal-tail holes on 3.00 mm pitch and one 3.00 mm-diameter retention hole centered between them.
- The signal-hole-to-retention-hole separation is 4.32 mm. In the printed orientation, the retention hole is below the signal pair and Circuit 1 is the right signal hole.
- The drawing assigns circuit identity but no voltage, ground, or polarity function to either circuit.

Native observed facts:

- The dossier explicitly states a front mount and COMPONENT-TOP coordinates with +x right and +y down. Its complete native inventory contains pad 1 at (0.00, 0.00), pad 2 at (3.00, 0.00), and one 3.00 mm NPTH retention feature at (1.50, -4.32).
- Rotating the manufacturer's component-side 2-circuit layout by 180 degrees places its retention hole above the signal pair and maps manufacturer Circuit 1 to dossier pad 1 at the left. This is a rotation-only match; no mirror is applied.
- Numbered feature count and pitch match: two numbered pads, 3.00 mm apart. The single unnumbered feature matches the manufacturer's one centered 3.00 mm retention hole at the specified 4.32 mm offset.
- Native pad 1 carries part function `+12V_IN` and board net `12V_IN`; native pad 2 carries part function `GND` and board net `GND`. These are electrically sane connector assignments and preserve the intended function-to-net mapping on the manufacturer-proved physical circuit identities.

Finding: `J9 pin 1 (+12V_IN): manufacturer Circuit 1 is the signal hole opposite Circuit 2 across the centered retention datum; after a 180-degree rotation it is native pad 1, and the dossier shows 12V_IN.`

Finding: `J9 pin 2 (GND): manufacturer Circuit 2 is the other signal hole; after the same rotation it is native pad 2, and the dossier shows GND.`

The PASS is limited to J9 pin identity, native feature inventory, and function-to-net sanity. `DO-NOT-ORDER` remains because this review is not whole-board acceptance and does not establish cable fit or first-article acceptance.
