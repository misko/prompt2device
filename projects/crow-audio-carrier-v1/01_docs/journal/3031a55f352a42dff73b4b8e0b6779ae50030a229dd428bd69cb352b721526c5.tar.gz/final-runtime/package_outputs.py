#!/usr/bin/python3
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import tarfile

root = Path("/tmp/rj45-pin-carrier-logic-toponly1-9dj_7_tw")
run = root / "06_build/task_runs/rj45-pin-carrier-logic-toponly1"
scratch = run / "scratch"
outputs = run / "outputs"
evidence_root = scratch / "evidence-archive"

def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def verify_inputs():
    envelope = json.loads((run / "envelope.json").read_text())
    rows = []
    for item in envelope["input_packet"]:
        path = root / item["path"]
        actual_hash = digest(path)
        actual_size = path.stat().st_size
        passed = actual_hash == item["sha256"] and actual_size == item["size"]
        rows.append({
            "path": item["path"],
            "expected_sha256": item["sha256"],
            "actual_sha256": actual_hash,
            "expected_size": item["size"],
            "actual_size": actual_size,
            "status": "PASS" if passed else "FAIL",
        })
    if any(row["status"] != "PASS" for row in rows):
        raise RuntimeError("input verification failed")
    return {"status": "PASS", "count": len(rows), "inputs": rows}

if evidence_root.exists():
    shutil.rmtree(evidence_root)
(evidence_root / "dossiers").mkdir(parents=True)
(evidence_root / "figures").mkdir()
(evidence_root / "runtime").mkdir()

before = verify_inputs()
(evidence_root / "input-verification-before.json").write_text(json.dumps(before, indent=2, sort_keys=True) + "\n")
shutil.copy2(scratch / "methods.md", evidence_root / "methods.md")
shutil.copy2(root / "pin-review-protocol.md", evidence_root / "pin-review-protocol.md")
for path in sorted((root / "dossiers").glob("*.md")):
    shutil.copy2(path, evidence_root / "dossiers" / path.name)
for path in sorted((scratch / "figures").glob("*.png")):
    shutil.copy2(path, evidence_root / "figures" / path.name)
runtime_logs = sorted((scratch / "runtime").glob("*.log"))
current_runtime_log = runtime_logs[-1] if runtime_logs else None
for path in runtime_logs:
    # The runtime allocates monotonically named logs; the newest is this open packaging run.
    if path != current_runtime_log:
        shutil.copy2(path, evidence_root / "runtime" / path.name)
shutil.copy2(outputs / "report.md", evidence_root / "report.md")
shutil.copy2(outputs / "evidence.json", evidence_root / "evidence.json")

after = verify_inputs()
(evidence_root / "input-verification-after.json").write_text(json.dumps(after, indent=2, sort_keys=True) + "\n")

members = []
seen = set()
for path in sorted(evidence_root.rglob("*")):
    info = path.lstat()
    if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
        if path.is_dir() and not path.is_symlink():
            continue
        raise RuntimeError(f"non-regular archive member: {path}")
    rel = path.relative_to(evidence_root).as_posix()
    pure = PurePosixPath(rel)
    if pure.is_absolute() or any(part in ("", ".", "..") for part in pure.parts) or rel in seen:
        raise RuntimeError(f"unsafe or duplicate archive member: {rel}")
    seen.add(rel)
    members.append({"path": rel, "size": info.st_size, "sha256": digest(path)})

archive_tmp = outputs / ".evidence.tar.gz.tmp"
with tarfile.open(archive_tmp, "w:gz", format=tarfile.PAX_FORMAT) as archive:
    for member in members:
        archive.add(evidence_root / member["path"], arcname=member["path"], recursive=False)

with tarfile.open(archive_tmp, "r:gz") as archive:
    names = archive.getnames()
    if names != [m["path"] for m in members] or len(names) != len(set(names)):
        raise RuntimeError("archive member census mismatch")
    for expected in members:
        info = archive.getmember(expected["path"])
        if not info.isfile() or info.issym() or info.islnk():
            raise RuntimeError(f"archive member is not a regular file: {expected['path']}")
        stream = archive.extractfile(info)
        if stream is None:
            raise RuntimeError(f"cannot reopen archive member: {expected['path']}")
        data = stream.read()
        if len(data) != expected["size"] or hashlib.sha256(data).hexdigest() != expected["sha256"]:
            raise RuntimeError(f"archive member digest mismatch: {expected['path']}")

archive_path = outputs / "evidence.tar.gz"
os.replace(archive_tmp, archive_path)
manifest = {
    "schema": 1,
    "archive_sha256": digest(archive_path),
    "archive_size": archive_path.stat().st_size,
    "member_count": len(members),
    "members": members,
}
(outputs / "evidence-manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")

result = {
    "subject": {
        "raw_sha256": "d9539d339f09d59accb29e2db159ab3a3f4f725903083c922214f0b240c3ce51",
        "semantic_sha256": "33bbd2f1a1ab6b55ed13eb17a1cc99a0c00a157bbbf3f244a5caf7b6001c34e6",
    },
    "checks": {
        "inputs-verified": "PASS",
        "review-complete": "PASS",
        "evidence-complete": "PASS",
    },
    "unresolved": [],
}
(outputs / "result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps({"archive": str(archive_path), "manifest": manifest, "result": result}, sort_keys=True))
