review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 92a4e2fc0fecde845f2dfa0d9e2f5bfbd943372962fb449d699a98d957fc5633
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: 7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c

# Fresh independent pin review — carrier-logic

Coverage is limited to commissioned refs `U_DUMP`, `U_LDO_EN`, `U_OE`, `U_TDM`, and `U_TDM_SCH`. This is not whole-board acceptance. All five commissioned refs passed; no unresolved finding remains. `DO-NOT-ORDER` is retained because this is a limited pre-route review rather than an order release.

## U_DUMP

VERDICT: PASS

Measured native pad identities: 5. Measured physical pin identities: 5. Exposed pads: 0 expected, 0 observed. Declared aliases/fused identities: 0.

Primary document: SHA-256 `b8f37c700d0fc8374de6d14f0e2caf310c34b480ffab9d63c69bb3b6defbebbf`, PDF page 3, GV/SOT753 top-view figure `aaa-035749` and Table 3.

- U_DUMP pins 1–5 (NC,A,GND,Y,VCC): expected top-view pin 1 upper-left and CCW order 1/2/3 west, 4/5 east; observed dossier is front-mounted, component-top, CCW, with exactly those sides and individual identities.
- U_DUMP pin 1 (NC): expected no functional net; observed dedicated unconnected net.
- U_DUMP pin 2 (A): expected signal input; observed `DUMP_RC`.
- U_DUMP pin 3 (GND): expected ground; observed `GND`.
- U_DUMP pin 4 (Y): expected inverter output; observed `DUMP_GATE`.
- U_DUMP pin 5 (VCC): expected supply rail; observed `5V_LDO_HOLD`.

## U_LDO_EN

VERDICT: PASS

Measured native pad identities: 5. Measured physical pin identities: 5. Exposed pads: 0 expected, 0 observed. Declared aliases/fused identities: 0.

Primary document: SHA-256 `b8f37c700d0fc8374de6d14f0e2caf310c34b480ffab9d63c69bb3b6defbebbf`, PDF page 3, GV/SOT753 top-view figure `aaa-035749` and Table 3.

- U_LDO_EN pins 1–5 (NC,A,GND,Y,VCC): expected top-view pin 1 upper-left and CCW order 1/2/3 west, 4/5 east; observed dossier is front-mounted, component-top, CCW, with exactly those sides and individual identities.
- U_LDO_EN pin 1 (NC): expected no functional net; observed dedicated unconnected net.
- U_LDO_EN pin 2 (A): expected signal input; observed `DUMP_GATE`.
- U_LDO_EN pin 3 (GND): expected ground; observed `GND`.
- U_LDO_EN pin 4 (Y): expected inverter output; observed `LDO_EN`.
- U_LDO_EN pin 5 (VCC): expected supply rail; observed `5V_LDO_HOLD`.

## U_OE

VERDICT: PASS

Measured native pad identities: 5. Measured physical pin identities: 5. Exposed pads: 0 expected, 0 observed. Declared aliases/fused identities: 0.

Primary document: SHA-256 `b8f37c700d0fc8374de6d14f0e2caf310c34b480ffab9d63c69bb3b6defbebbf`, PDF page 3, GV/SOT753 top-view figure `aaa-035749` and Table 3.

- U_OE pins 1–5 (NC,A,GND,Y,VCC): expected top-view pin 1 upper-left and CCW order 1/2/3 west, 4/5 east; observed dossier is front-mounted, component-top, CCW, with exactly those sides and individual identities.
- U_OE pin 1 (NC): expected no functional net; observed dedicated unconnected net.
- U_OE pin 2 (A): expected signal input; observed `TDM_SENSE_G`.
- U_OE pin 3 (GND): expected ground; observed `GND`.
- U_OE pin 4 (Y): expected inverter output; observed `TDM_OE_N`.
- U_OE pin 5 (VCC): expected supply rail; observed `3V3_ADC`.

The three 74LVC1G14 instances are symmetric by pin role and net kind: pin 1 NC/unconnected, pin 2 signal input, pin 3 ground, pin 4 signal output, and pin 5 supply rail on every instance.

## U_TDM

VERDICT: PASS

Measured native pad identities: 5. Measured physical pin identities: 5. Exposed pads: 0 expected, 0 observed. Declared aliases/fused identities: 0.

Primary document: SHA-256 `65afa3f9d879b37cb8be507caf84804b24bceeb2e0782ba449fff72160994e4c`, PDF page 3, section/figure `4 Pin Configuration and Functions`, `DBV PACKAGE (TOP VIEW)`, and Pin Functions table.

- U_TDM pins 1–5 (OE_N,A,GND,Y,VCC): expected top-view pin 1 upper-left and CCW order 1/2/3 west, 4/5 east; observed dossier is front-mounted, component-top, CCW, with exactly those sides and individual identities.
- U_TDM pin 1 (OE_N): expected active-low output-enable control input; observed `TDM_OE_N`.
- U_TDM pin 2 (A): expected data input; observed `TDM_CLEAN`.
- U_TDM pin 3 (GND): expected ground; observed `GND`.
- U_TDM pin 4 (Y): expected tri-state data output; observed `TDM_BUFFERED`.
- U_TDM pin 5 (VCC): expected supply rail; observed `3V3_ADC`.

## U_TDM_SCH

VERDICT: PASS

Measured native pad identities: 5. Measured physical pin identities: 5. Exposed pads: 0 expected, 0 observed. Declared aliases/fused identities: 0.

Primary document: SHA-256 `3db133d57486306950ba1140ac13a8a0ea95509dcefb88db36c08423a819b163`, PDF page 3, GV/SOT753 top-view figure `aaa-035749` and Table 3.

- U_TDM_SCH pins 1–5 (NC,A,GND,Y,VCC): expected top-view pin 1 upper-left and CCW order 1/2/3 west, 4/5 east; observed dossier is front-mounted, component-top, CCW, with exactly those sides and individual identities.
- U_TDM_SCH pin 1 (NC): expected no functional net; observed dedicated unconnected net.
- U_TDM_SCH pin 2 (A): expected signal input; observed `TDM_RAW`.
- U_TDM_SCH pin 3 (GND): expected ground; observed `GND`.
- U_TDM_SCH pin 4 (Y): expected buffer output; observed `TDM_CLEAN`.
- U_TDM_SCH pin 5 (VCC): expected supply rail; observed `3V3_ADC`.
