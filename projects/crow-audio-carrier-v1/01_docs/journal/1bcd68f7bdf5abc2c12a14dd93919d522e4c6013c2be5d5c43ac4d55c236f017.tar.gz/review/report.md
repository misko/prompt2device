review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 92a4e2fc0fecde845f2dfa0d9e2f5bfbd943372962fb449d699a98d957fc5633
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: 7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c

# Fresh independent pin review — carrier-esd

Limited coverage: only U_ESD1, U_ESD2, U_ESD3, U_ESD4, U_ESD5, U_ESD6, U_ESD7, and U_ESD8 were commissioned and reviewed. This is not whole-board acceptance. The required order verdict remains DO-NOT-ORDER.

Primary document: Texas Instruments, *TPD2E2U06 Dual-Channel High-Speed ESD Protection*, SLLSEG9C, SHA-256 `a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed`. The decisive figure is PDF page 3, “DRL Package, 5-Pin SOT, Top View,” with the adjacent Pin Functions table. PDF page 17, DRL0005A package outline, independently confirms five physical leads, the pin-1 identification area, and absence of an exposed pad.

Independent expected facts derived from the rendered figures before dossier comparison: DRL is a five-lead package with no exposed pad; top-view pin 1 is upper-left, pins 2 and 3 continue downward on the left, pin 4 is lower-right, and pin 5 is upper-right. Thus the top-view winding is CCW. Functions are 1=NC, 2=NC, 3=IO1, 4=GND, 5=IO2. IO1 and IO2 form the protected channel and may be used on either side; pin 4 must be ground. The datasheet permits NC pins to float, be grounded, or connect to VCC.

| Ref | VERDICT | Native pads | Physical identities | EP | Declared aliases | Expected vs observed |
|---|---|---:|---:|---:|---:|---|
| U_ESD1 | PASS | 5 | 5 | 0 | 0 | Front-mounted component-top table is CCW with 1/2/3 on W and 4/5 on E; 1,2 are unconnected, 3=IO1/AUDIO_P1, 4=GND/GND, 5=IO2/AUDIO_N1. |
| U_ESD2 | PASS | 5 | 5 | 0 | 0 | Same physical/function pattern; AUDIO_P2 and AUDIO_N2 occupy IO1 and IO2; GND is correct. |
| U_ESD3 | PASS | 5 | 5 | 0 | 0 | Same physical/function pattern; AUDIO_P3 and AUDIO_N3 occupy IO1 and IO2; GND is correct. |
| U_ESD4 | PASS | 5 | 5 | 0 | 0 | Same physical/function pattern; AUDIO_P4 and AUDIO_N4 occupy IO1 and IO2; GND is correct. |
| U_ESD5 | PASS | 5 | 5 | 0 | 0 | Same physical/function pattern; AUDIO_P5 and AUDIO_N5 occupy IO1 and IO2; GND is correct. |
| U_ESD6 | PASS | 5 | 5 | 0 | 0 | Same physical/function pattern; AUDIO_P6 and AUDIO_N6 occupy IO1 and IO2; GND is correct. |
| U_ESD7 | PASS | 5 | 5 | 0 | 0 | Same physical/function pattern; AUDIO_P7 and AUDIO_N7 occupy IO1 and IO2; GND is correct. |
| U_ESD8 | PASS | 5 | 5 | 0 | 0 | Same physical/function pattern; AUDIO_P8 and AUDIO_N8 occupy IO1 and IO2; GND is correct. |

All eight instances preserve the same per-pin kind: pins 1 and 2 are unconnected NC placeholders, pin 3 is an AUDIO_Px signal on IO1, pin 4 is GND, and pin 5 is an AUDIO_Nx signal on IO2. No pairwise instance divergence, fused identity, alias, missing pad, extra pad, or exposed-pad obligation was observed.

