from pathlib import Path
import json,hashlib,tarfile,io,sys,subprocess,shutil
D=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';j=json.loads((D/'source-corridor-opened.json').read_text())[0];Q=Path(j['project']);sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/pcb-design/scripts'));from pipeline_execution import TaskEnvelope,verify_input_packet
sha=lambda b:hashlib.sha256(b).hexdigest();e=TaskEnvelope.from_json(Path(j['envelope']).read_text());a=json.loads(Path(j['attempt']).read_text());assert a['status']=='PASS' and verify_input_packet(e,Q)[0]
files={};refs={};seen={};commit='b436d612c8d2d325204ebd253f4c885bd66943ee'; tracked=set(subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0'))
def add(n,p):
 b=p.read_bytes();h=sha(b);rel=p.relative_to(Q).as_posix() if p.is_relative_to(Q) else ''
 gp='projects/crow-audio-carrier-v1/'+rel[len('project/'):] if rel.startswith('project/') else rel[len('authority/current/'):] if rel.startswith('authority/current/') else None
 if gp in tracked:
  old=subprocess.check_output(['git','show',commit+':'+gp],cwd=R)
  if sha(old)==h:refs[n]={'git_commit':commit,'path':gp,'sha256':h,'size':len(b)};return
 if h in seen:refs[n]={'archive_member':seen[h],'sha256':h,'size':len(b)}
 else:files[n]=p;seen[h]=n
for x in e.input_packet:add('inputs/'+x.path,Q/x.path)
for p in Path(j['attempt']).parent.rglob('*'):
 if p.is_file() and p.name!='.closing':add('runtime/'+p.relative_to(Path(j['attempt']).parent).as_posix(),p)
for n in ['source-corridor-opened.json','source-corridor-reopening.json','preserve_source_corridor.py','live-fix-binding.json','commission_placement_change.py']:add('root/'+n,D/n)
(D/'source-corridor-references.json').write_text(json.dumps(refs,indent=2)+'\n');files['root/source-corridor-references.json']=D/'source-corridor-references.json'
m={n:{'size':p.stat().st_size,'sha256':sha(p.read_bytes())} for n,p in files.items()};tmp=D/'source-corridor-preserved.tar.gz'
with tarfile.open(tmp,'w:gz',compresslevel=3) as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
 b=(json.dumps({'members':m},indent=2)+'\n').encode();x=tarfile.TarInfo('MANIFEST.json');x.size=len(b);t.addfile(x,io.BytesIO(b))
h=sha(tmp.read_bytes());out=P/'01_docs/journal'/(h+'.tar.gz');assert not out.exists();shutil.copyfile(tmp,out)
with tarfile.open(out) as t:
 assert set(t.getnames())==set(m)|{'MANIFEST.json'}
 for n,x in m.items():b=t.extractfile(n).read();assert sha(b)==x['sha256'] and len(b)==x['size']
r={'archive':str(out),'sha256':h,'size':out.stat().st_size,'members':len(m),'references':len(refs),'inputs':len(e.input_packet)};(D/'source-corridor-preservation-result.json').write_text(json.dumps(r,indent=2)+'\n')
with (P/'01_docs/journal/contracts.md').open('a') as f:f.write(f'\n## Allowed fixed-pose source corridor comparison evidence\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Closed source hypothesis: 87 clearance failures and 8 pair-spread failures, full native geometry and measurements, exact Git preimages, no source adoption or routed acceptance; reopen MANIFEST and references |\n')
print(json.dumps(r,indent=2))
