from pathlib import Path
import sys,os,json,shutil,hashlib
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
N=Path(__file__).parent
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
S=Path('/tmp/rj45-coherent-top-only-source1-dz0edoky/06_build/task_runs/rj45-coherent-top-only-source1/scratch')
Q=N/'candidate4-root-qualification'
assert not Q.exists()
shutil.copytree(S/'nongeometry-followup/work',Q,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
manifest=json.loads((S/'nongeometry-followup/manifest.json').read_text())
P=Q/'projects/crow-audio-carrier-v1'
for row in manifest['files']:
 assert hashlib.sha256((P/row['path']).read_bytes()).hexdigest()==row['after_sha256']
env=dict(os.environ)
env.update(PYTHONDONTWRITEBYTECODE='1',CIRCUITS_ROOT=str(Q),GIT_DIR=(R/'.git').read_text().strip().split(': ',1)[1],KICAD10_FOOTPRINT_DIR='/usr/share/kicad/footprints',KICAD10_3DMODEL_DIR='/home/mouse9911/.local/share/kicad/10.0/3dmodels')
before={str(p.relative_to(Q)):hashlib.sha256(p.read_bytes()).hexdigest() for p in Q.rglob('*') if p.is_file()}
cmd=['/usr/bin/python3','-B','-m','unittest','-v','test_check_spoke_implementation','test_rj45_entry_paths','test_ground_connections','test_package_clearances','test_adc_channel_map','test_adc_feed_invariants','test_thermal_source']
result=run_stage({'id':'candidate4-root-composed-tests','work_class':'local','timeout_s':180},cmd,log_path=N/'candidate4-root-composed-tests.log',cwd=P/'03_src/tests',env=env,console_line_limit=25)
(N/'candidate4-root-composed-tests-runtime.json').write_text(json.dumps(result.to_mapping(),indent=2)+'\n')
changed=[rel for rel,h in before.items() if not (Q/rel).is_file() or hashlib.sha256((Q/rel).read_bytes()).hexdigest()!=h]
assert not changed,changed
(N/'candidate4-root-composed-tests-integrity.json').write_text(json.dumps({'files_unchanged':len(before),'overlay':manifest,'runtime':result.to_mapping()},indent=2)+'\n')
raise SystemExit(result.returncode)
