from pathlib import Path
import json,hashlib,tarfile,shutil,datetime
p=Path('/tmp/rj45-candidate5-thermal-dback1-v8m9c3l0');run=p/'06_build/task_runs/rj45-candidate5-thermal-dback1';s=Path(__file__).parent;o=run/'outputs';o.mkdir(exist_ok=True);e=json.loads((run/'envelope.json').read_text())
assert len(json.loads((s/'inputs-before.json').read_text()))==1271
assert all(x['ok'] for x in json.loads((s/'inputs-after.json').read_text()))
findings=[dict(id='NATIVE-THERMAL',severity='blocking',status='DEFECTIVE',finding='Actual candidate5 owning placement refusal: inherited target thermal, min2/actual1; no prep or later stage run.'),dict(id='CONTOUR-CAUSE',status='SOUND',finding='Unchanged filled pad has no zone contact; half-gap checker contour meets island10 at two exact points (90.394,72.06),(90.646,72.06), counted as1.'),dict(id='SOURCE-COMPOSITION',status='SOUND',finding='Exact final five-file composition; correct partial20 all preserved; final23 GREEN and separate focused38 GREEN, actual old-west and old-helper RED.'),dict(id='UPSTREAM-MODE-BOUNDARY',status='DEFECTIVE',finding='Native NONE can express intended dedicated return, but generator consumes only full/thermal and project override census assumes32full. Representation and exact mode qualification needed before implementation/native admission.'),dict(id='ROUTING-OBLIGATIONS',status='OPEN',finding='All499 same-net opens retained, including19GND; all native seed/via return paths absent at track-free placement. Source cuts remain future required proof.'),dict(id='FIVE-ATTEMPTS',status='RETAINED',finding='Five spent attempts, no pending or sixth trial, no routing pilot, no release/assembly/orientation acceptance.') ]
methods=[dict(name=f.name,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in sorted(s.rglob('*.py')) if 'work' not in f.relative_to(s).parts]
evidence=dict(schema=1,subject=e['subject'],verdict='DEFECTIVE',source_composition_verdict='SOUND',review_complete=True,methods=methods,findings=findings,measured_counts=dict(inputs_before=1271,inputs_after=1271,input_archives_reopened=25,raw_rows=500,starved_thermal=1,unconnected=499,ground_unconnected=19,other_unconnected=480,schematic_parity=0,unknown_raw_endpoints=0,native_rule_areas=83,native_zones=4,adc2_region_vertices=50,native_tracks_and_vias=0,all_ground_pads=234,inherited_ground_pads=201,full_ground_pads=33,source_full_targets=32,vmid_coupled_pads=7,adc2_affected_pads=4,filled_FCu_islands=11,filled_each_other_layer_islands=10,ground_graph_nodes=400,ground_graph_edges=647,original_methods_preserved=20,final_route_green=23,focused_green=38,shape_red_assertions=1,west_red_methods=2,west_red_assertion_records=3,attempts_spent=5,pending_attempts=0),native_subject_sha256='5c4174c313f3864ae242d75d50cfeae81f617aee8673f0dfef8454bccf906a16',supported_next_decision='Own and qualify explicit exact-pad no-zone connection representation while preserving dedicated return reservations, source seeds/vias and minimum2/globalfloors; no implementation or candidate6 admitted.',untested_alternatives=['Native changed none-mode board result','Strict positive contour-separation geometry and tolerance margin'],limits=['No source/live writes, commits, children, BOARD construction, Save, changed-setting trial, generation, prep or router','No routed return, assembly, human orientation, thermal/current or release acceptance'],official_sources=json.loads((s/'exact-official-sources.json').read_text())+[json.loads((s/'checker-source.json').read_text())])
(o/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n');shutil.copy2(s/'report-draft.md',o/'report.md');(o/'result.json').write_text(json.dumps(dict(subject=e['subject'],checks={x:'PASS' for x in e['completion']['checks']},unresolved=[]),indent=2)+'\n')
entries=[]
for f in sorted(s.rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(s)
 if f.suffix in ['.gz','.pyc'] or any(x in ['__pycache__'] for x in rel.parts):continue
 if f.name.startswith(('package.log','package-runtime','preflight-')):continue
 entries.append(('review/'+str(rel),f))
for root in ['native','current-handoff','root-test-supplement','source-delivery','upstream-decision','partial-proposal/delivery']:
 for f in sorted((p/root).rglob('*')):
  if f.is_file() and not f.name.endswith('.tar.gz'):entries.append(('frozen/'+str(f.relative_to(p)),f))
entries.extend([('frozen/TASK.md',p/'TASK.md'),('frozen/envelope.json',run/'envelope.json'),('handback/report.md',o/'report.md'),('handback/evidence.json',o/'evidence.json')])
records=[];seen=set();archive=o/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,f in entries:
  assert name not in seen and not f.is_symlink();seen.add(name);b=f.read_bytes();records.append(dict(path=name,size=len(b),sha256=hashlib.sha256(b).hexdigest()));t.add(f,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
 actual=t.getmembers();assert len(actual)==len(records);lookup={x['path']:x for x in records};seen=set()
 for item in actual:
  path=Path(item.name);assert item.isfile() and not path.is_absolute() and '..' not in path.parts and item.name not in seen and not item.name.endswith('.tar.gz');seen.add(item.name);b=t.extractfile(item).read();r=lookup[item.name];assert len(b)==r['size'] and hashlib.sha256(b).hexdigest()==r['sha256']
b=archive.read_bytes();manifest=dict(schema=1,archive_sha256=hashlib.sha256(b).hexdigest(),archive_size=len(b),member_count=len(records),members=records);(o/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k!='members'}));print('Exactly five outputs; every archive member reopened, hashed and checked safe.')
