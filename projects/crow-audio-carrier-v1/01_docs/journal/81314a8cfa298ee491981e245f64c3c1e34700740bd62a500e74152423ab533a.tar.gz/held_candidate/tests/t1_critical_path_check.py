#!/usr/bin/env python3
"""Shared short-path/prefix proof: native saved text and hostile topology.

The pod's original policy fixtures also run unchanged through its compatibility
entry point. New cases exercise exact four-layer carrier-style geometry and
longer parallel bypasses, where shortest-path inclusion alone would pass.
"""
from pathlib import Path
import copy
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from harness import check,eq,test,main,tmpdir,must_pass,must_fail,run,KPY,SCRIPTS
sys.path.insert(0,str(SCRIPTS))
import critical_path_check as gate
import yaml

CONFIG={'schema':1,'layers':['F.Cu','In1.Cu','In2.Cu','B.Cu'],'stackup_mm':[.2104,1.065,.2104],
        'short_paths':[{'from':'J1.5','to':'U1.3','max_length_mm':4.2,'layer':'B.Cu','max_pad_centre_mm':4.,'why':'connector entry clamp'}],
        'prefixes':[{'from':'J1.5','through':'U1.3','targets':['C1.1'],'why':'coupling after clamp'}]}

def board(segments=None, extra='', clamp_x=2):
    if segments is None:segments=[(0,0,clamp_x,0),(clamp_x,0,6,0)]
    s='(kicad_pcb\n\t(layers\n\t\t(0 "F.Cu" signal)\n\t\t(4 "In1.Cu" signal)\n\t\t(6 "In2.Cu" signal)\n\t\t(2 "B.Cu" signal)\n\t)\n'
    for ref,pin,x in [('J1','5',0),('U1','3',clamp_x),('C1','1',6)]:
        s+=f'\t(footprint "test:pad"\n\t\t(layer "B.Cu")\n\t\t(at {x} 0)\n\t\t(property "Reference" "{ref}")\n\t\t(pad "{pin}" smd rect (at 0 0) (size 0.4 0.4) (layers "B.Cu") (net 1 "AUDIO"))\n\t)\n'
    for a,b,c,d in segments:
        s+=f'\t(segment (start {a} {b}) (end {c} {d}) (width 0.2) (layer "B.Cu") (net "AUDIO"))\n'
    return s+extra+'\n)\n'

def invoke(text=None,config=None):
    d=tmpdir();(d/'b.kicad_pcb').write_text(text or board());(d/'policy.yaml').write_text(yaml.safe_dump(config or CONFIG))
    return run([KPY,str(SCRIPTS/'critical_path_check.py'),str(d/'b.kicad_pcb'),'--config',str(d/'policy.yaml'),'--json',str(d/'report.json')])

def reject_config(data):
    try:gate.validate_config(data)
    except gate.AuditError:return
    raise AssertionError('bad configuration accepted')

@test('shared path checker accepts an exact four-layer branch-after-clamp board')
def clean():
    r=invoke();must_pass(r, "critical-path fixture");check('R-CRITICAL-PATH PASS: 2 graded' in r.out,r.out)

@test('short-path checker rejects excess length and pad span',kind='known_bad')
def long():
    r=invoke(board(clamp_x=4.3));must_fail(r, "critical-path fixture");check('exceeds' in r.out,r.out)

@test('short-path checker rejects wrong layer',kind='known_bad')
def wrong_layer():
    r=invoke(board().replace('(layer "B.Cu") (net "AUDIO")','(layer "F.Cu") (net "AUDIO")'));must_fail(r, "critical-path fixture")

@test('prefix checker rejects branch before clamp',kind='known_bad')
def bypass():
    r=invoke(board([(0,0,1,0),(1,0,2,0),(1,0,1,1),(1,1,6,1),(6,1,6,0)]));must_fail(r, "critical-path fixture");check('branches before' in r.out,r.out)

@test('prefix checker rejects longer parallel bypass despite shortest-path inclusion',kind='known_bad')
def longer_bypass():
    r=invoke(board([(0,0,1,0),(1,0,2,0),(2,0,6,0),(1,0,1,2),(1,2,6,2),(6,2,6,0)]));must_fail(r, "critical-path fixture");check('parallel copper' in r.out,r.out)

@test('unsplit tee cannot silently escape prefix graph',kind='known_bad')
def unsplit():
    r=invoke(board([(0,0,2,0),(2,0,6,0),(1,0,1,2),(1,2,6,2),(6,2,6,0)]));must_fail(r, "critical-path fixture");check('unsplit' in r.out,r.out)

@test('unrepresented graded-net zones are rejected',kind='known_bad')
def zone():
    r=invoke(board(extra='\t(zone (net_name "AUDIO") (layer "B.Cu"))'));must_fail(r, "critical-path fixture");check('zone copper' in r.out,r.out)

@test('critical path missing copper cannot pass',kind='known_bad')
def no_copper():
    must_fail(invoke(board([])), "critical-path fixture")

@test('empty, duplicate, unknown and nonfinite config are rejected',kind='known_bad')
def config_cases():
    for mutate in [lambda d:d.update(short_paths=[]),lambda d:d['short_paths'].append(copy.deepcopy(d['short_paths'][0])),lambda d:d.update(unknown=True),lambda d:d['short_paths'][0].update(max_length_mm=float('nan')),lambda d:d['prefixes'][0].update(targets=[]),lambda d:d.update(stackup_mm=[1.6])]:
        d=copy.deepcopy(CONFIG);mutate(d);reject_config(d)

@test('component clamp failure is outside geometric path proof',kind='vacuity',gate='critical_path_check.py')
def physical_clamp_vacuity():
    # Mark a failed-open physical device without altering its copper. Geometry
    # is still valid; changing its routed prefix to a bypass supplies contrast.
    must_pass(invoke(board(extra='\t(property "physical_U1_status" "failed-open")')), "critical-path fixture")
    must_fail(invoke(board([(0,0,1,0),(1,0,2,0),(1,0,1,1),(1,1,6,1),(6,1,6,0)])), "critical-path fixture")

def native_pad_fixture(offset=.4, bypass=True):
    """Independent reviewer geometry reproduced through pcbnew save/reopen.

    The 1 mm connector land touches the longer route between its endpoints.
    offset=.4 crosses its interior; .55 touches only via track half-width.
    Original shared checker falsely passed both with native two-track contact.
    """
    import pcbnew
    d=tmpdir();b=pcbnew.BOARD();b.SetCopperLayerCount(2)
    net=pcbnew.NETINFO_ITEM(b,'AUDIO');b.Add(net)
    for ref,num,x,size in [('J1','5',10,1.),('U1','3',12,.4),('C1','1',16,.4)]:
        f=pcbnew.FOOTPRINT(b);f.SetReference(ref);f.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(x),pcbnew.FromMM(10)));b.Add(f)
        p=pcbnew.PAD(f);p.SetNumber(num);p.SetAttribute(pcbnew.PAD_ATTRIB_SMD);p.SetShape(pcbnew.PAD_SHAPE_RECT);p.SetSize(pcbnew.VECTOR2I(pcbnew.FromMM(size),pcbnew.FromMM(size)))
        ls=pcbnew.LSET();ls.AddLayer(pcbnew.B_Cu);p.SetLayerSet(ls);p.SetPosition(f.GetPosition());p.SetNet(net);f.Add(p)
    segments=[(10,10,12,10),(12,10,16,10)]
    if bypass:segments.extend([(9,10+offset,11,10+offset),(11,10+offset,11,12),(11,12,16,12),(16,12,16,10)])
    for a,y,c,z in segments:
        t=pcbnew.PCB_TRACK(b);t.SetStart(pcbnew.VECTOR2I(pcbnew.FromMM(a),pcbnew.FromMM(y)));t.SetEnd(pcbnew.VECTOR2I(pcbnew.FromMM(c),pcbnew.FromMM(z)));t.SetLayer(pcbnew.B_Cu);t.SetWidth(pcbnew.FromMM(.2));t.SetNet(net);b.Add(t)
    path=d/'board.kicad_pcb';pcbnew.SaveBoard(str(path),b)
    native=pcbnew.LoadBoard(str(path));native.BuildConnectivity()
    pad=next(p for f in native.GetFootprints() if f.GetReference()=='J1' for p in f.Pads())
    eq(len(native.GetConnectivity().GetConnectedTracks(pad)),2 if bypass else 1,'native connector track census')
    cfg=copy.deepcopy(CONFIG);cfg['layers']=['F.Cu','B.Cu'];cfg['stackup_mm']=[1.6]
    (d/'policy.yaml').write_text(yaml.safe_dump(cfg))
    return run([KPY,str(SCRIPTS/'critical_path_check.py'),str(path),'--config',str(d/'policy.yaml')])

@test('native pad-center tree retains correct acceptance')
def native_clean():
    must_pass(native_pad_fixture(bypass=False), 'native ordinary clamp tree')

@test('native pad-interior bypass cannot escape endpoint graph',kind='known_bad')
def native_pad_interior():
    # RED against the frozen source reviewed at 18:39Z: native two tracks,
    # shared false PASS. GREEN requires represented or refused contact.
    must_fail(native_pad_fixture(.4), 'native pad-interior bypass',expect='pad')

@test('native pad-width-only bypass cannot escape endpoint graph',kind='known_bad')
def native_pad_width():
    must_fail(native_pad_fixture(.55), 'native pad-width-only bypass',expect='pad')

@test('native absolute pad angle rejects false contact after footprint rotation',kind='known_bad',gate='copper_length_audit.py')
def native_pad_angle():
    # RED against 01fab37b read_pad_shapes: footprint angle was added twice.
    # Native square pads or only 0/180 rotations would hide the defect.
    import pcbnew
    import copper_length_audit as copper
    V=lambda x,y:pcbnew.VECTOR2I(pcbnew.FromMM(x),pcbnew.FromMM(y))
    discriminated=False
    for angle in (0,90,180,270):
        b=pcbnew.BOARD();b.SetCopperLayerCount(2);net=pcbnew.NETINFO_ITEM(b,'AUDIO');b.Add(net)
        f=pcbnew.FOOTPRINT(b);f.SetReference('J1');f.SetPosition(V(10,10));b.Add(f)
        p=pcbnew.PAD(f);p.SetNumber('5');p.SetAttribute(pcbnew.PAD_ATTRIB_SMD);p.SetShape(pcbnew.PAD_SHAPE_RECT);p.SetSize(V(1,.4));ls=pcbnew.LSET();ls.AddLayer(pcbnew.B_Cu);p.SetLayerSet(ls);p.SetPosition(f.GetPosition());p.SetNet(net);f.Add(p);f.SetOrientationDegrees(angle)
        path=tmpdir()/'rotated.kicad_pcb';pcbnew.SaveBoard(str(path),b);native=pcbnew.LoadBoard(str(path));pad=next(p for f in native.GetFootprints() for p in f.Pads())
        raw=copper.read_pad_shapes(path.read_text())['AUDIO'][0]
        for x,y in [(10.4,10),(10,10.4),(9.6,10),(10,9.6)]:
            hit=bool(pad.HitTest(V(x,y)))
            if angle==90 and x==10.4:
                check(not hit,'native false-contact control must discriminate')
                bad=dict(raw,angle=180.)
                check(copper._point_in_pad(bad,x,y),'old double-rotation must hit wrong arm')
                discriminated=True
            eq(copper._point_in_pad(raw,x,y),hit,f'pad contact angle={angle} point={(x,y)}')
    check(discriminated,'rotation fixture must exercise false hit at90 degrees')


def native_contact_case(case):
    """Native controls reproduced from the independent frozen-source review.

    These cases went RED against that frozen checker. Native contacts are
    asserted before asking the independently parsed-text gate to refuse them.
    """
    import pcbnew
    V=lambda x,y:pcbnew.VECTOR2I(pcbnew.FromMM(x),pcbnew.FromMM(y))
    b=pcbnew.BOARD();b.SetCopperLayerCount(4 if case in ('interior_via','interior_pad') else 2)
    net=pcbnew.NETINFO_ITEM(b,'AUDIO');b.Add(net)
    def pad(ref,num,x,y,size=1.,through=False,rounded=False):
        f=pcbnew.FOOTPRINT(b);f.SetReference(ref);f.SetPosition(V(x,y));b.Add(f)
        p=pcbnew.PAD(f);p.SetNumber(num);p.SetAttribute(pcbnew.PAD_ATTRIB_PTH if through else pcbnew.PAD_ATTRIB_SMD)
        p.SetShape(pcbnew.PAD_SHAPE_ROUNDRECT if rounded else pcbnew.PAD_SHAPE_RECT);p.SetSize(V(size,size))
        ls=pcbnew.LSET();ls.AddLayer(pcbnew.B_Cu);p.SetLayerSet(ls);p.SetPosition(f.GetPosition());p.SetNet(net)
        if through:p.SetDrillSize(V(.3,.3));p.SetLayerSet(pcbnew.LSET.AllCuMask())
        if rounded:p.SetRoundRectRadiusRatio(.25)
        f.Add(p)
    def track(a,y,c,z,layer=pcbnew.B_Cu,width=.2):
        t=pcbnew.PCB_TRACK(b);t.SetStart(V(a,y));t.SetEnd(V(c,z));t.SetLayer(layer);t.SetWidth(pcbnew.FromMM(width));t.SetNet(net);b.Add(t)
    def via(x,y):
        v=pcbnew.PCB_VIA(b);v.SetPosition(V(x,y));v.SetWidth(pcbnew.FromMM(.4));v.SetDrill(pcbnew.FromMM(.2));v.SetLayerPair(pcbnew.F_Cu,pcbnew.B_Cu);v.SetNet(net);b.Add(v)
    pad('J1','5',10,10,rounded=case=='roundrect')
    pad('U1','3',12,10,.4)
    pad('C1','1',10 if case=='overlap' else 16,10.8 if case=='overlap' else 10,
        1. if case in ('overlap','offcenter_pth') else .4,through=case in ('via_pad','interior_via','offcenter_pth'))
    if case=='roundrect':track(10.47,10.47,12,10,width=.02);track(12,10,16,10,width=.02)
    elif case=='overlap':
        for t in [(10,10,12,10),(12,10,13,10),(13,10,13,12),(13,12,10,12),(10,12,10,10.8)]:track(*t)
    elif case=='via_pad':
        track(10,10,12,10);track(12,10,16,10);via(10,10.6)
        track(10,10.6,16,10.6,pcbnew.F_Cu);track(16,10.6,16,10,pcbnew.F_Cu)
    elif case=='interior_pad':
        track(10,10,11,10);track(11,10,12,10);track(12,10,16,10)
        track(11,10,11,12);track(16,10,16,12);via(11,12);via(16,12)
        pad('TP1','1',13.5,12)
        ip=next(p for f in b.GetFootprints() if f.GetReference()=='TP1' for p in f.Pads())
        ip.SetSize(V(6,.6));ls=pcbnew.LSET();ls.AddLayer(pcbnew.In1_Cu);ip.SetLayerSet(ls)
    else:
        track(10,10,11,10);track(11,10,12,10);track(12,10,16,10)
        track(11,10,11,12);via(11,12)
        layer=pcbnew.In1_Cu if case=='interior_via' else pcbnew.F_Cu
        track(11,12,16,12,layer);track(16,12,16,10.4 if case=='offcenter_pth' else 10,layer)
    path=tmpdir()/'native.kicad_pcb';pcbnew.SaveBoard(str(path),b)
    native=pcbnew.LoadBoard(str(path));native.BuildConnectivity();conn=native.GetConnectivity()
    pads={f.GetReference():next(iter(f.Pads())) for f in native.GetFootprints()}
    if case=='roundrect':eq(len(conn.GetConnectedTracks(pads['J1'])),0,'native rounded corner is disconnected')
    elif case=='overlap':eq(len(conn.GetConnectedPads(pads['J1'])),1,'native overlapping lands are connected')
    elif case=='via_pad':eq(len(conn.GetConnectedTracks(pads['J1'])),2,'native pad contacts track and via')
    elif case=='interior_pad':
        eq(len(conn.GetConnectedTracks(pads['TP1'])),2,'native internal land bridges both through vias')
        eq(len(conn.GetConnectedTracks(pads['C1'])),2,'native downstream branch reaches bridge')
    else:
        eq(len(conn.GetConnectedTracks(pads['C1'])),2,'native plated land connects both layers')
        v=next(t for t in native.GetTracks() if isinstance(t,pcbnew.PCB_VIA))
        eq(len(conn.GetConnectedTracks(v)),2,'native via connects both branch tracks')
    cfg=copy.deepcopy(CONFIG)
    if case not in ('interior_via','interior_pad'):cfg['layers']=['F.Cu','B.Cu'];cfg['stackup_mm']=[1.6]
    policy=path.with_suffix('.yaml');policy.write_text(yaml.safe_dump(cfg))
    return run([KPY,str(SCRIPTS/'critical_path_check.py'),str(path),'--config',str(policy)])

@test('native via annulus touching land cannot hide a bypass',kind='known_bad')
def native_via_pad():must_fail(native_contact_case('via_pad'),'native via-pad bypass',expect='pad-via')

@test('native overlapping lands cannot hide a bypass',kind='known_bad')
def native_overlap():must_fail(native_contact_case('overlap'),'native land overlap',expect='distinct pads')

@test('native rounded pad corner cannot invent a connection',kind='known_bad')
def native_roundrect():must_fail(native_contact_case('roundrect'),'native rounded corner',expect='rounded-corner')

@test('native through via interior layer cannot hide a bypass',kind='known_bad')
def native_interior_via():must_fail(native_contact_case('interior_via'),'native interior via layer',expect='interior via-layer')

@test('native through vias bridged by an internal pad cannot hide a bypass',kind='known_bad')
def native_interior_pad():must_fail(native_contact_case('interior_pad'),'native internal pad bridge',expect='interior via-pad')

@test('native off-center plated land cannot hide a barrel transition',kind='known_bad')
def native_offcenter_pth():must_fail(native_contact_case('offcenter_pth'),'native off-center PTH',expect='PTH layer transition')


def native_pad_modifier(kind):
    # Independent second review found both classes falsely accepted after the
    # first geometry fix. Verify disconnected copper through native KiCad.
    import pcbnew
    V=lambda x,y:pcbnew.VECTOR2I(pcbnew.FromMM(x),pcbnew.FromMM(y))
    b=pcbnew.BOARD();b.SetCopperLayerCount(2);net=pcbnew.NETINFO_ITEM(b,'AUDIO');b.Add(net)
    for ref,num,x,size in [('J1','5',10,1.),('U1','3',12,.4),('C1','1',16,.4)]:
        f=pcbnew.FOOTPRINT(b);f.SetReference(ref);f.SetPosition(V(x,10));b.Add(f)
        p=pcbnew.PAD(f);p.SetNumber(num);p.SetAttribute(pcbnew.PAD_ATTRIB_SMD);p.SetShape(pcbnew.PAD_SHAPE_RECT)
        p.SetSize(V(size,size));ls=pcbnew.LSET();ls.AddLayer(pcbnew.B_Cu);p.SetLayerSet(ls);p.SetPosition(f.GetPosition());p.SetNet(net);f.Add(p)
        if ref=='J1':
            if kind=='chamfer':p.SetShape(pcbnew.PAD_SHAPE_CHAMFERED_RECT);p.SetChamferRectRatio(.5);p.SetChamferPositions(15)
            else:p.SetOffset(V(0,1.))
    for a,y,c,z in [(10.34 if kind=='chamfer' else 10,10.34 if kind=='chamfer' else 10,12,10),(12,10,16,10)]:
        t=pcbnew.PCB_TRACK(b);t.SetStart(V(a,y));t.SetEnd(V(c,z));t.SetLayer(pcbnew.B_Cu);t.SetWidth(pcbnew.FromMM(.2));t.SetNet(net);b.Add(t)
    path=tmpdir()/'modifier.kicad_pcb';pcbnew.SaveBoard(str(path),b);n=pcbnew.LoadBoard(str(path));n.BuildConnectivity()
    pad=next(p for f in n.GetFootprints() if f.GetReference()=='J1' for p in f.Pads())
    eq(len(n.GetConnectivity().GetConnectedTracks(pad)),0,'native modified pad is disconnected')
    cfg=copy.deepcopy(CONFIG);cfg['layers']=['F.Cu','B.Cu'];cfg['stackup_mm']=[1.6]
    policy=path.with_suffix('.yaml');policy.write_text(yaml.safe_dump(cfg))
    return run([KPY,str(SCRIPTS/'critical_path_check.py'),str(path),'--config',str(policy)])

@test('native chamfer modifiers cannot be mistaken for a filled rounded land',kind='known_bad')
def native_chamfer():must_fail(native_pad_modifier('chamfer'),'native chamfer false connection',expect='unsupported pad geometry')

@test('native offset copper cannot be mistaken for the pad anchor',kind='known_bad')
def native_offset():must_fail(native_pad_modifier('offset'),'native offset false connection',expect='unsupported pad geometry')

if __name__=='__main__':sys.exit(main())
