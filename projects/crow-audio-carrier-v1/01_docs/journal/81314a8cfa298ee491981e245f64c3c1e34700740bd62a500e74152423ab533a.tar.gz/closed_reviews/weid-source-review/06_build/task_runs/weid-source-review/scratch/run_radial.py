from pathlib import Path
import sys,os,json
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_runtime import run_stage
S=Path('/tmp/carrier-weid-source-review-f679qzah/06_build/task_runs/weid-source-review/scratch')
r=run_stage({'id':'nominal-axis-radial-review','work_class':'local','timeout_s':60},['/usr/bin/python3','-B',str(S/'review_radial.py')],cwd=S.parent.parent.parent.parent,env={'PATH':os.environ['PATH'],'HOME':os.environ['HOME'],'LANG':'C.UTF-8'},log_path=S/'radial.log');(S/'radial-runtime.json').write_text(json.dumps(r.to_mapping(),indent=2)+'\n');assert r.status=='PASS'
