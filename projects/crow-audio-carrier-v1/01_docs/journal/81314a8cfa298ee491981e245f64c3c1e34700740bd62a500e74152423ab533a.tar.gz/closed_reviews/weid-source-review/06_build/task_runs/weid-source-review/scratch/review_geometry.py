from pathlib import Path
import sys,json,hashlib,math
sys.path.insert(0,'/tmp/carrier-rj45-20260912/cad-libs')
from OCP.STEPControl import STEPControl_Reader
from OCP.IFSelect import IFSelect_RetDone
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_FACE,TopAbs_SOLID
from OCP.TopoDS import TopoDS
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.GeomAbs import GeomAbs_Cylinder
R=Path('/tmp/carrier-weid-source-review-f679qzah'); S=R/'06_build/task_runs/weid-source-review/scratch'
e=json.loads((S.parent/'envelope.json').read_text()); hashes=[]
for row in e['input_packet']:
 p=R/row['path']; d=p.read_bytes(); got=hashlib.sha256(d).hexdigest(); assert got==row['sha256'] and len(d)==row['size'];hashes.append({'path':row['path'],'sha256':got,'size':len(d)})
(S/'inputs-before.json').write_text(json.dumps(hashes,indent=2)+'\n')
r=STEPControl_Reader();assert r.ReadFile(str(R/'manufacturer/8909650150.stp'))==IFSelect_RetDone;assert r.TransferRoots()>0;shape=r.OneShape()
def bound(shape):
 b=Bnd_Box();BRepBndLib.AddOptimal_s(shape,b,False,False);return list(b.Get())
faces=[];it=TopExp_Explorer(shape,TopAbs_FACE)
while it.More():
 f=TopoDS.Face_s(it.Current());b=bound(f);row={'index':len(faces),'bounds_mm':b};a=BRepAdaptor_Surface(f,True)
 if a.GetType()==GeomAbs_Cylinder:
  c=a.Cylinder();ax=c.Axis();p=ax.Location();v=ax.Direction();row['cylinder']={'radius_mm':c.Radius(),'axis_point_mm':[p.X(),p.Y(),p.Z()],'axis_direction':[v.X(),v.Y(),v.Z()]}
 faces.append(row);it.Next()
solids=0;it=TopExp_Explorer(shape,TopAbs_SOLID)
while it.More():solids+=1;it.Next()
end=[f for f in faces if f['bounds_mm'][5]<100]
cross=[f for f in faces if f['bounds_mm'][2]<100<f['bounds_mm'][5]]
def union(rows):return [min(f['bounds_mm'][i] for f in rows) for i in range(3)]+[max(f['bounds_mm'][i] for f in rows) for i in range(3,6)]
b=union(end);candidates=[f for f in cross if 'cylinder'in f and abs(f['cylinder']['axis_direction'][2])>.999]
axis=candidates[0]['cylinder']['axis_point_mm'][:2]
def radius(b):return max(math.hypot(x-axis[0],y-axis[1]) for x in [b[0],b[3]] for y in [b[1],b[4]])
for f in end:f['face_box_max_radius_mm']=radius(f['bounds_mm'])
result={'source_sha256':hashlib.sha256((R/'manufacturer/8909650150.stp').read_bytes()).hexdigest(),'whole_bounds_mm':bound(shape),'solids':solids,'faces':len(faces),'end_face_count':len(end),'end_bounds_mm':b,'end_size_mm':[b[i+3]-b[i]for i in range(3)],'crossing_faces':cross,'cable_axis_xy_mm':axis,'box_diagonal_diameter_mm':math.hypot(b[3]-b[0],b[4]-b[1]),'axis_centered_whole_box_diameter_mm':2*radius(b),'axis_centered_face_box_diameter_mm':2*max(f['face_box_max_radius_mm']for f in end),'max_radius_faces':sorted(end,key=lambda f:f['face_box_max_radius_mm'],reverse=True)[:10],'end_faces':end}
(S/'geometry.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['end_faces','max_radius_faces']},indent=2))
