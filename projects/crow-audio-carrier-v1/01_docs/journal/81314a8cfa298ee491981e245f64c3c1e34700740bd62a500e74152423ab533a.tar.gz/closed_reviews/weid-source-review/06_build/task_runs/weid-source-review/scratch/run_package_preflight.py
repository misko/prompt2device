from pathlib import Path
import sys,os,json
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_runtime import run_stage
R=Path('/tmp/carrier-weid-source-review-f679qzah');S=R/'06_build/task_runs/weid-source-review/scratch';env={'PATH':os.environ['PATH'],'HOME':os.environ['HOME'],'LANG':'C.UTF-8'}
r=run_stage({'id':'evidence-packaging','work_class':'local','timeout_s':45},['/usr/bin/python3','-B',str(S/'package.py')],cwd=R,env=env,log_path=S/'package.log');(S/'package-runtime.json').write_text(json.dumps(r.to_mapping(),indent=2)+'\n');assert r.status=='PASS'
r=run_stage({'id':'mandatory-delivery-preflight','work_class':'local','timeout_s':45},['/usr/bin/python3','-B',str(R/'preflight.py'),str(S.parent/'envelope.json')],cwd=R,env=env,log_path=S/'preflight.log');(S/'preflight-runtime.json').write_text(json.dumps(r.to_mapping(),indent=2)+'\n');assert r.status=='PASS'
