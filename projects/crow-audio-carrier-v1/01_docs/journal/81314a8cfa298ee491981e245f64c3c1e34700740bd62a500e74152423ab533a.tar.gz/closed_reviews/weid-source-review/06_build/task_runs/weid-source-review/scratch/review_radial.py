from pathlib import Path
import sys,json,math
sys.path.insert(0,'/tmp/carrier-rj45-20260912/cad-libs')
from OCP.STEPControl import STEPControl_Reader
from OCP.IFSelect import IFSelect_RetDone
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_VERTEX
from OCP.TopoDS import TopoDS
from OCP.BRep import BRep_Tool
S=Path('/tmp/carrier-weid-source-review-f679qzah/06_build/task_runs/weid-source-review/scratch');g=json.loads((S/'geometry.json').read_text());cx,cy=g['cable_axis_xy_mm'];r=STEPControl_Reader();assert r.ReadFile(str(S.parent.parent.parent.parent/'manufacturer/8909650150.stp'))==IFSelect_RetDone;assert r.TransferRoots()>0
it=TopExp_Explorer(r.OneShape(),TopAbs_VERTEX);rows=[]
while it.More():
 p=BRep_Tool.Pnt_s(TopoDS.Vertex_s(it.Current()))
 if p.Z()<100:rows.append({'point_mm':[p.X(),p.Y(),p.Z()],'radius_mm':math.hypot(p.X()-cx,p.Y()-cy)})
 it.Next()
rows.sort(key=lambda p:p['radius_mm'],reverse=True);out={'nominal_axis_xy_mm':[cx,cy],'box_diagonal_radius_mm':g['box_diagonal_diameter_mm']/2,'vertices_count':len(rows),'maximum_vertex_radius_mm':rows[0]['radius_mm'],'vertex_counterexamples':rows[:10],'recommended_diameter_mm':26.048,'recommended_diameter_basis':'Ceil to 0.001 mm of twice maximum complete cross-section AABB corner distance from nominal cable axis; rounding is numeric containment only, not manufacturing allowance.'};(S/'radial.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
