from pathlib import Path
import hashlib,json,tarfile,sys
R=Path('/tmp/carrier-weid-source-review-f679qzah'); A=R/'06_build/task_runs/weid-source-review';S=A/'scratch';O=A/'outputs';e=json.loads((A/'envelope.json').read_text());rows=[]
def record(p):
 d=p.read_bytes();return {'size':len(d),'sha256':hashlib.sha256(d).hexdigest()}
for row in e['input_packet']:
 got=record(R/row['path']);assert got['sha256']==row['sha256'] and got['size']==row['size'];rows.append({'path':row['path'],**got})
(S/'inputs-after.json').write_text(json.dumps(rows,indent=2)+'\n')
extras=[]
for name in ['pipeline_runtime.py','pipeline_execution.py','pipeline_artifacts.py']:
 p=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')/name;extras.append({'path':str(p),**record(p)})
(S/'extra-source-bindings.json').write_text(json.dumps(extras,indent=2)+'\n')
evidence={'review_kind':'independent-connector-source-boundary-review','domain_verdict':'ACCEPT_RECOMMENDED_NOMINAL_SOURCE_REPRESENTATION','candidate_adopted':False,'whole_source_gate_receipt_issued':False,'physical_qualification':'INCOMPLETE','source_model_sha256':e['input_packet'][13]['sha256'],'nominal_grip':{'outer_diameter_mm':22.986,'axial_length_mm':57.98,'axis_model_xy_mm':[6.85,7.38],'basis':'Full nominal BREP cylinder-containment independently verified; no manufacturing allowance'},'findings':[{'id':'mate-model','status':'ACCEPT','detail':'Exact product-bound manufacturer STEP supports known nominal mate with null explicit body envelope.'},{'id':'grip-model','status':'ACCEPT','detail':'Native solid Boolean subtraction proves diagonal-diameter cylinder contains the complete nominal end; preserve origin and source-only limitation.'},{'id':'service-tolerances','status':'SOURCE_CORRECTION_REQUIRED','detail':'Represent distinct installed radial and axial unknown tolerance effects; suggested exact sections supplied in report. Preserve existing exposure stack.'},{'id':'wiring','status':'VISIBLE_MAP_CONFIRMED','detail':'Frozen image visibly gives straight-through T568B colors; root must preserve exact-product image linkage.'},{'id':'uv','status':'UNKNOWN_OUTDOOR_HOLD','detail':'Can remain a disclosed environmental qualification hold within accepted carrier prototype scope; no UV true claim or requirement weakening.'}],'evidence_files':['geometry.json','radial.json','containment.json'],'scope_limitations':['No integrated replacement source compiled','No physical manufacturing tolerances or fit established','No board or enclosure collision/placement qualification','No outdoor, order, or deployment authorization'],'frozen_inputs_before_after':'PASS','engineering_subprocess_runtime':'PASS'}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(O/'result.json').write_text(json.dumps({'subject':e['subject'],'checks':{c:'PASS' for c in e['completion']['checks']},'unresolved':[]},indent=2)+'\n')
members=[]
for row in e['input_packet']:members.append(('inputs/'+row['path'],R/row['path']))
for p in sorted(S.iterdir()):
 if p.is_file() and p.name not in ['package.log','package-runtime.json','preflight.log','preflight-runtime.json']:
  members.append(('methods-and-results/'+p.name,p))
members.extend([('review/report.md',O/'report.md'),('review/evidence.json',O/'evidence.json')])
manifest={'schema':1,'kind':'independent-source-review-evidence-manifest','members':[{'path':name,**record(p)}for name,p in members]}
with tarfile.open(O/'evidence.tar.gz','w:gz') as t:
 for name,p in members:t.add(p,arcname=name,recursive=False)
with tarfile.open(O/'evidence.tar.gz','r:gz')as t:
 files=t.getmembers();assert len(files)==len(members)
 for expected,actual in zip(manifest['members'],files):
  assert actual.isfile() and actual.name==expected['path'];d=t.extractfile(actual).read();assert len(d)==expected['size'] and hashlib.sha256(d).hexdigest()==expected['sha256']
manifest['archive']={'path':'evidence.tar.gz',**record(O/'evidence.tar.gz')};(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'frozen_inputs':len(rows),'archive_members':len(members),'archive':manifest['archive'],'outputs':sorted(p.name for p in O.iterdir())}))
