from pathlib import Path
import sys,json,math
sys.path.insert(0,'/tmp/carrier-rj45-20260912/cad-libs')
from OCP.STEPControl import STEPControl_Reader
from OCP.IFSelect import IFSelect_RetDone
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox,BRepPrimAPI_MakeCylinder
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common,BRepAlgoAPI_Cut
from OCP.gp import gp_Pnt,gp_Ax2,gp_Dir
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID,TopAbs_FACE
S=Path('/tmp/carrier-weid-source-review-f679qzah/06_build/task_runs/weid-source-review/scratch');g=json.loads((S/'geometry.json').read_text());cx,cy=g['cable_axis_xy_mm'];r=STEPControl_Reader();assert r.ReadFile(str(S.parent.parent.parent.parent/'manufacturer/8909650150.stp'))==IFSelect_RetDone;assert r.TransferRoots()>0;shape=r.OneShape()
def stats(s):
 p=GProp_GProps();BRepGProp.VolumeProperties_s(s,p);it=TopExp_Explorer(s,TopAbs_SOLID);n=0
 while it.More():n+=1;it.Next()
 f=TopExp_Explorer(s,TopAbs_FACE);nf=0
 while f.More():nf+=1;f.Next()
 return {'valid':BRepCheck_Analyzer(s).IsValid(),'volume_mm3':p.Mass(),'solids':n,'faces':nf}
clip=BRepPrimAPI_MakeBox(gp_Pnt(-1,-1,-1),16,22,59).Shape();op=BRepAlgoAPI_Common(shape,clip);op.Build();assert op.IsDone();end=op.Shape();rad=g['box_diagonal_diameter_mm']/2;cyl=BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(cx,cy,-2),gp_Dir(0,0,1)),rad,62).Shape();cut=BRepAlgoAPI_Cut(end,cyl);cut.Build();assert cut.IsDone();out={'method':'Native BREP common with Z -1..58 clipping prism, then subtract axis-centered cylinder radius equal full-end cross-section AABB diagonal/2. Clipping retains the sleeve and 0.02mm cable after it. No mesh or vertex-only inference.','source':stats(shape),'clipped_end':stats(end),'outside_diagonal_cylinder':stats(cut.Shape()),'cylinder_axis_xy_mm':[cx,cy],'cylinder_radius_mm':rad};(S/'containment.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
