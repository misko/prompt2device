# RJ45 source checkpoint — 2026-09-12

Status: **source INCOMPLETE; no new board or release**.

The approved direction is a nonmagnetic RJ45 port with a factory shielded
Cat6/Cat6A patch cord, carrying analog audio and 12 V. The selected draft uses
Würth 615008160221 jacks and HARTING 09484747743150 15 m Cat6A PUR cords.
The original live source and generated boards still implement Micro-Fit.
The 60-file revised source overlay is preserved as a held proposal; it has
not passed full source review or been adopted into the live design.

## Saved work

[Exact draft and evidence archive](../journal/42051c8dfecc2ee69f75808ab4b04ca48ce798187539c5d09032557eb4f3cfef.tar.gz):
SHA-256 `42051c8dfecc2ee69f75808ab4b04ca48ce798187539c5d09032557eb4f3cfef`, 55437083 bytes, 708 regular payload
members plus `MANIFEST.json`. Root reopened every member. Original author
proposals, rejected changes, all raw failures, fresh reviewer availability,
independent reviews and corrected root proposals are retained separately.
Baseline commit: `d5ee4f3cbf52f6582b730384077bddf9d9bee188`.

Inside the archive, start with `README.md`, `ROOT_REOPEN_AUDIT.json` and
`root/draft-integration-debt.json`. The held overlay is
`root/integrated_source_candidate/`, with exact file identities in
`root/integrated-source-manifest.json`. Resume in an isolated copy of the
baseline; do not blindly copy this draft over the live source.

The draft assigns contacts 1/3/7 to +12 V, 2/6/8 to return, 5 to AUDIO+
and 4 to AUDIO−. Shell tabs 9/10 are CHASSIS on the carrier and isolated
POD_SHIELD on the pod. The three copies of the interface contract have
SHA-256 `cd0307abdfad1edf0d344299b4e09b37be0beda4bf324aa9c788a8b9934f3b4e`.
Ports require an explicit analog/power label and de-energized mating.

## Measured checkpoint

| Check | Result and limit |
|---|---|
| Native startup qualification | 4/4 PASS; tool availability only |
| Fresh reviewer delivery | Availability 3 inputs/2 outputs; review 108 inputs/5 outputs; timely FINAL and closed PASS |
| Parent protocol tests | 14/14 PASS, including 12 known-bad cases; native integration case still owed |
| Carrier protocol tests | 12/12 PASS, including retained native-parser hostiles |
| Pod protocol tests | 10/10 pure tests PASS; native integration case still owed |
| Pod route-policy tests | 10/10 PASS; policy tests do not prove routed copper |
| Rejected-proposal controls | 4/4 discriminate stale board, stale schematic, duplicate pad and duplicate JSON; all were wrongly accepted by the unadopted proposal and rejected by the preserved checker |
| Draft syntax | 14 Python and 26 YAML files parse; no schema or source-admission claim |
| Carrier connector base | INCOMPLETE, 19/42 known, 23 unknown; 3 assemblies and 11 connector instances |
| Carrier source phase | INCOMPLETE; 21 permitted physical deferrals, 3 findings for mate identity/mate/grip |
| Pod connector base | INCOMPLETE, 5/14 known, 9 unknown; 1 assembly and 1 connector instance |
| Pod source phase | INCOMPLETE; 7 permitted physical deferrals, same 3 mate/grip findings |

Both final base and source receipts were reopened through the owning validation
APIs. Valid INCOMPLETE receipts establish an honest stop, not a gate PASS.
The generic runtime prints FAIL for child exit 2; the owning receipt classifies
these results as INCOMPLETE, not malformed source.

The independent source-hold review agrees that generation must stop. It also
identified the carrier standard SOT-553 orientation difference from the pod
custom footprint. Root corrected carrier north clamps to 180° and south to 0°;
an isolated native remeasurement gives 1.935073 mm audio-contact-to-clamp spans
on both sides. The frozen reviewer did not review these later bytes. Neither
its source review nor the footprint measurement is full board acceptance.

## Exact blocker and next input

The cord catalog gives approximately 45 mm boot length and nominal 6.7 mm OD.
It does not establish a maximum mate or grip envelope. The source gate has no
permitted deferral for those facts. The SOURCE-IDENTITY finding follows from
the unknown mate-section evidence; the exact cord MPN itself is selected.

The [measurement request](../evidence/rj45-cord-measurement-request.md) names
the required drawing or controlled sample evidence. Obtain that evidence,
enter the justified dimensions and tolerances into the single connector
contract, recompile base/source receipts, and complete fresh source review.
No sample has been purchased or measured during this work.

## Implementation work after evidence arrives

Before source adoption, finish the carrier's exact B.Cu clamp prefixes and
realized branch-dominance enforcement; retain all existing length/via limits.
Prove CHASSIS copper connectivity and the panel bond independently from
signal GND, and route the pod's isolated shell island. Resolve the pod's
150 VAC jack rating versus its draft DC recommended/absolute fields; prose
alone does not establish an electrical rating. Complete active first-article
and parent decision records, then run the full source and schema checks.

After source admission, regenerate both schematics and boards through the full
conductor. Renew pin, schematic readability, model, bottom assembly, visual
and layout reviews, then honor each project's actual connector admission gate.
Carrier ADR-0007 explicitly permits represented physical INCOMPLETE after
SOURCE success for the prototype design; physical fit tests belong to the
first assembled prototype, and a separate coupon is optional. That existing
user authorization remains in force. It does not permit unknown mate/grip
source facts, schema errors or known design defects. Fresh routes, DRC 0/0/0,
protection/analog/current gates, fabrication and independent release gates
remain mandatory for a new immutable release.

LAYOUT-001 remains closed with all three attempts spent. The late schematic
review remains TIMED_OUT and unaccepted. The prior sealed pod release remains
immutable. Root is the sole live writer; no author or reviewer remains active.
