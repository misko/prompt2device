from pathlib import Path
import hashlib,json,tarfile,io
P=Path('/tmp/carrier-weid-integration-review-dws2_3ux');run=P/'06_build/task_runs/weid-integration-review';s=run/'scratch';o=run/'outputs';e=json.loads((run/'envelope.json').read_text())
files=[('inputs/'+x['path'],P/x['path']) for x in e['input_packet']]
files += [('allocation/envelope.json',run/'envelope.json')]
files += [('methods-and-results/'+p.relative_to(s).as_posix(),p) for p in s.rglob('*') if p.is_file()]
files += [('review/report.md',o/'report.md'),('review/evidence.json',o/'evidence.json')]
rows=[]
with tarfile.open(o/'evidence.tar.gz','w:gz') as t:
 for name,p in sorted(files):
  assert p.is_file() and not p.is_symlink();b=p.read_bytes();i=tarfile.TarInfo(name);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b));rows.append({'path':name,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
with tarfile.open(o/'evidence.tar.gz','r:gz') as t:
 members=t.getmembers();assert len(members)==len(rows);expected={x['path']:x for x in rows};assert set(expected)=={m.name for m in members}
 for m in members:
  assert m.isfile() and not m.issym() and not m.islnk();b=t.extractfile(m).read();x=expected[m.name];assert len(b)==x['size'] and hashlib.sha256(b).hexdigest()==x['sha256']
a=o/'evidence.tar.gz';manifest={'schema':1,'kind':'independent-source-review-evidence-manifest','archive':{'path':a.name,'size':a.stat().st_size,'sha256':hashlib.sha256(a.read_bytes()).hexdigest()},'member_count':len(rows),'regular_members_verified':len(rows),'members':rows};(o/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'archive_members_verified':len(rows),'archive_bytes':a.stat().st_size,'archive_sha256':manifest['archive']['sha256']}))
