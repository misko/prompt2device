from pathlib import Path
import pcbnew,sys,json
s=Path(__file__).parent;sys.path.insert(0,str(s/'extra-source/skills/kicad-pcb/scripts'));import copper_length_audit as copper
V=lambda x,y:pcbnew.VECTOR2I(pcbnew.FromMM(x),pcbnew.FromMM(y))
b=pcbnew.BOARD();b.SetCopperLayerCount(2);net=pcbnew.NETINFO_ITEM(b,'AUDIO');b.Add(net)
f=pcbnew.FOOTPRINT(b);f.SetReference('J1');f.SetPosition(V(10,10));b.Add(f)
p=pcbnew.PAD(f);p.SetNumber('5');p.SetAttribute(pcbnew.PAD_ATTRIB_SMD);p.SetShape(pcbnew.PAD_SHAPE_RECT);p.SetSize(V(1,.4));ls=pcbnew.LSET();ls.AddLayer(pcbnew.B_Cu);p.SetLayerSet(ls);p.SetPosition(f.GetPosition());p.SetNet(net);f.Add(p);f.SetOrientationDegrees(90)
path=s/'rotated_pad.kicad_pcb';pcbnew.SaveBoard(str(path),b);b=pcbnew.LoadBoard(str(path));p=list(list(b.GetFootprints())[0].Pads())[0]
raw=copper.read_pad_shapes(path.read_text())['AUDIO'][0]
rows=[]
for x,y in [(10.4,10),(10,10.4)]:
 rows.append({'point':[x,y],'native_pad_HitTest':bool(p.HitTest(V(x,y))),'text_graph_inside':copper._point_in_pad(raw,x,y)})
r={'native_pad_angle':p.GetOrientationDegrees(),'text_reader_pad':raw,'comparisons':rows};print(json.dumps(r,indent=2));(s/'shape_probe_result.json').write_text(json.dumps(r,indent=2))
