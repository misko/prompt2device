from pathlib import Path
import sys,json,hashlib
sys.path.insert(0,'/tmp/carrier-rj45-20260912/cad-libs')
from OCP.STEPControl import STEPControl_Reader
from OCP.IFSelect import IFSelect_RetDone
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox,BRepPrimAPI_MakeCylinder
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common,BRepAlgoAPI_Cut
from OCP.gp import gp_Pnt,gp_Ax2,gp_Dir
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID,TopAbs_FACE
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
s=Path(__file__).parent;p=Path('/tmp/carrier-weid-integration-review-dws2_3ux/candidate/projects/crow-audio-carrier-v1/03_src/lib/3dmodels/weidmueller/8909650150.step')
r=STEPControl_Reader();assert r.ReadFile(str(p))==IFSelect_RetDone;assert r.TransferRoots()>0;shape=r.OneShape()
def stats(x):
 prop=GProp_GProps();BRepGProp.VolumeProperties_s(x,prop);result={'valid':BRepCheck_Analyzer(x).IsValid(),'volume_mm3':prop.Mass()}
 for name,kind in [('faces',TopAbs_FACE),('solids',TopAbs_SOLID)]:
  it=TopExp_Explorer(x,kind);n=0
  while it.More():n+=1;it.Next()
  result[name]=n
 return result
clip=BRepPrimAPI_MakeBox(gp_Pnt(-1,-1,-1),16,22,59).Shape();common=BRepAlgoAPI_Common(shape,clip);common.Build();assert common.IsDone()
cylinder=BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(6.85,7.38,-2),gp_Dir(0,0,1)),22.986/2,62).Shape();cut=BRepAlgoAPI_Cut(common.Shape(),cylinder);cut.Build();assert cut.IsDone()
result={'scope':'nominal first-end BREP only; no physical tolerance or mating acceptance','source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'radius_mm':22.986/2,'axis_xy_mm':[6.85,7.38],'source':stats(shape),'clipped_end':stats(common.Shape()),'outside_authored_cylinder':stats(cut.Shape())}
assert result['outside_authored_cylinder']['faces']==0 and result['outside_authored_cylinder']['solids']==0
(s/'nominal_reopen_result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
mods=[]
for name,m in list(sys.modules.items()):
 p=getattr(m,'__file__',None)
 if p and name.startswith('OCP') and Path(p).is_file():
  q=Path(p);mods.append({'module':name,'path':str(q),'size':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()})
(s/'ocp-dependencies.json').write_text(json.dumps(mods,indent=2))
