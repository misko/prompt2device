from pathlib import Path
import sys,json,os,dataclasses
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
s=Path(__file__).parent
name=sys.argv[1];cmd=sys.argv[2:]
env={k:os.environ[k] for k in ['PATH','HOME','LANG'] if k in os.environ}
env.update(PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(s),PYTHONPATH=str(s/'overlay/skills/kicad-pcb/scripts')+':'+str(R/'skills/kicad-pcb/scripts'))
(s/(name+'-command.json')).write_text(json.dumps({'argv':cmd,'cwd':str(s),'timeout_s':120,'env_keys':sorted(env)},indent=2))
r=run_stage({'id':name,'work_class':'local','timeout_s':120},cmd,log_path=s/(name+'.log'),cwd=s,env=env,console_line_limit=60)
(s/(name+'-runtime.json')).write_text(json.dumps(dataclasses.asdict(r),indent=2,default=str))
