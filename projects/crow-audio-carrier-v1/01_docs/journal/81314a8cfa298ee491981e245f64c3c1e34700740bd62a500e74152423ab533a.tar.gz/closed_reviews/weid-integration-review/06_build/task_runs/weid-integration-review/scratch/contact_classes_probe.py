from pathlib import Path
import pcbnew,sys,json
s=Path(__file__).parent;P=Path('/tmp/carrier-weid-integration-review-dws2_3ux/candidate')
sys.path.insert(0,str(s/'extra-source/skills/kicad-pcb/scripts'));sys.path.insert(0,str(P/'skills/kicad-pcb/scripts'))
import critical_path_check as gate
V=lambda x,y:pcbnew.VECTOR2I(pcbnew.FromMM(x),pcbnew.FromMM(y))
cfg={'schema':1,'layers':['F.Cu','B.Cu'],'stackup_mm':[1.6],'short_paths':[{'from':'J1.5','to':'U1.3','max_length_mm':4.2,'layer':'B.Cu','max_pad_centre_mm':4.,'why':'connector clamp'}],'prefixes':[{'from':'J1.5','through':'U1.3','targets':['C1.1'],'why':'after clamp'}]}
rows=[]
for case in ['clean','split_bypass','pad_width_bypass','via_pad_bypass','overlap_pads','roundrect_phantom']:
 b=pcbnew.BOARD();b.SetCopperLayerCount(2);net=pcbnew.NETINFO_ITEM(b,'AUDIO');b.Add(net)
 def pad(ref,num,x,y,size=1.,through=False,rounded=False):
  f=pcbnew.FOOTPRINT(b);f.SetReference(ref);f.SetPosition(V(x,y));b.Add(f)
  p=pcbnew.PAD(f);p.SetNumber(num);p.SetAttribute(pcbnew.PAD_ATTRIB_PTH if through else pcbnew.PAD_ATTRIB_SMD);p.SetShape(pcbnew.PAD_SHAPE_ROUNDRECT if rounded else pcbnew.PAD_SHAPE_RECT);p.SetSize(V(size,size));ls=pcbnew.LSET()
  for layer in ([pcbnew.F_Cu,pcbnew.B_Cu] if through else [pcbnew.B_Cu]):ls.AddLayer(layer)
  p.SetLayerSet(ls);p.SetPosition(f.GetPosition());p.SetNet(net)
  if through:p.SetDrillSize(V(.3,.3));p.SetLayerSet(pcbnew.LSET.AllCuMask())
  if rounded:p.SetRoundRectRadiusRatio(.25)
  f.Add(p)
 def tr(a,bb,c,d,layer=pcbnew.B_Cu,width=.2):
  t=pcbnew.PCB_TRACK(b);t.SetStart(V(a,bb));t.SetEnd(V(c,d));t.SetLayer(layer);t.SetWidth(pcbnew.FromMM(width));t.SetNet(net);b.Add(t)
 pad('J1','5',10,10,rounded=case=='roundrect_phantom');pad('U1','3',12,10,.4)
 if case=='overlap_pads':pad('C1','1',10,10.8)
 else:pad('C1','1',16,10,.4,through=case=='via_pad_bypass')
 if case=='split_bypass':
  for v in [(10,10,11,10),(11,10,12,10),(12,10,16,10),(11,10,11,12),(11,12,16,12),(16,12,16,10)]:tr(*v)
 elif case=='roundrect_phantom':tr(10.47,10.47,12,10,width=.02);tr(12,10,16,10,width=.02)
 elif case=='overlap_pads':
  for v in [(10,10,12,10),(12,10,13,10),(13,10,13,12),(13,12,10,12),(10,12,10,10.8)]:tr(*v)
 else:
  tr(10,10,12,10);tr(12,10,16,10)
  if case=='pad_width_bypass':
   for v in [(9,10.58,11,10.58),(11,10.58,11,12),(11,12,16,12),(16,12,16,10)]:tr(*v)
  if case=='via_pad_bypass':
   v=pcbnew.PCB_VIA(b);v.SetPosition(V(10,10.6));v.SetWidth(pcbnew.FromMM(.4));v.SetDrill(pcbnew.FromMM(.2));v.SetLayerPair(pcbnew.F_Cu,pcbnew.B_Cu);v.SetNet(net);b.Add(v)
   tr(10,10.6,16,10.6,pcbnew.F_Cu);tr(16,10.6,16,10,pcbnew.F_Cu)
 path=s/(case+'.kicad_pcb');pcbnew.SaveBoard(str(path),b);b=pcbnew.LoadBoard(str(path));b.BuildConnectivity();conn=b.GetConnectivity();native={}
 for f in b.GetFootprints():
  p=list(f.Pads())[0];native[f.GetReference()]={'tracks':len(conn.GetConnectedTracks(p)),'pads':len(conn.GetConnectedPads(p)),'items':len(conn.GetConnectedItems(p))}
 try:r=gate.audit(path,cfg)
 except Exception as e:r={'verdict':'ERROR','error':str(e)}
 rows.append({'case':case,'native_contacts':native,'audit':r});print(case,json.dumps(rows[-1]))
(s/'contact_classes_result.json').write_text(json.dumps(rows,indent=2))
