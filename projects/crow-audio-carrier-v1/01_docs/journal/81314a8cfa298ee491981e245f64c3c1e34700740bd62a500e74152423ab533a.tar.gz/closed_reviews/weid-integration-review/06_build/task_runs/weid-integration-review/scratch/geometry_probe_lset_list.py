from pathlib import Path
import sys,json,pcbnew
P=Path('/tmp/carrier-weid-integration-review-dws2_3ux/candidate')
sys.path.insert(0,str(P/'skills/kicad-pcb/scripts'))
import critical_path_check as gate
s=Path(__file__).parent
cfg={'schema':1,'layers':['F.Cu','B.Cu'],'stackup_mm':[1.6],'short_paths':[{'from':'J1.5','to':'U1.3','max_length_mm':4.2,'layer':'B.Cu','max_pad_centre_mm':4.,'why':'connector clamp'}],'prefixes':[{'from':'J1.5','through':'U1.3','targets':['C1.1'],'why':'after clamp'}]}
b=pcbnew.BOARD();b.SetCopperLayerCount(2)
net=pcbnew.NETINFO_ITEM(b,'AUDIO');b.Add(net)
pads={}
for ref,num,x,size in [('J1','5',10,1.),('U1','3',12,.4),('C1','1',16,.4)]:
 f=pcbnew.FOOTPRINT(b);f.SetReference(ref);f.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(x),pcbnew.FromMM(10)));b.Add(f)
 p=pcbnew.PAD(f);p.SetNumber(num);p.SetAttribute(pcbnew.PAD_ATTRIB_SMD);p.SetShape(pcbnew.PAD_SHAPE_RECT);p.SetSize(pcbnew.VECTOR2I(pcbnew.FromMM(size),pcbnew.FromMM(size)));p.SetLayerSet(pcbnew.LSET([pcbnew.B_Cu]));p.SetPosition(f.GetPosition());p.SetNet(net);f.Add(p);pads[ref]=p
segments=[(10,10,12,10),(12,10,16,10),(9,10.4,11,10.4),(11,10.4,11,12),(11,12,16,12),(16,12,16,10)]
for a,bb,c,d in segments:
 t=pcbnew.PCB_TRACK(b);t.SetStart(pcbnew.VECTOR2I(pcbnew.FromMM(a),pcbnew.FromMM(bb)));t.SetEnd(pcbnew.VECTOR2I(pcbnew.FromMM(c),pcbnew.FromMM(d)));t.SetLayer(pcbnew.B_Cu);t.SetWidth(pcbnew.FromMM(.2));t.SetNet(net);b.Add(t)
p=s/'pad_interior_bypass.kicad_pcb';pcbnew.SaveBoard(str(p),b)
b=pcbnew.LoadBoard(str(p));b.BuildConnectivity()
np={f.GetReference():list(f.Pads())[0] for f in b.GetFootprints()}
conn=b.GetConnectivity()
try: native_connected={r:len(conn.GetConnectedTracks(p)) for r,p in np.items()}
except Exception as e:native_connected={'error':str(e)}
r=gate.audit(p,cfg)
print(json.dumps({'native_connected_tracks':native_connected,'audit':r},indent=2))
(s/'geometry_probe_result.json').write_text(json.dumps({'native_connected_tracks':native_connected,'audit':r},indent=2))
