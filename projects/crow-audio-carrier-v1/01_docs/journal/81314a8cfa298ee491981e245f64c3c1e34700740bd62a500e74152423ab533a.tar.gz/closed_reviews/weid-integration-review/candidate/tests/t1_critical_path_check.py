#!/usr/bin/env python3
"""Shared short-path/prefix proof: native saved text and hostile topology.

The pod's original policy fixtures also run unchanged through its compatibility
entry point. New cases exercise exact four-layer carrier-style geometry and
longer parallel bypasses, where shortest-path inclusion alone would pass.
"""
from pathlib import Path
import copy
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from harness import check,eq,test,main,tmpdir,must_pass,must_fail,run,KPY,SCRIPTS
sys.path.insert(0,str(SCRIPTS))
import critical_path_check as gate
import yaml

CONFIG={'schema':1,'layers':['F.Cu','In1.Cu','In2.Cu','B.Cu'],'stackup_mm':[.2104,1.065,.2104],
        'short_paths':[{'from':'J1.5','to':'U1.3','max_length_mm':4.2,'layer':'B.Cu','max_pad_centre_mm':4.,'why':'connector entry clamp'}],
        'prefixes':[{'from':'J1.5','through':'U1.3','targets':['C1.1'],'why':'coupling after clamp'}]}

def board(segments=None, extra='', clamp_x=2):
    if segments is None:segments=[(0,0,clamp_x,0),(clamp_x,0,6,0)]
    s='(kicad_pcb\n\t(layers\n\t\t(0 "F.Cu" signal)\n\t\t(4 "In1.Cu" signal)\n\t\t(6 "In2.Cu" signal)\n\t\t(2 "B.Cu" signal)\n\t)\n'
    for ref,pin,x in [('J1','5',0),('U1','3',clamp_x),('C1','1',6)]:
        s+=f'\t(footprint "test:pad"\n\t\t(layer "B.Cu")\n\t\t(at {x} 0)\n\t\t(property "Reference" "{ref}")\n\t\t(pad "{pin}" smd rect (at 0 0) (size 0.4 0.4) (layers "B.Cu") (net 1 "AUDIO"))\n\t)\n'
    for a,b,c,d in segments:
        s+=f'\t(segment (start {a} {b}) (end {c} {d}) (width 0.2) (layer "B.Cu") (net "AUDIO"))\n'
    return s+extra+'\n)\n'

def invoke(text=None,config=None):
    d=tmpdir();(d/'b.kicad_pcb').write_text(text or board());(d/'policy.yaml').write_text(yaml.safe_dump(config or CONFIG))
    return run([KPY,str(SCRIPTS/'critical_path_check.py'),str(d/'b.kicad_pcb'),'--config',str(d/'policy.yaml'),'--json',str(d/'report.json')])

def reject_config(data):
    try:gate.validate_config(data)
    except gate.AuditError:return
    raise AssertionError('bad configuration accepted')

@test('shared path checker accepts an exact four-layer branch-after-clamp board')
def clean():
    r=invoke();must_pass(r, "critical-path fixture");check('R-CRITICAL-PATH PASS: 2 graded' in r.out,r.out)

@test('short-path checker rejects excess length and pad span',kind='known_bad')
def long():
    r=invoke(board(clamp_x=4.3));must_fail(r, "critical-path fixture");check('exceeds' in r.out,r.out)

@test('short-path checker rejects wrong layer',kind='known_bad')
def wrong_layer():
    r=invoke(board().replace('(layer "B.Cu") (net "AUDIO")','(layer "F.Cu") (net "AUDIO")'));must_fail(r, "critical-path fixture")

@test('prefix checker rejects branch before clamp',kind='known_bad')
def bypass():
    r=invoke(board([(0,0,1,0),(1,0,2,0),(1,0,1,1),(1,1,6,1),(6,1,6,0)]));must_fail(r, "critical-path fixture");check('branches before' in r.out,r.out)

@test('prefix checker rejects longer parallel bypass despite shortest-path inclusion',kind='known_bad')
def longer_bypass():
    r=invoke(board([(0,0,1,0),(1,0,2,0),(2,0,6,0),(1,0,1,2),(1,2,6,2),(6,2,6,0)]));must_fail(r, "critical-path fixture");check('parallel copper' in r.out,r.out)

@test('unsplit tee cannot silently escape prefix graph',kind='known_bad')
def unsplit():
    r=invoke(board([(0,0,2,0),(2,0,6,0),(1,0,1,2),(1,2,6,2),(6,2,6,0)]));must_fail(r, "critical-path fixture");check('unsplit' in r.out,r.out)

@test('unrepresented graded-net zones are rejected',kind='known_bad')
def zone():
    r=invoke(board(extra='\t(zone (net_name "AUDIO") (layer "B.Cu"))'));must_fail(r, "critical-path fixture");check('zone copper' in r.out,r.out)

@test('critical path missing copper cannot pass',kind='known_bad')
def no_copper():
    must_fail(invoke(board([])), "critical-path fixture")

@test('empty, duplicate, unknown and nonfinite config are rejected',kind='known_bad')
def config_cases():
    for mutate in [lambda d:d.update(short_paths=[]),lambda d:d['short_paths'].append(copy.deepcopy(d['short_paths'][0])),lambda d:d.update(unknown=True),lambda d:d['short_paths'][0].update(max_length_mm=float('nan')),lambda d:d['prefixes'][0].update(targets=[]),lambda d:d.update(stackup_mm=[1.6])]:
        d=copy.deepcopy(CONFIG);mutate(d);reject_config(d)

@test('component clamp failure is outside geometric path proof',kind='vacuity',gate='critical_path_check.py')
def physical_clamp_vacuity():
    # Mark a failed-open physical device without altering its copper. Geometry
    # is still valid; changing its routed prefix to a bypass supplies contrast.
    must_pass(invoke(board(extra='\t(property "physical_U1_status" "failed-open")')), "critical-path fixture")
    must_fail(invoke(board([(0,0,1,0),(1,0,2,0),(1,0,1,1),(1,1,6,1),(6,1,6,0)])), "critical-path fixture")

if __name__=='__main__':sys.exit(main())
