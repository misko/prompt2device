from pathlib import Path
from datetime import datetime,timezone,timedelta
import sys,json,hashlib,shutil,tempfile
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
name='rj45-source-hold-review';D=Path(tempfile.mkdtemp(prefix='carrier-rj45-source-hold-review-'))
C=N/'integrated_source_candidate'
for p in C.rglob('*'):
 if p.is_file():
  rel=p.relative_to(C);out=D/'candidate'/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out)
  if (R/rel).is_file():
   out=D/'baseline'/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,out)
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 for kind in ['connector_assembly_contract','connector_assembly_source_gate']:
  p=N/'source_validation/projects'/slug/'06_build/verification'/(kind+'.json');out=D/'receipts'/slug/p.name;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out)
for p in [R/'CLAUDE.md',R/'skills/pcb-design/references/connector-assembly-contract.md',N/'protocol-repair-summary.json',N/'component-geometry-native.json']:
 out=D/'context'/p.name;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out)
shutil.copyfile('/tmp/carrier-rj45-cable-selection-hkl9acsz/preflight.py',D/'preflight.py')
now=datetime.now(timezone.utc);cut=now+timedelta(minutes=10);hard=now+timedelta(minutes=13)
task=f'''Fresh independent judgment review of a held source proposal, not source admission or PCB acceptance. Read CLAUDE and connector reference. Root is sole live writer. Fresh reviewer availability was completed and closed PASS at17:35Z. The approved goal is RJ45 jacks and factory Cat6 patch cords for analog audio +12V; retain every gate. No live source/generated board has adopted this draft. Your bounded task is to verify the checkpoint is honest and actionable, review the source-critical connector cell and preserved checker behavior, and identify material defects that must be fixed before future admission. Do not try to certify the whole 333-component board, routing, native fit or source completeness.

Frozen candidate has 60 changed files and available baseline counterparts. Two actual base/source receipts per board are included. Carrier base19/42known23unknown, source21admitted and3findings; pod5/14known9unknown, source7admitted and3findings. Nondeferrable mate/grip facts block source; SOURCE-IDENTITY is because mate-section evidence is unknown, although exact cord MPN is selected. Published HARTING09484747743150 plug approximately45mm,13.3x13.8drawing andOD6.7nominal do not provide maximum envelope. Root explicitly left mate/gripunknown/null. Fullphysicalunknowns stayunknown. No new deferral class or gate edits. The pod author's original proposal used an invalid factory-cord-plug-envelope-qualification class, wrong axial/lateral bbox, and unmeasured conservative operation/tolerance claims; root did NOT adopt those into candidate. Check corrected facts/deferrals/coupon for any remaining overclaim. Any nonblocking draft implementation debts must be listed plainly.

Protocol original author had removed board/schematic hash bindings and duplicate JSON/pad checks. Root candidate restores original checker fully with only pinmap/identity/arithmetic updates and retains native parser tests. Added three source test cases check stale board/sch, duplicatepads andduplicateJSON. Parent puretests14/14pass,12knownbad; native case deliberately notrun because no newnative exists (unchanged test remains). Source geometry/census expected985=937+8*(10-4),oneadditionalCHASSISnet. Root might notfinish carrier routing/checker extensions before this source-stage checkpoint: flag as owed, do not pretend one shunt topology declaration proves clamp dominance or a CHASSIS copper path. Existing lowerlimits andLAYOUT0013spent remainimmutable.

Review: (1) Is stopping generation at source phase correct under actual contract? (2) Which exact manufacturer drawing or measurement record closes mate/grip? Include boot/latch travel, all bounds/tolerances, dryentry/OD installed tests separately; no fake numeric maximum. (3) Does root preserve original stale-subject/duplicate/timeout/parser guard behavior in changedchecker? (4) Identify obvious source proposal mistakes, withpaths/lines, especially two-layer bottom clamp side, pin5/4 andshield9/10isolation. Root can fix reversible draft defects but no schematic/PCB generation while blocked. Give clear INCOMPLETE/DO-NOT-ORDER verdict for overallcandidate; source hold can be justified independently. No claim tests or measurement you did not perform.

READ_ONLY frozen packet. All authored methods/evidence inside allocated scratch. No children, no purchases/network, no native generation/routing. May read actual repo owning scripts for schema meaning; hash any extra reads. Every Python /usr/bin/python3 -B; every subprocess via pipeline_runtime.run_stage from {R}/skills/pcb-design/scripts. Native availability alreadyqualified but isolated padprobe only ifneeded. No need to rerun extensive sourcechecks; root is running tests concurrently outside your frozen packet.

Five outputs report.md,evidence.json,evidence-manifest.json,evidence.tar.gz,result.json. Archive methods/results and rawlogs. Manifest everyarchive regular member SHA/size plusarchive. Verify frozeninput SHA/size beforeafter. Result subjectexactenvelope, checks evidence-complete/inputs-verified/review-complete PASS for honest completedreview, not engineeringapproval. Mandatory preflight /usr/bin/python3 -B {D}/preflight.py {D}/06_build/task_runs/{name}/envelope.json before actualFINAL. Work/FINAL {cut.isoformat()}, hard {hard.isoformat()}, zero replacements. Reserve packaging time; a short complete boundedreview is preferable to late closure. Root will close actual host FINAL promptly.
'''
(D/'TASK.md').write_text(task)
items=[]
for p in sorted(D.rglob('*')):
 if p.is_file():
  b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(D).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
s=subject_identity('rj45_source_hold_review',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
e=TaskEnvelope(schema=2,task_id=name,stage_id='PCB-SOURCING',run_id=name,subject=s,executor='reviewer',execution_class='review_wait',recommended_agent_role='judgment',agent_role='judgment',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']})
o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),agent_id='/root/carrier_rj45_source_hold_review',work_cutoff=cut.isoformat());(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2))
