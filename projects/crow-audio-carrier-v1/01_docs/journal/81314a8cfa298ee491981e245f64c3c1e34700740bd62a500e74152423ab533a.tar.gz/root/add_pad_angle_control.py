from pathlib import Path
import shutil
N=Path(__file__).parent;C=N/'weid_source_candidate';p=C/'tests/t1_critical_path_check.py';s=p.read_text();pos=s.index("if __name__=='__main__'")
new='''@test('native absolute pad angle rejects false contact after footprint rotation',kind='known_bad',gate='copper_length_audit.py')
def native_pad_angle():
    # RED against 01fab37b read_pad_shapes: footprint angle was added twice.
    # Native square pads or only 0/180 rotations would hide the defect.
    import pcbnew
    import copper_length_audit as copper
    V=lambda x,y:pcbnew.VECTOR2I(pcbnew.FromMM(x),pcbnew.FromMM(y))
    discriminated=False
    for angle in (0,90,180,270):
        b=pcbnew.BOARD();b.SetCopperLayerCount(2);net=pcbnew.NETINFO_ITEM(b,'AUDIO');b.Add(net)
        f=pcbnew.FOOTPRINT(b);f.SetReference('J1');f.SetPosition(V(10,10));b.Add(f)
        p=pcbnew.PAD(f);p.SetNumber('5');p.SetAttribute(pcbnew.PAD_ATTRIB_SMD);p.SetShape(pcbnew.PAD_SHAPE_RECT);p.SetSize(V(1,.4));ls=pcbnew.LSET();ls.AddLayer(pcbnew.B_Cu);p.SetLayerSet(ls);p.SetPosition(f.GetPosition());p.SetNet(net);f.Add(p);f.SetOrientationDegrees(angle)
        path=tmpdir()/'rotated.kicad_pcb';pcbnew.SaveBoard(str(path),b);native=pcbnew.LoadBoard(str(path));pad=next(p for f in native.GetFootprints() for p in f.Pads())
        raw=copper.read_pad_shapes(path.read_text())['AUDIO'][0]
        for x,y in [(10.4,10),(10,10.4),(9.6,10),(10,9.6)]:
            hit=bool(pad.HitTest(V(x,y)))
            if angle==90 and x==10.4:
                check(not hit,'native false-contact control must discriminate')
                bad=dict(raw,angle=180.)
                check(copper._point_in_pad(bad,x,y),'old double-rotation must hit wrong arm')
                discriminated=True
            eq(copper._point_in_pad(raw,x,y),hit,f'pad contact angle={angle} point={(x,y)}')
    check(discriminated,'rotation fixture must exercise false hit at90 degrees')

'''
p.write_text(s[:pos]+new+s[pos:]);shutil.copyfile(p,N/'weid_validation/tests'/p.name)
