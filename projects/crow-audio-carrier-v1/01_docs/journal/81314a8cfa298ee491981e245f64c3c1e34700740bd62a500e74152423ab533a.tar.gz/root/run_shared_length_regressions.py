from pathlib import Path
import sys,runpy
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;V=N/'weid_validation'
sys.path.insert(0,str(R/'tests'));import harness
harness.SCRIPTS=V/'skills/kicad-pcb/scripts'
sys.path.insert(0,str(harness.SCRIPTS))
runpy.run_path(str(R/'tests/t1_copper_length.py'),run_name='__main__')
