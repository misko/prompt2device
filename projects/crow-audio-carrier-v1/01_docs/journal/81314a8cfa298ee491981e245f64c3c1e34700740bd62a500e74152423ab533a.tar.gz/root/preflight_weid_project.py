from pathlib import Path
import os,sys,json
N=Path(__file__).parent;V=N/'weid_validation';P=V/'projects'/sys.argv[1]
sys.path.insert(0,str(V/'skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
S=V/'skills/kicad-pcb/scripts';K='/usr/bin/python3'
commands=[
 ['module_first_check.py','.'],['rf_contract_check.py','.','--require-applicability'],
 ['tsx_preflight.py','.'],['net_label_survival.py','.','--schema-only'],
 ['electrical_invariants.py','.','--schema-only'],['control_protocol_check.py','.'],
 ['control_profile_codegen.py','.','--check'],['early_design_check.py','.'],
 ['rules_audit.py','.','--phase','source'],
]
if sys.argv[1]=='crow-audio-carrier-v1':
    commands += [[str(P/'03_src/check_clock_defaults.py'),'--source-only'],
                 [str(P/'03_src/check_power_source.py'),'--source-only'],
                 [str(P/'03_src/check_analog_paths.py'),'--source-only']]
D=N/'source-preflights'/sys.argv[1];D.mkdir(parents=True,exist_ok=True)
rows=[]
for i,cmd in enumerate(commands):
    argv=[K,'-B',str(S/cmd[0]),*cmd[1:]]
    name=f'{i:02d}-{Path(cmd[0]).stem}'
    r=run_stage({'id':name,'work_class':'local','timeout_s':45},argv,log_path=D/(name+'.log'),cwd=P,
                env={'PATH':os.environ['PATH'],'HOME':os.environ['HOME'],'LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'},console_line_limit=2,console_tail_lines=2)
    row={'argv':argv,'cwd':str(P),'result':r.to_mapping()};rows.append(row)
    (D/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n')
(D/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
print(sum(r['result']['status']=='PASS' for r in rows),'/',len(rows),'source preflights passed')
sys.exit(0 if all(r['result']['status']=='PASS' for r in rows) else 1)
