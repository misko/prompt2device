from pathlib import Path
import shutil
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;C=N/'weid_source_candidate';V=N/'weid_validation'
p=C/'tests/t1_connector_assembly_phase_gate.py';shutil.copyfile(R/'tests'/p.name,p)
s=p.read_text();assert 'def shared_prototype' not in s
extra=r'''
def shared_prototype(project, decision='0005-first-article-only-release.md', create_decision=True):
    adr=project/'01_docs/decisions'/decision
    if create_decision:
        adr.parent.mkdir(parents=True,exist_ok=True)
        adr.write_text('Fixture of an already accepted project prototype decision.\n')
    return run(['bash',PCB_SCRIPTS/'connector_prototype_admission.sh',KPY,PCB_SCRIPTS,
                '[test]','01_docs/decisions/'+decision,'--compile-base'],cwd=project)

@test('shared admission compiles base under each existing project decision and retains FULL unknowns')
def t_shared_admission_compiles():
    for decision in ['0005-first-article-only-release.md','0007-prototype-before-physical-qualification.md']:
        p=fixture();(p/phase_gate.DEFAULT_BASE_RECEIPT).unlink()
        r=must_pass(shared_prototype(p,decision),'authorized prototype with physical debt')
        contains(r.out,'FIRST-ARTICLE-ONLY / DO-NOT-ORDER','prototype boundary')
        receipt=json.loads((p/phase_gate.DEFAULT_FULL_OUTPUT).read_text())
        eq(receipt['status'],'INCOMPLETE','physical unknowns are unchanged')
        ok,errors=phase_gate.validate_phase_gate(receipt,p,expected_phase='full')
        check(ok,str(errors))
        source=json.loads((p/phase_gate.DEFAULT_SOURCE_OUTPUT).read_text())
        eq(source['status'],'PASS','SOURCE must pass')

@test('shared prototype admission rejects missing or indirect decision',kind='known_bad')
def t_shared_missing_decision():
    p=fixture();must_fail(shared_prototype(p,create_decision=False),'missing prototype authority',expect='Missing')
    adr=p/'01_docs/decisions/0005-first-article-only-release.md';adr.parent.mkdir(parents=True,exist_ok=True)
    adr.symlink_to(p/'02_parts/fixture/record.txt')
    must_fail(shared_prototype(p,create_decision=False),'symlink prototype authority',expect='nonregular')

@test('shared prototype admission cannot admit fresh unknown identity',kind='known_bad')
def t_shared_unknown_identity():
    value=contract();value['assemblies'][0]['mate']['mpn']=None
    value['assemblies'][0]['mate']['evidence']=physical_unknown()
    must_fail(shared_prototype(fixture(value)),'unqualified source identity',expect='SOURCE INCOMPLETE')

@test('shared prototype admission rejects invalid base before continuation',kind='known_bad')
def t_shared_invalid_base():
    p=fixture();(p/base.DEFAULT_CONTRACT).write_text('schema: broken\n')
    must_fail(shared_prototype(p),'invalid connector base',expect='invalid connector base authority')

'''
# Keep the module's own harness exit handling unchanged.
anchor='if __name__ == "__main__":';assert anchor in s
p.write_text(s.replace(anchor,extra+anchor))
shutil.copyfile(p,V/'tests'/p.name)
