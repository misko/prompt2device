from pathlib import Path
from datetime import datetime, timezone, timedelta
import sys, json, hashlib, shutil, tempfile
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
N=Path(__file__).parent
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput, subject_identity
from pipeline_runtime import open_agent_attempt
name='rj45-jack-architecture'
D=Path(tempfile.mkdtemp(prefix='carrier-rj45-jack-architecture-'))
P=R/'projects/crow-mic-pod-v3'
paths=[R/'CLAUDE.md',R/'skills/pcb-design/references/connector-assembly-contract.md',
 P/'01_docs/BRIEF.md',P/'03_src/floorplan.yaml',P/'03_src/check_realized_routes.py',P/'03_src/rules/assembly.yaml',
 P/'02_parts/TPD2E2U06DRLR/part.yaml',P/'02_parts/TPD2E2U06DRLR/tpd2e2u06.pdf',P/'03_src/lib/crow_mic_pod_v3.pretty/TI_TPD2E2U06_DRL.kicad_mod',
 R/'projects/crow-audio-carrier-v1/01_docs/research/2026-09-12-rj45-source-backtrack.md',
 N/'manufacturer-kicad/J_Wurth_WR-MJ_615008160221.kicad_mod',N/'manufacturer-kicad/J_Wurth_WR-MJ_615008160121.kicad_mod',
 N/'manufacturer-kicad/J_Wurth_WR-MJ_615008160221.step',N/'jack-native-library-brep.json',
 Path('/tmp/carrier-rj45-harting-at0oel5v/06_build/task_runs/rj45-harting-completion/outputs/report.md')]
jroot=Path('/tmp/carrier-rj45-jack-selection-pntbys98')
for filename in ['wurth_615008160221.pdf','wurth_615008160121.pdf']:
 matches=list(jroot.rglob(filename));assert len(matches)==1,matches
 paths.append(matches[0])
(D/'input').mkdir()
for i,p in enumerate(paths):
 shutil.copyfile(p,D/'input'/f'{i:02d}-{p.name}')
shutil.copyfile('/tmp/carrier-rj45-cable-selection-hkl9acsz/preflight.py',D/'preflight.py')
now=datetime.now(timezone.utc);cut=now+timedelta(minutes=13);hard=now+timedelta(minutes=16)
task=f'''agent-role judgment, standard/full effort, fresh independent SOURCE ARCHITECTURE review. No live design or generated acceptance. User approved RJ45 ports/factory Cat6 patch cords for existing eight-pod 12V analog audio system. Root source-authoring in parallel; you only frozen input/scratch. Fresh live availability probe rj45-layout-availability closed PASS before this admission.

Resolve one concrete pre-layout choice without relaxing electrical protection: compact Wurth615008160221 Cat6 shielded plain8P8C with EMI panel fingers, vs Wurth615008160121 Cat6 shielded plain8P8C (no fingers). Exact Harting15mCat6A cord report included for mechanical context. Proposed map1/3/7+12V,2/6/8GND,5AUDIO+,4AUDIO-. Carrier shield to chassis at entry, isolated fromsignalGND; pod shell island isolated fromsignalground. NotEthernet/PoE, nohotplug. Pod60x40; carrier150x100 with32mmpitch north/southjacks. Existing required AUDIO pin->clamp maximum4.0mmpadcentre/4.2mmcopper,via-free,clampbeforebranch; existingchecker F.Cu-only and currentassembly bottomnone.

Root found221 manufacturerFP oddpinsy0,eveny4; bodyFPy-6.36..+7.09, so pin5>=7.09mm fromrearbody, cannotfit4.2mm exposed topclamp outsidebody. Agentinitialjackresearch geometry table was wrong (3.3mmrows and swapped4/5); do NOT use it. FrozenmanufactureroriginalFP with S1/S2 is source; modelmathY is opposite KiCadPCB Y. Only eventual projectpadrenamingS1->9/S2->10 andmodelpathadaptation intended, no geometry edits. NativeSTEPimport11solidsvalid; BREPbox includesfreeEMIfingers. Inspect primary drawings and TI actuallayoutprinciple, notjustreport.

Assess two explicit options: A)221 with ONLY U3 clamp bottom-side placed between its two signal rows, usingJ1platedthroughpads asdirectB.Cu origins (noaddedvia), B.Cu shortprefixes<=4.2mm andclampdominanceunchanged;groundpin4shortdirectlocalreturn. RestregulatorcriticalpathsF.Cu. Deliberateassembly2sides,model/clearance/silkscreen/CPLscopemustupdate. B)121 alltopESD: nativeFPmouth+X16.03,rearX-.47,oddrowx0/evenrowx2.54, henceP/Ncanexitrearshort; largerbodywidth16depth16.5 andseparatecompletechassiscontactassemblyowedwithoutEMIfingers. Preferlowesttotalengineeringburden, notautomaticcontinuationoldsideorcompactbody.

CanoptionA preserveelectricalphysics? IsrevisedEXACTlayercheckB.Cuonlyfortwoprefixes legitimate architecture or concealingdefect? IdentifyTHtail/mask/pad/bodyandgroundreturnrisksandotherrules needingexplicitgrade. OptionB requiresa realchassisbond; do notacceptuncontrolledmetalbodytouchorimaginedspring. No othercatalogsearch needed. If neither feasible, say preciseblocker. Suggestedcoordinates/routeconcept allowed but source-design feasibility only, noDRCorassembledfitclaim. Numericdistances frommanufacturerFP mustusecorrectframe and account U3courtyard againstTHpads onbottom. Do notincrease4.0/4.2limits, bypassdominance, changeMCU/analogICs, orweakenalllayersglobally. You may read actualrepo generator/owningrules for capabilities; recordextra inputhashes in evidence. No livewrites. Nativecompatibilityqualification root running separately; do notnativeexecute untilgivenPASS; offlineparsing/PDFimaging allowed.

Report clear SOUND/UNSOUND/INCOMPLETE peroption withselectedrecommendation, neededsource/gatechanges andphysicalfirstarticleholds. This is source decision evidence, not canonical pin/layout/renderreview. Allshell/native/PDF commandsvia pipeline_runtime.run_stage importedfrom {R}/skills/pcb-design/scripts. EveryPython/usr/bin/python3 -B. Rawlogs/runtimeargv/rc/times andactualviewedfigures inscratch, preservedefects;nochildren/network/installrequired. VerifyfrozeninputSHA/sizebeforeandafter. Keepprimaryevidencecopiesonlyifused,nohugecache.

Delivery5outputs exactlyreport.md,evidence.json,evidence-manifest.json,evidence.tar.gz,result.json. Archiveallnewmethods,rawlogs,viewedfigures. Manifestarchiveandeveryregularmemberpath/size/SHA. resultsubjectexactenvelope.subject; checks evidence-complete,inputs-verified,review-complete PASSforcompletedhonestreview regardlessengineeringverdict. Mandatorypreflight /usr/bin/python3 -B {D}/preflight.py {D}/06_build/task_runs/{name}/envelope.json BEFORE FINAL. Work/FINALcutoff{cut.isoformat()},hard{hard.isoformat()}; reservepackagingtime. Oneattempt,no replacement. RootobservesFINALandclosespromptly.
'''
(D/'TASK.md').write_text(task)
items=[]
for f in sorted(D.rglob('*')):
 if f.is_file():
  b=f.read_bytes();items.append({'name':f'input_{len(items):04d}','path':f.relative_to(D).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
subject=subject_identity('rj45_jack_architecture',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
e=TaskEnvelope(schema=2,task_id=name,stage_id='PCB-SOURCING',run_id=name,subject=subject,executor='reviewer',execution_class='review_wait',recommended_agent_role='judgment',agent_role='judgment',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']})
o=open_agent_attempt(e,cwd=D)
o.update(project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),agent_id='/root/carrier_rj45_jack_architecture',work_cutoff=cut.isoformat())
(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n')
print(json.dumps(o,indent=2))
