from pathlib import Path
from datetime import datetime,timezone,timedelta
import sys,json,hashlib,shutil,tempfile,difflib
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;C=N/'weid_source_candidate'
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
name='weid-integration-review';D=Path(tempfile.mkdtemp(prefix='carrier-weid-integration-review-'))
shutil.copytree(C,D/'candidate')
context=['CLAUDE.md','skills/pcb-design/SKILL.md','skills/pcb-design/references/execution-runtime.md','skills/pcb-design/references/connector-assembly-contract.md','skills/kicad-pcb/references/design-policies.md','projects/crow-audio-carrier-v1/01_docs/decisions/0007-prototype-before-physical-qualification.md','projects/crow-mic-pod-v3/01_docs/decisions/0005-first-article-only-release.md','projects/crow-audio-carrier-v1/03_src/rebuild_all.sh','projects/crow-audio-carrier-v1/03_src/rebuild_reuse.sh','projects/crow-mic-pod-v3/03_src/rebuild_all.sh','projects/crow-mic-pod-v3/03_src/rebuild_reuse.sh']
for rel in context:
 p=D/'context'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,p)
diff=[];changed=[]
for p in sorted(C.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(C).as_posix();b=p.read_bytes();base=R/rel
 changed.append({'path':rel,'size':len(b),'sha256':hashlib.sha256(b).hexdigest(),'baseline_sha256':hashlib.sha256(base.read_bytes()).hexdigest() if base.is_file() else None})
 if p.suffix in ['.py','.yaml','.json','.tsx','.md','.sh'] and p.name!='WEID_DRAFT_NOT_ADOPTED.md':
  diff.extend(difflib.unified_diff(base.read_text().splitlines(True) if base.exists() else [],b.decode().splitlines(True),fromfile='baseline/'+rel,tofile='candidate/'+rel))
(D/'source.diff').write_text(''.join(diff));(D/'candidate-manifest.json').write_text(json.dumps(changed,indent=2)+'\n')
prev=json.loads((N/'weid-source-review-opened.json').read_text());shutil.copytree(Path(prev['output_dir']),D/'prior-nominal-review')
for f in ['wurth-gigabit-jacks.html','wurth-gigabit-jacks-source.json','carrier-bottom-transform-corrected.json','weid-wiring.jpg']:
 p=D/'evidence'/f;p.parent.mkdir(exist_ok=True);shutil.copyfile(N/f,p)
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 for f in ['connector_assembly_contract.json','connector_assembly_source_gate.json']:
  src=N/'weid_validation/projects'/slug/'06_build/verification'/f;p=D/'evidence'/slug/f;p.parent.mkdir(exist_ok=True);shutil.copyfile(src,p)
for stem in ['weid-critical-path-tests-findings','weid-pod-shared-policy-tests','weid-carrier-entry-tests-owned','weid-jack-dc-source']:
 for suffix in ['.log','-runtime.json','-command.json']:
  shutil.copyfile(Path('/tmp/carrier-connector-integration-20260911')/(stem+suffix),D/'evidence'/(stem+suffix))
shutil.copyfile('/tmp/carrier-locator-implementation-availability-6c_4vwal/preflight.py',D/'preflight.py')
now=datetime.now(timezone.utc);cut=now+timedelta(minutes=23);hard=now+timedelta(minutes=26)
(D/'TASK.md').write_text(f'''Fresh independent engineering SOURCE integration review. User asks finish board and mint new release, authorizes factory Cat/RJ45 spokes; root sole live writer. Latest uncached availability probe actual FINAL and closed PASS at18:38Z. This is a required semantic review, not permission or a quota probe. Review frozen complete candidate and diff against baseline HEAD01fab37b. Candidate not adopted. Do NOT accept source merely because root tests pass. Read CLAUDE and relevant canon. No children. Read-only frozen packet; only allocated outputs/scratch writes. May read owning repo {R} and note/hash any extra files used. Do not edit live repo or frozen candidate. May build isolated temporary fixtures in scratch through bounded pipeline_runtime. No native full project conductor is requested; native board reviews follow source adoption.

Scope: independent ACCEPT/REJECT/INCOMPLETE of entire parent/carrier/pod RJ45 source integration for normal regeneration. Prior nominal-review accepts Weidmuller8909650150 exact manufacturer STEP plus explicit separate unknown installed radial/axial tolerances. Reopen that narrow judgment, not as full-board acceptance. Current source gates bothPASS0findings, physical unknown23carrier/9pod; existing carrierADR0007 permits physicalFULL INCOMPLETE for prototype progression afterSOURCE. Pod own firstarticleonly boundary must be honored separately. No production/outdoor/physical claim or new waiver.

Changed source includes8carrier+1pod Würth615008160221 jacks; exactthreeparallelpowerpairs,5AUDIO+4AUDIO-, factoryWeidmuller15mCat6A. ExactwiringprimaryT568B image;3copiedprotocolcontracts and original hostile/stale-byte guards retained. UVnull with outdoorhold, never transfer otherfamilyrating. ManufacturerJACK150VAC stays AC. Proposed pod E-SURGE J1fields28.5V are project insulation ceiling, NOTmanufacturerDCabsolute: exactjack listed manufacturerPoE++ compatible range;57V application/2xreserve=28.5,24.4*1.1=26.84. Assess whether this evidence+explicitboundedapplicationinference is defensible; reject if it would relabel unsupported ratings. May verify primary manufacturer pages if useful; no supplier contact/purchase.

CarrierB.CuESDplacement uses opposite sourcefliprotation to pod customfootprint; isolatednativeall16seeds now testedpadcentres1.935073mm, .20mmtracks. Eachprefixmax4.2mm,span4.0,0vias,B.Cuonly; allcapbranches mustfollowclamp. The old pod copper checker has been promoted perM8 to shared critical_path_check.py + critical_paths.yaml forbothboards. Podthincompatibilityentry retainsbothconductors; carrierexistinganalogchecker nowcalls shared backendbothsource/postroute. Shared graph rejects graded-net zones/arcs/unsplit-or-width-onlycontacts. Review graph soundness, prefixedgecut logic, pad/track/via and unsupportedgeometry, denominator/staleness, nativecensus binding and testcoverage. New10sharedtests8knownbad+1physicaldevicevacuity, existing10podpolicytests,5carrierentrytestsPASS. Initialharnesssetup/nativeunownedfp failures preserved inrootlogs; nofullboardpassclaimed. Carrier CHASSIS16shelllands getsown0.60mmouterlayerwave,class,localEMIfingerpanelbond; nosignalGNDtie/innerplaneuse. PodPOD_SHIELDstillisolated. Checkroutingowners,sourceplacement/tails/bottomassemblyconstraintsthatmustblocksource versusnativegeneration.

Source proposal includesfullold60files plus correction/currentADRs/firstarticleplans. Look for staleactivepromises, wrongschema, sourcepin/geometry/electricalregressions, gates bypassed, missing synchrony. Existingoldnativefixtures/censuses mayrequire legitimate updates afteractualregeneration; do not waive tests. Requireexplicit sourcefollow-up forrealdefects. Fullsourceadoptionnotroutingadmission: regenerateTSXthroughfullconductors, renewschematic/pin/placement/renderreviews andnormalroute/releasegates. LAYOUT001 remainsclosed3/3spent, no4thdiagnostic orresetbynewmodel.

Delivery report.md (domainverdict and precise prioritized findings or nextgate obligations), evidence.json, evidence-manifest.json, evidence.tar.gz, result.json. Archive your methods,rawcommands/logs andresults withhashverifiedregularmembers; denominatoractual. Mandatory preflight /usr/bin/python3 -B {D}/preflight.py {D}/06_build/task_runs/{name}/envelope.json. Everyengineeringchild uses pipeline_runtime.run_stage withfinitebudget. Verifyfrozeninputsbefore/after. Completionchecks inputs-verified,review-complete,evidence-complete canPASS forcompletedhonestREJECT domain; deliverynotengineeringacceptance. ActualFINAL by{cut.isoformat()}, harddeadline{hard.isoformat()}. Reserve3minpackaging. Zeroreplacements. Rootwillclosepromptly. Keep report legible with spaces, exact source locations and actionable corrections.
''')
items=[]
for p in sorted(D.rglob('*')):
 if p.is_file():
  b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(D).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
s=subject_identity('weid_integration_review',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
e=TaskEnvelope(schema=2,task_id=name,stage_id='PCB-SOURCING',run_id=name,subject=s,executor='reviewer',execution_class='review_wait',recommended_agent_role='judgment',agent_role='judgment',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']})
o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),agent_id='/root/carrier_weid_integration_review',work_cutoff=cut.isoformat());(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o));print(len(items),'frozen input files',len(changed),'candidate files')
