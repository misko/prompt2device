from pathlib import Path
import shutil
N=Path(__file__).parent;C=N/'weid_source_candidate';p=C/'skills/kicad-pcb/scripts/critical_path_check.py';s=p.read_text()
pos=s.index('def assert_graph_contacts')
new='''def pad_local(pad, point):
    angle = math.radians(pad['angle'])
    dx,dy = point[0]-pad['x'], point[1]-pad['y']
    return (dx*math.cos(angle)-dy*math.sin(angle),
            dx*math.sin(angle)+dy*math.cos(angle))


def pad_box_distance(pad, a, b):
    """Conservative contact screen against a rotated pad bounding rectangle.

    A near miss at a rounded corner may be refused. It can never be accepted
    as copper merely because the rectangle reaches farther than the land.
    """
    a,b = pad_local(pad,a),pad_local(pad,b)
    hx,hy = pad['sx']/2,pad['sy']/2
    if any(abs(x)<=hx and abs(y)<=hy for x,y in (a,b)):
        return 0.
    vertices=[(-hx,-hy),(hx,-hy),(hx,hy),(-hx,hy)]
    return min(segment_distance(a,b,c,d) for c,d in zip(vertices,vertices[1:]+vertices[:1]))


def verified_pad_hit(pad, point, copper):
    """Guarantee every graph anchor is within actual supported land geometry.

    The shared length reader's 2 um tolerance/roundrect rectangle is broader
    than this protection proof permits. Refuse ambiguous anchors; an inscribed
    ellipse is a conservative subset of a roundrect without guessing its radius.
    """
    graph_hit = copper._point_in_pad(pad,*point)
    if graph_hit:
        x,y = pad_local(pad,point);hx,hy=pad['sx']/2,pad['sy']/2
        if pad['shape'] in ('circle','oval','roundrect'):
            proven = (x/hx)**2+(y/hy)**2 <= 1.+1e-12
        else:
            proven = abs(x)<=hx+1e-12 and abs(y)<=hy+1e-12
        if not proven:
            raise AuditError(f"{pad['ref']}.{pad['pad']}: ambiguous pad boundary/rounded-corner graph anchor")
    return graph_hit


'''
s=s[:pos]+new+s[pos:]
# Refuse unsupported pad shapes and duplicate identities on every selected net.
s=s.replace('    segs = []\n', '''    seen_pads = set()
    for pad in pads:
        ident = (pad['ref'],pad['pad'])
        if ident in seen_pads or pad['shape'] not in {'rect','roundrect','circle','oval'}:
            raise AuditError(f"{net}: duplicate or unsupported pad {ident}")
        if not all(math.isfinite(pad[k]) and pad[k]>0 for k in ('sx','sy')):
            raise AuditError(f"{net}: invalid pad dimensions")
        seen_pads.add(ident)
    segs = []
''',1)
needle='    for i, (la,a,b,wa,line) in enumerate(segs):'
insert='''    # A physical connection to a pad must be present as an endpoint anchor.
    # Otherwise pad-interior or track-width contact could create a bypass that
    # the endpoint-only graph incorrectly treats as disconnected copper.
    for la,a,b,w,line in segs:
        for pad in pads:
            if not copper._pad_has_layer(pad,la):
                continue
            hit = [verified_pad_hit(pad,pt,copper) for pt in (a,b)]
            if not any(hit) and pad_box_distance(pad,a,b) <= w/2+1e-7:
                raise AuditError(f"{net}: unrepresented pad-track contact at {pad['ref']}.{pad['pad']}")
    # Distinct touching lands are not joined by the endpoint graph. Refuse a
    # conservative bounding-box overlap even if native DRC may later clear it.
    for i,pad in enumerate(pads):
        for other in pads[i+1:]:
            if not any(copper._pad_has_layer(pad,l) and copper._pad_has_layer(other,l) for l in set(pad['layers']+other['layers']) if l.endswith('.Cu')):
                continue
            angle=math.radians(other['angle']);co,si=math.cos(angle),math.sin(angle)
            hx,hy=other['sx']/2,other['sy']/2
            corners=[(other['x']+x*co+y*si,other['y']-x*si+y*co) for x,y in [(-hx,-hy),(hx,-hy),(hx,hy),(-hx,hy)]]
            if pad_box_distance(pad,(other['x'],other['y']),(other['x'],other['y'])) == 0. or any(pad_box_distance(pad,a,b)<=1e-7 for a,b in zip(corners,corners[1:]+corners[:1])):
                raise AuditError(f"{net}: potentially touching distinct pads {pad['ref']}.{pad['pad']} / {other['ref']}.{other['pad']}")
'''
assert needle in s;s=s.replace(needle,insert+needle,1)
# Pre-validate actual via pad contacts too; the graph joins via centers only.
needle='        for la,a,b,w,line in segs:\n            if point_segment_distance'
insert='''        for pad in pads:
            # Through vias conservatively visit every declared copper layer;
            # unsupported blind-span precision must not hide a possible bond.
            hit = verified_pad_hit(pad,at,copper)
            if not hit and pad_box_distance(pad,at,at) <= float(size[1])/2+1e-7:
                raise AuditError(f"{net}: unrepresented pad-via contact at {pad['ref']}.{pad['pad']}")
        for la,a,b,w,line in segs:
            if point_segment_distance'''
assert needle in s;s=s.replace(needle,insert,1)
# Update both schema homes without moving their source authority.
s=s.replace('on graded nets are refused rather than silently omitted from the graph.', 'and unrepresented pad contacts on graded nets are refused rather than silently\nomitted from the graph. Rounded-pad anchor ambiguity is conservatively refused.')
p.write_text(s);shutil.copyfile(p,N/'weid_validation/skills/kicad-pcb/scripts'/p.name)
print('pad contact omission repaired; native RED controls must turn GREEN')
