from pathlib import Path
import shutil,sys,runpy
N=Path(__file__).parent;V=N/'weid_validation';D=N/'critical_red_backend'
shutil.copytree(V/'skills/kicad-pcb/scripts',D,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
shutil.copyfile(N/'critical-path-before-pad-contact.py',D/'critical_path_check.py')
shutil.copyfile('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/kicad-pcb/scripts/copper_length_audit.py',D/'copper_length_audit.py')
sys.path.insert(0,str(V/'tests'));import harness
harness.SCRIPTS=D
sys.path.insert(0,str(D))
runpy.run_path(str(V/'tests/t1_critical_path_check.py'),run_name='__main__')
