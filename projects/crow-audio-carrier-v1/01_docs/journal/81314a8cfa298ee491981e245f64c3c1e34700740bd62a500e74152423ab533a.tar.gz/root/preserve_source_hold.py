from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import hashlib,json,tarfile,io,gzip,sys,subprocess
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;V=N/'source_validation';I=Path('/tmp/carrier-connector-integration-20260911')
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
import connector_assembly_contract as base
import connector_assembly_phase_gate as phase
roots={
 'architecture':Path('/tmp/carrier-rj45-jack-architecture-9qb5jr6a'),
 'protocol_author':Path('/tmp/carrier-rj45-spoke-protocol-afdhti9e'),
 'pod_author':Path('/tmp/carrier-rj45-pod-source-xokt7662'),
 'fresh_availability':Path('/tmp/carrier-rj45-source-hold-availability-137ohynk'),
 'source_hold_review':Path('/tmp/carrier-rj45-source-hold-review-jjvxiau6')}
payload={};checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def add(name,p):
 assert not p.is_symlink(),p
 assert name not in payload,name
 payload[name]=p.read_bytes()
def verify(b,row):assert len(b)==row['size'] and sha(b)==row['sha256'],row
for label,root in roots.items():
 env=next(root.glob('06_build/task_runs/*/envelope.json'));e=json.loads(env.read_text());attempt=json.loads((env.parent/'attempt.json').read_text());assert attempt['status']=='PASS',(label,attempt['status'])
 for row in e['input_packet']:verify((root/row['path']).read_bytes(),row)
 outputs=list((env.parent/'outputs').iterdir());result=json.loads((env.parent/'outputs/result.json').read_text());assert result['subject']==e['subject'],label
 row={'task':label,'status':attempt['status'],'inputs_reopened':len(e['input_packet']),'outputs_reopened':len(outputs)}
 if (env.parent/'outputs/evidence-manifest.json').is_file():
  m=json.loads((env.parent/'outputs/evidence-manifest.json').read_text());ar=env.parent/'outputs'/m['archive']['path'];verify(ar.read_bytes(),m['archive'])
  with tarfile.open(ar,'r:gz') as t:
   members=t.getmembers();names=[a.name for a in members];assert len(set(names))==len(names)
   for a in members:
    pp=PurePosixPath(a.name);assert not pp.is_absolute() and '..' not in pp.parts and not a.issym() and not a.islnk()
   declared=m['members'];assert set(x['path'] for x in declared)==set(a.name for a in members if a.isfile()),label
   for rec in declared:verify(t.extractfile(rec['path']).read(),rec)
   row['original_archive_members_reopened']=len(declared)
 for p in sorted(root.rglob('*')):
  if p.is_file():add('agents/'+label+'/'+p.relative_to(root).as_posix(),p)
 checks.append(row)
# Keep exact original and corrected root proposals, not only their success logs.
for directory in ['component_source_candidate','protocol_source_candidate','carrier_source_candidate','integrated_source_candidate']:
 for p in sorted((N/directory).rglob('*')):
  if p.is_file():add('root/'+p.relative_to(N).as_posix(),p)
for p in sorted(N.iterdir()):
 if p.is_file() and p.suffix in {'.py','.json','.png','.txt','.md'} and p.name not in {'source-hold-preservation.json'}:
  add('root/'+p.name,p)
for p in sorted(I.glob('rj45-*')):
 if p.is_file() and not p.name.startswith('rj45-source-hold-preservation'):
  add('root/runtime/'+p.name,p)
receipt_checks=[]
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 project=V/'projects'/slug;d=project/'06_build/verification'
 br=json.loads((d/'connector_assembly_contract.json').read_text());pr=json.loads((d/'connector_assembly_source_gate.json').read_text())
 good,problems=base.validate_receipt(br,project);assert good,problems
 good,problems=phase.validate_phase_gate(pr,project,expected_phase='source');assert good,problems
 assert br['status']==pr['status']=='INCOMPLETE'
 for p in d.iterdir():
  if p.is_file():add('validation/'+p.relative_to(V).as_posix(),p)
 # Store every base evidence byte so regrading needs no temporary-path facts.
 source_paths={x['path'] for x in br['inputs']['evidence_files']}|{'03_src/rules/connector_assemblies.yaml','03_src/rules/connector_assembly_phases.yaml'}
 for rel in sorted(source_paths):add('validation_support/projects/'+slug+'/'+rel,project/rel)
 receipt_checks.append({'project':slug,'base_valid':True,'source_valid':True,'status':'INCOMPLETE','base_summary':br['summary'],'source_summary':pr['summary'],'findings':pr['findings']})
for rel in ['skills/pcb-design/scripts/connector_assembly_contract.py','skills/pcb-design/scripts/connector_assembly_phase_gate.py','skills/pcb-design/references/connector-assembly-contract.md']:
 add('validation_support/'+rel,R/rel)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
audit={'created_at':datetime.now(timezone.utc).isoformat(),'baseline_commit':head,'completed_delivery_reopens':checks,'receipt_reopens':receipt_checks,'prior_source_archive':'168cb286ee392f49e1ec95ab9e66077b0069bb63ca653665095a3d7262204160','scope':'Held draft and source-stage INCOMPLETE evidence. No live source adoption, generated PCB, routing or release acceptance. Original rejected proposals and raw failures remain intact. Root final rotations/prose changes postdate the frozen review; no claim that it reviewed those later bytes.'}
payload['ROOT_REOPEN_AUDIT.json']=(json.dumps(audit,indent=2)+'\n').encode()
payload['README.md']=b'''# Held RJ45 source draft\n\nStart with ROOT_REOPEN_AUDIT.json and root/draft-integration-debt.json.\nThe changed-file overlay is root/integrated_source_candidate/ (60 files),\nbound by root/integrated-source-manifest.json. Apply only in a fresh isolated\ncopy of the stated baseline after resolving source evidence and completing\nreview; it is not admitted live source. Original agent and root candidates,\nincluding rejected proposals, remain in separate paths.\n\nThe source phase is INCOMPLETE on both boards because mate and grip envelopes\nare unknown. Do not run the conductor, prepare a coupon or route around it.\nSource author reports and delivery PASS do not grant engineering acceptance.\nNative integrations, carrier route protection and shell paths remain owed.\nThe validation_support/ subtree retains all files bound by the held connector\nreceipts; reconstruct normal project paths before regrading with the stated\nbaseline's compiler. No artifact outside this archive under /tmp is authority.\n'''
manifest={'schema':1,'files':[{'path':n,'size':len(b),'sha256':sha(b)} for n,b in sorted(payload.items())]}
out=N/'source-hold-preservation.tmp'
with out.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for name,b in sorted({**payload,'MANIFEST.json':(json.dumps(manifest,indent=2)+'\n').encode()}.items()):
    info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;t.addfile(info,io.BytesIO(b))
with tarfile.open(out,'r:gz') as t:
 members=t.getmembers();assert len({m.name for m in members})==len(members)==len(payload)+1
 assert all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in members)
 assert json.loads(t.extractfile('MANIFEST.json').read())==manifest
 for rec in manifest['files']:verify(t.extractfile(rec['path']).read(),rec)
h=sha(out.read_bytes());dest=R/'projects/crow-audio-carrier-v1/01_docs/journal'/(h+'.tar.gz');assert not dest.exists();out.rename(dest)
summary={'path':str(dest),'sha256':h,'size':dest.stat().st_size,'payload_members':len(payload),'completed_delivery_reopens':checks,'receipt_reopens':receipt_checks,'baseline_commit':head}
(N/'source-hold-preservation.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
