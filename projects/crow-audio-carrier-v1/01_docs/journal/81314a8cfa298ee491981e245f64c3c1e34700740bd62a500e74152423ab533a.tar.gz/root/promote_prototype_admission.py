from pathlib import Path
import re
N=Path(__file__).parent;C=N/'weid_source_candidate';R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
def read(rel):return ((C/rel) if (C/rel).exists() else R/rel).read_text()
def put(rel,s):
 p=C/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
shared='''#!/usr/bin/env bash
# Shared mechanics for a project whose accepted ADR already authorizes an
# unqualified prototype. This script creates no authorization or physical PASS.
# Usage: bash connector_prototype_admission.sh PY CS STAGE ADR [--compile-base]
set -euo pipefail
PY="${1:?Python interpreter required}"
CS="${2:?PCB design scripts directory required}"
stage="${3:?Stage label required}"
decision="${4:?Existing project prototype decision required}"
case "$decision" in
    01_docs/decisions/*.md) ;;
    *) echo "Prototype decision must be a project decision record" >&2; exit 1 ;;
esac
if [ ! -s "$decision" ] || [ -L "$decision" ]; then
    echo "Missing or nonregular prototype decision: $decision" >&2; exit 1
fi
case "${5:-}" in
    "") [ "$#" -eq 4 ] ;;
    --compile-base)
        [ "$#" -eq 5 ]
        base_rc=0
        "$PY" "$CS/connector_assembly_contract.py" --project . \\
            --contract 03_src/rules/connector_assemblies.yaml \\
            --output 06_build/verification/connector_assembly_contract.json || base_rc=$?
        case "$base_rc" in
            0|2) ;;
            *) echo "$stage invalid connector base authority" >&2; exit "$base_rc" ;;
        esac
        ;;
    *) echo "Unknown prototype admission option" >&2; exit 1 ;;
esac
# SOURCE reopens exact base/compiler/contract/evidence/policy bytes, rejects
# unclassified source unknowns, and requires actual connector identities.
"$PY" "$CS/connector_assembly_phase_gate.py" --project . --phase source \\
    --contract 03_src/rules/connector_assemblies.yaml \\
    --policy 03_src/rules/connector_assembly_phases.yaml \\
    --base-receipt 06_build/verification/connector_assembly_contract.json \\
    --output 06_build/verification/connector_assembly_source_gate.json
full_rc=0
"$PY" "$CS/connector_assembly_phase_gate.py" --project . --phase full \\
    --contract 03_src/rules/connector_assemblies.yaml \\
    --policy 03_src/rules/connector_assembly_phases.yaml \\
    --base-receipt 06_build/verification/connector_assembly_contract.json \\
    --output 06_build/verification/connector_assembly_full_gate.json || full_rc=$?
case "$full_rc" in
    0) echo "$stage CONNECTOR-FULL closed; independent geometry/review gates still required" ;;
    2) echo "$stage CONNECTOR-FULL INCOMPLETE: $decision admits prototype design only. Physical fit/service remains owed. FIRST-ARTICLE-ONLY / DO-NOT-ORDER." ;;
    *) echo "$stage CONNECTOR-FULL invalid authority; prototype admission rejected" >&2; exit "$full_rc" ;;
esac
'''
put('skills/pcb-design/scripts/connector_prototype_admission.sh',shared)
put('projects/crow-audio-carrier-v1/03_src/check_connector_prototype.sh','''#!/usr/bin/env bash
# Compatibility entry point under existing user-accepted carrier ADR0007.
# The common SOURCE/FULL mechanics live once in the shared PCB design backend.
set -euo pipefail
PY="${1:?Python interpreter required}"
CS="${2:?PCB design scripts directory required}"
stage="${3:?Stage label required}"
exec bash "$CS/connector_prototype_admission.sh" "$PY" "$CS" "$stage" \\
    01_docs/decisions/0007-prototype-before-physical-qualification.md
''')
P='projects/crow-mic-pod-v3'
for name in ['rebuild_all.sh','rebuild_reuse.sh']:
 rel=P+'/03_src/'+name;s=read(rel)
 pattern=r'\$PY "\$CS/connector_assembly_contract.py" --project \. \\\n    --contract 03_src/rules/connector_assemblies.yaml \\\n    --output 06_build/verification/connector_assembly_contract.json \\\n    \|\| \{[^\n]+\}\n'
 repl='''# ADR0005 permits a nonorderable candidate with planned physical unknowns.
# Shared SOURCE/FULL admission preserves every unknown and rejects invalid or
# unclassified authority before TSX, placement or route work.
bash "$CS/connector_prototype_admission.sh" "$PY" "$CS" "[connector]" \\
    01_docs/decisions/0005-first-article-only-release.md --compile-base
'''
 s,n=re.subn(pattern,lambda m:repl,s);assert n==1,(name,n)
 s=s.replace('# Unknown mate/tool/cable/torque/tolerance/operation evidence stops here before\n# schematic or layout spend.', '# Unknown SOURCE facts stop here; classified physical qualification remains\n# visible under the previously accepted first-article-only prototype decision.')
 put(rel,s)
rel='skills/pcb-design/contracts.md';put(rel,read(rel)+'''\n- `scripts/connector_prototype_admission.sh PY CS STAGE ADR [--compile-base]`
  shares mechanics formerly in a single project's admission helper. Call only
  from a project with an independently accepted prototype decision. SOURCE
  must pass against exact current bytes. FULL is always graded and remains
  INCOMPLETE when physical unknowns remain; only exact rc2 after SOURCE success
  can continue, labeled FIRST-ARTICLE-ONLY / DO-NOT-ORDER. Invalid, stale and
  unclassified authority is fatal. This creates no release/order authorization.
  Clean and hostile cases are in `t1_connector_assembly_phase_gate.py`.
''')
rel='skills/pcb-design/templates/contracts/03_src/contracts.md';put(rel,read(rel)+'''\nA project with an already accepted unqualified-prototype decision may invoke
shared `connector_prototype_admission.sh` with that exact project ADR. This
requires SOURCE success and retains a separately graded FULL receipt; only
classified physical INCOMPLETE permits continued prototype work. It does not
change connector schemas, source/physical grades, native reviews or order gates.
Absent an accepted project decision, retain the ordinary full qualification bar.
''')
for slug in ['projects/crow-audio-carrier-v1',P]:
 rel=slug+'/03_src/contracts.md';put(rel,read(rel)+'''\nConnector prototype admission uses shared `connector_prototype_admission.sh`
under the existing accepted project ADR (carrier0007, pod0005 respectively).
SOURCE must pass; FULL rc2 remains a visible physical qualification debt.
Malformed/stale/FAIL authority and nonphysical unknowns stay fatal. Native
schematic, placement, route and release gates are unchanged; DO-NOT-ORDER.
''')
print('shared admission and both existing project call sites prepared')
