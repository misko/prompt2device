from pathlib import Path
import importlib.util,sys,unittest
p=Path('/tmp/carrier-rj45-20260912/weid_validation/projects/crow-mic-pod-v3/03_src/tests/test_check_spoke_implementation.py')
s=importlib.util.spec_from_file_location('pod_spoke_tests',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
all_names=unittest.defaultTestLoader.getTestCaseNames(m.SpokeCheckerHostiles)
native='test_live_project_contract_and_generated_artifacts_pass'
assert native in all_names
names=[n for n in all_names if n!=native]
print('Pure checker suite:',len(names),'selected; unchanged native integration case remains OWED until admitted regeneration',flush=True)
r=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(m.SpokeCheckerHostiles(n) for n in names))
sys.exit(0 if r.wasSuccessful() else 1)
