from pathlib import Path
import shutil
N=Path(__file__).parent;C=N/'weid_source_candidate';V=N/'weid_validation'
p=C/'tests/t1_critical_path_check.py';s=p.read_text();assert 'def native_pad_modifier' not in s
extra=r'''
def native_pad_modifier(kind):
    # Independent second review found both classes falsely accepted after the
    # first geometry fix. Verify disconnected copper through native KiCad.
    import pcbnew
    V=lambda x,y:pcbnew.VECTOR2I(pcbnew.FromMM(x),pcbnew.FromMM(y))
    b=pcbnew.BOARD();b.SetCopperLayerCount(2);net=pcbnew.NETINFO_ITEM(b,'AUDIO');b.Add(net)
    for ref,num,x,size in [('J1','5',10,1.),('U1','3',12,.4),('C1','1',16,.4)]:
        f=pcbnew.FOOTPRINT(b);f.SetReference(ref);f.SetPosition(V(x,10));b.Add(f)
        p=pcbnew.PAD(f);p.SetNumber(num);p.SetAttribute(pcbnew.PAD_ATTRIB_SMD);p.SetShape(pcbnew.PAD_SHAPE_RECT)
        p.SetSize(V(size,size));ls=pcbnew.LSET();ls.AddLayer(pcbnew.B_Cu);p.SetLayerSet(ls);p.SetPosition(f.GetPosition());p.SetNet(net);f.Add(p)
        if ref=='J1':
            if kind=='chamfer':p.SetShape(pcbnew.PAD_SHAPE_CHAMFERED_RECT);p.SetChamferRectRatio(.5);p.SetChamferPositions(15)
            else:p.SetOffset(V(0,1.))
    for a,y,c,z in [(10.3 if kind=='chamfer' else 10,10.3 if kind=='chamfer' else 10,12,10),(12,10,16,10)]:
        t=pcbnew.PCB_TRACK(b);t.SetStart(V(a,y));t.SetEnd(V(c,z));t.SetLayer(pcbnew.B_Cu);t.SetWidth(pcbnew.FromMM(.02 if kind=='chamfer' else .2));t.SetNet(net);b.Add(t)
    path=tmpdir()/'modifier.kicad_pcb';pcbnew.SaveBoard(str(path),b);n=pcbnew.LoadBoard(str(path));n.BuildConnectivity()
    pad=next(p for f in n.GetFootprints() if f.GetReference()=='J1' for p in f.Pads())
    eq(len(n.GetConnectivity().GetConnectedTracks(pad)),0,'native modified pad is disconnected')
    cfg=copy.deepcopy(CONFIG);cfg['layers']=['F.Cu','B.Cu'];cfg['stackup_mm']=[1.6]
    policy=path.with_suffix('.yaml');policy.write_text(yaml.safe_dump(cfg))
    return run([KPY,str(SCRIPTS/'critical_path_check.py'),str(path),'--config',str(policy)])

@test('native chamfer modifiers cannot be mistaken for a filled rounded land',kind='known_bad')
def native_chamfer():must_fail(native_pad_modifier('chamfer'),'native chamfer false connection',expect='unsupported pad geometry')

@test('native offset copper cannot be mistaken for the pad anchor',kind='known_bad')
def native_offset():must_fail(native_pad_modifier('offset'),'native offset false connection',expect='unsupported pad geometry')

'''
p.write_text(s.replace("if __name__=='__main__':sys.exit(main())",extra+"if __name__=='__main__':sys.exit(main())"))
shutil.copyfile(p,V/'tests'/p.name)
shutil.copyfile(C/'skills/kicad-pcb/scripts/critical_path_check.py',N/'critical-path-before-pad-modifiers.py')
