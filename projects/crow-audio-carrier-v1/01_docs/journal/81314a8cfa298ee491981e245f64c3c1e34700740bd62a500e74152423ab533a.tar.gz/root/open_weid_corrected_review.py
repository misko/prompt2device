from pathlib import Path
from datetime import datetime,timezone,timedelta
import sys,json,hashlib,shutil,tempfile,difflib
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;C=N/'weid_source_candidate'
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
name='weid-corrected-review';D=Path(tempfile.mkdtemp(prefix='carrier-weid-corrected-review-'))
shutil.copytree(C,D/'candidate')
context=['CLAUDE.md','skills/pcb-design/SKILL.md','skills/pcb-design/references/execution-runtime.md','skills/pcb-design/references/connector-assembly-contract.md','skills/kicad-pcb/references/design-policies.md','projects/crow-audio-carrier-v1/01_docs/decisions/0007-prototype-before-physical-qualification.md','projects/crow-mic-pod-v3/01_docs/decisions/0005-first-article-only-release.md','projects/crow-audio-carrier-v1/03_src/rebuild_all.sh','projects/crow-audio-carrier-v1/03_src/rebuild_reuse.sh','projects/crow-mic-pod-v3/03_src/rebuild_all.sh','projects/crow-mic-pod-v3/03_src/rebuild_reuse.sh']
for rel in context:
 p=D/'context'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,p)
diff=[];changed=[]
for p in sorted(C.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(C).as_posix();b=p.read_bytes();base=R/rel
 changed.append({'path':rel,'size':len(b),'sha256':hashlib.sha256(b).hexdigest(),'baseline_sha256':hashlib.sha256(base.read_bytes()).hexdigest() if base.is_file() else None})
 if p.suffix in ['.py','.yaml','.json','.tsx','.md','.sh'] and p.name!='WEID_DRAFT_NOT_ADOPTED.md':
  diff.extend(difflib.unified_diff(base.read_text().splitlines(True) if base.exists() else [],b.decode().splitlines(True),fromfile='baseline/'+rel,tofile='candidate/'+rel))
(D/'source.diff').write_text(''.join(diff));(D/'candidate-manifest.json').write_text(json.dumps(changed,indent=2)+'\n')
prev=json.loads((N/'weid-integration-review-opened.json').read_text());shutil.copytree(Path(prev['output_dir']),D/'prior-integration-review')
for f in ['wurth-gigabit-jacks.html','wurth-gigabit-jacks-source.json','carrier-bottom-transform-corrected.json','weid-wiring.jpg']:
 p=D/'evidence'/f;p.parent.mkdir(exist_ok=True);shutil.copyfile(N/f,p)
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 for f in ['connector_assembly_contract.json','connector_assembly_source_gate.json','connector_assembly_full_gate.json']:
  src=N/'weid_validation/projects'/slug/'06_build/verification'/f;p=D/'evidence'/slug/f;p.parent.mkdir(exist_ok=True);shutil.copyfile(src,p)
for stem in ['weid-complete-contact-green','weid-complete-contact-red','weid-pad-angle-green','weid-shared-length-regressions','weid-shared-admission-extended','weid-carrier-entry-corrected','weid-plan-bound-receipts','weid-source-schema-governance','weid-skill-contract-sync','weid-new-adr-bound-governance','weid-carrier-source-policy','weid-pod-source-policy']:
 for suffix in ['.log','-runtime.json','-command.json']:
  shutil.copyfile(Path('/tmp/carrier-connector-integration-20260911')/(stem+suffix),D/'evidence'/(stem+suffix))
shutil.copyfile('/tmp/carrier-locator-implementation-availability-6c_4vwal/preflight.py',D/'preflight.py')
now=datetime.now(timezone.utc);cut=now+timedelta(minutes=18);hard=now+timedelta(minutes=21)
(D/'TASK.md').write_text(f"""Required fresh independent corrected SOURCE integration review for the factory RJ45 parent/carrier/pod proposal. Root sole live writer; no candidate has been adopted. Fresh availability completed and closed PASS at19:02Z. You are read-only; no children. Inspect CLAUDE and relevant canon in context. Verify frozen input packet before and after work. Use only allocated output/scratch writes. Additional repo reads at {R} are allowed but bind extra bytes used. Use pipeline_runtime.run_stage for every engineering subprocess, with finite budgets. No full project conductor; normal native generation follows accepted source.

Grade the exact complete candidate for SOURCE adoption and normal regeneration, independently of root's tests. Prior integration review is preserved in prior-integration-review and REJECTED its frozen proposal. Its affirmative architecture/CAD/DC-assessment conclusions are evidence of that narrow review, not acceptance of these bytes. Reopen the five actionable findings and the current correction delta. Candidate source.diff compares every file to baseline01fab37b. The current shared copper_length_audit.py is included in candidate; do not accidentally import old context versions.

Corrections: shared critical_path_check.py now conservatively refuses pad/track interior and width-only contact, via annulus contacts, distinct overlapping pads, ambiguous rounded-pad anchors, through-via interior-layer contacts and off-center/intermediate plated-pad transitions the inherited endpoint graph cannot faithfully represent. It uses actual saved absolute pad angle after correcting copper_length_audit.py. Critical path suite19/19 PASS; all8 newly discriminating cases FAIL against the old backend, including the independent review's native cases. Existing shared R-LEN34/34 PASS via immutable real repo fixtures and candidate backend. Every independent native fixture's connectivity controls are asserted before the text checker is invoked. Scrutinize whether unsupported physical contacts, shape, quantization, orientation, via spans or PTH still cause a false PASS. Conservative refusal is permitted; false PASS is not. Check ordinary valid topology still admitted and absence of copper/empty denominators fail. Geometric clamp path proof does not claim a functioning ESD device; the standing vacuity fixture demonstrates this.

Both connector contracts now bind FIRST_ARTICLE_TEST_PLAN.md as qualification-plan source; every factory-spoke physical unknown and its phase plan_source_ids includes it. Renewed receipt validators reopen exact evidence/compiler/policy bytes: carrier SOURCE PASS23 admitted zero findings, pod SOURCE PASS9 admitted zero; FULL valid INCOMPLETE23/9. This is not measured physical fit. Nominal mate/boot/sleeve57.98mm axial and22.986mm cylindrical grip retain explicit unknown installed radial/axial tolerances. Exact15m Weidmuller8909650150 Cat6A, Würth615008160221 jack, pin5AUDIO+4AUDIO-, straightT568B, unknown UV/outdoor hold unchanged. No rating transfer or imaginary manufactured maxima. E-SURGE project28.5V ceiling remains project assessment not150VAC relabeling; prior independent review supports the bounded inference but no transient proof.

Shared connector_prototype_admission.sh mechanically implements existing project authorization: carrier ADR0007 and pod ADR0005, both included in context. Carrier thin wrapper preserves invocation. Pod full/reuse conductors use shared helper --compile-base before TSX; SOURCE must succeed, FULL always runs, exact rc2 after SOURCE permits prototype only with FIRST-ARTICLE-ONLY / DO-NOT-ORDER. Invalid/stale/unclassified facts remain fatal. Existing15 plus4 new admission tests all19PASS,15knownbad. Human accepted decision is caller authority, not fabricated by shell file existence. No new release/order/outdoor/physical authorization. Review the adapter and both actual conductor call sites.

The16 carrier bottom entry seeds and shared source/native gate remain:4.0mm span4.2mm copper, B.Cu no vias, clamp prefix must dominate coupling paths. Carrier entry5/5 tests confirm isolated all16 native lands, not populated clearance. CHASSIS16lands own0.60mm outer-layer routing class and panel local bonds; no GND tie. Parent protocol copies remain synchronized. Exact source layouts/footprints/TSX/dossiers/plans included. Identify any unaddressed source-level regression. Source-schema governance914/914 keys809proven,0orphans across173files; six preexisting ungoverned families reported. Skill-contract sync2/2 including hostile control, both source part-layout checks2/2. ADR bound scan of3proposalADRs reports no recognized inequality blocks; this means its arithmetic regeneration denominator is zero, not arithmetic proof. Assess any actual newly published bound obligations honestly.

Verdict ACCEPT/REJECT/INCOMPLETE of complete current source for normal regeneration. No whole-board or release acceptance. If accepted, spell out required next gates: full TSX conductor for both boards, renewed schematic/pin/placement/render/native census, all source/saved-copper/route/DRC/release checks. Existing native old Micro-Fit fixtures may need updates only after actual generation. LAYOUT001 remains closed3/3 with no fourth diagnostic/reset. Do not create new coupon/user permission gate; physical first-article timing already authorized.

Delivery report.md,evidence.json,evidence-manifest.json,evidence.tar.gz,result.json. Archive frozen source and your native test methods/commands/logs with regular-member hashes. Completion checks evidence-complete,inputs-verified,review-complete can PASS for an honestly completed REJECT; they are not engineering acceptance. Mandatory final preflight: /usr/bin/python3 -B {D}/preflight.py {D}/06_build/task_runs/{name}/envelope.json. Initial full preflight refuses absent outputs by design; independently check initial hashes then run full final preflight after delivery. Actual FINAL by{cut.isoformat()}, hard{hard.isoformat()}, reserve3min packaging, zero replacements. Root closes after actualFINAL. Use readable sentences and precise actionable findings.
""")
items=[]
for p in sorted(D.rglob('*')):
 if p.is_file():
  b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(D).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
s=subject_identity('weid_integration_review',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
e=TaskEnvelope(schema=2,task_id=name,stage_id='PCB-SOURCING',run_id=name,subject=s,executor='reviewer',execution_class='review_wait',recommended_agent_role='judgment',agent_role='judgment',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']})
o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),agent_id='/root/carrier_weid_corrected_review',work_cutoff=cut.isoformat());(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o));print(len(items),'frozen input files',len(changed),'candidate files')
