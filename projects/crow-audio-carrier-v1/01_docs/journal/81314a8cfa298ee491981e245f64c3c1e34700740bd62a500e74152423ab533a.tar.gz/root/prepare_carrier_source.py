from pathlib import Path
import copy,hashlib,json,re,yaml
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;P=R/'projects/crow-audio-carrier-v1';C=N/'carrier_source_candidate/projects/crow-audio-carrier-v1'
def put(rel,s):
 p=C/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def load(rel):return yaml.safe_load((P/rel).read_text())
def dump(rel,v):put(rel,yaml.safe_dump(v,sort_keys=False))
s=(P/'03_src/floorplan.yaml').read_text()
for i in range(1,9):
 oldy=31.0 if i<=4 else 109.0;newy=25.86 if i<=4 else 114.14
 s,n=re.subn(r'(    J'+str(i)+r': \[[^,]+, )'+str(oldy)+r'(, [^\]]+\])',lambda m:m[1]+str(newy)+m[2],s);assert n==1,i
s=s.replace('placement:\n','placement:\n  # RJ45 entry clamps populate the underside between the THT contact rows.\n  sides: {U_ESD1: bottom, U_ESD2: bottom, U_ESD3: bottom, U_ESD4: bottom, U_ESD5: bottom, U_ESD6: bottom, U_ESD7: bottom, U_ESD8: bottom}\n')
s=s.replace('"U_ESD{i}": {at: [1.5, -13.2], rot: 0}','"U_ESD{i}": {at: [-0.93, -19.14], rot: 0}').replace('"U_ESD{i}": {at: [-1.5, 13.2], rot: 180}','"U_ESD{i}": {at: [0.93, 19.14], rot: 180}')
# Preserve existing pad-only 0.15 mm floor; move its exact NC2/IO1 area with
# the rotated bottom footprint. Geometry is the original pad span +0.01 mm.
for i in range(1,9):
 cx=(39.57+32*(i-1)) if i<=4 else (41.43+32*(i-5));cy=27.86 if i<=4 else 112.14
 px=cx-.7125 if i<=4 else cx+.7125
 y0,y1=(cy-.68,cy+.18) if i<=4 else(cy-.18,cy+.68)
 rect=[round(px-.3475,5),round(y0,5),round(px+.3475,5),round(y1,5)]
 s,n=re.subn(r'  - \{name: PKG_PAD_ESD'+str(i)+r'_2_3, layers: \[F.Cu\], deny: \[\], rect: \[[^\]]+\]\}',f'  - {{name: PKG_PAD_ESD{i}_2_3, layers: [B.Cu], deny: [], rect: {rect}}}',s);assert n==1,i
s=s.replace('J1-J8: 1 +12V  2 GND  3 AUDIO+  4 AUDIO-','POD AUDIO +12V / NOT ETHERNET OR POE')
put('03_src/floorplan.yaml',s)
s=(P/'03_src/rules/electrical_invariants.yaml').read_text();s=s.replace('pins: {"1": "12V_POD{n}", "2": GND, "3": "AUDIO_P{n}", "4": "AUDIO_N{n}"}','pins: {"1": "12V_POD{n}", "2": GND, "3": "12V_POD{n}", "4": "AUDIO_N{n}", "5": "AUDIO_P{n}", "6": GND, "7": "12V_POD{n}", "8": GND, "9": CHASSIS, "10": CHASSIS}')
put('03_src/rules/electrical_invariants.yaml',s)
s=(P/'03_src/rules/assembly.yaml').read_text().replace('sides: [top]','sides: [top, bottom]').replace('bottom_population: none','bottom_population: U_ESD1-U_ESD8 only; bottom paste, CPL and clearance require exact qualification').replace('Molex 43650 headers, both MCH','Wurth615008160221 RJ45 jacks, Molex43650-0200 power header, both MCH').replace('J1-J8 Micro-Fit and J9/J10/J11','J1-J8 Wurth RJ45 and J9/J10/J11')
s=s.replace('order_time_requirements:\n','order_time_requirements:\n  - qualify bottom U_ESD1-U_ESD8 stencil, paste, rotation, THT tail/fillet separation and rework access before PCBA\n  - qualify Wurth manual solder profile; no manufacturer iron-process approval is inferred\n  - verify all eight shell-to-chassis panel contacts and CHASSIS-to-GND isolation\n')
put('03_src/rules/assembly.yaml',s)
model=N/'manufacturer-kicad/J_Wurth_WR-MJ_615008160221.step'
m=load('03_src/rules/model_registration.yaml');g=m['groups'][0]
assert g['refs']==[f'J{i}' for i in range(1,9)]
g['id']='wurth-615008160221-side-entry';g['authority']='Wurth615008160221 drawing001.003 and manufacturer KiCad_WR-MJrev26c; exact native model and hole pattern, not mated fit'
g['model_sha256']=hashlib.sha256(model.read_bytes()).hexdigest();g['orientation'].update(authority='Manufacturer pad1 datum, mouth6.36mm toward footprint-Y; model+Y is outward; PCB edge target0.5mm nominal',mating_plane_offset_mm=6.36,edge_offset_range_mm=[.49,.51])
dump('03_src/rules/model_registration.yaml',m)
for rel in ['03_src/rules/requirements.yaml','03_src/rules/integration.yaml','03_src/rules/power_tree.yaml']:
 s=(P/rel).read_text().replace('Micro-Fit spoke','RJ45 analog/DC spoke').replace('carrier Micro-Fit header','carrier RJ45 contact bank').replace('Micro-Fit mated pair excluded; board-header/contact allocation only','RJ45 mated cord excluded; board-side paralleled power-contact allocation only')
 put(rel,s)
s=(P/'03_src/tests/test_local_placement_source.py').read_text().replace('31.0, 0] for i in range(4)','25.86, 0] for i in range(4)').replace('109.0, 180] for i in range(4)','114.14, 180] for i in range(4)').replace('def test_external_datums_unchanged','def test_rj45_datums_and_board_outline')
put('03_src/tests/test_local_placement_source.py',s)
s=(P/'03_src/tests/test_package_models.py').read_text().replace("'Molex_43650-0400_RA_Exact','Molex_43650-0200_RA_Exact',","'Molex_43650-0400_RA_Exact','Wurth_615008160221_RJ45','Molex_43650-0200_RA_Exact',")
put('03_src/tests/test_package_models.py',s)
put('01_docs/decisions/0028-rj45-factory-spokes.md','''# ADR0028 — factory RJ45 analog/DC spokes

Status: source implementation in progress, architecture selected; generated and release acceptance pending.
Date: 2026-09-12. Authority: user directive D8, parent D3 and pod D6.

Use Wurth615008160221 nonmagnetic8P8C Cat6 shielded jacks at J1-J8 and podJ1,
with exact15m HARTING09484747743150 Cat6A PUR factory patch cords. Preserve
analog/DC interface:1/3/7 positive,2/6/8 return,5 AUDIO+,4 AUDIO-. Shield tabs9/10
are CHASSIS oncarrier and POD_SHIELD onpod, isolated fromsignalGND. These
ports have noEthernet/PoE function and mating requirespoweroff.

ManufacturerKiCad libraryrev26c suppliesphysicalgeometry andnativeSTEP. Remap
S1/S2 to9/10 and adaptmodelpath only. The compactbody putsoddrowpins7.09mm
fromrear, so usebottom entryclamps betweenits4mmcontactrows. Freshindependent
sourcearchitecture judgedpodarrangementSOUND; fullcarrierimplementation and
allnativepin/model/assembly/route checksremainindependentacceptance gates.
RootnativeFlip(False) withboardownership gives1.935073mmpadcentrespans at
localU3centre3.57,2.0, rotation0. Review's1.514mmnumberwasnon-authoritative;
the actualgenerator transform controls. Keep4.0mmspan/4.2mmvia-freeprefix
ceilings andclamp-before-branch ordering. Onlyentryclamps usebottomassembly;
allothercriticalplacement/routingcontractsremainapplicable.

HARTING290ohm/kmloopDCR,15m,3parallelpairs,1.25hotfactorand.300ohmcontact
allocationgive2.1125ohm and10.58875Vminimumat.1Afrom10.8V. Actualcordcontact
resistance,currentqualification,fullbootmaxtolerance,ODextrema,wetentry,
chassisfingers,populatedlatchaccessandbottomassemblyareunqualified.
Approx45mmbootlengthand6.7mmnominalODmustnotbeclaimedsourcemaxima.

RetireMicroFitcrimps,fieldjoinsandpigtailsfromactivespokeassembly. J9powerand
J10/J11MCHinterfacesretaintheirexactseparateassemblies. Earlierdossiers,
reviewfailuresandsealedpodreleasearehistoricalrecords. Thisrevisiondoesnot
restoreanyLAYOUT001diagnosticattemptorinheritoldnativeacceptance.
''')
print('Prepared',sum(p.is_file() for p in C.rglob('*')),'carrier source candidate files; service contract completion pending')
