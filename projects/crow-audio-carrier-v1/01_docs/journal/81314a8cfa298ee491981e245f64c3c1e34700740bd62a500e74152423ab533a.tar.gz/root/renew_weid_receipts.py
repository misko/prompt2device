from pathlib import Path
import sys,json
N=Path(__file__).parent;V=N/'weid_validation'
sys.path.insert(0,str(V/'skills/pcb-design/scripts'))
import connector_assembly_contract as base
import connector_assembly_phase_gate as phase
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
    p=V/'projects'/slug
    r=base.load_and_compile(p)
    ok,errors=base.validate_receipt(r,p);assert ok,errors
    (p/phase.DEFAULT_BASE_RECEIPT).write_text(json.dumps(r,indent=2)+'\n')
    print(slug,'base',r['status'])
    for mode in ['source','full']:
        r=phase.compile_phase_gate(p,phase=mode)
        ok,errors=phase.validate_phase_gate(r,p,expected_phase=mode);assert ok,errors
        assert r['status']==('PASS' if mode=='source' else 'INCOMPLETE'),r
        out=phase.DEFAULT_SOURCE_OUTPUT if mode=='source' else phase.DEFAULT_FULL_OUTPUT
        (p/out).write_text(json.dumps(r,indent=2)+'\n')
        print(slug,mode,r['status'],r['summary'])
