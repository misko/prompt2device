from pathlib import Path
import ast, json, shutil
import yaml
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;C=N/'weid_source_candidate'
def put(rel,text):
 p=C/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
P='projects/crow-mic-pod-v3';A='projects/crow-audio-carrier-v1'
old=(C/P/'03_src/check_realized_routes.py').read_text(); tree=ast.parse(old)
values={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['SHORT_PATHS','PREFIXES']}
pod={'schema':1,'layers':['F.Cu','B.Cu'],'stackup_mm':[1.6], 'short_paths':[{'from':a,'to':b,'max_length_mm':m,'layer':l,'max_pad_centre_mm':4.0 if a in ['J1.5','J1.4'] else None,'why':why} for a,b,m,l,why in values['SHORT_PATHS']], 'prefixes':[{'from':a,'through':b,'targets':list(t),'why':why} for a,b,t,why in values['PREFIXES']]}
carrier={'schema':1,'layers':['F.Cu','In1.Cu','In2.Cu','B.Cu'],'stackup_mm':[.2104,1.065,.2104],'short_paths':[],'prefixes':[]}
for n in range(1,9):
 for leg,jpin,upin in [('P',5,3),('N',4,5)]:
  start=f'J{n}.{jpin}';clamp=f'U_ESD{n}.{upin}'
  carrier['short_paths'].append({'from':start,'to':clamp,'max_length_mm':4.2,'layer':'B.Cu','max_pad_centre_mm':4.0,'why':'ADR0028: connector-first audio ESD clamp, no layer transfer before clamp'})
  carrier['prefixes'].append({'from':start,'through':clamp,'targets':[f'C_A{n}{leg}.1'],'why':'Every downstream AC-coupling branch must follow the entire entry-clamp path'})
for slug,data in [(P,pod),(A,carrier)]:put(slug+'/03_src/rules/critical_paths.yaml',yaml.safe_dump(data,sort_keys=False))
# Promote the existing independently text-read graph and prefix-edge dominance
# mechanism. Project endpoint policy is now configuration, per M8.
s=old
start=s.index('SHORT_PATHS =');end=s.index('\ndef grade(',start)
s=s[:start]+s[end+1:]
s=s.replace('def grade(oracle: Callable[[str, str], PathResult]) -> dict:', 'def grade(oracle: Callable[[str, str], PathResult], config: dict) -> dict:\n    config = validate_config(config)\n    short_paths = config["short_paths"]\n    prefixes = config["prefixes"]')
s=s.replace('for start, end, maximum, required_layer, why in SHORT_PATHS:', 'for decl in short_paths:\n        start, end, maximum, required_layer, why = (decl[k] for k in ("from", "to", "max_length_mm", "layer", "why"))')
s=s.replace('if start in {"J1.4", "J1.5"} and item.pad_centre_mm > 4.0 + 1e-9:', 'if decl["max_pad_centre_mm"] is not None and item.pad_centre_mm > decl["max_pad_centre_mm"] + 1e-9:')
s=s.replace('mm exceeds 4.000 mm','mm exceeds {decl[\'max_pad_centre_mm\']:.3f} mm')
s=s.replace('for start, clamp, targets, why in PREFIXES:', 'for decl in prefixes:\n        start, clamp, targets, why = (decl[k] for k in ("from", "through", "targets", "why"))')
s=s.replace('"crow-pod-realized-route-audit-v1"','"critical-path-audit-v1"')
start=s.index('def _load_copper_module');end=s.index('def board_oracle',start)
s=s[:start]+s[end:]
s=s.replace('def board_oracle(board_path: Path) -> Callable[[str, str], PathResult]:', 'def board_oracle(board_path: Path, config: dict) -> Callable[[str, str], PathResult]:\n    config = validate_config(config)')
s=s.replace('    project = Path(__file__).resolve().parents[1]\n    repo = Path(os.environ.get("CIRCUITS_ROOT", project.parents[1])).resolve()\n    copper = _load_copper_module(repo)', '    import copper_length_audit as copper')
s=s.replace('if layers != ["F.Cu", "B.Cu"]:', 'if layers != config["layers"]:').replace('expected exact two-layer board, got','declared copper layers differ, got')
s=s.replace('nets[net], layers, [1.6], pads.get(net, []), plated.get(net, [])','nets[net], layers, config["stackup_mm"], pads.get(net, []), plated.get(net, [])')
s=s.replace('    def graph_for(net: str):', '    def graph_for(net: str):')
s=s.replace('            graph, error = copper._path_graph(', '            assert_graph_contacts(text, net, nets[net], pads.get(net, []), copper)\n            graph, error = copper._path_graph(')
s=s.replace('def audit(board_path: Path) -> dict:\n    receipt = grade(board_oracle(board_path))', 'def audit(board_path: Path, config: dict) -> dict:\n    before = board_path.read_bytes()\n    receipt = grade(board_oracle(board_path, config), config)\n    if board_path.read_bytes() != before:\n        raise AuditError("board changed during audit")')
s=s.replace('hashlib.sha256(board_path.read_bytes())','hashlib.sha256(before)')
s=s.replace('    parser.add_argument("--json", type=Path)', '    parser.add_argument("--json", type=Path)\n    parser.add_argument("--config", required=True, type=Path)')
s=s.replace('        receipt = audit(args.board)', '        raw = args.config.read_bytes()\n        config = load_config(args.config)\n        receipt = audit(args.board, config)\n        if args.config.read_bytes() != raw:\n            raise AuditError("config changed during audit")\n        receipt["config_sha256"] = hashlib.sha256(raw).hexdigest()')
s=s.replace('R-POD-PATH','R-CRITICAL-PATH').replace('except (AuditError, ValueError, OSError)', 'except (AuditError, ValueError, OSError)')
s=s.replace('import os\n','').replace('import importlib.util\n','')
s=s.replace('"""Grade the crow pod\'s safety- and stability-critical realized copper.', '"""Grade configured short paths and protection branch order on saved copper.\n\nUsage: critical_path_check.py BOARD --config critical_paths.yaml --json REPORT\nPromoted from the pod checker when a second board needed the same mechanism.\nNonempty schema-1 source fixes copper layers, stackup, endpoint paths and\nclamp-dominance obligations. Zones, arcs and unsplit/width-only copper contacts\non graded nets are refused rather than silently omitted from the graph.\nThis is not an ESD waveform or physical protection qualification.\n\nVACUITY: Correctly declared copper paths cannot establish that a fitted clamp\nactually limits voltage. A failed-open device with identical copper passes;\nphysical component and transient qualification remain separate.\n\nGrade safety- and stability-critical realized copper.')
insert=s.index('def grade(')
extra='''def validate_config(data):
    import re
    if not isinstance(data, dict) or set(data) != {"schema", "layers", "stackup_mm", "short_paths", "prefixes"} or type(data["schema"]) is not int or data["schema"] != 1:
        raise AuditError("invalid critical-path schema/header")
    layers = data["layers"]
    if not isinstance(layers, list) or len(layers) < 2 or len(set(layers)) != len(layers) or layers[0] != "F.Cu" or layers[-1] != "B.Cu" or any(not isinstance(x, str) or not re.fullmatch(r"(?:F|B|In[1-9][0-9]*)\\.Cu", x) for x in layers):
        raise AuditError("invalid declared copper layers")
    def positive(x):
        return type(x) in (int, float) and math.isfinite(x) and x > 0
    if not isinstance(data["stackup_mm"], list) or len(data["stackup_mm"]) != len(layers)-1 or not all(positive(x) for x in data["stackup_mm"]):
        raise AuditError("invalid declared layer spacing")
    def endpoint(x):
        return isinstance(x, str) and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*\\.[A-Za-z0-9_]+", x)
    short = data["short_paths"]
    if not isinstance(short, list) or not short:
        raise AuditError("short-path denominator is empty")
    pairs = set()
    for row in short:
        if not isinstance(row, dict) or set(row) != {"from", "to", "max_length_mm", "layer", "max_pad_centre_mm", "why"}:
            raise AuditError("invalid short-path keys")
        pair = (row["from"], row["to"])
        if not all(endpoint(x) for x in pair) or pair[0] == pair[1] or pair in pairs:
            raise AuditError("invalid/duplicate short-path endpoints")
        pairs.add(pair)
        if row["layer"] not in layers or not positive(row["max_length_mm"]) or (row["max_pad_centre_mm"] is not None and not positive(row["max_pad_centre_mm"])) or not isinstance(row["why"], str) or not row["why"].strip():
            raise AuditError("invalid short-path limit/layer/reason")
    if not isinstance(data["prefixes"], list):
        raise AuditError("prefixes must be a list")
    seen = set()
    for row in data["prefixes"]:
        if not isinstance(row, dict) or set(row) != {"from", "through", "targets", "why"}:
            raise AuditError("invalid prefix keys")
        pair = (row["from"], row["through"])
        targets = row["targets"]
        if pair not in pairs or pair in seen or not isinstance(targets, list) or not targets or not all(endpoint(x) for x in targets) or len(set(targets)) != len(targets) or any(x in pair for x in targets) or not isinstance(row["why"], str) or not row["why"].strip():
            raise AuditError("invalid/duplicate prefix or targets")
        seen.add(pair)
    return data


def load_config(path):
    import yaml
    class UniqueLoader(yaml.SafeLoader):
        pass
    def mapping(loader, node, deep=False):
        result = {}
        for key, value in node.value:
            key = loader.construct_object(key, deep=deep)
            if key in result:
                raise AuditError("duplicate critical-path YAML key")
            result[key] = loader.construct_object(value, deep=deep)
        return result
    UniqueLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, mapping)
    try:
        return validate_config(yaml.load(Path(path).read_text(), Loader=UniqueLoader))
    except (yaml.YAMLError, TypeError) as exc:
        raise AuditError(str(exc)) from exc


def assert_graph_contacts(text, net, entry, pads, copper):
    """Refuse physical contacts the endpoint graph cannot represent faithfully."""
    import re
    from shapely.geometry import LineString, Point
    if entry["zones"]:
        raise AuditError(f"{net}: zone copper is not represented by path graph")
    if any(copper._net(b) == net for b in copper._blocks(text, "arc")):
        raise AuditError(f"{net}: arc contacts require a supported graph adapter")
    segs = []
    for body in copper._blocks(text, "segment"):
        if copper._net(body) != net:
            continue
        width = re.search(r'\\(width\\s+([-\\d.eE+]+)\\)', body)
        if not width or not math.isfinite(float(width[1])) or float(width[1]) <= 0:
            raise AuditError(f"{net}: invalid track width")
        layer = re.search(r'\\(layer\\s+"([^\"]+)"', body)[1]
        a, b = copper._pt(body, "start"), copper._pt(body, "end")
        segs.append((layer, a, b, float(width[1]), LineString([a,b])))
    for i, (la,a,b,wa,line) in enumerate(segs):
        for lb,c,d,wb,other in segs[i+1:]:
            if la != lb or line.distance(other) > (wa+wb)/2 + 1e-7:
                continue
            if {a,b} & {c,d}:
                continue
            # Two tracks intentionally meeting within one ordinary land share
            # the same synthetic pad anchor even if their endpoints differ.
            if any(copper._pad_has_layer(p, la) and any(copper._point_in_pad(p,*x) for x in (a,b)) and any(copper._point_in_pad(p,*x) for x in (c,d)) for p in pads):
                continue
            raise AuditError(f"{net}: unsplit or width-only track contact; graph dominance unproven")
    for body in copper._blocks(text, "via"):
        if copper._net(body) != net:
            continue
        at = copper._pt(body, "at")
        size = re.search(r'\\(size\\s+([-\\d.eE+]+)\\)', body)
        if not size:
            raise AuditError(f"{net}: unpriced via contact")
        for la,a,b,w,line in segs:
            if Point(at).distance(line) <= (float(size[1])+w)/2 + 1e-7 and at not in (a,b):
                if any(copper._pad_has_layer(p, la) and copper._point_in_pad(p,*at) and any(copper._point_in_pad(p,*x) for x in (a,b)) for p in pads):
                    continue
                raise AuditError(f"{net}: unsplit or width-only via contact; graph dominance unproven")


'''
s=s[:insert]+extra+s[insert:]
put('skills/kicad-pcb/scripts/critical_path_check.py',s)
# Thin compatibility entry point retains conductor and test call sites. No
# duplicate topology/graph implementation remains in the project.
wrapper='''#!/usr/bin/env python3
"""Compatibility entry point for the shared configured critical-path checker."""
from pathlib import Path
import os
import sys
PROJECT = Path(__file__).resolve().parents[1]
REPO = Path(os.environ.get("CIRCUITS_ROOT", PROJECT.parents[1]))
sys.path.insert(0, str(REPO / "skills/kicad-pcb/scripts"))
import critical_path_check as shared
AuditError = shared.AuditError
PathResult = shared.PathResult
CONFIG_PATH = PROJECT / "03_src/rules/critical_paths.yaml"
def grade(oracle):
    return shared.grade(oracle, shared.load_config(CONFIG_PATH))
def board_oracle(board_path):
    return shared.board_oracle(board_path, shared.load_config(CONFIG_PATH))
def audit(board_path):
    return shared.audit(board_path, shared.load_config(CONFIG_PATH))
if __name__ == "__main__":
    sys.argv.extend(["--config", str(CONFIG_PATH)])
    raise SystemExit(shared.main())
'''
put(P+'/03_src/check_realized_routes.py',wrapper)
print('promoted shared checker and two source policies')
