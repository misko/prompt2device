from pathlib import Path
import shutil
N=Path(__file__).parent;C=N/'weid_source_candidate';p=C/'skills/kicad-pcb/scripts/critical_path_check.py';s=p.read_text()
s=s.replace("if pad_box_distance(pad,(other['x'],other['y']),(other['x'],other['y'])) == 0. or any", "if pad_box_distance(pad,(other['x'],other['y']),(other['x'],other['y'])) == 0. or pad_box_distance(other,(pad['x'],pad['y']),(pad['x'],pad['y'])) == 0. or any")
s=s.replace('    for body in copper._blocks(text, "via"):\n', '    vias = []\n    for body in copper._blocks(text, "via"):\n',1)
s=s.replace('        if not size:\n            raise AuditError(f"{net}: unpriced via contact")', '''        span = re.search(r'\\(layers\\s+"([^\"]+)"\\s+"([^\"]+)"', body)
        if not size or not span or not math.isfinite(float(size[1])) or float(size[1]) <= 0:
            raise AuditError(f"{net}: unpriced via contact")
        ends = span.groups()
        for other_at,other_size,_ends in vias:
            if at != other_at and math.dist(at,other_at) <= (float(size[1])+other_size)/2+1e-7:
                raise AuditError(f"{net}: unrepresented via-via annulus contact")
        vias.append((at,float(size[1]),ends))''')
s=s.replace('        for la,a,b,w,line in segs:\n            if point_segment_distance(at,*line)', '''        for la,a,b,w,line in segs:
            if la not in ends and point_segment_distance(at,*line) <= (float(size[1])+w)/2+1e-7:
                raise AuditError(f"{net}: unrepresented interior via-layer contact")
            if point_segment_distance(at,*line)''',1)
needle='\n\ndef grade(oracle:'
addition='''
    for pad in pads:
        if pad['kind'] != 'thru_hole':
            continue
        served = {}
        for layer,a,b,w,line in segs:
            if copper._pad_has_layer(pad,layer):
                for point in (a,b):
                    if verified_pad_hit(pad,point,copper):
                        served.setdefault(layer,set()).add(point)
        for at,size,ends in vias:
            if verified_pad_hit(pad,at,copper):
                for layer in ends:
                    served.setdefault(layer,set()).add(at)
        center=(pad['x'],pad['y'])
        if len(served)>2 or (len(served)>1 and any(center not in points for points in served.values())):
            raise AuditError(f"{net}: unrepresented off-center/intermediate PTH layer transition at {pad['ref']}.{pad['pad']}")
'''
assert needle in s;s=s.replace(needle,addition+needle,1)
p.write_text(s);shutil.copyfile(p,N/'weid_validation/skills/kicad-pcb/scripts'/p.name)
print('all represented contact classes guarded; native class regression required')
