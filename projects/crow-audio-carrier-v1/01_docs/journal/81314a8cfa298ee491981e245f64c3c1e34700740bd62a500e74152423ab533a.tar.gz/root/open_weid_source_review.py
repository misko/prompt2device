from pathlib import Path
from datetime import datetime,timezone,timedelta
import sys,json,hashlib,shutil,tempfile
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
name='weid-source-review';D=Path(tempfile.mkdtemp(prefix='carrier-weid-source-review-'))
paths=['CLAUDE.md','skills/pcb-design/references/connector-assembly-contract.md','skills/pcb-design/references/execution-runtime.md','projects/crow-audio-carrier-v1/01_docs/decisions/0007-prototype-before-physical-qualification.md','projects/crow-audio-carrier-v1/01_docs/reports/2026-09-12-rj45-dimensioned-alternative.md','projects/crow-audio-carrier-v1/01_docs/research/2026-09-12-rj45-source-checkpoint.md']
for rel in paths:
 p=D/'context'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,p)
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 for f in ['connector_assemblies.yaml','connector_assembly_phases.yaml','spoke_interface.yaml']:
  p=N/'integrated_source_candidate/projects'/slug/'03_src/rules'/f;o=D/'held'/slug/f;o.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,o)
for f in ['8909650150.stp','section-envelopes.json','step-source.json','README.md','plug-views.png']:
 o=D/'manufacturer'/f;o.parent.mkdir(exist_ok=True);shutil.copyfile(N/'weidmueller-8909650150'/f,o)
shutil.copyfile(N/'weid-wiring.jpg',D/'manufacturer/wiring.jpg');shutil.copyfile('/tmp/carrier-locator-implementation-availability-6c_4vwal/preflight.py',D/'preflight.py')
now=datetime.now(timezone.utc);cut=now+timedelta(minutes=10);hard=now+timedelta(minutes=13)
(D/'TASK.md').write_text(f'''Fresh independent SOURCE-boundary judgment for exact Weidmuller8909650150 cord. Probe weid-source-availability actual FINAL and closurePASS at18:06Z. Rootsolelivewriter; userapproved factoryRJ45/Catcords and continue mintnewrelease. Read context CLAUDE, connector contract and existing accepted ADR0007. No need reassess user authorization. Scope: does exact-product-linked manufacturerSTEP permit known nominal mate/grip facts, with installed fit/tolerances unknown at physical boundary? Do not confuse nominal CAD with manufacturing maximum; do not demand maxima if contract supports source geometry separately. Existing held HARTING proposal is context only, not adopted. No boardgeneration untilfullsourceacceptance.

Independently reopen STEP and inspect or recompute geometry (cadlibs /tmp/carrier-rj45-20260912/cad-libs available). Native model one solid internalfamily8909650000, exactproduct8909650150 downloadbinding in step-source.json and report, total279.96mm because200mmplaceholdercable. Root extracted firstend57.98x13.70x18.456687mm including sleeve/latch; actualplugboot ends39.98. Check whether segmentation/gripexpression faithful. Proposed mate.model_source_id exact manufacturer3D, body_envelope null. Proposed grip integral_latch_boot, axial_length57.98, circular outerdiameter derived from full nominal crosssection diagonal, explicitly conservative FOR NOMINAL MODEL ONLY; installed tolerance remainsunknown with existing installed-tolerance deferral. No arbitrary allowance, no claimphysicalenvelope max. If valid, propose exact YAML sections/evidence wording and classify limitations. If invalid, give minimal actual missing fact/source correction and why, not repeat old HARTING maximum hold.

Exact wiringimage rootdownloaded from manufacturerproduct shows1:1contacts1..8, whiteorange1,orange2,whitegreen3,blue4,whiteblue5,green6,whitebrown7,brown8 (T568B). Primary datasheetknown15m,Cat6A,PUR,S/FTP,26/7,OD6.1..6.5,-40..80Coperating,-15..60install,loop290ohm/km. UVnotstatedexactdatasheet; rootresearching. Review whether unqualifiedUV canbeexplicitfirst-article/outdoorhold under existingprototypeboundary, while retaining outdoorrequirement and nofalsetrueUVclaim, or mustblockpartsourcing. No requirementweakening/suppliersampleclaim. Complete all advicebounded toconnectorSOURCE, not wholeboardrelease.

READ_ONLY frozenpacket, output/scratchonly. May read owningrepo scripts and note/hash extras. No children, no livewrites, no networkunlessneededforprimaryexactgeometry. Every engineering subprocess via pipeline_runtime.run_stage /usr/bin/python3 -B. Outputs report.md,evidence.json,evidence-manifest.json,evidence.tar.gz,result.json; archive methods/logs andhashregularmembers. Checks inputs-verified,review-complete,evidence-complete PASSforcompletedhonestreview, domainverdictseparate. Verifyfrozenbeforeafter. Mandatorypreflight /usr/bin/python3 -B {D}/preflight.py {D}/06_build/task_runs/{name}/envelope.json. ActualFINAL by{cut.isoformat()}, hard{hard.isoformat()}, zeroreplacements. Reservepackagingtime. Rootwillclosepromptly.
''')
items=[]
for p in sorted(D.rglob('*')):
 if p.is_file():
  b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(D).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
s=subject_identity('weid_source_review',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
e=TaskEnvelope(schema=2,task_id=name,stage_id='PCB-SOURCING',run_id=name,subject=s,executor='reviewer',execution_class='review_wait',recommended_agent_role='judgment',agent_role='judgment',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']})
o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),agent_id='/root/carrier_weid_source_review',work_cutoff=cut.isoformat());(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o))
