from pathlib import Path
import shutil,sys,runpy
N=Path(__file__).parent;V=N/'weid_validation';D=N/'pad_modifier_red_backend'
shutil.copytree(V/'skills/kicad-pcb/scripts',D,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
shutil.copyfile(N/'critical-path-before-pad-modifiers.py',D/'critical_path_check.py')

sys.path.insert(0,str(V/'tests'));import harness
harness.SCRIPTS=D
sys.path.insert(0,str(D))
runpy.run_path(str(V/'tests/t1_critical_path_check.py'),run_name='__main__')
