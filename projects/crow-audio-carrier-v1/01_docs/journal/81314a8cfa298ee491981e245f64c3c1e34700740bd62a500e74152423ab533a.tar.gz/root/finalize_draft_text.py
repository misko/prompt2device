from pathlib import Path
import json,hashlib,ast,yaml
N=Path(__file__).parent;C=N/'integrated_source_candidate';V=N/'source_validation'
s='''# HARTING 09484747743150 source record

Selected cord: HARTING 09484747743150, factory 15 m Cat6A S/FTP PUR,
with shielded DualBoot RJ45 male plugs at both ends.

Primary assembly page:
https://www.harting.com/pl-PL/p/RJI-DB-Cat6a-Cable-Assy-grey-PUR-15m-09484747743150
Retained HTML SHA-256:
`0c01be75edcc64d76e9740aa752cf50ba16381c1b968dfece71155bcc9d4e2e2`.
The published assembly BOM identifies cable 094560006000301 and two
0948CON47P8BK plug subassemblies. The latter is an internal BOM identity;
it is not claimed to be a separately orderable retail part.

Primary catalog PDF, page 155:
https://b2b.harting.com/files/livebooks/en/PRD0200000100235/downloads/livebook.pdf
PDF SHA-256: `d581c83283e1c2b0e9afbf7753b885aaa68e5611d06dec010f76847c99f06577`.
The page shows the 15 m order code, straight-through T568B contacts and
shield continuity. Root inspected this actual page on 2026-09-12.
The drawing gives approximately 45 mm plug/boot length, 13.3 × 13.8 mm at
the front and nominal 6.7 mm cable OD. These are not established maxima.

The exact bulk cable page is:
https://www.harting.com/en-AE/p/HARTING-IE-Cat-6A-4x2xAWG26-7-PUR-grey-094560006000301
Retained HTML SHA-256:
`8058bd6e1b069c7e162fd9c563ab6cdf9dc01fa453d97942999650c6548a013c`.
It specifies AWG 26/7 copper, S/FTP shielding, PUR jacket, UV/oil resistance,
−40 to +80 °C and maximum pair-loop resistance of 290 Ω/km at 20 °C.
The single/repeated bend limits are 5D/10D: 33.5/67 mm at nominal OD.
No separate installation-temperature claim or wet mating qualification follows.
IP20 plug zones need protection against water and condensation.

For three parallel power pairs, the project's 1.25 hot multiplier and
unmeasured 0.300 Ω contact allocation give:
290 × 0.015 / 3 × 1.25 + 0.300 = 2.1125 Ω.
At 0.10 A, drop is 0.21125 V and the pod sees 10.58875 V from 10.8 V.
The 2.2 Ω / 10.5 V requirements remain unchanged. This is a calculation;
plug current, contact resistance and the finished cord require qualification.

Raw manufacturer evidence is preserved in carrier journal archive
168cb286ee392f49e1ec95ab9e66077b0069bb63ca653665095a3d7262204160.tar.gz.
The attempted PDF_DS_09484747743150_EN.pdf download contained HTML and is
retained as a failed retrieval, never as data-sheet authority.
'''
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 rel=Path('projects')/slug/'02_parts/09484747743150/primary-source-record.md'
 (C/rel).write_text(s);(V/rel).write_text(s)
# Record corrections separately from the frozen review subject.
notes={'status':'DRAFT_SOURCE_INCOMPLETE','live_adoption':False,'post_review_packet_changes':[
 'Carrier U_ESD member rotations north 0 to180 and south180 to0. Standard SOT-553 pin orientation is opposite the pod custom footprint. Isolated native remeasurement gives1.935073mm spans and aligns previously authored NC2/IO1 areas; full-board and route checks remain owed.',
 'HARTING primary-source prose spaced and linked for readability, with facts unchanged. Base/source receipts are renewed because referenced bytes changed.'
], 'remaining_implementation_debt':[
 'Manufacturer maximum or dimensioned measurement/allowance evidence for mate and grip; source INCOMPLETE is mandatory until resolved.',
 'Fresh full source acceptance across synchronized parent/carrier/pod, owning schema/policy/ADR checks and current commissioning state.',
 'Carrier exact B.Cu connector-to-clamp prefixes and realized dominance enforcement; shunt inventory does not prove the branch order.',
 'Routed common carrier CHASSIS bond and pod isolated POD_SHIELD island, plus enclosure bond/service qualification.',
 'Complete active first-article and parent decision updates before source adoption.',
 'Pod protection_paths J1 recommended/absolute150 fields originate from150VAC working rating, not a published150VDC absolute maximum; resolve actual electrical rating evidence without accepting a prose qualifier as a gate.',
 'Native transform/copper/tail/fillet/clearance/side/assembly/model/render/label qualification. No TSX build or full conductor while source gate remains blocked.',
 'Renew all schematic/placement/routing/physical/release evidence. Existing native boards and historical reviews do not implement this draft.'
]}
(N/'draft-integration-debt.json').write_text(json.dumps(notes,indent=2)+'\n')
rows=[];counts={'python_parsed':0,'yaml_parsed':0}
for p in sorted(C.rglob('*')):
 if not p.is_file():continue
 if p.suffix=='.py':ast.parse(p.read_text());counts['python_parsed']+=1
 if p.suffix in ('.yaml','.yml'):yaml.safe_load(p.read_text());counts['yaml_parsed']+=1
 b=p.read_bytes();rows.append({'path':p.relative_to(C).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(N/'integrated-source-manifest.json').write_text(json.dumps({'status':'DRAFT_SOURCE_INCOMPLETE','live_adoption':False,'files':rows},indent=2)+'\n')
(N/'draft-parse-results.json').write_text(json.dumps({'status':'PASS','counts':counts,'scope':'syntax only, not source-schema or implementation acceptance'},indent=2)+'\n')
print(len(rows),'draft files;',counts,'syntax only')
