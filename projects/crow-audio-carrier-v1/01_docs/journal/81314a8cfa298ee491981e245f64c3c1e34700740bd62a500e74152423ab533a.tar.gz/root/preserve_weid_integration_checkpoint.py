from pathlib import Path, PurePosixPath
import hashlib,json,tarfile,io,gzip
from datetime import datetime,timezone
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911')
C=N/'weid_source_candidate';payload={};checks=[]
def add(name,path):
    assert path.is_file() and not path.is_symlink(),path
    assert name not in payload,name
    payload[name]=path.read_bytes()
for name in ['weid-source-availability','weid-source-review','weid-integration-availability','weid-integration-review','weid-corrected-availability']:
    m=N/(name+'-opened.json')
    if not m.is_file():
        assert name=='weid-source-availability';continue
    meta=json.loads(m.read_text());D=Path(meta['project']);E=Path(meta['envelope']);e=json.loads(E.read_text())
    attempt=json.loads((E.parent/'attempt.json').read_text());assert attempt['status']=='PASS',(name,attempt)
    for row in e['input_packet']:
        b=(D/row['path']).read_bytes();assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256']
    for p in sorted(D.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:add('closed_reviews/'+name+'/'+p.relative_to(D).as_posix(),p)
    checks.append({'task':name,'delivery_status':attempt['status'],'frozen_inputs':len(e['input_packet'])})
    for suffix in ['-opened.json','-host-final.json']:
        add('root/'+name+suffix,N/(name+suffix))
for p in sorted(C.rglob('*')):
    if p.is_file() and '__pycache__' not in p.parts:add('held_candidate/'+p.relative_to(C).as_posix(),p)
for p in sorted(N.iterdir()):
    if p.is_file() and (p.suffix in ('.py','.json','.html','.jpg','.md')) and not p.name.startswith('weid-integration-checkpoint-'):
        name='root/'+p.name
        if name not in payload:add(name,p)
for p in sorted(I.glob('weid-*')):
    if p.is_file() and not p.name.startswith('weid-integration-checkpoint-preserve'):
        add('root/runtime/'+p.name,p)
for p in sorted((N/'source-preflights').rglob('*')):
    if p.is_file():add('root/source-preflights/'+p.relative_to(N/'source-preflights').as_posix(),p)
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
    for f in ['connector_assembly_contract.json','connector_assembly_source_gate.json','connector_assembly_full_gate.json']:
        p=N/'weid_validation/projects'/slug/'06_build/verification'/f
        add('root/connector-receipts/'+slug+'/'+f,p)
p=N/'weid_validation/projects/crow-audio-carrier-v1/06_build/netlists/crow_audio_carrier_v1.net'
add('root/historical-source-test-fixture/'+p.name,p)
audit={'created_at':datetime.now(timezone.utc).isoformat(),'closed_reviews':checks,
 'scope':'Held source checkpoint only. Complete original review REJECT retained. Corrected source review active, later fixes not yet independently accepted. No live source/native/release adoption.',
 'baseline_commit':'01fab37b','candidate_files':sum(n.startswith('held_candidate/') for n in payload),
 'measured':{'connector_source':'carrier PASS23 admitted/0findings; pod PASS9/0','physical_full':'INCOMPLETE23/9 unknowns; prototype decisions preserved',
 'critical_tests':'22/22 PASS;19 knownbad; one physical device-function vacuity','red_controls':'eight first-contact controls and three later geometry controls discriminate old backends',
 'shared_length':'34/34 PASS;16 knownbad; real immutable fixtures and candidate backend',
 'prototype_admission':'19/19 PASS;15 knownbad','carrier_entry':'5/5 isolated native pads/source; not full board',
 'source_schema':'914/914 keys809proven;0orphans;6reported preexisting ungoverned families',
 'preflights':'pod9/9; carrier standard9 corrected to9/9 and clock/power PASS. Extra early analog native check rightly rejects historical Micro-Fit netlist. Native regeneration owed.'},
 'raw_failures':'All original checker false PASS controls, harness/setup failures, schema failure and wrong-time old-netlist analog refusal retained. Runtime delivery PASS is not engineering acceptance.'}
payload['ROOT_REOPEN_AUDIT.json']=(json.dumps(audit,indent=2)+'\n').encode()
payload['README.md']=b'''# Held Weidmuller RJ45 integration checkpoint

Start with ROOT_REOPEN_AUDIT.json. held_candidate contains the proposed source,
not adopted engineering. closed_reviews preserves actual original proposals,
native counterexamples, decisions, hashes, raw commands and delivery closure.
The first complete integration verdict is REJECT. Later root fixes and the
active second review do not turn that rejected frozen subject into acceptance.
Root runtime logs include expected RED failures and setup errors. Current
connector SOURCE PASS leaves physical FULL INCOMPLETE and all later native,
schematic, placement, route, DRC, release and first-article gates mandatory.
Historical Micro-Fit netlist is only an explicitly identified test adapter
fixture for unchanged NC/footprint spelling, never an RJ45 native census.
'''
manifest={'schema':1,'files':[{'path':n,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(payload.items())]}
mb=(json.dumps(manifest,indent=2)+'\n').encode();out=N/'weid-integration-checkpoint.tmp'
with out.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w') as tar:
            for n,b in sorted({**payload,'MANIFEST.json':mb}.items()):
                info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;tar.addfile(info,io.BytesIO(b))
with tarfile.open(out,'r:gz') as tar:
    members=tar.getmembers();assert len({m.name for m in members})==len(members)==len(payload)+1
    for m in members:
        assert m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts
        expected=mb if m.name=='MANIFEST.json' else payload[m.name];assert tar.extractfile(m).read()==expected
b=out.read_bytes();h=hashlib.sha256(b).hexdigest();dest=R/'projects/crow-audio-carrier-v1/01_docs/journal'/(h+'.tar.gz')
assert not dest.exists();dest.write_bytes(b)
summary={'archive':str(dest),'sha256':h,'size':len(b),'payload_members':len(payload),'all_members_reopened':True,'candidate_files':audit['candidate_files'],'closed_reviews':checks}
(N/'weid-integration-checkpoint-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with (dest.parent/'contracts.md').open('a') as f:
    f.write(f'\n## Allowed held Weidmuller source integration checkpoint\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Original rejected source review, independent nominal review, completed availability, held corrected source, native RED/GREEN controls and raw source preflights; no source/native/release adoption |\n\nAudit: SHA-256 equals filename; {len(b)} bytes, {len(payload)} regular payload members plus MANIFEST.json, all reopened. Reject duplicate/link/traversal/extra members. Original failed verdicts remain unchanged.\n')
print(json.dumps(summary,indent=2))
