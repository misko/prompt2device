from pathlib import Path
from datetime import datetime, timezone, timedelta
import sys, json, hashlib, shutil, tempfile

R = Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
D = Path(__file__).parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(R / 'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput, subject_identity
from pipeline_runtime import open_agent_attempt

name = 'rj45-harting-completion'
root = Path(tempfile.mkdtemp(prefix='carrier-rj45-harting-'))
(root / 'input').mkdir()
paths = [
 R/'CLAUDE.md',
 R/'skills/pcb-design/references/connector-assembly-contract.md',
 R/'projects/crow-audio-carrier-v1/01_docs/research/2026-09-12-rj45-source-backtrack.md',
 R/'projects/crow-audio-carrier-v1/03_src/rules/spoke_interface.yaml',
 Path('/tmp/carrier-rj45-cable-selection-hkl9acsz/06_build/task_runs/rj45-cable-selection/outputs/report.md'),
 Path('/tmp/carrier-rj45-cable-selection-hkl9acsz/06_build/task_runs/rj45-cable-selection/outputs/evidence.json'),
]
for i, p in enumerate(paths):
 shutil.copyfile(p, root/'input'/f'{i:02d}-{p.name}')
shutil.copyfile('/tmp/carrier-rj45-cable-selection-hkl9acsz/preflight.py',root/'preflight.py')
now = datetime.now(timezone.utc)
cut = now + timedelta(minutes=16)
hard = now + timedelta(minutes=19)
task = f'''Source-authoring task: complete exact HARTING 09484747743150 cord facts for the user-approved RJ45/Cat6 redesign. This is a new selected-candidate implementation input after the completed first catalog research, not a rerun or replacement of that attempt. Previous research selected Phoenix1227591 but it cannot cover the existing pod -30 C operation. Preserve that result; do not edit it or claim it accepted. Root owns the jack and PCB source in parallel; you have no live write authority.

Preferred candidate is HARTING RJI DB Cat6A cable assembly grey PUR 15 m, 09484747743150. Primary assembly page https://www.harting.com/pl-PL/p/RJI-DB-Cat6a-Cable-Assy-grey-PUR-15m-09484747743150 ; underlying cable candidate https://www.harting.com/en-AE/p/HARTING-IE-Cat-6A-4x2xAWG26-7-PUR-grey-094560006000301 . Catalog https://b2b.harting.com/files/livebooks/en/PRD0200000100235/downloads/livebook.pdf . Confirm exact cable/connector BOM mapping; matching descriptive name alone is weaker than linked exact BOM.

Known lead: manufacturer assembly page 15m, both ends DualBoot RJ45, 4x2x26/7 PUR, -40..80 C. Cable page says UV/oil resistance, 290 ohm/km LOOP resistance; plausible at26AWG. Need exact primary PDF/model/drawing with complete plug + latch + boot LENGTH as well as width/height (catalog front13.8x13.3 is insufficient for full grip). Find exact male DualBoot connector identity or full assembly STEP/technical drawing from manufacturer. Verify standard8P8C straight T568B pin1..8 and shield continuity; retrieve raw primary bytes, record URL/time/SHA and actually inspect drawing images. If only a conservative full envelope can be justified, explain source and error bar; do not measure an undimensioned image as exact or invent dimensions. Avoid endless catalogs: one exact candidate, 16 minute work bound.

Complete source-owned cord part.yaml and primary-source-record.md proposals in scratch if facts allow, including exact ordinary ordering variant, raw PDF locally SHA-bound, diameter max/min, fixed bend radius, UV/moisture/temp properties, conductor DCR, mating current/contact R, all8wired pins. Recompute 15m75C loop with3parallel power pairs and existing0.300ohm combinedcontactallocation; 290 loop should yield2.1125ohm including allocation, but verify what resistance field actually means. Preserve2.2ohm ceiling/10.8Vcarrier/0.1A/10.5Vpod. Jack proposal Wurth615008160221 direct8contacts,20mohm max,1.5A,-40..85C. Proposed signalmap pins1/3/7 positive,2/6/8 GND,5 AUDIO+,4 AUDIO-. No Ethernet/PoE/hotplug claim. All plug zones are enclosed; qualify moisture/condensation and panel entry before hardware acceptance. Do not assert outdoorIP20 connectors are weatherproof. Exact cable should support existing -30..70C pod and75C hot-cable argument.

READ_ONLY frozen inputs. All new helpers/downloads/raw logs/figures in allocated scratch, declared outputs only in outputs. Every subprocess through pipeline_runtime.run_stage imported from {R}/skills/pcb-design/scripts, every Python /usr/bin/python3 -B. Network read/download allowed. No children, source edits, board generation, purchase, vendor messages or installs outside scratch. Verify every input SHA/size before and after. Preserve original failures/drafts when correcting within this one attempt.

Delivery exactly report.md,evidence.json,evidence-manifest.json,evidence.tar.gz,result.json. Archive actual primary source bytes and every supporting method/raw log/viewed figure; manifest each file size/SHA and archive. Evidence report separates confirmed facts, proposals and unresolved facts. Result exact envelope.subject, checks evidence-complete,inputs-verified,review-complete; delivery PASS may report incomplete engineering selection honestly. Mandatory preflight /usr/bin/python3 -B {root}/preflight.py {root}/06_build/task_runs/{name}/envelope.json before FINAL. Actual work/FINAL cutoff {cut.isoformat()}, hard {hard.isoformat()}. Finish promptly once complete; root closes after actual host FINAL.
'''
(root/'TASK.md').write_text(task)
items=[]
for f in sorted(root.rglob('*')):
 if f.is_file():
  b=f.read_bytes();items.append({'name':f'input_{len(items):04d}','path':f.relative_to(root).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
subject=subject_identity('rj45_harting_cord_source',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
env=TaskEnvelope(schema=2,task_id=name,stage_id='PCB-SOURCING',run_id=name,subject=subject,executor='agent',execution_class='network',recommended_agent_role='authoring',agent_role='authoring',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']})
opened=open_agent_attempt(env,cwd=root)
opened.update(project=str(root),envelope=str(root/env.output_path).replace('attempt.json','envelope.json'),task=str(root/'TASK.md'),agent_id='/root/carrier_rj45_harting_completion',work_cutoff=cut.isoformat())
(D/(name+'-opened.json')).write_text(json.dumps(opened,indent=2)+'\n')
print(json.dumps(opened,indent=2))
