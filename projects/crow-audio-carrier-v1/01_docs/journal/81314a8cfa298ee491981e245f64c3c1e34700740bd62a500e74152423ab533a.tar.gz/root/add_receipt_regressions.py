from pathlib import Path
N=Path(__file__).parent
C=N/'integrated_source_candidate'
p=C/'tests/t1_crow_spoke_interface.py'
s=p.read_text().replace('import importlib.util\n','import importlib.util\nimport hashlib\nimport json\nimport subprocess\nfrom unittest import mock\n')
extra='''

def receipt_fixture(contract_bytes=None):
    """Ordinary dummy subject bytes exercise binding, not native geometry.

    These cases distinguish the rejected 2026-09-12 author proposal (which
    accepted stale subjects and duplicate pads) from the preserved checker.
    Root retained RED/GREEN evidence against that unadopted proposal.
    """
    root = fixture()
    spec = module.CHILDREN["pod"]
    project = root / spec["root"]
    if contract_bytes is not None:
        (project / "03_src/rules/spoke_interface.yaml").write_bytes(contract_bytes)
    bindings = {}
    for kind in ("board", "schematic"):
        path = project / spec[kind]
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = ("fixture " + kind + " bytes\\n").encode()
        path.write_bytes(payload)
        bindings[kind] = {"path": spec[kind], "size": len(payload),
                          "sha256": hashlib.sha256(payload).hexdigest()}
    checker = project / spec["checker"]
    checker.parent.mkdir(parents=True, exist_ok=True)
    checker.write_text("# immutable mocked child checker\\n")
    raw = (project / "03_src/rules/spoke_interface.yaml").read_bytes()
    pads = {1: "12V_POD", 2: "GND", 3: "12V_POD", 4: "AUDIO_N",
            5: "AUDIO_P", 6: "GND", 7: "12V_POD", 8: "GND",
            9: "POD_SHIELD", 10: "POD_SHIELD"}
    receipt = {"schema": 1, "kind": "crow-spoke-implementation-v1", "role": "pod",
               "contract_sha256": hashlib.sha256(raw).hexdigest(),
               "denominator": {"expected": 1, "realized": 1}, **bindings,
               "connectors": [{"ref": "J1", "mpn": "615008160221",
                               "footprint": "crow_mic_pod_v3:Wurth_615008160221_RJ45",
                               "pads": [{"number": n, "net": net} for n, net in pads.items()]}]}
    return root, receipt


@test("RJ45 receipts bind both current board and schematic bytes", kind="known_bad")
def t_rj45_stale_subject_receipt():
    for kind in ("board", "schematic"):
        root, receipt = receipt_fixture()
        module._validate_child_receipt(root, "pod", receipt)
        subject = root / module.CHILDREN["pod"]["root"] / receipt[kind]["path"]
        subject.write_bytes(subject.read_bytes() + b"changed")
        try:
            module._validate_child_receipt(root, "pod", receipt)
        except module.ContractError:
            continue
        raise AssertionError(f"stale {kind} receipt accepted")


@test("RJ45 receipts reject duplicate physical pad records", kind="known_bad")
def t_rj45_duplicate_pad_receipt():
    root, receipt = receipt_fixture()
    module._validate_child_receipt(root, "pod", receipt)
    pads = receipt["connectors"][0]["pads"]
    pads.append(copy.deepcopy(pads[0]))
    try:
        module._validate_child_receipt(root, "pod", receipt)
    except module.ContractError:
        return
    raise AssertionError("duplicate pad record accepted")


@test("RJ45 child execution rejects duplicate JSON keys", kind="known_bad")
def t_rj45_duplicate_receipt_json():
    root, receipt = receipt_fixture()
    raw = json.dumps(receipt)
    result = subprocess.CompletedProcess(["fixture"], 0, stdout=raw, stderr="")
    with mock.patch.object(module.subprocess, "run", return_value=result):
        module._run_child_checker(root, "pod")
    result.stdout = raw[:-1] + ', "schema": 1}'
    with mock.patch.object(module.subprocess, "run", return_value=result):
        try:
            module._run_child_checker(root, "pod")
        except module.ContractError:
            return
    raise AssertionError("duplicate receipt JSON key accepted")

'''
s=s.replace('if __name__ == "__main__":',extra+'if __name__ == "__main__":')
p.write_text(s)
(N/'source_validation/tests/t1_crow_spoke_interface.py').write_text(s)
print('Added three discriminating receipt regressions; original tests retained')
