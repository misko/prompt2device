from pathlib import Path
import pcbnew,json,math
N=Path(__file__).parent;C=N/'integrated_source_candidate/projects/crow-audio-carrier-v1';rows=[]
for jx,jy,rot,ux,uy in [(36,25.86,0,39.57,27.86),(45,114.14,180,41.43,112.14)]:
 b=pcbnew.BOARD()
 j=pcbnew.FootprintLoad(str(C/'03_src/lib/crow_audio_carrier.pretty'),'Wurth_615008160221_RJ45')
 u=pcbnew.FootprintLoad('/usr/share/kicad/footprints/Package_TO_SOT_SMD.pretty','SOT-553')
 assert j and u
 for fp,x,y in [(j,jx,jy),(u,ux,uy)]:
  fp.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(x),pcbnew.FromMM(y)));fp.SetOrientationDegrees(rot);b.Add(fp)
 u.Flip(u.GetPosition(),False)
 def pads(fp):return {p.GetNumber():[pcbnew.ToMM(p.GetPosition().x),pcbnew.ToMM(p.GetPosition().y)] for p in fp.Pads() if p.GetNumber()}
 jp,up=pads(j),pads(u)
 rows.append({'source_rotation_before_flip':rot,'saved_bottom_rotation':u.GetOrientationDegrees(),'jack_pads':jp,'clamp_pads':up,'prefix_spans_mm':{a+'-'+c:math.dist(jp[a],up[c]) for a,c in [('5','3'),('4','5')]}})
(N/'carrier-bottom-transform-native.json').write_text(json.dumps({'scope':'two isolated footprint transforms, not board generation or clearance acceptance','rows':rows},indent=2)+'\n');print(json.dumps(rows,indent=2))
