from pathlib import Path
import json,math
import pcbnew
N=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');C=N/'component_source_candidate'
expected={'1':(0,0),'2':(1.02,4),'3':(2.04,0),'4':(3.06,4),'5':(4.08,0),'6':(5.1,4),'7':(6.12,0),'8':(7.14,4),'9':(10.97,-2.35),'10':(-3.83,-2.35)}
rows=[]
for slug,lib in [('crow-audio-carrier-v1','crow_audio_carrier'),('crow-mic-pod-v3','crow_mic_pod_v3')]:
 d=C/'projects'/slug/'03_src/lib'/(lib+'.pretty')
 fp=pcbnew.FootprintLoad(str(d),'Wurth_615008160221_RJ45');assert fp
 actual={};npth=[]
 for p in fp.Pads():
  xy=tuple(round(pcbnew.ToMM(v),6) for v in (p.GetPosition().x,p.GetPosition().y));key=p.GetNumber()
  if not key:npth.append(xy);continue
  assert key not in actual
  actual[key]=xy
 assert actual==expected,(slug,actual)
 assert sorted(npth)==[(-3.28,0.7),(10.42,0.7)]
 rows.append({'project':slug,'pins':actual,'npth':npth})
d=R/'projects/crow-mic-pod-v3/03_src/lib/crow_mic_pod_v3.pretty'
fp=pcbnew.FootprintLoad(str(d),'TI_TPD2E2U06_DRL');assert fp
fp.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(3.57),pcbnew.FromMM(2.0)))
fp.Flip(fp.GetPosition(),False)
pads={p.GetNumber():(pcbnew.ToMM(p.GetPosition().x),pcbnew.ToMM(p.GetPosition().y)) for p in fp.Pads()}
results=[]
for angle in [0,180]:
 fp.SetOrientationDegrees(angle)
 pads={p.GetNumber():(pcbnew.ToMM(p.GetPosition().x),pcbnew.ToMM(p.GetPosition().y)) for p in fp.Pads()}
 dist={a+'-'+b:math.dist(expected[a],pads[b]) for a,b in [('5','3'),('4','5')]}
 results.append({'bottom_rotation':angle,'layer':fp.GetLayerName(),'pads':pads,'span_mm':dist})
out={'native_jack_geometry':rows,'bottom_clamp_source_feasibility':results,'scope':'isolated footprint pad/side transform only, not routed/assembled clearance acceptance'}
(N/'component-geometry-native.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
