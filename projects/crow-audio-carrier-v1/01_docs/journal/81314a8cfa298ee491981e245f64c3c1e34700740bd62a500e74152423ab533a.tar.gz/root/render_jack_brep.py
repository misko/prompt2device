from pathlib import Path
import sys
sys.path.insert(0, '/tmp/carrier-rj45-20260912/cad-libs')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
sys.path.insert(0, '/tmp/carrier-rj45-20260912/cad-libs')
from OCP.STEPControl import STEPControl_Reader
from OCP.IFSelect import IFSelect_RetDone
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRep import BRep_Tool
from OCP.TopLoc import TopLoc_Location
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE
from OCP.TopoDS import TopoDS

D=Path('/tmp/carrier-rj45-20260912')
p=Path('/tmp/carrier-rj45-jack-selection-pntbys98/06_build/task_runs/rj45-jack-selection/scratch/wurth_615008160221.step')
r=STEPControl_Reader(); assert r.ReadFile(str(p))==IFSelect_RetDone
r.TransferRoots(); shape=r.OneShape()
BRepMesh_IncrementalMesh(shape,.05,False,.3,True)
triangles=[];colors=[]
solids=TopExp_Explorer(shape,TopAbs_SOLID);sid=0
while solids.More():
 fs=TopExp_Explorer(solids.Current(),TopAbs_FACE)
 color='#878f97' if sid==5 else '#222831' if sid in (0,2) else '#d4a646'
 while fs.More():
  face=TopoDS.Face_s(fs.Current());loc=TopLoc_Location()
  mesh=BRep_Tool.Triangulation_s(face,loc)
  if mesh:
   for j in range(1,mesh.NbTriangles()+1):
    pts=[]
    for i in mesh.Triangle(j).Get():
     v=mesh.Node(i).Transformed(loc.Transformation());pts.append([v.X(),v.Y(),v.Z()])
    triangles.append(pts);colors.append(color)
  fs.Next()
 solids.Next();sid+=1
triangles=np.array(triangles);colors=np.array(colors)
fig,axes=plt.subplots(1,3,figsize=(15,6))
for ax,ind,title in zip(axes,[(0,1,2),(0,2,1),(1,2,0)],['Top: raw STEP X/Y, viewed from +Z','Side: raw STEP X/Z, viewed from +Y','End: raw STEP Y/Z, viewed from +X']):
 order=np.argsort(triangles[:,:,ind[2]].mean(axis=1))
 poly=triangles[order][:,:,list(ind[:2])]
 ax.add_collection(PolyCollection(poly,facecolors=colors[order],edgecolors='none'))
 ax.autoscale(); ax.set_aspect('equal');ax.grid(alpha=.2);ax.set_title(title,fontsize=10)
 ax.set_xlabel('XYZ'[ind[0]]+' / mm');ax.set_ylabel('XYZ'[ind[1]]+' / mm')
 ax.axhline(0,color='red',linewidth=.5)
fig.suptitle('Würth 615008160221 manufacturer STEP — raw frame, no registration applied')
fig.tight_layout();fig.savefig(D/'jack-brep-three-views.png',dpi=150)
print('triangles',len(triangles),'solids',sid,'image',D/'jack-brep-three-views.png')
