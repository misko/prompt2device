from pathlib import Path
import yaml
C=Path(__file__).parent/'weid_source_candidate'
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
    rules=C/'projects'/slug/'03_src/rules'
    p=rules/'connector_assemblies.yaml';d=yaml.safe_load(p.read_text())
    assert not any(s['id']=='first-article-plan' for s in d['evidence_sources'])
    d['evidence_sources'].append({'id':'first-article-plan','kind':'qualification-plan','path':'01_docs/FIRST_ARTICLE_TEST_PLAN.md'})
    a=next(a for a in d['assemblies'] if a['id'].startswith('factory-rj45-spoke'))
    def bind(value):
        if isinstance(value,dict):
            if value.get('grade')=='unknown' and 'source_ids' in value:
                value['source_ids'].append('first-article-plan')
            for child in value.values():bind(child)
        elif isinstance(value,list):
            for child in value:bind(child)
    bind(a)
    p.write_text(yaml.safe_dump(d,sort_keys=False,width=95))
    p=rules/'connector_assembly_phases.yaml';d=yaml.safe_load(p.read_text())
    for row in d['source_deferrals']:
        if row['assembly_id'].startswith('factory-rj45-spoke'):row['plan_source_ids'].append('first-article-plan')
    p.write_text(yaml.safe_dump(d,sort_keys=False,width=95))
    print(slug,'bound physical qualification plan')
