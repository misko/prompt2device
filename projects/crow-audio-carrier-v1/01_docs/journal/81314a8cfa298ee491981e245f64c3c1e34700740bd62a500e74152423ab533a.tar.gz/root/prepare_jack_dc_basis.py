from pathlib import Path
import urllib.request,hashlib,json
N=Path(__file__).parent;C=N/'weid_source_candidate'
u='https://www.we-online.com/en/components/products/WR_MJ_MODULAR_JACKS_OVER'
b=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=60).read()
assert b'615008160221' in b and b'PoE++' in b
p=N/'wurth-gigabit-jacks.html';p.write_bytes(b)
(N/'wurth-gigabit-jacks-source.json').write_text(json.dumps({'url':u,'sha256':hashlib.sha256(b).hexdigest(),'size':len(b),'retrieved':'2026-09-12','scope':'Manufacturer family application statement on the page listing exact 615008160221; not a DC absolute maximum datasheet row'},indent=2)+'\n')
note='''
## DC application basis — source review pending

The exact manufacturer's [Gigabit modular-jack product page](https://www.we-online.com/en/components/products/WR_MJ_MODULAR_JACKS_OVER)
lists 615008160221 in the range stated to be PoE++ compatible under
IEEE 802.3bt. This is application evidence separate from the exact datasheet's
150 VAC working rating. The latter remains explicitly AC and is never copied
into a DC maximum field. Retrieved 2026-09-12; raw page SHA-256:
`HASH`.

Engineering inference for source review: PoE uses DC common-mode power on
these contacts, with a 57 V supply ceiling. A corroborating manufacturer
[PoE++ application page](https://www.we-online.com/en/components/products/WE-POE-PLUS-PLUS)
identifies 37–57 V DC input in that application. It is contextual voltage
information, not a rating transferred from a transformer to this jack.

For this power-off-mated, dry IP20, 13.2 V maximum normal spoke, adopt a
project insulation design ceiling of 28.5 V DC (57/2, a project 2x reserve).
The existing E-SURGE recommended/absolute comparison fields both use that
same deliberately lower project ceiling; neither asserts that the manufacturer
publishes a 28.5 V or 150 V DC absolute maximum. The 24.4 V component clamp
plus 10% coordination margin is 26.84 V, below 28.5 V by 1.66 V.
This is a bounded application assessment, not an AC-to-DC conversion, current
rating, surge waveform guarantee, PoE interoperability claim or hot-plug rating.
Physical first-article qualification and the upstream transient/source bounds
remain owed under the existing first-article-only restriction.
'''.replace('HASH',hashlib.sha256(b).hexdigest())
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 p=C/'projects'/slug/'02_parts/615008160221/primary-source-record.md';p.write_text(p.read_text()+note)
p=C/'projects/crow-mic-pod-v3/03_src/rules/protection_paths.yaml';s=p.read_text();old='recommended_max_V: 150, absolute_max_V: 150, qualification: "Manufacturer working-voltage evidence is 150 VAC; applying it to the 24.4 V DC transient envelope requires explicit AC/DC qualification."';new='recommended_max_V: 28.5, absolute_max_V: 28.5, qualification: "Project DC insulation ceiling, not a manufacturer absolute rating: 57 V PoE application / 2 engineering reserve. Exact jack is listed on the manufacturer PoE++ range page; primary-source-record.md carries source, inference and limits. Do not convert the 150 VAC datasheet row to DC. Independent source review required."';assert old in s;p.write_text(s.replace(old,new))
p=C/'projects/crow-mic-pod-v3/01_docs/decisions/0007-rj45-factory-spoke.md'
if not p.exists():
 matches=list((C/'projects/crow-mic-pod-v3/01_docs/decisions').glob('0007*'));assert len(matches)==1;p=matches[0]
p.write_text(p.read_text()+'''\nThe pod J1 surge-coordination ceiling is a proposed project 28.5 V DC
insulation limit (57 V PoE application divided by a 2x engineering reserve),
not a re-labelled 150 VAC rating. The exact jack appears on Würth's PoE++
compatible range page. The part source record separates that application
inference from its published AC specifications and retains first-article
qualification; independent source review must accept this assessment.
''')
print(json.dumps({'html_bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'dc_design_ceiling':28.5,'clamp_with_margin':24.4*1.1}))
