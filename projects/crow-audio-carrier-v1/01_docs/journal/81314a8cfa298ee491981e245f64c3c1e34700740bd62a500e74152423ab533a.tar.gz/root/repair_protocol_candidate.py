from pathlib import Path
import ast,copy,hashlib,json,pprint,re,shutil,yaml
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
A=Path('/tmp/carrier-rj45-spoke-protocol-afdhti9e/06_build/task_runs/rj45-spoke-protocol/scratch/source_candidate');C=N/'protocol_source_candidate'
for p in A.rglob('*'):
 if p.is_file():
  t=C/p.relative_to(A);t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,t)
rel='projects/crow-roof-array-v1/03_src/rules/spoke_interface.yaml'
v=yaml.safe_load((A/rel).read_text())
v['connector']['contact_rating_a']=1.5
v['connector']['contact_rating_qualification_status']='MANUFACTURER_JACK_RATING_ONLY'
v['connector']['contact_resistance_max_mohm']=20.0
v['cable']['plug_contact_rating_a']=None
v['cable']['plug_contact_resistance_max_ohm']=None
v['cable']['plug_contact_qualification_status']='OWED'
v['cable']['construction']['copper_clad_aluminum_permitted']=False
v['cable']['power_budget']['maximum_service_temperature_c']=75.0
v['electrical']['supply_plane']='carrier_RJ45_parallel_contacts_1_3_7_to_2_6_8'
v['cable']['continuity_test']='unpowered straight-through1-1 through8-8 and shield continuity; no cross-short; finished-cord DC loop resistance <=2.2 ohm at maximum service temperature'
raw=yaml.safe_dump(v,sort_keys=False);digest=hashlib.sha256(raw.encode()).hexdigest()
for slug in ['crow-roof-array-v1','crow-audio-carrier-v1','crow-mic-pod-v3']:
 (C/'projects'/slug/'03_src/rules/spoke_interface.yaml').write_text(raw)
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 p=C/'projects'/slug/'03_src/check_spoke_implementation.py'
 s=p.read_text().replace('44948e84aa143d199f18a9055813e53d6c55d682815035cddca0adbf86d15924',digest);p.write_text(s)
parent=R/'projects/crow-roof-array-v1/03_src/check_spoke_interface.py';s=parent.read_text()
start=s.index('EXPECTED = {');end=s.index('\n\n\nclass ContractError',start)
s=s[:start]+'EXPECTED = '+pprint.pformat(v,sort_dicts=False,width=98)+s[end:]
s=s.replace('import json\n','import json\nimport math\n')
s=s.replace('crow_audio_carrier:Molex_43650-0400_RA_Exact','crow_audio_carrier:Wurth_615008160221_RJ45').replace('Molex_Micro-Fit_3.0_43650-0400_1x04_P3.00mm_Horizontal','Wurth_615008160221_RJ45')
start=s.index('def cable_power_budget(');end=s.index('\n\ndef verify_contracts(',start)
budget='''def cable_power_budget(value: dict) -> dict:
    """Screen three distinct balanced power pairs and the complete hot DC loop.

    Manufacturer maximum DCR is a pair LOOP value; dividing by three accounts
    for the three independently terminated pairs in parallel. The contact
    allowance is an unmeasured design allocation, never a cord rating.
    """
    cable = value["cable"]
    rows = cable["conductor_map"]
    expected = {1: ("orange", "+12V_POD"), 2: ("orange", "GND"),
                3: ("green", "+12V_POD"), 6: ("green", "GND"),
                7: ("brown", "+12V_POD"), 8: ("brown", "GND")}
    power_rows = [row for row in rows if row.get("signal") in {"+12V_POD", "GND"}]
    actual = {row.get("cavity"): (row.get("pair"), row.get("signal")) for row in power_rows}
    if len(power_rows) != 6 or actual != expected:
        raise ContractError("power requires six distinct correctly paired contacts")

    def positive(name: str, number: object) -> float:
        if (isinstance(number, bool) or not isinstance(number, (int, float))
                or not math.isfinite(number) or number <= 0):
            raise ContractError(f"{name} must be finite and positive")
        return float(number)

    budget = cable["power_budget"]
    electrical = value["electrical"]
    length = positive("design length", cable["maximum_design_length_m"])
    dcr = positive("pair loop DCR", cable["construction"]["maximum_loop_dcr_ohm_per_km_at_20c"])
    hot_factor = positive("hot factor", budget["hot_resistance_multiplier"])
    allocation = positive("contact allocation", budget["loop_contact_allocation_ohm"])
    current = positive("pod current", electrical["maximum_continuous_pod_current_a"])
    supply = positive("carrier minimum", electrical["carrier_header_supply_min_v"])
    limit = positive("finished loop limit", electrical["maximum_cable_and_contact_loop_resistance_ohm"])
    minimum = positive("pod minimum", electrical["pod_header_supply_min_v_at_max_current_and_length"])
    if current > 0.100:
        raise ContractError("pod current exceeds the commissioned 0.100 A boundary")
    hot_loop = length / 1000 * dcr / 3 * hot_factor + allocation
    drop = hot_loop * current
    pod_voltage = supply - drop
    if hot_loop > limit or pod_voltage < minimum:
        raise ContractError(f"hot harness loop fails: {hot_loop:.6f} ohm, {pod_voltage:.6f} V")
    return {"power_conductors": 6,
            "design_hot_loop_ohm": round(hot_loop, 6),
            "design_drop_v": round(drop, 6),
            "design_pod_min_v": round(pod_voltage, 6),
            "physical_qualification": "OWED"}
'''
s=s[:start]+budget+s[end:]
s=s.replace('"pins": 4,','"pins": 8,\n        "electrical_pads_per_connector": 10,')
start=s.index('def _expected_nets(');end=s.index('\n\ndef _validate_binding',start)
s=s[:start]+'''def _expected_nets(role: str, ref: str) -> dict[int, str]:
    suffix = str(int(ref[1:])) if role == "carrier" else ""
    shell = "CHASSIS" if role == "carrier" else "POD_SHIELD"
    return {1: f"12V_POD{suffix}", 2: "GND", 3: f"12V_POD{suffix}",
            4: f"AUDIO_N{suffix}", 5: f"AUDIO_P{suffix}", 6: "GND",
            7: f"12V_POD{suffix}", 8: "GND", 9: shell, 10: shell}
'''+s[end:]
s=s.replace('"realized_straight_through_pin_paths": 32,','"realized_straight_through_pin_paths": 64,\n        "realized_shell_pads": 18,').replace('32/32 straight-through pin paths','64/64 straight-through contact paths; 18/18 shell pads')
(C/'projects/crow-roof-array-v1/03_src/check_spoke_interface.py').write_text(s)
# Keep the complete native-parser, stale-binding and timeout regression suite.
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 rel='projects/'+slug+'/03_src/tests/test_check_spoke_implementation.py'
 old=(R/rel).read_text()
 if slug=='crow-audio-carrier-v1':
  extra='''
    def test_rj45_map_has_all_contacts_and_isolated_shells(self):
        self.assertEqual(checker.expected_pads("J1"), {
            "1": "12V_POD1", "2": "GND", "3": "12V_POD1", "4": "AUDIO_N1",
            "5": "AUDIO_P1", "6": "GND", "7": "12V_POD1", "8": "GND",
            "9": "CHASSIS", "10": "CHASSIS"})

    def test_rj45_missing_contact_audio_swap_and_grounded_shell_rejected(self):
        for mutation in ("missing", "swap", "shield"):
            hostile = valid_rows()
            pads = checker.expected_pads("J1")
            if mutation == "missing": pads.pop("7")
            elif mutation == "swap": pads["4"], pads["5"] = pads["5"], pads["4"]
            else: pads["9"] = "GND"
            hostile[0] = row("J1", pads=pads)
            with self.assertRaises(checker.AuditError):
                checker._validate_realizations("fixture", hostile)
'''
  old=old.replace('\n\nif __name__ == "__main__":', '\n'+extra+'\n\nif __name__ == "__main__":')
 else:
  # Agent kept the existing pod test suite and appended new RJ45 hostiles.
  old=(A/rel).read_text()
 (C/rel).write_text(old)
rel='tests/t1_crow_spoke_interface.py';s=(R/rel).read_text()
s=s.replace('result["pins"], 4','result["pins"], 8').replace('result["realized_straight_through_pin_paths"], 32','result["realized_straight_through_pin_paths"], 64')
s=s.replace('{"blue": {3, 4}, "orange": {1, 2}, "green": {1, 2}, "brown": {1, 2}}','{"blue": {4, 5}, "orange": {1, 2}, "green": {3, 6}, "brown": {7, 8}}')
s=s.replace('pigtails_joins_contacts_loop_allowance_ohm','loop_contact_allocation_ohm').replace('Cat harness budget includes joins, pigtails and contacts','RJ45 harness budget includes both ends of the mated contacts')
extra='''
@test("RJ45 checker rejects missing and duplicate parallel contacts", kind="known_bad")
def t_rj45_parallel_contact_census():
    for duplicate in (False, True):
        value = copy.deepcopy(module.EXPECTED)
        rows = value["cable"]["conductor_map"]
        row = next(r for r in rows if r["cavity"] == 7)
        if duplicate: row["cavity"] = 3
        else: rows.remove(row)
        try: module.cable_power_budget(value)
        except module.ContractError: continue
        raise AssertionError("incomplete or duplicate power contact accepted")

@test("RJ45 budget rejects invalid scalars and excess pod current", kind="known_bad")
def t_rj45_invalid_budget():
    for group, field, bad in [
        ("construction", "maximum_loop_dcr_ohm_per_km_at_20c", float("nan")),
        ("power_budget", "hot_resistance_multiplier", -1),
        ("power_budget", "loop_contact_allocation_ohm", float("inf")),
        ("electrical", "maximum_continuous_pod_current_a", 0.11)]:
        value = copy.deepcopy(module.EXPECTED)
        owner = value[group] if group == "electrical" else value["cable"][group]
        owner[field] = bad
        try: module.cable_power_budget(value)
        except module.ContractError: continue
        raise AssertionError(f"invalid {group}.{field} accepted")

@test("RJ45 budget independently reproduces the maximum-length hot loop")
def t_rj45_hot_loop():
    budget = module.cable_power_budget(copy.deepcopy(module.EXPECTED))
    eq(budget["design_hot_loop_ohm"], 2.1125, "15 m hot loop")
    eq(budget["design_pod_min_v"], 10.58875, "pod minimum")

'''
s=s.replace('\nif __name__ == "__main__":','\n'+extra+'if __name__ == "__main__":')
(C/rel).write_text(s)
# Retain the original parser fixture as a historical-format regression, not a
# new RJ45 implementation witness. Shared parser/harness are scratch support.
for rel in ['tests/harness.py','projects/crow-audio-carrier-v1/03_src/tests/fixtures/kicad10_native_excerpt.net','skills/kicad-pcb/scripts/kicad_sch_parity.py']:
 out=C/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,out)
for p in C.rglob('*.py'):ast.parse(p.read_text())
print('Corrected contract',digest,'; restored original binding/schema/duplicate/parser checks; native acceptance owed')
(N/'protocol-repair-summary.json').write_text(json.dumps({'contract_sha256':digest,'rejected_author_scope':['parent checker rewrite removed board/schematic binding and duplicate JSON/pad checks','carrier tests deleted native parser coverage','jack contact rating incorrectly unknown; actual1.5A','75C hot boundary and explicit CCA prohibition omitted'],'root_candidate':str(C)},indent=2)+'\n')
