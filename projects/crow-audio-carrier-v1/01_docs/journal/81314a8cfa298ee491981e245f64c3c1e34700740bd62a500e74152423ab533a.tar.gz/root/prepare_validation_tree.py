from pathlib import Path
import shutil,json,hashlib
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;V=N/'source_validation';C=N/'integrated_source_candidate'
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3','crow-roof-array-v1']:
 p=R/'projects'/slug
 for rel in ['02_parts','03_src','01_docs/evidence','01_docs/decisions']:
  src=p/rel
  if src.exists():shutil.copytree(src,V/'projects'/slug/rel,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
 for rel in ['01_docs/BRIEF.md','01_docs/capability-profile.json']:
  if (p/rel).is_file():
   out=V/'projects'/slug/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p/rel,out)
for rel in ['tests/harness.py','skills/kicad-pcb/scripts/kicad_sch_parity.py']:
 out=V/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,out)
for p in C.rglob('*'):
 if p.is_file():
  out=V/p.relative_to(C);out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out)
print(V)
