from pathlib import Path
import importlib.util, sys, copy, json, subprocess
from unittest import mock
N=Path(__file__).parent;V=N/'source_validation'
sys.path.insert(0,str(V/'tests'))
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
suite=load('receipt_suite',V/'tests/t1_crow_spoke_interface.py');good=suite.module
A=Path('/tmp/carrier-rj45-spoke-protocol-afdhti9e/06_build/task_runs/rj45-spoke-protocol/scratch/source_candidate')
bad=load('rejected_author',A/'projects/crow-roof-array-v1/03_src/check_spoke_interface.py')
raw=(A/'projects/crow-mic-pod-v3/03_src/rules/spoke_interface.yaml').read_bytes()
rows=[]
# Each implementation gets the same unmodified original author's contract
# bytes in the receipt-binding fixture. This isolates receipt validation; it
# does not claim the old contract would pass the corrected full system gate.
for defect in ['board','schematic','duplicate-pad','duplicate-json']:
 root,receipt=suite.receipt_fixture(raw)
 good._validate_child_receipt(root,'pod',receipt);bad._validate_receipt(root,'pod',receipt)
 if defect in ['board','schematic']:
  p=root/good.CHILDREN['pod']['root']/receipt[defect]['path'];p.write_bytes(p.read_bytes()+b'changed')
 elif defect=='duplicate-pad':receipt['connectors'][0]['pads'].append(copy.deepcopy(receipt['connectors'][0]['pads'][0]))
 decisions={}
 for label,module,validate,execute in [('preserved',good,good._validate_child_receipt,good._run_child_checker),('rejected',bad,bad._validate_receipt,bad._run_child)]:
  try:
   if defect=='duplicate-json':
    payload=json.dumps(receipt)[:-1]+', "schema": 1}'
    result=subprocess.CompletedProcess(['fixture'],0,stdout=payload,stderr='')
    with mock.patch.object(module.subprocess,'run',return_value=result):execute(root,'pod')
   else:validate(root,'pod',receipt)
   decisions[label]='ACCEPTED'
  except module.ContractError as exc:decisions[label]='REJECTED';decisions[label+'_error']=str(exc)
 assert decisions['preserved']=='REJECTED',decisions
 assert decisions['rejected']=='ACCEPTED',decisions
 rows.append({'defect':defect,**decisions})
(N/'receipt-rejection-controls.json').write_text(json.dumps({'status':'PASS','controls':rows,'scope':'RED against unadopted author proposal; GREEN against preserved receipt validation. No claim of a bug in live baseline.'},indent=2)+'\n')
print(json.dumps(rows,indent=2))
