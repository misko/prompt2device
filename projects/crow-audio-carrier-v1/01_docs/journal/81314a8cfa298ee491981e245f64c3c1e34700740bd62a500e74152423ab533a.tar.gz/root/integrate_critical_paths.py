from pathlib import Path
import json,yaml
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;C=N/'weid_source_candidate';A='projects/crow-audio-carrier-v1';P='projects/crow-mic-pod-v3'
def read(rel):return ((C/rel) if (C/rel).exists() else R/rel).read_text()
def put(rel,s):
 p=C/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
# Source routing remains ordinary source input, not promoted copper.
r=read(A+'/03_src/route.yaml')
r=r.replace('      bootstrap: [BUCK_BST]', '      chassis: [CHASSIS]\n      bootstrap: [BUCK_BST]')
stubs=[]
rows=json.loads((N/'carrier-bottom-transform-corrected.json').read_text())['rows']
for n in range(1,9):
 row=rows[0 if n<=4 else 1];dx=32*((n-1)%4)
 for leg,jp,up in [('P','5','3'),('N','4','5')]:
  a=[row['jack_pads'][jp][0]+dx,row['jack_pads'][jp][1]];b=[row['clamp_pads'][up][0]+dx,row['clamp_pads'][up][1]]
  sign=1 if b[1]>a[1] else -1
  knee=[b[0],a[1]+sign*abs(b[0]-a[0])]
  stubs.append({'net':f'AUDIO_{leg}{n}','pin':f'J{n}.{jp}','segments':[{'layer':'B.Cu','width':.20,'pts':[[round(v,4) for v in pt] for pt in [a,knee,b]]}]})
addition='      # ADR0028: exact B.Cu connector-to-clamp prefixes; downstream\n      # branch dominance is regraded on saved copper, never inferred here.\n'+''.join('      - '+json.dumps(x,separators=(',',':'))+'\n' for x in stubs)
r=r.replace('    stubs:\n','    stubs:\n'+addition,1)
r=r.replace('class_layers: {ADC_CLOCK:', 'class_layers: {CHASSIS_SHIELD: [F.Cu, B.Cu], ADC_CLOCK:')
r=r.replace('    - {name: references,', '    - {name: chassis, group: chassis, track_width: 0.60, clearance: 0.25, max_iterations: 800000, max_probe_iterations: 60000, max_ripup: 30}\n    - {name: references,')
put(A+'/03_src/route.yaml',r)
s=read(A+'/03_src/rules/nets.yaml').replace('classes:\n','''classes:
  CHASSIS_SHIELD:
    intent: "RJ45 shell continuity, isolated from signal GND; each jack bonds locally to the panel through its EMI fingers"
    nets: [CHASSIS]
    current: "shield signal; no normal DC load and no protective-earth current rating"
    min_width: 0.60mm
    clearance: 0.25mm
    routing: "outer-layer shell interconnect; never use either inner GND reference plane"
    verify: "native shell net census, zero-unconnected DRC, and first-article shell/panel continuity and signal-GND isolation"
''',1);put(A+'/03_src/rules/nets.yaml',s)
# Reuse existing native source and saved-copper conductor call sites.
s=read(A+'/03_src/check_analog_paths.py')
s=s.replace('import copper_length_audit as length','import copper_length_audit as length\nimport critical_path_check as critical')
insert=s.index('\ndef _positive(')
s=s[:insert]+'''
def validate_entry_paths(config, route, pins):
    critical.validate_config(config)
    if config['layers'] != ['F.Cu','In1.Cu','In2.Cu','B.Cu'] or config['stackup_mm'] != [.2104,1.065,.2104]:
        raise PathError('entry path copper stack differs from carrier authority')
    expected = {}
    for n in range(1,9):
        for leg, jp, up in [('P',5,3),('N',4,5)]:
            start, clamp, target = f'J{n}.{jp}', f'U_ESD{n}.{up}', f'C_A{n}{leg}.1'
            net = f'AUDIO_{leg}{n}'
            actual = {f'{ref}.{pin}' for (ref,pin), name in pins.items() if name == net}
            if actual != {start, clamp, target}:
                raise PathError(f'{net}: entry/clamp/coupling endpoint census differs')
            expected[(start,clamp)] = (target,net)
    short = {(x['from'],x['to']):x for x in config['short_paths']}
    prefixes = {(x['from'],x['through']):x for x in config['prefixes']}
    if set(short) != set(expected) or set(prefixes) != set(expected):
        raise PathError('entry protection requires exact 16 prefixes and branch obligations')
    for pair,(target,net) in expected.items():
        row = short[pair]
        if row['max_length_mm'] != 4.2 or row['max_pad_centre_mm'] != 4.0 or row['layer'] != 'B.Cu' or prefixes[pair]['targets'] != [target]:
            raise PathError(f'{net}: changed protection path limit/layer/target')
        seeds = [x for x in route['prep']['seed_stubs']['stubs'] if x['net'] == net]
        if len(seeds) != 1 or seeds[0]['pin'] != pair[0] or seeds[0].get('vias') or not seeds[0].get('segments'):
            raise PathError(f'{net}: missing/duplicate/changed connector prefix seed')
        if any(x['layer'] != 'B.Cu' or x['width'] != .20 for x in seeds[0]['segments']):
            raise PathError(f'{net}: connector prefix seed layer/width differs')
    chassis = {f'{ref}.{pin}' for (ref,pin),name in pins.items() if name == 'CHASSIS'}
    if chassis != {f'J{n}.{p}' for n in range(1,9) for p in (9,10)}:
        raise PathError('carrier shell net must contain exactly sixteen RJ45 shield lands')
    if route['prep']['waves']['groups'].get('chassis') != ['CHASSIS'] or not any(x.get('group') == 'chassis' and x.get('track_width') == .60 for x in route['route']['waves']):
        raise PathError('CHASSIS lacks its declared outer-layer route owner')
    return {'status':'PASS','prefixes':16,'downstream_paths':16,'shield_pads':16,'realized_copper':'NOT_GRADED'}

''' +s[insert:]
s=s.replace("report['source'] = validate_source(groups, route, pins)","report['source'] = validate_source(groups, route, pins)\n        entry_config = critical.load_config(PROJECT/'03_src/rules/critical_paths.yaml')\n        report['entry_source'] = validate_entry_paths(entry_config, route, pins)")
s=s.replace("'03_src/check_analog_paths.py', floor", "'03_src/check_analog_paths.py', '03_src/rules/critical_paths.yaml', floor")
s=s.replace("result = length.grade(PROJECT, args.board)","report['entry_copper'] = critical.audit(args.board, entry_config)\n            if report['entry_copper']['verdict'] != 'PASS':\n                raise PathError('saved entry-clamp path or branch dominance failed')\n            result = length.grade(PROJECT, args.board)")
s=s.replace('except (PathError, length.AuditError,', 'except (PathError, critical.AuditError, length.AuditError,')
put(A+'/03_src/check_analog_paths.py',s)
# Bind shared implementation bytes alongside the existing source input hashes.
s=s.replace("if args.source_only:\n", "report['critical_path_checker_sha256'] = hashlib.sha256(Path(critical.__file__).read_bytes()).hexdigest()\n        if args.source_only:\n");put(A+'/03_src/check_analog_paths.py',s)
# Existing conductor hooks in both projects remain the only route acceptance
# path. No new project-only copied graph or disabled native test.
row='| `critical_paths.yaml` | Optional nonempty schema-1 short-path and clamp-dominance contract. Exact endpoints, length/pad-span ceilings, via-free layer, and downstream targets; the independent shared saved-copper checker refuses unsupported topology. Required when a project conductor declares this gate. |\n'
section='''
### keys: 03_src/rules/critical_paths.yaml

| key | reader | why |
|---|---|---|
| `schema` | `critical_path_check.py` | exact schema 1; unknown/duplicate keys refused |
| `layers` | `critical_path_check.py` | exact ordered native copper layer census |
| `stackup_mm` | `critical_path_check.py` | positive inter-layer distances, one fewer than layers |
| `short_paths` | `critical_path_check.py` | nonempty, unique exact endpoint pairs |
| `short_paths[].from` | `critical_path_check.py` | exact source pad identity |
| `short_paths[].to` | `critical_path_check.py` | exact destination pad identity |
| `short_paths[].max_length_mm` | `critical_path_check.py` | positive saved-copper length ceiling |
| `short_paths[].layer` | `critical_path_check.py` | single required routing layer; no vias |
| `short_paths[].max_pad_centre_mm` | `critical_path_check.py` | positive placement span ceiling or null when not asserted |
| `short_paths[].why` | `critical_path_check.py` | required reason carried in the graded row |
| `prefixes` | `critical_path_check.py` | explicit downstream order obligations, may be empty for ordinary short paths |
| `prefixes[].from` | `critical_path_check.py` | same source as an existing short path |
| `prefixes[].through` | `critical_path_check.py` | short-path clamp endpoint |
| `prefixes[].targets` | `critical_path_check.py` | nonempty unique downstream pad identities; every physical prefix edge must dominate each target |
| `prefixes[].why` | `critical_path_check.py` | required protection-order rationale carried in the graded row |

This graph proof requires explicit supported copper contacts. Graded-net zones,
arcs, unsplit intersections and width-only contacts are refused. A saved-board
PASS does not measure clamp function or environmental/transient survival.
'''
for rel in ['skills/pcb-design/templates/contracts/03_src/rules/contracts.md',A+'/03_src/rules/contracts.md',P+'/03_src/rules/contracts.md']:
 s=read(rel);pos=s.index('| `assembly_locator.yaml`');s=s[:pos]+row+s[pos:];put(rel,s+section)
for slug in [A,P]:
 rel=slug+'/03_src/contracts.md';s=read(rel)
 if slug==A:s=s.replace('ADR0019 one-board adapter:', 'ADR0028 adds shared configured entry-path checks: exactly 16 B.Cu via-free prefixes, 16 downstream branch obligations and 16 isolated shell lands, with same-board saved-copper dominance; ADR0019 one-board adapter:')
 else:s=s.replace('`check_realized_routes.py` |', '`check_realized_routes.py` | Thin compatibility entry point for shared `critical_path_check.py` and required `rules/critical_paths.yaml`; no local graph implementation. ')
 put(rel,s)
rel='skills/kicad-pcb/scripts/contracts.md';put(rel,read(rel)+'''\n- `critical_path_check.py BOARD --config POLICY --json REPORT` promotes the
  common saved-copper short-path and branch-dominance mechanism to source
  configuration. It grades nonempty denominators and exact layer/stack/endpoint
  identities and rejects unrepresented physical contacts, zones and arcs.
  Project conductors retain mandatory invocation; component ESD behavior remains
  outside this geometric gate. Known-bad and declared-vacuity fixtures live in
  `t1_critical_path_check.py`.
''')
# Remove an old contradictory first-article instruction instead of merely
# appending a new instruction that says the opposite.
rel=A+'/01_docs/FIRST_ARTICLE_TEST_PLAN.md';s=read(rel).replace('Confirm chassis/shield obligations are outside the PCB conductors.', 'Measure continuity of all sixteen RJ45 shell lands on CHASSIS, each jack\n      to the bonded panel, and isolation from signal GND.');put(rel,s)
rel=A+'/01_docs/decisions/0028-rj45-factory-spokes.md';put(rel,read(rel)+'''\nThe source owns sixteen 0.20 mm B.Cu jack-to-clamp prefix seeds. Shared
`critical_path_check.py` reopens saved copper and enforces 4.0 mm pad span,
4.2 mm path length, no vias, B.Cu only, and complete-prefix dominance before
any AC-coupling branch. Both conductors invoke this through the existing
analog path gate. Failure is a route/placement finding, not a waived branch.
CHASSIS has an explicit 0.60 mm outer-layer routing owner, joining all sixteen
shell lands while each connector's EMI fingers bond locally to the panel.
There is no CHASSIS-to-GND tie, no inner-plane assignment, and no protective
earth or lightning-current rating. Panel contact remains a first-article test.
''')
print('carrier routing, source gate, shared contracts and shield owner prepared')
