from pathlib import Path, PurePosixPath
import hashlib, json, tarfile, io, gzip
from datetime import datetime, timezone
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
N=Path(__file__).parent
I=Path('/tmp/carrier-connector-integration-20260911')
roots={
 'jack_selection':Path('/tmp/carrier-rj45-jack-selection-pntbys98'),
 'cable_selection':Path('/tmp/carrier-rj45-cable-selection-hkl9acsz'),
 'harting_completion':Path('/tmp/carrier-rj45-harting-at0oel5v'),
 'availability':Path('/tmp/carrier-rj45-layout-availability-masixg7v'),
}
payload={};checks=[];gaps=[]
def add(name,path):
 assert not path.is_symlink(),path
 assert name not in payload,name
 payload[name]=path.read_bytes()
for name,root in roots.items():
 for f in sorted(root.rglob('*')):
  if f.is_file(): add(f'agents/{name}/{f.relative_to(root).as_posix()}',f)
 env=next(root.rglob('envelope.json')); e=json.loads(env.read_text())
 for row in e['input_packet']:
  b=(root/row['path']).read_bytes()
  assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256'],row
 checks.append({'task':name,'input_count':len(e['input_packet']),'attempt_status':json.loads((env.parent/'attempt.json').read_text())['status']})
 if (env.parent/'outputs/evidence.tar.gz').exists():
  with tarfile.open(env.parent/'outputs/evidence.tar.gz','r:gz') as t:
   names=set()
   for m in t:
    assert not m.issym() and not m.islnk() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts,m.name
    assert m.name not in names,m.name
    names.add(m.name)
    if m.isfile():
     b=t.extractfile(m).read()
     assert len(b)==m.size
   checks[-1]['original_archive_members']=len(names)
  manifest=json.loads((env.parent/'outputs/evidence-manifest.json').read_text())
  verified=0
  for row in manifest.get('files',[]):
   if not isinstance(row,dict) or 'sha256' not in row or 'size' not in row:
    gaps.append({'task':name,'original_manifest_missing_identity':row});continue
   candidates=[env.parent/row['path'],env.parent/'scratch/evidence'/row['path'],root/row['path']]
   present=[p for p in candidates if p.is_file()]
   assert present,(name,row)
   b=present[0].read_bytes()
   assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256'],(name,row)
   verified+=1
  checks[-1]['verified_original_manifest_entries']=verified
for f in sorted(N.rglob('*')):
 if not f.is_file() or 'cad-libs' in f.parts:continue
 if f.name.startswith('source-research-') or f.name=='research-preservation.tmp':continue
 if f.name in {'rj45-jack-architecture-opened.json','open_jack_architecture_review.py'}:continue
 add('root/'+f.relative_to(N).as_posix(),f)
for f in sorted(I.glob('rj45-*')):
 if f.is_file() and not f.name.startswith('rj45-source-research-preservation'):
  add('root/runtime/'+f.name,f)
q=R/'projects/crow-mic-pod-v3/06_build/task_runs/qualify-64ad3f84df4d4e79b2cc9b0c7fcf66f8'
for f in sorted(q.rglob('*')):
 if f.is_file():add('root/native_qualification/'+f.relative_to(q).as_posix(),f)
audit={'created_at':datetime.now(timezone.utc).isoformat(),'delivery_checks':checks,'original_manifest_gaps':gaps,'scope':'Preservation of completed source proposals, root corroboration and fresh availability only; no source/PCB acceptance.','root_findings':[
 'Initial jack report had incorrect row spacing and reversed proposed audio map; manufacturer native library is the geometry reference, not that table.',
 '615008160221 top-side AUDIO+ clamp outside rear body cannot meet existing 4.2 mm path; architecture comparison separately running.',
 'Phoenix 1227591 does not cover pod -30 C; HARTING exact 09484747743150 stronger candidate, no engineering adoption yet.',
 'HARTING PDF_DS_09484747743150_EN.pdf is retained failed non-PDF download. Root pdftotext failed; use real catalog PDF and exact product HTML instead.',
 'HARTING boot approximately45mm and cable OD6.7mm nominal are not guaranteed maxima. Plug numeric current/contact resistance remains unpublished in retained evidence.',
 'Original source task manifests and telemetry are retained without correction. Root archive supplies full current member hashes, not fabricated original producer coverage.',
 'Generic STEP has one unresolved reference; native library STEP imports cleanly. Cached CAD probe and initial render failure preserved. CAD target install is in temporary scratch; libraries excluded from archive, runtime install command retained.',
 'Original root qualification command used wrong script path and failed. Correct path passed4/4 in8.352s; both logs retained.',
]}
payload['ROOT_REOPEN_AUDIT.json']=(json.dumps(audit,indent=2)+'\n').encode()
manifest={'schema':1,'files':[{'path':n,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(payload.items())]}
mb=(json.dumps(manifest,indent=2)+'\n').encode()
out=N/'research-preservation.tmp'
with out.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for n,b in sorted({**payload,'MANIFEST.json':mb}.items()):
    info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;t.addfile(info,io.BytesIO(b))
with tarfile.open(out,'r:gz') as t:
 members=t.getmembers();assert len({m.name for m in members})==len(members)==len(payload)+1
 assert all(m.isfile() for m in members)
 actual=json.loads(t.extractfile('MANIFEST.json').read());assert actual==manifest
 for row in actual['files']:
  b=t.extractfile(row['path']).read();assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256']
sha=hashlib.sha256(out.read_bytes()).hexdigest()
dest=R/'projects/crow-audio-carrier-v1/01_docs/journal'/f'{sha}.tar.gz'
assert not dest.exists();out.rename(dest)
summary={'path':str(dest),'sha256':sha,'size':dest.stat().st_size,'payload_members':len(payload),'delivery_checks':checks,'original_manifest_gap_count':len(gaps)}
(N/'source-research-preservation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
