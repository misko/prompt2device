from pathlib import Path
import shutil
N=Path(__file__).parent;C=N/'weid_source_candidate';p=C/'tests/t1_critical_path_check.py';s=p.read_text()
insert=s.index("if __name__=='__main__'")
new='''def native_pad_fixture(offset=.4, bypass=True):
    """Independent reviewer geometry reproduced through pcbnew save/reopen.

    The 1 mm connector land touches the longer route between its endpoints.
    offset=.4 crosses its interior; .55 touches only via track half-width.
    Original shared checker falsely passed both with native two-track contact.
    """
    import pcbnew
    d=tmpdir();b=pcbnew.BOARD();b.SetCopperLayerCount(2)
    net=pcbnew.NETINFO_ITEM(b,'AUDIO');b.Add(net)
    for ref,num,x,size in [('J1','5',10,1.),('U1','3',12,.4),('C1','1',16,.4)]:
        f=pcbnew.FOOTPRINT(b);f.SetReference(ref);f.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(x),pcbnew.FromMM(10)));b.Add(f)
        p=pcbnew.PAD(f);p.SetNumber(num);p.SetAttribute(pcbnew.PAD_ATTRIB_SMD);p.SetShape(pcbnew.PAD_SHAPE_RECT);p.SetSize(pcbnew.VECTOR2I(pcbnew.FromMM(size),pcbnew.FromMM(size)))
        ls=pcbnew.LSET();ls.AddLayer(pcbnew.B_Cu);p.SetLayerSet(ls);p.SetPosition(f.GetPosition());p.SetNet(net);f.Add(p)
    segments=[(10,10,12,10),(12,10,16,10)]
    if bypass:segments.extend([(9,10+offset,11,10+offset),(11,10+offset,11,12),(11,12,16,12),(16,12,16,10)])
    for a,y,c,z in segments:
        t=pcbnew.PCB_TRACK(b);t.SetStart(pcbnew.VECTOR2I(pcbnew.FromMM(a),pcbnew.FromMM(y)));t.SetEnd(pcbnew.VECTOR2I(pcbnew.FromMM(c),pcbnew.FromMM(z)));t.SetLayer(pcbnew.B_Cu);t.SetWidth(pcbnew.FromMM(.2));t.SetNet(net);b.Add(t)
    path=d/'board.kicad_pcb';pcbnew.SaveBoard(str(path),b)
    native=pcbnew.LoadBoard(str(path));native.BuildConnectivity()
    pad=next(p for f in native.GetFootprints() if f.GetReference()=='J1' for p in f.Pads())
    eq(len(native.GetConnectivity().GetConnectedTracks(pad)),2 if bypass else 1,'native connector track census')
    cfg=copy.deepcopy(CONFIG);cfg['layers']=['F.Cu','B.Cu'];cfg['stackup_mm']=[1.6]
    (d/'policy.yaml').write_text(yaml.safe_dump(cfg))
    return run([KPY,str(SCRIPTS/'critical_path_check.py'),str(path),'--config',str(d/'policy.yaml')])

@test('native pad-center tree retains correct acceptance')
def native_clean():
    must_pass(native_pad_fixture(bypass=False), 'native ordinary clamp tree')

@test('native pad-interior bypass cannot escape endpoint graph',kind='known_bad')
def native_pad_interior():
    # RED against the frozen source reviewed at 18:39Z: native two tracks,
    # shared false PASS. GREEN requires represented or refused contact.
    must_fail(native_pad_fixture(.4), 'native pad-interior bypass',expect='pad')

@test('native pad-width-only bypass cannot escape endpoint graph',kind='known_bad')
def native_pad_width():
    must_fail(native_pad_fixture(.55), 'native pad-width-only bypass',expect='pad')

'''
p.write_text(s[:insert]+new+s[insert:]);shutil.copyfile(p,N/'weid_validation/tests'/p.name)
shutil.copyfile(C/'skills/kicad-pcb/scripts/critical_path_check.py',N/'critical-path-before-pad-contact.py')
