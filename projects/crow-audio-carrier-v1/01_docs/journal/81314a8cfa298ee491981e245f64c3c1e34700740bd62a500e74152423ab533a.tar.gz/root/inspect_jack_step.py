from pathlib import Path
import re, json, hashlib

path = Path('/tmp/carrier-rj45-jack-selection-pntbys98/06_build/task_runs/rj45-jack-selection/scratch/wurth_615008160221.step')
raw = path.read_bytes()
text = raw.decode('ascii')
entities = {int(i): re.sub(r'\s+', ' ', row) for i, row in re.findall(r'#(\d+)\s*=\s*(.*?);', text, re.S)}

def refnums(row):
    return [int(n) for n in re.findall(r'#(\d+)', row)]

rows = []
for i, row in entities.items():
    if not row.startswith('CYLINDRICAL_SURFACE('):
        continue
    radius = float(row.rsplit(',', 1)[1].rstrip(')'))
    if not (abs(radius - .23) < 1e-5 or 1.45 < radius < 1.65):
        continue
    axis_id = refnums(row)[0]
    axis = entities[axis_id]
    xyz = [entities[n] for n in refnums(axis)]
    rows.append({'entity': i, 'radius': radius, 'axis_entity': axis_id, 'placement': axis, 'xyz': xyz})
out = {'source_sha256': hashlib.sha256(raw).hexdigest(),
       'method': 'STEP analytic cylinder axes only; not a BREP envelope or complete-solid verification',
       'units': [row for row in entities.values() if 'SI_UNIT' in row],
       'cylinders': rows}
Path('/tmp/carrier-rj45-20260912/jack-step-cylinder-axes.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out, indent=2))
