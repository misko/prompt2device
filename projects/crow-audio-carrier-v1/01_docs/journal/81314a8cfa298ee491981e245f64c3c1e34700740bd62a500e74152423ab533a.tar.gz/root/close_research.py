from pathlib import Path
import json, sys

R = Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
D = Path(__file__).parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(R / 'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_runtime import close_agent_attempt

# Invoke only after the coordinator observes actual host FINAL/completed state.
name = sys.argv[1]
meta = json.loads((D / (name + '-opened.json')).read_text())
env = TaskEnvelope.from_json(Path(meta['envelope']).read_text())
event = {'host': 'collaboration', 'agent_id': meta['agent_id'],
         'state': 'completed', 'envelope_sha256': meta['envelope_sha256'],
         'cleanup': 'confirmed',
         'detail': 'Root observed actual host FINAL. Source selection delivery closure does not grant engineering adoption.'}
(D / (name + '-host-final.json')).write_text(json.dumps(event, indent=2) + '\n')
result = close_agent_attempt(env, cwd=Path(meta['project']), event=event)
print(name, result.status, result.unresolved)
