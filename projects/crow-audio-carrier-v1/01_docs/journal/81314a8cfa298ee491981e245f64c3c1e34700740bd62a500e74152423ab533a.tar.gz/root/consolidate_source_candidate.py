from pathlib import Path
import copy, hashlib, json, shutil, yaml
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
N=Path(__file__).parent
C=N/'integrated_source_candidate'
A=Path('/tmp/carrier-rj45-pod-source-xokt7662/06_build/task_runs/rj45-pod-source/scratch/source_candidate')
support={'tests/harness.py','skills/kicad-pcb/scripts/kicad_sch_parity.py','projects/crow-audio-carrier-v1/03_src/tests/fixtures/kicad10_native_excerpt.net'}
for source in [N/'component_source_candidate',N/'protocol_source_candidate',N/'carrier_source_candidate',A]:
 for p in sorted(source.rglob('*')):
  if not p.is_file(): continue
  rel=p.relative_to(source)
  if str(rel) in support: continue
  dst=C/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
def read(slug, rel):
 p=C/'projects'/slug/rel
 return yaml.safe_load((p if p.exists() else R/'projects'/slug/rel).read_text())
def put(slug,rel,data):
 p=C/'projects'/slug/rel;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(yaml.safe_dump(data,sort_keys=False) if not isinstance(data,str) else data)
def evidence(grade,ids,why): return {'grade':grade,'source_ids':ids,'rationale':why}
# Retain the former complete cell structure and legitimate physical deferrals.
# Do not adopt the pod author's invalid deferral class or unmeasured PASS facts.
carrier='crow-audio-carrier-v1';pod='crow-mic-pod-v3'
base=read(carrier,'03_src/rules/connector_assemblies.yaml')
a=copy.deepcopy(base['assemblies'][0]);a['id']='factory-rj45-spoke-bank'
new_sources=[
 {'id':'shared-spoke-contract','kind':'interface-contract','path':'03_src/rules/spoke_interface.yaml'},
 {'id':'realized-floorplan','kind':'placement-contract','path':'03_src/floorplan.yaml'},
 {'id':'spoke-header-dossier','kind':'interface-contract','path':'02_parts/615008160221/part.yaml'},
 {'id':'spoke-header-drawing','kind':'manufacturer-drawing-record','path':'02_parts/615008160221/primary-source-record.md'},
 {'id':'spoke-header-model','kind':'manufacturer-3d-model','path':'03_src/lib/3dmodels/wurth/J_Wurth_WR-MJ_615008160221.step'},
 {'id':'spoke-cable-record','kind':'manufacturer-drawing-record','path':'02_parts/09484747743150/primary-source-record.md'}]
a['receptacle'].update(manufacturer='Wurth Elektronik',mpn='615008160221',mounting_method='right_angle_through_hole_shielded_nonmagnetic_8P8C',model_source_id='spoke-header-model',body_envelope_mm=None,
 evidence=evidence('exact',['spoke-header-dossier','spoke-header-drawing','spoke-header-model'],'The exact manufacturer native STEP supplies nominal receptacle geometry, including free EMI fingers. This is source identity and geometry, not installed tolerances, soldering or mated fit.'))
a['mate'].update(manufacturer='HARTING',mpn='09484747743150',part_kind='factory_15m_shielded_Cat6A_DualBoot_RJ45_patch_cord',body_envelope_mm=None,
 evidence=evidence('unknown',['spoke-cable-record'],'Exact selected cord identity is published, but the approximately 45 mm plug/boot drawing is not a maximum envelope. A manufacturer maximum drawing or dimensioned measurement record is required; source generation remains blocked.'))
a['grip'].update(kind='integral_latch_boot',across_flats_mm=None,axial_length_mm=None,
 evidence=evidence('unknown',['spoke-cable-record'],'The nominal 13.3 mm width and approximately 45 mm length do not establish a containing grip envelope. No source-phase deferral is permitted for this fact.'))
a['fastening']['evidence']=evidence('exact',['spoke-cable-record'],'The selected factory plug uses an integral RJ45 latch, not a threaded coupling. Physical mating and release remain unknown operations.')
a['tool']['evidence']=evidence('exact',['spoke-cable-record'],'Final RJ45 mating is by hand. The factory patch cord requires no field termination or crimp tool.')
a['torque']['evidence']=evidence('exact',['spoke-cable-record'],'An integral latch has no threaded joint or final torque operation.')
a['cable'].update(kind='factory_shielded_Cat6A_straight_through_patch_cord',manufacturer='HARTING',mpn='09484747743150',outer_diameter_mm=None,straight_run_mm=None,minimum_bend_radius_mm=None,
 evidence=evidence('unknown',['shared-spoke-contract','spoke-cable-record'],'The exact cord is selected. Nominal OD is 6.7 mm; the 10D repeated-bend rule gives 67 mm at nominal OD, not a verified installed bound. Measure OD extrema and qualify straight run, bend, strain relief and dry enclosure entry.'))
a['tolerances']=[
 {'id':'wurth-body-axial-drawing','applies_to':'drawing-controlled receptacle axial body dimension','effect':'exposure_setback','minus_mm':.15,'plus_mm':.15,'evidence':evidence('exact',['spoke-header-drawing'],'The manufacturer drawing specifies 13.45 +/- 0.15 mm axial body depth. This row is only that dimension, not the full contact-to-mouth or installed tolerance stack.')},
 copy.deepcopy(a['tolerances'][1])]
# The old interface, reaction, operation and installed tolerance facts stay
# unknown. Replacing a connector does not qualify an untested service step.
base['assemblies'][0]=a
retired={'shared-spoke-contract','realized-floorplan','spoke-header-dossier','spoke-header-drawing','spoke-mate-drawing','contact-tool-record','spoke-cable-record','cat-power-join','cat-power-pigtail'}
base['evidence_sources']=new_sources+[s for s in base['evidence_sources'] if s['id'] not in retired]
put(carrier,'03_src/rules/connector_assemblies.yaml',base)
phase=read(carrier,'03_src/rules/connector_assembly_phases.yaml')
for d in phase['source_deferrals']:
 if d['assembly_id']=='molex-micro-fit-spoke-bank':
  d['assembly_id']=a['id']
  if d['target_kind']=='cable':
   d['plan_source_ids']=['shared-spoke-contract','spoke-cable-record']
   d['rationale']='The exact factory cord is selected; qualify its installed route, bend and restraint. Unknown mate/grip maxima remain non-deferrable source blockers.'
put(carrier,'03_src/rules/connector_assembly_phases.yaml',phase)
pa=copy.deepcopy(a);pa['id']='factory-rj45-spoke';pa['instances']=[{'ref':'J1','mating_axis_board':[0.,-1.,0.],'simultaneous_group_ids':['spoke-cable-installed']}]
for op in pa['operations']:
 for k in ['start_state','end_state']:op[k]=op[k].replace('all_spokes','spoke')
pb={'schema':1,'contract_id':'crow-mic-pod-v3-j1-service','evidence_sources':copy.deepcopy(new_sources),'assemblies':[pa],'simultaneous_groups':[{'id':'spoke-cable-installed','members':['J1'],'required_state':'all_connected','serviceable_member_refs':['J1']}]}
put(pod,'03_src/rules/connector_assemblies.yaml',pb)
pp={'schema':1,'phase_policy_id':'crow-mic-pod-v3-factory-rj45-cord-qualification','source_deferrals':[]}
for d in phase['source_deferrals']:
 if d['assembly_id']==a['id']:
  d=copy.deepcopy(d);d['assembly_id']=pa['id'];d['rationale']=d['rationale'].replace('All eight selected harnesses','The selected factory cord').replace('all neighboring cables','populated enclosure neighbors').replace('carrier','pod');pp['source_deferrals'].append(d)
put(pod,'03_src/rules/connector_assembly_phases.yaml',pp)
# A coupon cannot be prepared while the source phase is incomplete. Preserve
# its target census and replace old field-crimp measurements by factory-cord
# measurements; no invented minimum pull force is substituted.
q=read(carrier,'03_src/connector_qualification_coupon.yaml')
q['qualification']['minimum_samples'][a['id']]=q['qualification']['minimum_samples'].pop('molex-micro-fit-spoke-bank')
for row in q['qualification']['targets']:
 if row['assembly_id']=='molex-micro-fit-spoke-bank':
  row['assembly_id']=a['id']
  if row['target_id']=='latch-pull-check':
   row['required_measurements']=[m for m in row['required_measurements'] if m['name'] not in {'strip-length','conductor-crimp-height','pull-force'}]
   row['required_measurements'] += [{'name':'exercised-cycles','unit':'count','minimum':3,'maximum':None},{'name':'latch-damage-count','unit':'count','minimum':0,'maximum':0},{'name':'finished-hot-loop-resistance','unit':'ohm','minimum':0.,'maximum':2.2}]
# Existing cable target was absent even in the old config; add the current
# required target explicitly. Qualification remains blocked before preparation.
q['qualification']['targets'].append({'assembly_id':a['id'],'target_kind':'cable','target_id':'cable','required_measurements':[{'name':'installed-outer-diameter','unit':'mm','minimum':0.,'maximum':None},{'name':'installed-straight-run','unit':'mm','minimum':0.,'maximum':None},{'name':'realized-minimum-bend-radius','unit':'mm','minimum':0.,'maximum':None},{'name':'minimum-route-clearance','unit':'mm','minimum':.5,'maximum':None}],'required_evidence_kinds':['photo','measurement_sheet']})
put(carrier,'03_src/connector_qualification_coupon.yaml',q)
# Clear drafting typography while preserving numerical and evidence claims.
for slug in [carrier,pod]:
 put(slug,'02_parts/615008160221/primary-source-record.md','''# Würth 615008160221 source record

The manufacturer drawing is revision 001.003, dated 2025-07-09 and retrieved
2026-09-12. Its local PDF SHA-256 is
`6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048`.
Source: https://www.we-online.com/components/products/datasheet/615008160221.pdf

The body is nominally 15 × 13.45 × 14.7 mm above the PCB, with ±0.15 mm
on those dimensions. The manufacturer KiCad WR-MJ library, revision 26c,
supplies the exact native footprint and STEP; provenance is recorded beside
the model. Include the free EMI fingers when evaluating the full geometry.
The STEP is nominal CAD, not a qualified manufacturing tolerance envelope.

There are eight signal drills of 0.8 mm, two unnumbered 3.18 mm locating
holes and two shield slots of 1 × 2 mm. Same-row pitch is 2.04 mm, stagger
is 1.02 mm and row spacing is 4 mm. Manufacturer shield pads S1/S2 are
renamed 9/10 without changing geometry. The circuit assignment belongs to
the synchronized spoke contract and TSX source.

Published 1.5 A and 20 mΩ maximum contact resistance apply to the jack,
not the HARTING cord. Manual soldering, bottom clamp assembly, system ESD,
wet entry, populated mating and installed tolerances require qualification.
''')
# This is a held draft, not a reviewed source admission or a generated board.
put(carrier,'01_docs/decisions/0028-rj45-factory-spokes.md','''# ADR-0028 — Factory RJ45 analog and power spokes

Status: proposed implementation; user direction and source architecture selected.
Date: 2026-09-12. Authority: carrier D8, pod D6 and parent D3.

Use Würth 615008160221 nonmagnetic, shielded 8P8C jacks and HARTING
09484747743150 factory 15 m Cat6A PUR patch cords. Contacts 1/3/7 carry
+12 V, 2/6/8 carry return, 5 carries AUDIO+ and 4 carries AUDIO−. Shield
pads 9/10 connect to CHASSIS on the carrier and isolated POD_SHIELD on the
pod. Label the ports “POD AUDIO +12V / NOT ETHERNET OR POE”. Mate with power off.

The compact jack requires the entry clamps on the bottom, between its
4 mm contact rows. Independent source architecture review supports this
arrangement. Native footprint measurement gives 1.935073 mm pad-centre
spans for the pod candidate. The review's earlier 1.514 mm estimate is not
a native measurement. Full carrier transforms, copper, bottom assembly,
THT tails, paste, service access and protection order require fresh checks.

At 15 m, the published 290 Ω/km pair-loop DCR, three parallel power pairs,
1.25 hot multiplier and an unmeasured 0.300 Ω contact allocation give
2.1125 Ω and 10.58875 V at the pod for 0.10 A from 10.8 V. The finished
cord's resistance and current capability still require qualification.

Source generation is blocked: approximately 45 mm boot length and nominal
6.7 mm cable OD do not establish maximum mate and grip envelopes. Keep these
facts unknown. Obtain a controlled maximum drawing or dimensioned measurement
record before source admission; do not invent a conservative maximum or a
new deferral category. Installed service and tolerance evidence remain
separate physical gates.

Retire the spoke's Micro-Fit crimps, joins and pigtails from the new assembly.
J9 power and J10/J11 module interfaces retain their separate contracts.
Prior sealed releases and every failed review remain historical evidence.
LAYOUT-001 remains closed with three spent attempts; this change grants no
additional diagnostic allowance. The generated carrier remains the old,
unrouted Micro-Fit subject until a normally admitted regeneration succeeds.
''')
# Source census derives from eight four-contact headers replaced by ten-pad
# jacks: 937 + 8*(10-4) = 985 memberships, one additional CHASSIS net.
for rel in ['03_src/check_protection_architecture.py','03_src/tests/test_route_source_contract.py','03_src/tests/test_startup_source.py','03_src/tests/test_adc_bypass_placement.py']:
 s=(R/'projects'/carrier/rel).read_text().replace('937','985')
 if rel.endswith('test_startup_source.py'):s=s.replace('!=220','!=221')
 put(carrier,rel,s)
manifest=[]
for p in sorted(C.rglob('*')):
 if p.is_file():
  b=p.read_bytes();manifest.append({'path':p.relative_to(C).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'size':len(b)})
(N/'integrated-source-manifest.json').write_text(json.dumps({'status':'DRAFT_SOURCE_INCOMPLETE','files':manifest},indent=2)+'\n')
print('Held integrated source draft:',len(manifest),'files')
