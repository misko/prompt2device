from pathlib import Path
import hashlib,shutil,json,re,yaml
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;C=N/'component_source_candidate'
J=Path('/tmp/carrier-rj45-jack-selection-pntbys98/06_build/task_runs/rj45-jack-selection/scratch')
H=Path('/tmp/carrier-rj45-harting-at0oel5v/06_build/task_runs/rj45-harting-completion/scratch/evidence/primary')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(rel,text):
 p=C/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
def cp(rel,p):
 t=C/rel;t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,t)
fp=N/'manufacturer-kicad/J_Wurth_WR-MJ_615008160221.kicad_mod';model=N/'manufacturer-kicad/J_Wurth_WR-MJ_615008160221.step'
assert fp.is_file() and model.is_file()
base=fp.read_text().replace('J_Wurth_WR-MJ_615008160221','Wurth_615008160221_RJ45').replace('(pad "S1"','(pad "9"').replace('(pad "S2"','(pad "10"')
base=re.sub(r'\$\{WE_3DMODEL_DIR\}/Connector_THT_Wurth.3dshapes/Wurth_615008160221_RJ45.step','${KIPRJMOD}/../03_src/lib/3dmodels/wurth/J_Wurth_WR-MJ_615008160221.step',base)
assert 'WE_3DMODEL_DIR' not in base
helper='''// Wurth native land pattern, in tscircuit +Y-up coordinates.
// Contacts 1..8, shell tabs 9/10; blank NPTH guides are mechanical only.
const Rj45Shielded = () => (
  <footprint>
    <platedhole portHints={["1"]} pcbX="0mm" pcbY="0mm"
      shape="circular_hole_with_rect_pad" holeDiameter="0.8mm"
      rectPadWidth="1.3mm" rectPadHeight="1.3mm" />
    {[[2, 1.02, -4], [3, 2.04, 0], [4, 3.06, -4], [5, 4.08, 0],
      [6, 5.10, -4], [7, 6.12, 0], [8, 7.14, -4]].map(([pin, x, y]) => (
      <platedhole key={pin} portHints={[`${pin}`]} pcbX={`${x}mm`} pcbY={`${y}mm`}
        shape="circle" outerDiameter="1.3mm" holeDiameter="0.8mm" />
    ))}
    {[[9, 10.97], [10, -3.83]].map(([pin, x]) => (
      <platedhole key={pin} portHints={[`${pin}`]} pcbX={`${x}mm`} pcbY="2.35mm"
        shape="oval" outerWidth="1.5mm" outerHeight="3mm" holeWidth="1mm" holeHeight="2mm" />
    ))}
    <hole pcbX="-3.28mm" pcbY="-0.7mm" diameter="3.18mm" />
    <hole pcbX="10.42mm" pcbY="-0.7mm" diameter="3.18mm" />
  </footprint>
)
'''
for slug,lib in [('crow-audio-carrier-v1','crow_audio_carrier'),('crow-mic-pod-v3','crow_mic_pod_v3')]:
 root='projects/'+slug
 put(root+'/03_src/lib/'+lib+'.pretty/Wurth_615008160221_RJ45.kicad_mod',base)
 cp(root+'/03_src/lib/3dmodels/wurth/J_Wurth_WR-MJ_615008160221.step',model)
 put(root+'/03_src/lib/3dmodels/wurth/provenance.md',f'''# Wurth615008160221 manufacturer native model\n\nSource: https://www.we-online.com/components/products/download/KiCad_WR-MJ%20%28rev26c%29.zip retrieved2026-09-12. WholezipSHA256 {sha(N/'KiCad_WR-MJ_rev26c.zip')}. Original exactnativefootprintSHA256 {sha(fp)}. Original modelSHA256 {sha(model)}. Modelcopiedunchanged; no translation/rotation/scale applied. Footprintpreservesall geometry and remaps manufacturer's S1/S2 labels to electrical pads9/10; modelpathandlibrarynameadaptedonly. BlankNPTHremainunnumbered.\n\nNative modelmathYisoppositetoKiCadPCB+Y-down. Mouthmodel+Y6.360054=>footprint-Y6.36. Originpad1. Barebody15x13.45x14.7mm; freeEMIfingers enlargeactual11-solid modelbox tox[-5.058081,12.218081],y[-7.09,6.360054],z[-3.254712,15.838181]. RootOCPmeasurement corroboratesmodelregistration, notmanufacturer tolerancelimits or physicalfit. Manufacturerdrawing001.003 governstolerances.\n\nThe separatelydownloadedgenericSTEP reportsoneunresolvedreference; it isretainedforensicandnotusedhere. Manufacturer KiCadmodel importswithoutthaterror. Initialsource-researchpin/tableerrors areexplicitlyrejected; see source-researcharchive168cb286ee392f49e1ec95ab9e66077b0069bb63ca653665095a3d7262204160. Assembly/latch/panelbondandtemperature testsremainowed.\n''')
 put(root+'/03_src/lib/3dmodels/wurth/SHA256SUMS',sha(model)+'  J_Wurth_WR-MJ_615008160221.step\n')
 ds=J/'wurth_615008160221.pdf'
 data={'mpn':'615008160221','manufacturer':'Wurth Elektronik','type':'shielded_nonmagnetic_rj45_receptacle','value':'615008160221','status':'active','datasheet':{'doc_id':'615008160221','revision':'001.003','url':'https://www.we-online.com/components/products/datasheet/615008160221.pdf','local':'Wurth_615008160221_rev001003.pdf','sha256':sha(ds),'fetched':'2026-09-12'},'package':'WR-MJ horizontal shielded EMI Tab Up Cat6, THT8P8C plus2shieldtabs','footprint':lib+':Wurth_615008160221_RJ45','mates':'receptacle','escape':{'style':'connector','pitch':2.04,'tier_required':'jlc_2layer_default','checked':'escape_check.py --style connector --pitch2.04, 2026-09-12; eight signal contacts two staggered rows'},'pins':{**{i:'CONTACT_'+str(i) for i in range(1,9)},9:'SHIELD_S1',10:'SHIELD_S2'},'limits':{'rated_current_a':1.5,'working_voltage_v_ac':150,'contact_resistance_max_mohm':20,'operating_temperature_min_c':-40,'operating_temperature_max_c':85,'mating_cycles':750,'pcb_nominal_thickness_mm':1.6},'gotchas':['Plain contacts, no magnetics or LEDs. Used for analog audio and DC, not Ethernet/PoE.','Audio positive uses contact5, negative4; power1/3/7, return2/6/8.','Two shield tabs are electrically represented as9/10. Carrier CHASSIS and pod POD_SHIELD are separate from signal GND.','Manufacturer generic solder caution supplies no qualified manual iron process; manual assembly qualification remains owed.','Compact body covers signal pins. Pod U3 underside proposal requires independent architecture and exact bottom-side clearance/route/assembly review.','Free EMI fingers exceed nominal body width and height. Do not use body dimensions as assembled maximum.'], 'verified':'Primary drawing pages1/2 inspected; manufacturer native KiCad footprint/model independently corroborated by root. Source candidate pending review and generated pin/orientation/assembly acceptance.','layout':{'source':'Manufacturer615008160221rev001.003 and native KiCad_WR-MJrev26c','reviewed':'2026-09-12','notes':['Preserve connector-first ESD and isolated chassis shell; qualify fully populated plug access and panelbond.']},'layout_refs':[{'tier':1,'reached':True,'artifact':'615008160221 drawing and native KiCad footprint/model','why':'Exact manufacturer hole/pin/body/mating authority.'},{'tier':2,'reached':False,'artifact':'Manufacturer editable application board','why':'Native footprint/model are available; no complete analog spoke board reference was identified. Exact placement/routing remain project-owned.'}],'sourcing':{'lcsc':None,'alternates':[],'note':'Manual fitted exact part; live allocation remains owed.'}}
 put(root+'/02_parts/615008160221/part.yaml',yaml.safe_dump(data,sort_keys=False))
 cp(root+'/02_parts/615008160221/Wurth_615008160221_rev001003.pdf',ds)
 put(root+'/02_parts/615008160221/primary-source-record.md',f'''# Exact Wurth615008160221\n\nManufacturer drawingrev001.003(2025-07-09), retrieved2026-09-12, localSHA256{sha(ds)}. Primary nativeKiCad library rev26c/modelprovenance is in03_src/lib/3dmodels/wurth/provenance.md. Contact ratings apply tothisjack, nottheHARTINGcord. Circuit assignment appearsinthe sharedspokecontractandTSX; physicalpins1..8 aredirectcontacts. S1/S2 manufacturerpadsbecome9/10.\n\nDatasheetbody15x13.45x14.7mm abovePCB; eight0.8mmholes,2NPTH3.18mm,2shieldslots1x2mm; same-row2.04mm,stagger1.02mm,rows4mm. No acceptedmanufacturing or systemESD/wet-serviceclaim. Nativepin/modelregistrationandactualmatedaccess requireordinaryreviewaftergeneration.\n''')
 cd={'mpn':'09484747743150','manufacturer':'HARTING','type':'factory_preassembled_shielded_rj45_cord','status':'active_catalog','datasheet':{'doc_id':'PRD0200000100235 industrial communication catalog','revision':'primary online catalog retrieved2026-09-12; exact15mvariant onPDFpage155','url':'https://b2b.harting.com/files/livebooks/en/PRD0200000100235/downloads/livebook.pdf','local':'HARTING_PRD0200000100235_20260912.pdf','sha256':sha(H/'PRD0200000100235-livebook.pdf'),'fetched':'2026-09-12'},'package':'off-board15mDualBootRJ45male-maleCat6APURgreycord','footprint':'none_off_board','limits':{'length_m':15,'loop_dcr_max_ohm_per_km':290,'cable_od_nominal_mm':6.7,'cable_od_max_mm':None,'full_plug_length_approx_mm':45,'full_plug_length_max_mm':None,'plug_front_width_mm':13.3,'plug_front_height_mm':13.8,'temperature_min_c':-40,'temperature_max_c':80},'gotchas':['IP20plugsrequireenclosedprotectedzones. PUR/UV/oilresistance doesnotqualifywetplugzones.','Boot45mmisapproximateandOD6.7mmnominal; maximummechanicalenvelopesremainunqualified.','Numericplugcurrent/contactresistancemaximum notfound; .300ohmwholeloopcontactallocationismeasurementowed.','FactoryT568Bstraightthrough8pins+shield. No fieldcutting,crimping,splices,pigtailsorWAGOjoins.','Customanalog/DCpinoutisnotEthernet/PoE;connectonlywithpoweroff.'],'verified':'ExactmanufacturerassemblyHTML/BOMandcatalogdrawinginspected; physicalqualificationOWED.','sourcing':{'lcsc':None,'alternates':[]}}
 put(root+'/02_parts/09484747743150/part.yaml',yaml.safe_dump(cd,sort_keys=False))
 cp(root+'/02_parts/09484747743150/HARTING_PRD0200000100235_20260912.pdf',H/'PRD0200000100235-livebook.pdf')
 put(root+'/02_parts/09484747743150/primary-source-record.md',f'''# HARTING09484747743150 source facts\n\nExactassembly https://www.harting.com/pl-PL/p/RJI-DB-Cat6a-Cable-Assy-grey-PUR-15m-09484747743150 . PrimaryHTMLSHA256{sha(H/'harting-assembly.html')}. AssemblyBOMcable094560006000301 and2x0948CON47P8BK. Exact15mordercodeis09484747743150; internalplugBOMcodeisnotassertedretailMPN. RawHTML/JSON/drawingbytes retainedin carrierjournal/168cb286ee392f49e1ec95ab9e66077b0069bb63ca653665095a3d7262204160.tar.gz.\n\nPrimarycatalogPDFpage155showsstraight-throughTIA/EIA568Bbothmaleendsandshieldcontinuity; rootactuallyviewedpage2026-09-12. Eightconductors1whiteorange,2orange,3whitegreen,4blue,5whiteblue,6green,7whitebrown,8brown. Fullplug/bootapprox45mm,front13.3x13.8mm,OD6.7mmnominal. Approximate/nominalarenotmaximums.\n\nExactbulk https://www.harting.com/en-AE/p/HARTING-IE-Cat-6A-4x2xAWG26-7-PUR-grey-094560006000301 . PrimaryHTMLSHA256{sha(H/'harting-cable.html')}. Published290ohm/kmmaximumloopresistance;AWG26/7copperS/FTP,PUR,UV/oilresistance,-40..80C. Bends5Dsingle/10Drepeatedmean33.5/67mmusingnominalOD. Noindependentinstallationtemperature claim. BothplugzonesIP20,protectedfromwater/condensation qualificationowed.\n\n15mthreeparallelpowerpairs at1.25hotfactorplus.300ohmcontactallocation:290*.015/3*1.25+.300=2.1125ohm; .1A gives.21125Vdropand10.58875Vfrom10.8Vcarrier. Limits2.2ohm/10.5Vpreserved. No actualmeasuredcord, contactallocationnotpublishedplugrating. No firstarticleorderauthorization.\n\nRetained PDF_DS_09484747743150_EN.pdf retrievalwasHTML/non-PDFandisnotusedasdatasheetauthority.\n''')
 tsname='crow_audio_carrier_v1.tsx' if 'carrier' in slug else 'crow_mic_pod_v3.tsx'
 path=R/root/'03_tscircuit/src'/tsname;s=path.read_text()
 s,n=re.subn(r'const MicroFit4 = \(\) => \(.*?\n\)\n',helper,s,count=1,flags=re.S);assert n==1
 s=s.replace('manufacturerPartNumber="43650-0400"','manufacturerPartNumber="615008160221"').replace('footprint={<MicroFit4 />}','footprint={<Rj45Shielded />}')
 old='pinLabels={{ pin1: "12V_POD", pin2: "GND", pin3: "AUDIO_P", pin4: "AUDIO_N" }}'
 new='pinLabels={{ pin1: "12V_1", pin2: "GND_1", pin3: "12V_2", pin4: "AUDIO_N", pin5: "AUDIO_P", pin6: "GND_2", pin7: "12V_3", pin8: "GND_3", pin9: "SHIELD_S1", pin10: "SHIELD_S2" }}'
 assert s.count(old)==1;s=s.replace(old,new).replace('schPinArrangement={{ leftSide: [1, 2], rightSide: [3, 4] }}','schPinArrangement={{ leftSide: [1, 3, 7, 2, 6, 8], rightSide: [5, 4, 9, 10] }}')
 if 'carrier' in slug:
  old='connections={{ pin1: N(`12V_POD${n}`), pin2: N("GND"), pin3: N(`AUDIO_P${n}`), pin4: N(`AUDIO_N${n}`) }}'
  new='connections={{ pin1: N(`12V_POD${n}`), pin2: N("GND"), pin3: N(`12V_POD${n}`), pin4: N(`AUDIO_N${n}`), pin5: N(`AUDIO_P${n}`), pin6: N("GND"), pin7: N(`12V_POD${n}`), pin8: N("GND"), pin9: N("CHASSIS"), pin10: N("CHASSIS") }}'
 else:
  old='connections={{ pin1: N("12V_POD"), pin2: N("GND"), pin3: N("AUDIO_P"), pin4: N("AUDIO_N") }}'
  new='connections={{ pin1: N("12V_POD"), pin2: N("GND"), pin3: N("12V_POD"), pin4: N("AUDIO_N"), pin5: N("AUDIO_P"), pin6: N("GND"), pin7: N("12V_POD"), pin8: N("GND"), pin9: N("POD_SHIELD"), pin10: N("POD_SHIELD") }}'
 assert s.count(old)==1;s=s.replace(old,new)
 put(root+'/03_tscircuit/src/'+tsname,s)
files=[]
for p in sorted(C.rglob('*')):
 if p.is_file():files.append({'path':p.relative_to(C).as_posix(),'size':p.stat().st_size,'sha256':sha(p)})
(N/'component-source-candidate-manifest.json').write_text(json.dumps({'scope':'Prospective221candidate, notlive/adopted/generated','files':files},indent=2)+'\n')
print('Prepared',len(files),'candidate source files; native untouched')
