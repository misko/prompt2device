from pathlib import Path
p=Path('/tmp/carrier-rj45-20260912/integrate_critical_paths.py')
s=p.read_text();header=s[:s.index('# Source routing')];tail=s[s.index("row='| `critical_paths.yaml`"):]
tail=tail.replace("s=read(rel);pos=s.index('| `assembly_locator.yaml`');s=s[:pos]+row+s[pos:];put(rel,s+section)","s=read(rel)\n if '### keys: 03_src/rules/critical_paths.yaml' not in s:\n  pos=s.index('|---|---|')+len('|---|---|\\n');s=s[:pos]+row+s[pos:];put(rel,s+section)")
exec(compile(header+tail,str(p),'exec'))
