from pathlib import Path
C=Path(__file__).parent/'weid_source_candidate'
p=C/'tests/t1_critical_path_check.py'
s=p.read_text();assert 'def native_contact_case' not in s
extra=r'''
def native_contact_case(case):
    """Native controls reproduced from the independent frozen-source review.

    These cases went RED against that frozen checker. Native contacts are
    asserted before asking the independently parsed-text gate to refuse them.
    """
    import pcbnew
    V=lambda x,y:pcbnew.VECTOR2I(pcbnew.FromMM(x),pcbnew.FromMM(y))
    b=pcbnew.BOARD();b.SetCopperLayerCount(4 if case=='interior_via' else 2)
    net=pcbnew.NETINFO_ITEM(b,'AUDIO');b.Add(net)
    def pad(ref,num,x,y,size=1.,through=False,rounded=False):
        f=pcbnew.FOOTPRINT(b);f.SetReference(ref);f.SetPosition(V(x,y));b.Add(f)
        p=pcbnew.PAD(f);p.SetNumber(num);p.SetAttribute(pcbnew.PAD_ATTRIB_PTH if through else pcbnew.PAD_ATTRIB_SMD)
        p.SetShape(pcbnew.PAD_SHAPE_ROUNDRECT if rounded else pcbnew.PAD_SHAPE_RECT);p.SetSize(V(size,size))
        ls=pcbnew.LSET();ls.AddLayer(pcbnew.B_Cu);p.SetLayerSet(ls);p.SetPosition(f.GetPosition());p.SetNet(net)
        if through:p.SetDrillSize(V(.3,.3));p.SetLayerSet(pcbnew.LSET.AllCuMask())
        if rounded:p.SetRoundRectRadiusRatio(.25)
        f.Add(p)
    def track(a,y,c,z,layer=pcbnew.B_Cu,width=.2):
        t=pcbnew.PCB_TRACK(b);t.SetStart(V(a,y));t.SetEnd(V(c,z));t.SetLayer(layer);t.SetWidth(pcbnew.FromMM(width));t.SetNet(net);b.Add(t)
    def via(x,y):
        v=pcbnew.PCB_VIA(b);v.SetPosition(V(x,y));v.SetWidth(pcbnew.FromMM(.4));v.SetDrill(pcbnew.FromMM(.2));v.SetLayerPair(pcbnew.F_Cu,pcbnew.B_Cu);v.SetNet(net);b.Add(v)
    pad('J1','5',10,10,rounded=case=='roundrect')
    pad('U1','3',12,10,.4)
    pad('C1','1',10 if case=='overlap' else 16,10.8 if case=='overlap' else 10,
        1. if case in ('overlap','offcenter_pth') else .4,through=case in ('via_pad','interior_via','offcenter_pth'))
    if case=='roundrect':track(10.47,10.47,12,10,width=.02);track(12,10,16,10,width=.02)
    elif case=='overlap':
        for t in [(10,10,12,10),(12,10,13,10),(13,10,13,12),(13,12,10,12),(10,12,10,10.8)]:track(*t)
    elif case=='via_pad':
        track(10,10,12,10);track(12,10,16,10);via(10,10.6)
        track(10,10.6,16,10.6,pcbnew.F_Cu);track(16,10.6,16,10,pcbnew.F_Cu)
    else:
        track(10,10,11,10);track(11,10,12,10);track(12,10,16,10)
        track(11,10,11,12);via(11,12)
        layer=pcbnew.In1_Cu if case=='interior_via' else pcbnew.F_Cu
        track(11,12,16,12,layer);track(16,12,16,10.4 if case=='offcenter_pth' else 10,layer)
    path=tmpdir()/'native.kicad_pcb';pcbnew.SaveBoard(str(path),b)
    native=pcbnew.LoadBoard(str(path));native.BuildConnectivity();conn=native.GetConnectivity()
    pads={f.GetReference():next(iter(f.Pads())) for f in native.GetFootprints()}
    if case=='roundrect':eq(len(conn.GetConnectedTracks(pads['J1'])),0,'native rounded corner is disconnected')
    elif case=='overlap':eq(len(conn.GetConnectedPads(pads['J1'])),1,'native overlapping lands are connected')
    elif case=='via_pad':eq(len(conn.GetConnectedTracks(pads['J1'])),2,'native pad contacts track and via')
    else:
        eq(len(conn.GetConnectedTracks(pads['C1'])),2,'native plated land connects both layers')
        v=next(t for t in native.GetTracks() if isinstance(t,pcbnew.PCB_VIA))
        eq(len(conn.GetConnectedTracks(v)),2,'native via connects both branch tracks')
    cfg=copy.deepcopy(CONFIG)
    if case!='interior_via':cfg['layers']=['F.Cu','B.Cu'];cfg['stackup_mm']=[1.6]
    policy=path.with_suffix('.yaml');policy.write_text(yaml.safe_dump(cfg))
    return run([KPY,str(SCRIPTS/'critical_path_check.py'),str(path),'--config',str(policy)])

@test('native via annulus touching land cannot hide a bypass',kind='known_bad')
def native_via_pad():must_fail(native_contact_case('via_pad'),'native via-pad bypass',expect='pad-via')

@test('native overlapping lands cannot hide a bypass',kind='known_bad')
def native_overlap():must_fail(native_contact_case('overlap'),'native land overlap',expect='distinct pads')

@test('native rounded pad corner cannot invent a connection',kind='known_bad')
def native_roundrect():must_fail(native_contact_case('roundrect'),'native rounded corner',expect='rounded-corner')

@test('native through via interior layer cannot hide a bypass',kind='known_bad')
def native_interior_via():must_fail(native_contact_case('interior_via'),'native interior via layer',expect='interior via-layer')

@test('native off-center plated land cannot hide a barrel transition',kind='known_bad')
def native_offcenter_pth():must_fail(native_contact_case('offcenter_pth'),'native off-center PTH',expect='PTH layer transition')

'''
s=s.replace("if __name__=='__main__':sys.exit(main())",extra+"if __name__=='__main__':sys.exit(main())")
p.write_text(s)
