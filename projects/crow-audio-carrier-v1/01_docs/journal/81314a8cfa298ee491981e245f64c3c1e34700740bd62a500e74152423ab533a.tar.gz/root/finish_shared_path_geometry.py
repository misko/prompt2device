from pathlib import Path
import shutil
N=Path(__file__).parent;C=N/'weid_source_candidate';p=C/'skills/kicad-pcb/scripts/critical_path_check.py';s=p.read_text().replace('    from shapely.geometry import LineString, Point\n','')
s=s.replace('float(width[1]), LineString([a,b])','float(width[1]), (a,b)').replace('line.distance(other)','segment_distance(*line,*other)').replace('Point(at).distance(line)','point_segment_distance(at,*line)')
pos=s.index('def assert_graph_contacts')
s=s[:pos]+'''def point_segment_distance(p, a, b):
    dx, dy = b[0]-a[0], b[1]-a[1]
    norm = dx*dx+dy*dy
    if norm == 0:
        return math.dist(p,a)
    t = max(0., min(1., ((p[0]-a[0])*dx+(p[1]-a[1])*dy)/norm))
    return math.dist(p,(a[0]+t*dx,a[1]+t*dy))


def segment_distance(a,b,c,d):
    def cross(p,q,r):
        return (q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0])
    ab_c,ab_d,cd_a,cd_b = cross(a,b,c),cross(a,b,d),cross(c,d,a),cross(c,d,b)
    if ab_c*ab_d < 0 and cd_a*cd_b < 0:
        return 0.
    return min(point_segment_distance(a,c,d),point_segment_distance(b,c,d),
               point_segment_distance(c,a,b),point_segment_distance(d,a,b))


'''+s[pos:]
s=s.replace('        failures = []\n', '''        failures = []
        if (item.start != start or item.end != end or not item.net
                or not math.isfinite(item.length_mm) or item.length_mm < 0
                or not math.isfinite(item.pad_centre_mm) or item.pad_centre_mm < 0
                or not item.physical_edges):
            raise AuditError(f"{start}->{end}: invalid or empty measured path")
''',1)
p.write_text(s);shutil.copyfile(p,N/'weid_validation/skills/kicad-pcb/scripts'/p.name)
