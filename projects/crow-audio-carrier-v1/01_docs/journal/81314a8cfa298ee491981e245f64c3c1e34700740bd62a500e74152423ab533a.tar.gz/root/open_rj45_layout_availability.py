from pathlib import Path
from datetime import datetime,timezone,timedelta
import json,sys,hashlib,tempfile
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');C=Path(__file__).parent;D=Path(tempfile.mkdtemp(prefix='carrier-rj45-layout-availability-'));old=Path('/tmp/carrier-locator-implementation-availability-6c_4vwal');name='rj45-layout-availability';E=D/f'06_build/task_runs/{name}/envelope.json'
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_runtime import open_agent_attempt
from pipeline_identity import subject_identity,TypedIdentityInput
(D/'challenge.txt').write_text('Fresh reviewer launch/delivery probe for the RJ45 connector and pod clamp architecture comparison; no design acceptance.\n')
(D/'preflight.py').write_bytes((old/'preflight.py').read_bytes())
(D/'producer.py').write_text((old/'producer.py').read_text().replace(str(old),str(D)).replace('locator-implementation-availability',name))
items=[]
for f in sorted(D.iterdir()):
 b=f.read_bytes();items.append({'name':f.stem,'path':f.name,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
s=subject_identity('review_availability',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())]);now=datetime.now(timezone.utc)
e=TaskEnvelope(schema=2,task_id=name,stage_id='KICAD-SCHEMATIC',run_id=name,subject=s,executor='agent',execution_class='review_wait',recommended_agent_role='judgment',agent_role='judgment',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=(now+timedelta(minutes=4)).isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'checks':['challenge-read'],'outputs':['report.md']})
o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(E),agent_id='/root/carrier_rj45_layout_availability',name=name,work_cutoff=(now+timedelta(minutes=2)).isoformat());(C/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2))
