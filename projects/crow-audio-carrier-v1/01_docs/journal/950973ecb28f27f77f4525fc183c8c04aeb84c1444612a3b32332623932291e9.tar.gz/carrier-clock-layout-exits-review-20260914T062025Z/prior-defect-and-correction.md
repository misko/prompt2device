# Preserved review finding and correction

The first final-ready image allowed ADC_CLOCK on F.Cu/B.Cu in route.yaml while authoritative stackup.yaml still allowed only F.Cu and named only In1.Cu. Independent review classified that as defective and reported it to the coordinator. The source was corrected to allow F.Cu/B.Cu with explicit F.Cu->In1.Cu and B.Cu->In2.Cu GND references.

A second independent check then found that nets.yaml's executable reference_plane_checks still projected only F.Cu/In1.Cu, even though the diagnostic route used B.Cu for six clock nets. That non-vacuous coverage gap was reported as defective. The corrected final subject adds ADC_DIGITAL_RETURN_BACK for B.Cu/In2.Cu across the same exact 13 ADC_CLOCK nets and adds a hostile regression that fails if the back-side check is deleted.

No earlier defective image is the subject of the final verdict.
