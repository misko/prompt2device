review_stage: pre-route
review_kind: layout
reviewer: Codex /root/pod_r3_layout_review carrier-clock-exits final3
context: FRESH
completed_at: 2026-09-14T06:20:25Z
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
floorplan_sha256: a9aff00c6609f9c0c1050e882f270a6c67bdac9fbf790194b5773efb63790876
route_yaml_sha256: 5910176bba8ae93d1b6d08352db4ef54b40d004ed106e08e55a26353dd268b55
nets_rules_sha256: 160640a030557c29871e2238b64a788cb8bc0b8aaa7725946aa284c6a733ef17
stackup_sha256: dffefa0c8433af3cc646d160330a470478943274ba8d9eb310fb290162d609b5
board_sha256: 6f1232d03971c9b897b5dc2cb929e3e104e052de6f18fdd4b29211dadf0e06e8
prepared_board_sha256: 108bf458850b3db37cf1b5ff18cf51ef875a33027ee627c8057615d6ea41bec0
design_rules_sha256: 734eaa9274e681d83c28028f0dd96d222658d32d8f500ab82552af057fc6ca58
krt_commit: de562199260dc82abb7f1f53edb6921348a19388

# Fresh carrier clock-exit and two-layer pre-route layout review

## Verdict

SOUND for the exact final3 source, placement and prepared r0 bound above. The ADC_BCLK dogleg clears the adjacent GND escape at ordinary 0.36 mm width and 0.25 mm clearance. MCH_FSYNC and MCLK_BUF now have independent east-going ordinary-width terminals beyond the U_CLK row and C_CLK. The ADC_CLOCK wave, authoritative stack contract, design prose and executable projection checks coherently permit F.Cu and B.Cu with continuous adjacent GND references In1.Cu and In2.Cu. A fresh routing diagnostic connects 11/11 single nets and 12/12 multipoint pads at nominal 0.25 mm, while both reference-plane projections pass.

This admits placement and route source. It does not accept the diagnostic route as completed copper, solve impedance, prove filled-plane continuity, close SI, mint a release, or authorize ordering. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.

## Bound source and corrected review history

All six source/board hashes were recomputed from the stopped-writer worktree and match the final-ready dispatch exactly. The project semantic design-rule digest is `734eaa9274e681d83c28028f0dd96d222658d32d8f500ab82552af057fc6ca58`.

This review first rejected two earlier mutable images: one allowed B.Cu in route.yaml while stackup authority remained F.Cu-only; the next had no executable B.Cu/In2 projection. Both defects were corrected before this verdict. A later ADC_FSYNC corner adjustment initially violated its source containment test; the final floor area and regenerated board now contain it and both source suites pass. `prior-defect-and-correction.md` preserves that history. No rejected image is restamped here.

## Native exit geometry

Fresh pcbnew effective-shape measurements on current r0 give:

- ADC_BCLK's scoped 0.18 mm pad-row launch is 0.900 mm long and retains 0.210 mm foreign-pad clearance, satisfying its exact 0.20 mm scoped rule.
- Its ordinary 0.36 mm lead-in `(99.85,70.6)->(100.1,70.6)` has 0.253239 mm minimum foreign clearance.
- Its north leg `(100.1,70.6)->(100.1,71.25)` has 0.255000 mm minimum clearance.
- Its east leg `(100.1,71.25)->(101.2,71.25)` has 0.270000 mm clearance to the adjacent GND via at `(100.85,70.55)`.

All three widened items meet the ordinary 0.36/0.25 class rule. The narrow item alone is contained by `ADC_BCLK_LAUNCH`; the widened continuation does not depend on the scoped relaxation.

MCH_FSYNC's 0.36 mm knee retains 0.290000 mm clearance and its independent east extension runs 2.200 mm from `(149.8,59.2)` to `(152.0,59.2)`, also with 0.290000 mm minimum clearance to MCLK_BUF. MCLK_BUF's extension runs 1.550 mm from `(149.95,58.55)` to `(151.5,58.55)` and retains 0.260000 mm minimum clearance to C_CLK.1. The two terminals remain separated by 0.290 mm copper-to-copper and no longer terminate inside the same dense pad/cap row.

The pre-existing 0.18 mm MCH_FSYNC and MCLK_BUF launch capsules remain inside `CLK_EAST_DIGITAL` with minimum foreign clearances of 0.235000 and 0.245137 mm. The new ordinary-width extensions do not enlarge or consume the 0.18/0.20 exception. The adjusted ADC_FSYNC corner and its full 0.36 mm capsule now pass the current source containment guard.

No exit collides with a pad, via, keepout or edge. A fresh parity-enabled, refill native r0 DRC reports zero clearance, width, collision, keepout, edge, drill, short or other hard physical findings. All 340 footprints remain on F.Cu; no fitted SMD is on B.Cu.

## Layer and via authority

The four-layer contract is coherent:

- F.Cu is a signal layer referenced to continuous GND In1.Cu;
- B.Cu is a signal layer referenced to continuous GND In2.Cu;
- ADC_CLOCK is allowed on exactly F.Cu and B.Cu and requires those references;
- the clock wave names the same two signal layers and restores the ordinary 0.25 mm clearance;
- only `ordinary_through` F.Cu-to-B.Cu vias may change layers.

The route's 0.50/0.20 mm ordinary via has 0.15 mm radial annulus, meeting the 0.45 mm minimum size, 0.20 mm minimum drill and 0.13 mm minimum annulus. Its nominal 1.6/0.2 = 8:1 board-thickness/drill ratio remains within the declared advanced prototype tier. `no_stub_layer_swap` prevents gratuitous one-ended layer changes.

Both outer signal layers have an adjacent same-net GND plane, so an ordinary through signal via changes between two declared continuous GND references rather than crossing an unrelated split or power plane. The corrected rules now execute both projections over the exact same 13 clock nets: `ADC_DIGITAL_RETURN` checks F.Cu/In1.Cu and `ADC_DIGITAL_RETURN_BACK` checks B.Cu/In2.Cu, each with 0.25 mm foreign-track and 0.50 mm foreign-via projection floors. The source regression deletes the back check and requires failure, preventing the previous vacuous coverage.

This is a valid pre-route return-path contract, with a remaining realized-board obligation: post-route stitching must keep In1/In2 in one GND component and the final filled-board checks must prove every actual segment and transition. It is not an impedance or return-current field solve.

## Routability witness

The exact diagnostic board SHA-256 is `2d794aa817c097e104e05a7cc3b04c73e29ee3bd5b0872749964fd86bbbcbb7c`. The pinned KRT revision routed 11/11 single nets and 12/12 multipoint pads at minimum clearance 0.25 mm. It used B.Cu non-vacuously on six clock nets and ordinary 0.50/0.20 mm through vias.

A fresh independent `reference_plane_check.py` run against the diagnostic and corrected live rules passes both checks. F.Cu/In1.Cu's nearest foreign via clearance is 0.583283 mm; B.Cu/In2.Cu's is 2.384694 mm. No foreign reference-layer track is present in either plane. This repairs the earlier diagnostic's 0.452383 mm ADC_FSYNC-to-ADC_RESET_N projected clearance failure.

The diagnostic establishes a feasible two-layer escape and route. It remains a partial/raw route witness; complete connectivity, cleanup, branch/cycle rules, filled GND continuity, critical-path checks and native zero-open DRC remain owned by later gates.

## Fresh checks

- `test_digital_launch_source.py`: 10/10 PASS, including full capsule, source budget, width, owner and layer checks.
- `test_route_source_contract.py`: 24/24 PASS, including authoritative F/B stack references and the hostile missing-back-projection control.
- Native KiCad 10.0.4 r0 DRC: 199 environment-only library warnings, 40 prepared `track_dangling`, 21 prepared `via_dangling`, 444 expected pre-route opens, zero schematic parity issues and zero other/hard physical findings.
- Diagnostic dual reference projection: PASS/PASS.

Prepared dangling copper and opens are not waived. The owning route must consume or correctly clean them before post-route acceptance.

FIRST-ARTICLE-ONLY / DO-NOT-ORDER.
