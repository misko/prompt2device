#!/usr/bin/python3
import pcbnew,json,math,hashlib,yaml,runpy
from pathlib import Path
root=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901'); proj=root/'projects/crow-audio-carrier-v1'; out=Path('/tmp/carrier-clock-layout-exits-review-20260914T055011Z')
board=proj/'06_build/route/r0.kicad_pcb'; b=pcbnew.LoadBoard(str(board)); route=yaml.safe_load((proj/'03_src/route.yaml').read_text()); nets=yaml.safe_load((proj/'03_src/rules/nets.yaml').read_text()); stack=yaml.safe_load((proj/'03_src/rules/stackup.yaml').read_text()); floor=yaml.safe_load((proj/'03_src/floorplan.yaml').read_text())
mm=lambda v:v/1e6
tracks=list(b.GetTracks())
def e(t):return [mm(t.GetStart().x),mm(t.GetStart().y),mm(t.GetEnd().x),mm(t.GetEnd().y)]
def d(o):
 if isinstance(o,pcbnew.PAD):return f'{o.GetParentFootprint().GetReference()}.{o.GetNumber()} pad/{o.GetNetname()}'
 if isinstance(o,pcbnew.PCB_VIA):return f'via {mm(o.GetPosition().x):.3f},{mm(o.GetPosition().y):.3f}/{o.GetNetname()}'
 q=e(o);return f'track {q[0]:.3f},{q[1]:.3f}->{q[2]:.3f},{q[3]:.3f}/{o.GetNetname()}/{mm(o.GetWidth()):.3f}/{o.GetLayerName()}'
def obs(layer):
 a=[t for t in tracks if t.IsOnLayer(layer)]
 for f in b.GetFootprints():a += [p for p in f.Pads() if p.IsOnLayer(layer)]
 return a
def nearest(t,layer):
 s=t.GetEffectiveShape(layer); best=None
 for o in obs(layer):
  if o is t or o.GetNetCode()==t.GetNetCode():continue
  try:q=mm(s.GetClearance(o.GetEffectiveShape(layer)))
  except:continue
  if best is None or q<best[0]:best=(q,d(o))
 return {'mm':round(best[0],6),'object':best[1]}
targets=[]
for t in tracks:
 if isinstance(t,pcbnew.PCB_VIA):continue
 q=e(t); key=(t.GetNetname(),tuple(q[:2]),tuple(q[2:]))
 if t.GetNetname() in ('ADC_BCLK','MCH_FSYNC','MCLK_BUF'):
  targets.append({'net':t.GetNetname(),'layer':t.GetLayerName(),'width_mm':mm(t.GetWidth()),'start':q[:2],'end':q[2:],'length_mm':math.dist(q[:2],q[2:]),'nearest_foreign':nearest(t,t.GetLayer())})
# authoritative versus execution layer contract
wave=next(w for w in route['route']['waves'] if w['name']=='clocks')
class_route=route['route']['routability']['class_layers']['ADC_CLOCK']; class_stack=stack['routing_classes']['ADC_CLOCK']; class_nets=nets['classes']['ADC_CLOCK']
# Via dimensions and physical reference planes
vias=[]
for t in tracks:
 if isinstance(t,pcbnew.PCB_VIA): vias.append({'net':t.GetNetname(),'at':[mm(t.GetPosition().x),mm(t.GetPosition().y)],'size_mm':mm(t.GetWidth(pcbnew.F_Cu)),'drill_mm':mm(t.GetDrillValue()),'layers':[b.GetLayerName(t.TopLayer()),b.GetLayerName(t.BottomLayer())]})
mod=runpy.run_path(str(root/'skills/kicad-pcb/scripts/pre_route_review_check.py'))
res={'pcbnew':pcbnew.GetBuildVersion(),'hashes':{p:hashlib.sha256((proj/p).read_bytes()).hexdigest() for p in ['03_src/route.yaml','03_src/floorplan.yaml','03_src/rules/nets.yaml','03_src/rules/stackup.yaml','04_kicad/crow_audio_carrier_v1.kicad_pcb','06_build/route/r0.kicad_pcb']},'design_rules':mod['design_rules_digest'](proj),'targets':sorted(targets,key=lambda x:(x['net'],x['start'])),'layer_contract':{'wave':wave['layers'],'route_class_layers':class_route,'stackup':class_stack,'nets_routing':class_nets['routing']},'stack_copper':stack['copper'],'via_families':stack['via_families'],'realized_vias':vias,'counts':{'footprints':len(list(b.GetFootprints())),'back_footprints':sum(f.GetLayer()==pcbnew.B_Cu for f in b.GetFootprints()),'vias':len(vias),'tracks':len(tracks)-len(vias),'zones':len(list(b.Zones()))}}
(out/'geometry-audit.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n');print(json.dumps(res,indent=2,sort_keys=True))
