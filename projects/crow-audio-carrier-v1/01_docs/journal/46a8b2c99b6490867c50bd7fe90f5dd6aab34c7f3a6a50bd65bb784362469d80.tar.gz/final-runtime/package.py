from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import sys,json,hashlib,re,tarfile,io,collections
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-mic-pod-v3';T=P/'06_build/task_runs/rj45-pod-placement-after-recovery1';O=T/'outputs';H=P/'06_build/handoffs/rj45-pod-placement-after-recovery1'
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet,writer_scope_receipt
from pipeline_runtime import _tree_snapshot,_changed_paths,_snapshot_sha256
E=TaskEnvelope.from_json((T/'envelope.json').read_text());A=json.loads((T/'admission.json').read_text());subject=E.subject.to_mapping();sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def record(p,base=P):return {'path':p.relative_to(base).as_posix(),'size':p.stat().st_size,'sha256':sha(p.read_bytes())}
protected=json.loads((T/'protected-preimages.json').read_text());assert all(sha((R/x['path']).read_bytes())==x['sha256'] for x in protected)
assert verify_input_packet(E,P)[0]
boardrel='04_kicad/crow_mic_pod_v3.kicad_pcb';census=json.loads((T/'native-census.json').read_text());board=census[boardrel]
components=sorted([{'ref':x['ref'],'value':x['value'],'footprint':x['footprint']} for x in board['footprints']],key=lambda x:x['ref'])
pins=sorted([{'ref':x['ref'],**p} for x in board['footprints'] for p in x['pads']],key=lambda x:(x['ref'],x['number'],x['x_mm'],x['y_mm']))
write(T/'component-census.json',components);write(T/'pin-census.json',pins)
net_cause={'VIN_PROTECTED':'protected-input distribution through D1, D2, U2, input capacitors and leakage shunt','VREF':'buffered reference distribution and unity-gain/spare-input ties','PRE_OUT':'preamplifier output to gain/output network','PRE_FB':'preamplifier feedback connection','OUTP_DRV':'positive output driver and feedback fanout','AUDIO_P':'positive audio clamp/output/probe connection','OUTP_FB':'positive driver feedback network','12V_FUSED':'fuse-to-reverse-protection input path','VREF_RAW':'reference divider and filter to buffer input','5V_QUIET':'quiet regulator output and decoupling/bias distribution','12V_POD':'RJ45 power contacts to fuse/probe and parallel power-contact ties','LDO_FB':'regulator divider/feed-forward feedback network','MIC_RAW':'capsule raw-signal/bias/coupling connection','AUDIO_N':'negative audio clamp/output/probe connection','MIC_BIAS':'microphone bias resistor/filter network','SPARE_BUF':'unused amplifier unity-gain feedback tie','LDO_NR':'regulator noise-reduction capacitor path','MIC_AC':'AC-coupled microphone input/bias/preamplifier network','POD_SHIELD':'connection between the two connector shell mounting contacts on their isolated shield net'}
classified={};md=[]
for name in ['pre_route.json','gate.json']:
 d=json.loads((P/'06_build/drc'/name).read_text());out={'report':record(P/'06_build/drc'/name),'scope':'current generated placement before prep' if name=='pre_route.json' else 'historical preceding PCB report; stale for current PCB','counts':{k:len(d[k]) for k in ['violations','unconnected_items','schematic_parity']},'ignored_checks':d['ignored_checks'],'rows':[]};md += ['\n### '+name,'','| Category / row | Exact subjects | Cause |','|---|---|---|']
 for cat in ['violations','unconnected_items','schematic_parity']:
  for i,row in enumerate(d[cat],1):
   endpoints='; '.join(x['description'] for x in row['items'])
   if cat=='unconnected_items':
    nets=set(re.findall(r'\[([^\]]+)\]',endpoints));assert len(nets)==1;net=nets.pop();assert net in net_cause
    cause=f'Unrouted {net_cause[net]}: these exact {net} endpoints have no connecting track in the zero-track placement board. Native refill still reports them disconnected; this row predates seed prep and is not evidence of router congestion.'
    if i==21:cause+=' Subsequent prep independently refuses the J1.5-to-U3.3 intent because its authored endpoint is physically on U3.5/AUDIO_N.'
    if i==49:cause+=' Subsequent prep independently refuses the J1.4-to-U3.5 intent because its authored endpoint is physically on U3.3/AUDIO_P.'
   elif row['type']=='footprint_symbol_field_mismatch':cause='Historical generated footprint omitted the Manufacturer Part Number field carried by the accepted schematic. Metadata parity mismatch for this exact footprint; current regenerated placement has no parity row.'
   elif row['type']=='footprint_symbol_mismatch':
    cause=('Historical J1 still used the four-contact Molex Micro-Fit footprint; accepted source requires the Wurth ten-pad RJ45 footprint.' if "doesn't match footprint given" in row['description'] else 'Historical footprint value differs from the accepted schematic value shown in this row; regenerated placement now reports zero native parity.')
   elif row['type']=='net_conflict':cause=('Historical Micro-Fit J1 pin 3 carried AUDIO_P while current RJ45 pin 3 is 12V_POD.' if 'Pad net' in row['description'] else 'Historical four-contact Micro-Fit J1 lacks the exact RJ45 pin/net named in this row. The new RJ45 footprint supplies it; current native parity is zero.')
   else:raise AssertionError(row)
   out['rows'].append({'category':cat,'index':i,'raw':row,'cause':cause});md.append(f'| {cat} {i} | {endpoints} | {row["description"]}. {cause} |')
 classified[name]=out
assert len(classified['pre_route.json']['rows'])==58 and len(classified['gate.json']['rows'])==55
write(T/'drc-classification.json',classified)
failures=[{'net':'GND','declared_pin':'U3.4','width_mm':0.5,'layer':'B.Cu','segment_mm':[[49.7825,27.36],[50.6,27.36]],'actual_foreign_pad':'U3.1','foreign_net':'unconnected-(U3-NC1-Pad1)','cause':'Authored stub starts exactly on NC1; actual U3.4 is at (48.3575,28.36).'}, {'net':'AUDIO_P','declared_pin':'J1.5','width_mm':0.26,'layer':'B.Cu','segment_mm':[[49.58,25.86],[48.3575,27.36]],'actual_foreign_pad':'U3.5','foreign_net':'AUDIO_N','cause':'Authored positive-audio endpoint equals actual negative-audio pad position; U3.3 AUDIO_P is at (49.7825,28.36).'}, {'net':'AUDIO_N','declared_pin':'J1.4','width_mm':0.26,'layer':'B.Cu','segment_mm':[[48.56,29.86],[49.7825,28.36]],'actual_foreign_pad':'U3.3','foreign_net':'AUDIO_P','cause':'Authored negative-audio endpoint equals actual positive-audio pad position; U3.5 AUDIO_N is at (48.3575,27.36).'}]
write(T/'seed-failures.json',failures)
now=datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
(P/'01_docs/STATUS.md').write_text(f'''# STATUS beacon — crow-mic-pod-v3

stage: placement
step: Single reviewed-schematic continuation stopped at deterministic route prep
measure: MEASURED: RJ45 PCB generated40parts+4holes; S-COUNT4/4; P-PINMAP4refs/38physical identities PASS; placement feasibility7/7 accepted; model coverage32/32; native pre-route DRC0violations/58unconnected/0parity. route_prep rc1/0.461s refuses3 U3 seed-coordinate collisions; outer resume rc1/5.958299s.
state: blocked
next: Root owns source diagnosis after worker FINAL/closure. Correct only through an admitted source successor; no local retry. Current compact handoff blocked by stale historical gate0/0/55, preserved intact. FIRST-ARTICLE-ONLY / DO-NOT-ORDER; physical FULL9pod remains owed; LAYOUT001closed3/3 unchanged.
op_pid:
updated: {now}
''')
with (P/'01_docs/journal/placement.md').open('a') as f:f.write(f'''\n## {now} — one fresh reviewed-schematic continuation; exact seed collision stop

MEASURED: input packet335/335, protected source/method preimages313/313 and green source commit2d3c8ef5 verified; canonical schematic handoff validated before launch. Exact authorized rebuild_all.sh --resume-after-schematic-review ran once via pipeline_runtime.run_stage outer660s and pcb_flow600s. Driver rc1/5.880s; outer rc1/5.958299s; route_prep rc1/0.461s. Current accepted schematic promoted normally. Generated RJ45 PCB40parts+4holes; S-COUNT4/4, P-PINMAP4refs/38physical pin identities, feasibility7/7, models32/32, placement DRC0/58/0 and P-LAND69/103 (34 without width floor) pass their stated scopes. Tier preflight0FAIL/1WARN: legalize clearance0.25mm below suggested0.8mm.

First stopping gate is prep.seed_stubs: GND U3.4 segment begins at actual NC1 pad(49.7825,27.36), while actual GND is(48.3575,28.36); AUDIO_P J1.5 segment ends at actual U3.5/AUDIO_N(48.3575,27.36); AUDIO_N J1.4 ends at actual U3.3/AUDIO_P(49.7825,28.36). All on B.Cu. Declared coordinates disagree with bottom-side U3's actual transformed pad identities. Raw log reports87 primitives constructed and3 refusals; saved PCB and failed r0 both remain0tracks/2zones, so those primitives are not saved route acceptance.

Every58 current native unconnected row and55 historical parity row is individually preserved/classified in the task outputs; current native0violations/0parity have empty censuses. This is an unrouted placement snapshot. Model registration, connector orientation, placement human review, route import/taps/stitch, route acceptance, layout seal and release are NOT RUN in this attempt. Compact handoff generation/validation refuses the untouched stale historical gate; no DRC deletion, touch or restamp. No source edits, retries, TSX generation, route import, waiver, children or commit. LAYOUT001closed3/3 unchanged. FIRST-ARTICLE-ONLY / DO-NOT-ORDER; physical FULL9pod obligations remain owed. Delivery:06_build/task_runs/rj45-pod-placement-after-recovery1/outputs.
''')
after=_tree_snapshot(P,ignored=frozenset(A['ignored']));changed=_changed_paths(A['before'],after);scope=writer_scope_receipt(E.writer_scope,changed,before_sha256=_snapshot_sha256(A['before']),after_sha256=_snapshot_sha256(after),protected_paths=tuple(sorted((E.output_path,A['claim']))));assert scope['status']=='PASS',scope
write(T/'scope-verification.json',{'writer_scope':scope,'input_packet_count':335,'input_packet_status':'PASS','protected_preimages_count':313,'protected_preimages_status':'PASS'})
paths=[P/rel for rel in changed if (P/rel).is_file() and not (P/rel).is_symlink() and not rel.startswith(('06_build/task_runs/','06_build/handoffs/'))]
paths += [P/'06_build/drc/gate.json',P/'06_build/agent_handoff.yaml',P/'04_kicad/crow_mic_pod_v3.kicad_sch',P/'03_tscircuit/build/circuit.json',P/'03_tscircuit/build/schematic.pdf',P/'06_build/netlists/crow_mic_pod_v3.net']
paths += [x for x in T.iterdir() if x.is_file() and x.name not in ['admission.json','.closing']]
paths += [R/x['path'] for x in protected if x['path'].startswith('projects/crow-mic-pod-v3/03_src/')]
paths=list(sorted(set(paths)));bindings=[record(x,R) for x in paths]
notrun=['model registration','connector orientation','placement human reviews','route import','route taps','stitch','critical-route connected check','realized-route contract','route acceptance/final native DRC','layout seal','release','physical FULL acceptance']
evidence={'schema':1,'subject':subject,'domain_result':'FAIL','stopping_gate':'route_prep / prep.seed_stubs foreign-copper refusal','source_commit':'2d3c8ef5c562499c1d1fbd4d2dc901b9b150835c','input_validation':json.loads((T/'input-validation.json').read_text()),'command':json.loads((T/'command.json').read_text()),'runtime':json.loads((T/'runtime.json').read_text()),'driver_elapsed_s':5.880,'route_prep_elapsed_s':0.461,'failures':failures,'classification':classified,'native_census':{'component_count':40,'mounting_holes':4,'pins_from_review':103,'physical_pads':len(pins),'tracks':board['track_count'],'zones':board['zone_count']},'hashes':{'pcb':record(P/boardrel),'component_census':record(T/'component-census.json'),'pin_census':record(T/'pin-census.json'),'schematic':record(P/'04_kicad/crow_mic_pod_v3.kicad_sch'),'circuit':record(P/'03_tscircuit/build/circuit.json'),'netlist':record(P/'06_build/netlists/crow_mic_pod_v3.net'),'failed_r0':record(P/'06_build/route/r0.kicad_pcb')},'not_run':notrun,'scope_verification':json.loads((T/'scope-verification.json').read_text()),'handoff_result':json.loads((T/'handoff-result.json').read_text()),'preserved_outputs':bindings,'authority':'FIRST-ARTICLE-ONLY / DO-NOT-ORDER; no routing, physical PASS or release acceptance; LAYOUT001closed3/3 unchanged'}
O.mkdir(exist_ok=True);write(O/'evidence.json',evidence)
report=f'''# Bounded pod placement continuation

MEASURED engineering result: **FAIL at route_prep / prep.seed_stubs**, 2026-09-12T23:00:28Z. The single normal reviewed-schematic continuation ran with driver rc1 in5.880s (outer runtime rc1 in5.958299s; prep0.461s). All335 frozen packet inputs,313 protected source/method preimages and source commit2d3c8ef5 were verified. No source was changed and no retry was run.

The accepted schematic was promoted and the RJ45 board generated normally:40 components and4 holes; S-COUNT4/4 and P-PINMAP4 multipart refs/38 physical identities PASS. Placement feasibility7/7, model coverage32/32, pad separation and policy pass; native pre-route DRC is0violations/58unconnected/0parity. P-LAND grades69/103 copper identities with34 having no declared width floor. Tier preflight reports0FAIL/1WARN for0.25mm legalize clearance against suggested0.8mm. Connector SOURCE is admitted while physical FULL9pod remains incomplete under the accepted first-article decision.

The three failures are exact source-coordinate/pad-identity disagreements at bottom-side U3:

| Intended seed | Measured failing segment mm | Actual collision / cause |
|---|---|---|
| GND U3.4, B.Cu0.5mm | (49.7825,27.36) to (50.6,27.36) | Start equals U3.1 NC1; actual GND pad is(48.3575,28.36). |
| AUDIO_P J1.5, B.Cu0.26mm | (49.58,25.86) to (48.3575,27.36) | End equals U3.5 AUDIO_N; AUDIO_P pad is(49.7825,28.36). |
| AUDIO_N J1.4, B.Cu0.26mm | (48.56,29.86) to (49.7825,28.36) | End equals U3.3 AUDIO_P; AUDIO_N pad is(48.3575,27.36). |

The raw prep log reports87 constructed primitives and3 refusals. Native reopen proves both the live PCB and saved failed r0 contain0tracks/2zones: those primitives were not saved as accepted copper. The58 unconnected rows below describe the placement before prep; they are not a router-failure census. No inference of congestion is made.

PCB SHA256: `{evidence['hashes']['pcb']['sha256']}`. Component-census SHA256: `{evidence['hashes']['component_census']['sha256']}`. Pin-census SHA256: `{evidence['hashes']['pin_census']['sha256']}`. Full native census, raw reports, runtime, command, generated sidecars and exact source are archived with per-member hashes.

Compact placement handoff generation refused because historical06_build/drc/gate.json is older than the new PCB. Validation also reports changed source/board hashes and stale gate. That file remains unchanged at0violations/0unconnected/55historical parity rows; no current handoff was manufactured. All55 historical rows are classified below separately. No additional DRC run or gate restamp was attempted.

NOT RUN in this attempt: {', '.join(notrun)}. Root must separately admit any source correction after actual worker FINAL and closure. Source/method preimages remain313/313 identical, frozen packet335/335 intact, exclusive writer-scope receipt PASS. Delivery checks concern complete honest evidence; they do not turn the engineering failure into a pass.

FIRST-ARTICLE-ONLY / DO-NOT-ORDER. Physical FULL9pod remains owed. No commit, route import, source edit, retry or child agent. LAYOUT001closed3/3 unchanged.

Exact output directory: `{O}`.

## Complete native row classification

Current violations0/0 and parity0/0 have no rows. Historical violations0/0 and unconnected0/0 have no rows. Every nonempty row retains its exact endpoints, native type, severity, UUIDs and positions in evidence.json and the raw archived JSON.
'''+ '\n'.join(md)+'\n'
(O/'report.md').write_text(report)
write(O/'result.json',{'subject':subject,'checks':{k:'PASS' for k in E.completion['checks']},'unresolved':[]})
members=[]
with tarfile.open(O/'evidence.tar.gz','w:gz') as tar:
 for p in paths:
  b=p.read_bytes();name=p.relative_to(R).as_posix();info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;tar.addfile(info,io.BytesIO(b));members.append({'path':name,'size':len(b),'sha256':sha(b)})
with tarfile.open(O/'evidence.tar.gz','r:gz') as tar:
 seen=set()
 for m in tar.getmembers():
  assert m.isfile() and not m.issym() and not m.islnk();assert m.name not in seen;seen.add(m.name);pp=PurePosixPath(m.name);assert not pp.is_absolute() and '..' not in pp.parts;assert not m.name.endswith(('.tar','.tar.gz','.tgz'));b=tar.extractfile(m).read();expected=next(x for x in members if x['path']==m.name);assert len(b)==expected['size'] and sha(b)==expected['sha256']
 assert len(seen)==len(members)
manifest={'archive_sha256':sha((O/'evidence.tar.gz').read_bytes()),'archive_size':(O/'evidence.tar.gz').stat().st_size,'member_count':len(members),'members':members,'independent_reopen':'PASS; all regular members re-read, safe and unique paths, no recursive archive'};write(O/'evidence-manifest.json',manifest)
print(json.dumps({'domain_result':'FAIL','writer_scope':scope['status'],'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'member_count':manifest['member_count'],'pcb_sha256':evidence['hashes']['pcb']['sha256'],'component_sha256':evidence['hashes']['component_census']['sha256'],'pin_sha256':evidence['hashes']['pin_census']['sha256']},indent=2))
