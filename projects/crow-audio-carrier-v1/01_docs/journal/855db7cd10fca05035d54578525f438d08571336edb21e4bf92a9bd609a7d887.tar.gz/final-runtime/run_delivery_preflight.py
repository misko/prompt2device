#!/usr/bin/env python3
import json,os,sys
from dataclasses import asdict
from pathlib import Path
RT=Path("/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts");sys.path.insert(0,str(RT))
from pipeline_runtime import run_stage
root=Path("/tmp/rj45-carrier-render-locator-toponly1-glpwcjiv"); scratch=root/"06_build/task_runs/rj45-carrier-render-locator-toponly1/scratch"
suffix=sys.argv[1] if len(sys.argv)>1 else "first"
cmd=["/usr/bin/python3","-B",str(root/"preflight.py"),str(root/"06_build/task_runs/rj45-carrier-render-locator-toponly1/envelope.json")]
out=run_stage({"id":f"delivery-preflight-{suffix}","work_class":"local","timeout_s":45.0},cmd,log_path=scratch/f"delivery-preflight-{suffix}.log",cwd=root,env=dict(os.environ),heartbeat_s=10.0)
(scratch/f"delivery-preflight-{suffix}-runtime.json").write_text(json.dumps(asdict(out),indent=2,sort_keys=True,default=str)+"\n")
if out.status!="PASS": raise SystemExit(out.status)
