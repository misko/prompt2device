#!/usr/bin/env python3
import hashlib
import json
import os
import stat
import sys
import tarfile
from pathlib import Path, PurePosixPath

RUNTIME=Path("/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts")
sys.path.insert(0,str(RUNTIME))
sys.path.insert(0,"/tmp/rj45-carrier-render-locator-toponly1-glpwcjiv/context/skills/kicad-pcb/scripts")
from pipeline_execution import TaskEnvelope, verify_input_packet
from pre_route_review_check import design_rules_digest

ROOT=Path("/tmp/rj45-carrier-render-locator-toponly1-glpwcjiv")
TASK=ROOT/"06_build/task_runs/rj45-carrier-render-locator-toponly1"
SCRATCH=TASK/"scratch"
OUT=TASK/"outputs"
OUT.mkdir(parents=True,exist_ok=True)
envelope=TaskEnvelope.from_json((TASK/"envelope.json").read_text())
subject=envelope.subject.to_mapping()
ok,details=verify_input_packet(envelope,ROOT)
(SCRATCH/"input-verification-after.json").write_text(json.dumps({"ok":ok,"details":details},indent=2,sort_keys=True)+"\n")
if not ok: raise SystemExit("input packet verification failed after review")

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def rec(path): return {"path":path.relative_to(ROOT).as_posix(),"size":path.stat().st_size,"sha256":sha(path)}

locator_manifest=ROOT/"current-locator/assembly_locator_manifest.json"
locator=json.loads(locator_manifest.read_text())
refs=[x["ref"] for x in locator["page_refs"]]
expected_refs=["C_AUDIO_CT2","C_FILT1_10U","C_FILT2_10U","C_PWR_CT","C_VDDA2_10N","C_VMID1_470N","C_VMID1_4U7","C_VMID2_470N","C_VMID2_4U7","R_ADC_BOT","R_ADC_PD6N","R_ADC_TOP","R_AUDIO_PD","R_AUDIO_PU","R_DUMP_TIME2","R_FILT1P","R_IN6N","R_PRE_G","R_PWR_TOP","R_VMID1_BOT","R_VMID1_TOP","R_VMID2_BOT","R_X6N"]
assert refs==expected_refs
assert sha(locator_manifest)=="1dbd47a33fd57e5cd5af3c2ad52fe444e2479ad89fe5cfd7c67e4b6c4a2e91dd"
assert design_rules_digest(ROOT/"project")=="7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c"

viewed=[]
for pattern in [
    "project/06_build/pre_route/approved_native_bottom.png",
    "project/06_build/pre_route/orientation/renders/*.png",
    "project/06_build/pre_route/orientation-supplement/*.png",
    "project/06_build/pre_route/orientation/views/*.png",
    "project/06_build/pre_route/native_registration/*/native_top_registration_overlay.png",
    "project/06_build/pre_route/native_registration/*/native_side_front.png",
    "project/06_build/pre_route/native_registration/*/native_side_right.png",
    "current-locator/assembly_locator.html",
    "current-locator/assembly_locator.pdf",
    "current-locator/assembly_locator_manifest.json",
    "current-locator/assembly_locator_[0-9][0-9][0-9].png",
]:
    for p in sorted(ROOT.glob(pattern)):
        # Only the six groups in the accepted registration index are visually consumed.
        if "molex-43650-0400-side-entry" in str(p): continue
        viewed.append(rec(p))
fresh=SCRATCH/"fresh-native-top-final.png"
viewed.append({"path":"scratch/fresh-native-top-final.png","size":fresh.stat().st_size,"sha256":sha(fresh)})
(SCRATCH/"viewed-identities.json").write_text(json.dumps({"schema":1,"viewed":viewed},indent=2,sort_keys=True)+"\n")

audit=json.loads((SCRATCH/"packet-native-audit-data.json").read_text())
pdfcmp=json.loads((SCRATCH/"pdf-visual-compare.json").read_text())
page_reviews=[]
for row,match,png in zip(locator["page_refs"],audit["locator_matches"],audit["locator_pngs"]):
    page_reviews.append({
        "page":row["page"],"ref":row["ref"],"path":row["path"],"sha256":png["sha256"],
        "verdict":"PASS","board_match":match,
        "observation":"Whole-board marker and close-up red body highlight are distinct; pads 1/2 are numbered; ref, MPN/value, top side, rotation, native X/Y and pad-net text are legible and consistent."
    })
visual_review={
    "schema":1,"reviewer":"Codex /root/rj45-carrier-render-locator-toponly1","context":"FRESH",
    "fresh_native_top":{"path":"scratch/fresh-native-top-final.png","sha256":sha(fresh),"verdict":"PASS","observation":"Complete top population renders coherently with connector mouths, polarized bulk markings, headers, board edge and four mounting holes visible; no body interpenetration or missing modeled assembly body was observed."},
    "approved_native_bottom":{"path":"project/06_build/pre_route/approved_native_bottom.png","sha256":sha(ROOT/"project/06_build/pre_route/approved_native_bottom.png"),"verdict":"PASS","observation":"Underside viewing preserves the board outline, four mounting holes, connector drilled/retention features and underside land context for F1-F8/U_ESD1-U_ESD8; source inspection confirms every footprint/body is top-mounted."},
    "orientation_views":{"verdict":"PASS","observation":"All supplied full-scene orthographic and oblique views plus J1/J5/J9 representative crops were opened. J1-J4 face north, J5-J8 south, J9 west, and J10/J11 enter vertically; visible mouths, latch/key geometry, approach axes and labels agree with source declarations."},
    "model_registration_groups":{"count":6,"ids":["wurth-615008160221-side-entry","molex-43650-0200-side-entry","samtec-tmm-106-01-l-d-top-entry","ti-dsg0008a-native-package","littelfuse-1812l035-native-package","yageo-rt0603-native-package"],"verdict":"PASS","observation":"Accepted overlay/front/right imagery and reports were inspected for all six current groups. Native bodies stay within Fab/courtyard evidence and register to declared drilled-centre, all-pad-centre or SMD-overlap datums."},
    "locator_manifest_sha256":sha(locator_manifest),"locator_reviewed_refs":refs,
    "locator_pages":page_reviews,"locator_verdict":"PASS",
    "pdf_visual_equivalence":{"embedded_page_count":pdfcmp["pdf_embedded_image_count"],"all_dimensions_match":pdfcmp["all_dimensions_match"],"max_mean_abs_channel":pdfcmp["max_mean_abs_channel"],"interpretation":"All PDF pages contain one 2400x1600 raster corresponding to the reviewed PNG page; measured difference is JPEG recompression."},
    "html_verdict":"PASS","html_observation":"Self-contained HTML was opened structurally; all 23 exact refs and the current board-bound atlas data are present."}
(SCRATCH/"visual-review.json").write_text(json.dumps(visual_review,indent=2,sort_keys=True)+"\n")

evidence={
    "schema":1,"review_stage":"pre-route","review_kind":"render","reviewer":"Codex /root/rj45-carrier-render-locator-toponly1","context":"FRESH",
    "subject":subject,"board_sha256":"92a4e2fc0fecde845f2dfa0d9e2f5bfbd943372962fb449d699a98d957fc5633",
    "design_rules_sha256":"7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c",
    "locator_manifest_sha256":sha(locator_manifest),"locator_reviewed_refs":refs,
    "verdict":"SOUND","order_verdict":"DO-NOT-ORDER",
    "methods":[
        {"id":"input-envelope","result":"PASS","detail":"Verified all 719 envelope inputs before render and after review."},
        {"id":"fresh-native-render","result":"PASS","detail":"Bounded supported render_board.py top render from the frozen board; 333/333 model paths resolved."},
        {"id":"native-scene-visual","result":"PASS","detail":"Opened fresh top, approved bottom, seven registered orientation renders, two supplemental obliques, eleven connector views, and all accepted six-group registration overlay/front/right images."},
        {"id":"source-measurement","result":"PASS","detail":"Read-only pcbnew census and exact locator-to-board coordinate/rotation/side comparison."},
        {"id":"locator-visual","result":"PASS","detail":"Visually reviewed all 23 PNG exception pages; structurally opened HTML; verified PDF as 23 full-page 2400x1600 rasters corresponding to reviewed PNGs."}
    ],
    "measured_counts":{"envelope_inputs":719,"board_footprints":340,"top_footprints":340,"bottom_footprints":0,"native_model_instances":333,"resolved_model_paths":333,"model_less_board_features":7,"assembly_parts":333,"locator_exception_refs":23,"locator_pages_png":23,"locator_pages_pdf":23,"edge_cut_primitives":4,"mounting_holes":4,"all_npth_including_connector_locators":21,"track_items_pre_route":11,"zones":87},
    "observations":[
        "J1-J8 exact Wurth RJ45 bodies present coherent outward mouths at north/south edges; J9 exact Molex power header presents west-facing keyed/latching access; J10/J11 exact Samtec 2x6 headers are top-entry and distinctly labeled.",
        "All bodies are source-declared top-mounted. The bottom view exposes underside pads, holes and retention geometry; F1-F8 and U_ESD1-U_ESD8 remain top-side parts in the native source.",
        "The nominal rectangular board is 154 x 100 mm; the measured Edge.Cuts stroke bounding box is 154.1 x 100.1 mm. H1-H4 are 3.2 mm NPTH mounting holes.",
        "The seven model-less footprints are board features FID1-FID3 and H1-H4, so 340 footprints and 333 model instances form a complete population/body census.",
        "The 23 omitted silkscreen refs are exactly the governed refdes waiver and exactly the locator hidden/page-ref list; each has a clear current locator page.",
        "Whole-board native render judgment is SOUND. Catalog component-body twin fidelity is a separate gate and was not inferred from these native model images."
    ],
    "findings":[],
    "limitations":[
        "Straight-on full-scene row views retain real occlusion; representative crops, top/oblique views and source axes cover the connector directions without removing parts.",
        "Native Fab sampling and rendered pixels are nominal model evidence, not installed tolerance, solder seating, mated fit or service-clearance qualification.",
        "Free RJ45 EMI-finger nominal extent is retained in the exact manufacturer model; manufacturing tolerance, latch sweep and hand clearance remain first-article measurements.",
        "J10/J11 are unshrouded top-entry headers; pin-1/source orientation is present, while cable fit, simultaneous seating and retention remain first-article holds."
    ],
    "first_article_holds":["Board remains unrouted and is not route-accepted.","Manual connector process, installed fit/tolerance, latch/finger access, polarity/continuity and service operation remain first-article-only.","Factory Cat6A/RJ45 carries custom analog/DC, not Ethernet/PoE; mate only power-off."],
    "unresolved_findings":[]
}
(OUT/"evidence.json").write_text(json.dumps(evidence,indent=2,sort_keys=True)+"\n")

report=f'''review_stage: pre-route
review_kind: render
reviewer: Codex /root/rj45-carrier-render-locator-toponly1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
subject_raw_sha256: {subject['raw_sha256']}
subject_semantic_sha256: {subject['semantic_sha256']}
board_sha256: 92a4e2fc0fecde845f2dfa0d9e2f5bfbd943372962fb449d699a98d957fc5633
design_rules_sha256: 7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c
locator_manifest_sha256: {sha(locator_manifest)}
locator_reviewed_refs: {json.dumps(refs,separators=(',',':'))}
full_board_native_render_verdict: SOUND
assembly_locator_verdict: SOUND
catalog_twin_verdict: SEPARATE-NOT-ADJUDICATED

The fresh supported top render resolved 333/333 native model paths and showed a coherent complete population. J1-J8 face outward at the north/south board edges, J9 faces west with its power-connector mouth/latch geometry exposed, and J10/J11 are distinct vertical top-entry headers. The existing full-scene orthographic/oblique views, connector representatives, approved bottom view, and accepted six-group registration evidence agree with the frozen source. All source footprints are top-mounted; the underside view supplies pad, drilled-retention and land context for the fuse/ESD rows without removing bodies.

The read-only census found 340 footprints: 333 modeled assembly parts plus FID1-FID3 and H1-H4 as seven intentional model-less board features. The nominal outline is 154 x 100 mm (154.1 x 100.1 mm including Edge.Cuts stroke), with four 3.2 mm mounting holes and 21 NPTH holes including connector locators. No body interpenetration, missing modeled assembly part, wrong mounted side, reversed connector access, or board-edge/hole anomaly was observed.

All 23 locator exception PNG pages were visually opened. Every page has an unambiguous whole-board mark and close-up highlighted body with numbered pads and legible exact ref/value/MPN/LCSC, top side, rotation and native coordinate. Those 23 coordinate/rotation/side tuples match the frozen board exactly; the page refs equal both the locator hidden list and the governed refdes waiver. The HTML contains all exact refs. The PDF has 23 pages, each holding one 2400 x 1600 page raster; comparison with the reviewed PNGs showed matching dimensions and only JPEG recompression (maximum mean absolute channel difference {pdfcmp['max_mean_abs_channel']}).

findings: []

Rendered visibility retains real row occlusion. The representative crops, top/oblique views and source axes resolve access direction without part removal, but native Fab sampling and nominal CAD do not qualify installed tolerance, solder seating, mated fit, EMI-finger/latch sweep, hand clearance, cable retention or simultaneous J10/J11 seating. Those remain first-article holds. Catalog component-body twin fidelity remains a separate gate. The board is unrouted, carries custom analog/DC over factory Cat6A rather than Ethernet/PoE, requires power-off mating, and remains FIRST-ARTICLE-ONLY / DO-NOT-ORDER.
'''
(OUT/"report.md").write_text(report)

archive_members=[
    "audit_packet.py","contact_sheets.py","run_audit_packet.py","run_contact_sheets.py","run_fresh_render.py","pdf_visual_compare.py","run_pdf_visual_compare.py","package_delivery.py","run_package_delivery.py",
    "input-verification-before.json","input-verification-after.json","viewed-identities.json","visual-review.json",
    "fresh-native-top.png","fresh-native-top.log","fresh-native-top-command.json",
    "fresh-native-top-final.png","fresh-native-top-final.log","fresh-native-top-final-command.json","fresh-native-top-final-runtime.json",
    "contact-sheets.log","contact-sheets-runtime.json","orientation-all.png","connector-views-all.png","registration-groups-1-3.png","registration-groups-4-6.png",
    "locator-pages-01-04.png","locator-pages-05-08.png","locator-pages-09-12.png","locator-pages-13-16.png","locator-pages-17-20.png","locator-pages-21-23.png",
    "packet-native-audit.json","packet-native-audit-runtime.json","packet-native-audit-final.json","packet-native-audit-final-runtime.json","packet-native-audit-data.json","packet-native-audit-data.log","packet-native-audit-data-runtime.json",
    "pdf-visual-compare.json","pdf-visual-compare.log","pdf-visual-compare-runtime.json"
]
# Include the first completed delivery preflight on the second packaging pass.
for optional in ["delivery-preflight-first.log","delivery-preflight-first-runtime.json","run_delivery_preflight.py",
                 "package-delivery-first.log","package-delivery-first-runtime.json",
                 "package-delivery-second.log","package-delivery-second-runtime.json"]:
    if (SCRATCH/optional).is_file(): archive_members.append(optional)
archive=OUT/"evidence.tar.gz"
with tarfile.open(archive,"w:gz",format=tarfile.PAX_FORMAT) as tf:
    for name in archive_members:
        p=SCRATCH/name
        if not p.is_file() or p.is_symlink(): raise SystemExit(f"unsafe/missing archive member {p}")
        tf.add(p,arcname=name,recursive=False)

records=[]; seen=set()
with tarfile.open(archive,"r:gz") as tf:
    for m in tf.getmembers():
        pp=PurePosixPath(m.name)
        if pp.is_absolute() or any(x in ("",".","..") for x in pp.parts) or m.name in seen or not m.isfile() or m.issym() or m.islnk(): raise SystemExit(f"unsafe archive member {m.name}")
        seen.add(m.name); f=tf.extractfile(m); data=f.read() if f else b""
        if len(data)!=m.size: raise SystemExit(f"archive reopen size mismatch {m.name}")
        records.append({"path":m.name,"size":m.size,"sha256":hashlib.sha256(data).hexdigest()})
if len(records)!=len(archive_members): raise SystemExit("archive member census mismatch")
manifest={"schema":1,"archive_sha256":sha(archive),"archive_size":archive.stat().st_size,"member_count":len(records),"members":records}
(OUT/"evidence-manifest.json").write_text(json.dumps(manifest,indent=2,sort_keys=True)+"\n")
(OUT/"result.json").write_text(json.dumps({"subject":subject,"checks":{"inputs-verified":"PASS","review-complete":"PASS","evidence-complete":"PASS"},"unresolved":[]},indent=2,sort_keys=True)+"\n")
print(json.dumps({"status":"PASS","verdict":"SOUND","archive_sha256":manifest["archive_sha256"],"archive_size":manifest["archive_size"],"member_count":manifest["member_count"]}))
