import gzip
import hashlib
import json
import tarfile
from pathlib import Path

root = Path('/tmp/carrier-channel-thermal-review-flk6gxax')
run = root / '06_build/task_runs/channel-thermal-review'
scratch = run / 'scratch'
outputs = run / 'outputs'
archive = outputs / 'evidence.tar.gz'

sources = []
for path in sorted(scratch.rglob('*')):
    if path.is_file():
        sources.append((path, Path('scratch') / path.relative_to(scratch)))
for name in ('report.md', 'evidence.json'):
    sources.append((outputs / name, Path(name)))

with archive.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tf:
            for path, arcname in sources:
                info = tf.gettarinfo(str(path), arcname.as_posix())
                info.mtime = 0
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                with path.open('rb') as stream:
                    tf.addfile(info, stream)

members = []
with tarfile.open(archive, 'r:gz') as tf:
    for info in tf.getmembers():
        stream = tf.extractfile(info)
        payload = stream.read() if stream else b''
        members.append({'path': info.name, 'size': len(payload),
                        'sha256': hashlib.sha256(payload).hexdigest()})
manifest = {
    'schema': 1,
    'archive': {'path': 'evidence.tar.gz', 'size': archive.stat().st_size,
                'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
    'members': members,
}
(outputs / 'evidence-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'members': len(members), **manifest['archive']}, sort_keys=True))
