import json
from pathlib import Path

root = Path(__file__).resolve().parent
data = json.loads((root / 'native-inspection.json').read_text())
colors = {-1: '#d1d5db', 2: '#16a34a'}
panels = [('pre_map', 'Accepted pre-map board'), ('current', 'Actual failed current board')]
svg = ['<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="560" viewBox="0 0 1200 560">',
       '<rect width="1200" height="560" fill="#111827"/>',
       '<style>text{font-family:DejaVu Sans,sans-serif;fill:#f9fafb}.small{font-size:14px}.label{font-size:17px}.title{font-size:23px;font-weight:bold}</style>']
for panel_i, (name, title) in enumerate(panels):
    ox = 40 + panel_i * 590
    svg.append(f'<text x="{ox}" y="42" class="title">{title}</text>')
    svg.append(f'<rect x="{ox}" y="65" width="540" height="420" rx="10" fill="#1f2937" stroke="#6b7280"/>')
    rows = data['adc_common_mode_projection'][name]
    for idx, ref in enumerate(sorted(rows)):
        row = rows[ref]['pad2']
        x, y = row['position_mm']
        px = ox + 60 + (x - 92.0) * 45
        py = 115 + (y - 61.5) * 28
        mode = row['local_zone_connection']
        color = colors.get(mode, '#ef4444')
        svg.append(f'<circle cx="{px:.1f}" cy="{py:.1f}" r="12" fill="{color}" stroke="#fff"/>')
        svg.append(f'<text x="{px+16:.1f}" y="{py+5:.1f}" class="small">{ref[8:]}</text>')
    svg.append(f'<text x="{ox+20}" y="520" class="label">green = pad 2 local full/solid; gray = inherited thermal</text>')
svg.append('</svg>')
(root / 'native-ground-modes.svg').write_text('\n'.join(svg) + '\n')
