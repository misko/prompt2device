import hashlib
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
import pcbnew


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pad_row(pad):
    pos = pad.GetPosition()
    size = pad.GetSize()
    return {
        "number": pad.GetNumber(),
        "net": pad.GetNetname(),
        "position_mm": [pos.x / 1_000_000, pos.y / 1_000_000],
        "size_mm": [size.x / 1_000_000, size.y / 1_000_000],
        "orientation_deg": pad.GetOrientationDegrees(),
        "layer": pad.GetLayerName(),
        "local_zone_connection": int(pad.GetLocalZoneConnection()),
    }


def board_rows(path):
    board = pcbnew.LoadBoard(str(path))
    refs = {}
    ground_pads = []
    for fp in board.GetFootprints():
        ref = fp.GetReference()
        pads = [pad_row(p) for p in fp.Pads()]
        refs[ref] = {
            "position_mm": [fp.GetPosition().x / 1_000_000,
                            fp.GetPosition().y / 1_000_000],
            "rotation_deg": fp.GetOrientationDegrees(),
            "pads": pads,
        }
        for row in pads:
            if row["net"] == "GND":
                ground_pads.append({"ref": ref, **row})
    return {
        "path": str(path),
        "sha256": sha256(path),
        "footprints": len(refs),
        "pads": sum(len(v["pads"]) for v in refs.values()),
        "refs": refs,
        "ground_pads": ground_pads,
    }


def physical_ground_modes(data):
    return sorted((tuple(p["position_mm"]), p["number"],
                   p["local_zone_connection"], p["ref"])
                  for p in data["ground_pads"])


root = Path(__file__).resolve().parent
boards = {
    "pre_map": board_rows(root / "pre-map-board.kicad_pcb"),
    "unfixed": board_rows(root / "unfixed-board.kicad_pcb"),
    "current": board_rows(root / "current-board.kicad_pcb"),
}

interesting = [f"C_ADC_CM{n}{leg}" for n in range(1, 9) for leg in "PN"]
projection = {}
for name, data in boards.items():
    projection[name] = {
        ref: {
            "footprint_position_mm": data["refs"][ref]["position_mm"],
            "footprint_rotation_deg": data["refs"][ref]["rotation_deg"],
            "pad2": next(p for p in data["refs"][ref]["pads"]
                         if p["number"] == "2"),
        }
        for ref in interesting
    }

def solids(data):
    return sorted((p["ref"], p["number"], p["position_mm"])
                  for p in data["ground_pads"]
                  if p["local_zone_connection"] == int(pcbnew.ZONE_CONNECTION_FULL))

result = {
    "schema": 1,
    "zone_enum": {
        "inherited": int(pcbnew.ZONE_CONNECTION_INHERITED),
        "thermal": int(pcbnew.ZONE_CONNECTION_THERMAL),
        "full": int(pcbnew.ZONE_CONNECTION_FULL),
        "none": int(pcbnew.ZONE_CONNECTION_NONE),
    },
    "boards": {k: {x: v[x] for x in ("path", "sha256", "footprints", "pads")}
               for k, v in boards.items()},
    "adc_common_mode_projection": projection,
    "solid_ground_pads": {k: solids(v) for k, v in boards.items()},
    "all_ground_physical_modes_pre_map_equal_unfixed":
        physical_ground_modes(boards["pre_map"]) == physical_ground_modes(boards["unfixed"]),
    "all_ground_physical_modes_pre_map_equal_current":
        physical_ground_modes(boards["pre_map"]) == physical_ground_modes(boards["current"]),
}

(root / "native-inspection.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
