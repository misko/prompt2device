import json
import os
import sys
from pathlib import Path

sys.dont_write_bytecode = True
scripts = Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
sys.path.insert(0, str(scripts))
from pipeline_runtime import run_stage

if len(sys.argv) < 4:
    raise SystemExit('usage: run_bounded.py STAGE LOG COMMAND...')

stage, log, *command = sys.argv[1:]
spec = {"id": stage, "work_class": "local", "timeout_s": 45}
outcome = run_stage(spec, command, log_path=log, cwd=Path(__file__).parent,
                    env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
                    heartbeat_s=5, console_line_limit=30)
payload = outcome.to_mapping() if hasattr(outcome, 'to_mapping') else outcome.__dict__
runtime_path = Path(log).with_suffix('.runtime.json')
runtime_path.write_text(json.dumps(payload, indent=2, default=str) + '\n')
print(json.dumps(payload, sort_keys=True, default=str))
raise SystemExit(outcome.returncode)
