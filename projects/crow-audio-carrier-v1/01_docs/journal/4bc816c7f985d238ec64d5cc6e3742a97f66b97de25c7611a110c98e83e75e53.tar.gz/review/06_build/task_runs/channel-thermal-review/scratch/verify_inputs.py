import hashlib
import json
from pathlib import Path

root = Path('/tmp/carrier-channel-thermal-review-flk6gxax')
env = json.loads((root / '06_build/task_runs/channel-thermal-review/envelope.json').read_text())
rows = []
for item in env['input_packet']:
    path = root / item['path']
    actual = {'size': path.stat().st_size,
              'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    rows.append({'path': item['path'], 'declared': {'size': item['size'], 'sha256': item['sha256']},
                 'actual': actual, 'pass': actual == {'size': item['size'], 'sha256': item['sha256']}})
sup = root / '06_build/task_runs/channel-thermal-review/scratch/supplement'
manifest = json.loads((sup / 'manifest.json').read_text())
supplement = []
for name, declared in manifest.items():
    path = sup / name
    actual = {'size': path.stat().st_size,
              'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    supplement.append({'path': name, 'declared': declared, 'actual': actual,
                       'pass': actual == declared})
result = {'original_packet': rows, 'original_pass': all(r['pass'] for r in rows),
          'supplement_manifest_sha256': hashlib.sha256((sup/'manifest.json').read_bytes()).hexdigest(),
          'supplement': supplement, 'supplement_pass': all(r['pass'] for r in supplement)}
(root / '06_build/task_runs/channel-thermal-review/scratch/input-verification.json').write_text(json.dumps(result, indent=2)+'\n')
print(f"original {sum(r['pass'] for r in rows)}/{len(rows)}; supplement {sum(r['pass'] for r in supplement)}/{len(supplement)}")
