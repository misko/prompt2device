from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,tarfile,io,sys,subprocess,shutil
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911');sha=lambda b:hashlib.sha256(b).hexdigest()
sys.path.insert(0,str(R/'skills/pcb-design/scripts'));from pipeline_execution import TaskEnvelope,verify_input_packet
j=json.loads((D/'channel-thermal-review-opened.json').read_text())[0];root=Path(j['project']);a=json.loads(Path(j['attempt']).read_text());e=TaskEnvelope.from_json(Path(j['envelope']).read_text());assert a['status']=='PASS' and verify_input_packet(e,root)[0]
for n,m in a['output']['completion']['outputs'].items():b=(Path(j['output_dir'])/n).read_bytes();assert len(b)==m['size'] and sha(b)==m['sha256']
for name in ['03_src/floorplan.yaml','03_src/tests/test_adc_channel_map.py']:assert (P/name).read_bytes()==(root/'current'/name).read_bytes()
files={'review/'+f.relative_to(root).as_posix():f for f in root.rglob('*') if f.is_file()}
for p in I.glob('channel-thermal-*'):
 if p.is_file():files['root/validation/'+p.name]=p
for n in ['channel-thermal-review-reopening.json','channel-thermal-failure-preservation.json','verify_channel_pin_transfer.py','preserve_channel_thermal_failure.py','preserve_channel_thermal_correction.py','commission_channel_thermal_review.py']:
 files['root/'+n]=D/n
for f in (D/'thermal-review-supplement').iterdir():
 if f.is_file():files['root/supplement/'+f.name]=f
assert (P/'03_src/tests/test_ground_connections.py').read_bytes()==(D/'thermal-review-supplement/after.py').read_bytes()
members={n:{'size':f.stat().st_size,'sha256':sha(f.read_bytes())} for n,f in sorted(files.items())}
tmp=D/'channel-thermal-correction.tar.gz'
with tarfile.open(tmp,'w:gz',compresslevel=3) as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 b=(json.dumps({'members':members},indent=2)+'\n').encode();m=tarfile.TarInfo('MANIFEST.json');m.size=len(b);t.addfile(m,io.BytesIO(b))
h=sha(tmp.read_bytes());out=D/(h+'.tar.gz');assert not out.exists();tmp.rename(out)
with tarfile.open(out) as t:
 assert set(t.getnames())==set(members)|{'MANIFEST.json'}
 for n,m in members.items():b=t.extractfile(n).read();assert len(b)==m['size'] and sha(b)==m['sha256']
result={'time':datetime.now(timezone.utc).isoformat(),'archive':str(out),'sha256':h,'size':out.stat().st_size,'payload_members':len(members),'inputs_verified':len(e.input_packet)};(D/'channel-thermal-correction-preservation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
