from pathlib import Path
import sys,tempfile,shutil,subprocess,json
sys.dont_write_bytecode=True
D=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';root=Path(tempfile.mkdtemp(prefix='carrier-channel-thermal-review-'));sys.path.insert(0,str(D));from open_review import open_review
for name in ['03_src/floorplan.yaml','03_src/tests/test_adc_channel_map.py','01_docs/decisions/0027-fixed-north-adc-channel-map.md','04_kicad/crow_audio_carrier_v1.kicad_pcb','06_build/drc/pre_route.json']:
 q=root/'current'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(P/name,q)
for commit,label in [('f2675b43','pre-map'),('3fc3935a','unfixed')]:
 for name in ['03_src/floorplan.yaml','04_kicad/crow_audio_carrier_v1.kicad_pcb']:
  q=root/label/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(subprocess.check_output(['git','show',commit+':projects/crow-audio-carrier-v1/'+name],cwd=R))
shutil.copyfile(R/'skills/kicad-pcb/scripts/generate_board_generic.py',root/'generate_board_generic.py')
shutil.copyfile(D/'verify_channel_pin_transfer.py',root/'root-native-projection.py')
for prefix in ['channel-thermal-source-red','channel-thermal-source-green','channel-thermal-native-red']:
 for p in Path('/tmp/carrier-connector-integration-20260911').glob(prefix+'*'):
  if p.is_file():shutil.copyfile(p,root/p.name)
open_review(root,'channel-thermal-review','''Agent-role judgment; independent focused review of one source omission following ADR0027. READ_ONLY, no children. Review source correction, not new board acceptance. current/floorplan is corrected; current PCB and pre_route.json are the actual FAILED unfixed placement (SHA25287c83682141495ac07ae7fdf541bd92156891abf3294fd15fca83ffed5b9b). pre-map is original accepted board9aa at f2675b43; unfixed source is3fc3935a. Exact source difference should ONLY change pad_override match CM3P/N to CM2P/N, restoring the original physical ground-land connection modes after ref swaps. Root source regression originalRED, corrected7/7GREEN; enhanced native projection failed against actual current board on four CM references. Full337-source suite is running separately and is not supplied/claimed.

Independently inspect native pad positions/net/zone modes and DRC causes. Compare all physical ground exceptions before/after mapping, ensure neither removing other exceptions nor adding unnecessary solid connections. Inspect production pad-overrides consumer and new property test; assess test independence, nonvacuity and old missed-migration hostile. Check unchanged geometry/limits/electrical connectivity of proposed source and any issue with mapping override attribution. Native corrected BOARD has not been generated yet; do not claim green DRC or corrected native projection. Any helper using live Git paths must instead use packet copies; no live project dependencies, network or edits. Use native pcbnew read-only/allocated scratch. Report SOUND/NEEDS-CORRECTION source judgment, exact coverage, remaining normal canonical/placement/native/PIN/render/layout/route/release gates. Existing corridor history3/3spent remains untouched. No further diagnosticroute admitted, DO-NOT-ORDER remains. Deliver noncanonical complete focused source report. Use actual current time for completed_at.''',10)
