review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_conversion_clockground1
context: Independent original fresh review continued with requested native/primary facts; not a new fresh agent
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
release_scope: FIRST-ARTICLE-ONLY
board_sha256: e85b1461a82f3d3853c19fae694693816e31570d23d37019ef187d6428bea4ae
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: e6d5b0b89efd79051b082f70b283ec7e85e1170ed11ddb94581744d26904c9c7

Limited conversion-group pin acceptance: U_ADC and U_LDO, plus the four supplied configuration resistors. All six scoped instances PASS. No unresolved pin-review findings remain. This is not whole-board, layout, routed-connectivity, capture or order acceptance. Immutable board/parts/rules fields remain supplied subject bindings.

This continuation resolves two questions from the closed original review without altering its report or its INCOMPLETE verdict. The original report SHA256 is c752850921aef58a5c7e5b29ebcb23df306322bbb5d585ebca729e377790785a. Successful original physical image judgments are inherited only for unchanged dossier/primary bytes. The exact native ADC and LDO rows were compared again against the retained measured comparison: all geometry, functions and nets remain identical. New supplemental facts establish mode and declared channel intent; desired operation was not used as proof of native wiring. The envelope context_mode field says FRESH, but this report honestly records CONTINUED context and makes no new-agent claim.

U_ADC — VERDICT: PASS

Primary CS5308P DS1314F1 SHA256 6ca42cc09ac47ebdacacaee435f05e3f9c34b83d5692e52a2d8a26533e810e57. Inherited actual images: page 4 Figure 1-1, page 7 Figure 2-1, page 93 Figure 10-1. New actual images: pages 19–20 Tables 4-1 through 4-4, page 32 Figure 4-7, page 37 Figure 4-15. Supporting text page 6 Table 1-2 and page 35 Table 4-13.

Inherited physical facts: TOP VIEW pin 1 upper left; 1–12 down west, 13–24 rightward south, 25–36 upward east, 37–48 leftward north; CCW with 12 terminals per side. Manufacturer bottom package view converts by horizontal reflection to this top view. Front native mounting uses no reflection, and local +x right/+y down matches directly. 6 x 6 mm package, 0.4-mm pitch, 4.6 x 4.6 mm nominal ground paddle, artifact identity 49 for manufacturer PAD. All 49 distinct identities preserved; nine additional anonymous paste-only features, 58 total native pad features. No fused aliases or identity collapse.

Inherited power/reference/clock checks remain PASS: pins 5/9/31 on 3V3_ADC; pins 6/8/30/49 on GND; 32/33 correctly share LDO_D_FILT; 7 on LDO_A_FILT; 1/12 VMID1/2; 18/43 FILT2P/FILT1P and 17/44 grounded as Figure 2-1 shows. Reset23, FSYNC24, DOUT1_25, BCLK29 and MCLK34 retain appropriate named nets ADC_RESET_N/ADC_FSYNC/TDM_RAW/ADC_BCLK/ADC_MCLK. Complete inherited pad-level measurements remain archived.

New native strap derivation, independently applying primary Tables 4-1 through 4-4:

- U_ADC pin 2 CONFIG1 reaches R_CFG1 pin 1 through CFG1; R_CFG1 pin 2 is GND. Exact manufacturer resistance 4.7 kohm selects hardware control, ASP Secondary Mode, 44.1/48 kHz. BCLK and FSYNC are therefore inputs (Figure 4-7).
- U_ADC pin 3 CONFIG2 reaches R_CFG2 pin 1 through CFG2; R_CFG2 pin 2 is 3V3_ADC, also the actual VDD_A net. Exact manufacturer 0-ohm resistance selects TDM minimum time slots.
- U_ADC pin 4 CONFIG3 is GND. This selects default/lower slots 0–7; no upper-eight assignment is selected.
- U_ADC pin 10 CONFIG4 reaches R_CFG4 pin 1 through CFG4; R_CFG4 pin 2 is 3V3_ADC. Exact 4.7 kohm pull-up selects default channel order, not reversed serial channel order.
- U_ADC pin 11 CONFIG5 reaches R_CFG5 pin 1 through CFG5; R_CFG5 pin 2 is GND. Exact 100 kohm pull-down selects linear-phase fast-roll-off filtering with HPF enabled.

Table 4-13 gives eight slots and one DOUT for TDM minimum slots at 44.1/48 kHz. Figure 4-15/page 37 explicitly places physical ADC channels 1–8 on DOUT1 in slots 0–7; DOUT2–4 are unused. Thus pin 25 TDM_RAW and pins 26–28 individually unconnected PASS. Hardware mode makes SPI unused: pin 35/36/37 grounded and pin 38 tied to VDD_IO (3V3_ADC) match Table 1-2. The original mode question is resolved by actual resistor endpoint/value evidence.

New channel-map comparison: declared map id crow-carrier-channel-map-20260912; exact source SHA256 1640e8993f47658a46b2d1c90f9f8082c5a04c5339ca063b6a9efceeb1f41c23. ADR0027 SHA256 3f7fc0dcbda74d882172d5d0ae270cf515c8980326a9dba4269027895373311d explicitly defines ADCnP/N as logical pod n and fixes north pod-to-physical ADC order 4,3,2,1. Each expected pair below was compared to current native U_ADC pad nets, not inferred from the ADR:

| Logical pod | Physical ADC | P / N pins | Observed P / N nets | Declared default slot |
|---|---|---|---|---|
| 1 | 4 | 48 / 47 | ADC1P / ADC1N | 3 |
| 2 | 3 | 46 / 45 | ADC2P / ADC2N | 2 |
| 3 | 2 | 42 / 41 | ADC3P / ADC3N | 1 |
| 4 | 1 | 40 / 39 | ADC4P / ADC4N | 0 |
| 5 | 5 | 14 / 13 | ADC5P / ADC5N | 4 |
| 6 | 6 | 16 / 15 | ADC6P / ADC6N | 5 |
| 7 | 7 | 20 / 19 | ADC7P / ADC7N | 6 |
| 8 | 8 | 22 / 21 | ADC8P / ADC8N | 7 |

All 16 pad-net identities match, with P/N polarity preserved and no duplicate/missing logical pairs. Default serial order and intentional analog permutation are distinct. The declared slot-to-pod sequence is 4,3,2,1,5,6,7,8. This resolves the original channel-intent question. It does not establish measured physical TDM slots or USB enumeration: the declared eight-channel impulse test and map/cable/pod/survey/epoch capture metadata checks remain first-article work.

U_LDO — VERDICT: PASS (inherited, unchanged)

Primary LT3041 Rev. A SHA256 35dda1deb2ffc9e20545ebe2aefd2fbd690cf9b04e8772290fd4991a4b8ef584. Inherited actual images page 7 Figure 3 and page 36 Figure 98; supporting Table 3 pages 7–8, VIOC guidance page 27. Top-view pin 1 upper left, pins 1–7 down left and 8–14 up right, CCW. Figure 98 bottom view reflects horizontally then rotates clockwise 90 degrees to Figure 3. Front-mounted native footprint receives no mirror. 0.5-mm pitch, seven terminals per bank and EP15, native EP 1.7 x 3.3 mm. Fifteen numbered pads/physical identities plus eight anonymous paste-only features = 23 total native features. Corner N/S dossier labels are generic position labels; coordinates establish the correct two side banks. No aliases or collapse.

U_LDO pins 1–3 input 5V_LDO_HOLD; optional VIOC4 and PG6 individually unconnected; EN5 LDO_EN; ILIM7 GND; PGFB8 tied to IN; SET9 LDO_NR; grounds10/11/15 GND; OUTS12 and OUT13/14 3V3_ADC. All pin-net roles remain PASS; no new physical judgment or unprovided resistor/capacitor values are claimed. Physical Kelvin routing, output setting component values and implementation remain outside this pin-map scope.

R_CFG1 — VERDICT: PASS. Two distinct native pads, two physical terminal identities, no anonymous pads, no EP, no fused alias. RC0402FR-074K7L: 4.7 kohm, 1%, 0402/1005. Pad1 CFG1, pad2 GND.
R_CFG2 — VERDICT: PASS. Two distinct native pads, two physical terminal identities, no anonymous pads, no EP, no fused alias. RC0402FR-070RL: nominal zero ohms, 0402/1005. Pad1 CFG2, pad2 3V3_ADC.
R_CFG4 — VERDICT: PASS. Two distinct native pads, two physical terminal identities, no anonymous pads, no EP, no fused alias. RC0402FR-074K7L: 4.7 kohm, 1%, 0402/1005. Pad1 CFG4, pad2 3V3_ADC.
R_CFG5 — VERDICT: PASS. Two distinct native pads, two physical terminal identities, no anonymous pads, no EP, no fused alias. RC0402FR-07100KL: 100 kohm, 1%, 0402/1005. Pad1 CFG5, pad2 GND.

New actual primary images: page 1, unnumbered dimensioned isometric package figure plus exact product specification for each YAGEO PDF. The figure shows two equivalent opposite-end terminations and no polarity or pin-1 marker. There is no meaningful winding for these two collinear nonpolar terminals; native A/B and 1/2 are artifact labels, not manufacturer polarity claims. All four are front-mounted at native 180 degrees, with local pads at (-0.51,0) and (+0.51,0), 0.54 x 0.64 mm each. Their 1.02-mm center spacing straddles the 1.0 x 0.5-mm chip and supports both physical end terminals. Actual rotation explains native pin1 right of pin2. No mirror or missing physical terminal is hidden by same-net equivalence.

Primary PDF hashes: RC0402FR-074K7L b894ff1ce27e9567b396a6cb9c16750970e4145c03bf64367db0cc8ca107459f; RC0402FR-070RL 86e35763f809c9aa780f4e8ad0d3d6f71b57a3d3afdeb5f523837e5a29da9813; RC0402FR-07100KL e42aa2b39be7476fef25efbe4656acbbc246d2b9b625d64db6b46e0f5e34d7af.

Instance symmetry: U_ADC/U_LDO each occur once. All four resistor instances have identical two-terminal topology with configuration net at pad1; destination and resistance differences are required by the distinct primary configuration tables. Both 4.7-kohm instances are reviewed separately. LDO output and ADC supply share 3V3_ADC as before. Total scoped inventory: 72 numbered physical/pad identities, 17 anonymous paste features, 89 native pad features.

All envelope input sizes/hashes were verified before and after. Archive contains the inherited inspected figures and original report as provenance, new native dossiers and exact declared authority, new actual inspected figures, complete raw text and finite runtime logs, comparison method and measurements. Source PDFs remain digest-bound frozen inputs. No original output or live source was edited. The five-output handback is validated with the exact new envelope; delivery PASS is distinct from engineering and order verdicts.
