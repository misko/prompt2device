from pathlib import Path
import sys,json
R=Path("/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901");sys.path.insert(0,str(R/"skills/pcb-design/scripts"))
from pipeline_execution import TaskEnvelope,verify_input_packet,writer_scope_receipt
from pipeline_runtime import _tree_snapshot,_changed_paths,_snapshot_sha256
from pipeline_artifacts import validate_task_outputs
p=Path(sys.argv[1]);e=TaskEnvelope.from_json(p.read_text());a=json.loads((p.parent/"admission.json").read_text());root=Path(a["root"])
assert verify_input_packet(e,root)[0]
after=_tree_snapshot(root,ignored=frozenset(a["ignored"]))
scope=writer_scope_receipt(e.writer_scope,_changed_paths(a["before"],after),before_sha256=_snapshot_sha256(a["before"]),after_sha256=_snapshot_sha256(after),protected_paths=tuple(sorted((e.output_path,a["claim"]))))
assert scope["status"]=="PASS",scope
v=validate_task_outputs(p.parent/"outputs",e.completion["outputs"],subject=e.subject.to_mapping(),checks=e.completion["checks"])
print(json.dumps({"writer_scope":scope,"delivery":v}))
