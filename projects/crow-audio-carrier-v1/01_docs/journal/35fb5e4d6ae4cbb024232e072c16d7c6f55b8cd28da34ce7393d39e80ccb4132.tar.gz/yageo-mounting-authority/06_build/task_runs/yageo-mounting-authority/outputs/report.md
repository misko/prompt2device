# Yageo RT0603 mounting-authority review

## Verdict

**PASS — the present copper is defensible for `RT0603BRD0730K9L`; the primary Yageo mounting authority does not establish a defect or require a footprint change.** It is not an exact copy of Yageo's recommended nominal reflow geometry, so an exact-manufacturer-pattern policy would call for the optional normalization below.

This judgment is limited to land-pattern applicability and geometry. It is not fabrication, order, stock, assembly-process, or sourcing acceptance.

## Primary authority and applicability chain

1. The supplied direct-manufacturer RT V.17 datasheet (`Yageo_RT_v17_20260212.pdf`, 547,014 bytes, SHA-256 `00a9148c2958122200e8a93292e389392a795adcfe40562d6ca4f690d1e5d7d1`) identifies the RT ordering-code grammar on page 2. `RT0603BRD0730K9L` decodes as RT series, 0603 size, B = ±0.1%, R = paper/PE reel, D = 25 ppm/°C, 07 = 7-inch reel, 30K9 = 30.9 kΩ, L = default order code.
2. RT V.17 page 6 explicitly says: “For recommended footprint and soldering profiles, please see the special data sheet ‘Chip resistors mounting’.”
3. The referenced Yageo document was retrieved from the primary manufacturer URL: `https://yageogroup.com/content/Resource%20Library/Product%20Guide-Catalog/yageo_PYu-R_Mount_10_19050818_343.pdf`. Retrieval completed 2026-09-11 19:45:41 UTC. The response was HTTP 200, `application/pdf`, 787,817 bytes, Last-Modified 2024-11-08 14:38:49 GMT. Download SHA-256 is `591634ace247f61e9c6a263ca1ac98d7672fc163f5e87334c3460956f5c68b7b`.
4. The same 787,817 bytes and SHA-256 were independently retrieved from a manufacturer-authored distributor mirror at `https://sigma.octopart.com/138820526/technical_drawing/Yageo-AT0603FRE074K7L.pdf`. Its content is visibly YAGEO/Phycomp branded, titled `Chip Resistor Surface Mount — Mounting`, dated February 13, 2018 V.10, and carries `www.yageo.com` on every inspected page. The byte-for-byte match confirms mirror provenance; the direct Yageo URL is the authority used for judgment.
5. Mounting V.10 page 4 labels Fig. 4 as the recommended footprint for **single resistor chips** and Table 1 as reflow dimensions for relevant chip-resistor sizes. Its unqualified 0603 row therefore applies to the RT0603 singled out by the current RT V.17 forward reference. No PA/PE-family land pattern was substituted.

## Applicable 0603 row

For reflow soldering, Fig. 4 defines `A` as the total outer land span, `B` as the inner gap, `C` as each land's X dimension, and `D` as the land's Y dimension. The 0603 row gives:

| Dimension | Yageo recommendation |
|---|---:|
| A, outer span | 2.60 mm |
| B, inner gap | 0.80 mm |
| C, each land X | 0.90 mm |
| D, each land Y | 0.80 mm |
| Placement accuracy | ±0.25 mm |

The separate wave-soldering row is A=2.70, B=0.90, C=0.90, D=0.80 mm. Reflow is the applicable comparison for the native SMD footprint review; the wave row is recorded only to avoid silently mixing process recommendations.

## Geometry reconciliation

The supplied native geometry has two ROUNDRECT pads at X = −0.825 and +0.825 mm, each 0.80 × 0.95 mm with 0.15 mm corner radius. This derives to pitch 1.65 mm, A=2.45 mm, B=0.85 mm, C=0.80 mm, D=0.95 mm. Against Yageo reflow nominal values, current-minus-recommended deltas are A −0.15, B +0.05, C −0.10, and D +0.15 mm.

Those differences do not by themselves prove a mounting defect. Yageo labels one recommended nominal pattern and supplies no allowable land-dimension band. The current land bounding-box area is 0.760 mm² per pad versus 0.720 mm² for Yageo's rectangular nominal (+5.6%). Accounting for the stated 0.15 mm roundrect corners gives about 0.7407 mm² (+2.9%). At the nominal 1.60 mm body length, X overlap is 0.375 mm per side versus 0.400 mm for the Yageo pattern, a 0.025 mm difference per side. The current footprint trades 0.10 mm less X land length for 0.15 mm more Y width while retaining nearly the same copper area and nominal body overlap. Yageo's ±0.25 mm entry is placement accuracy, not a pad-size tolerance, and is not used as such.

RT V.17 page 4 specifies body and termination tolerances (RT0603 L=1.60±0.10, W=0.80±0.10, H=0.45±0.10, I1=0.25±0.15, I2=0.25±0.15 mm). These are component-outline facts, not an assembly-land acceptance rule; full metallization coverage was not assumed.

The current 2.96 × 1.46 mm courtyard leaves about 0.255 mm clearance from the current copper bounding box on each side. Its fab outline is 1.60 × 0.825 mm. Neither changes the copper conclusion.

## Optional exact normalization

If the project elects an exact Yageo-reflow nominal rather than accepting the present compatible standard footprint, use exactly two pads with pin 1 on the left and pin 2 on the right, centers X = −0.850 and +0.850 mm, Y = 0, pad size 0.90 × 0.80 mm. ROUNDRECT may retain the present 0.15 mm corner radius because Fig. 4 specifies extents, not corner shape. Keep the 1.60 × 0.825 mm fab outline. With the same nominal 0.25 mm courtyard-to-copper clearance, change the courtyard envelope to 3.10 × 1.30 mm. This is an optional conformance normalization, not a correction compelled by the cited source.

## Visual inspection

The review visually inspected rendered RT V.17 pages 2, 4, and 6 and Mounting V.10 page 4. Page 2 confirms ordering-code fields and 0603 inclusion; page 4 confirms RT0603 body/termination dimensions; page 6 visibly contains the exact forward reference; Mounting page 4 visibly confirms Fig. 4 axis meanings and both 0603 reflow and wave rows. Rendered PNGs and lossless PDF-process logs are included in the evidence archive.

