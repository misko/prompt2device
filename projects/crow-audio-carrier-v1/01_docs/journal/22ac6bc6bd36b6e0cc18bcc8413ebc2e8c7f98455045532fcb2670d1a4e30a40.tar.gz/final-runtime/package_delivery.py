from pathlib import Path,PurePosixPath
import json,hashlib,shutil,difflib,tarfile,io,ast,datetime
s=Path(__file__).resolve().parent;run=s.parent;p=run.parents[2];out=run/'outputs';out.mkdir(exist_ok=True)
e=json.loads((run/'envelope.json').read_text());subject=e['subject'];prefix='projects/crow-audio-carrier-v1/'
files=['03_src/rules/stackup.yaml','03_src/tests/test_route_source_contract.py']
def sha(b):return hashlib.sha256(b).hexdigest()
def write(path,v):path.write_text(json.dumps(v,indent=2)+'\n')
packet=[];work=[]
for item in e['input_packet']:
 b=(p/item['path']).read_bytes();row=dict(path=item['path'],sha256=sha(b),size=len(b),ok=sha(b)==item['sha256'] and len(b)==item['size']);packet.append(row)
 rel=item['path'];target=None
 if rel.startswith('project/'):target=s/'work'/prefix/rel[len('project/'):]
 if rel.startswith('shared/'):target=s/'work'/rel[len('shared/'):]
 if target:work.append(dict(path=rel,unchanged=target.read_bytes()==b))
assert all(x['ok'] for x in packet)
changed=sorted(x['path'] for x in work if not x['unchanged']);assert changed==sorted('project/'+f for f in files)
write(s/'inputs-after.json',packet);write(s/'source-invariance.json',dict(input_count=len(packet),all_frozen_inputs_unchanged=True,work_comparison_count=len(work),changed=changed,other_work_inputs_unchanged=sum(x['unchanged'] for x in work),details=work))
manifest=[];diff=''
for rel in files:
 before=(p/'project'/rel).read_bytes();after=(s/'work'/prefix/rel).read_bytes()
 for side,data in [('before',before),('after',after)]:
  dest=s/side/prefix/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 manifest.append(dict(path=prefix+rel,before_sha256=sha(before),before_size=len(before),after_sha256=sha(after),after_size=len(after)))
 diff+=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+prefix+rel,tofile='b/'+prefix+rel))
write(s/'proposal-manifest.json',dict(file_count=2,files=manifest,adoption='NONE',domain_verdict='INCOMPLETE'));(s/'minimal.diff').write_text(diff)
original=ast.parse((p/'project/03_src/tests/test_route_source_contract.py').read_text());proposed=ast.parse((s/'work'/prefix/'03_src/tests/test_route_source_contract.py').read_text())
def tests(tree):return {n.name for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
assert tests(original)<=tests(proposed)
write(s/'test-method-invariance.json',dict(original=sorted(tests(original)),proposed=sorted(tests(proposed)),removed=[],added=sorted(tests(proposed)-tests(original))))
analysis=json.loads((s/'source-analysis.json').read_text());methods=[]
for name,argv in [
 ('baseline',['/usr/bin/python3','-B','-m','unittest','discover','-s','03_src/tests','-p','test_route_source_contract.py','-v']),
 ('new-test-red',['/usr/bin/python3','-B','-m','unittest','test_route_source_contract.RouteSourceContractTests.test_chassis_shadow_matches_exact_outer_layer_shell_owner','-v']),
 ('proposed-full-normal',['/usr/bin/python3','-B','-m','unittest','discover','-s','03_src/tests','-p','test_route_source_contract.py','-v']),
 ('source-analysis',['/usr/bin/python3','-B',str(s/'analyze_source.py')]),
 ('new-test-green',['/usr/bin/python3','-B','-m','unittest','test_route_source_contract.RouteSourceContractTests.test_chassis_shadow_matches_exact_outer_layer_shell_owner','-v'])]:
 methods.append(dict(id=name,argv=argv,cwd=str(s/'work'/prefix),runtime=json.loads((s/(name+'.runtime.json')).read_text()),raw_log=name+'.raw.log',representation=('both exact frozen source files' if name=='baseline' else 'new test with exact frozen shadow' if name=='new-test-red' else 'exact proposed two-file postimages')))
write(s/'methods.json',methods)
findings=[dict(id='CARRIER-ROUTE-SOURCE-BASELINE-001',status='PARTIALLY_CORRECTED',detail='Missing CHASSIS_SHIELD shadow class and stale source censuses corrected in exact two-file scratch proposal; no independent acceptance or live adoption.'),dict(id='CARRIER-ROUTE-SOURCE-BASELINE-001-VMID1-EXTENT',status='OPEN',severity='BLOCKING_SOURCE_OBLIGATION',pin='C_VMID1_470N.2',net='GND',spec_index=1,width_mm=.18,class_floor_mm=.30,scope='ADC_WEST_LOCAL',rect=[89.5,67.7,93.6,72.35],failed_points=[[89.45,68.7],[89.45,69.17]],capsule_x_min_mm=89.36,outside_extent_mm=.14,uncovered_primitives=analysis['primitives'][:2],required_dependency='Independent review of accepted bank1 GND route geometry or a justified explicit width scope in route.yaml/floorplan.yaml/rules/nets.yaml. All such edits prohibited in this handoff.',native_drc_claim=False)]
evidence=dict(verdict='INCOMPLETE',subject=subject,envelope_canonical_sha256='0bee3cc03b09774dd37bd7880f4ee700351c81efccce1fa49bb99fb620873602',input_count=382,methods=methods,findings=findings,measured_counts=analysis['counts'],tests=dict(baseline=dict(methods=19,passed=13,failed_methods=6),new_test_red=dict(methods=1,failed=1),new_test_green=dict(methods=1,passed=1),proposed_full_normal=dict(methods=20,passed=19,failed_methods=1,failed_subtests=2,status='FAIL')),proposal=manifest,source_invariance='All 382 frozen inputs unchanged; exactly two copied project files differ; no live writes or board operations.',engineering_acceptance=False)
write(out/'evidence.json',evidence)
report='''# INCOMPLETE — exact two-file baseline route-contract proposal

CARRIER-ROUTE-SOURCE-BASELINE-001 is partly corrected. The shadow class and census defects are repaired in scratch. A real bank1 GND capsule-scope defect remains; the proposed full normal suite is **FAIL**, not GREEN. No live adoption or independent acceptance is claimed.

The proposal modifies only `projects/crow-audio-carrier-v1/03_src/rules/stackup.yaml` and `projects/crow-audio-carrier-v1/03_src/tests/test_route_source_contract.py`. Exact preimages/postimages and SHA-256 values are in `before/`, `after/`, and `proposal-manifest.json` inside the archive; `minimal.diff` is the complete patch.

## Repairs and authority

The accepted route class_layers already limits CHASSIS_SHIELD to F.Cu/B.Cu. nets.yaml defines CHASSIS shell continuity isolated from signal GND, a0.60mm width and0.25mm clearance, without a DC load rating. The proposal adds that missing shadow class with empty declared references and reference_required:false. It changes no copper stack, pre-existing class, reference, width, current or fabrication floor. board_authority.resolve_routing_classes infers adjacent-role GND-plane metadata even when references is empty; that metadata is neither a DC bond nor inner-plane routing permission. The new test checks exact16 shell lands J1..J8 pins9/10, class/wave identity, outer layers, metadata and floors. It rejects missing class and inner reference-plane routing. The original double-owner and damaged-reference-plane controls remain.

Measured source inventory is333 refs/985 pins/221 native nets,42 explicit NC names and178 non-GND functional nets. The connected class census gains exactly CHASSIS_SHIELD:1; generic exact wave membership gains CHASSIS for173 members. Existing net-to-class and net-to-wave bijections and owner-consumer checks remain intact. The seed count154 reconciles105 existing banks plus eight five-bank RJ45 cells, eight fuse exits and the separate C_VDDA1_10N.2 return. Added checks require all49 exact overlay pin identities, unique banks and source pin/net identity for all154 banks. Via specifications total20:15 exact bank overrides plus five defaults/common specs; these are not the43 instantiated seed vias. The new override identity check includes the separately accepted bypass return. Full membership and owner data are in source-analysis.json.

## Residual source obligation

Both old hidden assertions are in **C_VMID1_470N.2**, net GND, segment specification1, width0.18mm. The points are[89.45,68.7] and[89.45,69.17]. The first primitive is the vertical[89.45,68.7]→[89.45,69.17] of length0.47mm; the second is[89.45,69.17]→[91.2,69.17] of length1.75mm. Their full-radius copper reaches x89.36. ADC_WEST_LOCAL begins at x89.5, so the capsules exceed its west edge by0.14mm. GND's ordinary class width floor remains0.30mm. Subtests now report both failures without deleting or weakening the original capsule predicate, reducing radius or skipping either endpoint.

Every GND scoped floor was inspected. The0.18mm-eligible set is ADC_WEST_LOCAL, ADC_EAST_SUPPLY_LOCAL, ADC_FILT_NORTH_LOCAL, ADC_FILT_SOUTH_LOCAL and ADC_CFG3_GND_LOCAL. None fully covers either offending primitive. LT3041_GROUND_NECKS requires0.20mm and is ineligible for this0.18mm branch. ADC_FEED_NORTH/SOUTH authorize only3V3_ADC, not GND; their supply permissions cannot be borrowed. The VMID return pour/via reservations are not width permissions. All exact rule/net/width/rectangle data are retained in source-analysis.json. ADR0030 explicitly accepts the changed north return column; ADR0015's retained full-capsule scope obligation still needs reconciliation with that physical authority. The source helper test_adc_source.extent_errors checks CELL_PINS that exclude this VMID capacitor return, so its accepted ADC supply checks do not establish coverage for this branch.

The actual generate_rules_generic.py width emitter constructs A.insideArea(zone) and an exact net clause. Its own documented KiCad semantics treat insideArea as overlap, not whole-shape containment. The vertical capsule overlaps the old rectangle by0.04mm even though its centerline lies outside; the horizontal primitive also overlaps. Therefore this report claims a failure of the stronger authored full-capsule obligation, **not a native DRC failure**. No board was loaded to evaluate native DRC. The diagnostic preserves the exact emitter lines and hash and exercises three independent source-predicate controls: fully contained capsule accepted, inside centerline with escaped radius rejected, and an escaped endpoint rejected.

## Normal tests and limits

- Exact original normal suite:19 methods,13 PASS/6 failing methods,7.151s runtime. Its first failures are stale class, wave, seed, owned-net, source-net and via censuses/shadow class. The packet's all-body observer retains10 assertions as DIAGNOSTIC ONLY and is never substituted for this FAIL.
- New CHASSIS test against exact frozen old stackup:1/1 RED,1.564s, missing CHASSIS_SHIELD.
- Exact proposed full normal suite:20 methods,19 PASS/1 failing method with2 failed subtests,7.409s. Every original19 method remains; all original hostile controls remain. Capsule failures remain visible and later length/power-limit assertions execute.
- Focused new CHASSIS test on exact proposal:1/1 GREEN,1.055s.
- Source scope/census diagnostic:PASS as a diagnostic execution,1.114s; it records the unresolved source defect rather than declaring geometry accepted.

No shared helper changed, so related ADC source suites were not broadened. Existing power2.5A bound,1.20mm bulk wave,54.294731mm/44 item ceiling, paired via/annulus/fabrication floors, return geometry and all physical regions remain exact. No board construction/load/save/generation/fill/DRC/prep/native candidate or pending ADC2 file edit occurred. All382 frozen envelope inputs were verified before and after. Copied project/shared input comparison permits exactly the two proposal files; all others remain byte-identical.

A separate authorized review must reconcile the bank1 return geometry or justified explicit width authority before a complete source GREEN can exist. This handoff does not propose such a change. Root retains sole live writer; cumulative native4/4 is closed. Delivery checks concern complete honest handback, not engineering acceptance.
'''
(out/'report.md').write_text(report)
write(out/'result.json',dict(subject=subject,checks={k:'PASS' for k in e['completion']['checks']},unresolved=[]))
# Archive only explicit regular evidence; never the archive or its own manifest.
entries={}
for path in s.iterdir():
 if path.is_file() and path.suffix in {'.py','.json','.log','.diff'}:entries[path.name]=path
for side in ['before','after']:
 for path in (s/side).rglob('*'):
  if path.is_file():entries[path.relative_to(s).as_posix()]=path
for rel in ['TASK.md','diagnostics/census_route_contract_assertions.json','diagnostics/census_route_contract_assertions.py','project/01_docs/decisions/0015-adc-supply-feeds.md','project/01_docs/decisions/0030-proposed-top-side-rj45-protection-geometry.md']:
 entries['packet/'+rel]=p/rel
entries['packet/envelope.json']=run/'envelope.json'
entries['report.md']=out/'report.md';entries['evidence.json']=out/'evidence.json'
archive=out/'evidence.tar.gz';members=[]
with tarfile.open(archive,'w:gz') as tf:
 for name,path in sorted(entries.items()):
  assert not path.is_symlink();b=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(b));members.append(dict(path=name,size=len(b),sha256=sha(b)))
with tarfile.open(archive,'r:gz') as tf:
 got=tf.getmembers();assert len(got)==len(members);seen=set()
 for member,expected in zip(got,members):
  assert member.isfile() and not member.issym() and member.name not in seen;seen.add(member.name)
  name=PurePosixPath(member.name);assert not name.is_absolute() and '..' not in name.parts and not member.name.endswith(('.tar','.tar.gz'))
  b=tf.extractfile(member).read();assert dict(path=member.name,size=len(b),sha256=sha(b))==expected
write(out/'evidence-manifest.json',dict(archive_sha256=sha(archive.read_bytes()),archive_size=archive.stat().st_size,member_count=len(members),members=members))
print(json.dumps(dict(verdict='INCOMPLETE',proposal_files=manifest,archive_sha256=sha(archive.read_bytes()),member_count=len(members),inputs=len(packet),changed=changed)))
