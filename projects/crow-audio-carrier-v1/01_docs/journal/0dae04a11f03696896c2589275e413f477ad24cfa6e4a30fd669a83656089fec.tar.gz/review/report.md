# Exact combined source integrity: SOUND

The exact13-file candidate2 is **SOURCE SOUND**. F-STARTUP-SIDE is resolved, and no unresolved source defect or coverage gap remains in the commissioned scope. This verdict covers all13 postimages below, with no subset adoption. Root may proceed to exact source adoption and full-checkout qualification, then normal current checkpoint/downstream renewal. No source was adopted during review. **FIRST-ARTICLE-ONLY / DO-NOT-ORDER.**

Subject raw `5a4a866e5b882fe5c83b3f910e839436de9e80b558cef94959a5c459d0ead078`; semantic `174f8e0affcf70e2c32f63861bb8b19ec06ed7aa66f178b8923dcad0a1211a25`. Canonical envelope SHA `e1fe362e3933f74d25fed26bca6725731571790551723f8fd9e5cd90bb9d378c`.

## Fresh independent reproduction

My separately authored `methods/independent-startup.js` executes the exact shipped script in a fresh DOM for each of11 URL cases. The candidate1 control is its actual archived carrier export, verified against the exact previously reviewed candidate1 template and unchanged generated data; no arbitrary source variant was constructed. Candidate2 uses the fresh exporter output from this review.

Candidate1 is RED:6valid/default/encoded cases pass, while unknown startup displays333components and four malformed escape cases throw URIError. Candidate2 is GREEN11/11: default and empty select C_AUDIO_CT2 with317top references; R_PWR_TOP and encoded equivalent show317top; U_ESD1 and encoded equivalent show16bottom. Nonexistent and malformed inputs show0component groups with an explicit no-selection convention, no selected identity/pads/crosshair/hash, and an error message. Each case then recovers through the actual search event handler, exercises top→bottom→top side controls and unknown-after-valid clearing. Exact visible-reference sets, selected identity, pad count and projected crosshair coordinates are graded, not only totals.

Six new actual Firefox processes with separate profiles generated screenshots that I opened and inspected. Candidate1 unknown shows the mixed population underTop. Candidate2 default/top/bottom show the correct population, readable conventions, native values and red target; unknown and malformed show the empty board with readable no-selection instruction and error. Static geometry is therefore truthful or explicitly unselected after startup. Browser warnings are retained and do not conceal the successful screenshot return codes. These source-review views do not replace the normal owning usability acceptance.

The maintained suite passes32/32, including its new native fresh-DOM regression and preserved old controls. Public CLI suite passes3/3 with2known-bad controls. Pin suite passes11/11 with8known-bad controls. Maintained control on the actual carrier passes333/333selected references plus8fresh-start cases. The top-only fixture retains empty-bottom behavior. All25original locator tests and all8original pin tests are AST-identical; all31candidate1 locator methods and11pin methods remain AST-identical. The JavaScript diff preserves its old all-reference/side/crosshair/unknown assertions and adds independent boots.

## Exact-source and native evidence binding

All1071frozen inputs verify before and after. All4492members of prior independent archive SHA `1076d51dbd72d795c8202faf527f32d6f4b12d5697b699025ad2ea75eb3d7d3e` and all241members of repair-author archive SHA `e6bd91ec7ab47e4b4a18360153f230e96285c0b154e801cb22b5e6b94f737ab0` were reopened and checked against their complete manifests. The1046-file source census proves exact original/native/primary/test identity against the prior independent archive and exactly13candidate2 postimages. Candidate1→2 changes only HTML initialization, maintained JavaScript test, one new native unittest, and appended README test description. All other9postimages, including3pin files, are unchanged.

The fresh actual exporter and a separate public exact CLI pass333/333references,1043pads,25/25exceptions/pages and28manifest members. Independent native census measures340footprints including7board-only references,317top+16bottom locator references,51BOM lines/300BOM references,300CPL rows284top+16bottom, and all33off-BOM references retained. Source exceptions, native omissions, P-SILK-REF waiver refs and page membership are the same25top references. Board SHA remains `d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de`. Fresh locator manifest SHA is `f7e14ce77768fceac05bb7b94b81345e3566fa3117acc70beb2b14457c168cfb`. This is an actual deterministic re-export, not a restamped prior bundle.

Fresh JSON, BOM, CPL and all25PNG pages are byte-identical to the prior independent export, and the entire SVG geometry is identical. The prior measured native mirrored bottom plot therefore remains applicable:56/56bottom pad envelopes across16components agree within one native nm; all56unmirrored comparisons reject, nearest wrong error1.63mm. Prior actual refreshed-hash hostile artifacts reject wrong side U_ESD1 and unmirrored HTML body geometry. These numbers are explicitly **inherited from verified immediately prior independent evidence**, not freshly rerun. Relevant exact members are `methods/native_locator_review.py`, `independent-locator-census.json`, `raw/native-locator-review-v2.log`, its runtime, and `raw/native-bottom-plot.runtime.json`, bound in `provenance.json` and the fully reopened archive manifest.

The pin3files and all primary/native inputs are identical to the independently measured campaign. I inspected its method, actual raw successful runtime, snapshots, extraction and matrix. Native physical unmount/zero-rotation comparison covers384footprints/1163pads, including17back mounts, with exact actual-board agreement. The independent irregular-pentagon matrix covers64instances/320pads and32physical mirrors; those32remain wrong winding. Snapshot equality preserves native pad numbers/nets/positions/rotations/layer sets/sizes/drills. Source inspection confirms local y-reflection depends only on native IsFlipped(), never expected winding, pin labels or functions. No footprint/pin/net change is proposed.

I freshly rendered and inspected digest-selected TI SLLSEG9C page3, SHA `a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed`. The DRL5-pin Top View has1/2/3down the left and4/5up the right: CCW. The bound prior native U3 extraction and generated dossier put pin1(-0.712500,-0.500000),3(-0.712500,+0.500000),4(+0.712500,+0.500000), with actual back mount at180degrees. Separate NC1/NC2 identities survive;3AUDIO_P,4GND,5AUDIO_N agree with the declared physical functions. The old dossier's CW was a frame-reporting defect. The explicit component-top/native-board distinction and no-extra-mirror protocol match the implementation. This comparison does not assert broader electrical acceptance.

## Contracts, boundaries and instrumentation

I read the source changes and their governing assembly/pin protocols, scripts contract, source/release templates and combined README. They consistently retain mixed-side native context, mounted Fab/silk ownership, readable native coordinates, bottom X reflection and top-only1–4pad exceptions. The independent checker imports no renderer; source/waiver/CSV identities, exact tool/artifact binding, PDF/PNG membership and consuming review gates remain. Startup initialization changes no schema, native geometry or tolerance. The new README accurately describes actual regression behavior; prior pin and locator test descriptions remain intact.

Prior frozen-corpus contract results remain explicit inherited limitations: baseline/candidate12pass5fail, same1C-ALLOW walk finding, and skill-contract sync passing. No full-checkout PASS is claimed. Root owes authority/docs/contracts checks on the full checkout after source acceptance. No source defect is waived by the partial corpus.

Initial instrumentation is preserved honestly. A console-tail setting exceeded the line limit, so the first campaign wrapper failed before tests; the corrected wrapper completed. First suites omitted TMPDIR and used system /tmp for disposable fixtures, a procedural deviation from allocated scratch. I reran the suites with explicit allocated TMPDIR; those final scoped runs also pass and their fixture artifacts/raw child runtimes are retained. Native unittest TemporaryDirectory cleanup removed its transient fixtures normally; no source postimage changed. All engineering subprocess launches used finite shared run_stage with explicit argv/cwd/environment; browser and native warnings remain lossless in raw logs. Packaging/preflight logs remain beside the archive because they cannot recursively include themselves.

The archive contains new methods/raw/runtime/screenshots and actual exports, plus the necessary exact original failure HTML/template. It does not duplicate the424MBprior archive, unchanged primary PDFs or full frozen source trees. Their digests and exact relevant members are retained as provenance. Browser profiles and gerber ZIPs are disposable exclusions. Source integrity is not placement, pin electrical, route, release/order, physical fit, environmental, or first-article assembly acceptance.

## Exact reviewed postimages

| Source | Candidate2 SHA-256 |
|---|---|
| `skills/jlcpcb-fab/references/assembly-and-order.md` | `7269640a9a81edb68d483257892e7b07d8414a64b4cb92b517419a2ecce8057c` |
| `skills/jlcpcb-fab/scripts/assembly_locator.html` | `02ebb7283ce6786faa989dcf0c6550808e11f7812e81eeedd687691cfbc6adee` |
| `skills/jlcpcb-fab/scripts/assembly_locator.py` | `f7967323698925edc1833223723ee24cf8a984a37365b03658d32a817b63cc6e` |
| `skills/jlcpcb-fab/scripts/assembly_locator_check.py` | `d93ae9bfd47912f8a871126d8a35afaf6e2af5b80ffdfffb274ce7145a1b0c5e` |
| `skills/jlcpcb-fab/scripts/contracts.md` | `dc49a87bc11640aeefcd723f0b6b0c279674849a42b9ea6367492f7a66784b16` |
| `skills/jlcpcb-fab/scripts/tests/locator_ui_control.js` | `a1cb150d752e5fb2bf852065114e430b55bd2362c5c9558582a17a9999c01248` |
| `skills/jlcpcb-fab/scripts/tests/test_assembly_locator.py` | `468dee7433219ec900af400305c861389e33de20f3cfada60480a238b0e8fd82` |
| `skills/pcb-design/templates/contracts/03_src/rules/contracts.md` | `0ad0773908d44a1a260b379f73e732aba43e6cead63f4017d566c1ead39b9d4b` |
| `skills/pcb-design/templates/contracts/07_releases/contracts.md` | `5599f4ce88bade893c08c6b881601b51d5d4916451243edd29d9577beb18769b` |
| `tests/README.md` | `69fecc94a47a24011b866dda2f9a3e28116f4a2b4baaa09e02e78f3505c92bb5` |
| `skills/kicad-pcb/scripts/pin_audit.py` | `af0520dc3e4e77da123c4627174df57ae54230c0b96d2e712965080b56995cd7` |
| `tests/t1_pin_audit.py` | `941ede5a42b36a680a2ea2ffcce8658f079ec8759937c63aed2f377db731aac9` |
| `skills/kicad-pcb/references/pin-review-protocol.md` | `d3155c46b0a1e67f7fd121f164e6285cd9d59c133b1cdff5d72dcc4bd6da33c5` |

Delivery checks PASS mean complete honest handback, not downstream engineering acceptance. Unresolved source findings: none.
