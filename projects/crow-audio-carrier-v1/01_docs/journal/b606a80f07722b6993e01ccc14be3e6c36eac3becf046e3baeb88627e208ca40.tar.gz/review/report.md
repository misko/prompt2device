review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_clock_reset_mountedframe1 (actual fresh agent)
context: FRESH
design_verdict: INCOMPLETE
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7
raw_sha256: 47fabbbe2be37cf731bb0d35722ea44927020eaeca0471bf6e3f1f88e70e6820
semantic_sha256: d43e737695c86bd2850abd52fc7e0a30628ec85c28092ca217d62332819f0b32

Coverage is limited to U_CLK, U_RST1 and U_RST2, all three commissioned instances. This is not whole-board acceptance. No schematic, live source, earlier review or author rationale was used for engineering judgment. Native dossiers were read after independent figure observations were saved. Dossier verification-note assertions were not accepted as evidence.

U_CLK VERDICT: PASS
Primary: TI SN74LVC3G34 SCES366L, SHA-256 d541afbccf6270522f5ba33b86ca31da0ec6bbf497c0d1f8ba265e9ac2e1faec. Actual inspected figures: PDF p.3, DCU 8-pin VSSOP Top View and Pin Functions; PDF p.19, DCU0008A package outline.
Expected 8 separate leads, 4 per side, pin 1 upper-left, left 1..4 down and right 5..8 up, CCW, no EP or fused pins. Observed 8 native pad rows and 8 distinct physical identities, 0 duplicates, 0 EP and 0 aliases. Component-top coordinates show the same corner/order, x +/-1.4 mm, y -0.75/-0.25/+0.25/+0.75 mm, 0.5 mm pitch; signed numeric polygon area -4.2 mm2 confirms CCW with +y down. Front mounting at rotation 0 needs translation only; native-to-local error is 0 mm.

| Pin (datasheet function) | Expected net kind | Observed net and result |
|---|---|---|
| 1 (1A) | buffer input 1 | MCH_MCLK, PASS |
| 2 (3Y) | buffer output 3 | FSYNC_BUF, PASS |
| 3 (2A) | buffer input 2 | MCH_BCLK, PASS |
| 4 (GND) | ground | GND, PASS |
| 5 (2Y) | buffer output 2 | BCLK_BUF, PASS |
| 6 (3A) | buffer input 3 | MCH_FSYNC, PASS |
| 7 (1Y) | buffer output 1 | MCLK_BUF, PASS |
| 8 (VCC) | positive supply | 3V3_ADC, PASS |

The three channels preserve input/output symmetry: 1->7 MCLK, 3->5 BCLK, 6->2 FSYNC. All declared functions match the independent primary pin table.

U_RST1 VERDICT: PASS
Primary: TI TPS3839 SBVS193D, SHA-256 5f9a9581d1b8df7f0b2a480a71dac6993c9aba3b05767ad22641d151434f5dd3. Actual inspected figures: PDF p.5, TPS3839 DBZ SOT23-3 Top View and Pin Functions; PDF p.28, DBZ0003A package outline.
Expected 3 separate leads: 1 upper-left, 2 lower-left, 3 centered right, CCW, no EP or aliases. Observed 3 native pad rows and 3 distinct physical identities, 0 duplicates, 0 EP, 0 aliases. Positions (-0.9375,-0.95),(-0.9375,+0.95),(+0.9375,0) mm match directly, with 1.9 mm spacing of pins 1 and 2; polygon area -1.78125 mm2 is CCW. The dossier side labels N/S/E reflect the slightly larger |y| of pins 1/2, not a numbering mismatch: actual positions put both on the left. Front mount at rotation 0; native-to-local error 0 mm.

| Pin (datasheet function) | Expected net kind | Observed net and result |
|---|---|---|
| 1 (GND) | ground | GND, PASS |
| 2 (active-low push-pull RESET) | active-low reset output | POR_N, PASS |
| 3 (VDD) | monitored positive supply | 3V3_ADC, PASS |

U_RST2 VERDICT: QUESTION
Primary: TI SN74LVC1G123 SCES586E, SHA-256 7248ef0ff62af4d2da172bb2900f0f1f136a6ae90109a6485228e01269fa1c1d. Actual inspected figures: PDF p.3 Figure 4-1 DCT Package 8-Pin SSOP Top View and Table 4-1; PDF p.23 DCT0008A package outline; PDF p.13 Table 7-1 Function Table; PDF p.14 Figure 8-1 Typical Application. PDF p.1 description supplies the mandatory external timing connections.
Expected 8 separate leads, 4 per side, pin 1 upper-left, left 1..4 down and right 5..8 up, CCW, no EP or fused pins. Observed 8 native pad rows and 8 distinct physical identities, 0 duplicates, 0 EP and 0 aliases. Component-top x +/-1.7 mm and y -0.975/-0.325/+0.325/+0.975 mm give the expected 0.65 mm pitch and ordering; signed numeric polygon area -6.63 mm2 is CCW. Front mount at rotation 0; native-to-local error 0 mm. Package identity/numbering PASS; no mirrored numbering was found.

| Pin (datasheet function) | Expected net kind/behavior | Observed net and result |
|---|---|---|
| 1 (A, falling-edge trigger) | may be held low for CLR rising trigger | GND, PASS |
| 2 (B, rising-edge trigger) | may be held high for CLR rising trigger | 3V3_ADC, PASS |
| 3 (active-low CLR) | reset/clear input, rising edge triggers when A=L/B=H | POR_N, PASS |
| 4 (GND) | ground | GND, PASS |
| 5 (Q) | positive pulse output | RESET_PULSE_H, PASS |
| 6 (Cext) | external capacitor only, other capacitor end at pin 7 | RESET_C name only; topology QUESTION |
| 7 (Rext/Cext) | capacitor to pin 6 and resistor to VCC | RESET_RC name only; topology QUESTION |
| 8 (VCC) | positive supply | 3V3_ADC, PASS |

U_RST1 pin 2 drives the same POR_N net that reaches U_RST2 pin 3. Both ICs use the same 3V3_ADC/GND domain. The primary function table explicitly supports this rising-CLR trigger arrangement with A low and B high; an output inversion is not indicated. There are no duplicate device instances in the supplied group, so same-part inter-instance symmetry is not applicable; all three U_CLK channels and the inter-device reset polarity were checked.

Finding Q1 — U_RST2 pins 6 (Cext) and 7 (Rext/Cext): the primary datasheet requires a timing capacitor between pins 6 and 7 and a resistor between pin 7 and VCC, with pin 6 connected only to the external capacitor. The dossier supplies RESET_C and RESET_RC names but no net membership or passive endpoints. Supply the native membership of these two nets, showing the capacitor 6-to-7 and resistor 7-to-3V3_ADC and any other pin-6 attachments. Names alone cannot establish this topology.

No definite electrical pin assignment or package winding defect was found. One missing connectivity fact prevents SOUND. This pin review does not establish timing value, signal-integrity, full land-pattern manufacture, routing or release acceptance. All 19 native pads/19 identities were inspected; no EP/NC/fused identities exist in these selected packages. Manufacturer DCU/DCT/DBZ top views were compared to the mounted component-top frame without mirroring; unrelated bottom-view YZP figures and DQN EPs were excluded.

Evidence: evidence.json holds exact subject, measured counts and findings. evidence.tar.gz retains the actual inspected PNGs, native dossiers, protocol, independent observations, measurement method, raw tool logs and completed runtime records. PDF SHA records bind the still-present frozen primary inputs; complete PDFs are not duplicated. Archive members were reopened and checked against evidence-manifest.json. Final post-packaging validation runtime remains in allocated scratch. Delivery check PASS means a complete honest handback, not engineering acceptance.
