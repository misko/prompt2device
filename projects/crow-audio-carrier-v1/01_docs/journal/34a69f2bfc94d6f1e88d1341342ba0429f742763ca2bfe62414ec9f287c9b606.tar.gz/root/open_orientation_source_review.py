from pathlib import Path
from datetime import datetime, timezone, timedelta
import sys, json, hashlib, shutil, tempfile
sys.dont_write_bytecode = True
R = Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
N = Path(__file__).parent
name = 'rj45-orientation-scene-review'
sys.path.insert(0, str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput, subject_identity
from pipeline_runtime import open_agent_attempt
author = json.loads((N/'rj45-orientation-scene-source-opened.json').read_text())
probe = json.loads((N/'rj45-orientation-source-review-availability-opened.json').read_text())
for meta in [author, probe]:
    assert json.loads((Path(meta['envelope']).parent/'attempt.json').read_text())['status'] == 'PASS'
assert (N/'rj45-orientation-scene-source-closeout-summary.json').is_file()
D = Path(tempfile.mkdtemp(prefix=name+'-'))
shutil.copytree(Path(author['project'])/'input', D/'input')
shutil.copytree(Path(author['output_dir']), D/'author')
shutil.copy2(Path(author['envelope']), D/'author-envelope.json')
shutil.copy2(Path(author['project'])/'preflight.py', D/'preflight.py')
for item in ['orientation-source-preparation.json', 'orientation-approval-lifecycle-finding.txt']:
    shutil.copy2(N/item, D/item)
now = datetime.now(timezone.utc); cut = now+timedelta(minutes=25); hard = now+timedelta(minutes=35)
(D/'TASK.md').write_text(f'''# Independent exact connector orientation source review

Fresh judgment after author actual FINAL, delivery closure and complete archive preservation. Root owns both live boards and live source. READ_ONLY frozen input and author; isolated scratch only, no children, commits, source modifications, board/model placement changes, human approval or route/release acceptance. Workcut {cut.isoformat()}, hard {hard.isoformat()}, zero replacements. Inspect CLAUDE, applicable policy/connector procedure, tests contract and exact source candidate; do not preload transcript/historical review arguments. Author verdict is not your verdict.

Reopen every input and every source archive member against manifest, then independently judge the exact candidate patch and native rendered evidence. Verify unchanged live source beforeimages for candidate files and exact carrier board9c30a147b2d94babd98bc2af4150d4e87270d2efb81a8bd39e88f1b9529a99f4. Camera/scene correction is shared by carrier and pod, whose current checkpoint source inventories include the owning checker. No source adopted yet; all normal rebuild/reviews remain owed after accepted source. Current carrier333model entries/340footprints and9orientation instances;284external instances share20files. Root census is read-only source declarations, not proof all bodies rendered.

Determine whether explicit model substitutions reach native CLI correctly with complete required dependencies and deterministic renderer configuration. Verify model entry visibility/DNP/mounting/rotation/offset/scale, active scene census, model SHA bindings and actual native command/config selection. Ordinary PCB routing-only byte churn may preserve semantic geometry under existing policy; nearby body changes, model changes, camera/recipe/renderer changes must stale approval. A resolver count does not prove native visible body count. No implicit user-config path, silent missing model, copied receipt, mislabelled rotation or partial scene accepted as complete.

Inspect every required current candidate image, including J1/J5 target rear identity. Opposing row cardinal views previously hid named rears; candidate elevated views must show intended rear with full populated board context and honest target identification. J1north andJ5south native model/PCB remain identical; original diagnostics used top/board rotations300 and60 degrees, respectively. No cardinal crop fed an oblique frame, body-hiding, populated-minus-hidden bbox or generated cosmetic substitution. Do not infer automated occlusion proof from a recipe. Verify complete top/outside/inside and J9profiles where required, actual9/9machine denominator, signed-Z/mating controls and limitations of local filmcap occlusion. If rear still unjudgeable, return correction required with precise evidence, no waiver.

Inspect exact-viewed-bundle approval reuse. Before approving or reusing evidence, current machine/scene/camera subject must be derived and every expected image key/hash verified. --approve-reviewer cannot rerender a missing/stale/tampered bundle and automatically approve unseen pixels. Valid reuse must preserve original reviewed images and their producer identity; observed raw-board hash vs semantic routing-only reuse cannot be conflated. Current fresh approval remains strict schema1. Schema2's existing unchanged-semantic pixel reuse is deliberate; preserve that positive behavior while invalidating both schemas for material geometry/camera/scene changes. No human decision exists for current product images.

Independently run targeted maintained regressions through bounded runtime, including explicit propagation/missing nonconnector model refusal, nonconnector occluder/model/transform changes stale both schemas, exact schema1 image/key mutations, valid exact image reuse without renderer, stale/tampered approval refusal and front/back/axis compatibility. Inspect actual RED-before/GREEN-after evidence rather than treating absent new helper alone as a bug proof. Use native realized controls for the camera/scene claims. Reuse author native exports where legitimately unchanged but perform one independent exact native candidate evidence run if needed to establish all critical properties; at most one full product orientation invocation plus bounded focused hostile fixture, no angle search. Verify relevant authority/docs/contracts outputs and declared blind spots. Report any untested scope honestly, no broad PASS from a smaller property.

Additional read-only current source/models/test fixture dependencies may be copied from root/local library with exact recorded hashes; no live writes. All native/test commands through shared pipeline_runtime.run_stage with explicit cwd/env and finite<=300s. Preserve failed setup/controls and original source; reviewer cannot fix candidate. Deliver EXACTLY report.md,evidence.json,evidence-manifest.json,evidence.tar.gz,result.json. domain_result nonempty string SOUND or CORRECTION_REQUIRED with scope/limitations separate from delivery. Fresh archive includes review methods/results/native images/logs and source bindings, not nested author archive. Manifest archive_sha256/archive_size/member_count/members(path,size,sha256); reopen allregularmembers, no traversal/duplicates/symlinks. Exact subject result checks evidence-complete/inputs-verified/review-complete, unresolved[] only complete honest handback. Mandatory provided preflight then actual FINAL promptly. FIRST-ARTICLE-ONLY/DO-NOT-ORDER; independent source review is not user orientation confirmation, routing or release acceptance.
''')
items=[]
for p in sorted(D.rglob('*')):
    if p.is_file():
        b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(D).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
s=subject_identity('orientation_scene_source_review',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
e=TaskEnvelope(schema=2,task_id=name,stage_id='KICAD-PLACEMENT',run_id=name,subject=s,executor='agent',execution_class='review_wait',recommended_agent_role='judgment',agent_role='judgment',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']})
o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),agent_id='/root/carrier_rj45_orientation_scene_review',work_cutoff=cut.isoformat())
(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n')
print(json.dumps(o,indent=2));print(len(items),'frozen inputs')
