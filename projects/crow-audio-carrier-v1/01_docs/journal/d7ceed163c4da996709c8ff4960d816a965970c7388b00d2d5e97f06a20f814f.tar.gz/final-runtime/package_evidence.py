#!/usr/bin/env python3
import gzip, hashlib, io, json, stat, tarfile
from pathlib import Path, PurePosixPath
root=Path('/tmp/rj45-carrier-layout-toponly1-ih54rn7r'); scratch=root/'06_build/task_runs/rj45-carrier-layout-toponly1/scratch'; outputs=root/'06_build/task_runs/rj45-carrier-layout-toponly1/outputs'
members={
 'methods/run_stage.py':scratch/'run_stage.py','methods/verify_inputs.py':scratch/'verify_inputs.py','methods/measure_board.py':scratch/'measure_board.py','methods/classify_drc.py':scratch/'classify_drc.py','methods/derive_review.py':scratch/'derive_review.py','methods/write_outputs.py':scratch/'write_outputs.py',
 'raw/native_drc.json':scratch/'native_drc_corrected.json','raw/r0_drc.json':scratch/'r0_drc_corrected.json','raw/drc_classification.json':scratch/'drc_classification.json','raw/native_measurements.json':scratch/'native_measurements.json','raw/r0_measurements.json':scratch/'r0_measurements.json','raw/review_metrics.json':scratch/'review_metrics.json','raw/placement_gates_pads.json':scratch/'placement_gates_pads.json','raw/placement_gates_strict_courtyard.json':scratch/'placement_gates.json','raw/policy_audit.md':scratch/'policy_audit.md',
 'images/native_top.png':scratch/'native_top.png','images/native_bottom.png':scratch/'native_bottom.png',
 'images/primary/cs530x-p10.png':scratch/'cs-10.png','images/primary/cs530x-p11.png':scratch/'cs-11.png','images/primary/cs530x-p12.png':scratch/'cs-12.png','images/primary/ap63205-p15.png':scratch/'ap-15.png','images/primary/tpd2e2u06-p11.png':scratch/'esd-11.png','images/primary/tpd2e2u06-p12.png':scratch/'esd-12.png','images/primary/lt3041-p26.png':scratch/'ltlayout-26.png','images/primary/dc3158a-p5.png':scratch/'lteval-5.png','images/primary/dc3158a-p6.png':scratch/'lteval-6.png','images/primary/wurth-615008160221-p1.png':scratch/'rj-1.png',
 'source/floorplan.yaml':root/'project/03_src/floorplan.yaml','source/critical_paths.yaml':root/'project/03_src/rules/critical_paths.yaml','source/nets.yaml':root/'project/03_src/rules/nets.yaml','source/assembly.yaml':root/'project/03_src/rules/assembly.yaml','source/first_article.yaml':root/'project/03_src/rules/first_article.yaml'
}
for p in sorted(scratch.glob('*.runtime.log')):
 if p.name not in {'package.runtime.log','preflight.runtime.log','verify_inputs_after.runtime.log'}: members['runtime/'+p.name]=p
records=[]; archive=outputs/'evidence.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for name,path in sorted(members.items()):
    pp=PurePosixPath(name)
    if pp.is_absolute() or '..' in pp.parts or name.endswith('evidence.tar.gz'):raise SystemExit('unsafe member '+name)
    info=path.lstat()
    if path.is_symlink() or not stat.S_ISREG(info.st_mode):raise SystemExit('nonregular '+str(path))
    data=path.read_bytes(); ti=tarfile.TarInfo(name);ti.size=len(data);ti.mtime=0;ti.mode=0o644;ti.uid=ti.gid=0;ti.uname=ti.gname='';tar.addfile(ti,io.BytesIO(data));records.append({'path':name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
seen=set(); got=[]
with tarfile.open(archive,'r:gz') as tar:
 for m in tar.getmembers():
  pp=PurePosixPath(m.name)
  if m.name in seen or pp.is_absolute() or '..' in pp.parts or not m.isfile() or m.issym() or m.islnk() or m.name.endswith('evidence.tar.gz'):raise SystemExit('unsafe reopened member '+m.name)
  seen.add(m.name);data=tar.extractfile(m).read();got.append({'path':m.name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
if got!=records:raise SystemExit('reopen records differ')
data=archive.read_bytes();manifest={'schema':1,'archive_sha256':hashlib.sha256(data).hexdigest(),'archive_size':len(data),'member_count':len(records),'members':records};(outputs/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n');print(json.dumps({k:manifest[k] for k in ('archive_sha256','archive_size','member_count')}))
