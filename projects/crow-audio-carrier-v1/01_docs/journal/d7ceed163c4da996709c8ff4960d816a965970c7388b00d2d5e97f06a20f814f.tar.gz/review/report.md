review_stage: pre-route
review_kind: layout
reviewer: rj45-carrier-layout-toponly1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 92a4e2fc0fecde845f2dfa0d9e2f5bfbd943372962fb449d699a98d957fc5633
design_rules_sha256: 7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c
prepared_board_sha256: cc981839345d9e61bfaf6915014b904dcfa35dacb8b9d4438e15d5fe6888fa4d
subject_raw_sha256: a423eb0adca36c679ff4a3340ef7781028102b985d24efe3d6d5969283fcf33f
subject_semantic_sha256: 805316073d4dbd26b1ab63dee0dea1bb8a22137c2cce097a3db4622a2ce9f73f

# Fresh independent carrier pre-route layout review

The exact native placement is **SOUND for pre-route layout acceptance**. This does not accept routing, fabrication, assembly, first article, or ordering. The order verdict remains **DO-NOT-ORDER**.

The native board is 154.0 x 100.0 mm nominal (154.1 x 100.1 mm edge-stroke bbox), with 340 footprints and 1,050 pads. Of these, 333 are functional and all 333 are on the top; H1-H4 and FID1-FID3 are the seven board-only footprints. The assembly intent is 300 ordinary CPL candidates plus 33 explicitly off-CPL/manual-or-consign functional parts, with zero design-DNP parts. Every functional pose matches source: 141/141 explicit anchors and 192/192 repeat-derived poses, with no unaccounted functional footprint.

Fresh KiCad 10.0.4 severity-all/refill/parity DRC found **0 violations / 499 unconnected / 0 parity** on native and **60 violations / 445 unconnected / 0 parity** on r0. All native opens are expected pre-route edges. On r0, all 60 violations are preparation-only dangling launches (39 segment ends, 21 vias); the 445 opens are 367 ordinary unrouted edges plus 78 edges ending on prepared copper. Every item is retained with endpoint description, ref/pad or copper kind, net, coordinate and UUID in `raw/drc_classification.json` inside the evidence archive.

Physical placement gates pass in their applicable form: all pads are inside the outline with a 1.32 mm minimum reported margin; 333 assembled envelopes have no body/courtyard-to-foreign-pad collision; the worst cut is 17 nets against 272-track geometric capacity (0.06); and 1,009 copper pads pass 505,544 inter-footprint pad pairs and 838,192 paste-to-foreign-copper pairs at the 0.09 mm floor. Strict courtyard mode reports J1-J8 1.0 mm beyond the north/south edge. Fresh render and primary drawing inspection show this is the intended outward service-mouth interface, not a misplaced part.

Datasheet placement policy passes 20/20 in-scope parts, 20/20 tier-graded precedents, 62/62 keep-short budgets, 353/353 ref-pair budgets, and 415/415 resolved relationships. The eight positive connector-to-clamp prepared paths are 8.748830-8.749831 mm against 9.0 mm; the eight negative paths are 6.966676-6.967676 mm against 7.5 mm. Every U_ESD1-U_ESD8 ground pad has a dedicated 0.5/0.2 mm GND via 0.85 mm center-to-center away. The quiet ADC is 54.148 mm from the buck, 52.173 mm from U_CLK and 60.166 mm from U_TDM.

Primary diagrams inspected directly were the Cirrus CS530x VMID/FILT/ground-cutout figures (pp10-12), Diodes AP63205 recommended layout (p15), TI TPD2E2U06 layout guidance/example (pp11-12), Analog Devices LT3041 and DC3158A layout figures (datasheet p26; guide pp5-6), and the Wurth 615008160221 hole/body drawing (p1). The current placement follows their judgeable proximity and separation guidance. Kelvin/split-cap return, filled ground cutout, 50-ohm digital geometry, power-current transfer and thermal behavior remain correctly deferred to routed and physical gates.

## Findings and holds

* **OBS-01, informational:** J1-J8 intentional edge-interface courtyards extend 1.0 mm past the board. Pad containment and service-mouth inspection pass. Next owner: mechanical first-article owner.
* **FA-01, order-blocking first article:** J1-J8 shell pads 9/10 have only 0.018639 mm nominal margin above the 0.25 mm hole-to-copper floor at the adjacent 3.18 mm guides. Next owner: PCB fabrication and connector-process owner.
* **FA-02, order-blocking first article:** J1-J8 free spring-finger nominal right-courtyard centerline margin is 0.001919 mm; installed fit/tolerance is unqualified. Next owner: mechanical/enclosure owner.
* **FA-03, order-blocking first article:** J1-J9 outward service mouths and J10/J11 internal headers still require actual seating, simultaneous cable/latch access, solder, shield-isolation and continuity checks. Next owner: assembly and enclosure/test owners.
* **FA-04, order-blocking first article:** completed routing/fill and assembled electrical, thermal, EMC, noise, gain, clipping, cable and fault performance remain unqualified. Next owner: routing, fabrication and bring-up owners.

There is no actionable placement defect in the frozen subject. Prepared r0 is accepted only as deterministic preparation; its open and dangling populations are not route acceptance.
