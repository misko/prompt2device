import sys,json,hashlib,tarfile
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
sys.dont_write_bytecode=True
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_execution import TaskEnvelope,envelope_sha256
r=Path('/tmp/rj45-carrier-readability-review-clockbridge1-inz2tb21');d=r/'06_build/task_runs/rj45-carrier-readability-review-clockbridge1';s=d/'scratch';o=d/'outputs'
e=TaskEnvelope.from_json((d/'envelope.json').read_text());ej=json.loads((d/'envelope.json').read_text());eh=envelope_sha256(e)
assert eh=='b448eef86f69bb65a73facda45aa5a90357a5180d06d8ea7a4dbb1d1a1428b53'
rows=[]
for p in ej['input_packet']:
 b=(r/p['path']).read_bytes();actual=hashlib.sha256(b).hexdigest();ok=actual==p['sha256'] and len(b)==p['size'];assert ok;rows.append({'path':p['path'],'sha256':actual,'size':len(b),'pass':ok})
(s/'packet-after.json').write_text(json.dumps(rows,indent=2))
h=json.loads((s/'subject-verified.json').read_text());inv=json.loads((s/'inventory.json').read_text())
notes=[
'Input fuse and reverse-polarity FET path is continuous; S/G/D names and TVS/Zener K/A labels are legible; GND returns are clear.',
'Buck input isolation diode, VIN/EN, switch/inductor, feedback and capacitor banks can be traced; bleed chain is separate and readable.',
'Precharge/bypass and held reservoir are distinguishable; both 470uF positive terminals are explicit; PG_NC/VIOC_NC are named and open-ended.',
'Raw-rail and ADC-rail supervisors, sense dividers, reset pullups, timing capacitors and audio enable are readable; wire crossings do not obscure text.',
'Inverting-Schmitt behavior is explicit in title and pin names; both NC pins, timing RC, dump gate pulldown and discharge resistor are clear.',
*[f'Channel {i}: all ten RJ45 contacts are readable; pins 1/3/7 carry fused 12V, 2/6/8 GND, 5 AUDIO_P{i}, 4 AUDIO_N{i}, 9/10 CHASSIS. Shield and GND remain separate. ESD NC pins, differential polarity, coupling/bias, feedback, output filtering, isolation switch and local bypass are traceable.' for i in range(1,9)],
'ADC pin numbers, channel labels, configuration straps, three DOUT NC pins, LDO_D_FILT/VDD_D tie, ground bank and local bypass labels are readable.',
'Two passive external half-supply dividers and their bypass capacitors are separated and explicitly named VMID1_EXT/VMID2_EXT.',
'Two independent reference filter banks and ADC VMID decoupling are clearly separated; 470uF positive polarity is visible.',
'Clock page inspected again at 240 dpi. MCLK/BCLK/FSYNC paths have visible bridge arcs at nonconnecting crossings and dots at real branches. Three 10k pulldowns, three 22Ohm series resistors, ADC destinations, J10 NC labels and C_CLK 100nF are readable. R_FSYNC source/native footprint identity is independently checked as 1206.',
'TDM Schmitt path, inverter-controlled output enable, J11 sense input and 33Ohm output series resistor are legible; signal/power crossing uses a bridge and NC pins are named.',
'Reset high-low-high sequence is traceable from supervisor through one-shot to pull-down FET; RESET_C/RESET_RC/RESET_PULSE_H and bypass/ground returns are clear.'
]
assert len(notes)==19
coverage=[{'page':i+1,'image':f'page-{i+1:02d}.png','components':inv['page_component_counts'][i],'visually_inspected':True,'verdict':'SOUND','observations':note} for i,note in enumerate(notes)]
(s/'visual-inspection.json').write_text(json.dumps(coverage,indent=2))
limits=['Verdict is the fresh schematic-render/readability lens; it is not the separately commissioned complete topology/ratings/205-invariant verdict.', 'Visual review concerns the delivered 19-page tscircuit PDF, not a newly generated native KiCad PDF. Native bytes were checked for identity, component census, selected pin-net facts and NC-mark count.', 'The visual census is 19 pages, not an automated exhaustive glyph-pair collision proof. Text extraction supplements image inspection and does not substitute for it.', 'No board generation, routing, native board saves, electrical simulation, physical measurements, mating qualification, order allocation or broad project unit suites were performed.', 'Existing first-article/prototype and physical-mate evidence remains owed; public sourcing identity is not assembly allocation. DO-NOT-ORDER remains. These are downstream holds, not invented prerequisites for this schematic verdict.']
evidence={'review_stage':'pre-route','review_kind':'schematic_render','reviewer_identity':'carrier_rj45_native_carrier_readability_clockbridge1','context':'FRESH','date':datetime.now(timezone.utc).isoformat(),'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','subject':ej['subject'],'envelope_sha256':eh,**h,'methods':['Verified 429 frozen packet entries before work, after rendering and after review by byte size and SHA256.','Recomputed all seven subject hashes using frozen pre_route_review_check.py functions and its parts hashing algorithm.','Rendered all actual PDF pages at 120 dpi using bounded pdftoppm; inspected each as an image via view_image. Rendered and inspected pages 3,6,17,18 again at 240 dpi.','Independently parsed native s-expression netlist and compared component sets with source manifest and circuit.json; crosschecked every declared refdes appears on exactly one PDF page.','Crosschecked native net membership for all 80 RJ45 contacts and inspected R_FSYNC source/native value, MPN and footprint.','Archived original image evidence, review methods, raw logs, runtime records, packet verification and per-page judgments; reopened all archive members and checked path safety, size and digest.'],'counts':{'input_packet_before':429,'input_packet_after':429,'subject_hashes_verified':7,'pdf_pages_visually_inspected':19,'pdf_pages_total':19,'detail_pages_inspected':4,'components_manifest_native_circuit_pdf':333,'rj45_contacts_verified':80,'native_nc_marks':42},'pages':coverage,'findings':[],'limits':limits}
(o/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
report='\n'.join(f'{k}: {evidence[k]}' for k in ['review_stage','review_kind','reviewer_identity','context','date','design_verdict','order_verdict'])+'\n'+'\n'.join(f'{k}: {v}' for k,v in h.items())+'\n\nenvelope_sha256: '+eh+'\n\nFresh independent visual review of the exact frozen PDF: SOUND within the schematic-render lens. No material unreadable label, obscured polarity/NC intent, misleading ground-bar touch or wire-text conflict was observed. This does not authorize an order.\n\nMeasured coverage: 19/19 pages visually inspected at 120 dpi; pages 3, 6, 17 and 18 also inspected at 240 dpi. All 333 manifest components match native and circuit.json refdes sets and each appears on exactly one PDF page. All 80 RJ45 contact net assignments match the custom analog/power interface; CHASSIS remains separate from GND. Native schematic contains 42 no-connect marks; delivered PDF uses explicit NC pin names and open pin ends. These observations are not a claim of physical mating verification.\n\nClock detail: R_FSYNC is 22Ohm in the drawing and native netlist, source circuit MPN CRCW120622R0FKEAHP, footprint Resistor_SMD:R_1206_3216Metric. Its frozen dossier declares C844025. MCLK/BCLK/FSYNC are distinct drawn paths with bridge arcs at crossings; all three source terminations read 22Ohm and all three input pulldowns read 10kOhm. Package identity is checked in source/native evidence because passive footprint names are not displayed in the PDF.\n\n| Page | Components | Visual observation |\n|---|---:|---|\n'+'\n'.join(f'| {i+1} | {inv["page_component_counts"][i]} | {note} |' for i,note in enumerate(notes))+'\n\nMethods and provenance: all 429 frozen packet files verified before/after; 7/7 subject hashes independently recomputed with the frozen review-check implementation. Raw render/inventory logs, finite runtime receipts, all 19 page images and four detail images are included in evidence.tar.gz, alongside executable methods and per-page observations. Prior review verdicts and parent geometric screens were not used to accept current bytes.\n\nLimits:\n\n'+'\n'.join('- '+x for x in limits)+'\n'
(o/'report.md').write_text(report)
(o/'result.json').write_text(json.dumps({'subject':ej['subject'],'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]},indent=2)+'\n')
files=sorted(f for f in s.iterdir() if f.is_file());members=[]
with tarfile.open(o/'evidence.tar.gz','w:gz') as tar:
 for f in files:
  assert not f.is_symlink() and f.suffix not in ['.gz','.tar'];b=f.read_bytes();members.append({'path':f.name,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()});tar.add(f,arcname=f.name,recursive=False)
with tarfile.open(o/'evidence.tar.gz','r:gz') as tar:
 names=set();found=[]
 for m in tar.getmembers():
  assert m.isfile() and not m.issym() and not m.islnk();pp=PurePosixPath(m.name);assert not pp.is_absolute() and '..' not in pp.parts and m.name not in names;names.add(m.name);b=tar.extractfile(m).read();found.append({'path':m.name,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 assert found==members
b=(o/'evidence.tar.gz').read_bytes();manifest={'archive_sha256':hashlib.sha256(b).hexdigest(),'archive_size':len(b),'member_count':len(members),'members':members};(o/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'design_verdict':'SOUND','outputs':sorted(f.name for f in o.iterdir()),'archive_members':len(members),'archive_size':len(b),'packet_after':len(rows),'envelope_sha256':eh}))
