import sys,json
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_runtime import run_stage
r=Path('/tmp/rj45-carrier-readability-review-clockbridge1-inz2tb21');d=r/'06_build/task_runs/rj45-carrier-readability-review-clockbridge1';s=d/'scratch'
o=run_stage({'id':'preflight','work_class':'local','timeout_s':45},['/usr/bin/python3',str(r/'preflight.py'),str(d/'envelope.json')],log_path=s/'preflight.log',cwd=r,env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'},console=None);(s/'preflight-runtime.json').write_text(json.dumps(o.to_mapping(),indent=2));print(o.status);print((s/'preflight.log').read_text());assert o.status=='PASS'
