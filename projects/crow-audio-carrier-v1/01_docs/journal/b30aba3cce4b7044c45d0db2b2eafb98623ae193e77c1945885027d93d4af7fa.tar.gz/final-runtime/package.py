from pathlib import Path,PurePosixPath
import json,hashlib,tarfile
S=Path(__file__).resolve().parent;O=S.parent/'outputs';B=S.parents[3]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((S/n).read_text())
def dump(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
E=json.loads((S.parent/'envelope.json').read_text())
inputs=[{'path':x['path'],'size':(B/x['path']).stat().st_size,'sha256':sha(B/x['path']),'pass':(B/x['path']).stat().st_size==x['size'] and sha(B/x['path'])==x['sha256']} for x in E['input_packet']]
assert len(inputs)==750 and all(x['pass'] for x in inputs);dump(S/'inputs-after.json',inputs)
ids=read('identities.json')['current'];text=(O/'report.md').read_text();assert all(k+': '+v in text for k,v in ids.items())
evidence={'schema':1,'review_stage':'pre-route','review_kind':'schematic_render','reviewer_identity':'Codex /root/carrier_rj45_native_carrier_readability_frontreg1','context':'FRESH','date':'2026-09-14','design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','subject':E['subject'],'subject_hashes':ids,'findings':[],'methods':['All750 envelope inputs independently SHA256/size checked before and after.','Frozen pre_route_review_check.py independently recomputes all seven subject hashes.','Poppler144dpi render of both19-page PDFs; Pillow RGB body equality and exact generated-caption-strip exclusion comparison.','Host view_image inspection of all19 current full-page rasters plus19-header montage.','Independent S-expression native component/value/footprint/pin/net inventory and UUID-only native schematic normalization.','Independent disjoint-set reconstruction of1475 source traces/985ports matches all221 native pin partitions.','Byte-delta of all314 shared supplied project paths, parsed YAML registration field diff.','Complete23 locator member and46pin/net match; current ERC warning-class census.'],'counts':{'input_packet':750,'current_pdf_pages':19,'preceding_pdf_pages':19,'current_pages_actually_viewed':19,'body_pixels_per_subject':37589400,'body_changed_pixels':0,'native_components':333,'native_nets':221,'native_pin_assignments':985,'native_NC_nets':42,'first_power_installed':333,'source_traces':1475,'source_ports':985,'source_pin_partitions':221,'parts_dossiers':89,'shared_paths_compared':314,'authored_files_changed':1,'generated_files_changed':4,'RJ45_connectors':8,'CHASSIS_contacts':16,'locator_refs':23,'locator_pin_rows':46,'ERC_errors':0,'ERC_warnings':2637,'ERC_endpoint_off_grid':2068,'ERC_lib_symbol_issues':569},'source_delta':read('source-delta.json'),'parsed_registration_delta':read('fidelity.json')['parsed_registration_delta'],'caption_coverage':read('fidelity.json')['captions'],'pixel_equivalence':'pixel-equivalence.json','visual_notes':'visual-notes.md','limits':['Schematic presentation acceptance only.','Carrier-only subject; no pod population claim.','SOURCE PASS and authentic FULL INCOMPLETE physical gates remain separate; FIRST-ARTICLE-ONLY/DO-NOT-ORDER.','Conditional23 locator exception requires current atlas/bundle and exact-artifact render acceptance.','Physical orientation/mating, thermal/fault tests, native placement/routing/copper returns, sourcing allocation, fabrication, release and order remain outside this judgment.','Root owns complete external checkpoint verification and delivery adoption.']}
dump(O/'evidence.json',evidence)
exclude={'package.log','package.runtime.json','archive-verification.json','preflight.log','preflight.runtime.json'}
members={x.name:x for x in S.iterdir() if x.is_file() and x.name not in exclude}
members.update({'report.md':O/'report.md','evidence.json':O/'evidence.json','envelope.json':S.parent/'envelope.json','TASK.md':B/'TASK.md','expected-subject.json':B/'expected-subject.json','preceding-receipt/report.md':B/'preceding-receipts/readability/report.md','preceding-receipt/evidence-manifest.json':B/'preceding-receipts/readability/evidence-manifest.json','preceding-receipt/delivery-attempt.json':B/'preceding-receipts/readability/delivery-attempt.json','current/schematic.pdf':B/'project/03_tscircuit/build/schematic.pdf','preceding/schematic.pdf':B/'preceding-subject/03_tscircuit/build/schematic.pdf','current/circuit.json':B/'project/03_tscircuit/build/circuit.json','current/native.kicad_sch':B/'project/04_kicad/crow_audio_carrier_v1.kicad_sch','current/native.net':B/'project/06_build/netlists/crow_audio_carrier_v1.net'})
archive=O/'evidence.tar.gz';manifest=[]
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(members.items()):
  assert p.is_file() and not p.is_symlink() and not name.endswith(('.tar','.tar.gz','.tgz')) and '..' not in PurePosixPath(name).parts and not PurePosixPath(name).is_absolute()
  t.add(p,arcname=name,recursive=False);manifest.append({'path':name,'size':p.stat().st_size,'sha256':sha(p)})
seen=set()
with tarfile.open(archive,'r:gz') as t:
 for m in t.getmembers():
  assert m.isfile() and m.name not in seen and '..' not in PurePosixPath(m.name).parts and not PurePosixPath(m.name).is_absolute();seen.add(m.name)
  body=t.extractfile(m).read();row=next(x for x in manifest if x['path']==m.name);assert len(body)==row['size']==m.size and hashlib.sha256(body).hexdigest()==row['sha256']
assert len(seen)==len(manifest)
man={'archive_sha256':sha(archive),'archive_size':archive.stat().st_size,'member_count':len(manifest),'members':manifest};dump(O/'evidence-manifest.json',man)
dump(S/'archive-verification.json',{'status':'PASS','regular_members_reopened':len(seen),'member_sizes_and_hashes_verified':True,'no_symlinks_traversal_duplicate_recursive_archives':True,'archive_sha256':man['archive_sha256'],'archive_size':man['archive_size']})
dump(O/'result.json',{'subject':E['subject'],'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]})
assert set(x.name for x in O.iterdir())=={'report.md','evidence.json','evidence-manifest.json','evidence.tar.gz','result.json'}
print(json.dumps({'archive_sha256':man['archive_sha256'],'archive_size':man['archive_size'],'members':len(manifest),'inputs_verified':len(inputs),'outputs':sorted(x.name for x in O.iterdir())},indent=2))
