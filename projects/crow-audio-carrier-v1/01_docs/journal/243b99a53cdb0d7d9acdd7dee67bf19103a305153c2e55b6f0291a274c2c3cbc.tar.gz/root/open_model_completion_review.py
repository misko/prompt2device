from pathlib import Path
from datetime import datetime, timezone, timedelta
import sys, json, hashlib, shutil, tempfile
sys.dont_write_bytecode = True
R = Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
N = Path(__file__).parent
C = N / 'model-registration-completion'
S = C / 'repo'
name = 'rj45-model-completion-review'
sys.path.insert(0, str(R / 'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput, subject_identity
from pipeline_runtime import open_agent_attempt
probe = json.loads((N / 'rj45-model-completion-availability-opened.json').read_text())
assert json.loads((Path(probe['envelope']).parent / 'attempt.json').read_text())['status'] == 'PASS'
prior = json.loads((N / 'rj45-model-visibility-reassessment-opened.json').read_text())
assert json.loads((Path(prior['envelope']).parent / 'attempt.json').read_text())['status'] == 'PASS'
D = Path(tempfile.mkdtemp(prefix=name + '-'))
shutil.copytree(Path(prior['project']) / 'input', D / 'input')
def copy(src, rel):
    dst = D / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
rows = json.loads((C / 'completion-source-verification.json').read_text())['files']
for row in rows:
    rel = row['path']
    assert hashlib.sha256((R / rel).read_bytes()).hexdigest() == row['before_sha256']
    assert hashlib.sha256((S / rel).read_bytes()).hexdigest() == row['completion_sha256']
    copy(S / rel, 'completion/' + rel)
    copy(N / 'model-candidate1-root-inspection/source_candidate' / rel, 'original-candidate/' + rel)
for rel in ('skills/pcb-design/references/lifecycle-and-backtrack.md', 'skills/kicad-pcb/references/routing-pipeline.md', 'skills/kicad-pcb/scripts/gate_contract_audit.py'):
    copy(R / rel, 'input/' + rel)
for p in Path(prior['output_dir']).iterdir():
    if p.is_file():
        copy(p, 'prior-review/' + p.name)
for p in (Path(prior['envelope']), Path(prior['envelope']).parent/'attempt.json'):
    copy(p, 'prior-review/allocation/' + p.name)
for p in C.glob('*.json'):
    copy(p, 'measurement/' + p.name)
I = Path('/tmp/carrier-connector-integration-20260911')
for p in I.glob('model-completion-*'):
    if p.is_file():
        copy(p, 'measurement/runtime/' + p.name)
shutil.copytree(S / 'projects/crow-audio-carrier-v1/06_build/pre_route', D / 'measurement/carrier-pre-route')
copy(Path('/tmp/carrier-locator-implementation-availability-6c_4vwal/preflight.py'), 'preflight.py')
now = datetime.now(timezone.utc)
cut = now + timedelta(minutes=12)
hard = now + timedelta(minutes=20)
(D / 'TASK.md').write_text((N / 'model_completion_review_task.txt').read_text().format(cut=cut.isoformat(), hard=hard.isoformat()))
items = []
for p in sorted(D.rglob('*')):
    if p.is_file():
        b = p.read_bytes()
        items.append({'name': f'input_{len(items):04d}', 'path': p.relative_to(D).as_posix(), 'size': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
subject = subject_identity('model_completion_review', 1, [TypedIdentityInput('packet', 'sequence', items, json.dumps(items, sort_keys=True).encode())])
e = TaskEnvelope(schema=2, task_id=name, stage_id='KICAD-PLACEMENT', run_id=name, subject=subject, executor='agent', execution_class='review_wait', recommended_agent_role='judgment', agent_role='judgment', role_escalation_reason=None, context_mode='FRESH', input_handoff_id=name, input_packet=items, deadline_at=hard.isoformat().replace('+00:00', 'Z'), max_nonimproving_attempts=1, replacement_limit=0, writer_scope={'mode': 'READ_ONLY', 'paths': []}, output_path=f'06_build/task_runs/{name}/attempt.json', completion={'outputs': ['evidence-manifest.json', 'evidence.json', 'evidence.tar.gz', 'report.md'], 'checks': ['evidence-complete', 'inputs-verified', 'review-complete']})
o = open_agent_attempt(e, cwd=D)
o.update(project=str(D), envelope=str(D / e.output_path).replace('attempt.json', 'envelope.json'), task=str(D/'TASK.md'), agent_id='/root/carrier_rj45_model_completion_review', work_cutoff=cut.isoformat())
(N / (name + '-opened.json')).write_text(json.dumps(o, indent=2) + '\n')
print(json.dumps(o, indent=2))
print(len(items), 'frozen inputs')
