# Native model physical registration — `native_top.png`

board_sha256: 9c30a147b2d94babd98bc2af4150d4e87270d2efb81a8bd39e88f1b9529a99f4
coupon_sha256: c8607f14a4bc32d942ff3f7344789edf476c446bd7f3b0770718b53cda2282fc
a-render_verdict: PASS
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 3f902b89d4bd756b121be056782deff312efb127c9c48f2c798ebd6db0e59f49
footprint_registration_datum_sha256: b5acb43902b94b875021e74ca342259f30127c6a3dc68fea444ee625d295c807
model_transform_sha256: 6cf53f0e2e5e9c07c31120b0a7392007f28e50daeb9d9b4fabcff69a71234dd2
registration_contract_sha256: 157c7435b98c929210522932eab5f09c2cb3d17ed53cd07db495b767f8a6dc8a
tuple_cache_key: 2d3109e18f1b5abfa7c9d23e622c0d97344a070084427e116862cdeb1ac1cbbe
calibration_px_per_mm: 18.3448 x, 18.3428 y
anisotropy: 1.0001
fit_tolerance_mm: 0.350
courtyard_containment_tolerance_mm: 0.350
registration_datum: drilled_centres
mount_side: front
actual_footprint_side: front
plan_camera: top
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 0.968696
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected drilled_centres field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | registration centres inside | min pad margin mm |
|---|---:|---:|---:|---:|---:|
| J1 | 0.035 | 0.084 | 0.000 | 12/12 | 0.175 |
| J2 | 0.020 | 0.054 | 0.000 | 12/12 | 0.204 |
| J3 | 0.032 | 0.080 | 0.000 | 12/12 | 0.179 |
| J4 | 0.002 | 0.029 | 0.000 | 12/12 | 0.175 |
| J5 | 0.000 | 0.054 | 0.000 | 12/12 | 0.204 |
| J6 | 0.002 | 0.029 | 0.000 | 12/12 | 0.175 |
| J7 | 0.007 | 0.029 | 0.000 | 12/12 | 0.175 |
| J8 | 0.007 | 0.054 | 0.000 | 12/12 | 0.204 |

## Failures

- none
