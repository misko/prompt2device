# Native model physical registration — `native_top.png`

board_sha256: 9c30a147b2d94babd98bc2af4150d4e87270d2efb81a8bd39e88f1b9529a99f4
coupon_sha256: c14a27d18b5a6f4deb0658dee4d87c04965f53b48fb864cd2aa212aad76dc43a
a-render_verdict: PASS
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 1875571c326d0d9e96f36b4efeb8094068ef7619f0a449c781caf0b49c2e5861
footprint_registration_datum_sha256: 3b640aed9f46e0b23dacde17b53e5efeaf3f2c0db5712e6980b969e3a4f45f93
model_transform_sha256: 6cf53f0e2e5e9c07c31120b0a7392007f28e50daeb9d9b4fabcff69a71234dd2
registration_contract_sha256: abdfe1ec70c542cf40fec280398a418dfc4bc6bb39e42ffaf10ef151b131587c
tuple_cache_key: 4e385fbefbcf37fe9ff3d2d65446f4b2532b94c82bb6ba66bf7df53b6ef68824
calibration_px_per_mm: 127.1901 x, 127.1698 y
anisotropy: 1.0002
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_smd_pad_overlap
mount_side: front
actual_footprint_side: front
plan_camera: top
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 0.812502
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_smd_pad_overlap field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | SMD pads overlapping model plan | minimum overlap mm2 |
|---|---:|---:|---:|---:|---:|
| R_PWR_TOP | 0.004 | 0.000 | 0.000 | 2/2 | 0.289 |

## Failures

- none
