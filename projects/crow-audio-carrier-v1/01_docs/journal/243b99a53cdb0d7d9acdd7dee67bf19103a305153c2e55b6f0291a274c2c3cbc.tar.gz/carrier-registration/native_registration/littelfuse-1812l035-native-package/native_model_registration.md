# Native model physical registration — `native_top.png`

board_sha256: 9c30a147b2d94babd98bc2af4150d4e87270d2efb81a8bd39e88f1b9529a99f4
coupon_sha256: b35c7f627b22ed5dfa823c2712fda302fa90263f61b566993873d6232fb7f658
a-render_verdict: PASS
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: edd6c3054b944bb9436d3943f1b5da78396621e59065dde98e828219fa62cde9
footprint_registration_datum_sha256: 40f8d1835302c944df092109acc47a2d778f089cb4bf67df260119324ee4c8e0
model_transform_sha256: 6cf53f0e2e5e9c07c31120b0a7392007f28e50daeb9d9b4fabcff69a71234dd2
registration_contract_sha256: faf9b652a453209509885289bebc10f19f618e256ee121cad7da4663878c31c2
tuple_cache_key: 69888cf3c8b46ac0c937f3df614409e7c95fdfe3753b3a563d02fb592e6278ec
calibration_px_per_mm: 33.6530 x, 33.6374 y
anisotropy: 1.0005
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_smd_pad_overlap
mount_side: back
actual_footprint_side: back
plan_camera: bottom
plan_projection: X-MIRRORED
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 1.000000
overlay: native_top_registration_overlay.png

Orange is B.CrtYd; green is the independent B.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_smd_pad_overlap field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond B.Fab mm | measured beyond courtyard mm | SMD pads overlapping model plan | minimum overlap mm2 |
|---|---:|---:|---:|---:|---:|
| F1 | 0.020 | 0.000 | 0.000 | 2/2 | 1.992 |
| F2 | 0.024 | 0.000 | 0.000 | 2/2 | 1.961 |
| F3 | 0.031 | 0.000 | 0.000 | 2/2 | 1.930 |
| F4 | 0.005 | 0.000 | 0.000 | 2/2 | 1.992 |
| F5 | 0.015 | 0.000 | 0.000 | 2/2 | 1.961 |
| F6 | 0.025 | 0.000 | 0.000 | 2/2 | 1.930 |
| F7 | 0.007 | 0.000 | 0.000 | 2/2 | 1.992 |
| F8 | 0.016 | 0.000 | 0.000 | 2/2 | 1.961 |

## Failures

- none
