# Project native model physical registration

board_sha256: 9c30a147b2d94babd98bc2af4150d4e87270d2efb81a8bd39e88f1b9529a99f4
a-render_verdict: PASS
registration_kind: P-MODEL-REG
config_sha256: e6dfacedbb7708b06452048bd1d46b07586cd4aeebd548fc4dd0ad7fcf8184ac
stage_receipt: 06_build/pre_route/model_registration.stage.json
accepted_bundle: 06_build/pre_route/model_registration_bundle/bundle.json

This aggregate is independent physical-registration evidence. Each group uses an origin-centred coupon and compares native-model pixels with mounted-side Fab/courtyard and each group's declared drilled-centre, all-pad-centre or SMD-overlap datum. Catalog-twin renderer fidelity is a separate gate.

| group | refs | tuple cache key | group report | result |
|---|---|---|---|---|
| wurth-615008160221-side-entry | J1,J2,J3,J4,J5,J6,J7,J8 | `2d3109e18f1b5abfa7c9d23e622c0d97344a070084427e116862cdeb1ac1cbbe` | `06_build/pre_route/native_registration/wurth-615008160221-side-entry/native_model_registration.md` | PASS |
| molex-43650-0200-side-entry | J9 | `fe79ee0167a406824bce27ecf0e2f31b8ec22dc09be68c7e219f0865d1c35145` | `06_build/pre_route/native_registration/molex-43650-0200-side-entry/native_model_registration.md` | PASS |
| samtec-tmm-106-01-l-d-top-entry | J10,J11 | `b8b6edb4599aedd57cb34941f6cd592b43ce80ecadfd4c312eb2bffb8daa4975` | `06_build/pre_route/native_registration/samtec-tmm-106-01-l-d-top-entry/native_model_registration.md` | PASS |
| ti-dsg0008a-native-package | U_ISO1,U_ISO2,U_ISO3,U_ISO4,U_ISO5,U_ISO6,U_ISO7,U_ISO8 | `b2b96dccb5bd8b51c09cf78161c19e70687e1df363a14196e996acd906856851` | `06_build/pre_route/native_registration/ti-dsg0008a-native-package/native_model_registration.md` | PASS |
| littelfuse-1812l035-native-package | F1,F2,F3,F4,F5,F6,F7,F8 | `69888cf3c8b46ac0c937f3df614409e7c95fdfe3753b3a563d02fb592e6278ec` | `06_build/pre_route/native_registration/littelfuse-1812l035-native-package/native_model_registration.md` | PASS |
| yageo-rt0603-native-package | R_PWR_TOP | `4e385fbefbcf37fe9ff3d2d65446f4b2532b94c82bb6ba66bf7df53b6ef68824` | `06_build/pre_route/native_registration/yageo-rt0603-native-package/native_model_registration.md` | PASS |
