# Fresh independent locator implementation and forward-use review

- Subject raw SHA-256: `8913f15683d9f40e961866bc9be8ed24e6b7b091d193d66da3eae7769092e785`
- Subject semantic SHA-256: `f040d6dbaff54f7bc9a690784580882e172ce16007be1e9785e0146423ae9ab4`
- Candidate PCB SHA-256: `9aa1c2c821a31129176a8b519b9a211d78dfc011adb997a64470c03d0726891f`
- Scope: locator producer, independent checker, current generated locator, project/placement composition, sealed-release forward use, documentation, and test persistence
- Engineering verdict: **INCOMPLETE**
- Exact 25-reference identification basis: **ACCEPTABLE for this exact candidate and exact shipped atlas**
- Order/release verdict: **DO-NOT-ORDER; no routing, release, or order acceptance was performed**

## Blocking findings

### 1. Exact-artifact human acceptance is required in prose but is not bound to a consumed hash

The implementation correctly says the machine checker establishes identity and packaging rather than visual usability. That separation is sound. The missing piece is a machine-consumed receipt that binds the required independent visual judgment to the exact locator artifact set. `pre_route_review_check.py` calls `project_check`, then grades the ordinary pin/layout/render review files against the PCB hash. It does not require a locator-manifest hash or reviewed-reference denominator in any human review. `release_freshness_check.py` reopens the shipped locator from sealed source and fab files, but likewise has no exact locator usability receipt to consume.

I exercised this gap with a new hostile control. Starting from a clean, freshly regenerated locator, I replaced the visible page-1 heading with `WRONG VISIBLE ID: J999`, while retaining the original PNG metadata fields (`reference`, board hash, identity hash). I regenerated the PDF from the altered 25 PNGs and refreshed every locator-manifest member size/hash. Both the exact checker and the sealed-release checker returned exit 0 and full coverage: 333 assembled references, 995 pads, 25 exceptions, 25 pages, and 28 manifest members. The altered page is visibly false while its footer still says `Locator 1/25 · C_AUDIO_CT2`.

This is not a request for OCR or for the metadata checker to pretend it can grade usability. It demonstrates why the separately required judgment must be hash-bound and enforced. An artifact index binds bytes to a producer run; it does not state that a reviewer accepted those bytes. A complete fix should use the existing independent render-review record rather than create a parallel approval system: add the exact `assembly_locator_manifest.json` SHA-256, the exact reviewed 25-reference set/denominator, reviewer, and explicit locator verdict; require those fields in project PR-REVIEW; ship the accepted review as the release render review; and require the release gate to match its hash and set to the shipped locator. Add a known-bad test which refreshes manifest hashes around a visibly altered page and proves the project and release acceptance gates reject it.

Until that consumer exists, P4/M4 adoption is incomplete even though the current artifact itself is legible and correctly identified.

### 2. The 23 locator tests are not exercised by the repository's default test harness

The copied `skills/jlcpcb-fab/scripts/tests/test_assembly_locator.py` passed all 23 tests in a fresh run, including stale PCB, fresh-hash BOM/CPL mutations, ref/pad/page/PDF/PNG/HTML controls, valid-to-unknown UI state, source-waiver equality, project PR-REVIEW composition, release-freshness composition, and sealed-source independence. The tests are useful and have teeth.

However, `tests/run_tests.sh` explicitly enumerates top-level suites and does not discover `skills/*/scripts/tests`. Static inspection found no `assembly_locator`, `test_assembly_locator`, or script-local test-discovery entry in the runner, `tests/t4_regressions.py`, `tests/t1_contracts.py`, or `tests/README.md`. The script-local contract also says repository integration gates remain under top-level `tests/`, while this locator suite includes the two integration controls for PR-REVIEW and release freshness. A direct 23-test invocation therefore does not establish persistent default-suite coverage.

The smallest remedy is to add a top-level locator suite (or move the composition cases into the owning top-level placement/release suites), enumerate it in `tests/run_tests.sh`, document its clean/known-bad coverage in `tests/README.md`, and add the ordinary harness-wiring backstop. The script-local unit cases may remain where they are if the top-level suite invokes them explicitly and propagates their result.

## Passing implementation evidence

The producer/checker split is otherwise credible. `assembly_locator.py` produces data, offline HTML and the atlas. `assembly_locator_check.py` does not import the producer and independently reopens the PCB, BOM, CPL, config, HTML/SVG/script, PNG metadata, and PDF object streams. It binds the exact generator, template and checker hashes, rejects unsafe/duplicate/missing members, checks all native body/pad envelopes, and enforces native/source/JSON/page set equality. The normal exporter generates the locator, calls the separate checker before publishing `artifact_index.json`, and indexes all 29 locator files (JSON, HTML, PDF, 25 PNGs, and the manifest) under the `assembly_locator` role.

My independent census, which did not call the locator checker, measured 340 native footprints and 1002 pads total; 7 board-only mechanical footprints are explicitly excluded, leaving 333 assembled footprints and 995 assembled pad objects. The expanded BOM and CPL each contain 300 references; the remaining 33 assembled bodies are manual-placement bodies. The hidden native set, source exception set, and JSON hidden set are exactly equal at 25. For all 25 exceptions I found zero native value/position/rotation errors, zero BOM MPN/LCSC errors, zero CPL position/side/rotation errors, and zero pad-number/net errors.

I ran the documented commands exactly against scratch output. Generation completed successfully, the exact checker returned the full 333/995/25/25/28 result, and all 28 generated locator members were byte-identical to the supplied current locator members. I also assembled a self-contained release fixture containing only the shipped source board, locator config, waiver, three locator tools, BOM/CPL and locator fab artifacts. `assembly_locator_check.py release` passed that fixture, confirming that the release checker does not need live project inputs.

The valid-to-unknown repair is effective in the actual shipped HTML. Running `locator_ui_control.js` directly against `project/06_build/pre_route/current_assembly/assembly_locator.html` selected a valid part, then an unknown reference, and confirmed removal of the selected body, heading, details, pad table, crosshair and URL hash. The supplied browser view also shows a coherent `R_PWR_TOP` selection with exact value, MPN, LCSC, native coordinates, rotation/side and pad identities.

I visually inspected all 25 supplied PNG pages at readable resolution. Every page has a full reference/value heading, MPN and LCSC, side/rotation, native coordinates, a whole-board locator ring, a local highlighted body with numbered pads, pad/net text, exact PCB hash, and ordered page footer. The pages are internally coherent and the repeated-channel examples remain distinguishable by whole-board position, local pad context, coordinates and net identity. I found no usability defect in the exact supplied atlas. The static 25-page locator is acceptable identification evidence for exactly these 25 top-side 1–4-pad exceptions once an exact-artifact acceptance receipt is enforced.

## Forward-use and scope limits

The sealed release check works after the required source/config/tool files are staged, and it reads only those copies. I found no production helper that stages the three locator tools and two source records into a release; current release staging appears operator-owned. The documentation names every required path, and my scratch assembly passed, so I treat this as an explicit manual release responsibility rather than a separate blocker. A release missing any of these files is expected to fail. The ordinary complete MANIFEST, `artifact_index.json`, and ORDER_README links remain mandatory.

This review does not make candidate `9aa1c2c8...` canonical. The canonical PCB remains `0d80ee92...`, and the owning PR-REVIEW remains failed because current layout acceptance is missing and the current render review is defective. The owner must regenerate/promote from source, reproduce or freshly validate the locator against the resulting exact board/BOM/CPL, commission a 25/25 exact locator usability review bound to the locator manifest, and obtain current layout/render acceptance before routing admission. Any resulting board, BOM, CPL, config, template, generator, checker, or locator-member change must stale the prior locator evidence.

The earlier P5 caption and Samtec signed-side conclusions were not reopened here except insofar as this candidate was the locator's exact PCB input. This review does not accept routing, DRC closure, electrical closure, installed connector fit, harness mating, supplier allocation, release sealing, publication, or ordering.

## Input and execution integrity

All 311 allocated inputs matched their envelope size and SHA-256 on both verification passes. Native/PDF work ran through bounded `pipeline_runtime.run_stage` calls with full argv, cwd, return code, timing and raw stdout/stderr retained. The only files inspected outside the allocated packet were the repository's read-only default-harness authorities, because the packet contains the locator suite but not those top-level files; their hashes are recorded in evidence. No input or live project file was modified.

## Separately staged repair supplement

After the frozen-source review was complete, the root supplied a separately staged, read-only repair for the two findings. This supplement does not change the original subject or its `INCOMPLETE` verdict. I independently inspected the four supplied files and recorded their hashes in `evidence.json`.

The corrected checker makes project and release modes consume the existing independent render-review record. It requires reviewer/date, render/SOUND verdict, the exact board SHA-256, the exact locator-manifest SHA-256, and a unique reviewed-reference list equal to the manifest page-reference set. Because the manifest hashes every locator member, a regenerated visible page/PDF/manifest now makes the independent review stale. Exact mode remains a structural producer check and cannot mint acceptance. The added hostile test recreates the visible `J999` substitution, proves exact mode still passes by design, and proves both owning project and sealed-release consumers reject it.

The correction also adds `tests/t1_assembly_locator.py` and enumerates it in `tests/run_tests.sh`. The focused top-level entry exercises public coverage output, a missing-page known-bad control, and the complete native suite, including the owning review/release consumers. In independent bounded runs, all 25 native controls passed and the top-level entry reported 3/3 pass with its two known-bad fixtures failing their checker as intended. I did not rerun the repository's entire default battery within the original review cutoff. On the supplied repair, both original blockers are addressed and I found no new material locator defect.
