from pathlib import Path
import sys,os,json
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');D=Path(__file__).parent/'locator-repair';I=Path('/tmp/carrier-connector-integration-20260911');sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
relative='skills/jlcpcb-fab/scripts/assembly_locator_check.py';path=D/relative;fixed=path.read_bytes();old=(R/relative).read_bytes()
try:
 path.write_bytes(old)
 argv=['/usr/bin/python3','skills/jlcpcb-fab/scripts/tests/test_assembly_locator.py']
 result=run_stage({'id':'locator-original-visual-control','work_class':'local','timeout_s':60},argv,log_path=I/'locator-original-visual-control.log',cwd=D,env=dict(os.environ),console_line_limit=8,console_tail_lines=4).to_mapping()
 (I/'locator-original-visual-control.runtime.json').write_text(json.dumps({'argv':argv,'cwd':str(D),'runtime':result},indent=2)+'\n')
 text=(I/'locator-original-visual-control.log').read_text()
 assert result['returncode']==1 and 'FAILED (failures=2)' in text,text[-4000:]
 assert 'test_rehashed_visible_tamper_stales_independent_acceptance' in text and 'test_visual_review_requires_complete_unique_refs_and_sound_verdict' in text
 print('PASS: actual original checker fails exactly the two added visual-acceptance controls; original live source unchanged.')
finally:
 path.write_bytes(fixed)
 assert (R/relative).read_bytes()==old
