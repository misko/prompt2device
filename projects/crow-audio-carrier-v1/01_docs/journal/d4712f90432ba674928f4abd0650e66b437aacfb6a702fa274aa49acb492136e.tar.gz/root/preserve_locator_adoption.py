from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,tarfile,io,shutil
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911');A=Path('/tmp/carrier-locator-implementation-review-3q8eb88j/06_build/task_runs/locator-implementation-review');files={};sha=lambda b:hashlib.sha256(b).hexdigest()
for f in A.rglob('*'):
 if f.is_file() and 'scratch' not in f.relative_to(A).parts and '__pycache__' not in f.parts:files['closed-review/'+f.relative_to(A).as_posix()]=f
for row in json.loads((A/'outputs/evidence.json').read_text())['external_read_only_inputs']:
 f=Path(row['path']);assert sha(f.read_bytes())==row['sha256'];files['reviewer-ancillary-main-checkout/'+f.name]=f
for row in json.loads((D/'locator-repair/correction-inputs.json').read_text())['inputs']:
 files['adopted-source/'+row['path']]=R/row['path']
for n in ['skills/kicad-pcb/scripts/gate_contract_audit.py','skills/kicad-pcb/scripts/contracts.md','tests/t1_gate_contract.py','tests/t1_land_witness.py']:
 files['adopted-source/'+n]=R/n
for f in I.glob('locator-*'):
 if f.is_file():files['root-logs/'+f.name]=f
for n in ['run.py']:files['root-logs/'+n]=I/n
for n in ['reopen_locator_implementation_review.py','locator-implementation-review-reopening.json','verify_locator_visual_red.py','preserve_locator_adoption.py','record_locator_implementation_checkpoint.py','locator-implementation-preservation-result.json','before-locator-renewal-preservation-result.json','next-canonical-and-corridor-plan.md']:
 files['root/'+n]=D/n
files['root/correction-inputs.json']=D/'locator-repair/correction-inputs.json'
m={n:{'size':f.stat().st_size,'sha256':sha(f.read_bytes())} for n,f in sorted(files.items())};tmp=D/'locator-adoption.tar.gz'
with tarfile.open(tmp,'w:gz',compresslevel=3) as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 b=(json.dumps({'members':m},indent=2)+'\n').encode();x=tarfile.TarInfo('MANIFEST.json');x.size=len(b);t.addfile(x,io.BytesIO(b))
h=sha(tmp.read_bytes());out=P/'01_docs/journal'/(h+'.tar.gz');assert not out.exists();shutil.copyfile(tmp,out)
with tarfile.open(out) as t:
 assert set(t.getnames())==set(m)|{'MANIFEST.json'}
 for n,row in m.items():b=t.extractfile(n).read();assert len(b)==row['size'] and sha(b)==row['sha256'],n
result={'archive':str(out),'sha256':h,'size':out.stat().st_size,'payload_members':len(m),'all_reopened':True,'time':datetime.now(timezone.utc).isoformat()};(D/'locator-adoption-preservation-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
