from pathlib import Path
import json,hashlib,tarfile
D=Path('/tmp/carrier-locator-implementation-review-3q8eb88j');A=D/'06_build/task_runs/locator-implementation-review';R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');C=Path('/tmp/carrier-placement-review-20260911');fix=C/'locator-repair';sha=lambda b:hashlib.sha256(b).hexdigest();env=json.loads((A/'envelope.json').read_text());assert json.loads((A/'attempt.json').read_text())['status']=='PASS'
for row in env['input_packet']:
 b=(D/row['path']).read_bytes();assert len(b)==row['size'] and sha(b)==row['sha256'],row['path']
m=json.loads((A/'outputs/evidence-manifest.json').read_text());ar=A/'outputs'/m['archive']['path'];assert ar.stat().st_size==m['archive']['size'] and sha(ar.read_bytes())==m['archive']['sha256']
with tarfile.open(ar) as t:
 assert set(t.getnames())=={row['path'] for row in m['members']}
 for row in m['members']:
  b=t.extractfile(row['path']).read();assert len(b)==row['size'] and sha(b)==row['sha256'],row['path']
e=json.loads((A/'outputs/evidence.json').read_text());corrected=[]
for row in e['repair_supplement']['files']:
 current=sha((fix/row['path']).read_bytes());corrected.append({'path':row['path'],'reviewed_sha256':row['sha256'],'current_sha256':current,'matches':current==row['sha256']})
assert all(row['matches'] for row in corrected if row['path']!='tests/run_tests.sh')
external=[]
for row in e['external_read_only_inputs']:
 relative=Path(row['path']).relative_to('/home/mouse9911/gits/circuits');current=sha((R/relative).read_bytes());external.append({'path':str(relative),'reviewed_sha256':row['sha256'],'worktree_sha256':current,'matches':current==row['sha256']})
result={'inputs_verified':len(env['input_packet']),'archive_members_verified':len(m['members']),'archive_sha256':m['archive']['sha256'],'supplement_files':corrected,'ancillary_main_checkout_comparison':external,'limits':'Original verdict INCOMPLETE preserved; focused correction accepted. Any ancillary/main differences are not transferred as exact-worktree evidence. Root actual default-wiring regression measured t1_land_witness omission and corrected that extra entry separately.'};(C/'locator-implementation-review-reopening.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
