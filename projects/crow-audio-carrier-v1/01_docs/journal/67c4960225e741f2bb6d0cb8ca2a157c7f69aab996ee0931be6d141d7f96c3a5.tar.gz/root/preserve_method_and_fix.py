from pathlib import Path
from datetime import datetime,timezone
import sys,json,tarfile,hashlib,io,shutil
D=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';I=Path('/tmp/carrier-connector-integration-20260911');sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/pcb-design/scripts'));from pipeline_execution import TaskEnvelope,verify_input_packet
sha=lambda b:hashlib.sha256(b).hexdigest();files={};refs={};seen={};rows=[]
def add(n,p):
 b=p.read_bytes();h=sha(b)
 if h in seen:refs[n]={'archive_member':seen[h],'size':len(b),'sha256':h}
 else:files[n]=p;seen[h]=n
for name in ['cat-pilot-reassessment','ownership-root-review']:
 j=json.loads((D/(name+'-opened.json')).read_text())[0];root=Path(j['project']);e=TaskEnvelope.from_json(Path(j['envelope']).read_text());a=json.loads(Path(j['attempt']).read_text());assert a['status']=='PASS' and verify_input_packet(e,root)[0]
 for x in e.input_packet:add(name+'/inputs/'+x.path,root/x.path)
 for p in Path(j['attempt']).parent.rglob('*'):
  if p.is_file() and p.name!='.closing':add(name+'/runtime/'+p.relative_to(Path(j['attempt']).parent).as_posix(),p)
 rows.append({'name':name,'inputs':len(e.input_packet),'status':a['status']})
for prefix in ['cat-pilot-handoff','cat-pilot-contracts','cat-pilot-validation','ownership-root-']:
 for p in I.glob(prefix+'*'):
  if p.is_file():add('root/'+p.name,p)
for n in ['assess_pilot.py','pilot-assessment.json','pilot-preservation-result.json','open_review.py','reopen_judgment.py','cat-pilot-reassessment-reopening.json','ownership-root-review-reopening.json','commission_ownership_review.py','commission_source_corridor.py','preserve_method_and_fix.py']:
 add('root/'+n,D/n)
for n in ['01_docs/findings.yaml','06_build/agent_handoff.yaml']:add('checkpoint/'+n,P/n)
(D/'method-fix-references.json').write_text(json.dumps(refs,indent=2)+'\n');files['root/method-fix-references.json']=D/'method-fix-references.json'
m={n:{'size':p.stat().st_size,'sha256':sha(p.read_bytes())} for n,p in files.items()};tmp=D/'method-fix-preserved.tar.gz'
with tarfile.open(tmp,'w:gz',compresslevel=3) as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
 b=(json.dumps({'members':m},indent=2)+'\n').encode();x=tarfile.TarInfo('MANIFEST.json');x.size=len(b);t.addfile(x,io.BytesIO(b))
h=sha(tmp.read_bytes());out=P/'01_docs/journal'/(h+'.tar.gz');assert not out.exists();shutil.copyfile(tmp,out)
with tarfile.open(out) as t:
 assert set(t.getnames())==set(m)|{'MANIFEST.json'}
 for n,x in m.items():b=t.extractfile(n).read();assert sha(b)==x['sha256'] and len(b)==x['size']
r={'archive':str(out),'sha256':h,'size':out.stat().st_size,'members':len(m),'references':len(refs),'tasks':rows};(D/'method-fix-preservation-result.json').write_text(json.dumps(r,indent=2)+'\n')
with (P/'01_docs/journal/contracts.md').open('a') as f:f.write(f'\n## Allowed corridor method reassessment and root-interface repair evidence\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Closed independent D-BACK and shared-tool review, exact original/fixed code and positive/hostile checks, spent-attempt assessment, raw closeout logs; no renewed corridor attempt or routed acceptance; reopen MANIFEST members and deduplicated references |\n')
print(json.dumps(r,indent=2))
