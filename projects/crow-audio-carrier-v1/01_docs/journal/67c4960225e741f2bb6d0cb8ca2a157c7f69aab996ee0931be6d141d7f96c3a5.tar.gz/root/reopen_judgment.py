from pathlib import Path
import json,hashlib,tarfile,sys
D=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/pcb-design/scripts'));from pipeline_execution import TaskEnvelope,verify_input_packet
name=sys.argv[1];j=json.loads((D/(name+'-opened.json')).read_text())[0];p=Path(j['output_dir']);e=TaskEnvelope.from_json(Path(j['envelope']).read_text());a=json.loads(Path(j['attempt']).read_text());assert a['status']=='PASS' and verify_input_packet(e,Path(j['project']))[0];sha=lambda b:hashlib.sha256(b).hexdigest()
for n,x in a['output']['completion']['outputs'].items():b=(p/n).read_bytes();assert len(b)==x['size'] and sha(b)==x['sha256']
m=json.loads((p/'evidence-manifest.json').read_text());rows=m['members'];rows=[dict(path=n,**x) for n,x in rows.items()] if isinstance(rows,dict) else rows
with tarfile.open(p/'evidence.tar.gz') as t:
 assert all(x.isfile() or x.isdir() for x in t.getmembers());assert len([x for x in t.getmembers() if x.isfile()])==len(rows);assert {x.name for x in t.getmembers() if x.isfile()}=={r['path'] for r in rows}
 for r in rows:b=t.extractfile(r['path']).read();assert sha(b)==r['sha256'] and len(b)==r['size']
arc=m.get('archive',m);b=(p/'evidence.tar.gz').read_bytes();assert sha(b)==arc['sha256'] and len(b)==arc['size'];result={'inputs':len(e.input_packet),'outputs':len(a['output']['completion']['outputs']),'archive_members':len(rows),'report_sha256':sha((p/'report.md').read_bytes()),'archive_sha256':arc['sha256']};(D/(name+'-reopening.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
