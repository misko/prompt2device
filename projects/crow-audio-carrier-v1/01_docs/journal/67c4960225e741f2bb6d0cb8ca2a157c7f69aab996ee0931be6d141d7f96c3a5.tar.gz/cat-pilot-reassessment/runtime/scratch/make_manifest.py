from pathlib import Path
import hashlib
import json
import sys
import tarfile

sys.dont_write_bytecode = True
run = Path("/tmp/carrier-cat-pilot-reassessment-sjj9ctm8/06_build/task_runs/cat-pilot-reassessment")
archive = run / "outputs/evidence.tar.gz"
rows = []
with tarfile.open(archive, "r:gz") as tf:
    for member in tf.getmembers():
        if not member.isfile():
            continue
        data = tf.extractfile(member).read()
        rows.append({"path": member.name, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()})
payload = {
    "schema": 1,
    "archive": {
        "path": "evidence.tar.gz",
        "size": archive.stat().st_size,
        "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
    },
    "member_count": len(rows),
    "members": rows,
}
(run / "outputs/evidence-manifest.json").write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
