from pathlib import Path
import os
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, "/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts")
from pipeline_runtime import run_stage

scratch = Path(__file__).resolve().parent
board = Path("/tmp/carrier-cat-pilot-reassessment-sjj9ctm8/project/04_kicad/crow_audio_carrier_v1.kicad_pcb")
argv = ["/usr/bin/kicad-cli", "pcb", "render", "--output", str(scratch / "board-top.png"), "--side", "top", str(board)]
result = run_stage(
    {"id": "readonly-board-render", "work_class": "local", "timeout_s": 90},
    argv,
    log_path=scratch / "board-render.log",
    cwd=board.parent,
    env=dict(os.environ),
    console_line_limit=20,
    console_tail_lines=10,
)
(scratch / "board-render.runtime.json").write_text(__import__("json").dumps(result.to_mapping(), indent=2) + "\n")
raise SystemExit(result.returncode)
