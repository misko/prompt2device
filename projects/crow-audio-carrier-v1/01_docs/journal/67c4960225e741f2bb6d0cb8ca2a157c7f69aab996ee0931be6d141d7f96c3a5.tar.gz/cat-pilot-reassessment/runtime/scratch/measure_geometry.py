from pathlib import Path
import json
import sys
import yaml

sys.dont_write_bytecode = True
root = Path("/tmp/carrier-cat-pilot-reassessment-sjj9ctm8")
floor = yaml.safe_load((root / "project/03_src/floorplan.yaml").read_text())
route = yaml.safe_load((root / "project/03_src/route.yaml").read_text())
north = next(item for item in floor["placement"]["repeat"] if item["name"] == "north_analog")
ox, oy = north["origin"]
px, py = north["pitch"]
source = {}
for ch in range(1, 5):
    cx = ox + (ch - north["index_from"]) * px
    source[ch] = {
        "bundle_center_x_mm": cx,
        "iso_center_y_mm": oy + (ch - north["index_from"]) * py + 7.1,
        "r_pd_p_x_mm": cx - 2.75,
        "r_pd_n_x_mm": cx + 2.75,
    }

adc = {}
for stub in route["prep"]["seed_stubs"]["stubs"]:
    net = stub.get("net", "")
    if len(net) == 5 and net.startswith("ADC") and net[3] in "1234" and net[4] in "PN" and stub.get("pin", "").startswith("U_ADC."):
        adc[net] = stub["segments"][0]["pts"][0][0]
dest = {ch: (adc[f"ADC{ch}P"] + adc[f"ADC{ch}N"]) / 2 for ch in range(1, 5)}
channel_inversions = []
for a in range(1, 5):
    for b in range(a + 1, 5):
        if (source[a]["bundle_center_x_mm"] - source[b]["bundle_center_x_mm"]) * (dest[a] - dest[b]) < 0:
            channel_inversions.append([a, b])
out = {
    "source": "project/03_src/floorplan.yaml + project/03_src/route.yaml",
    "north_source_bundles": source,
    "north_adc_destination_center_x_mm": dest,
    "source_channel_order_left_to_right": sorted(source, key=lambda c: source[c]["bundle_center_x_mm"]),
    "destination_channel_order_left_to_right": sorted(dest, key=dest.get),
    "channel_pair_inversions": channel_inversions,
    "channel_pair_inversion_count": len(channel_inversions),
    "two_conductors_per_channel_crossing_contribution": len(channel_inversions) * 4,
    "required_nets": 8,
    "required_pads": 32,
    "required_paths": 24,
    "required_pn_groups": 4,
}
print(json.dumps(out, indent=2, sort_keys=True))
