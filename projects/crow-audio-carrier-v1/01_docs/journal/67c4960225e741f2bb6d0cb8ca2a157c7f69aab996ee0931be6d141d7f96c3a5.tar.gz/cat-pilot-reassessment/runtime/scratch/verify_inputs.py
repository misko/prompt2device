from pathlib import Path
import hashlib
import json
import sys

sys.dont_write_bytecode = True
root = Path("/tmp/carrier-cat-pilot-reassessment-sjj9ctm8")
env = json.loads((root / "06_build/task_runs/cat-pilot-reassessment/envelope.json").read_text())
rows = []
for item in env["input_packet"]:
    path = root / item["path"]
    exists = path.is_file()
    size = path.stat().st_size if exists else None
    digest = hashlib.sha256(path.read_bytes()).hexdigest() if exists else None
    rows.append({
        "name": item["name"],
        "path": item["path"],
        "expected_size": item["size"],
        "actual_size": size,
        "expected_sha256": item["sha256"],
        "actual_sha256": digest,
        "verified": exists and size == item["size"] and digest == item["sha256"],
    })
result = {
    "envelope": "06_build/task_runs/cat-pilot-reassessment/envelope.json",
    "count": len(rows),
    "verified_count": sum(row["verified"] for row in rows),
    "all_verified": all(row["verified"] for row in rows),
    "rows": rows,
}
print(json.dumps(result, indent=2, sort_keys=True))
raise SystemExit(0 if result["all_verified"] else 1)
