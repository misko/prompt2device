#!/usr/bin/env python3
"""Typed preflight for one LAYOUT-001 evidence run; never accepts placement."""
from __future__ import annotations

import argparse
import contextlib
import datetime
import hashlib
import io
import json
import re
import sys
from pathlib import Path

NETS = ["ADC1P", "ADC1N", "ADC2P", "ADC2N", "ADC3P", "ADC3N", "ADC4P", "ADC4N"]
GROUPS = [f"ANALOG_CH{i}_ADC" for i in range(1, 5)]
STRICT_FIELD = re.compile(r"^[>\s*#`-]*([a-z][a-z0-9_-]*)\s*:\s*(.*?)\s*$", re.I)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def strict_fields(path: Path) -> dict[str, str]:
    """Parse every header field and reject duplicates instead of overwriting."""
    out: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        match = STRICT_FIELD.match(line)
        if not match:
            continue
        key = match.group(1).lower()
        if key in out:
            raise ValueError(f"duplicate review field {key}: {path}")
        out[key] = match.group(2).strip().strip("`*")
    return out


def expect(row: dict, key: str, wanted: str, failures: list[dict], owner: str) -> None:
    actual = row.get(key, "")
    if actual.lower() != wanted.lower():
        failures.append({"owner": owner, "field": key, "expected": wanted, "actual": actual})


def configured_path_matches(project: Path, configured: str, supplied: Path) -> bool:
    candidate = Path(configured)
    expected = (candidate if candidate.is_absolute() else project / candidate).resolve()
    return expected == supplied.resolve()


def admission_decision(failures: list[dict], schematic_rc: int, placement_rc: int) -> bool:
    """Only an otherwise-clean exact LAYOUT-001 INCOMPLETE report may proceed."""
    return schematic_rc == 0 and placement_rc == 1 and not failures


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("project", type=Path)
    ap.add_argument("--board", type=Path, required=True)
    ap.add_argument("--netlist", type=Path)
    ap.add_argument("--layout-review", type=Path, required=True)
    ap.add_argument("--kicad-scripts", type=Path, required=True)
    ap.add_argument("--json-output", type=Path, required=True)
    args = ap.parse_args()
    project, board = args.project.resolve(), args.board.resolve()

    # Import the shipped canonical checker and its shipped dependent APIs.
    scripts = args.kicad_scripts.resolve()
    sys.path.insert(0, str(scripts))
    import pre_route_review_check as pr
    from promoted_route_check import check as check_promoted_route

    cfg = pr.config(project)
    failures: list[dict] = []
    checks: dict[str, dict] = {}
    required_cfg = {"netlist", "topology", "schematic_render", "schematic_pdf",
                    "board", "pin", "layout", "render", "a_render"}
    for key in sorted(key for key in required_cfg if not cfg.get(key)):
        failures.append({"owner": "configuration", "field": key,
                         "error": "required pre_route_reviews path is absent"})
    if cfg.get("board") and not configured_path_matches(project, cfg["board"], board):
        failures.append({"owner": "configuration", "field": "board",
                         "error": "supplied board is not configured current board"})
    if cfg.get("layout") and not configured_path_matches(
            project, cfg["layout"], args.layout_review.resolve()):
        failures.append({"owner": "configuration", "field": "layout",
                         "error": "supplied layout review is not configured review path"})
    parts = sorted((project / "02_parts").glob("*/part.yaml"))
    if not parts:
        failures.append({"owner": "parts", "error": "no part.yaml files found"})
    parts_hash = hashlib.sha256(b"".join(
        p.relative_to(project).as_posix().encode() + b"\0" + p.read_bytes() + b"\0"
        for p in parts)).hexdigest()
    rules_hash = pr.design_rules_digest(project)
    board_hash = sha(board)

    netlist = (args.netlist.resolve() if args.netlist else
               pr.resolve(project, cfg.get("netlist", "")))
    netlist_hash = pr.netlist_digest(netlist)
    for kind in ("topology", "schematic_render"):
        config_key = kind
        path = pr.resolve(project, cfg.get(config_key, ""))
        row = strict_fields(path)
        expected = {"review_stage": "pre-route", "review_kind": kind,
                    "design_verdict": "SOUND", "netlist_sha256": netlist_hash,
                    "parts_sha256": parts_hash}
        if rules_hash:
            expected["design_rules_sha256"] = rules_hash
        if kind == "schematic_render":
            expected["schematic_pdf_sha256"] = sha(
                pr.resolve(project, cfg.get("schematic_pdf", "")))
        for key, wanted in expected.items():
            expect(row, key, wanted, failures, kind)
        checks[kind] = {"sound": not any(x.get("owner") == kind for x in failures),
                        "path": str(path), "sha256": sha(path), "fields": row}

    route_errors, route_note, footprints, vias, tracks = check_promoted_route(
        board, project / "03_src/route.yaml")
    checks["p_routebase"] = {"sound": not route_errors, "errors": route_errors,
                              "note": route_note, "footprints": footprints,
                              "vias": vias, "tracks": tracks}
    for item in route_errors:
        failures.append({"owner": "p_routebase", "error": item})

    locator_result = None
    locator_active = any(p.is_file() for p in (
        project / "03_src/rules/assembly_locator.yaml",
        project / "03_src/rules/policy_waivers.yaml",
        project / "06_build/pre_route/current_assembly/assembly_locator_manifest.json"))
    if locator_active:
        fab_scripts = scripts.parent.parent / "jlcpcb-fab/scripts"
        sys.path.insert(0, str(fab_scripts))
        from assembly_locator_check import project_check
        try:
            locator_result = project_check(project, board)
        except Exception as exc:
            failures.append({"owner": "a_locator", "error": f"{type(exc).__name__}: {exc}"})
    checks["a_locator"] = {"sound": not any(x["owner"] == "a_locator" for x in failures),
                           "active": locator_active, "result": locator_result}

    expected_common = {"review_stage": "pre-route", "board_sha256": board_hash,
                       "design_rules_sha256": rules_hash or ""}
    review_rows: dict[str, dict] = {}
    for kind in ("pin", "render"):
        path = pr.resolve(project, cfg.get(kind, ""))
        row = strict_fields(path)
        review_rows[kind] = {"path": str(path), "sha256": sha(path), "fields": row}
        expect(row, "review_stage", "pre-route", failures, kind)
        expect(row, "review_kind", kind, failures, kind)
        expect(row, "design_verdict", "SOUND", failures, kind)
        expect(row, "board_sha256", board_hash, failures, kind)
        if rules_hash:
            expect(row, "design_rules_sha256", rules_hash, failures, kind)
        if kind == "pin":
            expect(row, "parts_sha256", parts_hash, failures, kind)

    a_render_path = pr.resolve(project, cfg.get("a_render", ""))
    a_render = strict_fields(a_render_path)
    review_rows["a_render"] = {"path": str(a_render_path), "sha256": sha(a_render_path),
                                "fields": a_render}
    expect(a_render, "a-render_verdict", "PASS", failures, "a_render")
    expect(a_render, "board_sha256", board_hash, failures, "a_render")

    layout_path = args.layout_review.resolve()
    layout = strict_fields(layout_path)
    review_rows["layout"] = {"path": str(layout_path), "sha256": sha(layout_path),
                              "fields": layout}
    for key, wanted in expected_common.items():
        if wanted:
            expect(layout, key, wanted, failures, "layout")
    expect(layout, "review_kind", "layout", failures, "layout")
    expect(layout, "design_verdict", "INCOMPLETE", failures, "layout")
    expect(layout, "layout_finding", "LAYOUT-001", failures, "layout")
    expect(layout, "layout_finding_state", "OPEN", failures, "layout")
    expect(layout, "layout_finding_class", "missing_simultaneous_corridor_evidence", failures, "layout")
    expect(layout, "diagnostic_request", "bounded_saved_board_route_probe_or_simultaneous_corridor_reservation", failures, "layout")
    expect(layout, "diagnostic_nets", ",".join(NETS), failures, "layout")
    expect(layout, "diagnostic_pad_denominator", "32", failures, "layout")
    expect(layout, "diagnostic_path_denominator", "24", failures, "layout")
    expect(layout, "diagnostic_pn_groups", ",".join(GROUPS), failures, "layout")
    expect(layout, "diagnostic_max_spread_mm", "1.0", failures, "layout")
    expect(layout, "diagnostic_layers", "F.Cu,B.Cu", failures, "layout")
    expect(layout, "diagnostic_track_width_mm", "0.20", failures, "layout")
    expect(layout, "diagnostic_clearance_mm", "0.20", failures, "layout")
    expect(layout, "diagnostic_via_mm", "0.50/0.20", failures, "layout")
    expect(layout, "diagnostic_reference_plane_proof", "REQUIRED", failures, "layout")
    expect(layout, "diagnostic_promotion", "FORBIDDEN", failures, "layout")
    expect(layout, "context_mode", "FRESH", failures, "layout")
    expect(layout, "reviewer_provenance", "independent", failures, "layout")
    reviewer_id = layout.get("reviewer_id", "").strip()
    if not reviewer_id or reviewer_id.lower() == "root":
        failures.append({"owner": "layout", "field": "reviewer_id",
                         "error": "non-root independent reviewer identity required"})
    for key in ("raw_subject_sha256", "semantic_subject_sha256"):
        if not re.fullmatch(r"[0-9a-f]{64}", layout.get(key, "")):
            failures.append({"owner": "layout", "field": key,
                             "error": "exact task subject SHA256 required"})
    try:
        completed = datetime.datetime.fromisoformat(
            layout.get("completed_at_utc", "").replace("Z", "+00:00"))
        if completed.tzinfo is None:
            raise ValueError("timezone missing")
    except ValueError as exc:
        failures.append({"owner": "layout", "field": "completed_at_utc",
                         "error": str(exc)})
    try:
        blocking = json.loads(layout.get("blocking_finding_ids", ""))
    except json.JSONDecodeError as exc:
        blocking = None
        failures.append({"owner": "layout", "field": "blocking_finding_ids",
                         "error": str(exc)})
    if blocking != ["LAYOUT-001"]:
        failures.append({"owner": "layout", "field": "blocking_finding_ids",
                         "expected": ["LAYOUT-001"], "actual": blocking})

    # Execute the canonical full checker in-process. Its complete return code is
    # retained, but no stdout line is filtered or treated as authority.
    schematic_capture = io.StringIO()
    with contextlib.redirect_stdout(schematic_capture):
        schematic_rc = pr.main([str(project), "--phase", "schematic", "--netlist", str(netlist)])
    if schematic_rc != 0:
        failures.append({"owner": "canonical_schematic_review", "expected_rc": 0,
                         "actual_rc": schematic_rc})
    placement_capture = io.StringIO()
    with contextlib.redirect_stdout(placement_capture):
        placement_rc = pr.main([str(project), "--phase", "placement", "--board", str(board)])
    if placement_rc != 1:
        failures.append({"owner": "canonical_pr_review", "expected_rc": 1,
                         "actual_rc": placement_rc,
                         "reason": "diagnostic preflight requires the preserved layout-only FAIL"})

    nonlayout_owners = {"configuration", "parts", "topology", "schematic_render",
                        "canonical_schematic_review",
                        "p_routebase", "a_locator", "pin", "render", "a_render"}
    nonlayout_sound = not any(item.get("owner") in nonlayout_owners for item in failures)
    layout_request_exact = not any(item.get("owner") == "layout" for item in failures)
    admitted = nonlayout_sound and layout_request_exact and admission_decision(failures, schematic_rc, placement_rc)
    result = {
        "schema": 1,
        "subject": {"board_sha256": board_hash, "design_rules_sha256": rules_hash,
                    "parts_sha256": parts_hash},
        "canonical_schematic_review": {"returncode": schematic_rc,
                                        "verdict": "PASS" if schematic_rc == 0 else "FAIL",
                                        "full_stdout": schematic_capture.getvalue()},
        "canonical_placement_review": {"returncode": placement_rc, "verdict": "FAIL",
                                        "full_stdout": placement_capture.getvalue()},
        "checks": checks,
        "reviews": review_rows,
        "failures": failures,
        "diagnostic_admitted": admitted,
        "engineering_admitted": False,
        "production_routing_admitted": False,
        "promotion_admitted": False,
    }
    args.json_output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    return 0 if admitted else 1


if __name__ == "__main__":
    raise SystemExit(main())
