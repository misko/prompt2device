"""One owning KRT diagnostic after pcb_flow's durable reservation; no promotion."""
from pathlib import Path
import sys,json,os,argparse,hashlib,subprocess,yaml,copy
sys.dont_write_bytecode=True
ap=argparse.ArgumentParser();ap.add_argument('project',type=Path);ap.add_argument('--bindings',type=Path,required=True);args=ap.parse_args()
P=args.project.resolve();R=P.parents[1];D=Path(__file__).parent
sys.path.insert(0,str(R/'skills/pcb-design/scripts'));from pipeline_runtime import run_stage
sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'));import pre_route_review_check as pr
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());b=load(args.bindings)
def require(c,m):
 if not c:raise RuntimeError(m)
require((R/'.git').is_file(),'diagnostic must be an existing separate Git worktree')
require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==b['commit'],'worktree commit changed')
require(str(R)==b['worktree'],'wrong persistent worktree')
for n,h in b['files'].items():require(sha(P/n)==h,'stale input '+n)
for n,h in b['tools'].items():require(sha(R/n)==h,'stale tool '+n)
require(sha(D/'corridor_admission.py')==b['admission_sha256'],'stale admission helper')
require(sha(D/'current-pilot-config.yaml')==b['config_sha256'],'stale pilot config')
ledger=yaml.safe_load((P/'01_docs/findings.yaml').read_text());f=next(x for x in ledger['findings'] if x['id']=='LAYOUT-001-corridor-evidence');inv=f['investigation']
require(inv['max_attempts']==3 and inv['max_nonimproving_attempts']==3,'budget changed')
require(len(inv['history'])==2 and len(inv['launches'])==1,'expected two prior assessments and exactly one reserved dispatch')
require([x['id'] for x in inv['history']]==['custom-attempt-1','custom-attempt-2'],'historical attempts changed')
require(all(x['progress']==[] and x['model_domain']=='outside' for x in inv['history']),'historical geometry credit changed')
launch=inv['launches'][0];require(launch['id'] not in {x['id'] for x in inv['history']},'reservation already assessed')
# Atomic fresh directory refuses any rerun of this diagnostic after dispatch.
logs=P/'06_build/route/north_adc_pilot/runner_logs';logs.mkdir(parents=True,exist_ok=False)
records=[];terminal={'reservation':launch,'status':'INCOMPLETE','production_routing_admitted':False,'promotion_admitted':False}
def stage(name,argv,timeout):
 argv=list(map(str,argv));record={'name':name,'argv':argv,'cwd':str(P)}
 (logs/(name+'.command.json')).write_text(json.dumps(record,indent=2)+'\n')
 out=run_stage({'id':name,'work_class':'local','timeout_s':timeout},argv,log_path=logs/(name+'.log'),cwd=P,env=dict(os.environ),console_line_limit=5,console_tail_lines=3)
 record['runtime']=out.to_mapping();records.append(record);(logs/(name+'.runtime.json')).write_text(json.dumps(out.to_mapping(),indent=2)+'\n');return out.returncode
try:
 k=R/'skills/kicad-pcb/scripts';board=P/'04_kicad/crow_audio_carrier_v1.kicad_pcb'
 rc=stage('exact-admission',['/usr/bin/python3','-B',D/'corridor_admission.py',P,'--board',board,'--layout-review',P/'08_reviews/pre-route_layout.md','--kicad-scripts',k,'--json-output',logs/'admission.json'],120)
 require(rc==0 and load(logs/'admission.json')['diagnostic_admitted'],'current exact diagnostic admission failed')
 cfg=yaml.safe_load((D/'current-pilot-config.yaml').read_text());original=yaml.safe_load((P/'03_src/route.yaml').read_text());test=copy.deepcopy(cfg)
 for path in [('project','build_dir'),('prep','waves','groups'),('route','waves')]:
  a=test;o=original
  for key in path[:-1]:a=a[key];o=o[key]
  a[path[-1]]=o[path[-1]]
 require(test==original,'pilot changes more than build path and single net wave')
 nets=[f'ADC{i}{s}' for i in range(1,5) for s in ['P','N']];wave=cfg['route']['waves'];require(len(wave)==1 and wave[0]['nets']==nets,'wrong wave/net census')
 require(all(cfg['route'][key]['mode']=='enforce' for key in ['ownership_preflight','candidate_grade','exploration_guard']),'owning gates must enforce')
 config=logs/'pilot-config.yaml';config.write_bytes((D/'current-pilot-config.yaml').read_bytes())
 require(stage('pilot-prep',['/usr/bin/python3','-B',k/'route_and_stitch_generic.py','prep',config,'--root',P],180)==0,'native prep failed')
 build=logs.parent
 for ext in ['kicad_pcb','kicad_pro','kicad_dru']:
  require(sha(build/('r0.'+ext))==b['files']['06_build/route/r0.'+ext],'prepared r0 identity changed '+ext)
 require(stage('pilot-route',['/usr/bin/python3','-B',k/'route_and_stitch_generic.py','route',config,'--root',P,'--through-wave','north_adc_pilot'],1800)==0,'owning route failed; third attempt spent')
 receipts=list((build/'candidate_grades').glob('*/receipt.json'));require(len(receipts)==1,'expected exactly one candidate receipt')
 require(stage('verify-receipt',['/usr/bin/python3','-B',k/'route_candidate_workspace.py','verify',receipts[0]],180)==0,'receipt verification failed')
 receipt=load(receipts[0]);require(receipt['verdict']=='ACCEPTED' and receipt['required_nets']==sorted(nets),'candidate incomplete or wrong scope')
 connectivity=load(receipts[0].parent/'connectivity.json');require(connectivity['pad_coverage']=={n:4 for n in sorted(nets)},'32-pad census incomplete')
 candidate=build/'r1.kicad_pcb';require(sha(candidate)!=sha(build/'r0.kicad_pcb'),'no saved geometry')
 rc=stage('adc-path-lengths',['/usr/bin/python3','-B',k/'copper_length_audit.py',P,'--board',candidate,'--json-output',logs/'lengths.json','--json'],180)
 require(rc in [0,1],'length audit did not grade')
 lengths=load(logs/'lengths.json');groups={x['name']:x for x in lengths['groups']};target=[groups[f'ANALOG_CH{i}_ADC'] for i in range(1,5)]
 require(all(x['verdict']=='PASS' for x in target),'four ADC P/N groups not passing')
 require(sum(len(x.get('electrical_paths',[])) for x in target)==24,'24 paths unmeasured')
 terminal.update(status='ROUTE_CANDIDATE_REQUIRES_FILLED_REFERENCE_AND_INDEPENDENT_REVIEW',candidate=str(candidate),candidate_sha256=sha(candidate),pads=32,paths=24,pn_groups=4)
except Exception as e:
 terminal.update(status='STOPPED',error=f'{type(e).__name__}: {e}');raise
finally:
 terminal['commands']=records;terminal['immutable_inputs_changed']=[n for n,h in b['files'].items() if sha(P/n)!=h];terminal['immutable_tools_changed']=[n for n,h in b['tools'].items() if sha(R/n)!=h]
 (logs/'terminal.json').write_text(json.dumps(terminal,indent=2)+'\n')
 require(not terminal['immutable_inputs_changed'] and not terminal['immutable_tools_changed'],'immutable source changed')
