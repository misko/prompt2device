from pathlib import Path
from datetime import datetime,timezone
import sys,os,json,hashlib,traceback,yaml
sys.dont_write_bytecode=True
H=Path(__file__).parent;b=json.loads((H/'pilot-bindings.json').read_text());P=Path(b['project']);R=P.parents[1];sys.path.insert(0,str(R/'skills/pcb-design/scripts'));from pipeline_execution import TaskEnvelope,verify_input_packet;from pipeline_runtime import run_stage
cfg=json.loads((H/'worker-config.json').read_text());e=TaskEnvelope.from_json(Path(cfg['envelope']).read_text());A=Path(cfg['envelope']).parent;S=A/'scratch';O=A/'outputs';rows=[];error=None
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,argv,limit):
 remaining=(datetime.fromisoformat(cfg['work_cutoff'])-datetime.now(timezone.utc)).total_seconds()-120
 if remaining<limit:raise RuntimeError('Insufficient remaining time for '+name)
 r=run_stage({'id':name,'work_class':'local','timeout_s':limit},list(map(str,argv)),log_path=S/(name+'.log'),cwd=P,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),console_line_limit=5,console_tail_lines=3)
 row={'stage':name,'argv':list(map(str,argv)),'cwd':str(P),'runtime':r.to_mapping()};rows.append(row);(S/(name+'.runtime.json')).write_text(json.dumps(row,indent=2)+'\n');return r
try:
 assert verify_input_packet(e,P)[0];assert sha(P/'01_docs/findings.yaml')==b['initial_ledger_sha256']
 q=run('qualification',['/usr/bin/python3','-B',R/'skills/kicad-pcb/scripts/pcb_flow.py','qualify',P],180)
 if q.returncode==0:
  # Exactly one call. Dispatch owns the durable reservation before runner starts.
  run('guarded-diagnostic',['/usr/bin/python3','-B',R/'skills/kicad-pcb/scripts/pcb_flow.py','run',P,'--stage','routing','--investigation','LAYOUT-001-corridor-evidence','--budget-s','2100','--timeout-s','2100','--','/usr/bin/python3','-B',H/'current_pilot_runner.py',P,'--bindings',H/'pilot-bindings.json'],2130)
except Exception as ex:error=repr(ex);(S/'worker-error.txt').write_text(traceback.format_exc())
finally:
 ok=verify_input_packet(e,P)[0];closed=bool(rows) and all(x['runtime']['status'] in ['PASS','FAIL','TIMEOUT'] for x in rows);complete=error is None and ok and closed
 ledger=yaml.safe_load((P/'01_docs/findings.yaml').read_text());inv=next(x['investigation'] for x in ledger['findings'] if x['id']=='LAYOUT-001-corridor-evidence')
 t=P/'06_build/route/north_adc_pilot/runner_logs/terminal.json';terminal=json.loads(t.read_text()) if t.is_file() else None
 ev={'runs':rows,'error':error,'input_verified':ok,'launches':inv['launches'],'terminal':terminal,'scope':'One native qualification and at most one durable guarded diagnostic dispatch; no engineering/promotion acceptance; root owes same-reservation terminal assessment.'}
 for n in ['evidence.json','execution.json']:(O/n).write_text(json.dumps(ev,indent=2)+'\n')
 with (O/'execution.log').open('wb') as out:
  for row in rows:out.write(('\nARGV '+json.dumps(row['argv'])+'\nCWD '+str(P)+'\n').encode());out.write(Path(row['runtime']['log_path']).read_bytes())
 (O/'report.md').write_text('# Bounded owning corridor diagnostic\n\n'+'\n'.join('- '+x['stage']+': rc='+str(x['runtime']['returncode'])+', elapsed='+str(x['runtime']['elapsed_s'])+'s' for x in rows)+'\n- Terminal: '+json.dumps(terminal.get('status') if terminal else None)+'\n- Root owes assessment under exact reservation; no retry/promotion.\n'+('- Error: '+error+'\n' if error else ''))
 (O/'result.json').write_text(json.dumps({'subject':e.subject.to_mapping(),'checks':{'inputs-verified':'PASS' if ok else 'FAIL','raw-run-recorded':'PASS' if rows else 'FAIL','processes-closed':'PASS' if closed else 'FAIL'},'unresolved':[] if complete else [error or 'delivery incomplete']},indent=2)+'\n')
 print(json.dumps({'complete':complete,'error':error,'launches':inv['launches'],'terminal':terminal.get('status') if terminal else None},indent=2))
raise SystemExit(0 if complete else 1)
