# LAYOUT-001 diagnostic admission repair

Engineering verdict: **no source or skill-contract clarification is required before current placement regeneration. No diagnostic launch is currently admissible.** Existing authority already permits bounded evidence-producing investigation while an upstream gate remains red, and separately forbids treating that work as acceptance or promotion. The current packet lacks an exact current layout review and its exact current render review is `DEFECTIVE`, so the prerequisite is not satisfied.

## Owning boundary and applicable authority

`lifecycle-and-backtrack.md` lines 172–180 authorizes recurring investigations through the existing `01_docs/findings.yaml` plus `decision_progress.py` and `pcb_flow.py run --investigation`; it says `REASSESS` stops that launch rather than the whole project and allows bounded architecture comparison. Lines 219–231 preserve cumulative history across source revisions and require the named dispatch seam to reserve before launch, with failed dispatch assessed under the same reservation. Lines 265–280 require speculative downstream work to live in an isolated permanent worktree and forbid promotion while the upstream gate is red.

This authority is sufficient for evidence generation. It does not make `PR-REVIEW` pass. The canonical checker requires exact `SOUND` topology, schematic-render, pin, layout, and render reviews, exact hashes, `A-RENDER PASS`, route-base integrity, and locator integrity. The proposed diagnostic deliberately retains canonical placement review return code 1 / `PR-REVIEW FAIL` because the exact layout report remains `INCOMPLETE`. Only a later fresh independent exact-candidate/layout review can close or retain `LAYOUT-001`.

No source change is needed, so there is no source-comment or contract staleness impact. A future general reusable feature could expose a typed `pre_route_review_check` result API, but that is broader than this one already-authorized investigation and is not a prerequisite.

## Why the old proposal is not admissible

The old runner has four concrete admission failures:

1. It trusts an arbitrary root-authored JSON decision and bespoke copied ledger. Neither is the repository's durable cumulative reservation.
2. It parses canonical stdout with a regular expression and accepts a subset of failure prefixes. Unrelated canonical failures can be missed, and render is explicitly bypassed.
3. It binds stale board/prepared hashes (`0d80...` / `d380...`) rather than the next exact current board and exact current reviews.
4. It copies the project to an arbitrary proof root. Canon requires speculative downstream work in an isolated permanent worktree while placement acceptance is red.

The old proposal must not be edited into another owner exception. Retire its `owner-admission.template.json`, `cumulative-attempt-ledger.json`, root-copy execution path, and failure-text filtering.

## Smallest authorized replacement

After root finishes the current canonical regeneration, pin/render work, and commissions one fresh exact-board layout review, create one dedicated persistent Git worktree pinned to that reviewed commit. The independent layout report must remain `INCOMPLETE` and explicitly request only a bounded saved-board route probe or simultaneous corridor reservation for `LAYOUT-001`. Add machine-readable review headers binding the exact scope: eight named ADC nets; 32 pads; 24 paths; four `ANALOG_CH1_ADC` through `ANALOG_CH4_ADC` P/N groups at 1.0 mm; F.Cu/B.Cu; 0.20/0.20 mm track/clearance; 0.50/0.20 mm via; filled-reference-plane proof required; promotion forbidden.

The preflight also requires that the supplied layout file resolve to the configured `flow.pre_route_reviews.layout` path, so an alternate good-looking file cannot mask the canonical file. The review headers must bind a non-root reviewer ID, `reviewer_provenance: independent`, `context_mode: FRESH`, a timezone-bearing completion date, raw and semantic task-subject SHA-256 values, and the unique JSON array `blocking_finding_ids: ["LAYOUT-001"]`. Any other blocking finding makes the diagnostic inadmissible.

Run the proposed typed preflight in that worktree. It uses the shipped canonical hash/parser helpers, `promoted_route_check.check`, and `assembly_locator_check.project_check`; records every typed row; requires current `SOUND` topology, schematic render, pin and render; requires `A-RENDER PASS`; requires route-base and locator success; and executes both canonical checker phases in-process. It does not select or ignore stdout lines. Admission requires schematic return code 0 and placement return code 1, with the placement failure explained solely by the exact typed layout-request fields. The full canonical stdout remains evidence, not an admission predicate.

Add the proposed `LAYOUT-001-corridor-evidence` investigation row to the existing live `01_docs/findings.yaml` before dispatch, replacing every placeholder with hashes of actual project-relative evidence. Its total cap is three. Attempts 1 and 2 are preserved as historical assessments with zero route geometry; the independent D-BACK can credit only the decision milestone that rejects the custom model. With two assessed attempts and a cap/non-improvement limit of three, `decision_progress.py` must return `CONTINUE_BOUNDED` once before attempt 3.

Dispatch exactly once through the shipped API:

```text
/usr/bin/python3 skills/kicad-pcb/scripts/pcb_flow.py run DIAGNOSTIC_WORKTREE --stage routing --investigation LAYOUT-001-corridor-evidence --timeout-s <finite> -- /usr/bin/python3 CURRENT_PILOT_RUNNER.py ...
```

`pcb_flow.py` evaluates the named investigation, calls `reserve_launch(...)`, appends a `launch-*` reservation using the current tree hash, prints the reservation ID, and only then dispatches. The pilot runner must recompute the typed preflight after reservation, bind the exact current board/config/rules, contain exactly one eight-net KRT wave, and retain ownership preflight, candidate grading and exploration guard in enforce mode. It writes normal route candidate receipts below that worktree's `06_build`; it does not import, tap, stitch, promote, or mutate canonical source.

Whether dispatch itself fails, preflight becomes stale, KRT fails, or the probe completes, append one evidence-bound history observation using the same `launch-*` ID and subject hash, `origin: executed`, and the actual terminal result. A failed dispatch is attempt 3, not a retry opportunity. The evaluator must then report `REASSESS` because `max_attempts: 3`; attempt 4 is refused. Do not enlarge the cap, rename the finding, branch from an old attempt, or invoke a different folder to reclaim spend.

## Exact proof and stop conditions

The one diagnostic binds exactly eight nets (`ADC1P/N` through `ADC4P/N`), 32 target pads, 24 declared branches/paths, and four P/N tree groups. It must retain current `route.yaml`, `nets.yaml`, board, project/rule sidecars, source seed copper and non-owned copper identities. Stop on any stale input; ownership, route-base, locator, prep, KRT, receipt-verification or native-grade failure; any missing denominator; any required-net open; unchanged candidate copper; unowned mutation; illegal via; new hard DRC; path-group failure; or missing filled-return evidence.

A successful candidate receipt is only corridor evidence. Fresh independent review must inspect the exact candidate, including filled In1.Cu/In2.Cu GND continuity at every transition and all 24 path measurements. Canonical `PR-REVIEW` remains `FAIL` until that exact layout review is `SOUND`; production routing, placement acceptance, layout seal, fabrication, release, and order authority remain forbidden.

## Delivered proposal and validation

The evidence archive contains:

- `proposed-admission-gate.py`: concrete typed preflight skeleton using shipped APIs, parameterized for the future current board. It was syntax-parsed only; it was not executed against a board because the required future board/reviews do not exist in this packet and dependent shipped modules were intentionally not supplied.
- `proposal-selftest.py`: pure fail-closed tests proving that configured/alternate layout-path mismatch and an unrelated review failure are rejected.
- `proposed-findings-row.yaml`: exact schema-1 durable investigation row with placeholders that must be replaced from retained project evidence.
- `dispatch-sequence.txt`: exact preflight, evaluator, reservation/dispatch, and terminal-assessment sequence using a persistent worktree.
- `input-verification-before.json` and `input-verification-after.json`: complete 30/30 packet input size/SHA checks.

No KRT, KiCad, pcbnew, PDF, route, layout acceptance, source mutation, new attempt reservation, native child, or board-model process was executed. No visual inspection was needed for this source-contract diagnosis; the engineering geometry verdict remains inherited from the exact independent reports and is not reissued here.
