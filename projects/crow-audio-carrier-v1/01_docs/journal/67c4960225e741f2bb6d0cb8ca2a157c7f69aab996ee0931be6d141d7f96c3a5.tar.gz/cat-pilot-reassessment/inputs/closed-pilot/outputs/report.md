# Bounded owning corridor diagnostic

- qualification: rc=0, elapsed=9.238751s
- guarded-diagnostic: rc=1, elapsed=7.269257s
- Terminal: "STOPPED"
- Root owes assessment under exact reservation; no retry/promotion.
