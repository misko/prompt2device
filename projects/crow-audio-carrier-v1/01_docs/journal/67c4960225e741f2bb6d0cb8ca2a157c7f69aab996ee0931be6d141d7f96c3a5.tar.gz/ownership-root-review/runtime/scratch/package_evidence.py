#!/usr/bin/env python3
import hashlib
import json
import tarfile
from pathlib import Path

SCRATCH = Path("/tmp/carrier-ownership-root-review-johm_sh5/06_build/task_runs/ownership-root-review/scratch")
OUTPUTS = Path("/tmp/carrier-ownership-root-review-johm_sh5/06_build/task_runs/ownership-root-review/outputs")
archive = OUTPUTS / "evidence.tar.gz"
members = []
files = sorted(p for p in SCRATCH.rglob("*") if p.is_file())
with tarfile.open(archive, "w:gz") as tf:
    for path in files:
        rel = path.relative_to(SCRATCH).as_posix()
        tf.add(path, arcname=rel, recursive=False)
        data = path.read_bytes()
        members.append({"path": rel, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()})
blob = archive.read_bytes()
manifest = {
    "schema": 1,
    "archive": {"path": "evidence.tar.gz", "size": len(blob), "sha256": hashlib.sha256(blob).hexdigest()},
    "members": members,
}
(OUTPUTS / "evidence-manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
