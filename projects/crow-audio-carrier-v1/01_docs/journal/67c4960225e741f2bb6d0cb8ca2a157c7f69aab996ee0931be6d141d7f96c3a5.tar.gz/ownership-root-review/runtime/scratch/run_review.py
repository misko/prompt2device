#!/usr/bin/env python3
import hashlib
import json
import os
import sys
from pathlib import Path

sys.dont_write_bytecode = True
LIVE = Path("/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901")
SCRATCH = Path("/tmp/carrier-ownership-root-review-johm_sh5/06_build/task_runs/ownership-root-review/scratch")
sys.path.insert(0, str(LIVE / "skills/pcb-design/scripts"))
sys.path.insert(0, str(LIVE / "skills/kicad-pcb/scripts"))
from pipeline_runtime import run_stage
from pre_route_review_check import design_rules_digest

env = dict(os.environ)
env["TMPDIR"] = str(SCRATCH / "tmp")
(SCRATCH / "tmp").mkdir(parents=True, exist_ok=True)
command = ["/usr/bin/python3", "-B", "skills/kicad-pcb/scripts/tests/test_route_ownership_preflight.py"]
outcome = run_stage(
    {"id": "ownership-root-independent-focused", "work_class": "local", "timeout_s": 45, "produces": []},
    command,
    log_path=SCRATCH / "current-focused.log",
    cwd=LIVE,
    env=env,
    heartbeat_s=5,
)
(SCRATCH / "current-focused-runtime.json").write_text(json.dumps(outcome.to_mapping(), indent=2) + "\n")
(SCRATCH / "current-focused-command.json").write_text(json.dumps({"argv": command, "cwd": str(LIVE), "TMPDIR": env["TMPDIR"]}, indent=2) + "\n")
project = LIVE / "projects/crow-audio-carrier-v1"
board = project / "04_kicad/crow_audio_carrier_v1.kicad_pcb"
facts = {
    "board_sha256": hashlib.sha256(board.read_bytes()).hexdigest(),
    "board_size": board.stat().st_size,
    "design_rules_sha256": design_rules_digest(project),
}
(SCRATCH / "project-digests.json").write_text(json.dumps(facts, indent=2) + "\n")
raise SystemExit(0 if outcome.returncode == 0 else 1)
