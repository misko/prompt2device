subject: crow-audio-carrier-v1 shared route-ownership root propagation fix
source_commit: b436d612c8d2d325204ebd253f4c885bd66943ee
date: 2026-09-11
reviewer: Codex independent judgment agent /root/carrier_ownership_root_review
context-given: FRESH; immutable packet plus explicitly permitted read-only live modules/tests
subject_raw_sha256: 363e692715570d5f1552b47e3854441387e806cbf9f01fb12460a2cd2837d3b7
subject_semantic_sha256: c8608146894c71dc99e65c0f2219a3412aff7fe8dddc5665262f34813b8b00eb
board_sha256: 9aa1c2c821a31129176a8b519b9a211d78dfc011adb997a64470c03d0726891f
design_rules_sha256: 0637fdb2d3f5ab247c301147ad6ed875343674c225e5036a2bb1935bd025cec3
review_stage: pre-route
review_kind: shared-tool code and gate-interface review
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
engineering_verdict: SOUND
process_verdict: COMPLETE
scope: root propagation, authority containment, source/build compatibility, and regression evidence only
diagnostic_id: LAYOUT-001-corridor-evidence
diagnostic_status: OPEN; reservation 3/3 spent; no retry credit
locator_metadata: N/A for shared-tool code review; no locator or board evidence regraded
completed_at: 2026-09-12T01:49:00Z

# Independent root-propagation review

The exact fix is **SOUND** for this code-review lens. The driver now passes its already-resolved `cfg['_root']` to the ownership checker. With `--root`, the checker resolves the root strictly, admits only resolved configs under that project's `03_src` or `06_build`, rejects a nested `03_src` whose parent disagrees with the explicit root, and contains the resolved board and rules paths within the project. A build config always obtains rule authority from `03_src/rules/nets.yaml`; an adjacent `06_build/.../rules/nets.yaml` cannot shadow it. A source config retains the previous route-local ADR-0007 board-rule preference and top-level fallback. Without `--root`, configs outside `03_src` remain INCOMPLETE.

The ordering of checks is fail-closed for the reviewed threats. Config and board escapes are rejected before the native board reader. A symlinked build directory resolves outside the project and fails containment. A rules symlink resolves outside the project and fails containment. A mismatched root fails either config containment or the `03_src` ancestry equality. Missing canonical rules are fatal for build configs. The explicit-root branch does not widen board or rules authority, and the repair introduces **no new admission loophole found**.

The exact current focused suite passed **16/16 test methods** in an independently bounded run with `TMPDIR` inside allocated scratch. Its root-control class covers **12/12 methods and 13/13 exercised configurations**: four positive configurations (canonical source without root, nested canonical source with root and board-local rules, build copy with root and source rules, driver propagation) and nine hostile configurations (build copy without root; two mismatched-root config locations; build-rule shadowing; config symlink escape; external board; build-directory symlink escape; missing source rules; rules symlink escape). The four original O-PWR/O-DOUBLE/owned-power/corridor methods also pass, so those decisions are unchanged.

The supplied pre-fix raw log is exact RED evidence for its then-current 12-test version: **12 tests, 1 failure and 6 errors** against the old checker/driver hashes. It demonstrates absent `--root` parsing and absent driver propagation. It does not cover every later-added final case, and I do not claim that it does. The supplied intermediate GREEN log passed 15/15 before the nested-source case was added; my current run passed the final 16/16. Separately, the supplied owning boundary suite passed 10/10 (eight known-bad fixtures failed their checker as required), and the supplied contract audit returned `G-CONTRACT OK` for 99 verdict-printing scripts. Those denominators are reported separately and are not added to the 16 focused tests.

Changed-file identity is exact. The live hashes equal the packet hashes for `route_and_stitch_generic.py` (`84c57f...`), `route_ownership_preflight.py` (`4105c3...`), and `test_route_ownership_preflight.py` (`ca559d...`). The packet also binds the updated script contract (`5632f5...`) and owning safety suite (`31456b...`). Pre-fix owning files are bound as `route-driver-before.py` (`2e00e4...`) and `ownership-before.py` (`ae2253...`). All 33/33 packet inputs passed exact size and SHA-256 verification before review and again at delivery preflight.

No board source, admission state, geometry, route candidate, or cap was changed. This finding closes only the shared-tool repair review. `LAYOUT-001` remains spent at 3/3 and open; this SOUND code verdict does not authorize route execution, gate acceptance, board release, or another diagnostic attempt. The board hash and owning design-rules digest identify the current project context only; no geometric or physical judgment was performed.

No corrective patch is proposed because no concrete defect was found. Visual inspection was not applicable to this source-only gate-interface change; no image was used as evidence.
