review_stage: pre-route
review_kind: bounded layout policy/applicability gap
reviewer: fresh independent agent /root/rj45_carrier_layout_gap_policy1
design_verdict: DEFECTIVE
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
prepared_board_sha256: b75acca754b864d8c69df51b8343f21cf01ec9640325216c5e96f466f83861b1
design_rules_sha256: 3557aa03b99862ddb349413882ea7905a017465b7d72ff8fbcf427b1cf6a67de
native_dru_sha256: c86b53ca8630718200667bc19a6633971f0967b2a546a8fb1b63c7b544d314f5
canon_sha256: e0b7acf3acd4b0c1a7c37e55a1a155ab79c859835b76c1c6c1e2234fa49d3892

The requested bounded policy/applicability review is complete. Its scoped verdict is DEFECTIVE because the frozen ownership and copper-gap requirements remain unwaived and the module-decision inventory is incomplete. This is not a full-board verdict. No source, board, checker, threshold, waiver or live file was changed. DO-NOT-ORDER persists. The exact envelope subject and hashes are in evidence.json.

## Findings and governing applicability

### POL-01 — P5/P-SILK-OWN: DEFECTIVE
Each scoped jack owns zero nearby board legend in the frozen mixed-side J/F/TP family. Each CH label is nearer its opposite-side fuse by0.881620mm. The canon and checker provide no side exception.

Severity: unwaived policy gate failure; no electrical malfunction inferred. Owner: source floorplan/silkscreen owner.
Minimum correction: Move the eight existing CH legends into their own jack ownership regions while preserving native ink clearance and physical legibility. Closest point to the J/F bisector is1.220570571mm away (J4 differs by0.000001338mm); strict nearer requires more. Diagnostic candidate points are not accepted placements. Do not add duplicate labels, waive the rule, or adopt an ungoverned side filter.

### POL-02 — P8/P-ADJ-PAIR: DEFECTIVE
Native rounded copper-edge gap2.511520906650mm exceeds2.500mm by0.011520906650mm. Source bounding boxes give2.472473457896mm. A source layout note defines a bbox approximation but cannot override canon copper-edge-to-edge P-ADJ-PAIR.

Severity: unwaived copper-gap budget excess, not native DRC clearance or demonstrated malfunction. Owner: source placement/part-layout-rule owner.
Minimum correction: Move one endpoint sufficiently closer without weakening2.5mm. A pure +Y R_PWR_PU translation needs>0.011950541431mm; source anchor[32.4,53.92,90] would reduce this isolated analytical gap to2.492242051067mm. This is a diagnostic bound only; author and regenerate the smallest one-ref correction, then recheck affected adjacency/clearance/placement before acceptance.

### POL-03 — P-MOD: DEFECTIVE
The recorded ADC module comparison is substantively present and checker1/1 passes with exact ADR supplement. However, integration.yaml inventories only CS5308P and omits AP63205 switching-power control at U_BUCK; the conservative checker regex does not recognize synchronous_buck_converter. The13-entry ADC support_refs also includes U_ADC itself, contrary to external-support inventory semantics.

Severity: source decision/inventory coverage defect. Owner: source integration-policy owner.
Minimum correction: Add an explicit complexity-weighted U_BUCK decision and accurate external support inventory, and remove U_ADC itself from the ADC external-support list while completing that list against current source. At least9 distinct BUCK-named external supports are present; threshold10 applies to the complete inventory, not to a chosen subset. Below threshold a rationale suffices; at/above it retain ADR/cited module comparison. No hardware/module replacement is implied.

The P-SILK-REF proposal names a different policy and grants no P-SILK-OWN or P-ADJ-PAIR relief. Opposite-side geometric ownership can be a poor proxy for actual user confusion, but the frozen P5 rule explicitly includes the whole J/F/TP family; neither text nor footprint side removes a rival. No current render/locator usability judgment is inferred. Likewise, the source dossier calls its2.5mm number an engineering ceiling and its source-only measurement a rotation-aware bbox gap. That statement explains the numerical discrepancy; it does not replace the higher-authority P8 requirement for copper edge-to-edge gap. Both are policy violations, not evidence of demonstrated electrical malfunction.

All8 scoped J refs have2 nearby board legends and0 owned legends under an independently evaluated Voronoi half-plane intersection. Family denominator20, board-text denominator29. The native difference is a rounded-corner effect: U_PWR.6 radius0.050mm, R_PWR_PU.2 radius0.135mm, bbox separations0.530mm and2.415mm. The true gap is sqrt((0.530+0.185)^2+(2.415+0.185)^2)-0.185 =2.511520906650mm. Native collision changes from false at2.511520mm clearance to true at2.511521mm. The bbox underestimates copper separation by0.039047448754mm. The prior report’s0.011520mm excess was integer-resolution truncation of this result.

| Jack/label | Label XY mm | Rival | Own distance mm | Rival distance mm | Lead mm |
|---|---|---|---|---|---|
| J1/CH1 | [40.5, 34.5] | F1 B.Cu | 9.741642572 | 8.860022573 | -0.881619999 |
| J2/CH2 | [72.5, 34.5] | F2 B.Cu | 9.741642572 | 8.860022573 | -0.881619999 |
| J3/CH3 | [104.5, 34.5] | F3 B.Cu | 9.741642572 | 8.860022573 | -0.881619999 |
| J4/CH4 | [136.5, 34.5] | F4 B.Cu | 9.741642572 | 8.860023510 | -0.881619062 |
| J5/CH5 | [40.5, 105.5] | F5 B.Cu | 9.741642572 | 8.860022573 | -0.881619999 |
| J6/CH6 | [72.5, 105.5] | F6 B.Cu | 9.741642572 | 8.860022573 | -0.881619999 |
| J7/CH7 | [104.5, 105.5] | F7 B.Cu | 9.741642572 | 8.860022573 | -0.881619999 |
| J8/CH8 | [136.5, 105.5] | F8 B.Cu | 9.741642572 | 8.860022573 | -0.881619999 |

## Package and identity coverage

P-ESC/P-TIER: SOUND within frozen package-budget scope. All58 selected families are resolved;19 multi-pin families/52 physical refs require recomputation. The39 remaining selected families have<=2 declared pins and do not incur the multipin package obligation. All19 declared blocks agree, no conditional block is claimed, and no required tier exceeds jlc_4layer_advanced. Across52 realized refs the per-pin-pair distance multisets match their family representative exactly (maximum difference0mm). This proves geometry consistency for package budgeting, not all-net simultaneous escape or completed routing. The advanced order process and fabrication-specific via obligations remain later gates.

| Family | Refs | Style | Pitch mm | Required tier |
|---|---|---|---|---|
| 2N7002K-7 | Q_RST1, Q_PRE_EN | leaded | 0.95 | jlc_2layer_default |
| 615008160221 | J1, J2, J6, J5, J8, J7, J3, J4 | connector | 2.04 | jlc_2layer_default |
| 74LVC1G14GV,125 | U_DUMP, U_LDO_EN, U_OE | leaded | 0.95 | jlc_2layer_default |
| 74LVC1G17GV,125 | U_TDM_SCH | leaded | 0.95 | jlc_2layer_default |
| AO3400A | Q_DUMP | leaded | 0.95 | jlc_2layer_default |
| AO3401A | Q_PRE | leaded | 0.95 | jlc_2layer_default |
| AP63205WU-7 | U_BUCK | leaded | 0.95 | jlc_2layer_default |
| CS5308P-DN | U_ADC | qfn | 0.4 | jlc_4layer_advanced |
| DMP6023LFG-13 | Q_IN | dfn | 0.65 | jlc_4layer_standard |
| LT3041ADE-TRPBF | U_LDO | dfn | 0.5 | jlc_4layer_advanced |
| OPA2320AIDR | U_AFE3, U_AFE8, U_AFE4, U_AFE7, U_AFE5, U_AFE6, U_AFE2, U_AFE1 | leaded | 1.27 | jlc_2layer_default |
| SN74LVC1G123DCTR | U_RST2 | leaded | 0.65 | jlc_2layer_default |
| SN74LVC1G125DBVR | U_TDM | leaded | 0.95 | jlc_2layer_default |
| SN74LVC3G34DCUR | U_CLK | leaded | 0.5 | jlc_2layer_default |
| TMM-106-01-L-D | J11, J10 | connector | 2.0 | jlc_2layer_default |
| TMUX2821DSGR | U_ISO2, U_ISO4, U_ISO6, U_ISO5, U_ISO3, U_ISO1, U_ISO8, U_ISO7 | dfn | 0.5 | jlc_4layer_advanced |
| TPD2E2U06DRLR | U_ESD3, U_ESD4, U_ESD8, U_ESD2, U_ESD7, U_ESD6, U_ESD1, U_ESD5 | leaded | 0.5 | jlc_2layer_default |
| TPS3839K33DBZR | U_RST1 | leaded | 0.95 | jlc_2layer_default |
| TPS389001DSER | U_AUDIO, U_PWR | dfn | 0.5 | jlc_4layer_advanced |

Fourteen families compute default2-layer escape, DMP6023LFG computes4-layer-standard, and CS5308P/LT3041/TMUX2821/TPS389001 compute4-layer-advanced. Ring sum at default is0.727mm, standard0.577mm, advanced0.340mm; advanced supports0.4/0.5mm ring pitches. The three-pin SOT23 patterns contain same-side contacts1.9mm apart and the opposite contact at the intervening0.95mm station; the native1.9mm collinear minimum is not a contradiction of the0.95mm nominal pin pitch. Native representative pad coordinates and shape dimensions are retained per family.

P-PINMAP: SOUND for identity propagation. Independently resolving exact manufacturer IDs before supplier aliases reaches333/333 fitted refs,58 families and988 declared physical identities, with0 missing or extra identities in either schematic ports or native pads. The canonical gate checks47 refs/411 identities because it skips dossiers with<=3 pins; this review explicitly covers them too. The only collapsed logical identities are DMP6023LFG drain6/7/8 to artifact pad5, with explicit fused:true aliases and same DRAIN_COMMON function. Primary DS37204 pp1/5 visibly shows the fused drain leadframe and recommended land. The48-pin ADC retains EP49; the14-lead LT3041 retains EP15. Full vendor pin-winding/function review remains its separate gate; this scoped report does not invent acceptance for it.

## Fact and module applicability

P-FACT current-stage applicability is fully determined. All89 dossiers contain36 asserting families/38 optional assertions; the exact fitted population selects26 asserting families/28 assertions. Of these,2 polarity assertions apply now and pass across5 actual refs. The25 selected value assertions and1 selected assembly-absence assertion grade future fab BOM/CPL artifacts and remain OWED at that stage. Ten additional legacy value assertions are outside the current fitted subject: BLM21PG600SN1D, C1608X7R1C105K080AC, C3225X7R1H226M250AC, CL10A225KP8NNNC, CL10A475KO8NQNC, CL10B474KA8NNNC, EEEFK1V4R7R, RC0402FR-071KL, RC0402FR-071ML, RC0402FR-071RL. No msl, keepout_region or configured_pin_net optional assertion is declared. Their absence does not create a new physical prerequisite or waive existing first-article obligations.

The unchanged helper initially grades0/38 because no netlist/BOM is in the packet. After exporting the exact native schematic into scratch, it grades1/38 with37 UNREACHED,0 violated facts and strict exit1. Two limitations explain the result: selected-family filtering activates only after a fab BOM exists, and polarity ref resolution still uses LCSC, excluding the manual Panasonic part. Independent exact-MPN resolution and netlist S-expression parsing grade all required current instances. The netlist has985 pin nodes and0 conflicting assignments; its source schematic SHA is unchanged. The exporter emitted an annotation warning, retained in raw evidence; the inspected polarity nodes are present, unique and match native pads. No clean ERC/annotation verdict is inferred.

| Part/ref | Pin | Exported netlist and native net | Verdict |
|---|---|---|---|
| EEEFK1A471P/C_HOLD2 | 1 | 5V_LDO_HOLD | positive, PASS |
| EEEFK1A471P/C_HOLD1 | 1 | 5V_LDO_HOLD | positive, PASS |
| EEEFK1A471P/C_FILT1_470U | 1 | FILT1P | positive, PASS |
| EEEFK1A471P/C_FILT2_470U | 1 | FILT2P | positive, PASS |
| SMBJ15A/D_IN | 1 | 12V_PROTECTED | positive, PASS |

Native value corroboration covers239 instances of the25 applicable value assertions:238 decode to the specified numerical value; L_BUCK displays its exact MPN XGL4020-332MEC rather than a numerical inductance. That is not a failed fab-BOM comparison because the BOM is absent. Its future Comment must still satisfy3.3u. Assembly source correctly names all4 Panasonic refs as manual/non-BOM, but source intent does not prove absence from future BOM/CPL. No overall fabrication P-FACT PASS is granted.

P-MOD: ADC record has a concrete one-clock-domain/no-firmware rationale, a considered MCHStreamer boundary and Cirrus evaluation-platform comparison, and an exact accepted ADR. The original missing-ADR machine failure was a packet omission, not a design finding; a parent-supplied hash-bound unchanged ADR closes it in a working copy. However, machine1/1 is not whole-scope human acceptance: the canon covers switching-power controllers and AP63205 contains peak-current control, compensation and integrated switching MOSFETs. The commission does not prescribe this bare switching implementation. U_BUCK has at least9 separately named external supports (C_BUCK_IN/IN2/IN3, C_BUCK_BST, C_BUCK_O1/O2/O3, D_BUCK_IN, L_BUCK), so a complete inventory determines whether the10-support exception threshold applies. The ADC entry’s13 named refs include its own U_ADC; the12 actual listed external refs still exceed the threshold. The smallest correction is an accurate source decision record, not an imposed module swap.

## Evidence and limits

New primary images actually viewed: Diodes DMP6023LFG DS37204 Rev2-2 pp1/5; Diodes AP63205 DS41326 Rev3-2 p1; Cirrus CS5308P DS1314F1 p4; ADI DFN14 05-08-1708 RevB p1. Each image and exact PDF is SHA-bound in evidence.json. These targeted reads support the package/fusion/module applicability judgments and do not replace the separately owned20-family layout-reference campaign.

The prior archive was SHA/size verified, every visited member path/type checked, and only4 selected methods/raw-evidence members reopened against its manifest. No nested archive is delivered. Prior INCOMPLETE remains immutable. Current native/prepared board hashes are exactly inherited subjects; new judgments come from the independent methods in this archive. Existing12 starved thermals,2 GND opens, other route/preparation obligations, native render/model registration and locator usability remain separate. No full DRC, mechanical sweep or ADC-return proof was repeated. First-article physical qualification remains separate from design-only fabrication.

All569 original envelope inputs were checked before/after. Two separately authorized supplements are retained with exact hashes: ADR0001 b9e5767b90ffb5303aabfffd3e669264f21211e292fdda1e9f9b1c4bd16cfe43,1142B; part_facts_check.py b0d9f55139b5d318ada3070ba8d807f03739bef37a68330e4f2a7311ca094155,34487B. Frozen source/canon were not changed. Finite direct-argv engineering subprocesses use the shared pipeline_runtime.run_stage with explicit environment/cwd and raw logs/runtime receipts. Initial file-inspection/bootstrap commands preceded the runner; their commands are visible in task history, and no engineering acceptance rests on them. Failed probes remain diagnostic evidence.

Delivery PASS means this complete, honest scoped DEFECTIVE handback was packaged and validated. result.json unresolved=[] describes delivery completion only; the engineering findings above remain unresolved. No whole-board layout, route, model/render, fabrication, release or order acceptance is granted.
