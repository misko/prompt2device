from pathlib import Path
import json,hashlib,tarfile,io
s=Path(__file__).parent;o=s.parent/'outputs';archive=o/'evidence.tar.gz'
def sha(b):return hashlib.sha256(b).hexdigest()
entries={}
for p in sorted(s.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(s)
 if rel.parts[0]=='working-project':continue
 if rel.name.startswith('package.') or rel.name.startswith('delivery_preflight.') or rel.name.startswith('validate_archive.'):continue
 assert not p.is_symlink()
 entries['review/'+rel.as_posix()]=p.read_bytes()
entries['review/package.py']=(s/'package.py').read_bytes()
entries['derived/crow_audio_carrier_v1.net']=(s/'working-project/04_kicad/crow_audio_carrier_v1.net').read_bytes()
for name in ['report.md','evidence.json','result.json']:entries['review/'+name]=(o/name).read_bytes()
assert not any(n.endswith(('.tar','.tar.gz','.tgz')) for n in entries)
with tarfile.open(archive,'w:gz') as t:
 for name,b in sorted(entries.items()):
  ti=tarfile.TarInfo(name);ti.size=len(b);ti.mode=0o644;ti.mtime=0;t.addfile(ti,io.BytesIO(b))
rows=[]
with tarfile.open(archive,'r:gz') as t:
 seen=set()
 for m in t:
  assert m.name not in seen;seen.add(m.name)
  assert m.isfile() and not m.issym() and not m.islnk() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  b=t.extractfile(m).read();assert b==entries[m.name]
  rows.append({'path':m.name,'size':len(b),'sha256':sha(b)})
assert len(rows)==len(entries)
manifest={'archive_sha256':sha(archive.read_bytes()),'archive_size':archive.stat().st_size,'member_count':len(rows),'members':rows}
(o/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k!='members'}))
