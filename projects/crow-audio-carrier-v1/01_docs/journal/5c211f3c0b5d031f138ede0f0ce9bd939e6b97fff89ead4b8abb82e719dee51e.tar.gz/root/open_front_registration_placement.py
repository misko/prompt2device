"""Open only after exact schematic-stage acceptance, green commit and valid handoff."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import json,sys,hashlib,shutil
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
slug,revision=sys.argv[1:3];assert slug=='crow-audio-carrier-v1' and revision=='frontreg1';P=R/'projects'/slug;short='pod' if 'pod' in slug else 'carrier';name=f'rj45-{short}-placement-after-{revision}';agent=f'/root/carrier_rj45_{short}_placement_after_{revision}'
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
assert (N/f'{slug}-{revision}-review-adoption.json').is_file()
decision=json.loads((N/'front-registration-normal-renewal-decision.json').read_text());assert decision['decision']=='ADMIT_NORMAL_PLACEMENT_CONTINUATION' and decision['new_exploratory_candidates']==0
for lens in ['topology','readability']:
 c=json.loads((N/f'rj45-{short}-{lens}-review-{revision}-closeout-summary.json').read_text());assert c['delivery_status']=='PASS' and c['engineering_verdict']=='SOUND'
H=P/'06_build/handoffs'/name;H.mkdir(parents=True,exist_ok=False)
for rel,local in [('06_build/agent_handoff.yaml','flow.yaml'),('01_docs/STATUS.md','beacon.md')]:shutil.copy2(P/rel,H/local)
j=(P/'01_docs/journal/schematic.md').read_text();(H/'journal-tail.md').write_text('## '+j.rsplit('\n## ',1)[1])
shutil.copyfile(N/'front-registration-normal-renewal-decision.json',H/'normal-renewal-decision.json')
shutil.copyfile(N/'front-registration-handoff-native/classification.json',H/'current-native-classification.json')
shutil.copyfile(R/'projects/crow-audio-carrier-v1/06_build/task_runs/rj45-carrier-placement-after-none1/outputs/report.md',H/'previous-placement-report.md')
checkpoint=json.loads((P/'06_build/checkpoints/prelayout-inputs.json').read_text())
paths={R/key.removeprefix('repo:') for key in checkpoint['files']}
for rel in ['CLAUDE.md','skills/pcb-design/SKILL.md','skills/kicad-pcb/SKILL.md','skills/pcb-design/references/lifecycle-and-backtrack.md','skills/pcb-design/references/execution-runtime.md','skills/pcb-design/references/review-and-publication.md','skills/kicad-pcb/references/design-policies.md']:
 paths.add(R/rel)
for rel in ['06_build/checkpoints/prelayout-inputs.json','06_build/checkpoints/prelayout.json','06_build/checkpoints/schematic.json','06_build/sourcing/prelayout_response.csv','06_build/sourcing/public_catalog_stock.json','08_reviews/pre-route_topology.md','08_reviews/pre-route_schematic_render.md','01_docs/findings.yaml']:
 paths.add(P/rel)
paths.update((P/'04_kicad').glob('*.kicad_*'))
paths.update((P/'06_build/netlists').glob('*.net'))
for src in sorted(paths):
 assert src.is_file() and not src.is_symlink(),src
 dst=H/'context'/src.relative_to(R);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
shutil.copy2('/tmp/carrier-locator-implementation-availability-6c_4vwal/preflight.py',H/'preflight.py')
command=['/usr/bin/python3','-B',str(R/'skills/kicad-pcb/scripts/pcb_flow.py'),'run',str(P),'--stage','rj45_renewed_placement','--budget-s','600','--timeout-s','600','--','env','KICAD10_3DMODEL_DIR=/home/mouse9911/.local/share/kicad/10.0/3dmodels','bash',str(P/'03_src/rebuild_all.sh'),'--resume-after-schematic-review']
now=datetime.now(timezone.utc);hard=now+timedelta(minutes=22);cut=now+timedelta(minutes=14)
(H/'TASK.md').write_text(f'''# Fresh schematic-to-placement mechanical successor

Root transfers exclusive live writer ownership of {slug} to {agent} for this bounded attempt. Root and other agents must not write this project until actual FINAL and owning closure. Other board ownership remains separate. Read only this TASK, copied current flow/beacon/journal-tail and exact named canon/source in context/. Do not load previous conversation or unrelated historical review reasoning. Verify envelope input packet, live canonical handoff with pcb_flow validate, and exact source checkpoint before executing. Copies are frozen; actual live source is protected by EXCLUSIVE writer-scope exclusions.

The current carrier schematic is independently SOUND with exact frontreg1 reports adopted after ordinary accepted-source renewal. Source commit6374e89a changes only F1-F8 registration mount_side back to front; all floorplan/placement and electrical source remain unchanged from the completed normal none1 placement. The prior current native PCB92a4e2fc has all306 fitted SMD on F.Cu, zero bottom, ordinary DRC0/499/0. Carrier154x100mm. Exact source registration review is SOUND: six groups/28 refs/229 attachment datums pass, fresh fuse signed fraction1.0 and16/16overlaps, five unchanged caches valid. No model, numeric limit, geometry or placement hypothesis changed. Six exploratory native histories remain spent and no seventh is admitted. This is one separately admitted canonical continuation after a bounded stale registration-source correction; the earlier none1 normal allowance was already spent and is not reused. Copied normal-renewal-decision.json binds the new exact source correction and prerequisites. Current locator/render/orientation/placement/routing gates remain binding. Pod source/native unchanged and current human orientation pending. Root does not infer approval from general continue messages. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.



Use the explicit existing KiCad10 model root in the command; do not search or substitute models. Run ONE normal checkpoint-aware continuation, bounded through shared pipeline_runtime.run_stage (outer timeout660s). Exact argv:
{json.dumps(command)}

This driver verifies all source/native/review/checkpoint gates then promotes the accepted schematic and generates the RJ45 PCB from floorplan. Do not rerun TSX, edit source/config/parts/shared scripts, hand-edit generated outputs, restamp checkpoints, waive gates, import the stale pod FINAL/route chain, or bypass a placement failure. Stop at its first failed/missing gate; no retry. A nonzero engineering result is valid honest delivery when all evidence is present. If the unexpected driver reaches beyond missing placement reviews, stop and report; no unreviewed routing authorized.

The frozen current-native-classification.json and previous-placement-report.md preserve the complete preceding baseline. Rebind and classify all actual new rows; reuse only exact unchanged row/endpoint evidence and label it as such. Avoid unrelated analysis after the first gate stop. Finish actual FINAL promptly after required evidence and packaging are complete.

Return actual stopping gate, subprocess rc/time, component/pin/PCB hashes and exact output paths. Verify every fitted SMD is on F.Cu including manual/consigned. Preserve distinction between generated canonical placement and prepared route r0. The ordinary conductor owns its exact placement policy. Carrier J9 current setback and all current connector mouth/side/service images require the registered orientation gate; pod current five-view human approval remains pending. Neither physical fit nor orientation approval follows from a schematic or native graph verdict. If a DRC report exists, classify EVERY violation, unconnected item and parity node by cause; no aggregate congestion story. Preserve raw output/runtime and all failure subjects. Report absent stages as NOT RUN. Verify protected source/method preimages unchanged and final READ_ONLY/exclusive scope result via provided preflight.py. Do not mistake generated copper/pin map for physical service or route acceptance.

Only allowed project paths may change: STATUS, placement journal, promoted03_tscircuit/kicad,04_kicad and06_build. Do not modify frozen handoff files despite their06_build location. Root owns commits and durable archive after FINAL; do not git-add/commit/push or write other projects. Update project beacon and placement journal with measured gate result. Generate/validate the compact placement handoff if exact gate freshness allows; never delete or touch a stale DRC gate to manufacture handoff. Otherwise report that blocker intact.

Declared output_dir requires report.md,evidence.json,evidence-manifest.json,evidence.tar.gz,result.json. evidence binds exact envelope subject, command/runtime, outputs/hashes, stopping gate, full classification and preserved source. Archive exact logs/results and independently reopen all regular members (no symlinks, duplicate paths, traversal or recursive archive); manifest archive_sha256/archive_size/member_count/members(path,size,sha256). result checks execution-recorded,inputs-verified,outputs-preserved PASS only for complete honest delivery, with domain result separate. Finish work and actual FINAL by{cut.isoformat()}, hard{hard.isoformat()}; reserve packaging/closure time. No automatic replacement or extension.
''')
items=[]
for p in sorted(H.rglob('*')):
 if p.is_file():
  b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(P).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
s=subject_identity('native_placement_continuation',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
e=TaskEnvelope(schema=2,task_id=name,stage_id='KICAD-PLACEMENT',run_id=name,subject=s,executor='agent',execution_class='local',recommended_agent_role='mechanical',agent_role='mechanical',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'EXCLUSIVE','paths':['01_docs/STATUS.md','01_docs/journal/placement.md','03_tscircuit/kicad','04_kicad','06_build']},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['execution-recorded','inputs-verified','outputs-preserved']})
o=open_agent_attempt(e,cwd=P);o.update(project=str(P),envelope=str(P/e.output_path).replace('attempt.json','envelope.json'),task=str(H/'TASK.md'),agent_id=agent,work_cutoff=cut.isoformat());(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2));print(len(items),'frozen inputs')
