from pathlib import Path
import sys, subprocess, unittest
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
C=Path('/tmp/carrier-rj45-20260912/placement-integrated-source')
P=C/'projects/crow-audio-carrier-v1'
sys.path.insert(0,str(P/'03_src/tests'))
original=subprocess.check_output
def historical(args,*a,**kw):
    if isinstance(args,list) and args[:2]==['git','show']:
        assert len(args)==3 and ':' in args[2]
        kw['cwd']=R
    return original(args,*a,**kw)
subprocess.check_output=historical
suite=unittest.defaultTestLoader.loadTestsFromNames(['test_source_silkscreen','test_local_placement_source','test_ground_connections','test_package_models'])
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not result.wasSuccessful())
