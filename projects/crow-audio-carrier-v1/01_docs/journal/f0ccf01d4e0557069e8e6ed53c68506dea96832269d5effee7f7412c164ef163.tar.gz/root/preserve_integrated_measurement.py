from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io
from datetime import datetime,timezone
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911');C=N/'placement-integrated-source';payload={}
def add(p,key):
 assert p.is_file() and not p.is_symlink() and key not in payload
 payload[key]=p.read_bytes()
for name in ['placement-integration-base.json','integrated-measurement-input.json','run_integrated_tests.py','preserve_integrated_measurement.py','pod-route-companion-proposal.json','pod-placement-source1-live-integration.json','placement-source-coordination.json']:
 add(N/name,'root/'+name)
for p in N.glob('carrier-integrated-measurement*.json'):add(p,'measurement/'+p.name)
for prefix in ['carrier-integrated-','carrier-silk-consumer-','weid-pod-full-native-placement1','weid-pod-public-resume-placement1','rj45-delivery-dback-close']:
 for p in I.glob(prefix+'*'):
  if p.is_file():add(p,'runtime/'+p.name)
base=json.loads((N/'placement-integration-base.json').read_text());changed=[]
for row in base['files']:
 rel=row['path'];p=C/rel
 if '/03_src/' not in rel and '/02_parts/' not in rel:continue
 if hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:
  add(p,'source_candidate/'+rel);changed.append(rel)
for p in (C/'projects/crow-audio-carrier-v1/04_kicad').iterdir():
 if p.is_file() and p.suffix in ['.kicad_pcb','.kicad_pro','.kicad_dru','.kicad_sch']:add(p,'native/'+p.name)
for task in ['rj45-delivery-dback','rj45-placement-renewal-availability']:
 meta=json.loads((N/(task+'-opened.json')).read_text());D=Path(meta['project']);E=Path(meta['envelope'])
 for row in json.loads(E.read_text())['input_packet']:
  p=D/row['path'];b=p.read_bytes();assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256'];add(p,task+'/inputs/'+row['path'])
 for p in E.parent.iterdir():
  if p.is_file():add(p,task+'/allocation/'+p.name)
 for p in Path(meta['output_dir']).iterdir():
  if p.is_file():add(p,task+'/outputs/'+p.name)
 for suffix in ['-opened.json','-host-final.json']:add(N/(task+suffix),'root/'+task+suffix)
 if task=='rj45-delivery-dback':
  O=Path(meta['output_dir']);m=json.loads((O/'evidence-manifest.json').read_text());raw=(O/'evidence.tar.gz').read_bytes();assert hashlib.sha256(raw).hexdigest()==m['archive_sha256'];idx={r['path']:r for r in m['members']}
  with tarfile.open(O/'evidence.tar.gz') as t:
   assert len(t.getmembers())==len(idx)
   for member in t.getmembers():
    assert member.isfile() and not PurePosixPath(member.name).is_absolute() and '..' not in PurePosixPath(member.name).parts
    b=t.extractfile(member).read();r=idx[member.name];assert len(b)==r['size'] and hashlib.sha256(b).hexdigest()==r['sha256']
record={'created_at':datetime.now(timezone.utc).isoformat(),'scope':'First isolated integrated carrier source measurement and orchestration D-BACK. No source adoption, stale review acceptance or release. Late attempts remain TIMED_OUT.','source_candidate_files':changed,'tests':{'count':39,'status':'PASS'},'native_drc':{'violations':0,'unconnected':499,'parity':0,'exit_code':5},'placement_gate':'PASS;333 assembled bodies;0failures/0warnings','recovery_authorization':'OWED; no out-of-limit replacement dispatched'}
payload['MEASUREMENT.json']=(json.dumps(record,indent=2)+'\n').encode();payload['MANIFEST.json']=(json.dumps({'files':[{'path':k,'size':len(v),'sha256':hashlib.sha256(v).hexdigest()} for k,v in sorted(payload.items())]},indent=2)+'\n').encode();out=N/'integrated-measurement.tmp'
with out.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for k,b in sorted(payload.items()):
    x=tarfile.TarInfo(k);x.size=len(b);x.mode=0o644;t.addfile(x,io.BytesIO(b))
with tarfile.open(out) as t:
 assert len(t.getmembers())==len(payload)==len({x.name for x in t.getmembers()})
 for member in t.getmembers():assert member.isfile() and t.extractfile(member).read()==payload[member.name]
b=out.read_bytes();h=hashlib.sha256(b).hexdigest();J=R/'projects/crow-audio-carrier-v1/01_docs/journal';dest=J/(h+'.tar.gz');assert not dest.exists();dest.write_bytes(b)
with (J/'contracts.md').open('a') as f:f.write(f'\n## Allowed first integrated carrier measurement and delivery diagnosis\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Frozen unaccepted combined source, 39-test result, native 0/499/0 and per-row classification, original setup failures, source-test correction, and timely closed delivery D-BACK diagnosis |\n\nAudit: SHA-256 equals filename; {len(b)} bytes and {len(payload)} regular members, each reopened against MANIFEST.json. No source adoption or release acceptance; the three predecessor TIMED_OUT statuses remain terminal.\n')
summary={'sha256':h,'archive':str(dest),'size':len(b),'members':len(payload),**record};(N/'integrated-measurement-closeout.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:summary[k] for k in ['sha256','size','members','source_candidate_files']},indent=2))
