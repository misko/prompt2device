# Fresh carrier clock-exit PIN / terminal review

review_stage: pre-route
review_kind: pin
reviewer: /root/pod_r3_pin_review (fresh independent read-only reviewer)
review_context: FRESH
completed_at: 2026-09-14T06:22:00Z
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
release_scope: FIRST-ARTICLE-ONLY

floorplan_sha256: a9aff00c6609f9c0c1050e882f270a6c67bdac9fbf790194b5773efb63790876
route_yaml_sha256: 5910176bba8ae93d1b6d08352db4ef54b40d004ed106e08e55a26353dd268b55
nets_yaml_sha256: 160640a030557c29871e2238b64a788cb8bc0b8aaa7725946aa284c6a733ef17
stackup_yaml_sha256: dffefa0c8433af3cc646d160330a470478943274ba8d9eb310fb290162d609b5
board_sha256: 6f1232d03971c9b897b5dc2cb929e3e104e052de6f18fdd4b29211dadf0e06e8
r0_sha256: 108bf458850b3db37cf1b5ff18cf51ef875a33027ee627c8057615d6ea41bec0
netlist_sha256: 92b0e78a814516676babdb65da635f508808ec1020c0d18c154afef6df6c8a15
raw_netlist_sha256: 7d584ed53401128bce9e723ccf26676d7ac4624159e9d3200a2a6eba71935a18
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: 734eaa9274e681d83c28028f0dd96d222658d32d8f500ab82552af057fc6ca58
diagnostic_sha256: 2d794aa817c097e104e05a7cc3b04c73e29ee3bd5b0872749964fd86bbbcbb7c
diagnostic_log_sha256: d20b8aa8d9a09f0c19d0282568263f9868abfd284eddb84a990c64ca652e3f12
krt_commit: de562199260dc82abb7f1f53edb6921348a19388

## Scope and boundary

I independently reviewed the frozen carrier source, exact prepared `r0`, corrected two-layer clock policy, and diagnostic clock route. The review covers pin/net identity and continuity for the new ordinary-width exits, complete/partial seed ownership, all ten prepared digital launch endpoints, layer-transition electrical intent, and SMD population side.

This is pre-route source/PIN acceptance. The diagnostic is a bounded routability witness, not the released board. Full-board route, final DRC, fabrication, assembly, release, and order gates remain mandatory.

## Findings

No blocking PIN or terminal defect was found.

The new ordinary-width F.Cu continuations are exact, continuous members of their intended prepared islands:

- `ADC_BCLK / U_ADC.29`: the 0.36 mm launch continues north from `(100.10,70.60)` to `(100.10,71.25)`, then east to `(101.20,71.25)`. Native connectivity reaches only `U_ADC.29`; `R_BCLK.2` remains the intended remote endpoint for the clock wave.
- `MCH_FSYNC / U_CLK.6`: the 0.36 mm launch continues east from `(149.80,59.20)` to `(152.00,59.20)`. Native connectivity reaches only `U_CLK.6`; `J10.12` and `R_MCH_FSYNC_PD.1` remain intended wave endpoints.
- `MCLK_BUF / U_CLK.7`: the 0.36 mm launch continues east from `(149.95,58.55)` to `(151.50,58.55)`. Native connectivity reaches only `U_CLK.7`; `R_MCLK.1` remains the intended remote endpoint.

All declared edges for all ten prepared digital seeds occur exactly in `r0`; none was missing or assigned to a different net. The independent source geometry pass performed 45,314 native shape checks and found zero collisions, reach failures, or source-budget violations. All 20 other clock endpoints retained a full-width launch witness.

## Launch endpoint census

| Source pin | Net | Native pads reached in `r0` | Classification and owner |
|---|---|---|---|
| `U_CLK.1` | `MCH_MCLK` | `U_CLK.1` | partial; clock wave |
| `U_CLK.2` | `FSYNC_BUF` | `U_CLK.2`, `R_FSYNC.1` | complete; `prep.seed_stubs`; excluded |
| `U_CLK.3` | `MCH_BCLK` | `U_CLK.3` | partial; clock wave |
| `U_CLK.5` | `BCLK_BUF` | `U_CLK.5`, `R_BCLK.1` | complete; `prep.seed_stubs`; excluded |
| `U_CLK.6` | `MCH_FSYNC` | `U_CLK.6` | partial; clock wave |
| `U_CLK.7` | `MCLK_BUF` | `U_CLK.7` | partial; clock wave |
| `U_ADC.24` | `ADC_FSYNC` | `U_ADC.24` | partial; clock wave |
| `U_ADC.25` | `TDM_RAW` | `U_ADC.25` | partial; clock wave |
| `U_ADC.29` | `ADC_BCLK` | `U_ADC.29` | partial; clock wave |
| `U_ADC.34` | `ADC_MCLK` | `U_ADC.34` | partial; clock wave |

The complete set is exactly `{FSYNC_BUF, BCLK_BUF}`. Each complete two-pad net has one explicit local seed owner and is absent from generic waves. The other eight are partial, have no complete local owner, and remain wave-owned. The generated clock wave contains exactly 11 nets.

## Two-layer electrical intent

Both the clock wave and the ADC-clock class explicitly allow only `F.Cu` and `B.Cu`. The exact diagnostic connects every declared pad on all 13 ADC-clock nets, including all 11 wave-routed nets and the two locally complete buffers. Native inspection found 21 clock vias; every via's connected island contains both `F.Cu` and `B.Cu`, and no routed clock item used an undeclared signal layer.

The corrected reference-plane contract explicitly maps `F.Cu -> In1.Cu / GND` and `B.Cu -> In2.Cu / GND`. A fresh `reference_plane_check.py` run returned PASS for both projections. The nearest foreign-via clearances were 0.583283 mm on F.Cu/In1 and 2.384694 mm on B.Cu/In2, above the declared 0.50 mm via floor; both checks found zero projected foreign-track conflicts.

The bound diagnostic log reports 11/11 single nets routed, 12/12 multipoint pads connected across four nets, 21 vias, no failed net, and `min_clearance_used: 0.25`. Independent KiCad DRC of that partial diagnostic found no clock violation and no unconnected clock item. Its 86 warnings comprise 32 dangling tracks and 54 dangling vias on unrelated prepared, incomplete nets; no clearance or width violation was reported. Those unrelated partial-board warnings do not grant final-route acceptance.

## Population and checks

Source board, prepared `r0`, and diagnostic each contain 340 footprints and 309 footprints marked SMD. All 309 SMD footprints are on the front side in every artifact; none of the three boards has any back-side footprint.

- `test_digital_launch_source.py`: PASS, 10 tests.
- `test_route_source_contract.py`: PASS, 24 tests, including the explicit F.Cu/In1 and B.Cu/In2 projection contract and hostile omission check.
- `route_ownership_preflight.py`: PASS, zero findings over 221 board nets and 12 owners.
- Independent native launch, diagnostic connectivity, via-transition, and population audit: PASS, zero findings.
- Fresh reference-plane projection: PASS on both signal/reference layer pairs.
- Before/after hash comparison over every bound source, board, test, diagnostic, and log artifact: STABLE.

## Verdict

**SOUND** for this exact pre-route PIN/source-terminal gate. The new clock exits preserve intended pin/net continuity, the complete-buffer ownership is exact, and the F.Cu/B.Cu diagnostic preserves electrical endpoint identity with the declared adjacent GND reference-plane projections.

**FIRST-ARTICLE-ONLY / DO-NOT-ORDER.**
