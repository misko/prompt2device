"""Source declarations only: no BOARD construction/load/save or route producer.

These tests deliberately accept a NOT ROUTE-READY source correction. They
grade exact membership and consumer agreement, not physical feasibility.
"""
import copy
import fnmatch
import json
import math
import sys
import unittest
from collections import Counter
from pathlib import Path

import yaml

PROJECT = Path(__file__).resolve().parents[2]
REPO = PROJECT.parents[1]
sys.path.insert(0, str(REPO/'skills/kicad-pcb/scripts'))
from source_inventory import parse_netlist
from route_and_stitch_generic import wave_nets, check_wave_widths, net_class_floors, RouteConfigError
from route_ownership_preflight import audit_config
from rules_audit import parse_mm, parse_amps, required_width_mm
from board_authority import compile_source_prep_authority, verify_authority
from copper_length_audit import load_groups
from test_local_placement_source import source_builder
from escape_check import _poly_seg_dist, _point_in_poly, _seg_seg_dist
from placement_gates import _poly_gap_mm
import pcbnew


def load_source():
    floor = yaml.safe_load((PROJECT/'03_src/floorplan.yaml').read_text())
    route = yaml.safe_load((PROJECT/'03_src/route.yaml').read_text())
    route['_root'] = PROJECT
    nets = yaml.safe_load((PROJECT/'03_src/rules/nets.yaml').read_text())
    stack = yaml.safe_load((PROJECT/'03_src/rules/stackup.yaml').read_text())
    comps, pins, _ = parse_netlist(PROJECT/floor['project']['netlist'])
    return floor, route, nets, stack, comps, pins


def shadow_inputs(route, nets, comps, pins):
    membership = {n: name for name, c in nets['classes'].items() for n in c['nets']}
    groups = wave_nets(route, sorted(set(pins.values())))
    waves = []
    for wave in route['route']['waves']:
        classes = {membership[n] for n in groups[wave['group']]}
        assert len(classes) == 1, (wave['name'], classes)
        waves.append(dict(name=wave['name'], group=wave['group'], routing_class=classes.pop()))
    plan = dict(schema='route-plan-v1', groups=groups, waves=waves,
                exclusions=[dict(pattern='GND', owner='reference-plane', why='Existing common GND pours; local egress remains unproved'),
                            dict(pattern='unconnected-*', owner='intentional-nc', why='Explicit source intentional unused pins; preserve identities')],
                deterministic_owners=[dict(net=net, owner='prep.seed_stubs', why='Complete native local source connection, independently contact-graded and excluded from generic routing')
                                      for net, owner in route['route']['ownership']['nets'].items() if owner['owner']=='prep.seed_stubs'])
    parts = [yaml.safe_load(path.read_text()) for path in (PROJECT/'02_parts').glob('*/part.yaml')]
    observed = dict(schema='observed-source-facts-v1', refs=sorted(comps),
                    nets=sorted(set(pins.values())), mpns=sorted({p['mpn'] for p in parts}))
    return observed, plan


def via_rows(route):
    rows = []
    def walk(value, path):
        if isinstance(value, dict):
            if 'via_size' in value or 'via_drill' in value:
                rows.append((path, value.get('via_size'), value.get('via_drill')))
            if 'size' in value and 'drill' in value:
                rows.append((path, value['size'], value['drill']))
            for key, child in value.items(): walk(child, path+'.'+str(key))
        elif isinstance(value, list):
            for i, child in enumerate(value): walk(child, path+f'[{i}]')
    walk(route, 'route.yaml')
    return rows


def paired_vias_legal(route, floor):
    rules = floor['design_rules']
    for path, size, drill in via_rows(route):
        if size is None or drill is None: return False
        if size < rules['via_min_size'] or drill < rules['min_through_drill']: return False
        if (size-drill)/2 + 1e-9 < rules['via_min_annulus']: return False
        if floor['board']['stackup']['nominal_thickness_mm']/drill > 10: return False
    return True


class RouteSourceContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.floor, cls.route, cls.nets, cls.stack, cls.comps, cls.pins = load_source()
        cls.native = set(cls.pins.values())
        cls.groups = wave_nets(cls.route, sorted(cls.native))

    def test_source_census_includes_lt3041_shared_rail_and_explicit_nc(self):
        self.assertEqual(len(self.comps), 333)
        self.assertEqual(len(self.pins), 937)
        self.assertEqual(len(self.native), 220)
        self.assertEqual(sum(n.startswith('unconnected-') for n in self.native), 42)
        self.assertEqual(len(self.native-{'GND'}-{n for n in self.native if n.startswith('unconnected-')}), 177)

    def test_every_connected_net_has_one_exact_class(self):
        members = [n for c in self.nets['classes'].values() for n in c['nets']]
        self.assertFalse(any(any(ch in n for ch in '*?[') for n in members))
        self.assertEqual(set(members), {n for n in self.native if not n.startswith('unconnected-')})
        self.assertEqual(set(Counter(members).values()), {1})
        self.assertEqual({name:len(c['nets']) for name,c in self.nets['classes'].items()},
                         dict(POD_POWER=12, POWER_TRANSIENT=8, POWER_CONTROL=25, BOOTSTRAP=1,
                              QUIET_POWER=6, ANALOG_AUDIO=112, ADC_CLOCK=13, GROUND=1))

    def test_every_generic_net_has_one_exact_wave(self):
        members = [n for group in self.groups.values() for n in group]
        self.assertEqual(len(members), 172)
        self.assertEqual(set(Counter(members).values()), {1})
        self.assertEqual(set(members), {n for n in self.native if n not in {'GND','LDO_A_FILT','FSYNC_BUF','LDO_D_FILT','VMID1','VMID2'} and not n.startswith('unconnected-')})
        self.assertEqual(self.route['prep']['waves']['exclude'], ['GND', 'unconnected-*', 'LDO_A_FILT', 'FSYNC_BUF','LDO_D_FILT','VMID1','VMID2'])

    def test_existing_consumer_rejects_ghost_and_glob_groups(self):
        for bad_name in ['FILT1N', 'FILT2N', 'AUDIO_*', 'ADC?P']:
            bad = copy.deepcopy(self.route)
            bad['prep']['waves']['groups']['analog'].append(bad_name)
            with self.assertRaises(RouteConfigError): wave_nets(bad, self.native)

    def test_existing_width_consumer_reaches_all_current_wave_nets(self):
        floors = net_class_floors(self.route)
        self.assertEqual(set(floors), {n for n in self.native if not n.startswith('unconnected-')})
        check_wave_widths(self.route, self.groups)

    def test_existing_width_consumer_rejects_underfloor_power(self):
        bad = copy.deepcopy(self.route)
        next(w for w in bad['route']['waves'] if w['name']=='power')['track_width'] = .60
        with self.assertRaises(RouteConfigError): check_wave_widths(bad, self.groups)

    def test_declared_current_bound_is_not_lowered_to_fit(self):
        c = self.nets['classes']['POWER_TRANSIENT']
        self.assertEqual(parse_amps(c['current']), (2.5, 'number'))
        required = required_width_mm(2.5)
        self.assertAlmostEqual(required, 1.0630368549, places=8)
        self.assertGreaterEqual(parse_mm(c['min_width']), required)
        self.assertLess(.8, required)  # known-bad historical nominal floor
        self.assertNotIn('pour_fed', c)

    def test_transient_bulk_wave_cannot_intentionally_request_a_layer_transfer(self):
        wave = next(w for w in self.route['route']['waves'] if w['name']=='power')
        self.assertEqual(wave['layers'], ['F.Cu'])
        self.assertEqual(wave['track_width'], 1.20)
        self.assertFalse(self.route.get('taps', {}).get('connections'))
        # This is source intent only. Reopened copper must independently prove it.

    def test_existing_owner_consumer_and_known_bad_double_owner(self):
        kw = dict(pad_counts=dict(Counter(self.pins.values())), board_nets=self.native, nets_cfg=self.nets)
        self.assertEqual(audit_config(self.route, **kw)['findings'], [])
        bad = copy.deepcopy(self.route)
        bad['route']['ownership']['nets']['3V3_ADC']['owner'] = 'taps.connections'
        self.assertIn('O-DOUBLE', {r['code'] for r in audit_config(bad, **kw)['findings']})
        bad = copy.deepcopy(self.route)
        del bad['route']['ownership']['nets']['3V3_ADC']
        self.assertIn('O-PWR', {r['code'] for r in audit_config(bad, **kw)['findings']})

    def test_via_pair_not_independent_size_and_drill_floors(self):
        self.assertEqual(len(via_rows(self.route)), 19)
        self.assertTrue(paired_vias_legal(self.route, self.floor))
        bad = copy.deepcopy(self.route)
        bad['route']['common']['via_size'] = .45
        self.assertFalse(paired_vias_legal(bad, self.floor))
        via = self.route['stitch']['via']
        self.assertGreaterEqual(via['spacing']-via['drill'], self.floor['design_rules']['hole_to_hole'])
        self.assertGreaterEqual(via['spacing']-via['size'], self.route['stitch']['clearance'])
        self.assertEqual(self.route['stitch']['hole_to_hole']['mode'], 'nudge')
        self.assertNotIn('normalize_vias', self.route['stitch']['passes'])

    def test_stack_public_dimensions_reconcile_both_source_consumers(self):
        physical = self.floor['board']['stackup']
        self.assertEqual(physical['copper_thickness_mm'], [.035,.0152,.0152,.035])
        self.assertEqual([d['thickness_mm'] for d in physical['dielectrics']], [.2104,1.065,.2104])
        self.assertEqual([d['epsilon_r'] for d in physical['dielectrics']], [4.4,4.6,4.4])
        self.assertAlmostEqual(sum(physical['copper_thickness_mm'])+sum(d['thickness_mm'] for d in physical['dielectrics']), 1.5862)
        self.assertEqual([d['thickness_um']/1000 for d in self.stack['copper']], physical['copper_thickness_mm'])
        for d in physical['dielectrics']:
            self.assertTrue({'type','thickness_mm','material','epsilon_r','loss_tangent'} <= set(d))
            self.assertIn('assumed', d['material'])

    def test_shadow_compile_and_hostile_ownership_and_plane_rejection(self):
        observed, plan = shadow_inputs(self.route, self.nets, self.comps, self.pins)
        kwargs = dict(stack=self.stack, observed=observed, route_plan=plan, migration=None)
        receipt = compile_source_prep_authority(**kwargs)
        self.assertEqual(receipt['verdict'], 'PASS')
        self.assertEqual(receipt['coverage']['owned_live_nets'], 220)
        self.assertEqual(verify_authority(receipt, **kwargs), (True, []))
        duplicate = copy.deepcopy(plan)
        duplicate['deterministic_owners'].append(dict(net='ADC_MCLK', owner='prep.seed_stubs', why='Hostile duplicate whole-net owner'))
        self.assertEqual(compile_source_prep_authority(stack=self.stack, observed=observed, route_plan=duplicate)['verdict'], 'FAIL')
        wrong = copy.deepcopy(self.stack)
        wrong['copper'][1]['role'] = 'mixed'
        del wrong['copper'][1]['plane_net']
        self.assertEqual(compile_source_prep_authority(stack=wrong, observed=observed, route_plan=plan)['verdict'], 'FAIL')

    def test_sense_control_preserves_clearance_and_bootstrap_is_not_quiet(self):
        clock = self.nets['classes']['ADC_CLOCK']['nets']
        control = self.nets['classes']['POWER_CONTROL']
        for net in ['MCH_3V3_SENSE','TDM_SENSE_G','TDM_OE_N']:
            self.assertNotIn(net, clock)
            self.assertIn(net, control['nets'])
        self.assertGreaterEqual(parse_mm(control['clearance']), .25)
        self.assertEqual(self.nets['classes']['BOOTSTRAP']['nets'], ['BUCK_BST'])
        self.assertNotIn('BUCK_BST', control['nets'])

    def test_common_planes_and_only_explicit_bounded_launch_exceptions(self):
        self.assertEqual({z['net'] for z in self.floor['zones']}, {'GND'})
        self.assertEqual(set(self.floor['zones'][0]['layers']), {'F.Cu','In1.Cu','In2.Cu','B.Cu'})
        self.assertEqual(len(self.nets['scoped_floors']), 42)
        # PackageClearanceTests grade 15 additional pad-only, not route, scopes.
        self.assertEqual(len([r for r in self.nets['scoped_clearances'] if not r['zone'].startswith('PKG_PAD_')]), 18)
        self.assertEqual(self.route['route']['ownership']['nets']['LDO_A_FILT']['owner'], 'prep.seed_stubs')
        self.assertTrue(any('NOT ROUTE-READY' in text for text in self.route['flow']['blockers']))

    def test_native_filter_negative_and_ground_pin_identities(self):
        for pin in ['6','8','17','30','44','49']:
            self.assertEqual(self.pins[('U_ADC',pin)], 'GND')
        self.assertNotIn('FILT1N', self.native)
        self.assertNotIn('FILT2N', self.native)

    def test_rf_stays_disabled_without_denying_digital_impedance_intent(self):
        rf = yaml.safe_load((PROJECT/'03_src/rules/rf.yaml').read_text())['rf']
        self.assertIs(rf['enabled'], False)
        self.assertIn('50 ohm', rf['rationale'])
        self.assertIn('high_speed_digital', rf['rationale'])

    def test_existing_length_consumer_accepts_exact_complete_digital_paths(self):
        groups, _ = load_groups(PROJECT)
        # ADR0019 owns the additional analog groups; retain exact digital tests.
        groups = {k: groups[k] for k in ['MCH_INPUT_SECTIONS', 'BUFFERED_DIGITAL_SECTIONS']}
        covered = set()
        endpoints = set()
        self.assertEqual(len(groups), 2)
        for group in groups.values():
            self.assertTrue(group['no_vias'])
            self.assertEqual(group['max_spread_mm'], 'report')
            self.assertFalse(group['congruent_pads'])
            for paths in group['paths'].values():
                for path in paths:
                    for segment in path['segments']:
                        covered.add(segment['net'])
                        for kind in ['from', 'to']:
                            ref, pin = segment[kind].rsplit('.', 1)
                            self.assertEqual(self.pins[(ref,pin)], segment['net'])
                            endpoints.add((ref,pin))
        self.assertEqual(covered, set(self.nets['classes']['ADC_CLOCK']['nets']))
        self.assertEqual(endpoints, {pin for pin,net in self.pins.items() if net in covered})

    def test_exact_seed_identity_scope_extent_and_no_high_current_vias(self):
        all_seed = self.route['prep']['seed_stubs']['stubs']
        self.assertEqual(len(all_seed), 105)
        # Preserve the adopted west-ADC engineering checks. Digital geometry is
        # independently covered by test_digital_launch_source, not exempted here.
        seed = [s for s in all_seed if s['pin'].startswith(('U_ADC.5','U_ADC.6','U_ADC.7','U_ADC.8','U_ADC.9','C_VMID'))]
        self.assertEqual(len(seed), 9)
        self.assertEqual({s['pin'] for s in seed}, {'U_ADC.5','U_ADC.6','U_ADC.7','U_ADC.8','U_ADC.9',
                         'C_VMID1_470N.2','C_VMID1_4U7.2','C_VMID2_470N.2','C_VMID2_4U7.2'})
        area = next(k for k in self.floor['keepouts'] if k['name']=='ADC_WEST_LOCAL')
        self.assertEqual(area['layers'], ['F.Cu'])
        self.assertEqual(area['deny'], [])
        x0,y0,x1,y1 = area['rect']
        length = 0.; count = 0
        for stub in seed:
            ref,pin = stub['pin'].rsplit('.',1)
            self.assertEqual(self.pins[(ref,pin)], stub['net'])
            if stub.get('vias'): self.assertEqual(stub['net'], 'GND')
            for spec_index,segment in enumerate(stub['segments']):
                self.assertEqual(segment['layer'], 'F.Cu')
                if stub['net']=='3V3_ADC' and spec_index>0:
                    # Full new feed capsules have independent native/extent
                    # and exact length/count coverage in test_adc_feed_source.
                    continue
                if segment['width'] < .30 or stub['net']=='3V3_ADC':
                    radius = segment['width']/2
                    for x,y in segment['pts']:
                        self.assertTrue(x0+radius <= x <= x1-radius and y0+radius <= y <= y1-radius)
                if stub['net']=='3V3_ADC':
                    length += sum(math.dist(a,b) for a,b in zip(segment['pts'],segment['pts'][1:]))
                    count += len(segment['pts'])-1
        self.assertAlmostEqual(length, 3.69825107277109)
        self.assertEqual(count, 4)
        limits = next(w for w in self.route['route']['waves'] if w['name']=='power')['realized_width']
        # ADC, LT3041 and peripheral tests independently grade actual native
        # source capsules. This is their current whole-rail ceiling, not ampacity.
        self.assertEqual(limits['max_subnominal_length_per_net'], 54.294731)
        self.assertEqual(limits['max_subnominal_segments_per_net'], 44)

    def test_isolated_adopted_seed_geometry_and_three_pose_screen(self):
        # Isolated library footprints only: no BOARD constructor/load/save.
        source = source_builder(self.floor)
        pads=[]; footprints={}
        for ref,(fpid,_) in self.comps.items():
            lib,name=fpid.split(':')
            directory=PROJECT/'03_src/lib/crow_audio_carrier.pretty' if lib=='crow_audio_carrier' else Path('/usr/share/kicad/footprints')/(lib+'.pretty')
            fp=pcbnew.FootprintLoad(str(directory),name)
            self.assertIsNotNone(fp)
            x,y,rot,_=source.initial_pose(ref)
            fp.SetOrientationDegrees(rot)
            fp.SetPosition(pcbnew.VECTOR2I(round(x*1e6),round(y*1e6)))
            fp.BuildCourtyardCaches(); footprints[ref]=fp
            for p in fp.Pads():
                if not p.IsOnCopperLayer() or not p.IsOnLayer(pcbnew.F_Cu): continue
                poly=p.GetEffectivePolygon(pcbnew.F_Cu).Outline(0)
                points=[(poly.CPoint(i).x/1e6,poly.CPoint(i).y/1e6) for i in range(poly.PointCount())]
                pads.append((ref+'.'+p.GetNumber(),self.pins[(ref,p.GetNumber())],points))
        def distance(poly,a,b):
            return 0. if _point_in_poly(a,poly) or _point_in_poly(b,poly) else _poly_seg_dist(poly,a,b)
        segments=[]
        from test_regulator_source import CELL_PINS as REGULATOR_PINS
        original_west={'U_ADC.5','U_ADC.6','U_ADC.7','U_ADC.8','U_ADC.9',
                      'C_VMID1_470N.2','C_VMID1_4U7.2','C_VMID2_470N.2','C_VMID2_4U7.2'}
        for stub in self.route['prep']['seed_stubs']['stubs']:
            # Preserve this older ordinary-clearance screen for its original
            # west/regulator subjects. ADC additions have an independent native
            # all-pad/all-seed/all-layer-via screen in test_adc_source, including
            # cross-interactions here, and exact named0.20mm pin-pitch rules.
            if stub['pin'] not in original_west|REGULATOR_PINS:continue
            for s in stub['segments']:
                for a,b in zip(s['pts'],s['pts'][1:]):
                    segments.append((stub['net'],a,b,s['width']))
                    gap=min(distance(poly,a,b)-s['width']/2 for _,net,poly in pads if net!=stub['net'])
                    self.assertGreaterEqual(gap+1e-6,.25 if s['width']>=.30 else .20, stub['pin'])
        for i,(net,a,b,w) in enumerate(segments):
            for net2,c,d,w2 in segments[i+1:]:
                if net==net2: continue
                self.assertGreaterEqual(_seg_seg_dist(a,b,c,d)-(w+w2)/2+1e-6,.25 if max(w,w2)>=.30 else .20)
        moves={'C_LDO_A':[89.93,70.05,180], 'C_VDDA1_4U7':[87.45,68.4,180], 'C_VDDA2_4U7':[87.45,71.6,180]}
        for ref,pose in moves.items():
            self.assertEqual(self.floor['placement']['anchors'][ref],pose)
            env=footprints[ref].GetCourtyard(pcbnew.F_CrtYd)
            for other,fp in footprints.items():
                if other==ref: continue
                poly=fp.GetCourtyard(pcbnew.F_CrtYd)
                if poly.OutlineCount(): self.assertGreaterEqual(_poly_gap_mm(env,poly,.10)+1e-6,.10,(ref,other))
                for p in fp.Pads():
                    if p.IsOnCopperLayer() and p.IsOnLayer(pcbnew.F_Cu):
                        self.assertFalse(env.Collide(p.GetEffectiveShape(pcbnew.F_Cu),pcbnew.FromMM(.10)),(ref,other,p.GetNumber()))
                if poly.OutlineCount():
                    for p in footprints[ref].Pads():
                        if p.IsOnCopperLayer() and p.IsOnLayer(pcbnew.F_Cu):
                            self.assertFalse(poly.Collide(p.GetEffectiveShape(pcbnew.F_Cu),pcbnew.FromMM(.10)),(other,ref,p.GetNumber()))
        # Hostile historical single-cap west shift without companion shifts.
        bad=footprints['C_VDDA1_4U7']
        bad.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(87.35),pcbnew.FromMM(68.7)))
        bad.BuildCourtyardCaches()
        self.assertLess(_poly_gap_mm(footprints['C_LDO_A'].GetCourtyard(pcbnew.F_CrtYd),bad.GetCourtyard(pcbnew.F_CrtYd),.10),.10)


if __name__ == '__main__': unittest.main()
