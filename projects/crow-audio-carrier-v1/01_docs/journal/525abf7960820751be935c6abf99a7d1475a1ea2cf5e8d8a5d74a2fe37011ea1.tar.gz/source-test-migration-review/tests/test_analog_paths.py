"""Independent native source endpoints plus hostile saved-text model fixtures.

These tests do not turn a conditional model into physical DCR qualification.
No live/generated board is written or loaded.
"""
import copy
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest

import yaml

PROJECT = Path(__file__).resolve().parents[2]
REPO = PROJECT.parents[1]
sys.path.insert(0, str(PROJECT/'03_src'))
import check_analog_paths as checker
from test_route_source_contract import load_source
from route_and_stitch_generic import _krt_args
from copper_length_audit import load_groups, grade_declared_paths

BASE = '6b31017090831965530a32c24618cbaecbffa0b8'


def fixture_tracks(length_mm=10., layer='F.Cu', width=.2):
    # This fixture derives the 48 physical net identities from the native
    # circuit, independently of the checker that generates expected paths.
    _, _, _, _, _, pins = load_source()
    names = sorted({n for n in pins.values() if re.fullmatch(r'OPA_[PN][1-8]|FILTER[1-8][PN]|ADC[1-8][PN]', n)})
    assert len(names) == 48
    return '\n' + '\n'.join(f'\t(segment (start 0 0) (end {length_mm} 0) (width {width}) (layer "{layer}") (net "{n}"))' for n in names)


class AnalogPathTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.floor, cls.route, cls.nets, cls.stack, cls.comps, cls.pins = load_source()
        cls.groups, _ = load_groups(PROJECT)

    def test_real_shared_loader_and_native_all_leaf_coverage(self):
        result = checker.validate_source(self.groups, self.route, self.pins)
        self.assertEqual((result['groups'], result['nets'], result['endpoints'], result['paths']), (24, 48, 192, 144))
        self.assertEqual(len(self.groups), 26)
        self.assertEqual(result['physical_dcr_status'], 'UNVERIFIED')

    def test_old_unmatched_source_and_missing_branch_are_rejected(self):
        old = yaml.safe_load(subprocess.check_output(['git','show',BASE+':projects/crow-audio-carrier-v1/03_src/rules/nets.yaml'], cwd=REPO, timeout=15))
        with self.assertRaisesRegex(checker.PathError, 'census'):
            checker.validate_source(old['length_match'], self.route, self.pins)
        bad = copy.deepcopy(self.groups)
        bad['ANALOG_CH1_ADC']['paths']['P'].pop()
        with self.assertRaisesRegex(checker.PathError, 'endpoint paths'):
            checker.validate_source(bad, self.route, self.pins)

    def test_crossed_native_pin_and_ghost_leaf_are_rejected(self):
        for kind in ['cross', 'extra']:
            pins = copy.deepcopy(self.pins)
            if kind == 'cross':
                pins[('U_ADC','40')] = 'ADC1N'
            else:
                pins[('TP_EXTRA','1')] = 'ADC1P'
            with self.assertRaisesRegex(checker.PathError, 'census/identity'):
                checker.validate_source(self.groups, self.route, pins)

    def test_matching_recipe_is_real_krt_argv_and_cannot_be_omitted(self):
        wave = next(w for w in self.route['route']['waves'] if w['name']=='analog')
        argv = _krt_args(wave)
        self.assertEqual(argv.count('--length-match-group'), 24)
        self.assertIn('--length-match-tolerance', argv)
        for key in checker.MATCH_KEYS:
            bad = copy.deepcopy(self.route)
            next(w for w in bad['route']['waves'] if w['name']=='analog').pop(key)
            with self.assertRaisesRegex(checker.PathError, 'recipe'):
                checker.validate_source(self.groups, bad, self.pins)

    def test_unrelated_digital_matching_and_analog_recipe_preserved(self):
        # Preserve the contracts actually owned by this suite. A reverse
        # whole-tree migration through the removed TPS/buffer architecture is
        # not authority for the current layout or power rails.
        def before(name):
            return yaml.safe_load(subprocess.check_output(
                ['git','show','1b725986:projects/crow-audio-carrier-v1/03_src/'+name],
                cwd=REPO, timeout=15))
        old_nets=before('rules/nets.yaml')
        for name in ('MCH_INPUT_SECTIONS','BUFFERED_DIGITAL_SECTIONS'):
            self.assertEqual(self.nets['length_match'][name],old_nets['length_match'][name])
        old_route=before('route.yaml')
        for name in ('clocks','analog'):
            self.assertEqual(next(w for w in self.route['route']['waves'] if w['name']==name),
                             next(w for w in old_route['route']['waves'] if w['name']==name))
        self.assertEqual(self.nets['reference_plane_checks'],old_nets['reference_plane_checks'])

    def test_each_grounded_filter_shunt_is_a_required_leaf(self):
        for n in range(1,9):
            for leg in ('P','N'):
                for index in (1,2):
                    bad=copy.deepcopy(self.groups)
                    paths=bad[f'ANALOG_CH{n}_FILTER']['paths'][leg]
                    paths[:]=[p for p in paths if p['id']!=f'shunt{index}']
                    with self.subTest(channel=n,leg=leg,index=index),self.assertRaisesRegex(checker.PathError,'endpoint paths'):
                        checker.validate_source(bad,self.route,self.pins)

    def test_conditional_inventory_charges_all_three_nets_and_keeps_unknowns(self):
        result = checker.inventory_model(fixture_tracks(), {'F.Cu':.035,'B.Cu':.035}, 1.6)
        self.assertEqual(result['model_status'], 'PASS')
        self.assertEqual((len(result['nets']),len(result['legs'])), (48,16))
        self.assertAlmostEqual(result['legs'][0]['inventory_model_ohm'], 2.1643958e-8*.030/(.0002*.000035))
        self.assertEqual(result['reserve_factor'], 2)
        self.assertEqual(result['physical_dcr_status'], 'UNVERIFIED')
        self.assertIn('10 ohm series resistors', result['excluded'])
        self.assertIn('pad spreading', result['excluded'])

    def test_long_trace_and_extra_branch_inventory_fail_screen(self):
        bad = fixture_tracks() + '\n\t(segment (start 10 0) (end 1010 0) (width 0.2) (layer "F.Cu") (net "ADC1P"))'
        result = checker.inventory_model(bad, {'F.Cu':.035,'B.Cu':.035}, 1.6)
        self.assertEqual(result['model_status'],'FAIL')
        self.assertEqual(sum(not r['within_design_screen'] for r in result['legs']), 1)

    def test_missing_nets_underwidth_inner_layer_and_nonfinite_fail(self):
        fixtures = [fixture_tracks().replace('(net "ADC1P")','(net "ABSENT")'),
                    fixture_tracks(width=.18), fixture_tracks(layer='In1.Cu'),
                    fixture_tracks().replace('(end 10.0 0)', '(end 1e999 0)')]
        for bad in fixtures:
            with self.assertRaises(checker.PathError):
                checker.inventory_model(bad, {'F.Cu':.035,'B.Cu':.035}, 1.6)

    def test_arc_via_and_layer_thickness_are_actually_priced(self):
        base = fixture_tracks()
        changed = base + '\n\t(arc (start 10 0) (mid 11 1) (end 12 0) (width 0.2) (layer "B.Cu") (net "ADC1P"))'
        changed += '\n\t(via (at 12 0) (size 0.5) (drill 0.2) (layers "F.Cu" "B.Cu") (net "ADC1P"))'
        result = checker.inventory_model(changed, {'F.Cu':.035,'B.Cu':.0175}, 1.6)['nets']['ADC1P']
        self.assertAlmostEqual(result['track_mm'],10+math.pi)
        self.assertAlmostEqual(result['track_ohm'],2.1643958e-8*1000*(10/(.2*.035)+math.pi/(.2*.0175)))
        self.assertAlmostEqual(result['via_ohm'],2.1643958e-8*1.6*1000/(math.pi*.2*.018))
        for bad in [changed.replace('(drill 0.2)','(drill 0.15)'), base+'\n\t(zone (net "ADC1P"))']:
            with self.assertRaises(checker.PathError):
                checker.inventory_model(bad, {'F.Cu':.035,'B.Cu':.035}, 1.6)

    def test_shared_endpoint_gate_rejects_real_path_skew_and_orphan(self):
        decl = self.groups['ANALOG_CH1_OUTPUT']
        def measure(n_main=10., orphan=False):
            nets, pads = {}, {}
            for leg, y, main in [('P',0.,10.),('N',4.,n_main)]:
                paths = decl['paths'][leg]
                net = paths[0]['segments'][0]['net']
                start = paths[0]['segments'][0]['from']
                ends = [p['segments'][0]['to'] for p in paths]
                pts = [(start,0.,y),(ends[0],main,y),(ends[1],0.,y+1.)]
                pads[net] = [dict(ref=p.rsplit('.',1)[0],pad=p.rsplit('.',1)[1],shape='rect',kind='smd',x=x,y=py,angle=0.,sx=.2,sy=.2,layers=['F.Cu']) for p,x,py in pts]
                segs=[('F.Cu',(0.,y),(main,y),main),('F.Cu',(0.,y),(0.,y+1.),1.)]
                if orphan and leg=='P':segs.append(('F.Cu',(50.,50.),(51.,50.),1.))
                nets[net]=dict(segs=segs,vias=[],zones=0)
            row=dict(verdict='PASS');res=dict(unreached=[],fails=[],n_electrical_measured=0)
            grade_declared_paths('fixture',decl,row,nets,['F.Cu','In1.Cu','In2.Cu','B.Cu'],pads,{},res)
            return row,res
        row,result=measure();self.assertFalse(result['fails']);self.assertFalse(result['unreached'])
        self.assertEqual(result['n_electrical_measured'],4)
        self.assertTrue(any('R-LEN-SPREAD' in r for r in measure(12.)[1]['fails']))
        self.assertTrue(any('R-LEN-OFFPATH' in r for r in measure(orphan=True)[1]['fails']))

    def test_both_conductors_enforce_source_and_saved_copper(self):
        for name in ['rebuild_all.sh','rebuild_reuse.sh']:
            script=(PROJECT/'03_src'/name).read_text()
            self.assertIn('03_src/check_analog_paths.py --source-only',script)
            self.assertIn('03_src/check_analog_paths.py --board',script)
            self.assertLess(script.index('run_stage analog_copper'),script.index('run_stage route_acceptance'))
            self.assertNotIn('check_analog_paths.py || true',script)


if __name__ == '__main__':unittest.main()
