# Carrier source-test migration review

## Verdict

Adopt the proposed test-only migration in `proposed.patch`. Do not restore
`_poly_seg_dist`, `_point_in_poly`, `_seg_seg_dist`, or `launch_points` to
`escape_check.py`, and do not redirect these pre-board tests to the owning
native P-LAND implementation.

The current 23 errors have one migration root: three source-test modules import
private functions deleted by commit `5de08b98` when P-LAND moved from a float
polygon maximum to finite native witnesses. `test_route_source_contract` and
`test_digital_launch_source` are high-fanout test modules, so their two failed
imports prevent collection or execution across the rest of the source suite.
The removal is intentional production behavior, not a missing compatibility
export.

## Proposed patch

The exact patch is archived as `proposed.patch`. It:

1. Adds `03_src/tests/source_geometry.py`, explicitly scoped to pre-board
   source regression tests. It gives public, descriptive names to the four
   legacy operations: strict point-in-polygon, polygon-edge/segment distance,
   segment/segment distance, and bounded source start sampling.
2. Repoints only the three direct callers. Production code is unchanged.
3. Adds three focused positive/hostile controls, including crossing,
   separation, degenerate segments, containment kept separate from edge
   distance, and a concave polygon whose notch must not yield a start.
4. Fixes the independent model-order assertion by proving that all region
   patterns precede all three model overrides. It no longer assumes the model
   overrides are the final list entries, because the authorized exact 33-ref
   manual-placement exclusion is now appended as an `attrs` pattern.

The helper preserves the source tests' engineering constants (0.03 mm start
step, 25-point cap, existing clearance/width/reach values at call sites). It
also enforces the helper's stated property that returned samples are inside a
polygon: the bounding-box center is included only when it is actually inside.
This affects a concave/custom outline safely; the callers already add the
native pad center separately when that point is relevant.

## Authority boundary

These source tests instantiate isolated footprint shapes and authored seed
segments before a complete board exists. Their ray probes are useful local
screens, but they do not own physical gate authority and must retain their
existing labels: source geometry only, not generated P-LAND, native DRC,
connectivity, SI, or routability.

The owning physical interface is `land_witness.BoardContext.search()` on a
complete board/project/ruleset. It admits enabled copper layers and effective
native pad polygons, constructs real native tracks, resolves width and
Track–Pad clearance rules in context, runs native `Collide`, and returns a
`VALIDATED_WITNESS` or bounded `NO_VALIDATED_WITNESS` with coverage and limiting
pair evidence. If this project later needs a board-level regression, add a
separate generated-board consumer of that interface. Reusing it here would
silently change a pre-board source screen into the P-LAND authority and would
require generated canonical inputs that these tests deliberately do not own.

`launch_points` was especially unsafe as an import contract: its generic name
suggested a stable production API, but it was a private float-grid detail of
the retired checker. `sample_polygon_starts` names the remaining use precisely
and keeps it in the governed test directory. It must not be described as a
native witness.

## Validation and remaining failures

`git apply --check proposed.patch` passed against the current shared worktree.
The focused isolated replay passed 4 tests: three helper controls plus
`test_model_overrides_remain_exact_and_after_region_patterns`.

A full isolated discovery replay was run under the required bounded runtime.
It reached 120.058 seconds and timed out after substantial execution; no
`ImportError` appeared in its complete captured output. This is evidence that
the collection break was removed, but it is not a whole-suite pass. The replay
also surfaced the expected current native-netlist identity errors (for example
F1 still has `Fuse:Fuse_1812_4532Metric` while the current part authority asks
for `crow_audio_carrier:Littelfuse_1812L035_60_Exact`). Those checks must remain
strict until canonical native regeneration; the patch does not alter them,
invent a replacement netlist, or weaken identity.

No thresholds were relaxed, no tests were deleted, no generated file was
borrowed, and no live repository file was edited.

## Root application plan

Apply `proposed.patch`, run the focused helper and direct-caller modules, then
run the complete source suite after the canonical native netlist renewal. Keep
native identity mismatches red until that renewal is produced by the owning
generation path. A complete suite run remains the final acceptance step.
