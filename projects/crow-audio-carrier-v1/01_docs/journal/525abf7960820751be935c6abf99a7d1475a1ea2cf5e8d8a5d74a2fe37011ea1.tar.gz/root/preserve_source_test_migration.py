from pathlib import Path
from datetime import datetime,timezone
import sys,json,hashlib,tarfile,io,shutil,subprocess
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911')
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet
from pipeline_artifacts import validate_task_outputs
sha=lambda b:hashlib.sha256(b).hexdigest();payload={};proof=[]
for family in ['source-test-migration-review']:
 j=json.loads((D/(family+'-opened.json')).read_text())[0];root=Path(j['project']);a=Path(j['attempt']).parent;o=a/'outputs';e=TaskEnvelope.from_json((a/'envelope.json').read_text())
 assert json.loads((a/'attempt.json').read_text())['status']=='PASS';assert verify_input_packet(e,root)[0]
 v=validate_task_outputs(o,e.completion['outputs'],subject=e.subject.to_mapping(),checks=e.completion['checks']);m=json.loads((o/'evidence-manifest.json').read_text());members=m['members'];ar=o/'evidence.tar.gz';arsha=sha(ar.read_bytes());meta=m.get('archive');meta=meta if isinstance(meta,dict) else m
 declared=meta.get('sha256',meta.get('archive_sha256',meta.get('archiveSHA256')));size=meta.get('size',meta.get('archive_size',meta.get('archiveSize')))
 if declared:assert arsha==declared
 if size:assert ar.stat().st_size==size
 with tarfile.open(ar) as t:
  actual=[x for x in t.getmembers() if x.isfile()];assert len(actual)==len(members);assert {x.name.removeprefix('./') for x in actual}=={x['path'] for x in members}; names={x.name.removeprefix('./'):x.name for x in actual}
  for row in members:b=t.extractfile(names[row['path']]).read();assert len(b)==row['size'] and sha(b)==row['sha256']
 for f in root.rglob('*'):
  if f.is_file() and 'scratch' not in f.relative_to(root).parts:payload[family+'/'+f.relative_to(root).as_posix()]=f
 proof.append({'family':family,'input_count':len(e.input_packet),'delivery':v,'archive_sha256':arsha,'archive_size':ar.stat().st_size,'members_verified':len(members),'archive_sha_declared':bool(declared)})
(D/'source-test-migration-root-verification.json').write_text(json.dumps(proof,indent=2)+'\n')

for f in [D/'source-test-migration-root-verification.json',D/'preserve_source_test_migration.py']:payload['root/'+f.name]=f
manifest={n:{'size':f.stat().st_size,'sha256':sha(f.read_bytes())} for n,f in payload.items()};temp=D/'source-test-migration-review.tar.gz'
with tarfile.open(temp,'w:gz',compresslevel=3) as t:
 for n,f in payload.items():t.add(f,arcname=n,recursive=False)
 b=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('MANIFEST.json');info.size=len(b);t.addfile(info,io.BytesIO(b))
h=sha(temp.read_bytes());target=P/'01_docs/journal'/f'{h}.tar.gz';assert not target.exists();shutil.copyfile(temp,target)
with tarfile.open(target) as t:
 assert len(t.getmembers())==len(payload)+1
 for n,row in manifest.items():b=t.extractfile(n).read();assert len(b)==row['size'] and sha(b)==row['sha256']
with (P/'01_docs/journal/contracts.md').open('a') as w:w.write(f'\n\n## Allowed source test migration review\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Immutable independent source-only test geometry migration review, proposed patch and bounded partial replay; canonical identity failures retained |\n')
(D/'source-test-migration-preservation-result.json').write_text(json.dumps({'archive':str(target),'members':len(payload),'reviews':proof},indent=2)+'\n');print(json.dumps({'archive':str(target),'members':len(payload)},indent=2))
