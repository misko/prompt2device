review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent /root/rj45_pin_carrier_rectifiers_clockground1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: e85b1461a82f3d3853c19fae694693816e31570d23d37019ef187d6428bea4ae
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: e6d5b0b89efd79051b082f70b283ec7e85e1170ed11ddb94581744d26904c9c7

Limited coverage: C_FILT1_470U, C_FILT2_470U, C_HOLD1, C_HOLD2, D_BUCK_IN, D_HOLD only. This is not whole-board acceptance or order authorization. Immutable hashes above are supplied subject bindings, not separately reviewed conclusions.

Manufacturer figure derivation preceded reading dossier tables. All three exact PDFs were digest-verified. Inspected rendered images are archived. No schematic, author rationale, historical review, or live project was inspected.

Manufacturer geometry and physical identities

Panasonic FK: page 1 Marking and Dimensions, page 2 Standard products Land / Pad pattern, page 3 exact EEEFK1A471P standard row. Two terminals, positive at chamfered base end, negative at square base end and negative can marking; no EP. Page 1 terminal-side drawing is converted to top view by reflecting y, then rotated so positive is west and negative east. The numeric CAD aliases 1=positive, 2=negative are not manufacturer numeric designations. Exact part is standard size F, 8 x 10.2 mm; the vibration-proof supportive terminals do not apply. Standard land dimensions a=3.1, b=4.0, c=2.0 mm imply center spacing a+b=7.1 mm and two 4.0 x 2.0 mm lands, matching all four dossiers.

US1B DS16008 Rev11-2: page 1 Mechanical Data, top/bottom photos and Marking Information; page 4 Package Outline Dimensions and Suggested Pad Layout. B340A DS30891 Rev19-2: corresponding page 1 and page 6 figures. Both SMA packages have banded cathode at left in the marking/top outline and anode opposite, two distinct terminals and no EP. Bottom photos are not substituted for top views. Native aliases 1=K west and 2=A east match the shown top polarity orientation. No manufacturer numeric pin designations are asserted. Suggested centers +/-2.0 mm and 2.50 mm land length match; native 1.8 mm land width exceeds suggested 1.7 mm by 0.1 mm without identity or polarity error.

All six instances are front mounted. Component-top +x right/+y down needs no reflection from native relative frame. Every native coordinate was recomputed using its declared position/rotation and matched within 0.000001 mm. For two collinear terminals, clockwise/counterclockwise winding and a pin-1 corner are inapplicable, not evidence of a winding pass. The two opposed physical identities are individually retained; there are no fused aliases, duplicate-number lands, or EP requirements. Assembly artwork and manufacturing placement files are not in this packet and are outside this pin-dossier review.

C_FILT1_470U — VERDICT: PASS
Measured: native pads=2; distinct physical identities=2; EP=0; collapsed identities=0.
Primary: projects/crow-audio-carrier-v1/02_parts/EEEFK1A471P/Panasonic_FK_ABA0000C1181_20260210.pdf; SHA-256 b36857d089adaddf3042b33bf11d0f7d83bf70734e983f33b7827152e11854e3; figures pages 1/2 Marking, Dimensions, Standard Land / Pad; page 3 exact standard row.
C_FILT1_470U pin 1 (POSITIVE): expected higher-potential positive supply/filter rail; observed FILT1P, component-top [-3.55, 0.0] W, native [91.55, 55.3]. PASS.
C_FILT1_470U pin 2 (NEGATIVE): expected lower-potential return; observed GND, component-top [3.55, 0.0] E, native [84.45, 55.3]. PASS.

C_FILT2_470U — VERDICT: PASS
Measured: native pads=2; distinct physical identities=2; EP=0; collapsed identities=0.
Primary: projects/crow-audio-carrier-v1/02_parts/EEEFK1A471P/Panasonic_FK_ABA0000C1181_20260210.pdf; SHA-256 b36857d089adaddf3042b33bf11d0f7d83bf70734e983f33b7827152e11854e3; figures pages 1/2 Marking, Dimensions, Standard Land / Pad; page 3 exact standard row.
C_FILT2_470U pin 1 (POSITIVE): expected higher-potential positive supply/filter rail; observed FILT2P, component-top [-3.55, 0.0] W, native [91.55, 84.7]. PASS.
C_FILT2_470U pin 2 (NEGATIVE): expected lower-potential return; observed GND, component-top [3.55, 0.0] E, native [84.45, 84.7]. PASS.

C_HOLD1 — VERDICT: PASS
Measured: native pads=2; distinct physical identities=2; EP=0; collapsed identities=0.
Primary: projects/crow-audio-carrier-v1/02_parts/EEEFK1A471P/Panasonic_FK_ABA0000C1181_20260210.pdf; SHA-256 b36857d089adaddf3042b33bf11d0f7d83bf70734e983f33b7827152e11854e3; figures pages 1/2 Marking, Dimensions, Standard Land / Pad; page 3 exact standard row.
C_HOLD1 pin 1 (POSITIVE): expected higher-potential positive supply/filter rail; observed 5V_LDO_HOLD, component-top [-3.55, 0.0] W, native [55.45, 83.9]. PASS.
C_HOLD1 pin 2 (NEGATIVE): expected lower-potential return; observed GND, component-top [3.55, 0.0] E, native [62.55, 83.9]. PASS.

C_HOLD2 — VERDICT: PASS
Measured: native pads=2; distinct physical identities=2; EP=0; collapsed identities=0.
Primary: projects/crow-audio-carrier-v1/02_parts/EEEFK1A471P/Panasonic_FK_ABA0000C1181_20260210.pdf; SHA-256 b36857d089adaddf3042b33bf11d0f7d83bf70734e983f33b7827152e11854e3; figures pages 1/2 Marking, Dimensions, Standard Land / Pad; page 3 exact standard row.
C_HOLD2 pin 1 (POSITIVE): expected higher-potential positive supply/filter rail; observed 5V_LDO_HOLD, component-top [-3.55, 0.0] W, native [59.55, 95.0]. PASS.
C_HOLD2 pin 2 (NEGATIVE): expected lower-potential return; observed GND, component-top [3.55, 0.0] E, native [52.45, 95.0]. PASS.

D_BUCK_IN — VERDICT: PASS
Measured: native pads=2; distinct physical identities=2; EP=0; collapsed identities=0.
Primary: projects/crow-audio-carrier-v1/02_parts/US1B-13-F/Diodes_US1A_US1M_DS16008_Rev11-2.pdf; SHA-256 d50b2773c0300d97a77f5125419098c8130ecaf967202a44be2b182de8a15c1f; figures pages 1/4 Marking, top view, Package Outline and Suggested Pad Layout.
D_BUCK_IN pin 1 (K): expected downstream supply at banded cathode; observed 12V_BUCK_IN, component-top [-2.0, 0.0] W, native [26.0, 60.0]. PASS.
D_BUCK_IN pin 2 (A): expected upstream supply at unbanded anode; observed 12V_PROTECTED, component-top [2.0, 0.0] E, native [26.0, 56.0]. PASS.

D_HOLD — VERDICT: PASS
Measured: native pads=2; distinct physical identities=2; EP=0; collapsed identities=0.
Primary: projects/crow-audio-carrier-v1/02_parts/B340A-13-F/B340A_DS30891_Rev19-2.pdf; SHA-256 453cbd34d996482abd07ac694c4e2d812d26b1d679d05ee325acc5c3eeb79917; figures pages 1/6 Marking, top view, Package Outline and Suggested Pad Layout.
D_HOLD pin 1 (K): expected downstream supply at banded cathode; observed 5V_LDO_FEED, component-top [-2.0, 0.0] W, native [48.4, 58.1]. PASS.
D_HOLD pin 2 (A): expected upstream supply at unbanded anode; observed 5V_BUCK, component-top [2.0, 0.0] E, native [52.4, 58.1]. PASS.

Symmetry: all four capacitors map pad 1 to their positive filter/hold rail and pad 2 to GND, including 0 and 180 degree instances. Both diodes map pad 2/A to upstream supply (12V_PROTECTED or 5V_BUCK), pad 1/K to downstream supply (12V_BUCK_IN or 5V_LDO_FEED), including 0 and 90 degree instances. No structural divergence. Diode forward direction is A to K. This is function/net-type sanity, not a circuit startup, voltage-margin, ripple-current or transient analysis.

No unresolved pin findings. Domain SOUND applies only to these six commissioned instances.
