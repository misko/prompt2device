#!/usr/bin/python3
from __future__ import annotations
import hashlib, json, os, re, shutil, sys, xml.etree.ElementTree as ET
from pathlib import Path
from PIL import Image, ImageChops, ImageDraw

ROOT=Path('/tmp/carrier-waiver-schematic-delta-7_ylit6c')
RUN=ROOT/'06_build/task_runs/waiver-schematic-delta'
SCR=RUN/'scratch'; SCR.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,'/home/mouse9911/gits/circuits/skills/pcb-design/scripts')
import pipeline_runtime

# Clear only artifacts created by an earlier partial invocation of this helper.
for stale in ('previous','current'):
 p=SCR/stale
 if p.exists(): shutil.rmtree(p)
for stale in ('kicad-previous.log','kicad-current.log','pdftoppm-previous.log','pdftoppm-current.log','analysis.json','current-all19-contact.png','current-changed-strips.png','view-page-01.png','view-page-14.png','view-page-19.png'):
 p=SCR/stale
 if p.exists(): p.unlink()

def sha(p):
 h=hashlib.sha256();
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
def canon(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()

env=json.loads((RUN/'envelope.json').read_text())
checks=[]
for i in env['input_packet']:
 p=ROOT/i['path']; checks.append({'name':i['name'],'path':i['path'],'expected_size':i['size'],'actual_size':p.stat().st_size,'expected_sha256':i['sha256'],'actual_sha256':sha(p)})
assert all(x['expected_size']==x['actual_size'] and x['expected_sha256']==x['actual_sha256'] for x in checks)

prev={str(p.relative_to(ROOT/'previous')):(p.stat().st_size,sha(p)) for p in (ROOT/'previous').rglob('*') if p.is_file()}
curr={str(p.relative_to(ROOT/'current')):(p.stat().st_size,sha(p)) for p in (ROOT/'current').rglob('*') if p.is_file()}
tree={'previous_count':len(prev),'current_count':len(curr),'added':sorted(curr.keys()-prev.keys()),'removed':sorted(prev.keys()-curr.keys()),'changed':[p for p in sorted(curr.keys()&prev.keys()) if curr[p]!=prev[p]]}

# Waiver semantic comparison.
import yaml
pw=yaml.safe_load((ROOT/'previous/03_src/rules/policy_waivers.yaml').read_text())
cw=yaml.safe_load((ROOT/'current/03_src/rules/policy_waivers.yaml').read_text())
def find_waiver(x):
 if isinstance(x,dict):
  if x.get('id')=='P-SILK-REF' or x.get('waiver_id')=='P-SILK-REF': return x
  for v in x.values():
   z=find_waiver(v)
   if z:return z
 if isinstance(x,list):
  for v in x:
   z=find_waiver(v)
   if z:return z
 return None
pwa=find_waiver(pw); cwa=find_waiver(cw)
refskey=next(k for k,v in cwa.items() if isinstance(v,list) and len(v)==25)
waiver={'key':refskey,'previous_refs':pwa[refskey],'current_refs':cwa[refskey],'removed':sorted(set(pwa[refskey])-set(cwa[refskey])),'added':sorted(set(cwa[refskey])-set(pwa[refskey])),'unchanged':len(set(pwa[refskey])&set(cwa[refskey])),'ceiling':cwa.get('ceiling'),'other_fields_equal':{k:v for k,v in pwa.items() if k!=refskey}=={k:v for k,v in cwa.items() if k!=refskey}}

# circuit JSON object comparison: warnings and volatile project hash classified.
pj=json.loads((ROOT/'previous/03_tscircuit/build/circuit.json').read_text()); cj=json.loads((ROOT/'current/03_tscircuit/build/circuit.json').read_text())
warn=lambda o: str(o.get('type','')).endswith('_warning')
def stable(o):
 o=json.loads(json.dumps(o))
 if o.get('type')=='source_project_metadata': o.pop('source_filesystem_md5_hash',None)
 return o
pnon=[stable(o) for o in pj if not warn(o)]; cnon=[stable(o) for o in cj if not warn(o)]
types=lambda a:{t:sum(1 for o in a if o.get('type')==t) for t in sorted({o.get('type') for o in a})}
circuit={'previous_objects':len(pj),'current_objects':len(cj),'previous_warning_count':sum(map(warn,pj)),'current_warning_count':sum(map(warn,cj)),'nonwarning_previous':len(pnon),'nonwarning_current':len(cnon),'stable_nonwarning_equal':pnon==cnon,'stable_nonwarning_sha256':hashlib.sha256(canon(pnon)).hexdigest(),'types_previous':types(pj),'types_current':types(cj)}

# Complete UUID occurrence bijection and residual.
ps=(ROOT/'previous/04_kicad/crow_audio_carrier_v1.kicad_sch').read_text(); cs=(ROOT/'current/04_kicad/crow_audio_carrier_v1.kicad_sch').read_text()
pat=re.compile(r'(?<![0-9a-fA-F])([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})(?![0-9a-fA-F])')
pu=pat.findall(ps); cu=pat.findall(cs); assert len(pu)==len(cu)
fwd={}; rev={}; conflict=[]
for a,b in zip(cu,pu):
 if a in fwd and fwd[a]!=b: conflict.append([a,fwd[a],b])
 if b in rev and rev[b]!=a: conflict.append([b,rev[b],a])
 fwd[a]=b; rev[b]=a
sub=pat.sub(lambda m:fwd[m.group(1)],cs)
res=[]
if sub!=ps:
 import difflib
 res=list(difflib.unified_diff(ps.splitlines(),sub.splitlines(),n=1))
uuid={'previous_occurrences':len(pu),'current_occurrences':len(cu),'previous_unique':len(set(pu)),'current_unique':len(set(cu)),'bijection_size':len(fwd),'conflicts':conflict,'residual_line_count':len(res),'residual':res[:200],'mapping_sha256':hashlib.sha256(canon(sorted(fwd.items()))).hexdigest()}

# Copy exact native/pdf inputs before native tools.
for side in ('previous','current'):
 d=SCR/side; d.mkdir(exist_ok=True)
 for rel,name in [('04_kicad/crow_audio_carrier_v1.kicad_sch','design.kicad_sch'),('03_tscircuit/build/schematic.pdf','schematic.pdf'),('06_build/netlists/crow_audio_carrier_v1.net','canonical.net')]:
  shutil.copyfile(ROOT/side/rel,d/name); assert sha(ROOT/side/rel)==sha(d/name)

commands=[]
spec={'id':'DELTA-NATIVE','work_class':'local','timeout_s':75,'produces':[]}
for side in ('previous','current'):
 argv=['/usr/bin/kicad-cli','sch','export','netlist','-o',str(SCR/side/'fresh.net'),str(SCR/side/'design.kicad_sch')]
 out=pipeline_runtime.run_stage(spec,argv,log_path=SCR/f'kicad-{side}.log',cwd=SCR/side,env=dict(os.environ),console=None,run_id=f'kicad-{side}')
 commands.append({'argv':argv,'cwd':str(SCR/side),'log':f'kicad-{side}.log','returncode':out.returncode,'started_at':out.started_at,'completed_at':out.finished_at,'elapsed_s':out.elapsed_s,'timed_out':out.timed_out})
 assert out.returncode==0
spec2={'id':'DELTA-PDF','work_class':'local','timeout_s':75,'produces':[]}
for side in ('previous','current'):
 argv=['/usr/bin/pdftoppm','-png','-r','120',str(SCR/side/'schematic.pdf'),str(SCR/side/'page')]
 out=pipeline_runtime.run_stage(spec2,argv,log_path=SCR/f'pdftoppm-{side}.log',cwd=SCR/side,env=dict(os.environ),console=None,run_id=f'pdf-{side}')
 commands.append({'argv':argv,'cwd':str(SCR/side),'log':f'pdftoppm-{side}.log','returncode':out.returncode,'started_at':out.started_at,'completed_at':out.finished_at,'elapsed_s':out.elapsed_s,'timed_out':out.timed_out})
 assert out.returncode==0

def forms(text,name):
 out=[]
 for m in re.finditer(r'\(\s*'+re.escape(name)+r'\b',text):
  dep=0; quoted=False; esc=False
  for j in range(m.start(),len(text)):
   ch=text[j]
   if quoted:
    if esc: esc=False
    elif ch=='\\': esc=True
    elif ch=='"': quoted=False
   elif ch=='"': quoted=True
   elif ch=='(': dep+=1
   elif ch==')':
    dep-=1
    if dep==0: out.append(text[m.start():j+1]); break
 return out
def fld(form,name):
 m=re.search(r'\('+re.escape(name)+r'\s+"((?:\\.|[^"\\])*)"\)',form)
 return bytes(m.group(1),'utf8').decode('unicode_escape') if m else ''
def projection(path):
 text=path.read_text(); comps=[]; nets=[]; nodes=[]; nc=[]
 for c in forms(text,'comp'):
  r=fld(c,'ref')
  if r: comps.append((r,fld(c,'value'),fld(c,'footprint')))
 for n in forms(text,'net'):
  name=fld(n,'name'); ns=[]
  for x in forms(n,'node'):
   t=(name,fld(x,'ref'),fld(x,'pin'),fld(x,'pinfunction'),fld(x,'pintype')); nodes.append(t); ns.append(t[1:])
   if t[4].endswith('+no_connect'): nc.append(t)
  if name: nets.append((name,tuple(sorted(ns))))
 return {'components':sorted(comps),'nets':sorted(nets),'nodes':sorted(nodes),'nc':sorted(nc)}
projs={}
for side in ('previous','current'):
 for kind in ('canonical','fresh'): projs[f'{side}_{kind}']=projection(SCR/side/f'{kind}.net')
base=projs['previous_canonical']; equal={k:v==base for k,v in projs.items()}
net={'counts':{k:len(v) for k,v in base.items()},'equal_to_previous_canonical':equal,'projection_sha256':hashlib.sha256(canon(base)).hexdigest(),'raw_sha256':{f'{s}_{k}':sha(SCR/s/f'{k}.net') for s in ('previous','current') for k in ('canonical','fresh')}}

# Pixel compare all 19 exact-PDF rerenders and build visual evidence.
pages=[]; thumbs=[]
for i in range(1,20):
 pp=SCR/'previous'/f'page-{i:02d}.png'; cp=SCR/'current'/f'page-{i:02d}.png'; a=Image.open(pp).convert('RGB'); b=Image.open(cp).convert('RGB'); d=ImageChops.difference(a,b); box=d.getbbox(); changed=0
 if box:
  changed=sum(1 for px in d.getdata() if px!=(0,0,0))
 circuit_crop=(0,100,b.width,b.height)
 pages.append({'page':i,'dimensions':[b.width,b.height],'previous_png_sha256':sha(pp),'current_png_sha256':sha(cp),'changed_pixels':changed,'difference_bbox':list(box) if box else None,'circuit_area_equal':ImageChops.difference(a.crop(circuit_crop),b.crop(circuit_crop)).getbbox() is None})
 t=b.copy(); t.thumbnail((300,210)); thumbs.append((i,t.copy()))
W=1500; H=5*240; sheet=Image.new('RGB',(W,H),'white'); dr=ImageDraw.Draw(sheet)
for j,(i,t) in enumerate(thumbs):
 x=(j%4)*375; y=(j//4)*240; sheet.paste(t,(x,y+20)); dr.text((x+4,y+2),f'Page {i}',fill='black')
sheet.save(SCR/'current-all19-contact.png')
# changed caption strips and representative full pages 1,14,19.
strips=Image.new('RGB',(1500,19*34),'white')
for i in range(1,20):
 b=Image.open(SCR/'current'/f'page-{i:02d}.png').convert('RGB'); strips.paste(b.crop((0,70,b.width,104)),(0,(i-1)*34))
strips.save(SCR/'current-changed-strips.png')
for i in (1,14,19): shutil.copyfile(SCR/'current'/f'page-{i:02d}.png',SCR/f'view-page-{i:02d}.png')
pdf={'page_count':len(pages),'all_circuit_areas_equal':all(x['circuit_area_equal'] for x in pages),'pages':pages,'pdf_sha256':{'previous':sha(SCR/'previous/schematic.pdf'),'current':sha(SCR/'current/schematic.pdf')}}

result={'input_verification':{'count':len(checks),'all_pass':True,'checks':checks},'tree':tree,'waiver':waiver,'circuit':circuit,'uuid':uuid,'netlist':net,'pdf':pdf,'commands':commands,'bindings':json.loads((ROOT/'bindings.json').read_text()),'envelope_raw_sha256':sha(RUN/'envelope.json'),'envelope_canonical_sha256':hashlib.sha256(canon(env)).hexdigest()}
(SCR/'analysis.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:result[k] for k in ('tree','waiver','circuit','uuid','netlist')},indent=2))
