review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_amplifiers_mountedframe1 (fresh independent agent)
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

# Independent amplifier pin review

Coverage is limited to U_AFE1 through U_AFE8 (OPA2320AIDR). All eight refs PASS; no whole-board acceptance or order authorization is given. The three binding hashes above are immutable commission metadata, not independently reviewed board/parts/rules conclusions.

Envelope subject: `{"raw_sha256": "fb2946f834b451f07cad1ceed6ee590be0a92f9c37eb793e4afb7148291458fa", "semantic_sha256": "2bd2c04a450be50b9c14664e33a27821dd6d65a52fa909410cc7daabdb604957"}`.

## Primary source and independently derived expectations

Exact primary PDF: `projects/crow-audio-carrier-v1/02_parts/OPA2320AIDR/OPA2320_SBOS513F.pdf`; SHA-256 `1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc`; 2852198 bytes. Pages refer to one-based PDF pages.

Visually inspected p4, section 5, “OPA2320 D and DGK Packages / 8-Pin SOIC and VSSOP / Top View” and its pin-functions table before dossier comparison. The upper-left dot marks pin 1; left pins 1–4 descend and right pins 5–8 ascend, giving CCW top-view numbering, four pins per side. Pin functions are 1 OUTA, 2 −INA, 3 +INA, 4 V−, 5 +INB, 6 −INB, 7 OUTB, 8 V+. No NC or exposed pad applies to this D/SOIC package. The adjacent SON thermal-pad requirement does not apply.

Visually inspected p47 D0008A package outline and p48 example board layout (drawing 4214825/C, 02/2019). They agree on upper-left pin 1 and the 8-lead perimeter, with 1.27 mm pitch. The p32 package-option addendum explicitly identifies OPA2320AIDR as SOIC (D), 8 pins. P6 section 6.3 gives a 1.8–5.5 V recommended supply span, consistent with the nominal 3.3 V rail designation.

All dossiers explicitly say front (F.Cu), COMPONENT-TOP, +x right/+y down. They need no mounted-side reflection; manufacturer top view compares at zero relative rotation. U_AFE1–4 use native rotation 0° and U_AFE5–8 use 180°. Reconstructed native positions match every supplied coordinate exactly at displayed precision. Signed component-top perimeter area is −18.8595 mm² (CCW in a y-down frame).

The dossiers use 1.95 × 0.60 mm lands at x = ±2.475 mm and y = ±1.905, ±0.635 mm. These are eight separate lands with 1.27 mm lead pitch. TI p48 gives an example (1.55 × 0.60 mm lands at x = ±2.7 mm), not a mandatory identical land pattern; the dossier pad-size difference does not alter pin identity, winding or side. This review does not qualify solder-joint manufacturing performance.

## Per-ref verdicts and expected versus observed facts

### U_AFE1

VERDICT: PASS

Measured native dossier census: 8 pad records, 8 unique pad numbers, 8 unique native centers, 8 physical pin identities; expected 8. EP count 0; collapsed identities 0; no alias mapping is needed. Source: SHA-256 `1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc`, PDF p4 top-view pinout/functions, p47 D0008A outline, p48 layout; p32 exact orderable package and p6 supply span.

U_AFE1 pins 1–8 (package geometry): expected pin 1 upper-left, CCW, four pins on each side, no EP; observed pin 1 (−2.475, −1.905), CCW, pins 1–4 W and 5–8 E, no extra center pad. Front mount and 0° native rotation reconcile all coordinates without reflection.

U_AFE1 pin 1 (OUTA): expected output A; observed function `OUTA` on `OPA_P1` — PASS.
U_AFE1 pin 2 (-INA): expected inverting feedback A; observed function `-INA` on `FB_P1` — PASS.
U_AFE1 pin 3 (+INA): expected noninverting input A; observed function `+INA` on `AIN_P1` — PASS.
U_AFE1 pin 4 (V-): expected negative supply / ground; observed function `V-` on `GND` — PASS.
U_AFE1 pin 5 (+INB): expected noninverting input B; observed function `+INB` on `AIN_N1` — PASS.
U_AFE1 pin 6 (-INB): expected inverting feedback B; observed function `-INB` on `FB_N1` — PASS.
U_AFE1 pin 7 (OUTB): expected output B; observed function `OUTB` on `OPA_N1` — PASS.
U_AFE1 pin 8 (V+): expected positive supply; observed function `V+` on `3V3_ADC` — PASS.

### U_AFE2

VERDICT: PASS

Measured native dossier census: 8 pad records, 8 unique pad numbers, 8 unique native centers, 8 physical pin identities; expected 8. EP count 0; collapsed identities 0; no alias mapping is needed. Source: SHA-256 `1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc`, PDF p4 top-view pinout/functions, p47 D0008A outline, p48 layout; p32 exact orderable package and p6 supply span.

U_AFE2 pins 1–8 (package geometry): expected pin 1 upper-left, CCW, four pins on each side, no EP; observed pin 1 (−2.475, −1.905), CCW, pins 1–4 W and 5–8 E, no extra center pad. Front mount and 0° native rotation reconcile all coordinates without reflection.

U_AFE2 pin 1 (OUTA): expected output A; observed function `OUTA` on `OPA_P2` — PASS.
U_AFE2 pin 2 (-INA): expected inverting feedback A; observed function `-INA` on `FB_P2` — PASS.
U_AFE2 pin 3 (+INA): expected noninverting input A; observed function `+INA` on `AIN_P2` — PASS.
U_AFE2 pin 4 (V-): expected negative supply / ground; observed function `V-` on `GND` — PASS.
U_AFE2 pin 5 (+INB): expected noninverting input B; observed function `+INB` on `AIN_N2` — PASS.
U_AFE2 pin 6 (-INB): expected inverting feedback B; observed function `-INB` on `FB_N2` — PASS.
U_AFE2 pin 7 (OUTB): expected output B; observed function `OUTB` on `OPA_N2` — PASS.
U_AFE2 pin 8 (V+): expected positive supply; observed function `V+` on `3V3_ADC` — PASS.

### U_AFE3

VERDICT: PASS

Measured native dossier census: 8 pad records, 8 unique pad numbers, 8 unique native centers, 8 physical pin identities; expected 8. EP count 0; collapsed identities 0; no alias mapping is needed. Source: SHA-256 `1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc`, PDF p4 top-view pinout/functions, p47 D0008A outline, p48 layout; p32 exact orderable package and p6 supply span.

U_AFE3 pins 1–8 (package geometry): expected pin 1 upper-left, CCW, four pins on each side, no EP; observed pin 1 (−2.475, −1.905), CCW, pins 1–4 W and 5–8 E, no extra center pad. Front mount and 0° native rotation reconcile all coordinates without reflection.

U_AFE3 pin 1 (OUTA): expected output A; observed function `OUTA` on `OPA_P3` — PASS.
U_AFE3 pin 2 (-INA): expected inverting feedback A; observed function `-INA` on `FB_P3` — PASS.
U_AFE3 pin 3 (+INA): expected noninverting input A; observed function `+INA` on `AIN_P3` — PASS.
U_AFE3 pin 4 (V-): expected negative supply / ground; observed function `V-` on `GND` — PASS.
U_AFE3 pin 5 (+INB): expected noninverting input B; observed function `+INB` on `AIN_N3` — PASS.
U_AFE3 pin 6 (-INB): expected inverting feedback B; observed function `-INB` on `FB_N3` — PASS.
U_AFE3 pin 7 (OUTB): expected output B; observed function `OUTB` on `OPA_N3` — PASS.
U_AFE3 pin 8 (V+): expected positive supply; observed function `V+` on `3V3_ADC` — PASS.

### U_AFE4

VERDICT: PASS

Measured native dossier census: 8 pad records, 8 unique pad numbers, 8 unique native centers, 8 physical pin identities; expected 8. EP count 0; collapsed identities 0; no alias mapping is needed. Source: SHA-256 `1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc`, PDF p4 top-view pinout/functions, p47 D0008A outline, p48 layout; p32 exact orderable package and p6 supply span.

U_AFE4 pins 1–8 (package geometry): expected pin 1 upper-left, CCW, four pins on each side, no EP; observed pin 1 (−2.475, −1.905), CCW, pins 1–4 W and 5–8 E, no extra center pad. Front mount and 0° native rotation reconcile all coordinates without reflection.

U_AFE4 pin 1 (OUTA): expected output A; observed function `OUTA` on `OPA_P4` — PASS.
U_AFE4 pin 2 (-INA): expected inverting feedback A; observed function `-INA` on `FB_P4` — PASS.
U_AFE4 pin 3 (+INA): expected noninverting input A; observed function `+INA` on `AIN_P4` — PASS.
U_AFE4 pin 4 (V-): expected negative supply / ground; observed function `V-` on `GND` — PASS.
U_AFE4 pin 5 (+INB): expected noninverting input B; observed function `+INB` on `AIN_N4` — PASS.
U_AFE4 pin 6 (-INB): expected inverting feedback B; observed function `-INB` on `FB_N4` — PASS.
U_AFE4 pin 7 (OUTB): expected output B; observed function `OUTB` on `OPA_N4` — PASS.
U_AFE4 pin 8 (V+): expected positive supply; observed function `V+` on `3V3_ADC` — PASS.

### U_AFE5

VERDICT: PASS

Measured native dossier census: 8 pad records, 8 unique pad numbers, 8 unique native centers, 8 physical pin identities; expected 8. EP count 0; collapsed identities 0; no alias mapping is needed. Source: SHA-256 `1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc`, PDF p4 top-view pinout/functions, p47 D0008A outline, p48 layout; p32 exact orderable package and p6 supply span.

U_AFE5 pins 1–8 (package geometry): expected pin 1 upper-left, CCW, four pins on each side, no EP; observed pin 1 (−2.475, −1.905), CCW, pins 1–4 W and 5–8 E, no extra center pad. Front mount and 180° native rotation reconcile all coordinates without reflection.

U_AFE5 pin 1 (OUTA): expected output A; observed function `OUTA` on `OPA_P5` — PASS.
U_AFE5 pin 2 (-INA): expected inverting feedback A; observed function `-INA` on `FB_P5` — PASS.
U_AFE5 pin 3 (+INA): expected noninverting input A; observed function `+INA` on `AIN_P5` — PASS.
U_AFE5 pin 4 (V-): expected negative supply / ground; observed function `V-` on `GND` — PASS.
U_AFE5 pin 5 (+INB): expected noninverting input B; observed function `+INB` on `AIN_N5` — PASS.
U_AFE5 pin 6 (-INB): expected inverting feedback B; observed function `-INB` on `FB_N5` — PASS.
U_AFE5 pin 7 (OUTB): expected output B; observed function `OUTB` on `OPA_N5` — PASS.
U_AFE5 pin 8 (V+): expected positive supply; observed function `V+` on `3V3_ADC` — PASS.

### U_AFE6

VERDICT: PASS

Measured native dossier census: 8 pad records, 8 unique pad numbers, 8 unique native centers, 8 physical pin identities; expected 8. EP count 0; collapsed identities 0; no alias mapping is needed. Source: SHA-256 `1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc`, PDF p4 top-view pinout/functions, p47 D0008A outline, p48 layout; p32 exact orderable package and p6 supply span.

U_AFE6 pins 1–8 (package geometry): expected pin 1 upper-left, CCW, four pins on each side, no EP; observed pin 1 (−2.475, −1.905), CCW, pins 1–4 W and 5–8 E, no extra center pad. Front mount and 180° native rotation reconcile all coordinates without reflection.

U_AFE6 pin 1 (OUTA): expected output A; observed function `OUTA` on `OPA_P6` — PASS.
U_AFE6 pin 2 (-INA): expected inverting feedback A; observed function `-INA` on `FB_P6` — PASS.
U_AFE6 pin 3 (+INA): expected noninverting input A; observed function `+INA` on `AIN_P6` — PASS.
U_AFE6 pin 4 (V-): expected negative supply / ground; observed function `V-` on `GND` — PASS.
U_AFE6 pin 5 (+INB): expected noninverting input B; observed function `+INB` on `AIN_N6` — PASS.
U_AFE6 pin 6 (-INB): expected inverting feedback B; observed function `-INB` on `FB_N6` — PASS.
U_AFE6 pin 7 (OUTB): expected output B; observed function `OUTB` on `OPA_N6` — PASS.
U_AFE6 pin 8 (V+): expected positive supply; observed function `V+` on `3V3_ADC` — PASS.

### U_AFE7

VERDICT: PASS

Measured native dossier census: 8 pad records, 8 unique pad numbers, 8 unique native centers, 8 physical pin identities; expected 8. EP count 0; collapsed identities 0; no alias mapping is needed. Source: SHA-256 `1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc`, PDF p4 top-view pinout/functions, p47 D0008A outline, p48 layout; p32 exact orderable package and p6 supply span.

U_AFE7 pins 1–8 (package geometry): expected pin 1 upper-left, CCW, four pins on each side, no EP; observed pin 1 (−2.475, −1.905), CCW, pins 1–4 W and 5–8 E, no extra center pad. Front mount and 180° native rotation reconcile all coordinates without reflection.

U_AFE7 pin 1 (OUTA): expected output A; observed function `OUTA` on `OPA_P7` — PASS.
U_AFE7 pin 2 (-INA): expected inverting feedback A; observed function `-INA` on `FB_P7` — PASS.
U_AFE7 pin 3 (+INA): expected noninverting input A; observed function `+INA` on `AIN_P7` — PASS.
U_AFE7 pin 4 (V-): expected negative supply / ground; observed function `V-` on `GND` — PASS.
U_AFE7 pin 5 (+INB): expected noninverting input B; observed function `+INB` on `AIN_N7` — PASS.
U_AFE7 pin 6 (-INB): expected inverting feedback B; observed function `-INB` on `FB_N7` — PASS.
U_AFE7 pin 7 (OUTB): expected output B; observed function `OUTB` on `OPA_N7` — PASS.
U_AFE7 pin 8 (V+): expected positive supply; observed function `V+` on `3V3_ADC` — PASS.

### U_AFE8

VERDICT: PASS

Measured native dossier census: 8 pad records, 8 unique pad numbers, 8 unique native centers, 8 physical pin identities; expected 8. EP count 0; collapsed identities 0; no alias mapping is needed. Source: SHA-256 `1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc`, PDF p4 top-view pinout/functions, p47 D0008A outline, p48 layout; p32 exact orderable package and p6 supply span.

U_AFE8 pins 1–8 (package geometry): expected pin 1 upper-left, CCW, four pins on each side, no EP; observed pin 1 (−2.475, −1.905), CCW, pins 1–4 W and 5–8 E, no extra center pad. Front mount and 180° native rotation reconcile all coordinates without reflection.

U_AFE8 pin 1 (OUTA): expected output A; observed function `OUTA` on `OPA_P8` — PASS.
U_AFE8 pin 2 (-INA): expected inverting feedback A; observed function `-INA` on `FB_P8` — PASS.
U_AFE8 pin 3 (+INA): expected noninverting input A; observed function `+INA` on `AIN_P8` — PASS.
U_AFE8 pin 4 (V-): expected negative supply / ground; observed function `V-` on `GND` — PASS.
U_AFE8 pin 5 (+INB): expected noninverting input B; observed function `+INB` on `AIN_N8` — PASS.
U_AFE8 pin 6 (-INB): expected inverting feedback B; observed function `-INB` on `FB_N8` — PASS.
U_AFE8 pin 7 (OUTB): expected output B; observed function `OUTB` on `OPA_N8` — PASS.
U_AFE8 pin 8 (V+): expected positive supply; observed function `V+` on `3V3_ADC` — PASS.

## Symmetry and limits

All 8 instances have identical physical function mapping and net classes, differing only by channel index; refs 5..8 rotate 180 degrees without reflection.

Aggregate measured census: 8 refs, 64 native pad records and 64 distinct per-instance physical pin identities, 0 exposed pads, 0 collapsed identities; 8 PASS / 0 FAIL / 0 QUESTION. There are no unresolved pin-review findings. Net classification uses the supplied board net names; it establishes pin-level electrical sanity, not unprovided circuit topology, measured voltages, signal range or whole-board behavior.

## Methods and evidence

1. Verified SHA-256 and byte size of every envelope input before and after review using verify_input_packet.
2. Extracted exact PDF text only to locate relevant pages and supplement figure readings. Rendered PDF pages 4, 47 and 48 with pdftoppm at 110 DPI, inspected each with view_image, and saved independent-expectations.json before opening any dossier. Subsequently rendered and visually inspected pages 6 and 32 at 130 DPI for supply range and exact ordering/package selection.
3. Compared manufacturer top view directly against each COMPONENT-TOP dossier frame. All parts front-mounted; no reflection required or applied. Checked every native coordinate against board position and 0/180 degree rotation.
4. Manually checked all 64 per-pin function/net entries, then used measure.py to census rows, unique pad numbers and native centers, compute signed polygon area, and verify all coordinate transforms. Measurements are from supplied native dossiers, not a separate extraction of a live board.
5. Compared all eight instances for function/net-class symmetry. Evaluated basic pin-level net sanity; rail 3V3_ADC denotes nominal 3.3 V and GND denotes low supply. Dossiers do not establish actual rail voltage, circuit gain, feedback resistor topology, loading, signal amplitude or complete board behavior; these are outside this pin review.
6. Used finite direct-argv subprocess stages with explicit cwd/environment and pipeline_runtime.run_stage for review commands; retained commands/runtime and combined raw stdout/stderr, including failed rg launch and successful Python fallback. Initial task/runtime bootstrap reads used direct exec_command.
7. Packaged actual rendered pages, native dossiers, independent expectations, measurement source/results, review method source and runtime logs. Full primary PDF stays in digest-bound frozen packet.

The evidence archive includes the actual five inspected raster pages, all eight native dossiers, primary PDF digest binding, protocol, measurement script/results, command/runtime records and raw review logs. Packaging and final preflight receipts remain in allocated scratch because the archive cannot contain its own final digest or post-archive validation. Delivery checks signify complete honest handback, not permission to order.
