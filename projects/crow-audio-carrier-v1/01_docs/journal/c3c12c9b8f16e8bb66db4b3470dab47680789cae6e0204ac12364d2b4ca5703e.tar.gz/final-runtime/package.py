from pathlib import Path,PurePosixPath
import hashlib,json,tarfile,shutil
s=Path(__file__).parent;out=s.parent/'outputs'
digest=lambda data:hashlib.sha256(data).hexdigest()
(s/'delivered').mkdir(exist_ok=True)
for name in ('report.md','evidence.json','result.json'):
    shutil.copyfile(out/name,s/'delivered'/name)
excluded={'package.log','package-runtime.json','preflight.log','preflight-runtime.json','archive-reopen.json'}
files=[]
for p in sorted(s.rglob('*')):
    assert not p.is_symlink(),p
    if p.is_dir():continue
    rel=p.relative_to(s).as_posix()
    if rel in excluded:continue
    assert p.is_file() and not rel.endswith(('.tar.gz','.tar','.zip')),rel
    files.append((rel,p))
archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
    for rel,p in files:tf.add(p,arcname=rel,recursive=False)
records=[];seen=set()
with tarfile.open(archive,'r:gz') as tf:
    for member in tf.getmembers():
        name=member.name;parts=PurePosixPath(name).parts
        assert member.isfile() and not member.issym() and not member.islnk(),name
        assert not name.startswith('/') and '..' not in parts and name not in seen,name
        assert not name.endswith(('.tar.gz','.tar','.zip')),name
        seen.add(name);data=tf.extractfile(member).read();assert len(data)==member.size
        source=(s/name).read_bytes();assert data==source
        records.append({'path':name,'size':len(data),'sha256':digest(data)})
assert len(records)==len(files)
manifest={'archive_sha256':digest(archive.read_bytes()),'archive_size':archive.stat().st_size,'member_count':len(records),'members':records}
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(s/'archive-reopen.json').write_text(json.dumps({'status':'PASS','archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'member_count':len(records),'all_regular_members_reopened':True,'symlinks':0,'duplicates':0,'traversal':0,'recursive_archives':0},indent=2))
assert {p.name for p in out.iterdir()}=={'report.md','evidence.json','evidence-manifest.json','evidence.tar.gz','result.json'}
print(json.dumps({k:v for k,v in manifest.items() if k!='members'}))
