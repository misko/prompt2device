"""Reopen all current pre-renewal native DRC rows; no placement acceptance."""
from pathlib import Path
from collections import Counter
import json,hashlib,pcbnew as k
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
key=lambda r:json.dumps(r,sort_keys=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();results=[]
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 P=R/'projects'/slug;bp=P/'04_kicad'/(slug.replace('-','_')+'.kicad_pcb');gp=P/'06_build/drc/gate.json';prior=N/'none-renewal-prior-native'/slug
 assert bp.read_bytes()==(prior/'04_kicad'/bp.name).read_bytes()
 before=json.loads((prior/'06_build/drc/gate.json').read_text());raw=json.loads(gp.read_text());b=k.LoadBoard(str(bp));objects={}
 for fp in b.GetFootprints():
  for pad in fp.Pads():objects[pad.m_Uuid.AsString()]=(pad,'pad',fp.GetReference(),pad.GetNumber())
 for t in b.GetTracks():objects[t.m_Uuid.AsString()]=(t,'via' if t.GetClass()=='PCB_VIA' else 'track',None,None)
 for z in b.Zones():objects[z.m_Uuid.AsString()]=(z,'zone',None,None)
 rows=[];positions=0
 for collection in ['violations','unconnected_items','schematic_parity']:
  assert Counter(map(key,before.get(collection,[])))==Counter(map(key,raw.get(collection,[]))),collection
  for index,row in enumerate(raw.get(collection,[])):
   ends=[]
   for item in row['items']:
    obj,kind,ref,pin=objects[item['uuid']];net=obj.GetNetname();assert '['+net+']' in item['description']
    xy={'x':k.ToMM(obj.GetPosition().x),'y':k.ToMM(obj.GetPosition().y)}
    if kind!='zone':assert all(abs(xy[a]-item['pos'][a])<=0.000002 for a in ['x','y']);positions+=1
    ends.append({'uuid':item['uuid'],'kind':kind,'ref':ref,'pin':pin,'net':net,'native_anchor_mm':xy,'reported_position_mm':item['pos']})
   assert len({x['net'] for x in ends})==1
   if collection=='unconnected_items':cause='Preceding unprepared placement: this exact same-net pad/via/zone pair still requires routing. Zone report point is not treated as its anchor or a unique island. No route or prepared-return acceptance.'
   else:
    assert row['type']=='starved_thermal' and slug=='crow-audio-carrier-v1'
    assert any(e['ref']=='C_VDDA2_10N' and e['pin']=='2' for e in ends)
    cause='Preceding live board retains inherited thermal policy on C_VDDA2_10N.2. Independently accepted new source and isolated native6 resolve it, but this old unchanged live snapshot has not yet undergone canonical placement renewal. Original thermal refusal remains genuine for these bytes.'
   rows.append({'collection':collection,'index':index,'raw':row,'endpoints':ends,'cause':cause})
 d={'project':slug,'board_sha256':sha(bp),'report_sha256':sha(gp),'counts':{x:len(raw.get(x,[])) for x in ['violations','unconnected_items','schematic_parity']},'all_rows':rows,'native_endpoint_records':sum(len(x['endpoints']) for x in rows),'positions_checked':positions,'prior_raw_multiset_exact':True,'scope':'Fresh all-severity/refill/parity report of unchanged preceding native board after current schematic acceptance. Complete raw-row multiset matches preserved predecessor; native endpoint identities reverified. Not acceptance of pending canonical native renewal.'}
 (N/(slug+'-none-handoff-native-classification.json')).write_text(json.dumps(d,indent=2)+'\n');results.append({k:v for k,v in d.items() if k not in ['all_rows','scope']})
print(json.dumps(results,indent=2))
