from pathlib import Path
from collections import Counter
import json,hashlib,sys
import pcbnew
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;slug=sys.argv[1];short='pod' if 'pod' in slug else 'carrier';P=R/'projects'/slug;task='rj45-'+short+'-placement-after-fabfeatures1'
e=json.loads((P/'06_build/task_runs'/task/'outputs/evidence.json').read_text());bp=next((P/'04_kicad').glob('*.kicad_pcb'));before=bp.read_bytes();b=pcbnew.LoadBoard(str(bp));gp=P/'06_build/drc/gate.json';g=json.loads(gp.read_text());assert not g['violations'] and not g['schematic_parity']
commission=json.loads((N/(slug+'-fabfeatures1-human-commission.json')).read_text());assert hashlib.sha256(before).hexdigest()==commission['board_sha256'];receipt=json.loads((P/'06_build/pre_route/orientation/orientation_receipt.json').read_text());assert receipt['subject_sha256']==commission['subject_sha256'] and receipt['evidence']==commission['image_sha256'] and not receipt['failures']
for key in ['evidence','producer_evidence']:
 for rel,h in receipt[key].items():assert hashlib.sha256((P/'06_build/pre_route/orientation'/rel).read_bytes()).hexdigest()==h
pads={p.m_Uuid.AsString():p for f in b.GetFootprints() for p in f.Pads()};zones={z.m_Uuid.AsString():z for z in b.Zones()};tracks={x.m_Uuid.AsString():x for x in b.GetTracks()};objects={**pads,**zones,**tracks};rows=[]
for idx,row in enumerate(g['unconnected_items'],1):
 ends=[]
 for end in row['items']:
  uid=end['uuid'];o=objects[uid];net=o.GetNetname();assert '['+net+']' in end['description'];pos={'x':o.GetPosition().x/1e6,'y':o.GetPosition().y/1e6}
  if uid not in zones:assert all(abs(pos[k]-end['pos'][k])<=.000002 for k in pos)
  fp=o.GetParentFootprint() if uid in pads else None
  ends.append({'uuid':uid,'net':net,'kind':'pad' if uid in pads else 'zone' if uid in zones else o.GetClass(),'ref':fp.GetReference() if fp else None,'pin':o.GetNumber() if fp else None,'native_position_mm':pos,'reported_position_mm':end['pos']})
 assert len({x['net'] for x in ends})==1
 rows.append({'index':idx,'raw':row,'endpoints':ends,'cause':'Unrouted connection on canonical placement; exact endpoints verified. Deterministic seed/routing copper in separate r0 is not present in this board.','disposition':'OPEN, routing and route-acceptance gates owed.'})
assert len(rows)==(58 if short=='pod' else 499);assert all(x.GetClass()=='PCB_VIA' for x in tracks.values());assert bp.read_bytes()==before
res={'project':slug,'board_sha256':hashlib.sha256(before).hexdigest(),'gate_sha256':hashlib.sha256(gp.read_bytes()).hexdigest(),'counts':{'violations':0,'unconnected':len(rows),'parity':0,'native_endpoints':sum(len(x['endpoints']) for x in rows),'native_pad_via_positions':sum(x['kind']!='zone' for r in rows for x in r['endpoints']),'footprints':len(list(b.GetFootprints())),'tracks':0,'vias':len(tracks)},'method':'Root reopens actual final native DRC and native board, verifies every UUID/net/ref/pin and pad/via coordinate; zone anchor and report position retained separately. Checks all current image/producer hashes and exact pending commission. No additional DRC or image generation.','rows':rows,'human_orientation':'INCOMPLETE; explicit confirmation requested, not received','limits':'Zero violations is not routed acceptance; all unconnected rows remain OPEN.'}
(N/(slug+'-fabfeatures1-final-native-verified.json')).write_text(json.dumps(res,indent=2)+'\n');print(slug,json.dumps(res['counts']))
