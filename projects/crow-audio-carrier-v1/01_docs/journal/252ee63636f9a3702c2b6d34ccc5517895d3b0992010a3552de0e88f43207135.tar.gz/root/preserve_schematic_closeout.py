from pathlib import Path
import hashlib,json,tarfile,io,shutil,sys
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911');sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet
sha=lambda b:hashlib.sha256(b).hexdigest();files={}
j=json.loads((D/'cat-physical-availability-opened.json').read_text())[0];root=Path(j['project']);A=Path(j['attempt']).parent;e=TaskEnvelope.from_json(Path(j['envelope']).read_text());a=json.loads((A/'attempt.json').read_text());assert a['status']=='PASS' and verify_input_packet(e,root)[0]
for n,row in a['output']['completion']['outputs'].items():b=(A/'outputs'/n).read_bytes();assert len(b)==row['size'] and sha(b)==row['sha256']
for f in root.rglob('*'):
 if f.is_file() and f.name!='.closing':files['availability/'+f.relative_to(root).as_posix()]=f
for prefix in ['cat-schematic-owning-review','cat-schematic-handoff','cat-canonical-source-checkpoint']:
 for f in I.glob(prefix+'*'):
  if f.is_file():files['root/'+f.name]=f
for n in ['canonical-preservation-result.json','canonical-input-references.json','oversized-canonical-preservation-result.json','cat-delta-adoption-result.json','cat-delta-adoption-proof.json','cat-root-visual.json','record_schematic_gate.py','preserve_schematic_closeout.py']:
 files['root/'+n]=D/n
files['current/agent_handoff.yaml']=P/'06_build/agent_handoff.yaml'
manifest={n:{'size':f.stat().st_size,'sha256':sha(f.read_bytes())} for n,f in sorted(files.items())};tmp=D/'schematic-closeout.tar.gz'
with tarfile.open(tmp,'w:gz',compresslevel=3) as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 b=(json.dumps({'members':manifest},indent=2)+'\n').encode();m=tarfile.TarInfo('MANIFEST.json');m.size=len(b);t.addfile(m,io.BytesIO(b))
h=sha(tmp.read_bytes());out=P/'01_docs/journal'/(h+'.tar.gz');assert not out.exists();shutil.copyfile(tmp,out)
with tarfile.open(out) as t:
 assert set(t.getnames())==set(manifest)|{'MANIFEST.json'}
 for n,m in manifest.items():b=t.extractfile(n).read();assert len(b)==m['size'] and sha(b)==m['sha256'],n
result={'archive':str(out),'sha256':h,'size':out.stat().st_size,'payload_members':len(manifest),'availability_inputs':len(e.input_packet),'availability_outputs':len(a['output']['completion']['outputs'])};(D/'schematic-closeout-result.json').write_text(json.dumps(result,indent=2)+'\n')
with (P/'01_docs/journal/contracts.md').open('a') as f:f.write(f'\n## Allowed Cat schematic acceptance closeout\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Exact owning schematic gate and compact handoff, fresh physical reviewer availability, root input/artifact reopening and deduplicated evidence provenance; reopen every MANIFEST member |\n')
with (P/'01_docs/journal/schematic.md').open('a') as f:f.write(f'\n- Closeout evidence `{h}.tar.gz`: {out.stat().st_size}bytes, {len(manifest)}members, all reopened. Includes actual schematic gate2/2PASS and handoff plus fresh physical-reviewer availability3inputs/1check/2outputs, delivered and closedPASS. Independent schematic reviewer reported an initial preflight rejection for its own authority __pycache__; it removed that generated cache within its attempt. Root current-scope/delivery closure PASS is measured; the original preflight stdout was not included in the delivered71-member archive and is not claimed as retained raw evidence here.\n')
print(json.dumps(result,indent=2))
