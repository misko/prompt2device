review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_amplifiers_clockground1 (fresh independent agent)
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: e85b1461a82f3d3853c19fae694693816e31570d23d37019ef187d6428bea4ae
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: e6d5b0b89efd79051b082f70b283ec7e85e1170ed11ddb94581744d26904c9c7

Limited coverage: U_AFE1 through U_AFE8 only. This is pre-route pin review, not whole-board acceptance or authorization to order. The three preceding hashes are immutable subject metadata, not independently reviewed board/parts/rules conclusions.

Primary source: TI OPA2320 SBOS513F, exact PDF SHA-256 1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc. PDF page 4, section 5, unnumbered OPA2320 D/DGK top-view figure and OPA2320 pin-function table; PDF page 47 package outline D0008A; PDF page 48 example board layout D0008A. Page 6 section 6.3 establishes 1.8–5.5 V operating supply.

Method: Verified every envelope input by SHA-256 and size before processing and after review. Rendered manufacturer figures with pdftoppm and inspected images with view_image BEFORE reading native dossiers. Recorded manufacturer-first.txt. Manufacturer D SOIC-8 has pin 1 upper left; left pins 1,2,3,4 run downward and right pins 5,6,7,8 upward, CCW. Eight distinct physical leads, four per side, no EP and no fused identities. The SON underside thermal-pad requirement is inapplicable to the selected D package. The manufacturer's functional figure explicitly says TOP VIEW; no bottom-view conversion or mirroring was applied.

All native dossiers explicitly use component-top +x right/+y down and front mounting. Their common local geometry is pin 1 (-2.475,-1.905), 2 (-2.475,-0.635), 3 (-2.475,+0.635), 4 (-2.475,+1.905), 5 (+2.475,+1.905), 6 (+2.475,+0.635), 7 (+2.475,-0.635), 8 (+2.475,-1.905) mm. Pin 1 corner, CCW winding and four leads per side match the manufacturer by rotation alone. Native positions were checked numerically against placement and rotation for all 64 pads. Pins 1–4 are local W and 5–8 local E. U_AFE1–4 have 0 degree rotation; U_AFE5–8 have 180 degree rotation, without reflection.

Native lands have 1.27 mm pitch and 1.95 x 0.60 mm size, with 4.95 mm between column centers. TI's example uses 1.55 x 0.60 mm lands and 5.4 mm column centers; this is an example, not a required identity geometry. The native lands extend from 1.50 to 3.45 mm on each side of center and cover the outline's terminal extent (2.90–3.095 mm from center). This difference creates no pin-identity or package mismatch. No solder-process qualification is claimed.

Per-instance results follow. For every instance, expected manufacturer pin-function identity is independently compared with the part function and observed native net. Signal labels establish function/net-kind sanity only; feedback gain, signal amplitudes, decoupling, routing and system performance are beyond this commissioned pin review.

U_AFE1 VERDICT: PASS
Measured: 8 native pads, 8 distinct physical identities, 0 EP, 0 aliases. Primary PDF SHA-256 1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc; p4 OPA2320 D/DGK top-view figure, p47 D0008A outline, p48 D0008A land-pattern example. Expected CCW/pin 1 upper left in component-top; observed CCW/pin 1 upper left, front-mounted, rotation 0 degrees.
U_AFE1 pin 1 (OUT A): expected amplifier output; observed function OUTA on OPA_P1 — PASS.
U_AFE1 pin 2 (inverting input A): expected feedback input; observed function -INA on FB_P1 — PASS.
U_AFE1 pin 3 (noninverting input A): expected analog input; observed function +INA on AIN_P1 — PASS.
U_AFE1 pin 4 (V− (lowest supply)): expected ground for single-supply operation; observed function V- on GND — PASS.
U_AFE1 pin 5 (noninverting input B): expected analog input; observed function +INB on AIN_N1 — PASS.
U_AFE1 pin 6 (inverting input B): expected feedback input; observed function -INB on FB_N1 — PASS.
U_AFE1 pin 7 (OUT B): expected amplifier output; observed function OUTB on OPA_N1 — PASS.
U_AFE1 pin 8 (V+ (highest supply)): expected positive supply rail; observed function V+ on 3V3_ADC — PASS.

U_AFE2 VERDICT: PASS
Measured: 8 native pads, 8 distinct physical identities, 0 EP, 0 aliases. Primary PDF SHA-256 1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc; p4 OPA2320 D/DGK top-view figure, p47 D0008A outline, p48 D0008A land-pattern example. Expected CCW/pin 1 upper left in component-top; observed CCW/pin 1 upper left, front-mounted, rotation 0 degrees.
U_AFE2 pin 1 (OUT A): expected amplifier output; observed function OUTA on OPA_P2 — PASS.
U_AFE2 pin 2 (inverting input A): expected feedback input; observed function -INA on FB_P2 — PASS.
U_AFE2 pin 3 (noninverting input A): expected analog input; observed function +INA on AIN_P2 — PASS.
U_AFE2 pin 4 (V− (lowest supply)): expected ground for single-supply operation; observed function V- on GND — PASS.
U_AFE2 pin 5 (noninverting input B): expected analog input; observed function +INB on AIN_N2 — PASS.
U_AFE2 pin 6 (inverting input B): expected feedback input; observed function -INB on FB_N2 — PASS.
U_AFE2 pin 7 (OUT B): expected amplifier output; observed function OUTB on OPA_N2 — PASS.
U_AFE2 pin 8 (V+ (highest supply)): expected positive supply rail; observed function V+ on 3V3_ADC — PASS.

U_AFE3 VERDICT: PASS
Measured: 8 native pads, 8 distinct physical identities, 0 EP, 0 aliases. Primary PDF SHA-256 1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc; p4 OPA2320 D/DGK top-view figure, p47 D0008A outline, p48 D0008A land-pattern example. Expected CCW/pin 1 upper left in component-top; observed CCW/pin 1 upper left, front-mounted, rotation 0 degrees.
U_AFE3 pin 1 (OUT A): expected amplifier output; observed function OUTA on OPA_P3 — PASS.
U_AFE3 pin 2 (inverting input A): expected feedback input; observed function -INA on FB_P3 — PASS.
U_AFE3 pin 3 (noninverting input A): expected analog input; observed function +INA on AIN_P3 — PASS.
U_AFE3 pin 4 (V− (lowest supply)): expected ground for single-supply operation; observed function V- on GND — PASS.
U_AFE3 pin 5 (noninverting input B): expected analog input; observed function +INB on AIN_N3 — PASS.
U_AFE3 pin 6 (inverting input B): expected feedback input; observed function -INB on FB_N3 — PASS.
U_AFE3 pin 7 (OUT B): expected amplifier output; observed function OUTB on OPA_N3 — PASS.
U_AFE3 pin 8 (V+ (highest supply)): expected positive supply rail; observed function V+ on 3V3_ADC — PASS.

U_AFE4 VERDICT: PASS
Measured: 8 native pads, 8 distinct physical identities, 0 EP, 0 aliases. Primary PDF SHA-256 1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc; p4 OPA2320 D/DGK top-view figure, p47 D0008A outline, p48 D0008A land-pattern example. Expected CCW/pin 1 upper left in component-top; observed CCW/pin 1 upper left, front-mounted, rotation 0 degrees.
U_AFE4 pin 1 (OUT A): expected amplifier output; observed function OUTA on OPA_P4 — PASS.
U_AFE4 pin 2 (inverting input A): expected feedback input; observed function -INA on FB_P4 — PASS.
U_AFE4 pin 3 (noninverting input A): expected analog input; observed function +INA on AIN_P4 — PASS.
U_AFE4 pin 4 (V− (lowest supply)): expected ground for single-supply operation; observed function V- on GND — PASS.
U_AFE4 pin 5 (noninverting input B): expected analog input; observed function +INB on AIN_N4 — PASS.
U_AFE4 pin 6 (inverting input B): expected feedback input; observed function -INB on FB_N4 — PASS.
U_AFE4 pin 7 (OUT B): expected amplifier output; observed function OUTB on OPA_N4 — PASS.
U_AFE4 pin 8 (V+ (highest supply)): expected positive supply rail; observed function V+ on 3V3_ADC — PASS.

U_AFE5 VERDICT: PASS
Measured: 8 native pads, 8 distinct physical identities, 0 EP, 0 aliases. Primary PDF SHA-256 1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc; p4 OPA2320 D/DGK top-view figure, p47 D0008A outline, p48 D0008A land-pattern example. Expected CCW/pin 1 upper left in component-top; observed CCW/pin 1 upper left, front-mounted, rotation 180 degrees.
U_AFE5 pin 1 (OUT A): expected amplifier output; observed function OUTA on OPA_P5 — PASS.
U_AFE5 pin 2 (inverting input A): expected feedback input; observed function -INA on FB_P5 — PASS.
U_AFE5 pin 3 (noninverting input A): expected analog input; observed function +INA on AIN_P5 — PASS.
U_AFE5 pin 4 (V− (lowest supply)): expected ground for single-supply operation; observed function V- on GND — PASS.
U_AFE5 pin 5 (noninverting input B): expected analog input; observed function +INB on AIN_N5 — PASS.
U_AFE5 pin 6 (inverting input B): expected feedback input; observed function -INB on FB_N5 — PASS.
U_AFE5 pin 7 (OUT B): expected amplifier output; observed function OUTB on OPA_N5 — PASS.
U_AFE5 pin 8 (V+ (highest supply)): expected positive supply rail; observed function V+ on 3V3_ADC — PASS.

U_AFE6 VERDICT: PASS
Measured: 8 native pads, 8 distinct physical identities, 0 EP, 0 aliases. Primary PDF SHA-256 1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc; p4 OPA2320 D/DGK top-view figure, p47 D0008A outline, p48 D0008A land-pattern example. Expected CCW/pin 1 upper left in component-top; observed CCW/pin 1 upper left, front-mounted, rotation 180 degrees.
U_AFE6 pin 1 (OUT A): expected amplifier output; observed function OUTA on OPA_P6 — PASS.
U_AFE6 pin 2 (inverting input A): expected feedback input; observed function -INA on FB_P6 — PASS.
U_AFE6 pin 3 (noninverting input A): expected analog input; observed function +INA on AIN_P6 — PASS.
U_AFE6 pin 4 (V− (lowest supply)): expected ground for single-supply operation; observed function V- on GND — PASS.
U_AFE6 pin 5 (noninverting input B): expected analog input; observed function +INB on AIN_N6 — PASS.
U_AFE6 pin 6 (inverting input B): expected feedback input; observed function -INB on FB_N6 — PASS.
U_AFE6 pin 7 (OUT B): expected amplifier output; observed function OUTB on OPA_N6 — PASS.
U_AFE6 pin 8 (V+ (highest supply)): expected positive supply rail; observed function V+ on 3V3_ADC — PASS.

U_AFE7 VERDICT: PASS
Measured: 8 native pads, 8 distinct physical identities, 0 EP, 0 aliases. Primary PDF SHA-256 1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc; p4 OPA2320 D/DGK top-view figure, p47 D0008A outline, p48 D0008A land-pattern example. Expected CCW/pin 1 upper left in component-top; observed CCW/pin 1 upper left, front-mounted, rotation 180 degrees.
U_AFE7 pin 1 (OUT A): expected amplifier output; observed function OUTA on OPA_P7 — PASS.
U_AFE7 pin 2 (inverting input A): expected feedback input; observed function -INA on FB_P7 — PASS.
U_AFE7 pin 3 (noninverting input A): expected analog input; observed function +INA on AIN_P7 — PASS.
U_AFE7 pin 4 (V− (lowest supply)): expected ground for single-supply operation; observed function V- on GND — PASS.
U_AFE7 pin 5 (noninverting input B): expected analog input; observed function +INB on AIN_N7 — PASS.
U_AFE7 pin 6 (inverting input B): expected feedback input; observed function -INB on FB_N7 — PASS.
U_AFE7 pin 7 (OUT B): expected amplifier output; observed function OUTB on OPA_N7 — PASS.
U_AFE7 pin 8 (V+ (highest supply)): expected positive supply rail; observed function V+ on 3V3_ADC — PASS.

U_AFE8 VERDICT: PASS
Measured: 8 native pads, 8 distinct physical identities, 0 EP, 0 aliases. Primary PDF SHA-256 1d13d91bc220d3f37e814e29599ce23e086bd661227618104dcae5482c8144fc; p4 OPA2320 D/DGK top-view figure, p47 D0008A outline, p48 D0008A land-pattern example. Expected CCW/pin 1 upper left in component-top; observed CCW/pin 1 upper left, front-mounted, rotation 180 degrees.
U_AFE8 pin 1 (OUT A): expected amplifier output; observed function OUTA on OPA_P8 — PASS.
U_AFE8 pin 2 (inverting input A): expected feedback input; observed function -INA on FB_P8 — PASS.
U_AFE8 pin 3 (noninverting input A): expected analog input; observed function +INA on AIN_P8 — PASS.
U_AFE8 pin 4 (V− (lowest supply)): expected ground for single-supply operation; observed function V- on GND — PASS.
U_AFE8 pin 5 (noninverting input B): expected analog input; observed function +INB on AIN_N8 — PASS.
U_AFE8 pin 6 (inverting input B): expected feedback input; observed function -INB on FB_N8 — PASS.
U_AFE8 pin 7 (OUT B): expected amplifier output; observed function OUTB on OPA_N8 — PASS.
U_AFE8 pin 8 (V+ (highest supply)): expected positive supply rail; observed function V+ on 3V3_ADC — PASS.

Pairwise symmetry: all eight channels have identical pin/function/net-kind structure, with only channel indices changing on OPA_Pn, FB_Pn, AIN_Pn, AIN_Nn, FB_Nn and OPA_Nn. Pin 4 is GND and pin 8 is 3V3_ADC throughout; nominal 3.3 V is within the specified supply range. Measured total: 64 native pads and 64 distinct physical identities. No failed pins or unresolved questions in this group.
