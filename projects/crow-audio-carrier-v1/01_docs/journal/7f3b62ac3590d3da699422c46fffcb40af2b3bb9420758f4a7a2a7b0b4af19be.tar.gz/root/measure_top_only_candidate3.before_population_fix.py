from pathlib import Path
import json,hashlib,pcbnew
N=Path('/tmp/carrier-rj45-20260912');D=N/'top-only-candidate3-population';D.mkdir(exist_ok=False)
S=Path('/tmp/rj45-top-only-correction1-54q2bgy8/06_build/task_runs/rj45-top-only-correction1/scratch/work/projects')
results={}
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 src=next((S/slug/'04_kicad').glob('*.kicad_pcb'));raw=src.read_bytes();q=D/(slug+'.kicad_pcb');q.write_bytes(raw);assert src.read_bytes()==raw
 b=pcbnew.LoadBoard(str(q));groups={'top':[],'bottom':[],'other':[]};allrefs=[]
 for f in b.GetFootprints():
  allrefs.append(f.GetReference())
  if not any(p.GetNumber() and p.GetAttribute()==pcbnew.PAD_ATTRIB_SMD for p in f.Pads()):continue
  side='top' if f.GetLayer()==pcbnew.F_Cu else 'bottom' if f.GetLayer()==pcbnew.B_Cu else 'other';groups[side].append(f.GetReference())
 for k in groups:groups[k].sort()
 box=b.GetBoardEdgesBoundingBox();dims=[box.GetWidth()/1e6,box.GetHeight()/1e6]
 results[slug]={'source':str(src),'saved_copy':str(q),'sha256':hashlib.sha256(raw).hexdigest(),'native_footprint_count':len(allrefs),'numbered_smd_land_footprints':{k:len(v) for k,v in groups.items()},'smd_refs':groups,'outline_graphic_bbox_mm':dims,'scope':'Root independent pcbnew numbered-SMD-land census on exact generated current candidate copy. Not full assembly/population/clearance/route or source acceptance. Outlines may include stroke width.'}
 assert not groups['bottom'] and not groups['other']
 assert len(groups['top'])==(306 if slug=='crow-audio-carrier-v1' else 31)
(D/'result.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({s:{k:v[k] for k in ['sha256','native_footprint_count','numbered_smd_land_footprints','outline_graphic_bbox_mm']} for s,v in results.items()},indent=2))
