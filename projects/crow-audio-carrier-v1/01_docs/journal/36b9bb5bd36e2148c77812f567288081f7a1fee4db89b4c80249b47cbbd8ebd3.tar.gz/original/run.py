from pathlib import Path
import sys,os,json
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');D=Path(__file__).parent;sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/pcb-design/scripts'));from pipeline_runtime import run_stage
r=run_stage({'id':'source-native-endpoint-comparison','work_class':'local','timeout_s':120},['/usr/bin/python3',str(D/'compare.py')],log_path=D/'comparison.log',cwd=R,env={'PATH':os.environ['PATH'],'HOME':os.environ['HOME'],'LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'},console_line_limit=5,console_tail_lines=3);(D/'runtime.json').write_text(json.dumps(r.to_mapping(),indent=2)+'\n');raise SystemExit(0 if r.status=='PASS' else 1)
