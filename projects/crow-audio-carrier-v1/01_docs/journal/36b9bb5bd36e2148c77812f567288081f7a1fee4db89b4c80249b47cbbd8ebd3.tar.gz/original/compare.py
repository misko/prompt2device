"""Independent source-trace graph versus KiCad endpoint partition comparison.

Do not import the converter or its connectivity-map resolver. This diagnostic
checks concrete endpoint membership; it is not an independent visual verdict.
"""
from pathlib import Path
import collections,hashlib,json,re,tarfile,datetime,sys
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent
review=Path('/tmp/carrier-schematic-current-review-20260911');O=review/'06_build/task_runs/schematic-current-readability/outputs'
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((O/'evidence-manifest.json').read_text());b=(O/'evidence.tar.gz').read_bytes();assert {'sha256':sha(b),'size':len(b)}==manifest['archive']
with tarfile.open(O/'evidence.tar.gz','r:gz') as tf:
 b=tf.extractfile('native-export.net').read();assert {'sha256':sha(b),'size':len(b)}==manifest['members']['native-export.net'];(D/'reviewer-native-export.net').write_bytes(b)
for rel in ['03_tscircuit/build/circuit.json','04_kicad/crow_audio_carrier_v1.kicad_sch','06_build/netlists/crow_audio_carrier_v1.net']:
 assert (P/rel).read_bytes()==(review/'project'/rel).read_bytes(),rel
aliases={}
for line in (P/'03_tscircuit/net_aliases.txt').read_text().splitlines():
 line=line.split('#',1)[0].strip()
 if not line:continue
 parts=line.split();assert len(parts)==2 and parts[0] not in aliases;aliases[parts[0]]=parts[1]
def canonical_name(x):
 if x in aliases:return aliases[x]
 return x[1:] if re.match(r'^N[0-9]',x) else x
raw=json.loads((P/'03_tscircuit/build/circuit.json').read_text());components={x['source_component_id']:x for x in raw if x.get('type')=='source_component'};ports={x['source_port_id']:x for x in raw if x.get('type')=='source_port'};nets={x['source_net_id']:x for x in raw if x.get('type')=='source_net'};traces=[x for x in raw if x.get('type')=='source_trace']
assert len(components)==333 and len(ports)==937 and len(nets)==178 and len(traces)==1395
parent={k:k for k in list(ports)+list(nets)}
def root(k):
 assert k in parent,k
 while parent[k]!=k:parent[k]=parent[parent[k]];k=parent[k]
 return k
def join(a,b):parent[root(a)]=root(b)
for t in traces:
 ids=t.get('connected_source_port_ids',[])+t.get('connected_source_net_ids',[]);assert ids,t['source_trace_id']
 for k in ids:assert k in parent,k
 for k in ids[1:]:join(ids[0],k)
groups=collections.defaultdict(lambda:{'names':set(),'endpoints':set()});source_endpoint_ids={}
for k,x in ports.items():
 ep=(components[x['source_component_id']]['name'],str(x['pin_number']));assert ep not in source_endpoint_ids,ep;source_endpoint_ids[ep]=k;groups[root(k)]['endpoints'].add(ep)
for k,x in nets.items():groups[root(k)]['names'].add(canonical_name(x['name']))
expected={};source_nc=set();source_named={};issues=[]
for v in groups.values():
 names=v['names'];eps=v['endpoints']
 if len(names)==1:
  name=next(iter(names));assert name not in source_named;source_named[name]=eps
  if not eps:issues.append({'kind':'empty_named_net','net':name})
  for ep in eps:expected[ep]=name
 elif not names and len(eps)==1:
  ep=next(iter(eps));source_nc.add(ep);expected[ep]=None
 else:issues.append({'kind':'ambiguous_source_component','names':sorted(names),'endpoints':sorted(eps)})
def parse(text):
 stack=[];out=[]
 for token in re.findall(r'"(?:\\.|[^"\\])*"|[()]|[^\s()]+',text):
  if token=='(':
   q=[];(stack[-1] if stack else out).append(q);stack.append(q)
  elif token==')':assert stack;stack.pop()
  else:assert stack;stack[-1].append(json.loads(token) if token.startswith('"') else token)
 assert not stack and len(out)==1 and out[0][0]=='export';return out[0]
def children(obj,tag):return [v for v in obj[1:] if isinstance(v,list) and v and v[0]==tag]
def field(obj,tag):
 xs=children(obj,tag);assert len(xs)==1 and len(xs[0])==2,(tag,xs);return xs[0][1]
def native(path):
 ast=parse(path.read_text(encoding='utf-8-sig'));components_node=children(ast,'components');assert len(components_node)==1;refs=[field(c,'ref') for c in children(components_node[0],'comp')];assert len(refs)==len(set(refs))
 net_node=children(ast,'nets');assert len(net_node)==1;actual={};nc=set();named={};all_nets=[]
 for net in children(net_node[0],'net'):
  name=field(net,'name');nodes=children(net,'node');assert nodes;group=[];ncflags=[]
  for node in nodes:
   ep=(field(node,'ref'),field(node,'pin'));assert ep not in actual,ep;pin_type=field(node,'pintype');is_nc='no_connect' in pin_type.split('+');actual[ep]=None if is_nc else name;group.append(ep);ncflags.append(is_nc)
   if is_nc:nc.add(ep)
  if any(ncflags):assert len(nodes)==1 and all(ncflags),(name,nodes)
  else:assert name not in named;named[name]=set(group)
  all_nets.append({'name':name,'endpoints':sorted(group),'no_connect':all(ncflags)})
 return {'components':len(refs),'refs':set(refs),'map':actual,'nc':nc,'named':named,'groups':all_nets}
results={}
for name,path in [('canonical',P/'06_build/netlists/crow_audio_carrier_v1.net'),('reviewer_native',D/'reviewer-native-export.net')]:
 n=native(path);missing=sorted(set(expected)-set(n['map']));extra=sorted(set(n['map'])-set(expected));wrong=[{'endpoint':ep,'source':expected[ep],'native':n['map'][ep]} for ep in sorted(set(expected)&set(n['map'])) if expected[ep]!=n['map'][ep]];part_diff=sorted(set(c['name'] for c in components.values())^n['refs']);named_diff=[key for key in sorted(set(source_named)|set(n['named'])) if source_named.get(key)!=n['named'].get(key)];nc_diff=sorted(source_nc^n['nc'])
 results[name]={'sha256':sha(path.read_bytes()),'components':n['components'],'endpoints':len(n['map']),'named_nets':len(n['named']),'no_connect_endpoints':len(n['nc']),'missing_endpoints':missing,'extra_endpoints':extra,'wrong_endpoint_nets':wrong,'component_difference':part_diff,'named_partition_difference':named_diff,'no_connect_difference':nc_diff,'pass':not(issues or missing or extra or wrong or part_diff or named_diff or nc_diff)}
 (D/(name+'-partition.json')).write_text(json.dumps(n['groups'],indent=2)+'\n')
sp={x['source_port_id']:x for x in raw if x.get('type')=='schematic_port'};flag_false_connected=sorted(ep for ep,pid in source_endpoint_ids.items() if expected.get(ep) is not None and sp[pid].get('is_connected') is False)
source_rows=[{'reference':ep[0],'pin':ep[1],'net':name,'intentional_nc_inferred_from_isolated_source_port':name is None} for ep,name in sorted(expected.items())];(D/'source-endpoints.json').write_text(json.dumps(source_rows,indent=2)+'\n')
result={'measured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'Union-find of1395source_trace endpoint/net references, independent of subcircuit_connectivity_map_key; compare every ref/pin exactnet and complete named partitions plus native no_connect electrical flags. No converter imports.','source_components':len(components),'source_endpoints':len(expected),'source_named_nets':len(source_named),'source_isolated_endpoints':len(source_nc),'source_issues':issues,'source_false_presentation_flags_on_connected_endpoints':flag_false_connected,'source_false_presentation_flag_count':len(flag_false_connected),'bindings':{rel:sha((P/rel).read_bytes()) for rel in ['03_tscircuit/build/circuit.json','03_tscircuit/net_aliases.txt','03_tscircuit/src/crow_audio_carrier_v1.tsx','04_kicad/crow_audio_carrier_v1.kicad_sch']},'canonical_net_naming_authority':'Explicit aliases take precedence; remove one N before an initial digit, matching authoring N() convention. No arbitrary aliases inferred from membership.','comparisons':results,'scope':'Root independent connectivity diagnostic. Not visual readability, ratings, accepted review, native wire/pin rendering inspection, PCB connectivity or release. Source isolated-port NC inference is corroborated endpoint-by-endpoint by native no_connect flag; does not prove design intent without owning pin dossier/TSX review.','pass':all(x['pass'] for x in results.values())}
(D/'comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['source_false_presentation_flags_on_connected_endpoints','bindings']}));raise SystemExit(0 if result['pass'] else 1)
