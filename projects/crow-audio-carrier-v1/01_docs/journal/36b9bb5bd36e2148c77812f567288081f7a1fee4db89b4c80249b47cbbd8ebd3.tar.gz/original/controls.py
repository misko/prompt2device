from pathlib import Path
import json,re,hashlib,sys
D=Path(__file__).parent;C=D/'controls';C.mkdir(exist_ok=False)
# Re-execute the exact comparison in a separate scratch directory. Original
# reports, source artifacts and archived reviewer output remain untouched.
s=(D/'compare.py').read_text();(C/'compare.py').write_text(s);ns={'__file__':str(C/'compare.py'),'__name__':'__main__'}
try:exec(compile(s,str(C/'compare.py'),'exec'),ns)
except SystemExit as e:assert e.code==0
native=ns['native'];expected=ns['expected'];source_nc=ns['source_nc'];P=ns['P'];raw=(P/'06_build/netlists/crow_audio_carrier_v1.net').read_text();prefix,sep,nets=raw.partition('\n\t(nets\n');assert sep
cases=[]
assert nets.count('(name "ADC_TDM")')==1 and nets.count('(name "MCH_BCLK")')==1
swapped=nets.replace('(name "ADC_TDM")','(name "ROOT_TEMP_SWAP")').replace('(name "MCH_BCLK")','(name "ADC_TDM")').replace('(name "ROOT_TEMP_SWAP")','(name "MCH_BCLK")');cases.append(('swapped_net_names',prefix+sep+swapped,'wrong_net',('J10','2')))
pattern=r'\n\t{3}\(node\n\t{4}\(ref "J10"\)\n\t{4}\(pin "2"\).*?\n\t{3}\)';missing,n=re.subn(pattern,'',nets,count=1,flags=re.S);assert n==1;cases.append(('missing_endpoint',prefix+sep+missing,'missing',('J10','2')))
pattern=r'\n\t{3}\(node\n\t{4}\(ref "J10"\)\n\t{4}\(pin "1"\).*?\n\t{3}\)';m=re.search(pattern,nets,re.S);assert m and '+no_connect' in m.group();missingnc=nets[:m.start()]+m.group().replace('+no_connect','')+nets[m.end():];cases.append(('missing_nc_marker',prefix+sep+missingnc,'missing_nc',('J10','1')))
rows=[]
for name,mutant,kind,target in cases:
 path=C/(name+'.net');path.write_text(mutant);n=native(path);missing=sorted(set(expected)-set(n['map']));extra=sorted(set(n['map'])-set(expected));wrong=sorted(ep for ep in set(expected)&set(n['map']) if expected[ep]!=n['map'][ep]);nc_diff=sorted(source_nc^n['nc'])
 assert missing or extra or wrong or nc_diff,name
 assert target in {'wrong_net':wrong,'missing':missing,'missing_nc':nc_diff}[kind],name
 row={'control':name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'expected':'REJECT','observed':'REJECT','native_endpoint_count':len(n['map']),'missing_endpoints':missing,'extra_endpoints':extra,'wrong_net_endpoints':wrong,'nc_difference':nc_diff};rows.append(row)
(C/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'controls':len(rows),'rejected':len(rows),'named_controls':[x['control'] for x in rows]}))
