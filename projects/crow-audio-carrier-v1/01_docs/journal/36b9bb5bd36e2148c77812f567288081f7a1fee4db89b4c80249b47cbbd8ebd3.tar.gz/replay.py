"""Replay retained diagnostics using frozen inputs and the retained predecessor.

Only the two absolute workspace bindings in compare.py are remapped. The
comparison method and controls are executed unchanged. Run this through the
repository bounded runtime; the output directory must not already exist.
"""
from pathlib import Path
import argparse
import hashlib
import json
import runpy
import shutil
import tarfile

p = argparse.ArgumentParser()
p.add_argument('--predecessor', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
B = Path(__file__).resolve().parent
D = a.output.resolve()
D.mkdir(exist_ok=False)
sha = lambda b: hashlib.sha256(b).hexdigest()
m = json.loads((B / 'schematic-current-delivery-20260911-manifest.json').read_text())
b = a.predecessor.read_bytes()
assert len(b) == m['archive']['size'] and sha(b) == m['archive']['sha256']
root = D / 'repository'
project = root / 'projects/crow-audio-carrier-v1'
review = D / 'review'
shutil.copytree(B / 'inputs', project)
shutil.copytree(B / 'inputs', review / 'project')
out = review / '06_build/task_runs/schematic-current-readability/outputs'
out.mkdir(parents=True)
with tarfile.open(a.predecessor, 'r:gz') as t:
    names = [v.name for v in t.getmembers()]
    assert len(names) == len(set(names))
    for name in ['outputs/evidence.tar.gz', 'outputs/evidence-manifest.json']:
        member = t.getmember(name)
        assert member.isfile()
        data = t.extractfile(member).read()
        assert {'sha256': sha(data), 'size': len(data)} == m['members'][name]
        (out / Path(name).name).write_bytes(data)
code = (B / 'original/compare.py').read_text()
for old, new in [
    ("Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')", repr(root)),
    ("Path('/tmp/carrier-schematic-current-review-20260911')", repr(review)),
]:
    assert code.count(old) == 1
    # repr(Path) uses PosixPath; retain the script's imported Path constructor.
    code = code.replace(old, new.replace('PosixPath(', 'Path('))
(D / 'compare.py').write_text(code)
shutil.copyfile(B / 'original/controls.py', D / 'controls.py')
for script in ['compare.py', 'controls.py']:
    try:
        runpy.run_path(str(D / script), run_name='__main__')
    except SystemExit as e:
        assert e.code == 0, (script, e.code)
print('Frozen replay PASS: both 937-endpoint comparisons and all three negative controls.')
