# Source-to-native endpoint evidence

Root diagnostic, measured September 11, 2026 at 15:14 UTC; controls at 15:15 UTC.
This bundle is preparation for independent review. It does not accept the closed
review, approve design intent, or close a layout/release gate.

## Measured result

The graph reconstructed from all 1,395 compiled source traces contains 333
components, 937 pin endpoints, 178 named nets and 42 isolated pins. Both the
canonical KiCad netlist and the independent reviewer's archived native export
match every endpoint/net assignment and every no-connect pin. No missing,
extra, wrongly assigned or ambiguous endpoints were found.

The comparator uses union-find over source port/net adjacency. It imports
neither the converter nor its connectivity-map resolver. Net naming uses the
explicit source aliases, followed only by removal of the transport N prefix
before an initial digit, as specified by the owning TSX authoring convention.
It does not infer aliases from coincident endpoint membership.

Three mutations of the serialized canonical netlist are rejected by this same
parser and endpoint comparison: swapped ADC_TDM/MCH_BCLK names, removed J10.2,
and removal of J10.1's native no_connect marker. Actual mutated netlists and
all original logs are retained under original/controls/.

## Limits and commissioning correction

Forty-two graph-connected pins have a false schematic_port.is_connected flag.
That presentation flag was not used to classify electrical connectivity.
Graph-isolated pins match the native no_connect flags endpoint by endpoint;
intentional unused-pin treatment must still be judged against the owning
TSX and part dossiers. This is compiled-source/native agreement, not proof of
electrical ratings, visual readability, wire/pin geometry, PCB connectivity,
or release readiness.

The original review packet omitted net_aliases.txt. Its exact current bytes and
hash are now retained as an additional explicit review input. Adding the missing
input must be recorded in the correction commission; it does not authorize
changing the original packet or marking the failed attempt PASS.

## Retained inputs and replay

original/ contains the byte-exact diagnostic scripts, results, exports, logs,
runtime receipts and controls. inputs/ contains the five bound design files.
predecessor/ retains the original envelope, terminal attempt and export manifest.
The existing journal archive named in schematic-current-delivery-20260911-manifest.json
contains the original native evidence archive; it is referenced, not duplicated.

Run replay.py through pipeline_runtime.run_stage with a finite 120-second limit,
passing --predecessor the retained 65e1f753...tar.gz archive and --output a fresh
scratch directory. It verifies the predecessor archive and selected members,
reconstructs frozen input paths, and remaps only the two absolute workspace
bindings in the original comparator. It executes the comparison and controls
unchanged. This replay does not re-export KiCad or invent a new reviewer event.

The bundle's MANIFEST.json inventories every other regular member by size and
SHA-256. Its outer SHA-256 is its journal filename. Reject duplicate members,
links, traversal paths, extra members and hash mismatches when reopening.
