from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, tarfile, io, sys, shutil, subprocess
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope, verify_input_packet
sha=lambda b:hashlib.sha256(b).hexdigest()
files={};proof=[]
jobs=[json.loads(Path('/tmp/carrier-channel-thermal-canonical-opened.json').read_text()),*json.loads((D/'thermal-schematic-availability-opened.json').read_text())]
for number,j in enumerate(jobs):
 root=Path(j['project']);A=Path(j['attempt']).parent;e=TaskEnvelope.from_json(Path(j['envelope']).read_text());a=json.loads((A/'attempt.json').read_text())
 assert a['status']=='PASS' and verify_input_packet(e,root)[0]
 for n,m in a['output']['completion']['outputs'].items():
  b=(A/'outputs'/n).read_bytes();assert len(b)==m['size'] and sha(b)==m['sha256']
 for item in e.input_packet:files[f'task{number}/inputs/'+item.path]=root/item.path
 for f in A.rglob('*'):
  if f.is_file() and f.name!='.closing':files[f'task{number}/runtime/'+f.relative_to(A).as_posix()]=f
 proof.append({'root':str(root),'inputs':len(e.input_packet),'outputs':len(a['output']['completion']['outputs']),'status':a['status']})
j=jobs[0];H=Path(j['task']).parent
idx=json.loads((H/'source-index.json').read_text())
for n,h in idx.items():
 f=Path(n);assert sha(f.read_bytes())==h;files['source/'+f.relative_to(R).as_posix()]=f
ev=json.loads((Path(j['output_dir'])/'evidence.json').read_text())
for n,m in ev['artifacts'].items():
 f=P/n;b=f.read_bytes();assert len(b)==m['size'] and sha(b)==m['sha256'];files['generated/'+n]=f
started=datetime.fromisoformat(j['deadline_at'].replace('Z','+00:00')).timestamp()-1200
for name in [p.name for p in (P/'06_build/task_runs').glob('qualify-*') if p.is_dir() and p.stat().st_mtime>=started]:
 for f in (P/'06_build/task_runs'/name).rglob('*'):
  if f.is_file():files['qualification/'+name+'/'+f.relative_to(P/'06_build/task_runs'/name).as_posix()]=f
checkpoint=json.loads((P/'06_build/checkpoints/prelayout-inputs.json').read_text())
for n in checkpoint['explicit']:
 f=R/n.removeprefix('repo:');assert sha(f.read_bytes())==checkpoint['files'][n]['sha256'];files['generated/'+f.relative_to(P).as_posix()]=f
for group in ['checkpoints','sourcing','pipeline_state','verification']:
 for f in (P/'06_build'/group).rglob('*'):
  if f.is_file() and f.stat().st_mtime>=started:files['generated/'+f.relative_to(P).as_posix()]=f
for n in ['06_build/build_provenance.json','06_build/performance.json','06_build/erc.rpt','06_build/erc_errors.rpt','06_build/source_policy_audit.md']:
 files['generated/'+n]=P/n
for n in ['channel-thermal-guard-retirement.json','channel_canonical_runner.py','commission_channel_thermal_canonical.py','prepare_thermal_schematic_delta.py','commission_thermal_delta.py','preserve_thermal_canonical.py','channel-thermal-correction-preservation.json']:
 files['root/'+n]=D/n
for p in [*Path('/tmp/carrier-connector-integration-20260911').glob('channel-thermal-*')]:
 if p.is_file():files['root/source-closeout/'+p.name]=p
result={'time':datetime.now(timezone.utc).isoformat(),'tasks':proof,'source_index_verified':len(idx),'checkpoint_companions':len(checkpoint['explicit']),'artifacts_verified':len(ev['artifacts']),'scope':'Completed canonical generation and separate fresh availability. Actual PR-REVIEW stale-review failure retained; current engineering review is a separate live attempt.'}
(D/'thermal-canonical-reopening.json').write_text(json.dumps(result,indent=2)+'\n');files['root/canonical-reopening.json']=D/'thermal-canonical-reopening.json'
# Retain previous immutable archives by verified Git preimage rather than nesting
# old history in this new evidence bundle. Deduplicate identical input paths.
source_commit='9e00dcf23d03b244164476b51fc705ea0728d440'
references={};seen={};git_cache={}
tracked=set(subprocess.check_output(['git','ls-tree','-r','--name-only',source_commit],cwd=R,text=True).splitlines())
for n,f in list(sorted(files.items())):
 b=f.read_bytes();h=sha(b);rel=f.relative_to(R).as_posix() if f.is_relative_to(R) else None
 if rel in tracked:
  if rel not in git_cache:
   old=subprocess.run(['git','show',source_commit+':'+rel],cwd=R,capture_output=True);assert old.returncode==0
   git_cache[rel]=(len(old.stdout),sha(old.stdout))
  if git_cache[rel]==(len(b),h):
   references[n]={'git_commit':source_commit,'path':rel,'size':len(b),'sha256':h};del files[n];continue
 if h in seen:
  references[n]={'archive_member':seen[h],'size':len(b),'sha256':h};del files[n]
 else:seen[h]=n
(D/'thermal-canonical-input-references.json').write_text(json.dumps(references,indent=2)+'\n');files['root/canonical-input-references.json']=D/'thermal-canonical-input-references.json'
result['verified_references']=len(references)
members={n:{'size':f.stat().st_size,'sha256':sha(f.read_bytes())} for n,f in sorted(files.items())}
tmp=D/'thermal-canonical-preserved.tar.gz'
with tarfile.open(tmp,'w:gz',compresslevel=3) as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 b=(json.dumps({'members':members},indent=2)+'\n').encode();m=tarfile.TarInfo('MANIFEST.json');m.size=len(b);t.addfile(m,io.BytesIO(b))
h=sha(tmp.read_bytes());out=D/(h+'.tar.gz');assert not out.exists();shutil.copyfile(tmp,out)
with tarfile.open(out) as t:
 assert set(t.getnames())==set(members)|{'MANIFEST.json'}
 for n,row in members.items():b=t.extractfile(n).read();assert len(b)==row['size'] and sha(b)==row['sha256'],n
result.update(archive=str(out),sha256=h,size=out.stat().st_size,payload_members=len(members));(D/'thermal-canonical-preservation-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
