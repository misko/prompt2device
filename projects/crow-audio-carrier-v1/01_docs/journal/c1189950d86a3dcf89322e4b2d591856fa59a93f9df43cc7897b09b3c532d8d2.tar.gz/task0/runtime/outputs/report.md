# Recorded canonical attempt

- qualify: rc=0, 18.614114s; full raw output execution.log
- normal: rc=2, 94.81429s; full raw output execution.log
- public-continuation: rc=1, 4.081061s; full raw output execution.log
- Authored input hashes: 593/593
- All generated identities are in execution.json.
- Stop at the last actual recorded gate. No routing or release acceptance.
