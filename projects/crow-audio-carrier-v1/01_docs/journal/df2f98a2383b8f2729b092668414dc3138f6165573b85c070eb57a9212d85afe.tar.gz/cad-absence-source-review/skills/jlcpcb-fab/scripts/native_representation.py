"""Explicit authority for a native body when fetched vendor CAD has no model.

This module validates identities and scope only. Physical registration remains
owned by model_registration_gate; A-RENDER measures independent Fab/pixel data.
"""
from datetime import date
import hashlib
import json
from pathlib import Path
import re


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def safe_file(root, relative):
    p = Path(str(relative))
    if p.is_absolute() or ".." in p.parts or not p.parts:
        raise ValueError("native representation path must be bundle/project relative")
    resolved = (Path(root) / p).resolve()
    if not resolved.is_relative_to(Path(root).resolve()):
        raise ValueError("native representation path escapes its root")
    if not resolved.is_file() or resolved.stat().st_size == 0:
        raise ValueError(f"native representation file missing/empty: {relative}")
    return resolved


def declarations(rows):
    result = {}
    fields = {"reason", "mpn", "vendor_footprint_sha256", "model_sha256",
              "registration_group", "authority", "native_footprint", "generator",
              "provenance", "reviewer", "reviewed_on", "limitations"}
    for row in rows:
        spec = row.get("native_representation")
        if spec is None:
            continue
        if not isinstance(spec, dict) or set(spec) != fields:
            raise ValueError("native_representation requires the closed authority schema")
        if (row.get("render_model_source") != "native" or
                spec["reason"] != "vendor_model_absent"):
            raise ValueError("native representation requires native/vendor_model_absent")
        refs = row.get("refs")
        if (not isinstance(refs, list) or not refs or len(refs) != len(set(refs)) or
                any(not isinstance(r, str) or not re.fullmatch(r"[A-Za-z0-9_.-]+", r)
                    for r in refs)):
            raise ValueError("native representation refs must be explicit, unique and safe")
        if not re.fullmatch(r"C[0-9]+", str(row.get("lcsc", ""))):
            raise ValueError("native representation requires exact LCSC code")
        for key in ("mpn", "registration_group", "reviewer", "limitations"):
            if not isinstance(spec[key], str) or not spec[key].strip():
                raise ValueError(f"native representation requires {key}")
        date.fromisoformat(spec["reviewed_on"])
        if not re.fullmatch(r"[A-Za-z0-9_.-]+", spec["registration_group"]):
            raise ValueError("native registration group must be a safe identifier")
        for key in ("vendor_footprint_sha256", "model_sha256"):
            if not re.fullmatch(r"[a-f0-9]{64}", str(spec[key])):
                raise ValueError(f"native representation invalid {key}")
        for key in ("authority", "native_footprint", "generator", "provenance"):
            record = spec[key]
            expected = {"path", "sha256"} | ({"pages", "revision"} if key == "authority" else set())
            if (not isinstance(record, dict) or set(record) != expected or
                    not re.fullmatch(r"[a-f0-9]{64}", str(record.get("sha256", "")))):
                raise ValueError(f"native representation invalid {key} record")
            if key == "authority":
                pages = record["pages"]
                if (not isinstance(pages, list) or not pages or
                        any(type(p) is not int or p <= 0 for p in pages) or
                        len(pages) != len(set(pages)) or
                        not isinstance(record["revision"], str) or not record["revision"].strip()):
                    raise ValueError("native authority needs positive unique pages and revision")
        for ref in refs:
            if ref in result:
                raise ValueError(f"duplicate native representation ref {ref}")
            result[ref] = {**spec, "lcsc": row["lcsc"], "refs": sorted(refs)}
    return result


def check_vendor(spec, code, footprint, model_count):
    if code != spec["lcsc"] or model_count != 0:
        raise ValueError("native absence authority disagrees with code/vendor model count")
    if not footprint or sha(footprint) != spec["vendor_footprint_sha256"]:
        raise ValueError("native absence authority disagrees with fetched footprint bytes")


def check_source_files(project, spec):
    for key in ("authority", "native_footprint", "generator", "provenance"):
        record = spec[key]
        if sha(safe_file(project, record["path"])) != record["sha256"]:
            raise ValueError(f"native representation {key} source changed")


def check_overlay_receipt(bundle, source_board, ref, code, footprint, model_count, spec):
    """Reopen delivered identities without using rendered pixels as authority."""
    check_vendor(spec, code, footprint, model_count)
    receipt = json.loads(safe_file(bundle, "native_representation_receipt.json").read_text())
    if receipt.get("schema") != 1 or receipt.get("source_board_sha256") != sha(source_board):
        raise ValueError("native representation receipt source board differs")
    if receipt.get("twin_board_sha256") != sha(safe_file(bundle, "twin.kicad_pcb")):
        raise ValueError("native representation receipt twin board differs")
    matches = [r for r in receipt.get("rows", []) if r.get("ref") == ref]
    if len(matches) != 1 or matches[0].get("declaration") != spec:
        raise ValueError("native representation receipt scope/authority differs")
    row = matches[0]
    if sha(safe_file(bundle, row["model"])) != spec["model_sha256"]:
        raise ValueError("native representation bundled model differs")
    registration = safe_file(bundle, row["registration_manifest"])
    if sha(registration) != row["registration_manifest_sha256"]:
        raise ValueError("native representation registration manifest differs")
    manifest = json.loads(registration.read_text())
    if manifest.get("status") != "PASS":
        raise ValueError("native representation registration is not accepted")
    for name, record in manifest["outputs"].items():
        artifact = safe_file(registration.parent, name)
        if artifact.stat().st_size != record["size"] or sha(artifact) != record["sha256"]:
            raise ValueError("native representation registration evidence differs")
    return row
