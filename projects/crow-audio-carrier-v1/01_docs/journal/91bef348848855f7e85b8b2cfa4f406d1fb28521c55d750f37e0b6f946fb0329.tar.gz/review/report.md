review_stage: pre-route
review_kind: schematic_render
reviewer: /root/carrier_rj45_native_carrier_readability_corrected
reviewer_identity: fresh independent Codex review agent
context: FRESH
date: 2026-09-12
design_verdict: DEFECTIVE
order_verdict: DO-NOT-ORDER
netlist_sha256: fcbc77f7f615d47dec4b7d58a3f451033be34cff00fddefa064cebf2af7ed06e
parts_sha256: af715d3842f3e6e4ce4102f12023e2493aea1b3e7591ce0638cceecb9975594d
design_rules_sha256: c1e4fa3248fbe4fbecf77bb427cb1023ad1a2d237251cb36990f3e6cbce3dc65
schematic_pdf_sha256: 1f0eff66aef185da0648326928fdd25018d10a4d37e9d34a2b616379d35600da
exact_netlist_sha256: 3e724ae1790d7ff23ce6a51a7bd9bfdbf365bcc6092489b995dce7c23f6fad2e
circuit_json_sha256: 56ba476a3aefa3ee576315b1959e88c8a97bb98aeff055af41bcb818b295d75e
kicad_schematic_sha256: 427fe8aa3eadf3a52bbfdc3aec6221d1c053f734132ef9f5d3145adcd181812c
envelope_raw_sha256: 4581f7251e4472879fb2c7035a615932216d86d1ab8d96b1df04bf609a3500c5
envelope_semantic_sha256: 7b46e5ed8c53f4e5a7de759b264b7ccf3892d6cef62ba2d3a495ab95633aa0af

The corrected human PDF remains DEFECTIVE for readability. All three original findings are closed on these exact bytes, but this fresh review identifies two other S11 defects, affecting nine locations. No live source edits or hypothetical later corrections are accepted.

Measured coverage: visually reviewed19/19 independently rendered actual PDF pages and enlarged details; checked333/333 source component references in the PDF,2,616 word boxes with0 off-page boxes,80/80 visible RJ45 pin numbers/names,80/80 native pin identities and80/80 source-trace graph identities. Native netlist contains333 components,221 nets and985 terminals. All221 native net node sets match the preceding netlist. This is not a claim of independent ratings review of all985 terminals. Three connector known-bad controls reject audio swap,shell-to-ground and missing return.

READ-ISO-VALUE-GROUND — P1,S11,pages6–13: R_ADC_PD1P..R_ADC_PD8P ground downlegs and bars cross the DSG region of U_ISO1..U_ISO8 value TMUX2821DSGR. Eight of eight instances confirmed in actual PDF ink. Source location:03_tscircuit/src/schematic_presentation.tsx lines71–72 and Ground helper at176–201. Move the resistor ground presentation or value clearance in owning source, regenerate and inspect all eight. Exact crop scratch/isolation-detail.png and census montage show the collision. U_ISO and pulldown component geometry matches previous CircuitJSON: this is a newly discovered inherited defect, not an electrical regression attributed to this correction.

READ-FSYNC-LABEL-WIRE — P1,S11,page17: the MCH_FSYNC plate next to R_MCH_FSYNC_PD is crossed by its vertical downleg through the final C. The pale label fill does not remove the visible underlying conductor. Exact crop scratch/candidate-17-MCH_FSYNC.png. Move the source-owned label or downleg so the conductor reaches the attachment without entering the lettering; regenerate and recheck.

Original finding closure: READ-RJ45-GROUND(P1) is closed at8/8 jack bodies and24/24 return pins: the ground bar and GND text now sit below the body and pin numbers2/6/8. READ-RJ45-CHASSIS(P1) is closed at8/8 channels: CHASSIS label appears above/left of each shell pair and clears the12V downleg. The16 shell pins remain CHASSIS, separate from GND. Vertical shell wires cross the supply horizontal without junction dots; both continue through the crossing, and native pin checks confirm separate identities. READ-CLOCK-REFERENCE(P2) is closed:3V3_ADC plate clears U_CLK on page17. The full jack MPN clears C_A1P..C_A8P after the leftward move.

The complete raster census covered19 pages and2,616 word boxes at4000px page size, retaining819 raw red-run/green hits. Of these33 cross-color or green candidates were inspected individually; nine actual collision instances produce the two findings above. C_LDO_IN page3 is a narrow clear gap despite bbox overlap; all eight vertical5V_LDO_HOLD names are clear; FILT1P/2P and page18 supply candidates touch plate borders without obscuring glyphs; nearby body/value boxes are not glyph collisions. Red-only hits predominantly represent label borders, underscores and symbol outlines; whole-page review supplements the candidate filter. The raster screen is not an exhaustive vector proof, and its threshold/antialiasing limits are retained in evidence.

Pages1–5 and14–16,18–19 have no visually confirmed glyph collision. Primary power/protection/regulation and audio paths are wired; diode K/A, capacitor polarity, NC naming and local bypass are visible. Individual observations are retained for all19 pages.

Scope: custom analog audio plus DC on factory shieldedCat6A RJ45,not Ethernet/PoE;mate with power off. Frozen SOURCE connector receipt PASS and FULL INCOMPLETE with23 carrier physical unknowns;9 pod unknowns are inherited. ADR7 authorizes prototype progression FIRST-ARTICLE-ONLY/DO-NOT-ORDER;this review does not invent a physical pre-schematic gate or physicalPASS. Jack-only manufacturer ratings do not qualify the cable/plug/system. Public catalog screen is design-only,operator response blank and allocation absent. Placement,routing,layout/render,DRC,fabrication,release,firstarticle and outdoor qualification remain owed. LAYOUT0013/3 is inherited and not re-proved. ARCHITECTURE.md MicroFit/Cat5 prose is separate document debt to close before release;this lens does not accept it.

Independently verified436/436 frozen files,full semantic/raw envelope subject and all seven expected-subject hashes. Initial provided preflight passed input/writer assertions then rejected deliberately absent output membership; final preflight follows packaging. Only allocated scratch/output were written. Evidence preserves all render pages,crops,census methods,independent checks,raw runtime logs,exact packet manifest and key input copies. Every archive member is regular,path-safe,unique,hashed and reopened. Delivery PASS means this honest rejection is fully delivered;it is not design SOUND.
