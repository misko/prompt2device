from pathlib import Path
import json,hashlib,tarfile,sys,shutil
B=Path('/tmp/rj45-pod-topology-review-placement1-ids2so8u');D=B/'06_build/task_runs/rj45-pod-topology-review-placement1';S=D/'scratch';O=D/'outputs';H=lambda b:hashlib.sha256(b).hexdigest()
e=json.loads((D/'envelope.json').read_text());hs=json.loads((S/'hashes.json').read_text());a=json.loads((S/'analysis.json').read_text());par=json.loads((S/'parity.json').read_text());facts=json.loads((S/'facts.json').read_text());pdf=json.loads((S/'pdf-comparison.json').read_text())
assert len(a['compared_files'])==23 and len(facts['local_primary_pdfs_hash_verified'])==20
for x in e['input_packet']:
 p=B/x['path'];b=p.read_bytes();assert len(b)==x['size'] and H(b)==x['sha256'] and not p.is_symlink()
(S/'inputs-after.json').write_text(json.dumps({'verified':len(e['input_packet']),'status':'PASS'},indent=2))
head={'review_stage':'pre-route','review_kind':'topology','reviewer':'/root/carrier_rj45_native_pod_topology_placement1','reviewer_identity':'fresh independent agent /root/carrier_rj45_native_pod_topology_placement1','context':'FRESH','date':'2026-09-12','design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER',**hs}
(O/'report.md').write_text('\n'.join(f'{k}: {v}' for k,v in head.items())+'\n\n'+(S/'report-body.md').read_text())
ev={'schema':1,'design_verdict':'SOUND','verdict':'SOUND','order_verdict':'DO-NOT-ORDER','subject':e['subject'],'hashes':hs,'review_stage':'pre-route','review_kind':'topology','context':'FRESH','counts':{'inputs_verified':194,'accepted_file_pairs':23,'native_components':40,'native_nets':24,'native_nodes':103,'connected_pins':99,'intended_nc':4,'invariants_pass':39,'invariants_total':39,'pdf_pages':4,'pdf_body_pixels':13920000,'firstpower_population':33,'testpoints':7},'methods':['frozen owner hash algorithm recomputation','exact accepted/current source comparison','independent native export and complete ref-pin-net graph','all-object CircuitJSON comparison','current dossier/native identity and footprint agreement','39 native electrical invariants','all-page pixel difference and host visual inspection','exact jack primary drawing images','rating and cable arithmetic','archive per-member reopen and frozen input reverification'],'findings':[],'limitations':['No PCB, routing, physical qualification, release or order acceptance','Current pod packet has no carrier native/card bytes','Prior non-overlap source bytes unavailable; no invented full-history delta claim','158 classified native warnings remain','SOURCE PASS / FULL INCOMPLETE 9 physical obligations preserved','Public catalog admission is design-only'],'parity':par,'facts':facts,'pdf_comparison':pdf,'comparison':a['compared_files']}
(O/'evidence.json').write_text(json.dumps(ev,indent=2)+'\n')
runtime=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
for filename in ['pipeline_runtime.py','pipeline_execution.py','pipeline_artifacts.py']:
 shutil.copyfile(runtime/filename,S/('runtime-source-'+filename))
shutil.copyfile(B/'context/skills/kicad-pcb/scripts/pre_route_review_check.py',S/'hash-owner.py')
# Package stable completed evidence; exclude the currently active packaging log/receipt.
files=sorted(p for p in S.iterdir() if p.is_file() and p.name not in {'package-final.log','package-final.runtime.json'} and not p.name.startswith('preflight'))
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in files:assert not p.is_symlink();t.add(p,arcname='evidence/'+p.name,recursive=False)
rows=[];seen=set()
with tarfile.open(archive,'r:gz') as t:
 for m in t.getmembers():
  assert m.isfile() and not m.issym() and not m.islnk() and not m.name.startswith('/') and '..' not in Path(m.name).parts and m.name not in seen and not m.name.endswith('.tar.gz');seen.add(m.name)
  b=t.extractfile(m).read();assert len(b)==m.size; original=S/Path(m.name).name;assert b==original.read_bytes();rows.append({'path':m.name,'size':len(b),'sha256':H(b)})
manifest={'schema':1,'archive_sha256':H(archive.read_bytes()),'archive_size':archive.stat().st_size,'member_count':len(rows),'members':rows}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(O/'result.json').write_text(json.dumps({'subject':e['subject'],'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]},indent=2)+'\n')
assert sorted(p.name for p in O.iterdir())==['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md','result.json']
print(json.dumps({'outputs':5,'archive_members':len(rows),'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'design_verdict':'SOUND','frozen_inputs_verified':194}))
