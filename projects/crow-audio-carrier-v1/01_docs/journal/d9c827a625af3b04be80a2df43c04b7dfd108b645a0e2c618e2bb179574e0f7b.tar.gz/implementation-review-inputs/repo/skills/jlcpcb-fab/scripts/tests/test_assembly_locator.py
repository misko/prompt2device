"""Hostile locator controls; native fixture authored independently of emitter."""
from pathlib import Path
import csv
import contextlib
import hashlib
import io
import json
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import pcbnew
from PIL import Image

SCRIPTS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SCRIPTS))
import assembly_locator as producer
import assembly_locator_check as checker


class LocatorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base = tempfile.TemporaryDirectory(prefix="locator-fixture-")
        root = Path(cls.base.name)
        board = pcbnew.BOARD()
        net = pcbnew.NETINFO_ITEM(board, "SIGNAL")
        board.Add(net)
        records = []
        for index, ref in enumerate(["R1", "R2", "R3"], 1):
            x, y = index*10, 10
            fp = pcbnew.FOOTPRINT(board)
            fp.SetReference(ref)
            fp.SetValue("10k")
            fp.SetAttributes(pcbnew.FP_SMD)
            fp.SetPosition(pcbnew.VECTOR2I(x*1000000, y*1000000))
            fp.Reference().SetLayer(pcbnew.F_SilkS)
            fp.Reference().SetVisible(index == 3)
            shape = pcbnew.PCB_SHAPE(fp)
            shape.SetShape(pcbnew.SHAPE_T_RECT)
            shape.SetLayer(pcbnew.F_Fab)
            shape.SetStart(pcbnew.VECTOR2I(int((x-.8)*1e6), int((y-.4)*1e6)))
            shape.SetEnd(pcbnew.VECTOR2I(int((x+.8)*1e6), int((y+.4)*1e6)))
            fp.Add(shape)
            for number, dx in [("1", -.825), ("2", .825)]:
                pad = pcbnew.PAD(fp)
                pad.SetNumber(number)
                pad.SetAttribute(pcbnew.PAD_ATTRIB_SMD)
                pad.SetShape(pcbnew.PAD_SHAPE_RECT)
                pad.SetSize(pcbnew.VECTOR2I(800000, 950000))
                pad.SetPosition(pcbnew.VECTOR2I(round((x+dx)*1e6), y*1000000))
                layers = pcbnew.LSET()
                layers.AddLayer(pcbnew.F_Cu)
                pad.SetLayerSet(layers)
                pad.SetNet(net)
                fp.Add(pad)
            board.Add(fp)
            if index < 3:
                records.append({"ref": ref, "value": "10k", "mpn": "R-10K", "lcsc": "C100",
                                "x": x, "y": y, "rotation": 0, "side": "top",
                                "pads": [{"number": "1", "net": "SIGNAL"}, {"number": "2", "net": "SIGNAL"}]})
        edge = pcbnew.PCB_SHAPE(board)
        edge.SetShape(pcbnew.SHAPE_T_RECT)
        edge.SetLayer(pcbnew.Edge_Cuts)
        edge.SetStart(pcbnew.VECTOR2I(0, 0))
        edge.SetEnd(pcbnew.VECTOR2I(40000000, 20000000))
        board.Add(edge)
        pcbnew.SaveBoard(str(root / "board.kicad_pcb"), board)
        (root / "bom.csv").write_text('Designator,Comment,MPN,LCSC\n"R1,R2,R3",10k,R-10K,C100\n')
        (root / "cpl.csv").write_text('Designator,Mid X,Mid Y,Layer,Rotation\nR1,10,-10,Top,0\nR2,20,-10,Top,0\nR3,30,-10,Top,0\n')
        (root / "config.yaml").write_text(json.dumps({"schema": 1, "title": "Test board",
            "owner": "test owner", "orientation": "Component side up; origin upper left.", "exceptions": records}))
        producer.generate(root / "board.kicad_pcb", root / "bom.csv", root / "cpl.csv", root / "config.yaml", root / "out")

    @classmethod
    def tearDownClass(cls):
        cls.base.cleanup()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="locator-hostile-")
        self.root = Path(self.temp.name) / "fixture"
        shutil.copytree(self.base.name, self.root)
        self.out = self.root / "out"

    def tearDown(self):
        self.temp.cleanup()

    def check(self):
        return checker.check(self.root / "board.kicad_pcb", self.root / "bom.csv",
                             self.root / "cpl.csv", self.root / "config.yaml", self.out)

    def read(self, name):
        return json.loads((self.out / name).read_text())

    def write(self, name, data):
        (self.out / name).write_text(json.dumps(data))

    def rehash_members(self):
        doc = self.read("assembly_locator_manifest.json")
        for rec in doc["members"]:
            path = self.out / rec["path"]
            rec.update(sha256=checker.digest(path), size=path.stat().st_size)
        self.write("assembly_locator_manifest.json", doc)

    def update_data(self, mutate):
        data = self.read("assembly_locator.json")
        mutate(data)
        self.write("assembly_locator.json", data)
        html = self.out / "assembly_locator.html"
        text = re.sub(r"const DATA=.*?;const byRef=", lambda _: "const DATA=" + json.dumps(data) + ";const byRef=", html.read_text(), flags=re.S)
        html.write_text(text)
        self.rehash_members()

    def accept_new_input_hash(self, key, path):
        self.update_data(lambda data: data.update({key: checker.digest(path)}))
        manifest = self.read("assembly_locator_manifest.json")
        manifest[key] = checker.digest(path)
        self.write("assembly_locator_manifest.json", manifest)

    def test_clean_full_denominators(self):
        self.assertEqual(self.check(), {"assembled_refs": 3, "pads": 6, "exceptions": 2, "pages": 2, "manifest_members": 5})

    def test_stale_board(self):
        path = self.root / "board.kicad_pcb"
        path.write_text(path.read_text() + "\n")
        with self.assertRaisesRegex(ValueError, "stale board"):
            self.check()

    def test_bom_mpn_mutation_with_fresh_hash(self):
        path = self.root / "bom.csv"
        path.write_text(path.read_text().replace("R-10K", "WRONG-MPN"))
        self.accept_new_input_hash("bom_sha256", path)
        with self.assertRaisesRegex(ValueError, "BOM identity"):
            self.check()

    def test_cpl_coordinate_side_rotation_with_fresh_hash(self):
        path = self.root / "cpl.csv"
        original = path.read_text()
        for replacement, reason in [("R1,11,-10,Top,0", "datum"), ("R1,10,-10,Bottom,0", "side"), ("R1,10,-10,Top,90", "rotation")]:
            with self.subTest(reason=reason):
                path.write_text(original.replace("R1,10,-10,Top,0", replacement))
                self.accept_new_input_hash("cpl_sha256", path)
                with self.assertRaisesRegex(ValueError, "CPL " + reason):
                    self.check()

    def test_missing_reference(self):
        self.update_data(lambda data: data["parts"].pop())
        with self.assertRaisesRegex(ValueError, "denominator"):
            self.check()

    def test_duplicate_reference(self):
        self.update_data(lambda data: data["parts"].__setitem__(1, data["parts"][0]))
        with self.assertRaisesRegex(ValueError, "reference set/duplicate"):
            self.check()

    def test_swapped_pad_net(self):
        self.update_data(lambda data: data["parts"][0]["pads"][0].update(net="WRONG_NET"))
        with self.assertRaisesRegex(ValueError, "pad identity"):
            self.check()

    def test_extra_hidden_native_reference(self):
        path = self.root / "board.kicad_pcb"
        board = pcbnew.LoadBoard(str(path))
        board.FindFootprintByReference("R3").Reference().SetVisible(False)
        pcbnew.SaveBoard(str(path), board)
        self.accept_new_input_hash("board_sha256", path)
        with self.assertRaisesRegex(ValueError, "omission sets"):
            self.check()

    def test_html_data_disagreement(self):
        path = self.out / "assembly_locator.html"
        path.write_text(path.read_text().replace('"value":"10k"', '"value":"WRONG"', 1))
        self.rehash_members()
        with self.assertRaisesRegex(ValueError, "HTML/JSON"):
            self.check()

    def test_missing_and_duplicate_page_records(self):
        original = self.read("assembly_locator_manifest.json")
        for records in [original["page_refs"][:1], [original["page_refs"][0], original["page_refs"][0]]]:
            doc = dict(original, page_refs=records)
            self.write("assembly_locator_manifest.json", doc)
            with self.assertRaisesRegex(ValueError, "atlas"):
                self.check()

    def test_wrong_pdf_page_order_even_with_rehashed_manifest(self):
        pages = [Image.open(self.out / f"assembly_locator_{i:03d}.png").convert("RGB") for i in [2, 1]]
        pages[0].save(self.out / "assembly_locator.pdf", save_all=True, append_images=pages[1:], resolution=200)
        self.rehash_members()
        with self.assertRaisesRegex(ValueError, "PDF/PNG"):
            self.check()

    def test_wrong_png_reference_even_with_rehashed_manifest(self):
        shutil.copyfile(self.out / "assembly_locator_002.png", self.out / "assembly_locator_001.png")
        self.rehash_members()
        with self.assertRaisesRegex(ValueError, "PNG reference"):
            self.check()

    def test_missing_manifest_member(self):
        (self.out / "assembly_locator_001.png").unlink()
        with self.assertRaisesRegex(ValueError, "missing/corrupt"):
            self.check()

    def test_corrupt_manifest_member(self):
        path = self.out / "assembly_locator_001.png"
        path.write_bytes(path.read_bytes() + b"corrupt")
        with self.assertRaisesRegex(ValueError, "missing/corrupt"):
            self.check()

    def test_unknown_query_clears_previous_selection(self):
        runtime = shutil.which("bun") or shutil.which("node")
        self.assertIsNotNone(runtime, "JavaScript runtime required for locator transition control")
        result = subprocess.run([runtime, str(Path(__file__).with_name("locator_ui_control.js")),
                                 str(self.out / "assembly_locator.html")], capture_output=True, text=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_html_wrong_body_with_correct_data(self):
        path = self.out / "assembly_locator.html"
        path.write_text(path.read_text().replace('class="body" x="', 'class="body" x="1', 1))
        self.rehash_members()
        with self.assertRaisesRegex(ValueError, "HTML body geometry"):
            self.check()

    def test_html_selection_code_changed(self):
        path = self.out / "assembly_locator.html"
        path.write_text(path.read_text().replace("location.hash='';", "location.hash='R1';", 1))
        self.rehash_members()
        with self.assertRaisesRegex(ValueError, "HTML executable"):
            self.check()

    def test_wrong_unique_reference(self):
        self.update_data(lambda data: data["parts"][0].update(ref="WRONG_REF"))
        with self.assertRaisesRegex(ValueError, "reference set"):
            self.check()

    def make_release(self):
        release = self.root / "07_releases/v1-2026-09-11"
        source = release / "source"
        source.mkdir(parents=True)
        shutil.copytree(self.out, release / "fab")
        for old, new in [("board.kicad_pcb", "board.kicad_pcb"), ("config.yaml", "assembly_locator.yaml")]:
            shutil.copyfile(self.root / old, source / new)
        for name in ["bom.csv", "cpl.csv"]:
            shutil.copyfile(self.root / name, release / "fab" / name)
        (source / "locator_tools").mkdir()
        for name in ["assembly_locator.py", "assembly_locator.html", "assembly_locator_check.py"]:
            shutil.copyfile(SCRIPTS / name, source / "locator_tools" / name)
        waiver = [{"id": "P-SILK-REF", "refs": ["R1", "R2"],
                   "why": "These exact two references use the independently reviewed assembly atlas and native identity records.",
                   "evidence": [{"command": "/usr/bin/python3 assembly_locator_check.py project fixture"}]}]
        (source / "policy_waivers.yaml").write_text(json.dumps(waiver))
        return release

    def test_release_reads_only_its_shipped_sources(self):
        release = self.make_release()
        (self.root / "bom.csv").write_text("mutable project changed")
        self.assertEqual(checker.release_check(release)["exceptions"], 2)

    def test_release_missing_source_and_wrong_waiver_set(self):
        release = self.make_release()
        config = release / "source/assembly_locator.yaml"
        data = config.read_bytes()
        config.unlink()
        with self.assertRaisesRegex(ValueError, "source contract"):
            checker.release_check(release)
        config.write_bytes(data)
        waiver = release / "source/policy_waivers.yaml"
        entries = json.loads(waiver.read_text())
        entries[0]["refs"] = ["R1"]
        waiver.write_text(json.dumps(entries))
        with self.assertRaisesRegex(ValueError, "waiver/locator sets"):
            checker.release_check(release)

    def test_freshness_composes_locator_failure(self):
        import release_freshness_check
        release = self.make_release()
        (release / "fab/assembly_locator_001.png").unlink()
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            result = release_freshness_check.main([str(release), "--claim", "design"])
        self.assertNotEqual(result, 0)
        self.assertIn("A-LOCATOR FAIL", output.getvalue())

    def test_project_requires_human_waiver(self):
        rules = self.root / "03_src/rules"
        rules.mkdir(parents=True)
        shutil.copyfile(self.root / "config.yaml", rules / "assembly_locator.yaml")
        with self.assertRaisesRegex(ValueError, "source policy waiver"):
            checker.project_check(self.root, self.root / "board.kicad_pcb", self.out)

    def test_placement_review_composes_locator_failure(self):
        kicad = SCRIPTS.parents[1] / "kicad-pcb/scripts"
        sys.path.insert(0, str(kicad))
        import pre_route_review_check
        rules = self.root / "03_src/rules"
        rules.mkdir(parents=True)
        shutil.copyfile(self.root / "config.yaml", rules / "assembly_locator.yaml")
        part = self.root / "02_parts/R-10K"
        part.mkdir(parents=True)
        (part / "part.yaml").write_text("mpn: R-10K\n")
        config = {"flow": {"pre_route_reviews": {"board": "board.kicad_pcb",
            "pin": "missing-pin.md", "layout": "missing-layout.md", "render": "missing-render.md", "a_render": "missing-overlay.md"}}}
        (self.root / "03_src/route.yaml").write_text(json.dumps(config))
        output = io.StringIO()
        with patch("promoted_route_check.check", return_value=([], "fixture: no promoted route", 0, 0, 0)), contextlib.redirect_stdout(output):
            result = pre_route_review_check.main([str(self.root), "--phase", "placement"])
        self.assertNotEqual(result, 0)
        self.assertIn("A-LOCATOR", output.getvalue())
        self.assertIn("source policy waiver record is missing", output.getvalue())


if __name__ == "__main__":
    unittest.main()
