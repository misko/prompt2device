from pathlib import Path
import json,sys
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');D=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911');sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
paths={R/'skills/jlcpcb-fab/scripts/release_freshness_check.py':D/'release_freshness-before-locator.py',R/'skills/kicad-pcb/scripts/pre_route_review_check.py':D/'pre_route_review-before-locator.py'}
saved={p:p.read_bytes() for p in paths}
try:
 for p,old in paths.items():p.write_bytes(old.read_bytes())
 cmd=['/usr/bin/python3','-m','unittest','discover','-s','skills/jlcpcb-fab/scripts/tests','-p','test_assembly_locator.py','-v']
 r=run_stage({'id':'locator_owning_gate_red','work_class':'local','timeout_s':60},cmd,cwd=R,log_path=I/'locator-owning-gate-red.log',env={'PYTHONDONTWRITEBYTECODE':'1'},console_line_limit=4,console_tail_lines=3)
 (I/'locator-owning-gate-red-runtime.json').write_text(json.dumps({'argv':cmd,**r.to_mapping()},indent=2)+'\n')
 text=(I/'locator-owning-gate-red.log').read_text();assert r.returncode!=0 and 'FAILED (failures=2)' in text,text[-2500:]
 assert 'FAIL: test_freshness_composes_locator_failure' in text and 'FAIL: test_placement_review_composes_locator_failure' in text
finally:
 for p,b in saved.items():p.write_bytes(b)
print('PASS proof: both owning integration tests RED against actual pre-change gates; complete working bytes restored.')
