# Fresh engineering assessment — locator proposal, corrected captions, signed header side

- Subject: raw `1a189859005562215c1b99325e816d7a4e4c8c327be8139eb5e3d1363d169f8c`; semantic `feefe2c9145d1e4bb84aa7792df9d26200f9f4b403ef4d21247c971fb5e9f206`
- Review stage: `KICAD-PLACEMENT`; bounded diagnostic/source-proposal assessment
- Candidate PCB SHA-256: `9aa1c2c821a31129176a8b519b9a211d78dfc011adb997a64470c03d0726891f`
- Prior PCB SHA-256: `0d80ee923dbbae34995fa892e5fc2224b489e5d4afc1a03dc2a7836c44a31058`
- Overall engineering verdict: **INCOMPLETE for P4 adoption; P5 geometry PASS; signed-side proof CONDITIONALLY CLOSES the prior CAD-side evidence gap after owning regeneration**
- Order verdict: **DO-NOT-ORDER** (this review is neither routing nor release acceptance)

## A. Locator-based P4 proposal

**Engineering fitness: the static 25-page atlas/data are ACCEPTABLE as the evidence basis for exactly these 25 project-specific exceptions; the interactive HTML is DEFECTIVE on an unknown-reference transition. Current P4/adoption status: INCOMPLETE.**

I inspected a 25/25 page high-resolution contact sheet and detailed pages for the densest/repeated and power examples, including `C_VMID1_470N`, `R_IN6N`, and `R_PWR_TOP`. Each page names one full reference, exact value, MPN, LCSC code, top side, rotation, native X/Y, inverted CPL Y, whole-board orientation, a red target ring, numbered pads and pad-net names. The whole-board and local views make every target unambiguous even in the repeated channel cells. The instructions explicitly prohibit using the nearest displaced silk reference. I also inspected the supplied browser view for `R_PWR_TOP`: exact search selects the same body, presents the identity/pads, and clearly says the exception is unapproved.

Independent `pcbnew` extraction found **333/333** non-board-only native footprints and compared them with all **333/333** JSON records. Reference set, value, side, X/Y, rotation, F.Fab body envelope, and every pad number/net/envelope produced **0 mismatches**. Raw BOM hash `7469938f...` and CPL hash `f8f72dde...` match the hashes embedded in the proposal. The BOM has **51 grouped data rows / 300 expanded references**; CPL has **300 data rows**; the board has **33 manual-placement bodies**, totaling 333. All **25/25** proposed exceptions are top-side CPL entries whose coordinates, side and rotation match the native footprint anchor, and whose value/MPN/LCSC identity matches the BOM; each exact MPN has a supplied `02_parts/<MPN>/part.yaml`. This is stronger identification evidence than displaced reference text in these dense regions. The existing 149 nearest-centroid degradation flags do not make these locator selections ambiguous because selection is tied to the target body and its pad pattern, not to a neighboring silk centroid.

The HTML `select(ref)` error path sets `No exact reference match` and returns before clearing the existing `.selected` class, crosshair, reference heading, details, or pad table. After selecting a valid part and entering an unknown reference, the invalid query and error coexist with the previous part's highlight and identity. That is a concrete wrong-part ambiguity in a service locator. The smallest source fix is to clear every selected body, the crosshair, heading, details and pad table before returning false (and clear or neutralize the hash); a RED transition test must select a valid ref, then an unknown ref, and assert error present plus zero retained selection/identity. The static PDF/PNG pages do not have this defect.

The proposal also does not yet satisfy P4 because it is expressly a review draft, `refdes_waiver.json` is only a 25-name list, and no adopted, source-owned, release-shipped waiver/gate is present. I do not reject it for exceeding nine: `MACHINE_UNBACKED_CEILING=9` governs machine omissions lacking project evidence, while M4/P4 allows evidenced project exceptions.

Minimum implementation contract before P4 may pass:

1. Author a project-side waiver record whose exception set is exactly the 25 references. Each record must bind the full reference, rationale for assembly/service identification, owner, side, native X/Y/rotation, value/MPN/LCSC, pad/net identity, exact PCB/BOM/CPL hashes, and the locator artifact/manifest hashes.
2. Generate HTML, JSON and the 25-page PDF/PNG atlas from the final release PCB and final release BOM/CPL. Ship them in the same immutable release bundle; do not accept a detached label experiment or an artifact copied from another board.
3. Gate set equality: native-hidden refs = authored waiver refs = locator-hidden refs = atlas page refs, with exactly one page/record per ref, no duplicates, and 333/333 JSON-to-native identity/geometry coverage. Preserve the existing text size, clearance and machine-unbacked ceiling.
4. Gate content hashes and release identity. Any board/BOM/CPL change must stale the exception evidence until regeneration and re-review.
5. Repair the HTML unknown-reference transition so no prior selection or identity survives an error. Add a RED UI control for valid-to-unknown selection, plus artifact/gate controls that reject a stale board hash, stale BOM/MPN, stale CPL coordinate/side/rotation, missing ref/page, wrong ref, duplicate ref/page, extra hidden ref, HTML/JSON/PDF disagreement, and corrupt or missing release manifest member. Demonstrate the controls fail before relying on the gate.

No further PCB source relocation is necessary if the HTML defect and that contract are implemented and independently accepted. Until then P4 remains unresolved.

## B. P5 corrected source-native channel captions

**Verdict: PASS for the exact candidate geometry.**

Independent comparison reopened both boards and found **340 vs 340 footprints** with **0 footprint/pad/model projection differences**. Exactly seven captions moved: north `CH1` `(36,28)->(37,34)`, `CH2` `(68,28)->(69,34)`, `CH4` `(132,28)->(133,34)`; south `CH5..CH8` from y=112 to y=106 at x=36/68/100/132. `CH3` remains `(100,34)`.

All eight native caption boxes measure 2.350 x 1.2753 mm. The supplied independent geometry result reports **0.000 mm² caption/body overlap**, no text-text overlaps, and correct nearest connector for **8/8**; ownership leads remain 13.708–31.623 mm. I inspected an independently rendered 3600x2400 native top view of the exact candidate: all eight captions are readable in clear strips between each connector and its channel components. The prior populated native view confirms why the old north/south positions disappeared under the connector bodies. A separate west-edge probe found **0 mm²** bounding-box overlap among `K`, `J9: 12V ISOLATED INPUT; NO HOT PLUG`, and `CROW AUDIO CARRIER v1 FIRST ARTICLE / DO NOT ORDER`; I do not reproduce an introduced west-text collision.

The corrected final-rule DRC records **0 violations, 499 unconnected items, 0 schematic-parity issues**. Native CLI exit 5 is retained because the board is intentionally unrouted; this is placement-specific acceptance, not routing or release acceptance. The earlier 8-violation diagnostic was made before final rules and is not used to waive any geometry. Adopt P5 only by regenerating from the owning source and reproducing the exact geometry/hash or rerunning these checks on the resulting board.

## C. Samtec J10/J11 signed-side proof

**Verdict: CONDITIONALLY CLOSES the previously missing CAD-side proof after `mount_side: front` is authored and the owning registration is freshly regenerated.**

I inspected both orthogonal native side profiles. The black insulator and mating posts are above the board plane; through-hole tails extend below it. The native top overlays show the model within F.Fab/F.CrtYd and the drilled field aligned for both headers. The receipt grades **12/12 drilled centres for J10 and 12/12 for J11**, centre deltas **0.021089 mm / 0.000178 mm**, zero measured F.Fab/courtyard excess, and measured front-side fraction **0.830808**, above the existing **0.750** threshold. The exact model SHA-256 is `3a9f0dd56986b0a8b9fa5229f8fcd12451cb9b857a472bb36f87992f8f086737`.

The diagnostic is bound to prior PCB `0d80...`, while the independent comparison proves the candidate has identical footprint/pad/model projections. The remaining action is source ownership: commit `mount_side: front`, regenerate the receipt against the owning current board, and preserve the same model/footprint/transform tuple. This proof does not qualify installed fit, mating-harness orientation, connector orderability, or the overall order.

## Evidence limits

This review covers locator identity/service clarity, source-native caption geometry, and J10/J11 CAD-side orientation. It does not accept routing, electrical closure, full release packaging, installed mechanical fit, harness mating, supplier allocation, or ordering. Delivery completeness is independent of the engineering verdict.
