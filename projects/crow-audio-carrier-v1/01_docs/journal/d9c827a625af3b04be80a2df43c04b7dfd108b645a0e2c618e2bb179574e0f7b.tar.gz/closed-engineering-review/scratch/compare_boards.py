#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, sys
sys.dont_write_bytecode=True
import pcbnew
R=Path('/tmp/carrier-locator-engineering-review-9dzo4mat')
def fp_record(f):
    pads=[]
    for p in f.Pads():
        pads.append((p.GetNumber(),p.GetNetname(),p.GetPosition().x,p.GetPosition().y,p.GetSize().x,p.GetSize().y,p.GetDrillSize().x,p.GetDrillSize().y,p.GetLayerSet().FmtHex()))
    models=[]
    for m in f.Models():
        models.append((m.m_Filename,tuple(m.m_Offset),tuple(m.m_Scale),tuple(m.m_Rotation)))
    return {'position':(f.GetPosition().x,f.GetPosition().y),'orientation':f.GetOrientationDegrees(),'flipped':f.IsFlipped(),'pads':pads,'models':models}
def board_records(path):
    b=pcbnew.LoadBoard(str(path)); return b,{f.GetReference():fp_record(f) for f in b.GetFootprints()}
oldb,old=board_records(R/'prior/current.kicad_pcb'); newb,new=board_records(R/'project/04_kicad/crow_audio_carrier_v1.kicad_pcb')
diff={r:{'old':old.get(r),'new':new.get(r)} for r in sorted(set(old)|set(new)) if old.get(r)!=new.get(r)}
def captions(b):
    return sorted([{'text':g.GetText(),'x':g.GetPosition().x/1e6,'y':g.GetPosition().y/1e6,'layer':g.GetLayerName()} for g in b.GetDrawings() if g.GetClass()=='PCB_TEXT' and g.GetText().startswith('CH')],key=lambda x:x['text'])
o=captions(oldb); n=captions(newb)
res={'old_footprints':len(old),'new_footprints':len(new),'footprint_pad_model_projection_differences':diff,'old_captions':o,'new_captions':n,'caption_changes':[{'caption':a['text'],'old':[a['x'],a['y']],'new':[b['x'],b['y']]} for a,b in zip(o,n) if a!=b]}
(R/'06_build/task_runs/locator-engineering-review/scratch/board-comparison.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps({'old_footprints':len(old),'new_footprints':len(new),'projection_differences':len(diff),'caption_changes':len(res['caption_changes'])},indent=2))
