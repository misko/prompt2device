#!/usr/bin/env python3
from pathlib import Path
import csv, hashlib, json, shutil, sys
sys.dont_write_bytecode = True
import pcbnew
from PIL import Image, ImageDraw, ImageFont

ROOT=Path('/tmp/carrier-locator-engineering-review-9dzo4mat')
S=ROOT/'06_build/task_runs/locator-engineering-review/scratch'
SRC=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/current_assembly')
data=json.loads((ROOT/'locator-proposal/locator-data.json').read_text())
env=json.loads((ROOT/'06_build/task_runs/locator-engineering-review/envelope.json').read_text())
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

# Exact input packet verification and authorized added evidence copies.
iv=[]
for ent in env['input_packet']:
    p=ROOT/ent['path']; gotsha=sha(p); gotsize=p.stat().st_size
    iv.append({'path':ent['path'],'expected_sha256':ent['sha256'],'actual_sha256':gotsha,'expected_size':ent['size'],'actual_size':gotsize,'pass':gotsha==ent['sha256'] and gotsize==ent['size']})
assert all(x['pass'] for x in iv)
for name in ('bom.csv','cpl.csv'):
    shutil.copy2(SRC/name,S/name)

def bbox(o):
    q=o.GetBoundingBox(); return [q.GetLeft()/1e6,q.GetTop()/1e6,q.GetRight()/1e6,q.GetBottom()/1e6]
def union(qs): return [min(q[0] for q in qs),min(q[1] for q in qs),max(q[2] for q in qs),max(q[3] for q in qs)]
board=pcbnew.LoadBoard(str(ROOT/'project/04_kicad/crow_audio_carrier_v1.kicad_pcb'))
native={}
for f in board.GetFootprints():
    if f.GetAttributes() & pcbnew.FP_BOARD_ONLY: continue
    shapes=[bbox(g) for g in f.GraphicalItems() if g.GetClass()=='PCB_SHAPE' and g.GetLayer()==pcbnew.F_Fab]
    pads=[{'number':p.GetNumber(),'net':p.GetNetname(),'box':bbox(p)} for p in f.Pads()]
    native[f.GetReference()]={'ref':f.GetReference(),'value':f.GetValue(),'x':f.GetPosition().x/1e6,'y':f.GetPosition().y/1e6,'rotation':f.GetOrientationDegrees(),'side':'bottom' if f.IsFlipped() else 'top','body':union(shapes),'pads':pads}
assert len(native)==333

tol=1e-6; mismatches=[]
for p in data['parts']:
    n=native.get(p['ref'])
    if n is None: mismatches.append({'ref':p['ref'],'field':'missing_native'}); continue
    for k in ('value','side'):
        if p[k]!=n[k]: mismatches.append({'ref':p['ref'],'field':k,'json':p[k],'native':n[k]})
    for k in ('x','y','rotation'):
        if abs(float(p[k])-float(n[k]))>tol:mismatches.append({'ref':p['ref'],'field':k,'json':p[k],'native':n[k]})
    if len(p['body'])!=4 or max(abs(a-b) for a,b in zip(p['body'],n['body']))>tol:mismatches.append({'ref':p['ref'],'field':'body'})
    if p['pads']!=n['pads']: mismatches.append({'ref':p['ref'],'field':'pads'})
if set(native)!=set(x['ref'] for x in data['parts']): mismatches.append({'field':'reference_set'})

bom_rows=list(csv.DictReader((S/'bom.csv').open(encoding='utf-8-sig')))
bom={r:row for row in bom_rows for r in row['Designator'].split(',')}
cpl_rows=list(csv.DictReader((S/'cpl.csv').open(encoding='utf-8-sig'))); cpl={r['Designator']:r for r in cpl_rows}
hidden=[]
for ref in data['hidden']:
    p=next(x for x in data['parts'] if x['ref']==ref); br=bom[ref]; cr=cpl[ref]; n=native[ref]
    hidden.append({'ref':ref,'json_value':p['value'],'bom_value':br['Comment'],'json_mpn':p['mpn'],'bom_mpn':br['MPN'],'json_lcsc':p['lcsc'],'bom_lcsc':br['LCSC'],'native_x':n['x'],'native_y':n['y'],'cpl_x':float(cr['Mid X']),'cpl_inverted_y':float(cr['Mid Y']),'rotation_native':n['rotation'],'rotation_cpl':float(cr['Rotation']),'side_native':n['side'],'side_cpl':cr['Layer'],'part_yaml':f'project/02_parts/{br["MPN"]}/part.yaml','part_yaml_exists':(ROOT/f'project/02_parts/{br["MPN"]}/part.yaml').is_file(),'identity_pass':p['value']==br['Comment'] and p['mpn']==br['MPN'] and p['lcsc']==br['LCSC'] and abs(n['x']-float(cr['Mid X']))<tol and abs(n['y']+float(cr['Mid Y']))<tol and n['side']==cr['Layer'] and abs(n['rotation']-float(cr['Rotation']))<tol and (ROOT/f'project/02_parts/{br["MPN"]}/part.yaml').is_file()})
assert all(x['identity_pass'] for x in hidden)

# 5x5 overview with enough retained pixels to inspect every supplied page.
files=sorted((ROOT/'locator-proposal').glob('locator-[0-9][0-9]-*.png'))
assert len(files)==25
thumbs=[]
for p in files:
    im=Image.open(p).convert('RGB'); im.thumbnail((1200,800)); thumbs.append(im.copy())
sheet=Image.new('RGB',(6000,4000),'white')
for i,im in enumerate(thumbs): sheet.paste(im,((i%5)*1200,(i//5)*800))
sheet.save(S/'locator-contact-25.png')

# Independent geometry plot of all eight corrected captions and local footprints.
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'; fb='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
F=lambda n,b=False:ImageFont.truetype(fb if b else font,n)
im=Image.new('RGB',(3000,2000),'white'); d=ImageDraw.Draw(im)
sx,sy=18,18; X=lambda x:(x-15)*sx; Y=lambda y:(y-15)*sy
d.rectangle([X(20),Y(20),X(170),Y(120)],fill='#eef3ee',outline='#173e32',width=4)
for f in board.GetFootprints():
    q=bbox(f)
    if q[2]<20 or q[0]>170 or q[3]<20 or q[1]>120: continue
    d.rectangle([X(q[0]),Y(q[1]),X(q[2]),Y(q[3])],outline='#a0aaa3',width=1)
capt=[]
for g in board.GetDrawings():
    if g.GetClass()=='PCB_TEXT' and g.GetText() in {f'CH{i}' for i in range(1,9)}:
        q=bbox(g); t=g.GetText(); x=g.GetPosition().x/1e6; y=g.GetPosition().y/1e6
        d.rectangle([X(q[0]),Y(q[1]),X(q[2]),Y(q[3])],fill='#f8da65',outline='#8a6100',width=3)
        d.text((X(x),Y(y)),t,font=F(26,True),anchor='mm',fill='#161616')
        capt.append({'caption':t,'x':x,'y':y,'bbox':q})
d.text((50,30),'Corrected source-native caption positions (footprint envelopes in gray)',font=F(34,True),fill='#173e32')
im.save(S/'caption-geometry.png')

result={'input_verification':iv,'board_sha256':sha(ROOT/'project/04_kicad/crow_audio_carrier_v1.kicad_pcb'),'locator_board_sha256':data['board_sha256'],'native_assembly_count':len(native),'json_part_count':len(data['parts']),'native_json_mismatches':mismatches,'bom_sha256':sha(S/'bom.csv'),'cpl_sha256':sha(S/'cpl.csv'),'bom_data_rows':len(bom_rows),'bom_expanded_refs':len(bom),'cpl_data_rows':len(cpl_rows),'manual_placement_count':len(native)-len(cpl),'hidden_identity_checks':hidden,'captions':sorted(capt,key=lambda x:x['caption']),'locator_page_files':[p.name for p in files]}
(S/'audit-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'inputs':len(iv),'all_inputs_pass':all(x['pass'] for x in iv),'native_json_mismatches':len(mismatches),'hidden_identity_pass':sum(x['identity_pass'] for x in hidden),'locator_pages':len(files),'bom_rows':len(bom_rows),'bom_expanded_refs':len(bom),'cpl_rows':len(cpl_rows),'manual_count':len(native)-len(cpl)},indent=2))
