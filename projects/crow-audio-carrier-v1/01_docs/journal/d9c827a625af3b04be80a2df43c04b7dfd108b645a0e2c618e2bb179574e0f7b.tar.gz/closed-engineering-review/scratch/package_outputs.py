#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,tarfile,sys
from datetime import datetime,timezone
sys.dont_write_bytecode=True
R=Path('/tmp/carrier-locator-engineering-review-9dzo4mat'); S=R/'06_build/task_runs/locator-engineering-review/scratch'; O=R/'06_build/task_runs/locator-engineering-review/outputs'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=json.loads((R/'06_build/task_runs/locator-engineering-review/envelope.json').read_text()); audit=json.loads((S/'audit-results.json').read_text()); comp=json.loads((S/'board-comparison.json').read_text()); west=json.loads((S/'west-text-check.json').read_text()); html_check=json.loads((S/'html-unknown-ref-check.json').read_text()); receipt=json.loads((R/'samtec-signed-side-diagnosis/model_registration_receipt.json').read_text())
# Final frozen-packet verification, independently repeated after all inspection.
after=[]
for e in env['input_packet']:
    p=R/e['path']; a={'path':e['path'],'expected_sha256':e['sha256'],'actual_sha256':sha(p),'expected_size':e['size'],'actual_size':p.stat().st_size};a['pass']=a['expected_sha256']==a['actual_sha256'] and a['expected_size']==a['actual_size'];after.append(a)
assert len(after)==262 and all(x['pass'] for x in after)
commands=[]
for meta in sorted(S.glob('*-runtime.json'))+([S/'audit-runtime.json'] if (S/'audit-runtime.json').exists() else []):
    if meta.name=='audit-runtime.json' and any(c.get('runtime_record')==meta.name for c in commands): continue
    m=json.loads(meta.read_text()); m['runtime_record']=meta.name; log=S/meta.name.replace('-runtime.json','.log');m['raw_log']=log.name if log.exists() else None;commands.append(m)
commands.append({'command_record':'preflight-command.json','raw_failure':'preflight-failure.log','raw_success_before_final_repack':'preflight-success.log'})
evidence={
 'subject':env['subject'],
 'delivery_verdict':'PASS',
 'engineering_verdict':{'locator_p4_current':'INCOMPLETE','locator_static_atlas_and_data':'ACCEPTABLE_FOR_EXACT_25','locator_interactive_html':'DEFECTIVE_UNKNOWN_REF_RETAINS_PRIOR_SELECTION','p5_caption_geometry':'PASS','samtec_signed_side':'CONDITIONALLY_CLOSES_AFTER_OWNING_REGENERATION','order':'DO-NOT-ORDER'},
 'input_verification':{'before':audit['input_verification'],'after':after,'count':262,'all_pass':True,'added_read_only_inputs':[{'path':str(S/'bom.csv'),'sha256':audit['bom_sha256'],'size':(S/'bom.csv').stat().st_size},{'path':str(S/'cpl.csv'),'sha256':audit['cpl_sha256'],'size':(S/'cpl.csv').stat().st_size}]},
 'commands':commands,
 'actual_coverage':{'locator_pages_visually_inspected':25,'locator_pages_total':25,'json_parts_compared_to_native':333,'native_assembly_total':333,'native_json_mismatches':len(audit['native_json_mismatches']),'hidden_bom_cpl_yaml_checks_passed':sum(x['identity_pass'] for x in audit['hidden_identity_checks']),'hidden_total':25,'candidate_prior_footprints_compared':comp['new_footprints'],'footprint_pad_model_projection_differences':len(comp['footprint_pad_model_projection_differences']),'captions_inspected':8,'samtec_side_profiles_inspected':2,'samtec_overlays_inspected':3},
 'visual_inspection':[
   {'artifact':'scratch/locator-contact-25.png','detail':'original/resized by viewer only for display','finding':'25/25 pages present; every title, identity line, global map, target ring, numbered pads and exact-board hash visible.'},
   {'artifacts':['locator-proposal/locator-05-C_VMID1_470N.png','locator-proposal/locator-18-R_IN6N.png','locator-proposal/locator-21-R_PWR_TOP.png'],'finding':'Dense/repeated and power targets remain unambiguous from body/pad pattern plus coordinates.'},
   {'artifact':'locator-proposal/browser-r-pwr-top.png','finding':'Exact reference selection highlights R_PWR_TOP and exposes value/MPN/LCSC/side/rotation/pad nets; draft/unapproved state is explicit. Static source inspection finds the unknown-ref branch returns before clearing a previous highlight/details, creating a wrong-part ambiguity after valid-to-invalid input.'},
   {'artifact':'scratch/candidate-native-top.png','finding':'All CH1..CH8 captions visible in clear connector-to-channel strips on exact candidate native render.'},
   {'artifact':'prior/current-native-top.png','finding':'Old CH positions are obscured by populated edge connector bodies except CH3, corroborating the original defect.'},
   {'artifacts':['samtec-signed-side-diagnosis/native_side_front.png','samtec-signed-side-diagnosis/native_side_right.png'],'finding':'Insulator/posts are above board; through-hole tails extend below.'},
   {'artifacts':['samtec-signed-side-diagnosis/native_top_registration_overlay.png','samtec-signed-side-diagnosis/native_overlay_J10.png','samtec-signed-side-diagnosis/native_overlay_J11.png'],'finding':'Models align with F.Fab/F.CrtYd and 12 drilled centres per header.'}
 ],
 'measurements':{'locator':{'board_sha256':audit['board_sha256'],'parts':333,'bom_grouped_rows':audit['bom_data_rows'],'bom_expanded_refs':audit['bom_expanded_refs'],'cpl_rows':audit['cpl_data_rows'],'manual_parts':audit['manual_placement_count'],'hidden_exact_identity_checks':audit['hidden_identity_checks']},'html_unknown_ref_check':html_check,'caption_comparison':comp,'west_text_check':west,'samtec_receipt':receipt,'drc':{'final_rules':{'violations':0,'unconnected_items':499,'schematic_parity':0,'native_returncode':5},'pre_final_rules':{'violations':8,'unconnected_items':499,'schematic_parity':0,'used_for_acceptance':False}}},
 'required_p4_contract':['repair unknown-ref HTML path to clear selection/crosshair/identity/pads/hash and prove valid-to-invalid RED control','authored per-ref evidence with exact PCB/BOM/CPL and locator hashes','same immutable release package for HTML JSON PDF and atlas','native hidden set equals waiver set equals locator set; one record/page per ref','333/333 native-to-locator gate','stale/missing/wrong/duplicate/extra/hash-corrupt negative controls demonstrated RED','existing text floors, clearances and machine-unbacked ceiling unchanged'],
 'limits':['No routing, electrical, release, installed-fit, harness, allocation, or order acceptance.','P4 current state remains incomplete until contract implementation and independent acceptance.','J10/J11 diagnostic must be regenerated from authored mount_side: front in owning source.'],
 'completed_at':datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(O/'result.json').write_text(json.dumps({'subject':env['subject'],'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]},separators=(',',':'))+'\n')
# Archive every new scratch script, raw log, runtime record, copied input, and derived figure/result.
members=[]; archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
    for p in sorted(S.iterdir(),key=lambda x:x.name):
        if not p.is_file(): continue
        arc='scratch/'+p.name; tf.add(p,arcname=arc,recursive=False);members.append({'path':arc,'size':p.stat().st_size,'sha256':sha(p)})
manifest={'archive':{'path':'evidence.tar.gz','size':archive.stat().st_size,'sha256':sha(archive)},'members':members}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'inputs_after':len(after),'members':len(members),'archive_size':archive.stat().st_size,'archive_sha256':sha(archive)},indent=2))
