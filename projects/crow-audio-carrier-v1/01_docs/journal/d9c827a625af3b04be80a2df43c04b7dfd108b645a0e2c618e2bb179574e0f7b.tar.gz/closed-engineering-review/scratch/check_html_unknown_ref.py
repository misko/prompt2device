#!/usr/bin/env python3
from pathlib import Path
import json,re,sys
sys.dont_write_bytecode=True
p=Path('/tmp/carrier-locator-engineering-review-9dzo4mat/locator-proposal/assembly-locator.html');s=p.read_text()
m=re.search(r"function select\(ref\)\{(.*?)\}document\.querySelectorAll",s)
assert m
body=m.group(1); branch=re.search(r"if\(!p\)\{(.*?)\}",body).group(1)
state_tokens=['.selected','#cross','#ref','#details','#pads','location.hash']
cleared=[x for x in state_tokens if x in branch]
out={'function':'select(ref)','unknown_ref_branch':branch,'sets_error':"No exact reference match" in branch,'returns_false':'return false' in branch,'state_surfaces_expected_to_clear':state_tokens,'state_surfaces_cleared_in_branch':cleared,'retains_prior_selection_and_identity':len(cleared)==0,'verdict':'DEFECTIVE' if len(cleared)==0 else 'REVIEW'}
Path('/tmp/carrier-locator-engineering-review-9dzo4mat/06_build/task_runs/locator-engineering-review/scratch/html-unknown-ref-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
