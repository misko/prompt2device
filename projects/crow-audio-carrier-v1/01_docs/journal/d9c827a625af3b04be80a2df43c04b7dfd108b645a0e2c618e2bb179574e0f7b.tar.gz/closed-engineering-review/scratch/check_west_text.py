#!/usr/bin/env python3
from pathlib import Path
import json,sys
sys.dont_write_bytecode=True
import pcbnew
p=Path('/tmp/carrier-locator-engineering-review-9dzo4mat/project/04_kicad/crow_audio_carrier_v1.kicad_pcb')
b=pcbnew.LoadBoard(str(p)); wanted={'K','J9: 12V ISOLATED INPUT; NO HOT PLUG','CROW AUDIO CARRIER v1  FIRST ARTICLE / DO NOT ORDER'}
rows=[]
for g in b.GetDrawings():
    if g.GetClass()=='PCB_TEXT' and g.GetText() in wanted:
        q=g.GetBoundingBox(); rows.append({'text':g.GetText(),'box_mm':[q.GetLeft()/1e6,q.GetTop()/1e6,q.GetRight()/1e6,q.GetBottom()/1e6]})
def area(a,b): return max(0,min(a[2],b[2])-max(a[0],b[0]))*max(0,min(a[3],b[3])-max(a[1],b[1]))
over=[]
for i,a in enumerate(rows):
    for b in rows[i+1:]: over.append({'a':a['text'],'b':b['text'],'bbox_overlap_mm2':area(a['box_mm'],b['box_mm'])})
out={'texts':rows,'pair_overlaps':over}; q=Path('/tmp/carrier-locator-engineering-review-9dzo4mat/06_build/task_runs/locator-engineering-review/scratch/west-text-check.json');q.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
