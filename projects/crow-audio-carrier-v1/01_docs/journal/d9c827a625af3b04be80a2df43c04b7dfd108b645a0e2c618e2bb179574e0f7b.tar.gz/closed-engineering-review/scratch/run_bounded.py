#!/usr/bin/env python3
import json
import os
import sys
from pathlib import Path

sys.dont_write_bytecode = True
TOOLS = Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
sys.path.insert(0, str(TOOLS))
from pipeline_runtime import run_stage

if len(sys.argv) < 4:
    raise SystemExit('usage: run_bounded.py LOG META -- COMMAND...')
log = Path(sys.argv[1])
meta = Path(sys.argv[2])
if sys.argv[3] != '--':
    raise SystemExit('missing --')
cmd = sys.argv[4:]
spec = {'id': 'locator_review_native', 'work_class': 'local', 'timeout_s': 180.0, 'produces': []}
out = run_stage(spec, cmd, log_path=log, cwd='/tmp/carrier-locator-engineering-review-9dzo4mat', env=dict(os.environ), console=None)
meta.write_text(json.dumps({
    'argv': cmd,
    'cwd': '/tmp/carrier-locator-engineering-review-9dzo4mat',
    'returncode': out.returncode,
    'started_at': out.started_at,
    'finished_at': out.finished_at,
    'elapsed_s': out.elapsed_s,
    'status': out.status,
}, indent=2) + '\n')
raise SystemExit(out.returncode)
