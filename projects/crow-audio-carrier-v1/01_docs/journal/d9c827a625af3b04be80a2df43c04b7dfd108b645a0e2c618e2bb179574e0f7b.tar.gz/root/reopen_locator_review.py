from pathlib import Path
import json,hashlib,tarfile
D=Path('/tmp/carrier-locator-engineering-review-9dzo4mat');A=D/'06_build/task_runs/locator-engineering-review';sha=lambda b:hashlib.sha256(b).hexdigest();env=json.loads((A/'envelope.json').read_text())
for r in env['input_packet']:
 b=(D/r['path']).read_bytes();assert len(b)==r['size'] and sha(b)==r['sha256'],r['path']
m=json.loads((A/'outputs/evidence-manifest.json').read_text());ar=A/'outputs'/m['archive']['path'];assert ar.stat().st_size==m['archive']['size'] and sha(ar.read_bytes())==m['archive']['sha256']
with tarfile.open(ar) as t:
 assert set(t.getnames())=={r['path'] for r in m['members']}
 for r in m['members']:
  b=t.extractfile(r['path']).read();assert len(b)==r['size'] and sha(b)==r['sha256'],r['path']
result={'inputs':len(env['input_packet']),'archive_members':len(m['members']),'archive_sha256':m['archive']['sha256'],'delivery':json.loads((A/'outputs/result.json').read_text()),'engineering':'Static locator basis acceptable; unknown-ref HTML defective; P4 incomplete; P5 PASS; side conditional on owning regeneration'}
Path('/tmp/carrier-placement-review-20260911/locator-review-reopening.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
