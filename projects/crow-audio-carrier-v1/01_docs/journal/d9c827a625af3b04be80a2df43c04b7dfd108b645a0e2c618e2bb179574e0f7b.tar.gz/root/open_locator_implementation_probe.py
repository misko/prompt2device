from pathlib import Path
from datetime import datetime,timezone,timedelta
import sys,json,hashlib,tempfile,shutil
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');D=Path(tempfile.mkdtemp(prefix='carrier-locator-implementation-availability-'));sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
name='locator-implementation-availability';ep=D/f'06_build/task_runs/{name}/envelope.json';(D/'challenge.txt').write_text('Fresh review availability requires complete correctly located delivery.\n');shutil.copyfile('/tmp/carrier-keying-source-review-27x1olqz/preflight.py',D/'preflight.py')
(D/'producer.py').write_text(f'''from pathlib import Path
import json,hashlib
D=Path({str(D)!r});E=Path({str(ep)!r});e=json.loads(E.read_text());i=next(x for x in e['input_packet'] if x['path']=='challenge.txt');b=(D/'challenge.txt').read_bytes();assert len(b)==i['size'] and hashlib.sha256(b).hexdigest()==i['sha256'];O=E.parent/'outputs';assert O.is_dir();(O/'report.md').write_text('Read '+repr(b.decode())+'; verified '+str(len(b))+' bytes SHA256 '+hashlib.sha256(b).hexdigest()+'.\\n');(O/'result.json').write_text(json.dumps({{'subject':e['subject'],'checks':{{'challenge-read':'PASS'}},'unresolved':[]}},indent=2)+'\\n');print(str(O))
''')
now=datetime.now(timezone.utc);hard=now+timedelta(minutes=4);items=[]
for p in sorted(D.iterdir()):b=p.read_bytes();items.append({'name':p.stem.replace('-','_'),'path':p.name,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
s=subject_identity('live_review_probe',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())]);e=TaskEnvelope(schema=2,task_id=name,stage_id='KICAD-PLACEMENT',run_id=name,subject=s,executor='agent',execution_class='review_wait',recommended_agent_role='judgment',agent_role='judgment',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['report.md'],'checks':['challenge-read']})
o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(ep),agent_id='/root/carrier_locator_implementation_availability',producer=str(D/'producer.py'),preflight=str(D/'preflight.py'));Path('/tmp/carrier-locator-implementation-availability-opened.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2))
