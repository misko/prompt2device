from pathlib import Path
from datetime import datetime,timezone
import hashlib,tarfile,io,json,shutil,subprocess
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911');files={};sha=lambda b:hashlib.sha256(b).hexdigest()
def tree(root,prefix):
 for f in sorted(root.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':files[prefix+'/'+f.relative_to(root).as_posix()]=f
# Prior immutable input packet is already in archive 2b632c...; retain actual final receipt and complete original handback here.
A=Path('/tmp/carrier-locator-engineering-review-9dzo4mat/06_build/task_runs/locator-engineering-review');tree(A,'closed-engineering-review')
tree(Path('/tmp/carrier-locator-implementation-availability-6c_4vwal'),'closed-implementation-availability')
for f in I.glob('locator-*'):
 if f.is_file():files['logs/'+f.name]=f
for prefix in ['source-owned-locator','caption-locator']:
 for f in I.glob(prefix+'*'):
  if f.is_file():files['logs/'+f.name]=f
for n in ['run.py']:
 files['logs/'+n]=I/n
for n in ['reopen_locator_review.py','locator-review-reopening.json','verify_locator_integration_red.py','open_locator_implementation_probe.py','locator-implementation-availability-opened.json','commission_locator_implementation_review.py','locator-implementation-review-opened.json','owned-locator-browser.png','preserve_locator_implementation_checkpoint.py']:
 files['root/'+n]=D/n
for rel in subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines():
 f=R/rel
 if f.is_file():files['source/'+rel]=f
j=json.loads((D/'locator-implementation-review-opened.json').read_text())[0];root=Path(j['project']);env=json.loads(Path(j['envelope']).read_text())
for row in env['input_packet']:files['implementation-review-inputs/'+row['path']]=root/row['path']
files['implementation-review-inputs/envelope.json']=Path(j['envelope'])
m={n:{'size':f.stat().st_size,'sha256':sha(f.read_bytes())} for n,f in sorted(files.items())};tmp=D/'locator-implementation-checkpoint.tar.gz'
with tarfile.open(tmp,'w:gz',compresslevel=3) as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 b=(json.dumps({'members':m},indent=2)+'\n').encode();z=tarfile.TarInfo('MANIFEST.json');z.size=len(b);t.addfile(z,io.BytesIO(b))
h=sha(tmp.read_bytes());out=P/'01_docs/journal'/(h+'.tar.gz');assert not out.exists();shutil.copyfile(tmp,out)
with tarfile.open(out) as t:
 assert set(t.getnames())==set(m)|{'MANIFEST.json'}
 for n,row in m.items():b=t.extractfile(n).read();assert len(b)==row['size'] and sha(b)==row['sha256'],n
result={'archive':str(out),'sha256':h,'size':out.stat().st_size,'payload_members':len(m),'all_reopened':True,'time':datetime.now(timezone.utc).isoformat()};(D/'locator-implementation-preservation-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
