from pathlib import Path
import hashlib,json
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
changes={}
def edit(rel,pairs):
 p=R/rel;b=p.read_bytes();s=b.decode()
 for old,new in pairs:
  assert old in s,old;s=s.replace(old,new)
 changes[rel]=(b,s.encode())
edit('projects/crow-audio-carrier-v1/01_docs/ARCHITECTURE.md',[
 ('D_TVS_IN shunt clamp','D_IN shunt clamp'),('F_PORT1..F_PORT8','F1..F8'),
 ('order-blocking first-article hold','first-article qualification hold')])
edit('projects/crow-mic-pod-v3/01_docs/BRIEF.md',[
 ('installed array uses nominal 4 m spokes for an 8 m diameter; the same electrical\ndesign is evaluated at a 15 m boundary without claiming that distance qualified', 'array has a nominal 4 m acoustic radius / 8 m diameter; the selected complete\ncord is 15 m, without claiming that cable distance qualified'),
 ('One four-position spoke connector per pod','One shielded 8P8C RJ45 spoke jack (eight signal contacts plus two shell pads) per pod'),
 ('exact 4 m installed harness and 15 m boundary harness are separate system fixtures, not included in the bare-PCB claim.','the exact selected 15 m factory cord is a separate system fixture, not included in the bare-PCB claim; any shorter cord needs its own adopted identity.'),
 ('Freeze one straight-through four-wire active-analog spoke interface and exact harness family.','Original four-wire interface decision; connector/cable choices superseded by ADR0007, analog/power function retained.'),
 ('Keep all source/release artifacts non-orderable until physical and first-article holds close.','Separate prototype design and authorized ordering from subsequent physical qualification; current artifacts remain DO-NOT-ORDER.'),
 ('| 0006 | Permit design-only continuation', '| 0007 | Adopt exact factory RJ45 analog/power spokes and isolated shield island; physical qualification remains owed. | user D6 / independent source review | [RJ45 ADR](decisions/0007-rj45-factory-spoke.md) |\n| 0006 | Permit design-only continuation'),
 ('| [0001](decisions/0001-four-wire-analog-spoke.md) | yes — first-article hold |','| [0007](decisions/0007-rj45-factory-spoke.md) | yes — first-article hold |')])
edit('projects/crow-mic-pod-v3/01_docs/FIRST_ARTICLE_TEST_PLAN.md',[
 ('capsule, 4 m and 15 m Belden harnesses, carrier','capsule, exact Weidmüller 8909650150 factory 15 m cord, carrier'),
 ('J1 pin 1=`12V_POD`, 2=`GND`, 3=`AUDIO_P`, 4=`AUDIO_N` end to end.','J1 pins 1/3/7=`12V_POD`, 2/6/8=`GND`, 5=`AUDIO_P`,\n      4=`AUDIO_N` end to end. Shell pads 9/10 join POD_SHIELD, isolated from GND.'),
 ('With the exact 4 m harness, measure gain, phase, common mode, noise,','With the exact selected 15 m factory cord, measure gain, phase, common mode, noise,'),
 ('Repeat the complete matrix with the exact 15 m boundary harness. The\n      15 m value remains an unqualified design boundary until this passes.','Any shorter installed cord requires its own exact-source adoption and\n      complete measurement matrix. A 4 m acoustic radius does not select a\n      cable SKU. The 15 m design boundary is unqualified until measurements pass.'),
 ('approved shield/drain termination.','approved continuous cord shield and isolated POD_SHIELD termination.'),
 ('For the proposed Würth615008160221 jack','For the source-adopted Würth615008160221 jack')])
edit('projects/crow-audio-carrier-v1/01_docs/FIRST_ARTICLE_TEST_PLAN.md',[
 ('Repeat the steady-state rail/current observations at 12.0 V and 13.2 V,\n   removing power and rechecking resistance after any abnormal result.','Repeat the steady-state rail/current observations at 12.0 V, removing power\n   and rechecking resistance after any abnormal result. The present card limits\n   several probe rows to 12.0 V input. The required 13.2 V functional corner\n   needs a reviewed card/procedure update before that test; do not exceed the\n   current card or copy a 12.0 V result into the 13.2 V acceptance row.'),
 ('For the proposed Würth615008160221 jack','For the source-adopted Würth615008160221 jack')])
out=N/'final-doc-payload';assert not out.exists();out.mkdir();rows=[]
for rel,(b,v) in changes.items():
 for phase,data in [('before',b),('after',v)]:
  p=out/phase/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 assert (R/rel).read_bytes()==b
 rows.append({'path':rel,'old_sha256':hashlib.sha256(b).hexdigest(),'new_sha256':hashlib.sha256(v).hexdigest()})
for rel,(b,v) in changes.items():(R/rel).write_bytes(v)
(N/'final-doc-applied.json').write_text(json.dumps(rows,indent=2)+'\n');print('Applied',len(rows),'document-only files; no electrical or presentation source change.')
