# SOUND bounded source proposal; ROOT acceptance still owed

The proposed five-file correction is complete and passes **61 source regression
methods**:23 maintained route-contract methods and38 focused ADC feed/source,
electrical-invariant, thermal and safe-ground methods. This authoring verdict
applies to the exact postimages. The frozen prior source remains DEFECTIVE;
ROOT owns adoption and independent exact-source/native acceptance.

The floorplan changes only `ADC_WEST_LOCAL.rect[0]`,89.5→89.35. All other
floorplan fields, including the independently adopted ADC2 union and all82
other areas, are exact. Both nets.yaml width and paired-clearance rationales
are appended; their previous text, exact net sets and numeric floors remain.
The stackup postimage is byte-identical to the independently reviewed partial
CHASSIS mapping. ADR0030 is append-only. All20 supplied partial test methods
and all its existing helper functions remain unchanged; three maintained
methods and independent pure-source helpers are added. `minimal.diff`,
`postimages.json`, and `source-invariance.json` make this reviewable. Exact
postimages are under `after/projects/crow-audio-carrier-v1/` in the archive.

The maintained checker recursively walks the whole route document, deriving
216 point specifications /391 straight primitives from154 banks. It rejects
non-seed point geometry and arcs instead of silently excluding them. GND has
35 banks/67 primitives. Exact owner/spec/primitive/endpoints/net/layer/width
identity is pinned for all20 sub0.30mm GND primitives:17 at0.18mm,3 at0.20mm,
10 banks/10 specifications and15.509834613921mm total length. Every full round
capsule must fit an eligible exact-net/layer rectangle at an appropriate width
floor. Ordinary GND and three fallback settings remain0.30mm. The immutable
source route and all source via settings are unchanged.

Actual maintained **RED** used the exact prior floorplan SHA-256
`0fd6d3e0f7c138f1dcfe49fc994fb66c676a46e1616b6a2e5b04c13c6e7b69cc`:
23 methods ran,21 passed,2 failed methods produced3 failure records. The new
complete-capsule method identified exactly C_VMID1_470N.2 specification1
primitives0/1; the unchanged original method also failed its two endpoint
subtests. Actual composed **GREEN** ran the same23 methods with zero failures.
The separate original partial proposal remains historically **INCOMPLETE**:
19 of20 methods passed, with two failed subtests in the remaining method.
Its archived report and raw evidence are retained, not upgraded retrospectively.

Hostile controls retain the old scope, centers-inside/radius-outside escape,
wrong layer/deny/net permission, inappropriate minimum width and a remote
ADC30 escaped endpoint. Every narrow specification is subjected to endpoint
removal; whole-population empty/missing, wrong net/layer, ordinary-width
replacement, unrelated owner, non-seed point and arc insertion, and each
underfloor fallback are rejected. Existing CHASSIS, duplicate ownership,
reference-plane, current/width, via and geometric controls still pass.

The focused38-method run preserves the adopted ADC2 pad-clearance union,
ADC supply and independent ground drops, electrical invariants,11 thermal
plus43 seed vias, minimum2resolved spokes and32exactfull-ground targets.
All five safe ground-source methods run. The sixth ground method constructs
a BOARD and was explicitly excluded from this source-only task. The runner
guards BOARD/LoadBoard/SaveBoard, and no forbidden board-producing operation
was called. Isolated native library footprint geometry remains source evidence,
not a constructed candidate or filled-board proof.

The independent decision report SHA-256 is
`e4e6feb60f65c9bc0ef25c5aea1d891cd1c77bfc4db3d5b224268855f3baad8b`;
its archive is `1345f8f0cc3f631282ea19e6530d02cdd8459be238cc0ab7fbf6c0481052c097`.
It supports the precise rectangle and its0.01mm source margin. Both width0.18mm
and paired-clearance0.20mm geography expand for the same three nets. The
reviewed current memberships remain26 width tracks and1290 distinct-net
clearance pairs; those are predicate counts, not fresh clearance acceptance.
The changed area is0.6975mm² and future geographic permission is explicitly
larger. No thermal, current, manufacturing or native DRC qualification follows.

All501 frozen input hashes/sizes were verified before and after. All479 copied
project/shared inputs were compared; exactly the five owning files differ.
Actual git-show historical controls use explicit real GIT_DIR and scratch
GIT_WORK_TREE; their exact specs/hashes/bytes are archived. Finite shared
run_stage invocations use default console output and retain raw logs/runtime.
One preliminary inspection failed with KeyError because fallback settings
were queried under route instead of stitch. The failed script/log and corrected
successful inspection are retained; there were no missing dependencies or
unresolved test failures. The expected RED is engineering evidence, not a
setup error. Engineering run timings are in command-contexts.json and each
runtime JSON; route RED6.924s, route GREEN7.231s, focused35.646s.

No live/frozen writes, children, commits, board construction/load/save,
generation, fill, DRC, prep or routing occurred. Candidate5 is not admitted by
this handback. ROOT must perform exact composed source preflight and subsequent
independent exact source/native acceptance under any separately admitted
single candidate. Four prior native outcomes remain spent; no sixth trial is
authorized. All thermal/return-cut/assembly/orientation/order/release holds
remain. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.

Delivery PASS means the honest complete authoring package, not native or final
engineering acceptance. No source-authoring defect is left unresolved in these
postimages; wider qualification obligations remain with their owning gates.
