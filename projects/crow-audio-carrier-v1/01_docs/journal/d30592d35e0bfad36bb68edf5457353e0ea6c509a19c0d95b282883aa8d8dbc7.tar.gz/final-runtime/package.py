from pathlib import Path,PurePosixPath
import hashlib,json,tarfile,shutil,datetime
S=Path(__file__).resolve().parent;F=S.parents[3];O=S.parent/'outputs';O.mkdir(exist_ok=True)
def h(b):return hashlib.sha256(b).hexdigest()
def record(p):b=p.read_bytes();return dict(sha256=h(b),size=len(b))
e=json.loads((S.parent/'envelope.json').read_text());rows=[]
for r in e['input_packet']:
 p=F/r['path'];got=record(p);assert got==dict(sha256=r['sha256'],size=r['size']),r['path'];rows.append(dict(path=r['path'],**got))
assert len(rows)==501
(S/'inputs-after.json').write_text(json.dumps(rows,indent=2))
assert rows==json.loads((S/'inputs-before.json').read_text())
for name in ['route-green','focused']:
 t=json.loads((S/(name+'.tests.json')).read_text());assert t['success'] and not t['failures'] and not t['errors']
red=json.loads((S/'route-red.tests.json').read_text());assert red['tests_run']==23 and len(red['failures'])==3 and red['errors']==[]
postimages=json.loads((S/'postimages.json').read_text());assert len(postimages)==5
# Include independent decision and actual historical partial delivery unchanged.
D=S/'review-inputs'
for rel in ['TASK.md','current-handoff/STATUS.md','current-handoff/adc2-adoption.json','decision-closeout.json','decision/report.md','decision/evidence.json','decision/evidence-manifest.json','decision/result.json','partial-proposal/delivery/report.md','partial-proposal/delivery/evidence.json','partial-proposal/delivery/evidence-manifest.json','partial-proposal/delivery/result.json','partial-proposal/source-analysis.json','canon/kicad-rule-area-semantics.md','canon/testing.md','canon/CLAUDE.md']:
 t=D/rel;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(F/rel,t)
shutil.copy2(S.parent/'envelope.json',D/'envelope.json')
# Retain all original partial author scripts/logs without nested archives.
with tarfile.open(F/'partial-proposal/delivery/evidence.tar.gz','r:gz') as tf:
 for m in tf.getmembers():
  if not m.isfile():continue
  p=PurePosixPath(m.name);assert not p.is_absolute() and '..' not in p.parts
  if str(p).endswith(('.py','.log','.json','.md','.diff')):
   t=D/'partial-raw'/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(tf.extractfile(m).read())
counts=dict(frozen_inputs=501,copied_project_shared_inputs=479,changed_files=5,route_methods=23,route_green_pass=23,route_red_failed_methods=2,route_red_failure_records=3,focused_methods=38,focused_pass=38,total_green_methods=61,seed_banks=154,point_specifications=216,source_primitives=391,gnd_banks=35,gnd_primitives=67,narrow_gnd_banks=10,narrow_gnd_specs=10,narrow_gnd_primitives=20,narrow_018=17,narrow_020=3,prior_covered=18,proposed_covered=20,source_vias=54,seed_vias=43,thermal_vias=11,full_ground_targets=32,source_areas=83,width_scopes=42,clearance_scopes=33)
verdict=dict(verdict='SOUND',subject=e['subject'],scope='Bounded five-file proposed source remedy only; original frozen source remains DEFECTIVE until ROOT adoption. Not independent/native acceptance.',methods=['SHA-256 and size verification of all501 frozen inputs before and after','Exact reviewed partial two-file composition with all20 original methods/functions unchanged','Recursive entire-route point census and exact identities; analytic full-radius capsule rectangle containment for all20 sub0.30mm GND primitives','Actual23-method RED on exact prior floorplan and23-method GREEN on proposed composed files','Actual38 focused ADC/feed/source/invariant/thermal/safe-ground tests with BOARD/LoadBoard/SaveBoard guarded','Five-file byte/semantic invariance proof, exact immutable historical control blobs, full archive reopening and envelope delivery preflight'],findings=[dict(id='SOURCE-REMEDY',status='SOUND',detail='Only ADC_WEST_LOCAL xmin89.5→89.35; unchanged routes/ADC2/reservations/floors. Both rule rationales and ADR0030 acknowledge width and paired-clearance geography, unchanged present membership and0.01mm source slack.'),dict(id='PRIOR-SOURCE',status='DEFECTIVE',detail='Exactly two prior full capsules outside scope by0.14mm; retained actual RED. No assertion of native width DRC failure.'),dict(id='PARTIAL-HISTORY',status='INCOMPLETE',detail='Independent original partial20methods:19PASS,one failed method/two endpoint subtests. Preserved without relabeling.'),dict(id='SETUP-FAIL',status='RESOLVED',detail='Inspection script queried fallback settings under route rather than stitch, raised KeyError; exact failed script/log retained and corrected. No dependency absent.'),dict(id='ADOPTION-NATIVE',status='OUTSIDE_SCOPE',detail='Root source preflight and independent source/native acceptance owed; candidate5 not admitted by this task. Four prior candidates remain spent; no candidate6 or routing pilot.')],measured_counts=counts,narrow_gnd_total_length_mm=15.509834613921,independent_decision=dict(report=record(F/'decision/report.md'),archive=record(F/'decision/evidence.tar.gz')),postimages=postimages,limitations=['Source declarations and isolated library native geometry only; no PCB construction/load/save/generation/fill/DRC/prep/router','The sixth ground test constructs a BOARD and was explicitly excluded; all five safe ground tests passed, including32sourcefulltargets','Current native thermal/return-cut/assembly/orientation/order/release holds remain; FIRST-ARTICLE-ONLY/DO-NOT-ORDER','26 eligible width tracks and1290 eligible clearance pairs are independently reviewed predicate membership counts, not new native clearance acceptance'])
(O/'evidence.json').write_text(json.dumps(verdict,indent=2))
report='''# SOUND bounded source proposal; ROOT acceptance still owed

The proposed five-file correction is complete and passes **61 source regression
methods**:23 maintained route-contract methods and38 focused ADC feed/source,
electrical-invariant, thermal and safe-ground methods. This authoring verdict
applies to the exact postimages. The frozen prior source remains DEFECTIVE;
ROOT owns adoption and independent exact-source/native acceptance.

The floorplan changes only `ADC_WEST_LOCAL.rect[0]`,89.5→89.35. All other
floorplan fields, including the independently adopted ADC2 union and all82
other areas, are exact. Both nets.yaml width and paired-clearance rationales
are appended; their previous text, exact net sets and numeric floors remain.
The stackup postimage is byte-identical to the independently reviewed partial
CHASSIS mapping. ADR0030 is append-only. All20 supplied partial test methods
and all its existing helper functions remain unchanged; three maintained
methods and independent pure-source helpers are added. `minimal.diff`,
`postimages.json`, and `source-invariance.json` make this reviewable. Exact
postimages are under `after/projects/crow-audio-carrier-v1/` in the archive.

The maintained checker recursively walks the whole route document, deriving
216 point specifications /391 straight primitives from154 banks. It rejects
non-seed point geometry and arcs instead of silently excluding them. GND has
35 banks/67 primitives. Exact owner/spec/primitive/endpoints/net/layer/width
identity is pinned for all20 sub0.30mm GND primitives:17 at0.18mm,3 at0.20mm,
10 banks/10 specifications and15.509834613921mm total length. Every full round
capsule must fit an eligible exact-net/layer rectangle at an appropriate width
floor. Ordinary GND and three fallback settings remain0.30mm. The immutable
source route and all source via settings are unchanged.

Actual maintained **RED** used the exact prior floorplan SHA-256
`0fd6d3e0f7c138f1dcfe49fc994fb66c676a46e1616b6a2e5b04c13c6e7b69cc`:
23 methods ran,21 passed,2 failed methods produced3 failure records. The new
complete-capsule method identified exactly C_VMID1_470N.2 specification1
primitives0/1; the unchanged original method also failed its two endpoint
subtests. Actual composed **GREEN** ran the same23 methods with zero failures.
The separate original partial proposal remains historically **INCOMPLETE**:
19 of20 methods passed, with two failed subtests in the remaining method.
Its archived report and raw evidence are retained, not upgraded retrospectively.

Hostile controls retain the old scope, centers-inside/radius-outside escape,
wrong layer/deny/net permission, inappropriate minimum width and a remote
ADC30 escaped endpoint. Every narrow specification is subjected to endpoint
removal; whole-population empty/missing, wrong net/layer, ordinary-width
replacement, unrelated owner, non-seed point and arc insertion, and each
underfloor fallback are rejected. Existing CHASSIS, duplicate ownership,
reference-plane, current/width, via and geometric controls still pass.

The focused38-method run preserves the adopted ADC2 pad-clearance union,
ADC supply and independent ground drops, electrical invariants,11 thermal
plus43 seed vias, minimum2resolved spokes and32exactfull-ground targets.
All five safe ground-source methods run. The sixth ground method constructs
a BOARD and was explicitly excluded from this source-only task. The runner
guards BOARD/LoadBoard/SaveBoard, and no forbidden board-producing operation
was called. Isolated native library footprint geometry remains source evidence,
not a constructed candidate or filled-board proof.

The independent decision report SHA-256 is
`e4e6feb60f65c9bc0ef25c5aea1d891cd1c77bfc4db3d5b224268855f3baad8b`;
its archive is `1345f8f0cc3f631282ea19e6530d02cdd8459be238cc0ab7fbf6c0481052c097`.
It supports the precise rectangle and its0.01mm source margin. Both width0.18mm
and paired-clearance0.20mm geography expand for the same three nets. The
reviewed current memberships remain26 width tracks and1290 distinct-net
clearance pairs; those are predicate counts, not fresh clearance acceptance.
The changed area is0.6975mm² and future geographic permission is explicitly
larger. No thermal, current, manufacturing or native DRC qualification follows.

All501 frozen input hashes/sizes were verified before and after. All479 copied
project/shared inputs were compared; exactly the five owning files differ.
Actual git-show historical controls use explicit real GIT_DIR and scratch
GIT_WORK_TREE; their exact specs/hashes/bytes are archived. Finite shared
run_stage invocations use default console output and retain raw logs/runtime.
One preliminary inspection failed with KeyError because fallback settings
were queried under route instead of stitch. The failed script/log and corrected
successful inspection are retained; there were no missing dependencies or
unresolved test failures. The expected RED is engineering evidence, not a
setup error. Engineering run timings are in command-contexts.json and each
runtime JSON; route RED6.924s, route GREEN7.231s, focused35.646s.

No live/frozen writes, children, commits, board construction/load/save,
generation, fill, DRC, prep or routing occurred. Candidate5 is not admitted by
this handback. ROOT must perform exact composed source preflight and subsequent
independent exact source/native acceptance under any separately admitted
single candidate. Four prior native outcomes remain spent; no sixth trial is
authorized. All thermal/return-cut/assembly/orientation/order/release holds
remain. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.

Delivery PASS means the honest complete authoring package, not native or final
engineering acceptance. No source-authoring defect is left unresolved in these
postimages; wider qualification obligations remain with their owning gates.
'''
(O/'report.md').write_text(report)
(O/'result.json').write_text(json.dumps(dict(subject=e['subject'],checks={k:'PASS' for k in e['completion']['checks']},unresolved=[]),indent=2))
# Finite engineering evidence is complete before this delivery operation.
# Archive no nested archive, output directory, symlink or own archive.
members=[]
with tarfile.open(O/'evidence.tar.gz','w:gz') as tf:
 for p in sorted(S.rglob('*')):
  if not p.is_file() or p.suffixes[-2:]==['.tar','.gz']:continue
  if p.is_symlink():raise AssertionError(p)
  if p.name in ['package.log','package.runtime.json']:continue
  rel=p.relative_to(S).as_posix();assert not PurePosixPath(rel).is_absolute() and '..' not in PurePosixPath(rel).parts
  tf.add(p,arcname=rel,recursive=False);members.append(dict(path=rel,**record(p)))
 for name in ['report.md','evidence.json','result.json']:
  p=O/name;rel='delivery/'+name;tf.add(p,arcname=rel,recursive=False);members.append(dict(path=rel,**record(p)))
expected={r['path']:r for r in members};assert len(expected)==len(members)
with tarfile.open(O/'evidence.tar.gz','r:gz') as tf:
 seen=set()
 for m in tf.getmembers():
  assert m.isfile() and not m.issym() and not m.islnk() and m.name not in seen
  seen.add(m.name);b=tf.extractfile(m).read();assert expected[m.name]==dict(path=m.name,size=len(b),sha256=h(b))
 assert seen==set(expected)
a=record(O/'evidence.tar.gz');manifest=dict(archive_sha256=a['sha256'],archive_size=a['size'],member_count=len(members),members=members)
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(dict(verdict='SOUND',verified_inputs=len(rows),outputs=sorted(p.name for p in O.iterdir()),archive_sha256=a['sha256'],archive_size=a['size'],member_count=len(members))))
