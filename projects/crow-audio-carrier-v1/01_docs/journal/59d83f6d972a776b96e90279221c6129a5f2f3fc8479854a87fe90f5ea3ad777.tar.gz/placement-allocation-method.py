"""Open only after exact schematic-stage acceptance, green commit and valid handoff."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import json,sys,hashlib,shutil
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
slug,revision=sys.argv[1:3];assert revision=='fabfeatures1';P=R/'projects'/slug;short='pod' if 'pod' in slug else 'carrier';name=f'rj45-{short}-placement-after-{revision}';agent=f'/root/carrier_rj45_{short}_placement_after_{revision}'
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
assert (N/f'{slug}-{revision}-review-adoption.json').is_file()
for lens in ['topology','readability']:
 c=json.loads((N/f'rj45-{short}-{lens}-review-{revision}-closeout-summary.json').read_text());assert c['delivery_status']=='PASS' and c['engineering_verdict']=='SOUND'
H=P/'06_build/handoffs'/name;H.mkdir(parents=True,exist_ok=False)
for rel,local in [('06_build/agent_handoff.yaml','flow.yaml'),('01_docs/STATUS.md','beacon.md')]:shutil.copy2(P/rel,H/local)
j=(P/'01_docs/journal/schematic.md').read_text();(H/'journal-tail.md').write_text('## '+j.rsplit('\n## ',1)[1])
checkpoint=json.loads((P/'06_build/checkpoints/prelayout-inputs.json').read_text())
paths={R/key.removeprefix('repo:') for key in checkpoint['files']}
for rel in ['CLAUDE.md','skills/pcb-design/SKILL.md','skills/kicad-pcb/SKILL.md','skills/pcb-design/references/lifecycle-and-backtrack.md','skills/pcb-design/references/execution-runtime.md','skills/pcb-design/references/review-and-publication.md','skills/kicad-pcb/references/design-policies.md']:
 paths.add(R/rel)
for rel in ['06_build/checkpoints/prelayout-inputs.json','06_build/checkpoints/prelayout.json','06_build/checkpoints/schematic.json','06_build/sourcing/prelayout_response.csv','06_build/sourcing/public_catalog_stock.json','08_reviews/pre-route_topology.md','08_reviews/pre-route_schematic_render.md','01_docs/findings.yaml']:
 paths.add(P/rel)
paths.update((P/'04_kicad').glob('*.kicad_*'))
paths.update((P/'06_build/netlists').glob('*.net'))
for src in sorted(paths):
 assert src.is_file() and not src.is_symlink(),src
 dst=H/'context'/src.relative_to(R);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
shutil.copy2('/tmp/carrier-locator-implementation-availability-6c_4vwal/preflight.py',H/'preflight.py')
command=['/usr/bin/python3','-B',str(R/'skills/kicad-pcb/scripts/pcb_flow.py'),'run',str(P),'--stage','rj45_renewed_placement','--budget-s','600','--timeout-s','600','--','bash',str(P/'03_src/rebuild_all.sh'),'--resume-after-schematic-review']
now=datetime.now(timezone.utc);hard=now+timedelta(minutes=30);cut=now+timedelta(minutes=20)
(H/'TASK.md').write_text(f'''# Fresh schematic-to-placement mechanical successor

Root transfers exclusive live writer ownership of {slug} to {agent} for this bounded attempt. Root and other agents must not write this project until actual FINAL and owning closure. Other board ownership remains separate. Read only this TASK, copied current flow/beacon/journal-tail and exact named canon/source in context/. Do not load previous conversation or unrelated historical review reasoning. Verify envelope input packet, live canonical handoff with pcb_flow validate, and exact source checkpoint before executing. Copies are frozen; actual live source is protected by EXCLUSIVE writer-scope exclusions.

The preceding schematic is independently SOUND with current reports adopted. FIRST-ARTICLE-ONLY / DO-NOT-ORDER, public catalog design-only admission, physical FULL23carrier/9pod deferred under accepted decisions. No order, physical PASS or release authority. The existing PCB is the preceding RJ45 placement snapshot and remains unrouted; it does not accept the latest source placement or routing. MEASURED root current prior-placement DRC is carrier8/499/0 and pod1/58/0: exactly nine library-footprint mismatch warnings identify old embedded Fab versus the accepted new18-mark library; every unconnected item retains its individual classification. These failed prior-placement reports must be replaced by normal board regeneration, not waived. The shared Fab spring-finger source and sampling limitation are independently accepted through the exact source adoption in the current journal; original physical models, pads, courtyard, copper and extraction algorithm remain unchanged. Existing shared camera/scene and receipt-integrity authority remains accepted at ee3eaf28. Supplemental native shell/attachment/full-extent proof is required alongside ordinary raster registration and remains nominal CAD evidence. Both prior Fab source candidates remain spent; no new geometry repair is admitted. No current user orientation approval exists; the new normal evidence must be reviewed and explicitly approved through the owning gate. Root has integrated source corrections and renewed schematic authority normally. No candidate proof bypasses current gates. LAYOUT001closed3/3 remains unchanged; no fourth diagnostic/model reset.

Run ONE normal checkpoint-aware continuation, bounded through shared pipeline_runtime.run_stage (outer timeout660s). Exact argv:
{json.dumps(command)}

This driver verifies all source/native/review/checkpoint gates then promotes the accepted schematic and generates the RJ45 PCB from floorplan. Do not rerun TSX, edit source/config/parts/shared scripts, hand-edit generated outputs, restamp checkpoints, waive gates, import the stale pod FINAL/route chain, or bypass a placement failure. Stop at its first failed/missing gate; no retry. A nonzero engineering result is valid honest delivery when all evidence is present. If the unexpected driver reaches beyond missing placement reviews, stop and report; no unreviewed routing authorized.

Return actual stopping gate, subprocess rc/time, component/pin/PCB hashes and exact output paths. If a DRC report exists, classify EVERY violation, unconnected item and parity node by cause; no aggregate congestion story. Preserve raw output/runtime and all failure subjects. Report absent stages as NOT RUN. Verify protected source/method preimages unchanged and final READ_ONLY/exclusive scope result via provided preflight.py. Do not mistake generated copper/pin map for physical service or route acceptance.

Only allowed project paths may change: STATUS, placement journal, promoted03_tscircuit/kicad,04_kicad and06_build. Do not modify frozen handoff files despite their06_build location. Root owns commits and durable archive after FINAL; do not git-add/commit/push or write other projects. Update project beacon and placement journal with measured gate result. Generate/validate the compact placement handoff if exact gate freshness allows; never delete or touch a stale DRC gate to manufacture handoff. Otherwise report that blocker intact.

Declared output_dir requires report.md,evidence.json,evidence-manifest.json,evidence.tar.gz,result.json. evidence binds exact envelope subject, command/runtime, outputs/hashes, stopping gate, full classification and preserved source. Archive exact logs/results and independently reopen all regular members (no symlinks, duplicate paths, traversal or recursive archive); manifest archive_sha256/archive_size/member_count/members(path,size,sha256). result checks execution-recorded,inputs-verified,outputs-preserved PASS only for complete honest delivery, with domain result separate. Finish work and actual FINAL by{cut.isoformat()}, hard{hard.isoformat()}; reserve packaging/closure time. No automatic replacement or extension.
''')
items=[]
for p in sorted(H.rglob('*')):
 if p.is_file():
  b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(P).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
s=subject_identity('native_placement_continuation',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
e=TaskEnvelope(schema=2,task_id=name,stage_id='KICAD-PLACEMENT',run_id=name,subject=s,executor='agent',execution_class='local',recommended_agent_role='mechanical',agent_role='mechanical',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'EXCLUSIVE','paths':['01_docs/STATUS.md','01_docs/journal/placement.md','03_tscircuit/kicad','04_kicad','06_build']},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['execution-recorded','inputs-verified','outputs-preserved']})
o=open_agent_attempt(e,cwd=P);o.update(project=str(P),envelope=str(P/e.output_path).replace('attempt.json','envelope.json'),task=str(H/'TASK.md'),agent_id=agent,work_cutoff=cut.isoformat());(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2));print(len(items),'frozen inputs')
