from pathlib import Path
import json
import thermal_review_common as common
ns={'__file__':common.__file__}
exec(compile(Path(common.__file__).read_text().replace('rj45-placement-thermal-availability-opened.json','rj45-candidate6-native-availability-opened.json'),'<fresh-native-review>','exec'),ns)
R,N=common.R,common.N;Q=Path('/tmp/crow-none-native6-unadmitted-v19jufxe')
assert json.loads((N/'candidate6-completed-assessment.json').read_text())['decision']=='REASSESS'
copies=[(Q,'native'),(R/'CLAUDE.md','canon/CLAUDE.md'),(R/'skills/pcb-design/SKILL.md','canon/SKILL.md'),(R/'skills/pcb-design/references/lifecycle-and-backtrack.md','canon/lifecycle-and-backtrack.md'),(R/'skills/kicad-pcb/references/design-policies.md','canon/design-policies.md'),(R/'projects/crow-audio-carrier-v1/01_docs/STATUS.md','current-handoff/STATUS.md'),(R/'projects/crow-audio-carrier-v1/01_docs/findings.yaml','current-handoff/findings.yaml')]
for name in ['candidate6-completed-assessment.json','candidate6-stopped-outcome.json','candidate6-placement-classified.json','candidate6-prepared-classified.json','classify_candidate6_stop.py','none-reviewed-source-adoption.json','rj45-none-return-independent-review1-closeout-summary.json']:
 copies.append((N/name,'current-handoff/'+name))
for p in Path('/tmp/carrier-connector-integration-20260911').glob('candidate6-*'):
 if p.is_file():copies.append((p,'root-runtime/'+p.name))
task='''# Fresh independent exact native6 review and bounded D-BACK judgment

Read current-handoff first. Root is sole live carrier/pod/shared writer. Six
native candidates are spent and assessed, zero pending. No new BOARD, generation,
prep, Save, property-changing experiment, routing pilot or live edit. Load exact
existing saved boards read-only; unchanged in-memory zone fill and native geometry
analysis are allowed. Work only in allocated scratch and explicit outputs.

SOURCE: exact independently SOUND nine-file NONE composition is adopted and
committed d3a6e486; source-review closure and adoption list pin exact postimages.
Engineering628copied inputs were rebound live before6. Frozen native workspace
findings is reviewed five-spent snapshot; current-handoff contains live assessed
six-spent ledger. This controlled metadata distinction is explicit, not staleness
in the electrical source. Source mode is NONE only C_VDDA2_10N.2;32source FULL
plus existing nativeU_ADC.49FULL remain. All geometry and numeric floors preserved.

ACTUAL native6 ordinary P-DRC0violations/499opens/0parity PASS, then separation,
feasibility, policy, escape, tier, prep, fill, rules-last and verify-fill PASS.
Prepared fullDRC reports60warnings(39track_dangling/21via_dangling),445opens,
0parity. Every raw row/native UUID/net retained. Original source-binding driver
stops because it unconditionally requires all nonmechanical reference text visible.
Its other four checks pass: all434seed primitives,83regions, exact two changed
rule areas and306fittedSMDtop. All23hiddenrefs equal authored locator/policy and
generated list. Exact set membership alone DOES NOT grant locator waiver or
current independent atlas/render acceptance. Original FAIL and later ordered
graph/analog/critical/spoke/rules NOT_RUN must remain unchanged.

Required complete bounded handback:
1. Independently bind actual source to unprepared/prepared board, all affected
   modes234GND, pad shapes/positions/layers, geometry/settings/return declarations
   and no lower floors. Validate the correct explicit NONE target and actual
   disappearance of prior thermal refusal; all306fittedSMD must remain F.Cu.
2. Judge the stopped proof assertion against the real source/locator contracts.
   Determine whether this is an overbroad proof method, missing current locator
   acceptance, a native label defect, or a combination. Enumerate the complete23
   body/pad/ref identity set, and name precise owed owning gates. Do not waive or
   force visible labels globally. Propose the smallest supported proof correction
   or normal renewal path; no source/native modifications during review.
3. Independently assess complete prepared return topology using actual effective
   copper geometry and unchanged filled islands: ADC2C_VDDA2_10N.2 must reach
   U_ADC.8 and bothVMID2caps on surface, then designated89.8,71.5drop; no direct
   ambientzone shortcut, cut owner/drop disconnects broad ground. Recheck all4
   VMID caps,3LTquiet returns/output cut,5ADCground-to-paddle relations,ADC1supply
   drop/broad-plane/full-disk closure. Exact methods/native_returns.py is an
   unexecuted root intended checker, not evidence. Use an independent derivation
   for judgment; if running it as a diagnostic, distinguish that result from
   original driver NOT_RUN and check its completeness/geometry assumptions.
4. Account for EVERY ordinary499 and prepared505 raw row. Verify every endpoint
   against native UUID/net/position, all60dangling source banks and bothremaining
   GNDopens using actual island/component attribution. Distinguish ordinary
   routing obligations from actual unintended shortcuts or disconnects. A zone
   UUID may contain several disconnected islands; never use its anchor as island.
5. In a separately labeled READ_ONLY diagnostic on frozen prepared subject,
   inspect/execute remaining analog, critical, spoke and rules consumers (exact
   commands in stopped driver) where they do not mutate native artifacts. Output
   reports under scratch, immutable source/board byte guards. Explain any needed
   command-path relocation and complete all failed findings. No rerun driver,
   regen, gate-order change or retrospective PASS. Source-side proof and current
   graph are distinct from final routed acceptance.
6. Return a supported next decision: exact native evidence SOUND/DEFECTIVE or
   INCOMPLETE, complete causes and obligations, and whether normal coherent
   source/checkpoint/schematic/placement renewal is justified without a design
   change. No seventh native construction is admitted by review. Do not spend
   this review requalifying unchanged generic source tests already independently
   accepted; focus on actual native artifact and complete remaining consumers.

No new fixture BOARD, source edit, install, live write, commit or children.
All command work via finite pipeline_runtime.run_stage, directargv/explicit
cwd/env, raw logs and actual durations under scratch; /usr/bin/python3 -B.
Verify frozen input hashes before/after, preserve full original failures.
Five exact delivery outputs; honest deliveryPASS can accompany engineering
DEFECTIVE or INCOMPLETE. Pod current five-view human orientation remains pending,
FIRST-ARTICLE-ONLY/DO-NOT-ORDER. No final routed/layout/fab/release acceptance.
'''
ns['open_task']('rj45-candidate6-native-review1',task,copies,minutes=20)
