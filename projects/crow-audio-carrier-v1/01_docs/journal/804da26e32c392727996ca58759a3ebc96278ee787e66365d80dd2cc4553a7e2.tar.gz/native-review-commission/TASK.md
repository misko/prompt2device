# Fresh independent exact native6 review and bounded D-BACK judgment

Read current-handoff first. Root is sole live carrier/pod/shared writer. Six
native candidates are spent and assessed, zero pending. No new BOARD, generation,
prep, Save, property-changing experiment, routing pilot or live edit. Load exact
existing saved boards read-only; unchanged in-memory zone fill and native geometry
analysis are allowed. Work only in allocated scratch and explicit outputs.

SOURCE: exact independently SOUND nine-file NONE composition is adopted and
committed d3a6e486; source-review closure and adoption list pin exact postimages.
Engineering628copied inputs were rebound live before6. Frozen native workspace
findings is reviewed five-spent snapshot; current-handoff contains live assessed
six-spent ledger. This controlled metadata distinction is explicit, not staleness
in the electrical source. Source mode is NONE only C_VDDA2_10N.2;32source FULL
plus existing nativeU_ADC.49FULL remain. All geometry and numeric floors preserved.

ACTUAL native6 ordinary P-DRC0violations/499opens/0parity PASS, then separation,
feasibility, policy, escape, tier, prep, fill, rules-last and verify-fill PASS.
Prepared fullDRC reports60warnings(39track_dangling/21via_dangling),445opens,
0parity. Every raw row/native UUID/net retained. Original source-binding driver
stops because it unconditionally requires all nonmechanical reference text visible.
Its other four checks pass: all434seed primitives,83regions, exact two changed
rule areas and306fittedSMDtop. All23hiddenrefs equal authored locator/policy and
generated list. Exact set membership alone DOES NOT grant locator waiver or
current independent atlas/render acceptance. Original FAIL and later ordered
graph/analog/critical/spoke/rules NOT_RUN must remain unchanged.

Required complete bounded handback:
1. Independently bind actual source to unprepared/prepared board, all affected
   modes234GND, pad shapes/positions/layers, geometry/settings/return declarations
   and no lower floors. Validate the correct explicit NONE target and actual
   disappearance of prior thermal refusal; all306fittedSMD must remain F.Cu.
2. Judge the stopped proof assertion against the real source/locator contracts.
   Determine whether this is an overbroad proof method, missing current locator
   acceptance, a native label defect, or a combination. Enumerate the complete23
   body/pad/ref identity set, and name precise owed owning gates. Do not waive or
   force visible labels globally. Propose the smallest supported proof correction
   or normal renewal path; no source/native modifications during review.
3. Independently assess complete prepared return topology using actual effective
   copper geometry and unchanged filled islands: ADC2C_VDDA2_10N.2 must reach
   U_ADC.8 and bothVMID2caps on surface, then designated89.8,71.5drop; no direct
   ambientzone shortcut, cut owner/drop disconnects broad ground. Recheck all4
   VMID caps,3LTquiet returns/output cut,5ADCground-to-paddle relations,ADC1supply
   drop/broad-plane/full-disk closure. Exact methods/native_returns.py is an
   unexecuted root intended checker, not evidence. Use an independent derivation
   for judgment; if running it as a diagnostic, distinguish that result from
   original driver NOT_RUN and check its completeness/geometry assumptions.
4. Account for EVERY ordinary499 and prepared505 raw row. Verify every endpoint
   against native UUID/net/position, all60dangling source banks and bothremaining
   GNDopens using actual island/component attribution. Distinguish ordinary
   routing obligations from actual unintended shortcuts or disconnects. A zone
   UUID may contain several disconnected islands; never use its anchor as island.
5. In a separately labeled READ_ONLY diagnostic on frozen prepared subject,
   inspect/execute remaining analog, critical, spoke and rules consumers (exact
   commands in stopped driver) where they do not mutate native artifacts. Output
   reports under scratch, immutable source/board byte guards. Explain any needed
   command-path relocation and complete all failed findings. No rerun driver,
   regen, gate-order change or retrospective PASS. Source-side proof and current
   graph are distinct from final routed acceptance.
6. Return a supported next decision: exact native evidence SOUND/DEFECTIVE or
   INCOMPLETE, complete causes and obligations, and whether normal coherent
   source/checkpoint/schematic/placement renewal is justified without a design
   change. No seventh native construction is admitted by review. Do not spend
   this review requalifying unchanged generic source tests already independently
   accepted; focus on actual native artifact and complete remaining consumers.

No new fixture BOARD, source edit, install, live write, commit or children.
All command work via finite pipeline_runtime.run_stage, directargv/explicit
cwd/env, raw logs and actual durations under scratch; /usr/bin/python3 -B.
Verify frozen input hashes before/after, preserve full original failures.
Five exact delivery outputs; honest deliveryPASS can accompany engineering
DEFECTIVE or INCOMPLETE. Pod current five-view human orientation remains pending,
FIRST-ARTICLE-ONLY/DO-NOT-ORDER. No final routed/layout/fab/release acceptance.


Delivery mechanics: Allocated scratch: /tmp/rj45-candidate6-native-review1-5n0q1c8a/06_build/task_runs/rj45-candidate6-native-review1/scratch . Final outputs: /tmp/rj45-candidate6-native-review1-5n0q1c8a/06_build/task_runs/rj45-candidate6-native-review1/outputs . Root sole live writer. Frozen packet read-only; make working copies under the allocated scratch dir only. No live writes, commits, children, background processes, or source adoption. Verify every envelope input before/after. Use /usr/bin/python3 -B and shared pipeline_runtime.run_stage for finite direct-argv subprocesses, explicit cwd/environment, raw stdout/stderr/runtime retained under scratch. Shared runtime is at /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts. Images can be opened with view_image.

Work cutoff 2026-09-14T00:36:31.624451+00:00, hard 2026-09-14T00:43:31.624451+00:00, zero replacements. Stop engineering at work cutoff and return actual FINAL promptly. Preserve honest INCOMPLETE if coverage absent; delivery PASS means complete honest handback, never engineering acceptance. Outputs exactly report.md, evidence.json, evidence-manifest.json, evidence.tar.gz, result.json. evidence.json requires verdict SOUND|DEFECTIVE|INCOMPLETE and exact envelope subject, methods, findings and measured counts. Archive all actual methods/raw evidence/runtime; manifest archive_sha256/archive_size/member_count/members with path,size,sha256; reopen every regular member, no symlink/traversal/duplicate/recursive archive. result.json exact subject, checks inputs-verified/review-complete/evidence-complete PASS only when factually complete delivery; unresolved [] for delivered honest findings. Use preflight.py with exact envelope after packaging to validate delivery. Final response gives domain verdict and unresolved findings, exact report and archive.
