from pathlib import Path
import json
import thermal_review_common as common

# Keep the shared task constructor's mechanics; bind this commission to the
# newly observed live delivery probe rather than an older cached observation.
source = Path(common.__file__).read_text().replace(
    "rj45-placement-thermal-availability-opened.json",
    "rj45-adc2-source-review-availability-opened.json")
namespace = {'__file__': common.__file__}
exec(compile(source, '<adc2-reviewed-commission>', 'exec'), namespace)
N, R = common.N, common.R
author = json.loads((N/'rj45-adc2-reservation-source1-opened.json').read_text())
D, O, S = map(Path, (author['project'], author['output_dir'], author['scratch_dir']))
assert json.loads(Path(author['attempt']).read_text())['status'] == 'PASS'
assert (N/'rj45-adc2-reservation-source1-closeout-summary.json').is_file()
assert json.loads((O/'evidence.json').read_text())['verdict'] == 'SOUND'
copies = [(D/'project', 'project'), (D/'canon', 'canon'),
          (D/'candidate4', 'candidate4'), (D/'actual-stop', 'actual-stop'),
          (D/'decision', 'decision'), (D/'shared', 'shared'),
          (D/'current-handoff', 'current-handoff'),
          (O, 'proposal-delivery'), (S/'after', 'after'),
          (R/'projects/crow-audio-carrier-v1/03_tscircuit/src', 'project/03_tscircuit/src')]
task = '''# Independent exact ADC2 return-reservation source review

Read current-handoff, exact proposal and primary ADC authority. This is an
independent SOURCE review, not native acceptance. Root retains the sole live
writer. No generator, saved PCB, fill, DRC, routing or new native candidate.
The cumulative native4/4 cap is closed. Analyze existing frozen native geometry
read-only where useful. Verify the complete proposal manifest against before
and after bytes; all actual methods must run on your own scratch working copies.

Decide whether the complete exact proposal is SOUND, DEFECTIVE or INCOMPLETE:
* Only ADC_VMID2_RETURN_POUR.points may change in floorplan. Independently prove
  the set union of the old polygon with x89.99..91.05,y70.94..72.06mm, at native
  integer precision: one simple polygon/no holes, no lost protected area, full
  pad/clearance coverage, no extra added area. Use an independent geometric
  method or independently constructed controls; author BooleanAdd proving
  itself is insufficient. Assess consumer polygon representation constraints.
* Re-derive actual target pad geometry and named GND/ADC8/VMID2 seed/via ownership
  from primary/source/native. Distinguish pours from tracks/vias and recognize
  the BEFOREprep stage of the retained thermal failure. Review full affected
  pad/route/via/region inventory, not bbox overlap as a claimed obstruction.
* Preserve placement, all separate via reservations,32 source exact full-GND
  targets/33 native full, minimum2spokes, clearance/width/current floors,
  explicit return seeds/drops and all unrelated source fields. No pad override.
* Review maintained tests for useful independent properties and real defect
  sensitivity. Reproduce actual property RED with before-floorplan and GREEN
  with proposal, retaining existing cases. Import/setup ERROR with0tests is
  not RED. Exercise partial coverage, loss of old protected branch, wrong layer,
  wrong denial and designated seed/drop tampering. Do not merely trust author
  logs or duplicate the author method. Relevant source suites only.
* ADR0015 addition must faithfully explain the supported local return-reservation
  decision and explicit native evidence still owed. Preserve historical claims;
  no source paragraph may grant placement/routing/first-article acceptance.
* State separately whether this reviewed changed return-reservation premise
  supports ROOT consideration of AT MOST ONE cumulative native candidate5,
  retaining all4 prior observations/spend, no native6 or reset. Exact source
  acceptance is not the admission itself. If supported, enumerate required
  native predicates: ordinary generated placement full-severity/refill/parity
  DRC and owning P-DRC BEFORE prep, then prepared/filled DRC plus4VMID cuts,
  3LT quiet cuts,5paddle exclusions, supply/ground paths and unchanged source
  authority. Stop on earlier actual refusal; diagnostic work cannot advance it.

The author packet initially missed TSX dependencies; all committed TSX source
is frozen here to avoid repeating that setup gap. Its immutable dependencies
and all earlier failed setup logs remain in proposal archive. Shared tools are
frozen in shared/skills; standard installed libraries are read-only dependencies.
For source tests requiring Git historical controls, explicitly resolve real
R's .git object store; record actual immutable commit/blob hashes. Do not install
tools. /usr/bin/python3 has pcbnew but not Shapely; inspect APIs before use.

Return exact reviewed file/hash table, full method/controls and limitations,
source verdict and separate bounded next-native recommendation. Preserve all
raw results and actual scripts in the required evidence archive. No source
adoption, new PCB, stage approval or human witness may be claimed.
'''
namespace['open_task']('rj45-adc2-exact-source-review1', task, copies, minutes=18)
