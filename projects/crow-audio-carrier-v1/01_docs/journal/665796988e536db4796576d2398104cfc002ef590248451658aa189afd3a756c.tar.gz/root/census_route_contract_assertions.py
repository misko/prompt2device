"""Diagnostic only: retain EVERY assertion failure; never grade a passing suite."""
from pathlib import Path
import functools, hashlib, json, sys, traceback, unittest
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
P=R/'projects/crow-audio-carrier-v1'
sys.path.insert(0,str(P/'03_src/tests'))
import test_route_source_contract as module
failures=[]
current=''
for name in dir(unittest.TestCase):
    if not name.startswith('assert') or name in ['assertRaises','assertRaisesRegex','assertWarns','assertWarnsRegex','assertLogs','assertNoLogs']:
        continue
    original=getattr(unittest.TestCase,name)
    if not callable(original): continue
    def wrap(fn,name):
        @functools.wraps(fn)
        def observed(self,*args,**kwargs):
            try: return fn(self,*args,**kwargs)
            except AssertionError as exc:
                frames=traceback.extract_tb(exc.__traceback__)
                failures.append({'test':current,'assertion':name,'message':str(exc),
                                 'caller':traceback.format_stack(limit=3)[-2]})
        return observed
    setattr(unittest.TestCase,name,wrap(original,name))
paths=[p for p in (P/'03_src').rglob('*') if p.is_file() and '__pycache__' not in p.parts]
before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
case=module.RouteSourceContractTests
case.setUpClass()
results=[]
for current in unittest.defaultTestLoader.getTestCaseNames(case):
    start=len(failures)
    try:
        getattr(case(current),current)()
        results.append({'test':current,'recorded_failures':len(failures)-start})
    except Exception as exc:
        results.append({'test':current,'recorded_failures':len(failures)-start,
                        'exception':repr(exc),'traceback':traceback.format_exc()})
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before.items())
out={'status':'DIAGNOSTIC_ONLY_NOT_A_TEST_PASS','method':'Actual unmodified test bodies with assertion observers that record and continue; original normal suite FAIL remains authority.',
     'source_files_unchanged':len(before),'tests':results,'failures':failures}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
