"""Read-only cause census for the already observed baseline source test failure."""
from pathlib import Path
import hashlib, json, sys
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
P=R/'projects/crow-audio-carrier-v1'
sys.path.insert(0,str(P/'03_src/tests'))
import test_route_source_contract as test
paths=list((P/'03_src').rglob('*'))+list((P/'03_tscircuit/src').rglob('*'))
before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.is_file() and '__pycache__' not in p.parts}
floor,route,nets,stack,comps,pins=test.load_source()
observed,plan=test.shadow_inputs(route,nets,comps,pins)
receipt=test.compile_source_prep_authority(stack=stack,observed=observed,route_plan=plan,migration=None)
for path,digest in before.items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
result={'scope':'Read-only unchanged-source diagnosis, no repaired test/source or native generation',
        'source_files_unchanged':len(before),'observed':observed,'plan':plan,
        'receipt':receipt,'route_ownership':route['route']['ownership']}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2,default=str)+'\n')
print(json.dumps({'verdict':receipt['verdict'],'findings':receipt.get('findings'),
                  'coverage':receipt.get('coverage'),'keys':list(receipt)},indent=2))
