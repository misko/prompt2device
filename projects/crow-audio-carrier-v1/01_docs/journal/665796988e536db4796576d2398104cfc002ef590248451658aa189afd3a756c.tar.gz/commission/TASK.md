# Independent exact ADC2 return-reservation source review

Read current-handoff, exact proposal and primary ADC authority. This is an
independent SOURCE review, not native acceptance. Root retains the sole live
writer. No generator, saved PCB, fill, DRC, routing or new native candidate.
The cumulative native4/4 cap is closed. Analyze existing frozen native geometry
read-only where useful. Verify the complete proposal manifest against before
and after bytes; all actual methods must run on your own scratch working copies.

Decide whether the complete exact proposal is SOUND, DEFECTIVE or INCOMPLETE:
* Only ADC_VMID2_RETURN_POUR.points may change in floorplan. Independently prove
  the set union of the old polygon with x89.99..91.05,y70.94..72.06mm, at native
  integer precision: one simple polygon/no holes, no lost protected area, full
  pad/clearance coverage, no extra added area. Use an independent geometric
  method or independently constructed controls; author BooleanAdd proving
  itself is insufficient. Assess consumer polygon representation constraints.
* Re-derive actual target pad geometry and named GND/ADC8/VMID2 seed/via ownership
  from primary/source/native. Distinguish pours from tracks/vias and recognize
  the BEFOREprep stage of the retained thermal failure. Review full affected
  pad/route/via/region inventory, not bbox overlap as a claimed obstruction.
* Preserve placement, all separate via reservations,32 source exact full-GND
  targets/33 native full, minimum2spokes, clearance/width/current floors,
  explicit return seeds/drops and all unrelated source fields. No pad override.
* Review maintained tests for useful independent properties and real defect
  sensitivity. Reproduce actual property RED with before-floorplan and GREEN
  with proposal, retaining existing cases. Import/setup ERROR with0tests is
  not RED. Exercise partial coverage, loss of old protected branch, wrong layer,
  wrong denial and designated seed/drop tampering. Do not merely trust author
  logs or duplicate the author method. Relevant source suites only.
* ADR0015 addition must faithfully explain the supported local return-reservation
  decision and explicit native evidence still owed. Preserve historical claims;
  no source paragraph may grant placement/routing/first-article acceptance.
* State separately whether this reviewed changed return-reservation premise
  supports ROOT consideration of AT MOST ONE cumulative native candidate5,
  retaining all4 prior observations/spend, no native6 or reset. Exact source
  acceptance is not the admission itself. If supported, enumerate required
  native predicates: ordinary generated placement full-severity/refill/parity
  DRC and owning P-DRC BEFORE prep, then prepared/filled DRC plus4VMID cuts,
  3LT quiet cuts,5paddle exclusions, supply/ground paths and unchanged source
  authority. Stop on earlier actual refusal; diagnostic work cannot advance it.

The author packet initially missed TSX dependencies; all committed TSX source
is frozen here to avoid repeating that setup gap. Its immutable dependencies
and all earlier failed setup logs remain in proposal archive. Shared tools are
frozen in shared/skills; standard installed libraries are read-only dependencies.
For source tests requiring Git historical controls, explicitly resolve real
R's .git object store; record actual immutable commit/blob hashes. Do not install
tools. /usr/bin/python3 has pcbnew but not Shapely; inspect APIs before use.

Return exact reviewed file/hash table, full method/controls and limitations,
source verdict and separate bounded next-native recommendation. Preserve all
raw results and actual scripts in the required evidence archive. No source
adoption, new PCB, stage approval or human witness may be claimed.


Delivery mechanics: Allocated scratch: /tmp/rj45-adc2-exact-source-review1-4jmbwv9g/06_build/task_runs/rj45-adc2-exact-source-review1/scratch . Final outputs: /tmp/rj45-adc2-exact-source-review1-4jmbwv9g/06_build/task_runs/rj45-adc2-exact-source-review1/outputs . Root sole live writer. Frozen packet read-only; make working copies under the allocated scratch dir only. No live writes, commits, children, background processes, or source adoption. Verify every envelope input before/after. Use /usr/bin/python3 -B and shared pipeline_runtime.run_stage for finite direct-argv subprocesses, explicit cwd/environment, raw stdout/stderr/runtime retained under scratch. Shared runtime is at /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts. Images can be opened with view_image.

Work cutoff 2026-09-13T21:59:40.600807+00:00, hard 2026-09-13T22:06:40.600807+00:00, zero replacements. Stop engineering at work cutoff and return actual FINAL promptly. Preserve honest INCOMPLETE if coverage absent; delivery PASS means complete honest handback, never engineering acceptance. Outputs exactly report.md, evidence.json, evidence-manifest.json, evidence.tar.gz, result.json. evidence.json requires verdict SOUND|DEFECTIVE|INCOMPLETE and exact envelope subject, methods, findings and measured counts. Archive all actual methods/raw evidence/runtime; manifest archive_sha256/archive_size/member_count/members with path,size,sha256; reopen every regular member, no symlink/traversal/duplicate/recursive archive. result.json exact subject, checks inputs-verified/review-complete/evidence-complete PASS only when factually complete delivery; unresolved [] for delivered honest findings. Use preflight.py with exact envelope after packaging to validate delivery. Final response gives domain verdict and unresolved findings, exact report and archive.
