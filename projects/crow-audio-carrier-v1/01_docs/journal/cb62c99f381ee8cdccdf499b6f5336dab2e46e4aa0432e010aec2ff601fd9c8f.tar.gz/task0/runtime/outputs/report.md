# Recorded canonical attempt

- qualify: rc=0, 19.621129s; full raw output execution.log
- normal: rc=2, 94.096636s; full raw output execution.log
- public-continuation: rc=1, 3.889807s; full raw output execution.log
- Authored input hashes: 593/593
- All generated identities are in execution.json.
- Stop at the last actual recorded gate. No routing or release acceptance.
