from pathlib import Path
import sys,json,hashlib,tarfile,datetime
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
P=R/'projects/crow-audio-carrier-v1'; D=Path(__file__).parent
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet,envelope_sha256
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[]; writes=[]
def archive(path, manifest):
    raw=path.read_bytes(); m=json.loads(manifest.read_text())
    assert {'sha256':sha(raw),'size':len(raw)}==m['archive']
    payload={}
    with tarfile.open(path) as t:
        for x in t.getmembers():
            assert x.isfile() and not Path(x.name).is_absolute() and '..' not in Path(x.name).parts and x.name not in payload
            b=t.extractfile(x).read(); assert {'sha256':sha(b),'size':len(b)}==m['members'][x.name]
            payload[x.name]=b
    assert set(payload)==set(m['members'])
    return payload
for root,name in [(Path('/tmp/carrier-orientation-frame-20260911'),'orientation-frame'),(Path('/tmp/carrier-keying-source-review-27x1olqz'),'keying-source-review')]:
    a=root/'06_build/task_runs'/name
    e=TaskEnvelope.from_json((a/'envelope.json').read_text())
    ok,findings=verify_input_packet(e,root); assert ok,findings
    attempt=json.loads((a/'attempt.json').read_text()); assert attempt['status']=='PASS' and not attempt['unresolved']
    assert attempt['envelope_sha256']==envelope_sha256(e)
    for name2,expected in attempt['output']['completion']['outputs'].items():
        b=(a/'outputs'/name2).read_bytes(); assert {'sha256':sha(b),'size':len(b)}==expected
    rows.append({'attempt':str(a),'packet_members':len(e.input_packet),'status':attempt['status'],'finished_at':attempt['finished_at']})
f=Path('/tmp/carrier-orientation-frame-20260911/06_build/task_runs/orientation-frame/outputs')
payload=archive(f/'evidence.tar.gz',f/'evidence-manifest.json')
for c in json.loads((f/'changes.json').read_text()): writes.append((R,c,payload['source/'+c['path']]))
k=Path('/tmp/carrier-keying-source-review-27x1olqz/input')
model=archive(k/'candidate.tar.gz',k/'candidate-manifest.json')
assert sha((k/'candidate.tar.gz').read_bytes())=='7c9160803ea4e5ad558931776eb33973f350a3f5d3dda954b758c673c153c80a'
for c in json.loads((k/'changes.json').read_text())['changes']: writes.append((P,c,model['source/'+c['path']]))
before={}
for root,c,b in writes:
    p=root/c['path']; old=p.read_bytes() if p.exists() else None
    assert (sha(old) if old is not None else None)==c['before_sha256'],str(p)
    assert sha(b)==c['after_sha256'],str(p)
    rel=p.relative_to(R).as_posix(); before[rel]={'before_sha256':c['before_sha256'],'after_sha256':c['after_sha256']}
    if old is not None:
        backup=D/'preimages'/rel; backup.parent.mkdir(parents=True,exist_ok=True); backup.write_bytes(old)
(D/'verification.json').write_text(json.dumps({'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'attempts':rows,'checker_evidence_members':len(payload),'model_members':len(model),'source_changes':before},indent=2)+'\n')
print('Verified packets, terminal deliveries, 76 checker members, 109 model members, and all 18 live preimages/afters')
if '--adopt' in sys.argv:
    for root,c,b in writes:
        p=root/c['path']; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(b)
    print('Adopted 18 exact source files; no generated artifact, checkpoint or review altered')
