from review import *
import tarfile,io
O=S.parent/'outputs';O.mkdir(exist_ok=True)
verify('inputs-after')
report="""# Narrow method review: SOUND

The fixed placement-only thermal deferral is sound for this declared boundary. The proposal is a sound one-off method-only checkpoint re-admission under the stated root sole-writer and ordinary non-optimized Python execution assumptions. This is code/process acceptance, not execution of re-admission or acceptance of the PCB.

Independent checks reproduced RED to GREEN on the frozen native report: 5 starved_thermal violations, 499 unrouted connections, 0 parity findings. The new checker prints every exact deferred row, including pad and zone UUIDs. Connected-board thermal findings still fail. Short, clearance, hole, library, unknown-type, malformed-row, and parity controls all fail. There is no configurable allowlist. Fourteen independent classifier cases met their expected outcomes. The supplied tests and red/green result receipts were inspected; the receipts alone do not contain the original complete test output, so independent cases provide the directly retained behavioral evidence.

The frozen old census has exactly 617 entries. The proposal requires the identical key set and exactly the three specified before/after hash-and-size transitions (placement checker and two contracts), retaining the other 614 rows. Extracting only its check_delta function and exercising it against the frozen census accepted that exact transition and rejected addition, deletion, and foreign-authority content drift. This did not import or execute the proposal main block.

The proposal acquires the same project-directory inode flock as both normal conductors before checking inputs. It checks every one of the 11 old prelayout stage entries before writes, including the exact reviewed native schematic, circuit JSON, PDF, netlist and prior census. It reruns schematic review and source-provenance checks, archives both old checkpoints and the method delta, records a new census through the owning recorder, repeats the exact transition check, and verifies it through its owner before publication. Publication and the stage record plus normal resume admission are inside a rollback handler restoring both old checkpoint files on ordinary exceptions, including failing child stages. Normal resume requires the schematic checkpoint and verifies provenance, stage checkpoint, complete census, exact sourcing request and the permitted sourcing/readiness path. The existing schematic checkpoint is not rewritten. No command invokes TSX or regenerates schematic, PDF, PCB geometry or copper. Root sole-writer discipline is material because flock is advisory.

The frozen conductors still run fresh native refill/parity DRC before this placement classifier, and keep the later route acceptance/final gates. This changes intermediate grading, not the final zero-violations/unconnected/parity requirement or thermal spoke rules. Root is independently performing contract/regression checks and must run the normal conductor and all final native/release gates afterward.

Limits: no mutation-proposal execution, live 617-file recensus, fault-injected rollback execution, new native DRC, routed-board review, or release acceptance was performed. Runtime assertions are active in the reviewed ordinary invocation; optimized Python execution is outside that invocation. Process-kill/power-loss crash recovery is not promised by the ordinary exception rollback. The packet includes the proposed project-contract hash transition, not its full project-contract body; that content is covered by root's parallel contract check. These are scope boundaries, not hidden evidence of completed execution. No actionable defect was found within the commissioned code/process review.

All 20 envelope inputs verified byte-for-byte before and after review. All work products are confined to allocated scratch/outputs. Evidence includes actual case documents, raw merged stdout/stderr logs and shared-runtime records. No child agent, background process, live write, commit or mutation-proposal execution occurred.
"""
(O/'report.md').write_text(report)
evidence=dict(verdict='SOUND',subject=E['subject'],methods=['Frozen input hash/size verification before and after','Static review of classifier, supplied tests, exact delta and record/verify/resume flow','14 independent classifier executions including frozen real report against old/new checker','AST extraction of check_delta only, exact transition and three drift controls','Shared pipeline_runtime.run_stage finite direct-argv subprocesses with explicit cwd/environment','Archive regular-member reopen and exact delivery preflight'],findings=[],measured_counts=dict(envelope_inputs=20,classifier_cases=14,census_inputs=617,allowed_method_changes=3,preserved_census_entries=614,stage_entries=11,thermal_findings=5,unrouted_connections=499,parity_findings=0,delta_negative_controls=3),limits=['Review-only; mutation proposal not executed','No new native DRC or release acceptance','Root independently checks project contract content; full project contract not in frozen packet','Ordinary Python assertions enabled and root sole-writer/project-lock assumptions'])
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(O/'result.json').write_text(json.dumps(dict(subject=E['subject'],checks={k:'PASS' for k in E['completion']['checks']},unresolved=[]),indent=2)+'\n')
# Store immutable copies of all commissioned methods and input evidence in archive.
C=S/'packet';C.mkdir(exist_ok=True)
for row in E['input_packet']:
 d=C/row['path'];d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes((R/row['path']).read_bytes())
(C/'envelope.json').write_text(json.dumps(E,indent=2))
files=[x for x in S.rglob('*') if x.is_file()]
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for f in sorted(files):
  assert not f.is_symlink();tf.add(f,arcname='scratch/'+f.relative_to(S).as_posix(),recursive=False)
 for name in ['report.md','evidence.json','result.json']:tf.add(O/name,arcname=name,recursive=False)
members=[]
with tarfile.open(archive,'r:gz') as tf:
 names=set()
 for m in tf.getmembers():
  assert m.isfile() and not m.issym() and not m.islnk()
  assert not m.name.startswith('/') and '..' not in Path(m.name).parts and m.name not in names and not m.name.endswith('.tar.gz');names.add(m.name)
  b=tf.extractfile(m).read();assert len(b)==m.size
  members.append(dict(path=m.name,size=len(b),sha256=hashlib.sha256(b).hexdigest()))
manifest=dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_size=archive.stat().st_size,member_count=len(members),members=members)
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PACKAGED',len(members),'members',manifest['archive_size'],'bytes')
