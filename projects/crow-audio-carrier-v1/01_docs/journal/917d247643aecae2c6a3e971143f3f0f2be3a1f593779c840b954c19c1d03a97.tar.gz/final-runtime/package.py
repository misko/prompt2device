from pathlib import Path
import json,hashlib,tarfile,shutil
s=Path(__file__).parent;root=s.parents[3];out=s.parent/"outputs";out.mkdir(exist_ok=True)
envelope=json.loads((s.parent/"envelope.json").read_text());subject=envelope["subject"];measure=json.loads((s/"measured.json").read_text())
sha_t="66d9ffaa15ef8ff9b1614640d81fd2d1c2c6629b522df0cddc64acac3e73efc3";sha_m="b8942b95bc3fe4c02171de9e714d99b2688055e249ba1524e3c2a8c3cf78eaa3"
report="""review_stage: pre-route
review_kind: pin
reviewer: fresh agent /root/rj45_pin_carrier_headers_clockground1
context: FRESH
design_verdict: INCOMPLETE
order_verdict: DO-NOT-ORDER
board_sha256: e85b1461a82f3d3853c19fae694693816e31570d23d37019ef187d6428bea4ae
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: e6d5b0b89efd79051b082f70b283ec7e85e1170ed11ddb94581744d26904c9c7

Scope is limited to J10, J11 and J9 in this frozen packet. No whole-board acceptance, mating-system acceptance, placement or routing review is implied. All commissioned instances were examined. Questions below are delivered engineering findings, not unfinished delivery.

Manufacturer figures were rendered and visually inspected before reading native dossiers. Samtec PDF page 1, FIG. 1, numbered post-side plan and -D section establish six positions in two rows, 12 independent pins at 2 mm pitch. In the manufacturer's post-side plan pin 1 is lower left, odds progress rightward along the lower row and evens along the row above. The unnumbered lower plan is the tail/bottom-side view and was not substituted for the numbered plan. Rotation 90 degrees clockwise maps manufacturer-relative coordinates (2*k,0) for odd pins and (2*k,-2) for even pins to dossier (0,2*k)/(2,2*k). No mirror is required. These alternating-row pins do not form a normal perimeter winding; dossier CW is not independently a package-winding criterion.

Molex page 1 PCB LAYOUT: COMPONENT SIDE and PCB LAYOUT: 2 CKT establish circuit 1 at right, circuit 2 at left, 3 mm pitch, and a 3 mm mechanical peg centered between contacts, 4.32 mm below them. Rotating this component-side figure 180 degrees yields dossier circuit 1 at (0,0), circuit 2 at (3,0), peg at (1.5,-4.32). Two collinear electrical pins cannot establish winding; the peg-relative identity does. No bottom-view mirror conversion is used.

All three dossiers explicitly state front mount and component-top +x right/+y down with placement undone. Every numbered pad's native position was checked against its component-top coordinate and stated 90-degree native KiCad placement. No exposed pads or fused identities are shown in either primary drawing; none are represented in the dossiers. No physical identity collapse was found.

J10 VERDICT: QUESTION
J11 VERDICT: QUESTION
Primary: Samtec TMM-Series_RevAS.pdf, SHA256 SHA_T, PDF page 1 / drawing sheet 1, FIG. 1 and -D cross-section. This selected file contains only sheet 1 (title says sheet 1 of 2); the geometry relevant to the unmodified -D header is present.
Each instance measures 12 native numbered pads, 12 distinct physical electrical identities, 12 unique numbered lands, 0 EP, 0 aliases and 0 listed unnumbered mechanical pads. Expected geometry, physical identities and pitch match in both instances. Generic ROWn_COLn functions denote positions, not mating-module signal functions.
J10 pin 2 (ROW1_COL2): expected assigned passive contact with external interface meaning requiring a mating map; observed ADC_TDM.
J10 pins 9/10/11/12 (ROW5_COL1/ROW5_COL2/ROW6_COL1/ROW6_COL2): expected external interface mapping not specified by Samtec; observed MCH_MCLK/MCH_BCLK/GND/MCH_FSYNC. The manufacturer drawing cannot independently establish that pin 11 is the mating module's clock-ground contact.
J11 pins 1/2 (ROW1_COL1/ROW1_COL2): expected external interface mapping not specified by Samtec; observed GND/MCH_3V3_SENSE.
J10/J11 pins 1,2,9,10,11,12 (pairwise symmetry): expected either corresponding net kinds or evidence of intentionally different mating-interface roles; observed J10 NC/signal/clock/clock/ground/clock versus J11 ground/rail-sense/NC/NC/NC/NC. Mechanical symmetry passes; electrical asymmetry needs context, and is not proof of a defect.
J10 pins 1,3-8 and J11 pins 3-12: observed individually named unconnected nets on separate physical contacts; Samtec assigns no mandatory electrical NC pins. Whether each contact may be omitted is an external-interface question.
Missing fact: authoritative mating-module pinout or connector interface specification identifying each of J10 and J11, its viewing convention/orientation, required clock/data/ground/sense contacts and allowed unused contacts. Without this, the exact function-net mapping cannot receive PASS.

J9 VERDICT: PASS
Primary: Molex Molex_436501000_SD_revD8.pdf, SHA256 SHA_M, PDF page 1 / sheet 1 of 1, PCB LAYOUT: COMPONENT SIDE, PCB LAYOUT: 2 CKT, and material table row 43650-0200.
Measured 2 native numbered pads, 2 physical electrical identities, 2 unique numbered lands, 1 unnumbered NPTH mechanical feature (3 mm drill), 0 EP and 0 aliases. Table identifies the exact 2-circuit order code with no void circuit. Contact spacing and pin identity relative to the peg match after the rotation above. Numbered contact drill dimensions are absent from dossier and are not a claim of this pin-identity review.
J9 pin 1 (+12V_IN): expected rail-type net under declared application function; observed 12V_IN, sane for a passive contact. Manufacturer imposes no intrinsic polarity.
J9 pin 2 (GND): expected ground net under declared application function; observed GND. Harness wiring and first-article mating fit are outside this limited pin review and are not certified here.

Complete observed per-pin positions/functions/nets, machine-counted identities and native-coordinate checks are in measured.json in the archive. Evidence includes the native dossiers, actual inspected rendered figures, independent figure-first derivation, scripts, raw stage logs, runtime records and before/after packet digests. Primary PDFs remain in the immutable digest-bound packet; their bytes are not duplicated in the archive.
""".replace("SHA_T",sha_t).replace("SHA_M",sha_m)
(out/"report.md").write_text(report)
findings=[dict(ref="J10",verdict="QUESTION",geometry="PASS",finding="Mating module function-net map unavailable; clock/data/ground assignments including pin 11 cannot independently be established."),dict(ref="J11",verdict="QUESTION",geometry="PASS",finding="Mating module function-net map unavailable; GND/sense and unused assignments cannot independently be established."),dict(ref="J10,J11",verdict="QUESTION",finding="Electrical symmetry differs at pins 1,2,9,10,11,12; authoritative distinct interface-role mapping required."),dict(ref="J9",verdict="PASS",finding="Exact two-contact identity and peg geometry match 180-degree rotation; declared power and ground functions map to corresponding net kinds.")]
evidence=dict(verdict="INCOMPLETE",subject=subject,review_stage="pre-route",review_kind="pin",reviewer="/root/rj45_pin_carrier_headers_clockground1",context="FRESH",coverage=["J10","J11","J9"],methods=["Verified every envelope input SHA256 and byte count before and after review.","Rendered exact SHA-selected primary PDFs with pdftoppm through finite pipeline_runtime.run_stage; visually inspected 80 dpi pages and Samtec 160 dpi detail before reading dossiers.","Derived manufacturer pin identities and component-side view; matched by rotation only, separately for every instance.","Parsed native dossier tables; measured pad and physical identity counts; checked native-coordinate placement transform.","Compared every function/net and cross-instance symmetry; preserved unresolved electrical interface facts as QUESTION.","Reopened every regular archive member and verified membership, sizes and SHA256; ran exact-envelope preflight after packaging."],findings=findings,measured_counts=measure,primary_documents=[dict(path=x["path"],sha256=x["sha256"],size=x["size"],page=1) for x in envelope["input_packet"] if x["path"].endswith(".pdf")])
(out/"evidence.json").write_text(json.dumps(evidence,indent=2))
for name in ["TASK.md","pin-review-protocol.md","preflight.py"]:shutil.copyfile(root/name,s/name)
shutil.copyfile(s.parent/"envelope.json",s/"envelope.json")
shutil.copyfile(out/"report.md",s/"report.md");shutil.copyfile(out/"evidence.json",s/"evidence.json")
files=sorted(p for p in s.iterdir() if p.is_file() and not p.name.startswith("preflight-final"))
archive=out/"evidence.tar.gz"
with tarfile.open(archive,"w:gz") as tf:
 for p in files:
  assert not p.is_symlink();tf.add(p,arcname=p.name,recursive=False)
rows=[];seen=set()
with tarfile.open(archive,"r:gz") as tf:
 for m in tf.getmembers():
  assert m.isfile() and not m.issym() and not m.islnk() and m.name not in seen and not Path(m.name).is_absolute() and ".." not in Path(m.name).parts and not m.name.endswith((".tar",".tar.gz",".tgz"));seen.add(m.name)
  data=tf.extractfile(m).read();assert len(data)==m.size and data==(s/m.name).read_bytes()
  rows.append(dict(path=m.name,size=len(data),sha256=hashlib.sha256(data).hexdigest()))
(out/"evidence-manifest.json").write_text(json.dumps(dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_size=archive.stat().st_size,member_count=len(rows),members=rows),indent=2))
(out/"result.json").write_text(json.dumps(dict(subject=subject,checks={x:"PASS" for x in envelope["completion"]["checks"]},unresolved=[]),indent=2))
print(json.dumps(dict(verdict="INCOMPLETE",outputs=str(out),member_count=len(rows))))
