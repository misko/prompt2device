import sys,os,json
from pathlib import Path
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_runtime import run_stage
S=Path(__file__).parent; R=S.parents[3]
r=run_stage({'id':'delivery-preflight','work_class':'local','timeout_s':60},['/usr/bin/python3','-B',str(R/'preflight.py'),str(S.parent/'envelope.json')],log_path=S/'preflight.log',cwd=S,env=dict(os.environ),console_line_limit=10,console_tail_lines=10)
(S/'runtime-preflight.json').write_text(json.dumps(vars(r),default=str,indent=2))
