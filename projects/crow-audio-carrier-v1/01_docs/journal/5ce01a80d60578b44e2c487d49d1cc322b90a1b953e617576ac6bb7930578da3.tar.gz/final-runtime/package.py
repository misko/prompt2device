from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,io,shutil,datetime
R=Path('/tmp/rj45-carrier-render-approved-h71modud');P=R/'project';S=Path(__file__).parent;O=S.parent/'outputs';E=json.loads((S.parent/'envelope.json').read_text())
sha=lambda d:hashlib.sha256(d).hexdigest()
checks=[]
for x in E['input_packet']:
 p=R/x['path']; data=p.read_bytes();checks.append({'path':x['path'],'sha256':sha(data),'size':len(data),'matches':sha(data)==x['sha256'] and len(data)==x['size']})
assert all(x['matches'] for x in checks)
(S/'inputs-after.json').write_text(json.dumps({'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'count':len(checks),'bad':[],'subject':E['subject'],'records':checks},indent=2))
# Actual review measurements, method source and all completed review runtime records.
member_data={}
for p in sorted(S.iterdir()):
 if not p.is_file() or p.name.startswith(('package-evidence.','final-preflight.')):continue
 if p.suffix=='.gz':continue
 assert not p.is_symlink()
 member_data['review/'+p.name]=p.read_bytes()
viewed=json.loads((S/'viewed-images.json').read_text())
for x in viewed:
 if x['disposition']=='accepted':member_data['selected/'+x['path']]=(R/x['path']).read_bytes()
# Small selected provenance and source evidence, never an input tree or nested archive.
selected=['TASK.md','preflight.py','project/04_kicad/crow_audio_carrier_v1.kicad_pcb','project/04_kicad/refdes_waiver.json','project/03_src/floorplan.yaml','project/03_src/rules/model_registration.yaml','project/03_src/lib/3dmodels/provenance.md','project/02_parts/615008160221/primary-source-record.md','project/06_build/pre_route/model_registration.md','project/06_build/pre_route/model_registration.stage.json','project/06_build/pre_route/model_registration_bundle/bundle.json','project/06_build/pre_route/model_registration_bundle/model_registration_index.json','project/06_build/pre_route/orientation/orientation_receipt.json','project/06_build/pre_route/orientation-supplement/manifest.json']
selected += [str(p.relative_to(R)) for p in (R/'root-render').iterdir() if p.is_file()]
for x in json.loads((S/'bindings-and-geometry.json').read_text())['groups']:
 for name in ['bundle.json','model_registration_receipt.json','native_model_registration.md']:selected.append('project/06_build/pre_route/native_registration/'+x['id']+'/'+name)
for p in (P/'06_build/pre_route/orientation/renders').iterdir():
 if p.suffix in ['.json','.log']:selected.append(str(p.relative_to(R)))
for name in sorted(set(selected)):member_data['selected/'+name]=(R/name).read_bytes()
member_data['commission/envelope.json']=(S.parent/'envelope.json').read_bytes()
O.mkdir(exist_ok=True)
for name in ['report.md','evidence.json']:shutil.copyfile(S/name,O/name)
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as t:
 for name,data in sorted(member_data.items()):
  assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
manifest_members=[];seen=set()
with tarfile.open(archive,'r:gz') as t:
 for x in t.getmembers():
  assert x.isfile() and not x.issym() and not x.islnk() and x.name not in seen and '..' not in PurePosixPath(x.name).parts and not PurePosixPath(x.name).is_absolute()
  assert not x.name.endswith(('.tar','.tar.gz','.tgz','.zip'))
  seen.add(x.name);data=t.extractfile(x).read();assert len(data)==x.size and data==member_data[x.name]
  manifest_members.append({'path':x.name,'size':len(data),'sha256':sha(data)})
assert seen==set(member_data)
manifest={'schema':1,'subject':E['subject'],'archive_sha256':sha(archive.read_bytes()),'archive_size':archive.stat().st_size,'member_count':len(manifest_members),'members':manifest_members,'verification':'Every regular member reopened; no links, traversal, duplicate names, or nested archive. Review methods/raw evidence/runtime retained; final delivery command/preflight telemetry remains in scratch to avoid self-referential archives.'}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2))
(O/'result.json').write_text(json.dumps({'subject':E['subject'],'checks':{x:'PASS' for x in E['completion']['checks']},'unresolved':[]},indent=2))
print(json.dumps({'input_count':len(checks),'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'member_count':manifest['member_count'],'outputs':sorted(p.name for p in O.iterdir())},indent=2))
