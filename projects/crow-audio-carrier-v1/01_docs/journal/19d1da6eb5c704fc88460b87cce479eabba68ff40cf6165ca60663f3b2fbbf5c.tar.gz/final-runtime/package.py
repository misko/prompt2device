from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import sys,json,hashlib,tarfile,collections
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';T=P/'06_build/task_runs/rj45-carrier-placement-after-policy23';W=T/'scratch';O=T/'outputs';H=P/'06_build/handoffs/rj45-carrier-placement-after-policy23'
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet,writer_scope_receipt
from pipeline_runtime import _tree_snapshot,_changed_paths,_snapshot_sha256
E=TaskEnvelope.from_json((T/'envelope.json').read_text());ad=json.loads((T/'admission.json').read_text());before=json.loads((W/'inputs-before.json').read_text());v=verify_input_packet(E,P);assert v[0],v
hashf=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
protected=[]
for x in before['protected']:
 a=R/x['path'];protected.append({**x,'after_sha256':hashf(a),'after_size':a.stat().st_size,'unchanged':hashf(a)==x['sha256'] and a.stat().st_size==x['size']})
assert all(x['unchanged'] for x in protected)
after=_tree_snapshot(P,ignored=frozenset(ad['ignored']));changed=_changed_paths(ad['before'],after);scope=writer_scope_receipt(E.writer_scope,changed,before_sha256=_snapshot_sha256(ad['before']),after_sha256=_snapshot_sha256(after),protected_paths=tuple(sorted((E.output_path,ad['claim']))));assert scope['status']=='PASS',scope
(W/'inputs-and-scope-after.json').write_text(json.dumps({'packet_verified':v,'input_count':len(E.input_packet),'protected':protected,'writer_scope':scope,'changed_paths':changed},indent=2)+'\n')
assert hashf(P/'06_build/drc/gate.json')==hashf(W/'before/06_build/drc/gate.json')
for x in ['06_build/checkpoints/schematic.json','06_build/checkpoints/prelayout-inputs.json']:assert hashf(P/x)==hashf(W/'before'/x)
runtime=json.loads((W/'execution-runtime.json').read_text());census=json.loads((W/'current-component-census.json').read_text());drc=json.loads((W/'current-drc-classification.json').read_text())[0]
assert census['fitted_smd_by_layer']=={'F.Cu':306}
endpoints=[x for kind in ['violations','unconnected_items','schematic_parity'] for row in drc[kind] for x in row['endpoints']]
exact={}
paths=['03_tscircuit/build/circuit.json','03_tscircuit/manifest.yaml','04_kicad/crow_audio_carrier_v1.kicad_sch','04_kicad/crow_audio_carrier_v1.kicad_pcb','04_kicad/crow_audio_carrier_v1.kicad_pro','04_kicad/crow_audio_carrier_v1.kicad_dru','06_build/netlists/crow_audio_carrier_v1.net','06_build/drc/pre_route.json','06_build/drc/gate.json','06_build/route/r0.kicad_pcb','06_build/agent_handoff.yaml']
for f in paths:
 p=P/f
 if p.is_file():exact[f]={'sha256':hashf(p),'size':p.stat().st_size}
for n in ['current-component-census.json','current-pin-map.json','current-zone-map.json','current-drc-classification.json']:exact[str((W/n).relative_to(P))]={'sha256':hashf(W/n),'size':(W/n).stat().st_size}
stale=[]
for p in sorted((P/'06_build/pre_route/orientation').rglob('*')):
 if p.is_file():
  rel=str(p.relative_to(P));prior=ad['before'].get(rel);stale.append({'path':rel,'sha256':hashf(p),'size':p.stat().st_size,'status':'STALE; current orientation stage NOT RUN','snapshot_unchanged':rel not in changed})
assert all(x['snapshot_unchanged'] for x in stale)
(W/'stale-orientation-index.json').write_text(json.dumps(stale,indent=2)+'\n')
checks={'execution-recorded':'PASS','inputs-verified':'PASS','outputs-preserved':'PASS'}
evidence={'schema':1,'subject':E.subject.to_mapping(),'envelope_canonical_sha256':ad['envelope_sha256'],'domain_result':'FAIL','stopping_gate':'[4c2] P-DRC','setup_validation_failures':1,'engineering_launches':1,'runtime':runtime,'conductor_elapsed_s':23.042,'prescribed_command':json.loads((W/'execution-command.json').read_text()),'observer_correction':{'in_memory_only':True,'console_line_limit':18,'console_tail_lines':3,'authorization':'scratch/coordinator-clarification.txt in archive'},'source_preserved':{'frozen_inputs_verified':638,'protected_source_method_preimages_unchanged':len(protected),'checkpoint_unchanged':True,'writer_scope':scope},'census':census,'drc':drc,'endpoint_verification':{'total':len(endpoints),'uuid_net_verified':sum(x['uuid_net_verified'] for x in endpoints),'position_verified':sum(x['position_verified'] for x in endpoints),'zone_anchor_exceptions':sum(not x['position_verified'] for x in endpoints)},'artifact_identities':exact,'not_run':['P-LAND','tier route preflight','route prep r0','model registration','current connector orientation renders/approval','placement review','route import','route acceptance','release'],'compact_handoff':'BLOCKED intact stale gate.json; generation and validation logs retained','stale_orientation_files':stale,'mechanical_obligations':['Current human connector orientation approval owed; former approvals stale','J9 inboard mouth setback3.08mm needs current registered service evidence','Inherited candidate4 strict courtyard nine connector envelope overhangs1mm remain; ordinary P-OUT pad-based PASS does not waive these','Physical FULL23carrier/9pod deferred under accepted prototype policy; no physical PASS'],'limits':'FIRST-ARTICLE-ONLY / DO-NOT-ORDER; no route or release acceptance; CAR-TOP-ONLY-SMD4/4spent unchanged; LAYOUT001closed3/3 unchanged'}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n');(O/'result.json').write_text(json.dumps({'subject':E.subject.to_mapping(),'checks':checks,'unresolved':[]},indent=2)+'\n')
report=f'''# Carrier ordinary placement: P-DRC failure

MEASURED: one prescribed engineering continuation stopped at **[4c2] P-DRC**, subprocess rc1, conductor23.042s, shared outer23.179691s. Runtime {runtime['started_at']} to {runtime['finished_at']}. No second engineering launch occurred.

Before launch,638 frozen inputs,464 protected live source/method preimages, live pcb_flow handoff and schematic checkpoint7/7 passed. One wrapper observer validation failure occurred before runtime allocation or Popen (limit18/tail24). It remains counted and preserved. The coordinator authorized correction only in memory to tail3 for the still-unused first engineering dispatch; original argv, timeout600/outer660, subject, writer scope, deadline and native candidate budget remained unchanged.

## Exact resulting placement

PCB: `04_kicad/crow_audio_carrier_v1.kicad_pcb`, SHA256 **{census['board_sha256']}**. Dimensions154×100mm.333 fitted components on340 footprints,1043 fitted physical pads/1050 all pads. **306/306 fitted SMD on F.Cu;0 on B.Cu**, including all six fitted SMD excluded from position files. Native census does not restrict itself to automated BOM population. Zero routed tracks,11GND vias,87 zones. Generated canonical placement and existing prepared route r0 are distinct; r0 was not regenerated and remains stale.

Component census SHA256 `{hashf(W/'current-component-census.json')}`. Full1050-pad pin map SHA256 `{hashf(W/'current-pin-map.json')}`. Logical netlist SHA256 `{exact['06_build/netlists/crow_audio_carrier_v1.net']['sha256']}`. Full path/size/hash index is in evidence.json.

## Measured gates and stopping cause

S-COUNT passed333refs; P-PINMAP passed47 multi-pin refs/411 declared physical pin identities. Placement feasibility accepted7/7 (including explicit N-A rows), model coverage333/333, P-PADSEP and placement policy passed. Existing ordinary placement configuration grades pads: P-OUT tightest J11.11 margin1.32mm against0.15mm. P-CAP worst x36.5mm demand17/capacity272, ratio0.06 against0.5. Body envelope census333, zero reported overlaps. These results do not erase inherited candidate4 strict courtyard nine1mm connector-envelope overhang obligations or provide a new waiver.

Fresh `06_build/drc/pre_route.json` reports **1 violation,499 unconnected items,0 parity nodes**. The violation is `starved_thermal`: GND zone on F.Cu UUID `b8eb10fd-90c4-4416-8fa6-e153f4efd8dd` and C_VDDA2_10N pad2 UUID `1d0d56e9-17dd-44d2-8ed2-cd3041e3433b`, at90.52,71.50mm. Native refill reports actual1 spoke against configured minimum2. This is a thermal connection defect in generated placement, not an allowed unrouted connection. No local source or geometry correction was attempted; exact obstruction-level comparison remains the upstream owner's work.

All500 current rows and1000 endpoints are independently UUID/net matched to current native items. {sum(x['position_verified'] for x in endpoints)} positions match pad/via coordinates; {sum(not x['position_verified'] for x in endpoints)} zone entries preserve the distinct DRC edge position and zone anchor. Every499 open row names both exact endpoints and its net; that net has no routed track copper in current placement. Raw rows, full endpoint records and row-specific causes are preserved in evidence.json and archive `scratch/current-drc-classification.json`. No aggregate congestion explanation substitutes for endpoint evidence. Both retained old DRC reports and their499-row classifications are separately archived with the preceding mixed-side PCB.

## Unreached work and protected state

P-LAND, route tier preflight, route prep, model registration, connector orientation generation/approval, placement reviews, routing and route acceptance: **NOT RUN**. Existing orientation36files are unchanged and explicitly stale; no current views or human approval are claimed. J9's inherited3.08mm inboard mouth setback still needs current registered orientation/service evidence. Physical FULL23carrier/9pod stays deferred under the accepted first-article policy; SOURCE admission is not physical qualification.

Compact handoff generation refused because existing gate.json is stale; subsequent validation also refused. The gate file is byte-identical to its preimage, neither deleted nor restamped. Source/method464preimages and frozen638inputs remain unchanged; final exclusive writer scope PASS covers only16 allowed project changes. Provided preflight.py validates the exact five-output delivery after packaging; owning closure remains root's responsibility.

## Delivery

The output directory is `{O}`. It contains report.md, evidence.json, evidence-manifest.json, evidence.tar.gz and result.json. Delivery checks PASS mean the nonpassing domain result is honestly and completely preserved. The archive includes exact raw runtime log, setup failure and coordinator clarification, checkpoints, current and preceding PCB/DRC subjects, current pad/zone/census maps, changed generated artifacts, stale orientation evidence, report and result. Every regular member is independently reopened and its digest/size matched; symlinks, duplicate names, traversal and recursive archives are refused.

**FIRST-ARTICLE-ONLY / DO-NOT-ORDER. No route, release, order or physical PASS.** CAR-TOP-ONLY-SMD remains4/4spent and LAYOUT001closed3/3 unchanged. Root owns any later causal review and closure; no replacement or native candidate5 was launched.
'''
(O/'report.md').write_text(report)
# Archive exact forensic files and all changed generated subjects, without recursively packaging this archive.
member_sources={}
def add(path,name):
 assert path.is_file() and not path.is_symlink(),path
 assert name not in member_sources and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts,name
 member_sources[name]=path
for p in sorted(W.rglob('*')):
 if p.is_file() and p.name not in ['package.py']:add(p,'scratch/'+str(p.relative_to(W)))
for rel in sorted(set(list(changed)+paths)):
 p=P/rel
 if p.is_file():add(p,'project/'+rel)
for row in stale:add(P/row['path'],'stale-orientation/'+str(Path(row['path']).relative_to('06_build/pre_route/orientation')))
for p,name in [(T/'envelope.json','commission/envelope.json'),(H/'TASK.md','commission/TASK.md'),(H/'preflight.py','commission/preflight.py')]:add(p,name)
for name in ['report.md','evidence.json','result.json']:add(O/name,'delivery/'+name)
manifest=[]
with tarfile.open(O/'evidence.tar.gz','w:gz') as archive:
 for name,p in sorted(member_sources.items()):
  manifest.append({'path':name,'size':p.stat().st_size,'sha256':hashf(p)});archive.add(p,arcname=name,recursive=False)
seen=set();reopened=[]
with tarfile.open(O/'evidence.tar.gz','r:gz') as archive:
 for member in archive:
  assert member.isfile() and member.name not in seen and not PurePosixPath(member.name).is_absolute() and '..' not in PurePosixPath(member.name).parts
  seen.add(member.name);data=archive.extractfile(member).read();reopened.append({'path':member.name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
assert reopened==manifest
(O/'evidence-manifest.json').write_text(json.dumps({'schema':1,'archive_sha256':hashf(O/'evidence.tar.gz'),'archive_size':(O/'evidence.tar.gz').stat().st_size,'member_count':len(manifest),'members':manifest,'verification':{'independently_reopened':len(reopened),'regular_only':True,'duplicates':0,'traversal':0,'recursive_archive':False}},indent=2)+'\n')
print(json.dumps({'writer_scope':scope['status'],'changed_paths':len(changed),'protected_unchanged':len(protected),'archive_members':len(manifest),'archive_sha256':hashf(O/'evidence.tar.gz'),'output_dir':str(O)},indent=2))
