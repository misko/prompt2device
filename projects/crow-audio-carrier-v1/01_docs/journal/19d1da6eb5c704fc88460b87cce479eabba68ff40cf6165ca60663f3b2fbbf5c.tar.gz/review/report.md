# Carrier ordinary placement: P-DRC failure

MEASURED: one prescribed engineering continuation stopped at **[4c2] P-DRC**, subprocess rc1, conductor23.042s, shared outer23.179691s. Runtime 2026-09-13T20:57:59.029049Z to 2026-09-13T20:58:22.208752Z. No second engineering launch occurred.

Before launch,638 frozen inputs,464 protected live source/method preimages, live pcb_flow handoff and schematic checkpoint7/7 passed. One wrapper observer validation failure occurred before runtime allocation or Popen (limit18/tail24). It remains counted and preserved. The coordinator authorized correction only in memory to tail3 for the still-unused first engineering dispatch; original argv, timeout600/outer660, subject, writer scope, deadline and native candidate budget remained unchanged.

## Exact resulting placement

PCB: `04_kicad/crow_audio_carrier_v1.kicad_pcb`, SHA256 **fd6a30ebf5d5c95e2f04601fc5cab82913bdafdd224b1cd9bdcbee56240bcbab**. Dimensions154×100mm.333 fitted components on340 footprints,1043 fitted physical pads/1050 all pads. **306/306 fitted SMD on F.Cu;0 on B.Cu**, including all six fitted SMD excluded from position files. Native census does not restrict itself to automated BOM population. Zero routed tracks,11GND vias,87 zones. Generated canonical placement and existing prepared route r0 are distinct; r0 was not regenerated and remains stale.

Component census SHA256 `1a5b96f43341f3eb9ba1e5dbd828dc190315873699ec9e44d7d7f4685b4e204c`. Full1050-pad pin map SHA256 `1bd235251c456618d94a25481b84133743323af0039a5b9b13ec11ed2ac0de81`. Logical netlist SHA256 `3e19b46f8d39aa87e9fccd8f1694698620a31048ec78a958bfca544da4a301b3`. Full path/size/hash index is in evidence.json.

## Measured gates and stopping cause

S-COUNT passed333refs; P-PINMAP passed47 multi-pin refs/411 declared physical pin identities. Placement feasibility accepted7/7 (including explicit N-A rows), model coverage333/333, P-PADSEP and placement policy passed. Existing ordinary placement configuration grades pads: P-OUT tightest J11.11 margin1.32mm against0.15mm. P-CAP worst x36.5mm demand17/capacity272, ratio0.06 against0.5. Body envelope census333, zero reported overlaps. These results do not erase inherited candidate4 strict courtyard nine1mm connector-envelope overhang obligations or provide a new waiver.

Fresh `06_build/drc/pre_route.json` reports **1 violation,499 unconnected items,0 parity nodes**. The violation is `starved_thermal`: GND zone on F.Cu UUID `b8eb10fd-90c4-4416-8fa6-e153f4efd8dd` and C_VDDA2_10N pad2 UUID `1d0d56e9-17dd-44d2-8ed2-cd3041e3433b`, at90.52,71.50mm. Native refill reports actual1 spoke against configured minimum2. This is a thermal connection defect in generated placement, not an allowed unrouted connection. No local source or geometry correction was attempted; exact obstruction-level comparison remains the upstream owner's work.

All500 current rows and1000 endpoints are independently UUID/net matched to current native items. 1000 positions match pad/via coordinates; 0 zone entries preserve the distinct DRC edge position and zone anchor. Every499 open row names both exact endpoints and its net; that net has no routed track copper in current placement. Raw rows, full endpoint records and row-specific causes are preserved in evidence.json and archive `scratch/current-drc-classification.json`. No aggregate congestion explanation substitutes for endpoint evidence. Both retained old DRC reports and their499-row classifications are separately archived with the preceding mixed-side PCB.

## Unreached work and protected state

P-LAND, route tier preflight, route prep, model registration, connector orientation generation/approval, placement reviews, routing and route acceptance: **NOT RUN**. Existing orientation36files are unchanged and explicitly stale; no current views or human approval are claimed. J9's inherited3.08mm inboard mouth setback still needs current registered orientation/service evidence. Physical FULL23carrier/9pod stays deferred under the accepted first-article policy; SOURCE admission is not physical qualification.

Compact handoff generation refused because existing gate.json is stale; subsequent validation also refused. The gate file is byte-identical to its preimage, neither deleted nor restamped. Source/method464preimages and frozen638inputs remain unchanged; final exclusive writer scope PASS covers only16 allowed project changes. Provided preflight.py validates the exact five-output delivery after packaging; owning closure remains root's responsibility.

## Delivery

The output directory is `/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/task_runs/rj45-carrier-placement-after-policy23/outputs`. It contains report.md, evidence.json, evidence-manifest.json, evidence.tar.gz and result.json. Delivery checks PASS mean the nonpassing domain result is honestly and completely preserved. The archive includes exact raw runtime log, setup failure and coordinator clarification, checkpoints, current and preceding PCB/DRC subjects, current pad/zone/census maps, changed generated artifacts, stale orientation evidence, report and result. Every regular member is independently reopened and its digest/size matched; symlinks, duplicate names, traversal and recursive archives are refused.

**FIRST-ARTICLE-ONLY / DO-NOT-ORDER. No route, release, order or physical PASS.** CAR-TOP-ONLY-SMD remains4/4spent and LAYOUT001closed3/3 unchanged. Root owns any later causal review and closure; no replacement or native candidate5 was launched.
