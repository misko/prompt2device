from pathlib import Path
from datetime import datetime,timezone,timedelta
import sys,json,hashlib,shutil,tempfile
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
slug,lens=sys.argv[1:3];revision=sys.argv[3] if len(sys.argv)>3 else '';short='pod' if 'pod' in slug else 'carrier';name=f'rj45-{short}-{lens}-review'+('-'+revision if revision else '');D=Path(tempfile.mkdtemp(prefix=name+'-'));P=D/'project';live=R/'projects'/slug
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'))
from pre_route_review_check import digest,netlist_digest,design_rules_digest
for directory in ['02_parts','03_src','03_tscircuit/src']:
 shutil.copytree(live/directory,P/directory,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
files=['03_tscircuit/manifest.yaml','03_tscircuit/build/circuit.json','03_tscircuit/build/schematic.pdf','06_build/build_provenance.json','06_build/erc.rpt','06_build/erc_errors.rpt']
files += [str(p.relative_to(live)) for p in (live/'04_kicad').glob('*.kicad_sch')]
files += [str(p.relative_to(live)) for p in (live/'06_build/netlists').glob('*.net')]
files += [str(p.relative_to(live)) for p in (live/'06_build/checkpoints').glob('*.json')]
files += [str(p.relative_to(live)) for p in (live/'01_docs').glob('*') if p.is_file()]
files += [str(p.relative_to(live)) for folder in ['decisions','sourcing'] for p in (live/'01_docs'/folder).rglob('*') if p.is_file()]
files += [str(p.relative_to(live)) for p in (live/'06_build/verification').glob('connector_assembly*.json')]
files += [str(p.relative_to(live)) for p in (live/'06_build/sourcing').glob('*') if p.is_file()]
for rel in sorted(set(files)):
 src=live/rel
 if src.exists():
  dst=P/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
for rel in ['CLAUDE.md','skills/pcb-design/SKILL.md','skills/pcb-design/references/execution-runtime.md','skills/pcb-design/references/review-and-publication.md','skills/kicad-pcb/references/design-policies.md','skills/kicad-pcb/references/tscircuit-folder.md','skills/kicad-pcb/scripts/pre_route_review_check.py']:
 dst=D/'context'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/rel,dst)
for kind in ['topology','schematic_render']:
 dst=D/'previous-reviews'/f'pre-route_{kind}.md';dst.parent.mkdir(exist_ok=True);shutil.copy2(live/'08_reviews'/dst.name,dst)
# Only the immediately accepted subject is carried as comparison evidence.
for previous_lens in ['topology','readability']:
 prior_revision = 'top_only1' if short=='pod' else 'policy23'
 meta=json.loads((N/f'rj45-{short}-{previous_lens}-review-{prior_revision}-opened.json').read_text())
 assert json.loads((Path(meta['envelope']).parent/'attempt.json').read_text())['status']=='PASS'
 dst=D/'preceding-receipts'/previous_lens;dst.mkdir(parents=True)
 for filename in ['report.md','evidence-manifest.json']:
  shutil.copy2(Path(meta['output_dir'])/filename,dst/filename)
 shutil.copy2(Path(meta['envelope']).parent/'attempt.json',dst/'delivery-attempt.json')
 if previous_lens=='topology':
  old=Path(meta['project'])/'project';old_dst=D/'preceding-subject'
  for folder in ['03_tscircuit/src','06_build/netlists','03_src','02_parts']:
   shutil.copytree(old/folder,old_dst/folder)
  for rel in ['03_tscircuit/build/circuit.json','03_tscircuit/build/schematic.pdf','03_src/floorplan.yaml']+[str(x.relative_to(old)) for x in (old/'04_kicad').glob('*.kicad_sch')]:
   target=old_dst/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old/rel,target)
probe=json.loads((N/'rj45-none-schematic-availability-opened.json').read_text())
assert json.loads((Path(probe['envelope']).parent/'attempt.json').read_text())['status']=='PASS'
assert (live/'06_build/checkpoints/schematic.json').is_file()
for key in ['rj45-none-return-independent-review1-closeout-summary.json','none-reviewed-source-adoption.json','candidate6-completed-assessment.json']:
 dst=D/'decision-context'/key;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(N/key,dst)
shutil.copy2('/tmp/carrier-locator-implementation-availability-6c_4vwal/preflight.py',D/'preflight.py')
net=next((P/'06_build/netlists').glob('*.net'));parts=sorted((P/'02_parts').glob('*/part.yaml'))
hashes={'netlist_sha256':netlist_digest(net),'parts_sha256':hashlib.sha256(b''.join(p.relative_to(P).as_posix().encode()+b'\0'+p.read_bytes()+b'\0' for p in parts)).hexdigest(),'design_rules_sha256':design_rules_digest(P),'schematic_pdf_sha256':digest(P/'03_tscircuit/build/schematic.pdf'),'exact_netlist_sha256':digest(net),'circuit_json_sha256':digest(P/'03_tscircuit/build/circuit.json'),'kicad_schematic_sha256':digest(next((P/'04_kicad').glob('*.kicad_sch')))}
(D/'expected-subject.json').write_text(json.dumps(hashes,indent=2)+'\n')
now=datetime.now(timezone.utc);cut=now+timedelta(minutes=15);hard=now+timedelta(minutes=22)
(D/'TASK.md').write_text(f'''# Fresh independent {lens} schematic review after accepted return-source renewal

Review exact frozen project for {slug}; root sole live writer. Read copied canon,
current dossiers/source, new CircuitJSON/native schematic/netlist and actual PDF.
Preceding subject is immediately accepted carrier policy23 or pod top_only1,
with hash-bound delivery receipts; it does not accept current bytes.

Renewal follows independently accepted source corrections: carrier ADC2 return
pour reservation union, ADC1 west whole-capsule permission xmin89.35, shadow
CHASSIS mapping, two net rationales, polygon-aware test helper, and exact NONE
pad policy C_VDDA2_10N.2 plus shared generic consumer/contracts/tests/ADR0015.
All32source FULL targets plus existing native ADC49FULL retained; all widths,
clearance floors and authored electrical TSX intended unchanged. Source adoption
and independent review receipts pin the final nine-file correction; earlier
floor/rule source changes must also be captured by comparison with preceding
accepted schematic. Pod authored source is unchanged; exact313input owning
checkpoint refused only the changed shared generator, so ordinary renewal was
required. Independently derive actual source delta, rather than assuming these
summaries are complete. Source acceptance and native6 candidate progress are
separate from this schematic judgment.

Carrier isolated native6 cleared ordinary thermal DRC and remained306SMDtop;
its independent exact native return/locator-proof review is currently pending.
Live carrier PCB remains preceding native subject and is outside this schematic
review. Pod remains31SMDtop and current five-view human orientation pending.
No PCB generation, Save, prep, native property changes, router, live writes,
source edits, checkpoint restamps, children or commits during this review.

Topology lens: independently derive complete current component/pin/net inventory,
compare every prior/current identity and all changed source/rule rows, verify
native schematic vs current TSX using maintained electrical invariants, connector
pin assignments, shield isolation, ratings, explicit NC and source topology.
Carrier expected333first-power references must be measured; derive actual pod
population independently. Current conditional23locator exception membership must
stay exact; it cannot become effective without current atlas/render acceptance.
Do not rerun unrelated source unit suites or claim a board from schematic data.

Readability lens: inspect actual delivered PDF/images. Independently measure
all-page body pixel equality to preceding accepted PDF excluding only precisely
identified generated identity headers if useful. Inspect current headers and
integrated current pages plus every changed body. If equality is not proven,
perform full actual page coverage. Text extraction alone is not visual judgment.
Verify legible connector labels/wires/polarity/NC and any previous unresolved
finding; current carrier19pages expected must be counted. All7subject hashes
must be independently recomputed with frozen owning pre_route_review_check.py.

Factory Cat6A RJ45 cables carry custom analog/DC, NOT Ethernet/PoE; power-off
mating. Pins1/3/7power,2/6/8return,5audio+,4audio-,9/10shell. Carrier CHASSIS and
pod POD_SHIELD isolated from GND. Preserve classified ERC warnings; zero errors
is not all-severity clean. SOURCE PASS versus authentic FULL INCOMPLETE physical
obligations remain separate, FIRST-ARTICLE-ONLY/DO-NOT-ORDER. No order-stock,
physical mating, final routing/layout/fabrication/release acceptance here.

All subprocess engineering/native/imageanalysis work via finite direct-argv
pipeline_runtime.run_stage with explicit cwd/environment, raw logs and duration
retained under allocated scratch; /usr/bin/python3 -B. Root handles complete
external checkpoint authority verification separately. Frozen packet read-only;
verify every envelope input before/after, use providedpreflight after packaging.
Hostview_image permitted. Delivery failures must be reported honestly.

report.md flat fields: review_stage:pre-route,
review_kind:{'topology' if lens=='topology' else 'schematic_render'}, revieweridentity,
context:FRESH,date,design_verdict:SOUND|DEFECTIVE|INCOMPLETE,
order_verdict:DO-NOT-ORDER and exact7hashes from expected-subject.json.
State measured denominators, actual source changes, methods and remaining limits.
Five outputs exactly report.md,evidence.json,evidence-manifest.json,evidence.tar.gz,
result.json. evidence.json includes verdict, exact envelope subject, methods,
counts and findings. Archive actual methods/rawlogs/runtime/image/equivalence
proof; manifest archive_sha256/archive_size/member_count/members(path,size,sha256).
Reopen every regular member; no symlink/traversal/duplicate/recursivearchive.
result exactsubject with evidence-complete/inputs-verified/review-complete PASS
only for factually complete honest delivery, not engineering acceptance.
Work/actualFINALcutoff {cut.isoformat()}, hard {hard.isoformat()},0replacements.
Return actual FINAL promptly. Root closes/reverifies before current adoption.
''')
items=[]
for p in sorted(D.rglob('*')):
 if p.is_file():
  b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(D).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
s=subject_identity('native_schematic_review',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
e=TaskEnvelope(schema=2,task_id=name,stage_id='KICAD-SCHEMATIC',run_id=name,subject=s,executor='reviewer',execution_class='review_wait',recommended_agent_role='judgment',agent_role='judgment',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']})
o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),agent_id=f'/root/carrier_rj45_native_{short}_{lens}'+('_'+revision.replace('-','_') if revision else ''),work_cutoff=cut.isoformat());(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o));print(len(items),'frozen files')
