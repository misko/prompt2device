# Fresh independent topology schematic review after accepted return-source renewal

Review exact frozen project for crow-audio-carrier-v1; root sole live writer. Read copied canon,
current dossiers/source, new CircuitJSON/native schematic/netlist and actual PDF.
Preceding subject is immediately accepted carrier policy23 or pod top_only1,
with hash-bound delivery receipts; it does not accept current bytes.

Renewal follows independently accepted source corrections: carrier ADC2 return
pour reservation union, ADC1 west whole-capsule permission xmin89.35, shadow
CHASSIS mapping, two net rationales, polygon-aware test helper, and exact NONE
pad policy C_VDDA2_10N.2 plus shared generic consumer/contracts/tests/ADR0015.
All32source FULL targets plus existing native ADC49FULL retained; all widths,
clearance floors and authored electrical TSX intended unchanged. Source adoption
and independent review receipts pin the final nine-file correction; earlier
floor/rule source changes must also be captured by comparison with preceding
accepted schematic. Pod authored source is unchanged; exact313input owning
checkpoint refused only the changed shared generator, so ordinary renewal was
required. Independently derive actual source delta, rather than assuming these
summaries are complete. Source acceptance and native6 candidate progress are
separate from this schematic judgment.

Carrier isolated native6 cleared ordinary thermal DRC and remained306SMDtop;
its independent exact native return/locator-proof review is currently pending.
Live carrier PCB remains preceding native subject and is outside this schematic
review. Pod remains31SMDtop and current five-view human orientation pending.
No PCB generation, Save, prep, native property changes, router, live writes,
source edits, checkpoint restamps, children or commits during this review.

Topology lens: independently derive complete current component/pin/net inventory,
compare every prior/current identity and all changed source/rule rows, verify
native schematic vs current TSX using maintained electrical invariants, connector
pin assignments, shield isolation, ratings, explicit NC and source topology.
Carrier expected333first-power references must be measured; derive actual pod
population independently. Current conditional23locator exception membership must
stay exact; it cannot become effective without current atlas/render acceptance.
Do not rerun unrelated source unit suites or claim a board from schematic data.

Readability lens: inspect actual delivered PDF/images. Independently measure
all-page body pixel equality to preceding accepted PDF excluding only precisely
identified generated identity headers if useful. Inspect current headers and
integrated current pages plus every changed body. If equality is not proven,
perform full actual page coverage. Text extraction alone is not visual judgment.
Verify legible connector labels/wires/polarity/NC and any previous unresolved
finding; current carrier19pages expected must be counted. All7subject hashes
must be independently recomputed with frozen owning pre_route_review_check.py.

Factory Cat6A RJ45 cables carry custom analog/DC, NOT Ethernet/PoE; power-off
mating. Pins1/3/7power,2/6/8return,5audio+,4audio-,9/10shell. Carrier CHASSIS and
pod POD_SHIELD isolated from GND. Preserve classified ERC warnings; zero errors
is not all-severity clean. SOURCE PASS versus authentic FULL INCOMPLETE physical
obligations remain separate, FIRST-ARTICLE-ONLY/DO-NOT-ORDER. No order-stock,
physical mating, final routing/layout/fabrication/release acceptance here.

All subprocess engineering/native/imageanalysis work via finite direct-argv
pipeline_runtime.run_stage with explicit cwd/environment, raw logs and duration
retained under allocated scratch; /usr/bin/python3 -B. Root handles complete
external checkpoint authority verification separately. Frozen packet read-only;
verify every envelope input before/after, use providedpreflight after packaging.
Hostview_image permitted. Delivery failures must be reported honestly.

report.md flat fields: review_stage:pre-route,
review_kind:topology, revieweridentity,
context:FRESH,date,design_verdict:SOUND|DEFECTIVE|INCOMPLETE,
order_verdict:DO-NOT-ORDER and exact7hashes from expected-subject.json.
State measured denominators, actual source changes, methods and remaining limits.
Five outputs exactly report.md,evidence.json,evidence-manifest.json,evidence.tar.gz,
result.json. evidence.json includes verdict, exact envelope subject, methods,
counts and findings. Archive actual methods/rawlogs/runtime/image/equivalence
proof; manifest archive_sha256/archive_size/member_count/members(path,size,sha256).
Reopen every regular member; no symlink/traversal/duplicate/recursivearchive.
result exactsubject with evidence-complete/inputs-verified/review-complete PASS
only for factually complete honest delivery, not engineering acceptance.
Work/actualFINALcutoff 2026-09-14T00:37:10.227958+00:00, hard 2026-09-14T00:44:10.227958+00:00,0replacements.
Return actual FINAL promptly. Root closes/reverifies before current adoption.
