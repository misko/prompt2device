from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,io
s=Path(__file__).parent;t=s.parent;p=s.parents[3];o=t/'outputs';o.mkdir(exist_ok=True)
def read(name):return json.loads((s/name).read_text())
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
envelope=json.loads((t/'envelope.json').read_text());runtime=read('runtime.json');sub=read('subjects.json');classification=read('drc-classification.json');scope=read('writer-scope.json');orient=json.loads((p/'06_build/pre_route/orientation/orientation_receipt.json').read_text());full=json.loads((p/'06_build/verification/connector_assembly_full_gate.json').read_text())
rawgate=json.loads((p/'06_build/drc/gate.json').read_text())
for cat in ['violations','unconnected_items','schematic_parity']:assert rawgate[cat]==json.loads((p/'06_build/drc/pre_route.json').read_text())[cat]
write(s/'preserved-gate-classification-binding.json',{'gate_sha256':sha((p/'06_build/drc/gate.json').read_bytes()),'pre_route_sha256':classification['report_sha256'],'all_three_native_row_arrays_identical':True,'classification_path':'task/scratch/drc-classification.json','freshness':'Historical gate remains stale by normal owning mtime gate; identical native rows do not renew it.'})
# Verify the receipt's full image/producer census without rerendering or approving.
for label in ['evidence','producer_evidence']:
 for name,expected in orient[label].items():assert sha((p/'06_build/pre_route/orientation'/name).read_bytes())==expected,(label,name)
write(s/'orientation-bytes-verification.json',{'status':'PASS','subject_sha256':orient['subject_sha256'],'review_images':len(orient['evidence']),'producer_artifacts':len(orient['producer_evidence']),'machine_rows':len(orient['measurements']),'approval':'STALE; no current user approval exists'})
not_run=['placement pre-route review after P-ORIENT','route_import','route_taps','stitch','post-route critical-route check','post-route rules audit','post-route DRC','route acceptance','release/order']
# Archive each complete current output, plus unchanged evidence consumed by this run.
files={}
def add(q,name):
 assert q.is_file() and not q.is_symlink(),str(q)
 assert name not in files or files[name]==q,name
 assert not (name.endswith('.tar.gz') or name.endswith('.tgz')),name
 files[name]=q
for name in read('changed-paths.json'):
 q=p/name
 if q.exists():add(q,'project/'+name)
for name in sub['files']:add(p/name,'project/'+name)
for name in ['04_kicad/crow_audio_carrier_v1.kicad_pro','04_kicad/crow_audio_carrier_v1.kicad_dru','06_build/agent_handoff.yaml','06_build/checkpoints/prelayout.json','06_build/checkpoints/prelayout-inputs.json','06_build/checkpoints/schematic.json','06_build/verification/connector_assembly_contract.json','06_build/verification/connector_assembly_full_gate.json','06_build/verification/connector_assembly_source_gate.json','06_build/verification/model_coverage.json','06_build/verification/placement_routability_receipt.json','03_src/rules/model_registration.yaml','03_src/floorplan.yaml','03_src/route.yaml','08_reviews/connector_orientation.yaml','08_reviews/pre-route_schematic_render.md','08_reviews/pre-route_topology.md']:
 add(p/name,'project/'+name)
for name in ['06_build/pre_route/orientation','06_build/pre_route/model_registration_bundle','06_build/verification/pipeline/bundles/placement_feasibility']:
 for q in (p/name).rglob('*'):
  if q.is_file():add(q,'project/'+q.relative_to(p).as_posix())
for q in s.rglob('*'):
 if q.is_file() and q.name not in ['package.py','final-preflight.json','final-preflight.log']:add(q,'task/scratch/'+q.relative_to(s).as_posix())
add(t/'envelope.json','task/envelope.json')
for name in ['TASK.md','preflight.py','beacon.md','flow.yaml','journal-tail.md']:
 add(p/'06_build/handoffs/rj45-carrier-placement-after-orientation1'/name,'task/input/'+name)
members=[]
with tarfile.open(o/'evidence.tar.gz','w:gz',compresslevel=6) as ar:
 for name,q in sorted(files.items()):
  data=q.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;ar.addfile(info,io.BytesIO(data));members.append({'path':name,'size':len(data),'sha256':sha(data)})
# Independent reopening of every exact regular member and complete membership.
actual=[];seen=set()
with tarfile.open(o/'evidence.tar.gz','r:gz') as ar:
 for m in ar:
  n=PurePosixPath(m.name);assert m.isfile() and not n.is_absolute() and '..' not in n.parts and m.name not in seen,m.name;seen.add(m.name);f=ar.extractfile(m);data=f.read();assert len(data)==m.size;actual.append({'path':m.name,'size':len(data),'sha256':sha(data)})
assert actual==members
manifest={'schema':1,'archive_sha256':sha((o/'evidence.tar.gz').read_bytes()),'archive_size':(o/'evidence.tar.gz').stat().st_size,'member_count':len(members),'members':members,'verification':{'status':'PASS','every_regular_member_reopened':True,'symlinks':0,'duplicate_paths':0,'traversal_paths':0,'recursive_archives':0}}
write(o/'evidence-manifest.json',manifest)
evidence={'schema':1,'subject':envelope['subject'],'envelope_canonical_sha256':'c2af48462513a5cb40755bcfde2e7acd36a4054fa9a69eaa89ef15111f4a79ba','input_count':636,'domain_result':'BLOCKED_AT_P_ORIENT_HUMAN_APPROVAL','stopping_gate':{'id':'P-ORIENT','driver_position':'[5e]','machine':'9/9 PASS','reason':'approval subject or denominator is stale','subject_sha256':orient['subject_sha256'],'current_user_approval':False},'command':read('command.json'),'runtime':runtime,'inner_runtime':json.loads((p/'06_build/pipeline_state/rj45_renewed_placement.json').read_text()),'native':{k:v for k,v in sub.items() if k not in ['components','pins']},'full_native_classification':classification,'connector_full_findings':full,'stage_exclusions':not_run,'drc_exclusions':classification['ignored_checks'],'protected_source':{'status':'PASS','frozen_live_files':618,'record':'task/scratch/protected-final.json'},'writer_scope':scope,'handoff':read('handoff-state.json'),'archive':{k:manifest[k] for k in ['archive_sha256','archive_size','member_count']},'delivery_vs_domain':'Completion checks grade complete honest delivery only; engineering remains blocked. No approval, physical FULL PASS, route acceptance, or release authority is supplied.'}
write(o/'evidence.json',evidence)
report=f'''# Carrier normal placement continuation — actual stopping gate

One authorized normal continuation stopped at **[5e] P-ORIENT**, rc **1**. Machine orientation **9/9 PASS**, seven full-scene renders completed, and eleven representative review images are preserved. The owning gate reports **approval subject or denominator is stale**. No current user orientation approval exists. Current orientation subject: `{orient['subject_sha256']}`.

Exact command is in evidence.json and task/scratch/command.json. Inner subprocess time **135.351 s**, outer shared pipeline_runtime time **{runtime['elapsed_s']:.6f} s**, from {runtime['started_at']} to {runtime['finished_at']}; inner timeout600s/budget600s, outer timeout660s. One attempt, zero retries. All78490raw output bytes/1164lines preserved; console suppression was1064lines, not evidence deletion.

Initial canonical envelope and636/636inputs, live compact handoff, and7/7schematic checkpoint bindings passed. The normal driver additionally verified612/612input bindings and11/11prelayout bindings; schematic PR-REVIEW SOUND, count333, spoke8/8, P-PINMAP, P-FEASIBILITY, model coverage333/333, pad separation, placement policy, P-LAND, tier preflight and model registration6/6 passed. Source physical deferral remains explicit: connector FULL23findings, all preserved, not physical qualification PASS. Tier preflight's2warnings and all native/runtime exclusions remain in raw evidence. Deterministic route preparation ran1.47s; it is not route import or routing acceptance.

Native component count333; pin count985 =943connected +42NC. Manufacturer Q_IN drain leads6/7/8 explicitly alias to5; this is not an unaliased package-lead denominator. Canonical component table SHA256 `{sub['component_table_sha256']}`; canonical native pin table SHA256 `{sub['native_pin_table_sha256']}`. Full exact rows and normalization are in task/scratch/subjects.json.

PCB SHA256 `{classification['board_sha256']}`. Native schematic SHA256 `{sub['files']['04_kicad/crow_audio_carrier_v1.kicad_sch']['sha256']}`. Netlist SHA256 `{sub['files']['06_build/netlists/crow_audio_carrier_v1.net']['sha256']}`. Fresh pre_route DRC SHA256 `{classification['report_sha256']}`.

Fresh native DRC is **0violations /499unconnected /0parity**. Every499rawrow is retained and independently classified by its exact endpoints; all998UUID/net identities and992pad/via positions match the exact saved native board, with6zone anchors and nearest-copper report points retained distinctly. This board has0tracks/11seedvias,340footprints/1050native pads/81zones. Each remaining connection is open on the unrouted placement; neither congestion nor routing feasibility is inferred. The stale gate's three raw native row arrays are identical and bind to this full classification, but that does not renew its freshness.

NOT RUN: {', '.join(not_run)}. No TSX regeneration, source/config/shared gate edit, checkpoint restamp, stale route import, camera search, or unreviewed routing occurred. LAYOUT001closed3/3 is unchanged. No physical service or release authority is asserted.

The compact handoff fails normal validation: source hash changed and existing DRC gate is stale after generated input mtimes changed. Its gate.json remains untouched; handoff generation was not run to manufacture freshness. Source/method preservation is618/618PASS and exclusive writer scopePASS,72changed paths all allowed. Status beacon and placement journal reflect the actual stop.

Five-file handback lives at `{o}`. The archive preserves current output bytes, both raw runtime records, every full orientation render and representative, native subjects and classifications, frozen envelope and source-preservation/scope evidence. All{len(members)}regular archive members were independently reopened and hashed; no symlink, duplicate path, traversal, or recursive archive. Archive SHA256 `{manifest['archive_sha256']}`; size{manifest['archive_size']}bytes. Completion PASS means complete honest delivery; domain result remains blocked at the owning human approval gate. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.
'''
(o/'report.md').write_text(report)
write(o/'result.json',{'subject':envelope['subject'],'checks':{x:'PASS' for x in envelope['completion']['checks']},'unresolved':[]})
print('PACKAGE PASS',manifest['member_count'],manifest['archive_size'],manifest['archive_sha256'])
