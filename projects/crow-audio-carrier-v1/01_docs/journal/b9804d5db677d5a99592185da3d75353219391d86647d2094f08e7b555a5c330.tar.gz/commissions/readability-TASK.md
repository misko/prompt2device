# Fresh independent readability schematic review after exact mounting-side correction

Review exact frozen project for crow-audio-carrier-v1; root sole live writer. Read copied canon,
current dossiers/source, new CircuitJSON/native schematic/netlist and actual PDF.
Preceding subject is the immediately accepted carrier none1 with hash-bound
fresh review deliveries. It does not accept current bytes.

Renewal follows independently accepted one-field source correction:
03_src/rules/model_registration.yaml, group littelfuse-1812l035-native-package,
F1-F8 mount_side back to front. All other source bytes and electrical intent
are intended unchanged. Independently derive complete delta against the
preceding accepted subject. The current canonical carrier native already has
all306 fitted SMD top, zero bottom, and ordinary placement DRC0/499/0.
This source correction resolves a stale registration declaration; it does not
change the schematic electrical topology or authorize any routing claim.
Previous nine-file NONE source correction was already accepted in none1.
Source acceptance and registration coupon proof are separate from this review.
No PCB generation, Save, prep, native property changes, router, live writes,
source edits, checkpoint restamps, children or commits during this review.
Current carrier/pod orientation human approvals remain separate obligations.

Topology lens: independently derive complete current component/pin/net inventory,
compare every prior/current identity and all changed source/rule rows, verify
native schematic vs current TSX using maintained electrical invariants, connector
pin assignments, shield isolation, ratings, explicit NC and source topology.
Carrier expected333first-power references must be measured; derive actual pod
population independently. Current conditional23locator exception membership must
stay exact; it cannot become effective without current atlas/render acceptance.
Do not rerun unrelated source unit suites or claim a board from schematic data.

Readability lens: inspect actual delivered PDF/images. Independently measure
all-page body pixel equality to preceding accepted PDF excluding only precisely
identified generated identity headers if useful. Inspect current headers and
integrated current pages plus every changed body. If equality is not proven,
perform full actual page coverage. Text extraction alone is not visual judgment.
Verify legible connector labels/wires/polarity/NC and any previous unresolved
finding; current carrier19pages expected must be counted. All7subject hashes
must be independently recomputed with frozen owning pre_route_review_check.py.

Factory Cat6A RJ45 cables carry custom analog/DC, NOT Ethernet/PoE; power-off
mating. Pins1/3/7power,2/6/8return,5audio+,4audio-,9/10shell. Carrier CHASSIS and
pod POD_SHIELD isolated from GND. Preserve classified ERC warnings; zero errors
is not all-severity clean. SOURCE PASS versus authentic FULL INCOMPLETE physical
obligations remain separate, FIRST-ARTICLE-ONLY/DO-NOT-ORDER. No order-stock,
physical mating, final routing/layout/fabrication/release acceptance here.

All subprocess engineering/native/imageanalysis work via finite direct-argv
pipeline_runtime.run_stage with explicit cwd/environment, raw logs and duration
retained under allocated scratch; /usr/bin/python3 -B. Root handles complete
external checkpoint authority verification separately. Frozen packet read-only;
verify every envelope input before/after, use providedpreflight after packaging.
Hostview_image permitted. Delivery failures must be reported honestly.

report.md flat fields: review_stage:pre-route,
review_kind:schematic_render, revieweridentity,
context:FRESH,date,design_verdict:SOUND|DEFECTIVE|INCOMPLETE,
order_verdict:DO-NOT-ORDER and exact7hashes from expected-subject.json.
State measured denominators, actual source changes, methods and remaining limits.
Five outputs exactly report.md,evidence.json,evidence-manifest.json,evidence.tar.gz,
result.json. evidence.json includes verdict, exact envelope subject, methods,
counts and findings. Archive actual methods/rawlogs/runtime/image/equivalence
proof; manifest archive_sha256/archive_size/member_count/members(path,size,sha256).
Reopen every regular member; no symlink/traversal/duplicate/recursivearchive.
result exactsubject with evidence-complete/inputs-verified/review-complete PASS
only for factually complete honest delivery, not engineering acceptance.
Work/actualFINALcutoff 2026-09-14T01:42:21.175039+00:00, hard 2026-09-14T01:49:21.175039+00:00,0replacements.
Return actual FINAL promptly. Root closes/reverifies before current adoption.
