from pathlib import Path
from collections import Counter
import json,hashlib,pcbnew as k
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path('/tmp/carrier-rj45-20260912');P=R/'projects/crow-audio-carrier-v1';D=N/'front-registration-handoff-native';bp=P/'04_kicad/crow_audio_carrier_v1.kicad_pcb';gp=P/'06_build/drc/gate.json'
assert bp.read_bytes()==(D/'board.kicad_pcb').read_bytes();before=json.loads((D/'placement-baseline.json').read_text());raw=json.loads(gp.read_text());b=k.LoadBoard(str(bp));objects={};rows=[];positions=0
for f in b.GetFootprints():
 for p in f.Pads():objects[p.m_Uuid.AsString()]=(p,'pad',f.GetReference(),p.GetNumber())
for t in b.GetTracks():objects[t.m_Uuid.AsString()]=(t,'via' if t.GetClass()=='PCB_VIA' else 'track',None,None)
for z in b.Zones():objects[z.m_Uuid.AsString()]=(z,'zone',None,None)
key=lambda row:json.dumps(row,sort_keys=True)
for collection in ['violations','unconnected_items','schematic_parity']:
 assert Counter(map(key,before.get(collection,[])))==Counter(map(key,raw.get(collection,[]))),collection
 for index,row in enumerate(raw.get(collection,[])):
  assert collection=='unconnected_items';ends=[]
  for item in row['items']:
   o,kind,ref,pin=objects[item['uuid']];net=o.GetNetname();assert '['+net+']' in item['description'];xy={'x':k.ToMM(o.GetPosition().x),'y':k.ToMM(o.GetPosition().y)}
   if kind!='zone':assert all(abs(xy[a]-item['pos'][a])<=0.000002 for a in ['x','y']);positions+=1
   ends.append({'uuid':item['uuid'],'kind':kind,'ref':ref,'pin':pin,'net':net,'native_anchor_mm':xy,'reported_position_mm':item['pos']})
  assert len({e['net'] for e in ends})==1
  rows.append({'collection':collection,'index':index,'raw':row,'endpoints':ends,'cause':'Exact same-net pad/via/zone endpoints have no completed copper path on this unprepared placement. Same native row as complete accepted-source placement classification; routing owed. Zone report point is not treated as unique island or anchor.'})
counts={c:len(raw.get(c,[])) for c in ['violations','unconnected_items','schematic_parity']};assert counts=={'violations':0,'unconnected_items':499,'schematic_parity':0}
result={'board_sha256':hashlib.sha256(bp.read_bytes()).hexdigest(),'report_sha256':hashlib.sha256(gp.read_bytes()).hexdigest(),'counts':counts,'rows':rows,'native_endpoint_records':sum(len(x['endpoints']) for x in rows),'positions_checked':positions,'prior_placement_raw_multiset_exact':True,'scope':'Current unchanged top-only native board, refreshed complete all-severity/refill/parity DRC for upcoming normal handoff; not routing or pending whole placement acceptance.'}
(D/'classification.json').write_text(json.dumps(result,indent=2)+'\n');(D/'current-gate.json').write_bytes(gp.read_bytes());print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
