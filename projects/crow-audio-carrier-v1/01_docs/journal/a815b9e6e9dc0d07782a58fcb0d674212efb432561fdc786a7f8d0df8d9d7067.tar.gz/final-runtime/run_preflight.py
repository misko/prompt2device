#!/usr/bin/env python3
import json
import os
import sys
from pathlib import Path

SCRIPTS = Path("/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts")
sys.path.insert(0, str(SCRIPTS))
from pipeline_runtime import run_stage

root = Path("/tmp/rj45-pin-carrier-headers-toponly1-b55dbbbo")
run = root / "06_build/task_runs/rj45-pin-carrier-headers-toponly1"
scratch = run / "scratch"
spec = {"id": "pin_review_delivery_preflight", "work_class": "local", "timeout_s": 90, "produces": []}
result = run_stage(
    spec,
    ["/usr/bin/python3", "-B", str(root / "preflight.py"), str(run / "envelope.json")],
    log_path=scratch / "runtime-preflight.log",
    cwd=root,
    env=dict(os.environ),
    console=None,
    run_id="pin-review-preflight",
)
(scratch / "preflight-outcome.json").write_text(json.dumps(result.to_mapping(), indent=2, sort_keys=True) + "\n")
if result.status != "PASS":
    raise SystemExit(1)
