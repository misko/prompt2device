review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent /root/rj45_pin_carrier_tvs_mountedframe1
context: FRESH
design_verdict: INCOMPLETE
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

Coverage is limited to D_IN and D_QIN_GS in this frozen commission. This is not whole-board acceptance. Board/parts/design-rule hashes above are immutable subject metadata, not independently reviewed board conclusions.

D_IN — VERDICT: PASS

Primary: Littelfuse SMBJ series, revised JC.07/04/25 v4, PDF SHA-256 d7df155be4b1f612085401e8c946f065e284d65a0e7de22b9225a7b73946e51b. Inspected page 1 Functional Diagram and package illustrations, page 2 Electrical Characteristics exact SMBJ15A row, page 5 Dimensions / DO-214AA (SMB J-Bend), and page 6 Part Marking System / Part Numbering System figures.

D_IN pin 1 (K): expect the banded terminal of the unidirectional device on the positive protected rail; observe west pad at component-top (-2.15,0), native (30.649999,82.3), K on 12V_PROTECTED. Matches the page 5 marked-top drawing with band left.
D_IN pin 2 (A): expect the opposite terminal toward ground for a positive-rail shunt suppressor; observe east pad (+2.15,0), native (34.949999,82.3), A on GND. PASS.
D_IN package/count: expect two opposed physical terminals and no EP; measured 2 native pads, 2 unique artifact pad numbers, 2 physical identities (K,A), 0 EP, 0 aliases/identity collapse. Each pad is 2.5 x 2.3 mm; center separation 4.3 mm, resulting inner gap 1.8 mm. This covers the two opposed J-bend terminal locations and satisfies the manufacturer's suggested pad minimum widths/heights (2.16/2.26 mm) and maximum gap (2.74 mm).
D_IN view/winding: front-mounted F.Cu; dossier explicitly uses component-top +x right/+y down, no front reflection. The marked package surface is top, not the side section or solder-pad drawing. Page 6 band-at-top marking image rotates into page 5 band-at-left; no mirror is required. Manufacturer provides K/A identities rather than numeric pin labels; dossier artifact pad 1 aliases the banded cathode, pad 2 the anode. There is no pin-1 corner or meaningful winding for two collinear terminals; reported n/a is correct. No fused physical aliases are needed.
D_IN electrical scope: 15 V standoff supports the named 12 V rail connection at pin-review level. Surge energy, rail tolerances, downstream withstand and clamp sizing are not established by this pin dossier and are outside this limited mapping verdict.

D_QIN_GS — VERDICT: QUESTION

Primary: Diodes Incorporated BZT52C2V0–BZT52C51, DS18004 Rev. 38-2, October 2017, PDF SHA-256 0fbd7d137524820f0160594065cbceb8c6b3188757c328416d08fceb7418202f. Inspected page 1 explicit Top View / Marking Information and Mechanical Data cathode-band statement, page 2 exact BZT52C12 electrical row, and page 4 SOD123 Package Outline Dimensions / Suggested Pad Layout figure images.

D_QIN_GS pin 1 (K): expect banded SOD123 cathode; observe west pad (-1.65,0), native (40.75,71), K on 12V_PROTECTED. Physical identity and package orientation match the page 1 left-band marking image.
D_QIN_GS pin 2 (A): expect opposite SOD123 anode; observe east pad (+1.65,0), native (44.05,71), A on Q_IN_GATE. Physical identity matches.
D_QIN_GS package/count: expect two opposing physical terminals and no EP; measured 2 native pads, 2 unique artifact pad numbers, 2 physical identities (K,A), 0 EP, 0 aliases/identity collapse. Pads measure 0.9 x 1.2 mm, center separation 3.3 mm. Manufacturer suggested pads are 0.9 x 0.95 mm with 4.05 mm outside span, hence 3.15 mm center separation. Observed centers are 0.075 mm farther outward per pad and still overlap the lead locations in the 3.55–3.85 mm overall-terminal envelope. This difference is not a pin identity or package mismatch.
D_QIN_GS view/winding: front-mounted F.Cu; explicit component-top convention requires no reflection. Compare to the explicit manufacturer Top View by rotation only. No bottom-view pinout was substituted. Numeric 1/2 are artifact designations for K/A, not manufacturer numbered pins. Two collinear terminals have no winding; dossier n/a is correct.
D_QIN_GS electrical QUESTION: with K=12V_PROTECTED and A=Q_IN_GATE the zener limits the rail-above-gate differential by reverse breakdown (BZT52C12: 11.4–12.7 V at 5 mA), and the opposite differential by forward conduction. This can be appropriate for a negative gate-to-source clamp, but the dossier does not establish Q_IN's source net, device polarity, or intended gate excursion. Required missing fact: confirm that Q_IN source is 12V_PROTECTED and Q_IN is intended to operate with its gate below that source (or supply the intended clamp polarity and actual source net). Without that fact, function-to-net correctness remains unproven; no electrical defect is asserted.

Instance symmetry: exactly one commissioned instance of each different part; no same-part instance pair exists to compare. Both preserve the same K=pad 1 west / A=pad 2 east physical convention. Their anodes intentionally name different net types; appropriateness of D_QIN_GS's gate connection remains the question above.

Methods: actual datasheet figure images inspected before dossier comparison; exact input hashes verified before/after; native counts measured from all supplied table rows. Evidence includes inspected page PNGs, native dossiers, extracted primary text, independent pre-comparison derivation, scripts, combined subprocess stdout/stderr and runtime records. Primary PDFs remain digest-bound in the frozen packet and are not duplicated in the archive. Delivery PASS means complete honest handback, not engineering approval. All commissioned refs were examined; one unresolved engineering question makes this domain INCOMPLETE.
