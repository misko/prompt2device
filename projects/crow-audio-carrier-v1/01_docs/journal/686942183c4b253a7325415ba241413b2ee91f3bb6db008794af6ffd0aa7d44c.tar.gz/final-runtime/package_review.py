from pathlib import Path, PurePosixPath
import sys,json,hashlib,tarfile,io,re,shutil
sys.path.insert(0,str(Path(__file__).parent))
from review_runtime import ROOT,SCRATCH,verify
RUN=ROOT/"06_build/task_runs/rj45-pin-carrier-tvs-mountedframe1"
OUT=RUN/"outputs"
OUT.mkdir(exist_ok=True)
e=json.loads((RUN/"envelope.json").read_text())
verify("inputs-after")
for name in ["TASK.md","pin-review-protocol.md","preflight.py"]:
    shutil.copyfile(ROOT/name,SCRATCH/name)
shutil.copyfile(RUN/"envelope.json",SCRATCH/"envelope.json")
counts={}
for ref in ["D_IN","D_QIN_GS"]:
    rows=[line.split("|")[1:-1] for line in (SCRATCH/(ref+".md")).read_text().splitlines() if re.match(r"^\| [12] \|",line)]
    counts[ref]={"native_pad_rows":len(rows),"unique_pad_numbers":len(set(r[0].strip() for r in rows)),"physical_terminal_identities":len(set(r[4].strip() for r in rows)),"exposed_pads":0,"aliases":0,"same_part_instances_in_commission":1,"pads":[{"pad":r[0].strip(),"component_top_mm":r[1].strip(),"side":r[2].strip(),"size_mm":r[3].strip(),"function":r[4].strip(),"net":r[5].strip(),"native_mm":r[6].strip()} for r in rows]}
    assert counts[ref]["native_pad_rows"]==counts[ref]["physical_terminal_identities"]==2
(SCRATCH/"measured-counts.json").write_text(json.dumps(counts,indent=2))
methods={"reviewer":"/root/rj45_pin_carrier_tvs_mountedframe1 (actual fresh agent)","context":"FRESH","engineering_sources":"Only frozen protocol, exact SHA-selected PDFs, and commissioned dossiers; no schematic, author rationale, history, live source, other project files, web, or children used.","order":"Verified envelope inputs; rendered and visually inspected manufacturer pages; recorded independent expected package/polarity/geometry in datasheet-first-derivation.json before reading dossiers; compared two native dossier instances; reverified all input bytes.","image_inspection":["bzt-page-1.png","bzt-page-2.png","bzt-page-4.png","smbj-page-1.png","smbj-page-2.png","smbj-page-5.png","smbj-page-6.png"],"subprocess_method":"Finite direct-argv pdfinfo, pdftotext, pdftoppm through shared pipeline_runtime.run_stage; explicit allocated-scratch cwd, PATH=/usr/bin:/bin LANG=C.UTF-8 PYTHONDONTWRITEBYTECODE=1; 60s stage timeout. Combined lossless stdout/stderr and runtime JSON retained. Python file work uses /usr/bin/python3 -B.","render_commands":[{"program":"/usr/bin/pdftoppm","arguments":["-png","-r",str(100 if page==1 else 125),"-f",str(page),"-l",str(page),str(ROOT/pdf),str(SCRATCH/(name+"-page"))]} for name,pdf,pages in [("bzt","projects/crow-audio-carrier-v1/02_parts/BZT52C12-7-F/BZT52_DS18004_Rev38-2.pdf",[1,2,4]),("smbj","projects/crow-audio-carrier-v1/02_parts/SMBJ15A/Littelfuse_SMBJ_v4_2025-07-04.pdf",[1,2,5,6])] for page in pages],"bootstrap":"Initial task/envelope/protocol/preflight and runtime API reads used exec_command cat/ls/rg/sed before shared runner bootstrap. One metadata call completed successfully before wrapper raised AttributeError accessing exit_code; wrapper fixed to returncode; both pdfinfo logs retained. No engineering result was lost or altered.","archive_validation":"Reopen every regular tar member; reject symlinks, traversal, duplicate names, recursive archives; verify size and SHA-256 against source bytes. Final exact-envelope preflight logs remain beside archive in scratch to avoid archive self-reference."}
(SCRATCH/"methods.json").write_text(json.dumps(methods,indent=2))
report="""review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent /root/rj45_pin_carrier_tvs_mountedframe1
context: FRESH
design_verdict: INCOMPLETE
order_verdict: DO-NOT-ORDER
board_sha256: d5caf1ca050a466569325567cdc826d99f998ed58ce9a3e204e86d96a8bad9de
parts_sha256: 3f5819cb79b9391453a66d7b59cdcdcba4758fafa23d2739f4ddc88701ced4f2
design_rules_sha256: ccf8a8adb3d10b89b0f9019af60279f512eb39ff330bbf45109fbe9e3e10c0b7

Coverage is limited to D_IN and D_QIN_GS in this frozen commission. This is not whole-board acceptance. Board/parts/design-rule hashes above are immutable subject metadata, not independently reviewed board conclusions.

D_IN — VERDICT: PASS

Primary: Littelfuse SMBJ series, revised JC.07/04/25 v4, PDF SHA-256 d7df155be4b1f612085401e8c946f065e284d65a0e7de22b9225a7b73946e51b. Inspected page 1 Functional Diagram and package illustrations, page 2 Electrical Characteristics exact SMBJ15A row, page 5 Dimensions / DO-214AA (SMB J-Bend), and page 6 Part Marking System / Part Numbering System figures.

D_IN pin 1 (K): expect the banded terminal of the unidirectional device on the positive protected rail; observe west pad at component-top (-2.15,0), native (30.649999,82.3), K on 12V_PROTECTED. Matches the page 5 marked-top drawing with band left.
D_IN pin 2 (A): expect the opposite terminal toward ground for a positive-rail shunt suppressor; observe east pad (+2.15,0), native (34.949999,82.3), A on GND. PASS.
D_IN package/count: expect two opposed physical terminals and no EP; measured 2 native pads, 2 unique artifact pad numbers, 2 physical identities (K,A), 0 EP, 0 aliases/identity collapse. Each pad is 2.5 x 2.3 mm; center separation 4.3 mm, resulting inner gap 1.8 mm. This covers the two opposed J-bend terminal locations and satisfies the manufacturer's suggested pad minimum widths/heights (2.16/2.26 mm) and maximum gap (2.74 mm).
D_IN view/winding: front-mounted F.Cu; dossier explicitly uses component-top +x right/+y down, no front reflection. The marked package surface is top, not the side section or solder-pad drawing. Page 6 band-at-top marking image rotates into page 5 band-at-left; no mirror is required. Manufacturer provides K/A identities rather than numeric pin labels; dossier artifact pad 1 aliases the banded cathode, pad 2 the anode. There is no pin-1 corner or meaningful winding for two collinear terminals; reported n/a is correct. No fused physical aliases are needed.
D_IN electrical scope: 15 V standoff supports the named 12 V rail connection at pin-review level. Surge energy, rail tolerances, downstream withstand and clamp sizing are not established by this pin dossier and are outside this limited mapping verdict.

D_QIN_GS — VERDICT: QUESTION

Primary: Diodes Incorporated BZT52C2V0–BZT52C51, DS18004 Rev. 38-2, October 2017, PDF SHA-256 0fbd7d137524820f0160594065cbceb8c6b3188757c328416d08fceb7418202f. Inspected page 1 explicit Top View / Marking Information and Mechanical Data cathode-band statement, page 2 exact BZT52C12 electrical row, and page 4 SOD123 Package Outline Dimensions / Suggested Pad Layout figure images.

D_QIN_GS pin 1 (K): expect banded SOD123 cathode; observe west pad (-1.65,0), native (40.75,71), K on 12V_PROTECTED. Physical identity and package orientation match the page 1 left-band marking image.
D_QIN_GS pin 2 (A): expect opposite SOD123 anode; observe east pad (+1.65,0), native (44.05,71), A on Q_IN_GATE. Physical identity matches.
D_QIN_GS package/count: expect two opposing physical terminals and no EP; measured 2 native pads, 2 unique artifact pad numbers, 2 physical identities (K,A), 0 EP, 0 aliases/identity collapse. Pads measure 0.9 x 1.2 mm, center separation 3.3 mm. Manufacturer suggested pads are 0.9 x 0.95 mm with 4.05 mm outside span, hence 3.15 mm center separation. Observed centers are 0.075 mm farther outward per pad and still overlap the lead locations in the 3.55–3.85 mm overall-terminal envelope. This difference is not a pin identity or package mismatch.
D_QIN_GS view/winding: front-mounted F.Cu; explicit component-top convention requires no reflection. Compare to the explicit manufacturer Top View by rotation only. No bottom-view pinout was substituted. Numeric 1/2 are artifact designations for K/A, not manufacturer numbered pins. Two collinear terminals have no winding; dossier n/a is correct.
D_QIN_GS electrical QUESTION: with K=12V_PROTECTED and A=Q_IN_GATE the zener limits the rail-above-gate differential by reverse breakdown (BZT52C12: 11.4–12.7 V at 5 mA), and the opposite differential by forward conduction. This can be appropriate for a negative gate-to-source clamp, but the dossier does not establish Q_IN's source net, device polarity, or intended gate excursion. Required missing fact: confirm that Q_IN source is 12V_PROTECTED and Q_IN is intended to operate with its gate below that source (or supply the intended clamp polarity and actual source net). Without that fact, function-to-net correctness remains unproven; no electrical defect is asserted.

Instance symmetry: exactly one commissioned instance of each different part; no same-part instance pair exists to compare. Both preserve the same K=pad 1 west / A=pad 2 east physical convention. Their anodes intentionally name different net types; appropriateness of D_QIN_GS's gate connection remains the question above.

Methods: actual datasheet figure images inspected before dossier comparison; exact input hashes verified before/after; native counts measured from all supplied table rows. Evidence includes inspected page PNGs, native dossiers, extracted primary text, independent pre-comparison derivation, scripts, combined subprocess stdout/stderr and runtime records. Primary PDFs remain digest-bound in the frozen packet and are not duplicated in the archive. Delivery PASS means complete honest handback, not engineering approval. All commissioned refs were examined; one unresolved engineering question makes this domain INCOMPLETE.
"""
(OUT/"report.md").write_text(report)
findings=[{"ref":"D_IN","verdict":"PASS","expected":"Two physical K/A terminals; banded K toward protected positive rail, A ground; no EP or winding","observed":"Pad 1 west K=12V_PROTECTED, pad 2 east A=GND; front mount, 2 physical pads, no EP","primary_sha256":"d7df155be4b1f612085401e8c946f065e284d65a0e7de22b9225a7b73946e51b","pages":[1,2,5,6]}, {"ref":"D_QIN_GS","verdict":"QUESTION","expected":"Two physical K/A terminals, no EP or winding; rail-to-gate zener orientation must match Q_IN source and desired gate differential","observed":"Pad 1 west K=12V_PROTECTED, pad 2 east A=Q_IN_GATE; package identity passes; source net/device operating polarity absent","question":"Confirm Q_IN source=12V_PROTECTED and gate-below-source operation, or provide intended clamp polarity and actual source net.","primary_sha256":"0fbd7d137524820f0160594065cbceb8c6b3188757c328416d08fceb7418202f","pages":[1,2,4]}]
ev={"verdict":"INCOMPLETE","subject":e["subject"],"coverage":["D_IN","D_QIN_GS"],"whole_board_acceptance":False,"methods":methods,"findings":findings,"measured_counts":counts,"inputs_before":json.loads((SCRATCH/"inputs-before.json").read_text()),"inputs_after":json.loads((SCRATCH/"inputs-after.json").read_text())}
(OUT/"evidence.json").write_text(json.dumps(ev,indent=2))
(SCRATCH/"report.md").write_text(report)
(SCRATCH/"evidence.json").write_text(json.dumps(ev,indent=2))
archive=OUT/"evidence.tar.gz"
paths=sorted(p for p in SCRATCH.rglob("*") if p.is_file() and not p.name.startswith("final-preflight") and not p.name.endswith((".tar.gz",".pyc")))
assert not any(p.is_symlink() for p in paths)
records=[]
with tarfile.open(archive,"w:gz") as tar:
    for p in paths:
        b=p.read_bytes();name=p.relative_to(SCRATCH).as_posix()
        assert not PurePosixPath(name).is_absolute() and ".." not in PurePosixPath(name).parts
        ti=tarfile.TarInfo(name);ti.size=len(b);ti.mode=0o644;tar.addfile(ti,io.BytesIO(b))
        records.append({"path":name,"size":len(b),"sha256":hashlib.sha256(b).hexdigest()})
with tarfile.open(archive,"r:gz") as tar:
    members=tar.getmembers();assert len(members)==len(records)
    assert len({m.name for m in members})==len(members)
    for m,r in zip(members,records):
        assert m.isfile() and m.name==r["path"] and m.size==r["size"]
        assert not PurePosixPath(m.name).is_absolute() and ".." not in PurePosixPath(m.name).parts and not m.name.endswith((".tar.gz",".tar",".tgz"))
        b=tar.extractfile(m).read();assert len(b)==r["size"] and hashlib.sha256(b).hexdigest()==r["sha256"]
b=archive.read_bytes()
(OUT/"evidence-manifest.json").write_text(json.dumps({"archive_sha256":hashlib.sha256(b).hexdigest(),"archive_size":len(b),"member_count":len(records),"members":records},indent=2))
(OUT/"result.json").write_text(json.dumps({"subject":e["subject"],"checks":{c:"PASS" for c in e["completion"]["checks"]},"unresolved":[]},indent=2))
print(json.dumps({"verdict":"INCOMPLETE","counts":counts,"archive_member_count":len(records),"outputs":str(OUT)}))
