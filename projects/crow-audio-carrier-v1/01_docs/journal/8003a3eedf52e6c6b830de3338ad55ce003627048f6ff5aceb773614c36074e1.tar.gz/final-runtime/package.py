from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,shutil,datetime
B=Path(__file__).resolve().parent;R=B.parents[3];O=B.parent/'outputs';O.mkdir(exist_ok=True)
E=json.loads((B.parent/'envelope.json').read_text());H=json.loads((B/'hashes.json').read_text())
assert H==json.loads((R/'expected-subject.json').read_text())
checks=[]
for x in E['input_packet']:
 p=R/x['path'];data=p.read_bytes();actual=hashlib.sha256(data).hexdigest();ok=len(data)==x['size'] and actual==x['sha256'];checks.append({'path':x['path'],'size':len(data),'sha256':actual,'pass':ok})
assert len(checks)==460 and all(x['pass'] for x in checks)
(B/'inputs-after.json').write_text(json.dumps(checks,indent=2))
report=(B/'report-draft.md').read_text();at='order_verdict: DO-NOT-ORDER\n';report=report.replace(at,at+''.join(f'{k}: {v}\n' for k,v in H.items()),1)
(O/'report.md').write_text(report);(B/'review-report.md').write_text(report)
analysis=json.loads((B/'analysis.json').read_text());families=json.loads((B/'families.json').read_text());pdf=json.loads((B/'pdf-comparison.json').read_text());fidelity=json.loads((B/'fidelity.json').read_text());final=json.loads((B/'final-checks.json').read_text())
assert not families['differences'] and all(x['body_equal'] for x in pdf) and fidelity['fresh_native_export_equal']
ev={'schema':1,'review_stage':'pre-route','review_kind':'topology','revieweridentity':'/root/carrier_rj45_native_carrier_topology_source1','context':'FRESH','date':datetime.datetime.now(datetime.timezone.utc).isoformat(),'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','subject':E['subject'],'subject_hashes':H,'inputs_verified_before':460,'inputs_verified_after':460,'methods':['Independent native S-expression graph parser; equality current versus accepted graph and freshly re-exported KiCad native schematic','Independent authored JSX evaluation with minimal React element collector; compare333components and943connectedpins to current CircuitJSON and native graph','Current dossier MPN/value/footprint and pin-set fidelity on333components/58fittedfamilies, applying explicit fused-pin aliases only','205 authored electrical assertions evaluated against independently parsed native graph; current power/protection/analog/clock domain invariants','Exact card semantic diff excluding only installed list, then population set equality','110dpi pdftoppm raster equality over19pagepairs, current integrated images and current header visual inspection','Authoritative copied hash algorithms recomputed seven current subject hashes; all460frozen packet inputs hashed before/after','Safe evidence tar reopened for every regular member with independently checked size and SHA256'],'counts':analysis,'fitted_family_count':families['fitted_family_count'],'connector_count':fidelity['connector_count'],'connector_pin_count':fidelity['connector_pin_count'],'dossier_local_primaries_verified':fidelity['dossier_primary_files_verified'],'pdf_pages':19,'pdf_equal_drawing_bodies':19,'electrical_invariants_passed':205,'electrical_invariants_total':205,'visual_full_pages':[1,2,3,6,14,16,17,18],'visual_overview_pages':list(range(1,20)),'visual_header_pages':list(range(1,20)),'findings':[],'limitations':['Topology acceptance only; physical placement/routing/assembly effects of underside fuses, ground attachments and derived jack lands require their owning gates','SOURCE PASS/FULL INCOMPLETE23physicalobligations; FIRST-ARTICLE-ONLY/DO-NOT-ORDER; no allocated stock or release acceptance','0ERCerrors/2637classifiedwarnings; not warning-free','Current89dossiers independently bound; older report parts digest differs and no accepted02_partstree supplied, so no dossier byte-equivalence claim','Power/clock calculations are bounded engineering screens; first-article captures and timing/thermal tests remain owed'],'boundary_receipts':final,'diagnostic_history':'All raw script diagnostics retained; finite bounded stages include intermediate reviewer parser/value-normalization/schema corrections. Final named complete-stage results and independently inspected artifacts establish coverage.'}
(O/'evidence.json').write_text(json.dumps(ev,indent=2));(B/'evidence-record.json').write_text(json.dumps(ev,indent=2))
(B/'coordinator-clarification.txt').write_text('2026-09-12 coordinator clarification, not an independently supplied old source tree: intended dossier delta is02_parts/615008160221/part.yaml andprimary-source-record.md for project-derived2.5x1.5mm shell copper lands andsilk correction; slots/centres/model andelectricalratings unchanged. Current record independently read, primary jack drawing inspected, assignments independently checked. No historical dossier byte-equivalence asserted.\n')
runtime=B/'runtime-source';runtime.mkdir(exist_ok=True)
toolroot=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
for n in ['pipeline_runtime.py','pipeline_execution.py','pipeline_artifacts.py','pipeline_identity.py']:shutil.copyfile(toolroot/n,runtime/n)
shutil.copyfile(R/'context/skills/kicad-pcb/scripts/pre_route_review_check.py',runtime/'pre_route_review_check.py')
members=[]
for p in sorted(B.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(B).as_posix()
 if rel in ('package.log','package.runtime.json') or rel.startswith('preflight'):continue
 assert not p.is_symlink() and not rel.endswith(('.tar','.tar.gz'))
 data=p.read_bytes();members.append({'path':rel,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for m in members:tf.add(B/m['path'],arcname=m['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 actual=tf.getmembers();assert len(actual)==len(members);seen=set();expected={m['path']:m for m in members}
 for m in actual:
  path=PurePosixPath(m.name);assert m.isfile() and not path.is_absolute() and '..' not in path.parts and m.name not in seen and m.name in expected
  seen.add(m.name);data=tf.extractfile(m).read();want=expected[m.name];assert len(data)==want['size']==m.size and hashlib.sha256(data).hexdigest()==want['sha256']
manifest={'schema':1,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_size':archive.stat().st_size,'member_count':len(members),'members':members}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2))
(O/'result.json').write_text(json.dumps({'subject':E['subject'],'checks':{k:'PASS' for k in E['completion']['checks']},'unresolved':[]},indent=2))
assert sorted(p.name for p in O.iterdir())==['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md','result.json']
print(json.dumps({'design_verdict':'SOUND','output_dir':str(O),'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'members':len(members),'inputs_after':len(checks)},indent=2))
