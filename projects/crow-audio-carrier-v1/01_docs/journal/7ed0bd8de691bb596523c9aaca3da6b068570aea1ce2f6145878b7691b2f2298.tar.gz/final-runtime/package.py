from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,io
from datetime import datetime,timezone
P=Path('/tmp/rj45-pod-readability-review-recovery1-21stji5k'); S=Path(__file__).parent; O=S.parent/'outputs'
e=json.loads((S.parent/'envelope.json').read_text()); h=json.loads((S/'hashes.json').read_text()); pix=json.loads((S/'pixel-equivalence.json').read_text()); f=json.loads((S/'fidelity.json').read_text())
after=[dict(path=x['path'],size=len((P/x['path']).read_bytes()),sha256=hashlib.sha256((P/x['path']).read_bytes()).hexdigest(),ok=(len((P/x['path']).read_bytes())==x['size'] and hashlib.sha256((P/x['path']).read_bytes()).hexdigest()==x['sha256'])) for x in e['input_packet']]
assert len(after)==195 and all(x['ok'] for x in after);(S/'inputs-after.json').write_text(json.dumps(after,indent=2))
assert len(pix)==4 and sum(x['body_changed_pixels'] for x in pix)==0
now=datetime.now(timezone.utc).isoformat()
report='''review_stage: pre-route
review_kind: schematic_render
reviewer: carrier_rj45_native_pod_readability_recovery1
reviewer_identity: /root/carrier_rj45_native_pod_readability_recovery1
context: FRESH
date: 2026-09-12
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
'''+''.join(k+': '+v+'\n' for k,v in h.items())+'''
The exact frozen current crow-mic-pod-v3 PDF is SOUND for this pre-route rendered-schematic lens. This is fresh current-byte judgment, not import of a previous verdict. No historical review report or timed-out verdict was read. The original timeout and source variants remain untouched. Root alone owns live promotion.

Measured scope and source change

195/195 envelope input files matched size and SHA-256 before and after work; seven independently recomputed subject hashes match expected-subject.json. The frozen pre_route_review_check.py owns the normalized-netlist, parts and design-rules algorithms; exact bytes bind the other four hashes.

Authored TSX is byte-identical to accepted-subject. All supplied prior rule-family files are byte-identical. The sole changed authored file among the supplied comparative source family is floorplan.yaml: D1 moves y34.5 to35.6mm, TP5 moves x57.9 to59.7mm, the RJ45 pinmap silk legend moves y32 to38mm, and the A+ caption follows TP5. Comments explain clearance intent. These are observed source edits, not independent clearance or placement acceptance.

Current and accepted native schematics become byte-identical after UUID-only normalization. Independent S-expression parsing compares 40/40 native component identities/values/footprints and24/24 net node populations, including103/103 physical-pin nodes. The canonical gate's electrical netlist hashes also match. CircuitJSON differs only in15 reordered supplier-footprint warning records with regenerated warning IDs and one filesystem metadata hash. Sorting records, omitting that metadata, and stripping only the warning-ID field gives exact equality; other electrical, drawing and PCB records remain equal. No warning was waived by this comparison.

Measured rendered coverage

The actual current and accepted PDFs were independently rasterized with pdftoppm at120dpi. Each has4 pages at1500x1013pixels. Full-image differences are confined to the current CircuitJSON identity prefix at x299..665,y83..98; the complete drawing-body rectangle [0,110,1500,1013) has0 changed pixels out of1,354,500 per page, totaling0/5,418,000. No changed drawing body exists to adjudicate. Every current full page and current identity header was inspected as an image, with enlarged RJ45/opamp crops and240dpi native header crops. This is measured all-page equality, not an inference from text extraction or a previous hash claim.

4/4 integrated current pages cover7+11+10+12=40 components. Page1 shows the10-pin RJ45, fuse, reverse diode, TVS, bleed resistor and input probes. Labels and branching wires are separated and readable. Page2 shows the adjustable LDO, adjacent input/output capacitors, feedback and noise-reduction components; NC/DNC pins are identified. Page3 shows capsule polarity, filtered bias, AC coupling and reference divider/capacitor. Page4 shows the quad-amplifier pin names, reference follower, inverting preamp, complementary driver, spare-channel feedback, per-leg100ohm output resistors, ESD device NC pins and output probes. No wire-through-label, ambiguous polarity, or unreadable connector pin was found in this visual coverage.

All4 current headers visibly identify FIRST ARTICLE, page x of4, current circuit.json SHA-256 prefix40910558f437df72, and component counts. Section captions preserve the10.5–13.2V/no-hot-plug input boundary, TPS7A4901 quiet5V stage, electret front end, and18/11V/V differential/DC-coupled output. A provisional suspicion of clipped repeated title text was rejected: exact title-strip pixels are identical on all4 pages, each containing3906 dark-red ink pixels, and PDF text bounds place the title inside the page at y4.214756..24.644756points. A native240dpi crop confirmed complete text. The apparent clipping was host image presentation, not a PDF defect; no source repair is warranted.

Source/native fidelity and current limits

99/99 connected CircuitJSON source ports map to the same native net, with0 mismatches. The remaining4/103 ports are explicit no-connects U2.3,U2.7,U3.1,U3.2. All10/10 J1 pins are legible and verified:1/3/7=12V_POD,2/6/8=GND,5=AUDIO_P,4=AUDIO_N,9/10=POD_SHIELD. The native POD_SHIELD net has exactly J1.9 and J1.10 and remains isolated from GND. J1's current615008160221 identity is visible. This is custom analog/power over the selected factory Cat6A RJ45 cord, NOT Ethernet/PoE; mating remains power-off. Historical MicroFit artifacts are not current interface authority.

The first-power card is unchanged and has exactly33 installed refs, equal to the40 native refs minus7 testpoints. Its supply boundary remains10.5–13.2V,30mA current limit and20mA maximum no-load current. No voltage/current limit was raised. The carrier's separate population change is outside this pod-only packet/lens and is not certified here. This review checks current readability and source/native correspondence; it does not replace the separately commissioned topology/ratings review or datasheet/physical qualification.

Existing ERC evidence reports0 errors and158 warnings:64 lib_symbol_issues and94 endpoint_off_grid. The error-only report is not an all-severity-clean claim. Warnings retain their existing classification; the supplied reports also explicitly list ignored checks. No additional ERC waiver or electrical acceptance is inferred from visual equality.

Findings and limits

No actionable current rendered-schematic defect found across4/4 pages and40/40 components. The observed title-display concern was independently falsified and is recorded for audit, not carried as a design defect. Readability acceptance does not certify placement, courtyard/service clearance, routing, layout, enclosure, release or production.

The supplied connector SOURCE gate remains PASS with9 source-admitted physical unknowns, and FULL remains INCOMPLETE with9 physical obligations. These are prototype obligations; this review adds no physical-measurement prerequisite before fabrication. FIRST-ARTICLE-ONLY intent and DO-NOT-ORDER remain. Public-catalog design-only admission and blank operator sourcing response do not allocate stock or authorize an order. LAYOUT001's recorded3/3 closure is unchanged, not independently regraded by this schematic lens.

Execution used finite120-second stages, direct argv, explicit scratch cwd/environment and the shared pipeline_runtime.run_stage. No child reviewers were launched. The initial optional fitz import was unavailable, so Poppler/Pillow performed the actual completed image work; its failed log is preserved. A local analysis parser was corrected to permit absent optional pinfunction fields, then completed103-node comparison; both logs are retained. These diagnostic repairs changed scratch only. No source, checkpoint, review receipt, release or live project bytes were edited.
'''
(O/'report.md').write_text(report)
ev={'schema':1,'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','review_stage':'pre-route','review_kind':'schematic_render','context':'FRESH','reviewer':'/root/carrier_rj45_native_pod_readability_recovery1','completed_at':now,'subject':e['subject'],'hashes':h,'methods':['Frozen input before/after SHA-256 census','Frozen gate-owned seven-hash algorithms','Independent native S-expression component/net/node comparison','CircuitJSON source-port to native net comparison','Exact TSX/rule source family and floorplan diff','All-page current/accepted Poppler120dpi image pixel comparison','Actual current full-page and enlarged crop visual inspection','Native240dpi header crop plus pixel-title falsification','Independent tar member reopening and digest census'],'counts':{'inputs_before':195,'inputs_after':195,'subject_hashes':7,'pdf_pages':4,'pages_visually_inspected':4,'components':40,'connected_ports':99,'no_connect_ports':4,'rj45_pins':10,'first_power_installed':33,'test_points':7,'body_pixels_compared':5418000,'body_pixels_changed':0,'erc_errors':0,'erc_warnings':158,'physical_obligations':9},'pixel_equivalence':pix,'findings':[],'rejected_hypotheses':[{'hypothesis':'Repeated title clipped on pages2/3','resolution':'Exact title strips equal across all4pages; native240dpi image and PDF coordinates confirm complete title. Host presentation artifact.'}],'limitations':['Readability and source/native fidelity only; separate topology/ratings review remains','No placement/route/layout/release acceptance','SOURCE PASS and FULL INCOMPLETE9 physical obligations retained','FIRST-ARTICLE-ONLY / DO-NOT-ORDER; no stock allocation or ordering permission','Existing ERC warnings remain classified'],'source_delta':'D1/TP5 owning placement and two related silk captions only among compared authored family; TSX/rules unchanged','historical_reports_read':False}
(O/'evidence.json').write_text(json.dumps(ev,indent=2)+'\n')
members=[]
with tarfile.open(O/'evidence.tar.gz','w:gz') as t:
 for p in sorted(S.iterdir()):
  if p.name in ('package.log','package.runtime.json') or not p.is_file():continue
  assert not p.is_symlink();name='scratch/'+p.name; data=p.read_bytes();ti=tarfile.TarInfo(name);ti.size=len(data);ti.mode=0o644;t.addfile(ti,io.BytesIO(data))
 for name in ('report.md','evidence.json'):
  data=(O/name).read_bytes();ti=tarfile.TarInfo('witness/'+name);ti.size=len(data);ti.mode=0o644;t.addfile(ti,io.BytesIO(data))
seen=set()
with tarfile.open(O/'evidence.tar.gz','r:gz') as t:
 for m in t.getmembers():
  q=PurePosixPath(m.name);assert m.isfile() and not q.is_absolute() and '..' not in q.parts and m.name not in seen and not m.name.endswith(('.tar.gz','.tgz'));seen.add(m.name)
  data=t.extractfile(m).read();assert len(data)==m.size;members.append({'path':m.name,'size':m.size,'sha256':hashlib.sha256(data).hexdigest()})
archive=(O/'evidence.tar.gz').read_bytes();manifest={'schema':1,'archive_sha256':hashlib.sha256(archive).hexdigest(),'archive_size':len(archive),'member_count':len(members),'members':members}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(O/'result.json').write_text(json.dumps({'subject':e['subject'],'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]},indent=2)+'\n')
print(json.dumps({'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','outputs':sorted(p.name for p in O.iterdir()),'archive_members':len(members),'archive_size':len(archive),'archive_sha256':manifest['archive_sha256'],'verified_inputs_after':195}))
