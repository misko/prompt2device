from pathlib import Path,PurePosixPath
import json,hashlib,tarfile
s=Path(__file__).parent;o=s.parent/"outputs"
archive=o/"evidence.tar.gz"
files=[(p,"review/"+p.relative_to(s).as_posix()) for p in sorted(s.rglob("*")) if p.is_file() and not p.name.startswith(("package-stage", "preflight-stage"))]
files += [(o/n,n) for n in ["report.md","evidence.json","result.json"]]
with tarfile.open(archive,"w:gz") as t:
 for p,n in files:
  assert not p.is_symlink();t.add(p,arcname=n,recursive=False)
records=[];seen=set()
with tarfile.open(archive,"r:gz") as t:
 for m in t:
  p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and ".." not in p.parts and m.name not in seen
  assert not m.name.endswith((".tar.gz",".tgz"));seen.add(m.name)
  data=t.extractfile(m).read();assert len(data)==m.size
  records.append({"path":m.name,"size":len(data),"sha256":hashlib.sha256(data).hexdigest()})
manifest={"archive_sha256":hashlib.sha256(archive.read_bytes()).hexdigest(),"archive_size":archive.stat().st_size,"member_count":len(records),"members":records}
(o/"evidence-manifest.json").write_text(json.dumps(manifest,indent=2))
print(json.dumps({k:v for k,v in manifest.items() if k!="members"}))
