review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_carrier_clock_reset_clockground1 (actual fresh agent)
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: e85b1461a82f3d3853c19fae694693816e31570d23d37019ef187d6428bea4ae
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: e6d5b0b89efd79051b082f70b283ec7e85e1170ed11ddb94581744d26904c9c7

Coverage is limited to U_CLK, U_RST1 and U_RST2 in the frozen native dossiers. SOUND is the pin-review verdict for this group only, not whole-board acceptance or release authorization. The three immutable hashes above are supplied subject bindings, not independently reviewed whole-artifact conclusions.

Method: verified every envelope input by SHA-256 and byte count before review and after review. Rendered selected primary PDFs with pdftoppm; inspected actual pin-configuration and mechanical-outline images before reading dossier pad tables. Recorded independent derivation before comparison. Manufacturer selected-package figures are TOP VIEW. All instances are front-mounted, at native rotation 0; COMPONENT-TOP +x right/+y down requires no reflection. Translation-only comparison independently verified every native coordinate. No bottom-view conversion or mirror was used. Supplementary extracted datasheet text was used for functional-mode checks, never to establish winding.

Measured coverage: 19 native pad rows, 19 distinct physical identities, 0 exposed pads, 0 fused aliases. Each package occurs once in this commissioned group. The three channels inside U_CLK were checked pairwise; the two reset ICs are different devices and must not be assigned matching pin numbers by analogy.

U_CLK VERDICT: PASS
Primary: projects/crow-audio-carrier-v1/02_parts/SN74LVC3G34DCUR/SN74LVC3G34_SCES366L.pdf; SHA-256 d541afbccf6270522f5ba33b86ca31da0ec6bbf497c0d1f8ba265e9ac2e1faec; PDF page 3, Section 5, DCU Package 8-Pin VSSOP Top View; PDF page 19, DCU0008A package outline.
Measured: 8 native pads / 8 unique pad numbers / 8 physical identities, no EP, no aliases. Signed polygon area in +y-down frame: -4.200000 mm², establishing CCW. Manufacturer and observed pin 1 are upper-left.
Expected and observed: left side 1,2,3,4 from top to bottom; right side 8,7,6,5 from top to bottom; four leads each side; pitch 0.50 mm. No physical identity is missing or collapsed.
U_CLK pin 1 (1A): expected clock input; observed function 1A on MCH_MCLK; PASS.
U_CLK pin 2 (3Y): expected buffered frame-sync output; observed function 3Y on FSYNC_BUF; PASS.
U_CLK pin 3 (2A): expected bit-clock input; observed function 2A on MCH_BCLK; PASS.
U_CLK pin 4 (GND): expected ground; observed function GND on GND; PASS.
U_CLK pin 5 (2Y): expected buffered bit-clock output; observed function 2Y on BCLK_BUF; PASS.
U_CLK pin 6 (3A): expected frame-sync input; observed function 3A on MCH_FSYNC; PASS.
U_CLK pin 7 (1Y): expected buffered master-clock output; observed function 1Y on MCLK_BUF; PASS.
U_CLK pin 8 (VCC): expected supply rail; observed function VCC on 3V3_ADC; PASS.

U_RST1 VERDICT: PASS
Primary: projects/crow-audio-carrier-v1/02_parts/TPS3839K33DBZR/TPS3839_SBVS193D.pdf; SHA-256 5f9a9581d1b8df7f0b2a480a71dac6993c9aba3b05767ad22641d151434f5dd3; PDF page 5, Section 6, TPS3839 DBZ Package SOT23-3 Top View; PDF page 28, DBZ0003A package outline.
Measured: 3 native pads / 3 unique pad numbers / 3 physical identities, no EP, no aliases. Signed polygon area in +y-down frame: -1.781250 mm², establishing CCW. Manufacturer and observed pin 1 are upper-left.
Expected: pins 1/2 on left, 3 at right-middle, 1.90 mm separation of pins 1/2. Observed: (-0.9375,-0.95), (-0.9375,+0.95), (+0.9375,0), exactly that arrangement. Dossier N/S side labels classify the dominant coordinate magnitude; coordinates establish the actual two-left/one-right package arrangement. They are not a mirror or physical side swap.
U_RST1 pin 1 (GND): expected ground; observed function GND on GND; PASS.
U_RST1 pin 2 (RESET#): expected active-low push-pull reset output; observed function RESET# on POR_N; PASS.
U_RST1 pin 3 (VDD): expected supply/sense rail; observed function VDD on 3V3_ADC; PASS.

U_RST2 VERDICT: PASS
Primary: projects/crow-audio-carrier-v1/02_parts/SN74LVC1G123DCTR/SN74LVC1G123_SCES586E.pdf; SHA-256 7248ef0ff62af4d2da172bb2900f0f1f136a6ae90109a6485228e01269fa1c1d; PDF page 3, Figure 4-1 and Table 4-1; PDF page 23, DCT0008A package outline.
Measured: 8 native pads / 8 unique pad numbers / 8 physical identities, no EP, no aliases. Signed polygon area in +y-down frame: -6.630000 mm², establishing CCW. Manufacturer and observed pin 1 are upper-left.
Expected and observed: left side 1,2,3,4 from top to bottom; right side 8,7,6,5 from top to bottom; four leads each side; pitch 0.65 mm. No physical identity is missing or collapsed.
U_RST2 pin 1 (A): expected falling-edge input, held low for CLR-edge trigger; observed function A on GND; PASS.
U_RST2 pin 2 (B): expected rising-edge input, held high for CLR-edge trigger; observed function B on 3V3_ADC; PASS.
U_RST2 pin 3 (CLR#): expected active-low clear / rising-edge trigger; observed function CLR# on POR_N; PASS.
U_RST2 pin 4 (GND): expected ground; observed function GND on GND; PASS.
U_RST2 pin 5 (Q): expected positive output pulse; observed function Q on RESET_PULSE_H; PASS.
U_RST2 pin 6 (Cext): expected external timing capacitor node; observed function Cext on RESET_C; PASS.
U_RST2 pin 7 (Rext/Cext): expected external timing resistor/capacitor node; observed function Rext/Cext on RESET_RC; PASS.
U_RST2 pin 8 (VCC): expected supply rail; observed function VCC on 3V3_ADC; PASS.

U_CLK channel symmetry: 1A→1Y is pin 1 MCH_MCLK → pin 7 MCLK_BUF; 2A→2Y is pin 3 MCH_BCLK → pin 5 BCLK_BUF; 3A→3Y is pin 6 MCH_FSYNC → pin 2 FSYNC_BUF. All input/output kinds and numbering agree; no channel swap.

Reset-chain sanity: TPS3839 DBZ pin 2 is an active-low push-pull output on POR_N. The SN74LVC1G123 pin 3 is active-low CLR on that same net; A is held at GND and B at 3V3_ADC. SCES586E PDF pages 12–13, section 7.1 and Table 7-1, explicitly permit a rising CLR edge to trigger Q under A=low/B=high. Pin 5 RESET_PULSE_H is consistent with the positive pulse output.

Scope limits: this review checks physical numbering, counts, winding, package identities, supplied function labels and native net roles. It does not establish external timing resistor/capacitor values, complete endpoint connectivity, pulse duration, power-rail behavior, solder-land dimensional qualification, routing or assembly acceptance from these IC-only dossiers. RESET_C and RESET_RC are compatible timing-node assignments; the full external RC network is not present in this packet. No broader circuit-performance conclusion is made.

No FAIL or QUESTION findings within the commissioned pin review. All three refs PASS; group design verdict SOUND. Order verdict remains DO-NOT-ORDER at this pre-route stage.
