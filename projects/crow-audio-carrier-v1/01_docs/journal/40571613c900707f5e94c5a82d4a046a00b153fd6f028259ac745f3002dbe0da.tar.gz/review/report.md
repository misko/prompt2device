review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 92a4e2fc0fecde845f2dfa0d9e2f5bfbd943372962fb449d699a98d957fc5633
parts_sha256: a69aabc3aa5f223b301b6bb03e874580486db3bf2cb185db047b3bc19da6d1e1
design_rules_sha256: 7e0d0f0eae778e8332e9597a7345955b2b9423921d5decb980190d97e8721d4c

Limited group coverage: Q_IN and Q_PRE only; this is not whole-board acceptance.

Q_IN VERDICT: PASS
Measured counts: 5 native numbered copper pad records; 8 manufacturer terminal identities; 3 declared fused aliases (6, 7, 8 -> native pad 5); effective identity coverage 8/8; 8 unnumbered paste/mechanical pads excluded from terminal count.
Primary document: SHA-256 1ea244be5e0fe4195ad20cb2da0960ac622b6efc19cf9e579c9eb8ef5777fa27; PDF page 1 POWERDI3333-8 Bottom View and Equivalent Circuit; PDF page 5 Package Outline Dimensions and Suggested Pad Layout.
Q_IN pin 1 (SOURCE): expected first source terminal at one end of the 1-4 source/gate bank in TOP VIEW after one required bottom-to-top reflection vs dossier shows pin 1 at the north end of the west bank after rotation, SOURCE on 12V_PROTECTED.
Q_IN pins 2-3 (SOURCE): expected remaining source terminals consecutive with pin 1 on the same bank vs dossier shows pins 2-3 consecutive southward on the west bank, SOURCE on 12V_PROTECTED.
Q_IN pin 4 (GATE): expected gate at the opposite end of the 1-4 bank vs dossier shows the south end of the west bank, GATE on dedicated Q_IN_GATE.
Q_IN pins 5-8 (DRAIN_COMMON): expected all four drain identities and thermal drain metal electrically fused by the manufacturer vs dossier shows native composite drain pad 5 on 12V_FUSED and explicit fused aliases preserving identities 6-8. The collinear surviving records do not establish winding; the manufacturer figure plus aliases resolves all identities without an additional mirror.

Q_PRE VERDICT: PASS
Measured counts: 3 native numbered copper pad records; 3 manufacturer terminal identities; 0 aliases; effective identity coverage 3/3; no exposed pad.
Primary document: SHA-256 0d8e3261ae280e007b5837fff60c55142f2d92af71edc4d02aee6f7a760a785c; PDF page 1 SOT23 Top View, Bottom View, and Equivalent Circuit.
Q_PRE pin 1 (G): expected marked pin-1 gate at one end of the two-lead side in manufacturer TOP VIEW vs dossier shows pin 1 at the north end of the west pair after a 180-degree rotation, G on dedicated PRE_GATE.
Q_PRE pin 2 (S): expected source at the other end of the two-lead side vs dossier shows pin 2 at the south end of the west pair, S on rail-kind 5V_LDO_FEED.
Q_PRE pin 3 (D): expected drain as the single opposite lead vs dossier shows pin 3 on the east side, D on rail-kind 5V_LDO_HOLD.
Package winding expected from the page-1 TOP VIEW is CCW with the marked gate as pin 1; observed component-top winding is CCW. No mirror is required.

Instance symmetry: all commissioned instances were checked (one Q_IN and one Q_PRE). They use different packages and therefore have no same-part multi-instance symmetry pair; both preserve the common P-channel source-rail, dedicated-gate, drain-output structure.

