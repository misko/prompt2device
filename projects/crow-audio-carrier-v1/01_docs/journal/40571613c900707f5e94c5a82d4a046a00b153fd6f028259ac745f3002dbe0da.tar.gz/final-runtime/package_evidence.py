#!/usr/bin/env /usr/bin/python3
from __future__ import annotations

import hashlib
import json
import shutil
import tarfile
from pathlib import Path, PurePosixPath

root = Path("/tmp/rj45-pin-carrier-power-fets-toponly1-vp0hmg29")
run = root / "06_build/task_runs/rj45-pin-carrier-power-fets-toponly1"
scratch = run / "scratch"
outputs = run / "outputs"
tree = scratch / "evidence-tree"
if tree.exists():
    shutil.rmtree(tree)
tree.mkdir()

copies = {
    scratch / "methods.md": tree / "methods.md",
    scratch / "input-hashes.txt": tree / "input-hashes.txt",
    scratch / "run_cmd.py": tree / "methods/run_cmd.py",
    scratch / "package_evidence.py": tree / "methods/package_evidence.py",
    root / "dossiers/Q_IN.md": tree / "native-dossiers/Q_IN.md",
    root / "dossiers/Q_PRE.md": tree / "native-dossiers/Q_PRE.md",
    outputs / "report.md": tree / "conclusions/report.md",
    outputs / "evidence.json": tree / "conclusions/evidence.json",
    scratch / "ao3401a-p1.txt": tree / "extracted/ao3401a-p1.txt",
    scratch / "dmp6023-p1.txt": tree / "extracted/dmp6023-p1.txt",
    scratch / "dmp6023-p5.txt": tree / "extracted/dmp6023-p5.txt",
}
for src, dst in copies.items():
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)

for src in sorted((scratch / "rendered").glob("*.png")):
    dst = tree / "rendered-figures" / src.name
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
for src in sorted(scratch.glob("runtime-*.log")):
    if int(src.stem.split("-")[1]) > 18:
        continue
    dst = tree / "runtime" / src.name
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)

members = []
paths = sorted(p for p in tree.rglob("*") if p.is_file())
seen = set()
for path in paths:
    if path.is_symlink():
        raise RuntimeError(f"symlink refused: {path}")
    rel = path.relative_to(tree).as_posix()
    pure = PurePosixPath(rel)
    if pure.is_absolute() or ".." in pure.parts or rel in seen:
        raise RuntimeError(f"unsafe or duplicate archive member: {rel}")
    seen.add(rel)
    data = path.read_bytes()
    members.append({"path": rel, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()})

archive = outputs / "evidence.tar.gz"
with tarfile.open(archive, "w:gz", format=tarfile.PAX_FORMAT) as tar:
    for path in paths:
        tar.add(path, arcname=path.relative_to(tree).as_posix(), recursive=False)

with tarfile.open(archive, "r:gz") as tar:
    reopened = []
    names = set()
    for info in tar.getmembers():
        pure = PurePosixPath(info.name)
        if not info.isfile() or info.issym() or info.islnk():
            raise RuntimeError(f"non-regular archive member: {info.name}")
        if pure.is_absolute() or ".." in pure.parts or info.name in names:
            raise RuntimeError(f"unsafe or duplicate reopened member: {info.name}")
        names.add(info.name)
        stream = tar.extractfile(info)
        if stream is None:
            raise RuntimeError(f"cannot reopen: {info.name}")
        data = stream.read()
        reopened.append({"path": info.name, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()})
if reopened != members:
    raise RuntimeError("reopened archive member census/digests differ")

archive_data = archive.read_bytes()
manifest = {
    "archive_sha256": hashlib.sha256(archive_data).hexdigest(),
    "archive_size": len(archive_data),
    "member_count": len(members),
    "members": members,
}
(outputs / "evidence-manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
print(json.dumps(manifest, sort_keys=True))
