# Fresh D-BACK: native regression-fixture admission

agent-role: judgment
context_mode: FRESH
source_commit: 95e51ad67f42c39c3f00e04c43975fdafa246368
repository: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901
private_output_root: /tmp/pland-fixture-dback-20260910T213128Z
live_source: READ_ONLY; root remains sole live writer

Verify this strict envelope and every named member before work. Read CLAUDE.md,
the copied handoff/beacon/journal tail, pcb-design lifecycle/compute references,
tests/README.md and harness, original escape_check.py, and P-LAND canon/contract.
The actual source-author cap failure is preserved in
01_docs/evidence/pland-backtrack-20260910/witness-adoption.md and verbatim
witness-author-result.md. Read them to preserve the actual history, limits and
corrections. Do not inherit the WIP's false RED-VERIFIED claim. Rehash the
94bde46519fbe62185e729a769f5e2ee8e9fc2410bdade7c0bc54633c1cd7f03.tar.gz
and all56 members against witness-attempt-manifest.json before extracting any
inputs safely under your private directory. Do not modify original private dirs.
No transcript, whole journals or previous reviewer findings are needed.

Question: what upstream fixture/persistence/admission design can establish a
causal PUBLIC free-search regression, and what production implementation scope
and role are justified after two exhausted standard author commissions?
This is diagnosis of the failed test-construction method, not a replacement
author, another live test-edit attempt, or a reset of prior implementation caps.

MEASURED inherited subject: original checker SHA
cb0d0cf6cb593b5f231fa372920e7dc6adf10bce95c0d734fac0900d3fd3ddf3,
original test424d6dd38567c99fb5ee457f01e1f2b0b071bed48c4b92d4a49b02e04816856c.
The rejected author first accidentally changed sampling25 to37, then failed
004/005 fixture attempts with0graded/4floorless. The final73-line test WIP
contains an unexecuted pattern change. All three scratch fixtures are retained
in the archive. Inspect their exact PCB/PRO/DRU and reopen through native pcbnew
to distinguish ephemeral class assignment, project schema/version behavior,
parser applicability, geometric admission and unsupported syntax.

Required bounded outputs:
1. Complete native reloaded census of original fixtures: pads, classes (including
effective compound-class semantics where relevant), persisted net assignments,
declared floors, layers and native shapes. Explain the two actual zero-denominator
failures from exact artifacts/stdout. Do not rerun the entire old suite.
2. Decide and build ONE private diagnostic clean/hostile pair that can establish
the remote-High class blanket-clearance defect on the unchanged public CLI with
NONZERO denominator and a named central pad failing specifically width/clearance.
First state expected classes/floors, census and geometry as a hypothesis. Verify
those by save/reload BEFORE the public CLI. Retain exact fixture source, all
native files, full CLI stdout/rc/timing and original checker hash before/after.
Do not label a missing API, parse exception, zero census or output-string mismatch
as behavioral RED. No production/test source writes or fake new-verdict outputs.
3. Independently check one explicit width0.2mm native copper launch on the same
base geometry and its nearest-High hostile control. Retain all native DRC categories
and connectivity, including baseline pad-to-pad clearance findings if any. Prefer
a static-clean specimen with a connected receiving pad so the control isolates
track clearance. If modifying dimensions to obtain that, derive and disclose them
before execution, retain failed evidence and avoid fitting a desired verdict.
Native DRC with no schematic cannot establish parity. A specified-track native
pass is a geometric oracle; it does not itself establish whole public-search RED.
4. Report whether this evidence admits a maintained regression and how final test
assertions should separate baseline admission, causal named-pad failure and final
witness admission. Public current output is a maximum-width claim; final intended
output is VALIDATED_CONSTANT_WIDTH_WITNESS / NO_VALIDATED_WITNESS, with each actual
start/end/width/layer/floor and limiting pair/rule/gap/margin. Do not implement it.
5. Give a bounded ownership/cost decision for the full source repair. Prior fixed
point implementation and latest fixture-author caps remain exhausted. Accepted
upstream direction is finite declared-width witnesses, complete compiled AST with
both A/B orderings and per-constraint last-match semantics, native candidate shape
validation, truthful non-witness failure. Retain actual MAX_LAUNCH_PTS25 (37actual
sample points),48directions,1mmreach/2mmcap. Seven production guard groups still
owed: native support/unreadable geometry; all effective/local clearance bounds;
B-dependent width AST prevalidation; complete supported attributes/constraints;
native class/string/wildcard semantics; absolute board minima/local-custom
precedence; full public verdict/denominator migration with retained hostile corpus.
Do not reopen design width floors or source copper to avoid these obligations.
Recommend decomposition or a justified role escalation based on measured failures,
not a budget reset or a promise that another identical author will do better.

Budget: one read-only judgment, hard deadline now+25minutes as exact envelope;
final120seconds reserved for complete report/closure. Maximum3 nonimproving
diagnostic commands/fixture corrections, zero replacement or automatic extension.
No board sweep or live project native rerun. Each native/CLI tiny fixture command
<=60seconds and bounded by remaining deadline. Use /usr/bin/python3 for pcbnew.
Full command argv/start/stdout/stderr/rc/duration/process pid and source SHA are
written to real files BEFORE/AFTER each run. Root's reusable capture helper is
/tmp/carrier-pland-fixture-adoption-20260910.hnDKH2sk/run_capture.py; copy it privately if useful. Bootstrap
tool reads may be recorded as reads; never invent missing command metadata.
Report meaningful progress at most60seconds apart and stop when evidence answers
the question. All failed/terminated commands remain part of the handback.

Read-only live scope includes project source, nativePCB/PRO/DRU/SCH, tests,
checker, historical evidence, models, routes, checkpoints, approvals and releases.
All scratch outputs exclusively private; report to/tmp/pland-fixture-dback-20260910T213128Z/result.md. Root will
archive/adopt afterward. Full final report must include deadline/cap accounting,
all output SHA/size manifest, every packet input rehash/mutation inventory, actual
process cessation and remaining production obligations. No partial report is a
passing witness. End all writes/processes before final delivery.

Envelope aggregate formula for independent checking:
pipeline_identity.subject_identity('crow_pland_fixture_dback',1,
[TypedIdentityInput('packet','sequence',input_packet,json.dumps(input_packet,sort_keys=True).encode())]).
