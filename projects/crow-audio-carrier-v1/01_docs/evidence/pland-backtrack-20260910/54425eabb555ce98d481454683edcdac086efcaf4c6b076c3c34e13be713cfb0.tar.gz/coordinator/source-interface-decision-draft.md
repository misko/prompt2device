# Native interface and rule authority — coordinator preparation

Private judgment preparation, not adopted production source or a native test.
The original checker and native board remain unchanged. This note retains the
prior three-failure caps; it does not authorize another census/API retry.

## Measured source evidence

The installed Python binding reports KiCad10.0.4 (with three existing property
enum assertions). Official matching-tag source was fetched with full command
logs from the KiCad GitHub mirror. Two guessed provider filenames returned404;
the official directory listing then identified the actual filenames. None of
these fetches establishes an executed native fixture verdict.

- [PAD clearance source](https://github.com/KiCad/kicad/blob/10.0.4/pcbnew/pad.cpp),
  lines1638–1655: the pad's explicit optional override takes priority over its
  footprint's override. Empty and explicit zero are distinct source values.
- [DRC rule engine](https://github.com/KiCad/kicad/blob/10.0.4/pcbnew/drc/drc_engine.cpp),
  lines1135–1207: nonzero local overrides are resolved before custom rules and
  compared with the board minimum. Thus prototype behavior that applies custom
  clearance after GetOwnClearance is not generally the native precedence.
  Explicit zero enters a distinct control path, requiring native evidence.
- The same source returns a matched explicit rule at1842 before its later
  implicit/local board-minimum fallback. The manual's blanket absolute-minimum
  language is insufficient to claim how every custom case executes. A maintained
  native below-minimum control or explicit unsupported classification is owed.
- [Copper provider](https://github.com/KiCad/kicad/blob/10.0.4/pcbnew/drc/drc_test_provider_copper_clearance.cpp),
  lines253–263, and [width provider](https://github.com/KiCad/kicad/blob/10.0.4/pcbnew/drc/drc_test_provider_track_width.cpp),
  lines96–112, consume the selected rule constraint and severity. No separate
  provider clamp appears in these inspected paths. This is source inspection,
  not proof of the complete native executable on a candidate.
- [Connected-item implementation](https://github.com/KiCad/kicad/blob/10.0.4/pcbnew/board_connected_item.cpp),
  lines121–130: GetOwnClearance requires an initialized board DRC engine and
  otherwise returns zero. Engine GetCachedOwnClearance at2970ff evaluates a
  singleton item with no B, and caches by UUID/layer. It is neither a raw class
  clearance getter nor a complete candidate/obstacle pair oracle.

## Execution-interface diagnosis

The failed census already called the maintained read_board before every wrapper
error, but delayed serializing those useful fields until after optional API
introspection. Consequently all three commands lost their census output:
PAD.GetNetClass was absent; GetEffectiveNetClass returned an opaque pointer;
GetConstituentNetclasses returned a noniterable pointer. The first error was
followed by broader introspection of class containers that the simple Default/
Low/High fixture did not need. No fourth probe is authorized by this draft.

The upstream interface decision should replace speculative C++ container access
with the repository's exercised native scalar/polygon interface. Existing
escape_check.read_board uses GetNetClassName, GetNetname, position, CuStack,
GetEffectivePolygon and returns fully serializable records after converting
layer frozensets. Its old declared-floor resolver is already the causal parser
under study; floor results must remain labeled old-reader values. Native DRC
remains an independent oracle for actual track/rule behavior.

Do not make optional class-implementation introspection a prerequisite for
publishing required census fields. Compound-class implementation can be handled
as a separate supported/unsupported semantic case during production repair;
plain netclass names in these specific specimens do not require container
enumeration. This is a change to the diagnostic dependency/interface contract,
not a claim that an unexecuted fourth census or the old test WIP passed.

## Public contract migration identified from current source

- Retain CAL_ELEVEN identities and declared floors in t1_escape_tier; replace
  assertions of a sampled maximum with actual witness/non-witness properties.
  Any changed finding population needs a native causal explanation.
- Preserve the relaxed-board positive, clearance-relaxation round trip,
  zero-denominator/missing-board/unreadable cases, pour/via/no-net inventory,
  and the declared no-floor vacuity with its must-pass then must-fail contrast.
- Retire the routed 'WIDER than maximum' claim. Existing copper may be counted
  and checked as an explicit candidate where supported, but a finite search
  returning no witness does not prove physical impossibility or model refutation.
- Preserve historical routing-grid guidance while changing the final causal
  sentence: no validated sampled witness is unresolved, not proof of width failure.
- Correct the printed sampling cap without changing MAX_LAUNCH_PTS25 or its
  grid: five intervals yield6x6 points plus center, at most37 per simple polygon.
- Add synchronized P-LAND homes in the template and project04 contracts with
  native/rule/support/census and scope limits. No frozen checkpoint restamp.

The source interface decision must be adjudicated with the completed fresh
D-BACK handback. All author caps, physical gates, and production guard groups
remain open; this draft is not a new implementation commission.
