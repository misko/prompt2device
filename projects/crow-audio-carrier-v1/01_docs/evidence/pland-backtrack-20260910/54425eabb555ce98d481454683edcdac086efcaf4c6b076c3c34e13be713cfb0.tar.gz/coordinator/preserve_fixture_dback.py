from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,shutil,subprocess,tarfile
r=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');p=r/'projects/crow-audio-carrier-v1';d=Path(__file__).parent
private=Path('/tmp/pland-fixture-dback-20260910T213128Z');packet=p/'06_build/handoffs/pland-fixture-dback-20260910T213128Z';e=p/'01_docs/evidence/pland-backtrack-20260910'
sha=lambda b:hashlib.sha256(b).hexdigest()
report=private/'result.md';assert sha(report.read_bytes())=='b64d4724f96f0fd29acdf99fe8843af915bd5b01b32da9934345756a23db9ec4'
env=json.loads((packet/'task-envelope.json').read_text());changes=[]
for x in env['input_packet']:
 q=r/x['path'];b=q.read_bytes();assert not q.is_symlink()
 if sha(b)!=x['sha256'] or len(b)!=x['size']:changes.append(x['path'])
assert not changes,changes
out=json.loads((private/'output-manifest.json').read_text());assert out['count']==len(out['entries'])==83
for x in out['entries']:
 q=private/x['path'];assert q.is_file() and not q.is_symlink();b=q.read_bytes()
 assert sha(b)==x['sha256'] and len(b)==x['size'],x['path']
assert (private/'output-manifest.sha256').read_text().split()[0]==sha((private/'output-manifest.json').read_bytes())
proc=json.loads((private/'process-audit.json').read_text());assert proc['all_captured_children_absent'] and not proc['remaining_matching_processes']
assert all(not Path('/proc',str(x['pid'])).exists() for x in proc['captured_children'])
audit=dict(time=datetime.now(timezone.utc).isoformat(),inputs=len(env['input_packet']),changes=changes,verified_output_rows=83,report_sha256=sha(report.read_bytes()),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),captured_children_absent=True)
(d/'fixture-root-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
sources=[(q,'diagnosis/'+q.relative_to(private).as_posix()) for q in private.rglob('*') if q.is_file()]
sources += [(q,'commission/'+q.relative_to(packet).as_posix()) for q in packet.rglob('*') if q.is_file()]
supplement=[q for q in d.iterdir() if q.is_file() and (q.name.startswith('authority-') or q.suffix=='.cpp' or q.name in ['drc-directory-10.0.4.json','source-interface-decision-draft.md','scalar-fixture-proposal.py','fixture-root-audit.json','preserve_fixture_dback.py'])]
sources += [(q,'coordinator/'+q.name) for q in supplement]
rows=[];temp=d/'fixture-dback-complete.tar.gz'
with tarfile.open(temp,'w:gz') as tf:
 for q,name in sorted(sources,key=lambda x:x[1]):
  assert not q.is_symlink();b=q.read_bytes();tf.add(q,arcname=name,recursive=False)
  rows.append(dict(member=name,original_path=str(q),sha256=sha(b),size=len(b)))
digest=sha(temp.read_bytes())
with tarfile.open(temp) as tf:
 members=tf.getmembers();assert len(members)==len(rows)==len({m.name for m in members})
 for m,x in zip(members,rows):
  assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
  assert m.name==x['member'] and m.size==x['size'] and sha(tf.extractfile(m).read())==x['sha256']
target=e/(digest+'.tar.gz');assert not target.exists();shutil.copy2(temp,target)
shutil.copy2(report,e/'fixture-dback-result.md')
(e/'fixture-dback-manifest.json').write_text(json.dumps(dict(schema=1,created_at=audit['time'],source_commit=audit['head'],tar_sha256=digest,tar_size=target.stat().st_size,count=len(rows),entries=rows),indent=2)+'\n')
c=e/'contracts.md';t=c.read_text();anchor='| `contracts.md` | this exact dated contract | no wildcard evidence namespace |';assert t.count(anchor)==1
c.write_text(t.replace(anchor,'\n'.join([f'| `{digest}.tar.gz` | complete failed fixture diagnosis and coordinator interface/source preparation | exact regular members verified by fixture-dback-manifest.json; original failures retained |','| `fixture-dback-manifest.json` | original-path, SHA256 and size inventory | all failed scripts, full logs, audits and unexecuted proposals retain their proof limits |','| `fixture-dback-result.md` | verbatim incomplete fresh fixture-admission judgment | three binding failures do not establish a native census or behavioral RED |','| `fixture-dback-adoption.md` | coordinator upstream interface and decomposed ownership decision | retains every prior cap and all unresolved production gates |',anchor])))
print(json.dumps(dict(audit=audit,archive_sha256=digest,members=len(rows),size=target.stat().st_size),indent=2))
