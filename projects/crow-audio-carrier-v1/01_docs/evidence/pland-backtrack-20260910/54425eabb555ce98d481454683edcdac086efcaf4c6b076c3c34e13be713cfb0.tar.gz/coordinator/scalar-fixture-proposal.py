"""UNEXECUTED proposal: deterministic fixture using exercised pcbnew calls.

This is an upstream interface design artifact, not an author retry or evidence
of native/CLI success. Execution requires coordinator adoption and a bounded
fresh handoff. No production file is written by this module.
"""
from pathlib import Path
import json, sys
import pcbnew

OUT = Path(sys.argv[1]).resolve()
EXPECTED = {
    'central': 'X1.1', 'receiver': 'X1.2', 'copper_pads': 5,
    'graded_declared_floor': 2, 'floorless': 3, 'floor_mm': .2,
    'pad_width_mm': .1, 'central_and_sibling_height_mm': .8,
    'sibling_pitch_mm': .36, 'candidate_width_mm': .2,
    'candidate_start_mm': [10, 10], 'candidate_end_mm': [10, 11],
    'static_pad_gap_mm': .26, 'candidate_to_sibling_gap_mm': .21,
    'base_local_clearance_mm': .1, 'hostile_local_clearance_mm': .25,
    'remote_clearance_mm': .25, 'original_sampled_maximum_mm': .12,
    'prediction': 'Original public X1.1 fails at nonzero denominator; native base launch passes; hostile native launch has two track clearance violations and no static pad clearance violation.'
}

def v(x, y):
    return pcbnew.VECTOR2I(round(x*1e6), round(y*1e6))

def emit(hostile):
    d = OUT / ('hostile' if hostile else 'base')
    d.mkdir(parents=True, exist_ok=False)
    (d/'hypothesis.json').write_text(json.dumps(EXPECTED, indent=2)+'\n')
    b = pcbnew.BOARD()
    b.SetCopperLayerCount(2)
    patterns = []
    nets = {}
    assignments = {'TARGET': 'ADC', 'LEFT': 'High' if hostile else 'Low',
                   'RIGHT': 'High' if hostile else 'Low', 'REMOTE': 'High'}
    for name, cls in assignments.items():
        n = pcbnew.NETINFO_ITEM(b, name)
        b.Add(n)
        nets[name] = n
        patterns.append({'netclass': cls, 'pattern': name})
    fp = pcbnew.FOOTPRINT(b)
    fp.SetReference('X1')
    fp.SetValue('scalar_interface_fixture')
    fp.SetPosition(v(10, 10))
    fp.SetAttributes(pcbnew.FP_SMD | pcbnew.FP_EXCLUDE_FROM_BOM | pcbnew.FP_EXCLUDE_FROM_POS_FILES)
    for number, x, y, height, name in [(1, 10, 10, .8, 'TARGET'),
                                      (2, 10, 11, .2, 'TARGET'),
                                      (3, 9.64, 10, .8, 'LEFT'),
                                      (4, 10.36, 10, .8, 'RIGHT'),
                                      (5, 12, 10, .8, 'REMOTE')]:
        p = pcbnew.PAD(fp)
        p.SetNumber(str(number))
        p.SetAttribute(pcbnew.PAD_ATTRIB_SMD)
        p.SetShape(pcbnew.PAD_SHAPE_RECT)
        p.SetSize(v(.1, height))
        p.SetPosition(v(x, y))
        ls = pcbnew.LSET()
        ls.AddLayer(pcbnew.F_Cu)
        p.SetLayerSet(ls)
        p.SetNet(nets[name])
        fp.Add(p)
    for a, c in [((9.2, 9.3), (12.3, 9.3)), ((12.3, 9.3), (12.3, 11.4)),
                 ((12.3, 11.4), (9.2, 11.4)), ((9.2, 11.4), (9.2, 9.3))]:
        s = pcbnew.PCB_SHAPE(fp)
        s.SetShape(pcbnew.SHAPE_T_SEGMENT)
        s.SetLayer(pcbnew.F_CrtYd)
        s.SetStart(v(*a)); s.SetEnd(v(*c)); s.SetWidth(50000)
        fp.Add(s)
    b.Add(fp)
    for a, c in [((5, 5), (15, 5)), ((15, 5), (15, 15)),
                 ((15, 15), (5, 15)), ((5, 15), (5, 5))]:
        s = pcbnew.PCB_SHAPE(b)
        s.SetShape(pcbnew.SHAPE_T_SEGMENT)
        s.SetLayer(pcbnew.Edge_Cuts)
        s.SetStart(v(*a)); s.SetEnd(v(*c)); s.SetWidth(50000)
        b.Add(s)
    public = d/'public.kicad_pcb'
    oracle = d/'oracle.kicad_pcb'
    pcbnew.SaveBoard(str(public), b)
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(v(10, 10)); t.SetEnd(v(10, 11)); t.SetWidth(200000)
    t.SetLayer(pcbnew.F_Cu); t.SetNet(nets['TARGET']); b.Add(t)
    pcbnew.SaveBoard(str(oracle), b)
    pro = {'board': {'design_settings': {'rules': {'min_clearance': .1, 'min_track_width': .1}, 'drc_exclusions': []}},
           'net_settings': {'classes': [{'name': k, 'clearance': c, 'track_width': .2,
                                        'via_diameter': .6, 'via_drill': .3}
                                       for k, c in [('Default', .1), ('ADC', .1), ('Low', .1), ('High', .25)]],
                            'netclass_patterns': patterns},
           'meta': {'version': 1}}
    dru = '(version 1)\n(rule "ADC_width" (condition "A.NetClass == \'ADC\'") (constraint track_width (min 0.2mm)))\n'
    # Persist project assignments after ALL native board saves.
    for target in (public, oracle):
        pro['meta']['filename'] = target.with_suffix('.kicad_pro').name
        target.with_suffix('.kicad_pro').write_text(json.dumps(pro, indent=2)+'\n')
        target.with_suffix('.kicad_dru').write_text(dru)
    (d/'expected-assignments.json').write_text(json.dumps(assignments, indent=2)+'\n')
    print(json.dumps({'label': d.name, 'public': str(public), 'oracle': str(oracle), 'hypothesis': EXPECTED}), flush=True)

if __name__ == '__main__':
    emit(False)
    emit(True)
