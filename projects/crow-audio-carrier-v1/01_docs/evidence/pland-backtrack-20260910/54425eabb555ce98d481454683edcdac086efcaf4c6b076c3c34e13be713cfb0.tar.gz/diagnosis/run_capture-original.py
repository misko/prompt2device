from pathlib import Path
from datetime import datetime, timezone
import json, os, signal, subprocess, time
ROOT = Path(__file__).parent
REPO = Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
def run(argv, stem, timeout=120):
    start = datetime.now(timezone.utc).isoformat()
    meta = dict(argv=[str(x) for x in argv], cwd=str(REPO), start=start, timeout_seconds=timeout)
    (ROOT/(stem+'.start.json')).write_text(json.dumps(meta, indent=2)+'\n')
    t = time.monotonic()
    with (ROOT/(stem+'.log')).open('wb') as out:
        process = subprocess.Popen(meta['argv'], cwd=REPO, stdout=out, stderr=subprocess.STDOUT, start_new_session=True)
        timed_out = False
        try:
            rc = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                rc = process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                rc = process.wait()
    meta.update(rc=rc, timed_out=timed_out, duration_seconds=time.monotonic()-t,
                end=datetime.now(timezone.utc).isoformat(), pid=process.pid)
    (ROOT/(stem+'.result.json')).write_text(json.dumps(meta, indent=2)+'\n')
    print(json.dumps(meta), flush=True)
    return rc
