from pathlib import Path
from datetime import datetime, timezone
import json, os, signal, subprocess, time, hashlib, sys
ROOT=Path(__file__).parent
REPO=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
CHECKER=REPO/'skills/kicad-pcb/scripts/escape_check.py'
STOP=datetime.fromisoformat('2026-09-10T21:54:28+00:00')
def stamp():return datetime.now(timezone.utc).isoformat()
def sha():return hashlib.sha256(CHECKER.read_bytes()).hexdigest()
def run(argv,stem,timeout=60):
    now=datetime.now(timezone.utc); budget=min(timeout,60,(STOP-now).total_seconds())
    assert budget>1, 'closure reserve reached'
    meta=dict(argv=[str(x) for x in argv],cwd=str(REPO),start=stamp(),timeout_seconds=budget,checker_sha256_before=sha(),head_before=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip())
    startfile=ROOT/(stem+'.start.json');startfile.write_text(json.dumps(meta,indent=2)+'\n');t=time.monotonic()
    with (ROOT/(stem+'.stdout.log')).open('wb') as out, (ROOT/(stem+'.stderr.log')).open('wb') as err:
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
        p=subprocess.Popen(meta['argv'],cwd=REPO,stdout=out,stderr=err,start_new_session=True,env=env)
        meta['pid']=p.pid;startfile.write_text(json.dumps(meta,indent=2)+'\n');timed_out=False
        try:rc=p.wait(timeout=budget)
        except subprocess.TimeoutExpired:
            timed_out=True;os.killpg(p.pid,signal.SIGTERM)
            try:rc=p.wait(timeout=2)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait()
    meta.update(rc=rc,timed_out=timed_out,duration_seconds=time.monotonic()-t,end=stamp(),checker_sha256_after=sha(),process_reaped=p.poll() is not None)
    (ROOT/(stem+'.result.json')).write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta),flush=True);return rc
if __name__=='__main__':sys.exit(run(sys.argv[2:],sys.argv[1]))
