import pcbnew,json,sys,pathlib
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/kicad-pcb/scripts')
import escape_check as ec
out=[]
for arg in sys.argv[1:]:
 path=pathlib.Path(arg);b=pcbnew.LoadBoard(str(path)); rules=ec.read_dru_rules(path.with_suffix('.kicad_dru')); pads,unreached,areas,pours,vias,tracks=ec.read_board(path)
 rec={'path':str(path),'native_version':pcbnew.Version(),'pro':json.loads(path.with_suffix('.kicad_pro').read_text()),'rules_old_parser':rules,'native_pads':[],'old_reader_pads':[],'unreached':unreached,'tracks':tracks,'vias':vias,'zones':len(list(b.Zones()))}
 for fp in b.GetFootprints():
  for p in fp.Pads():
   c=p.GetNetClass(); n=p.GetNet()
   entry={'ref':fp.GetReference(),'num':p.GetNumber(),'net':p.GetNetname(),'net_code':p.GetNetCode(),'net_class_name':p.GetNetClassName(),'class_object_name':c.GetName(),'class_clearance_mm':pcbnew.ToMM(c.GetClearance()),'position_mm':[pcbnew.ToMM(p.GetPosition().x),pcbnew.ToMM(p.GetPosition().y)],'size_mm':[pcbnew.ToMM(p.GetSize().x),pcbnew.ToMM(p.GetSize().y)],'shape_enum':p.GetShape(),'attribute_enum':p.GetAttribute(),'orientation_deg':p.GetOrientation().AsDegrees(),'layer_ids':list(p.GetLayerSet().CuStack()),'class_api':[x for x in dir(c) if any(t in x.lower() for t in ['constituent','compound','class','name'])]}
   for method in ('IsDefault','IsNull','IsComposite'):
    if hasattr(c,method):entry[method]=getattr(c,method)()
   if hasattr(c,'GetConstituentNetclasses'):
    entry['constituent_names']=[x.GetName() for x in c.GetConstituentNetclasses()]
   shape=p.GetEffectivePolygon(pcbnew.F_Cu);entry['native_outlines']=[[[pcbnew.ToMM(shape.Outline(i).CPoint(j).x),pcbnew.ToMM(shape.Outline(i).CPoint(j).y)] for j in range(shape.Outline(i).PointCount())] for i in range(shape.OutlineCount())]
   rec['native_pads'].append(entry)
 for p in pads:
  floor,rule=ec.resolve_min(rules,'track_width',p,areas);rec['old_reader_pads'].append({**p,'layers':sorted(p['layers']),'resolved_floor':floor,'resolved_rule':rule,'sample_count':len(ec.launch_points(p['poly']))})
 out.append(rec)
print(json.dumps(out,indent=2))
