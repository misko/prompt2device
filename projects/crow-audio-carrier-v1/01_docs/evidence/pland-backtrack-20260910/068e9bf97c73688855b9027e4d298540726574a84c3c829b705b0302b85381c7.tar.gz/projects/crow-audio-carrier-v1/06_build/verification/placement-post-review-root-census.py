import pcbnew,json,pathlib,collections,time,re,sys
P=pathlib.Path(__file__).parent; OUT=P
b=pcbnew.LoadBoard(str(P/'04_kicad/crow_audio_carrier_v1.kicad_pcb')); c=b.GetConnectivity();c.Build(b);c.RecalculateRatsnest();before=c.GetUnconnectedCount(False)
t=time.monotonic(); pcbnew.ZONE_FILLER(b).Fill(b.Zones());c.Build(b);c.RecalculateRatsnest(); after=c.GetUnconnectedCount(False)
print('native',before,after,'fill',time.monotonic()-t,flush=True)
items=[p for f in b.GetFootprints() for p in f.Pads() if p.GetNetCode()>0]+list(b.GetTracks()); byid={x.m_Uuid.AsString():x for x in items}; parent={k:k for k in byid}
def find(k):
 while parent[k]!=k:parent[k]=parent[parent[k]];k=parent[k]
 return k
def union(a,d):
 if a in parent and d in parent:parent[find(a)]=find(d)
for i in items:
 for connected in c.GetConnectedItems(i):union(i.m_Uuid.AsString(),connected.m_Uuid.AsString())
groups=collections.defaultdict(lambda:collections.defaultdict(list))
for i in items:
 k=i.m_Uuid.AsString(); ident=dict(uuid=k,net=i.GetNetname(),kind=type(i).__name__,x=pcbnew.ToMM(i.GetPosition().x),y=pcbnew.ToMM(i.GetPosition().y))
 if isinstance(i,pcbnew.PAD):ident.update(ref=i.GetParentFootprint().GetReference(),pad=i.GetNumber(),layers=[b.GetLayerName(l) for l in i.GetLayerSet().Seq() if b.IsLayerEnabled(l)],size_mm=[pcbnew.ToMM(i.GetSize().x),pcbnew.ToMM(i.GetSize().y)])
 groups[i.GetNetname()][find(k)].append(ident)
result={net:list(g.values()) for net,g in sorted(groups.items())}; derived=sum(max(0,len(g)-1) for g in result.values()); print('group-derived',derived,'nets',len(result),flush=True)
(OUT/'connectivity.json').write_text(json.dumps(dict(method='BOARD.GetConnectivity; Build; RecalculateRatsnest; GetUnconnectedCount(False); native ZONE_FILLER.Fill; union of transitive GetConnectedItems over every pad/track/via (zone objects themselves never unioned; each returned copper-connected pad/track is)',saved_unfilled_native_count=before,refilled_native_count=after,derived_component_deficit=derived,fill_seconds=time.monotonic()-t,nets=result),indent=2)+'\n')
print('footprints',len(list(b.GetFootprints())),'physicalpads',sum(len(list(f.Pads())) for f in b.GetFootprints()),'trace_segments',sum(not isinstance(t,pcbnew.PCB_VIA) for t in b.GetTracks()),'vias',sum(isinstance(t,pcbnew.PCB_VIA) for t in b.GetTracks()),flush=True)
