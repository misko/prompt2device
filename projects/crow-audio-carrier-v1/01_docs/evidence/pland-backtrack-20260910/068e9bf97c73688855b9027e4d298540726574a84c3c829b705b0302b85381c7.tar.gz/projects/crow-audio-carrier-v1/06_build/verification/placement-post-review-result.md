# Placement post review result

Status: STOPPED / FAILED at P-LAND [5a]. No route import occurred.

TaskEnvelope `placement-post-review-20260910T192615Z`; verified packet 500/500 exact, envelope SHA256 `257848f4190db7bdf61dab4f070e3c10b260a48bce20ae4e5bb71aa9b1f033d1`.

Command: `/usr/bin/python3 skills/kicad-pcb/scripts/pcb_flow.py run ... --stage placement_after_canonical_review --budget-s 600 --timeout-s 600 -- bash .../03_src/rebuild_all.sh --resume-after-schematic-review`; rc=1, elapsed 45.753 s; full log `06_build/placement-post-review.log`.

First stopping gate: P-LAND [5a]. 677/940 copper pads graded; 14 failed. ADC pads U_ADC.14/.15/.16/.19/.20/.21/.22/.39/.40/.41/.45/.46/.47: landable 0.100 mm, floor 0.200 mm, clearance 0.250 mm, short 0.100 mm. U_BUCK.5 net BUCK_SW: landable 0.800 mm, floor 1.200 mm, short 0.400 mm. Underlying independent gaps: 14 pad launch gaps.

Measured native checks before stop: 0 DRC violations, 0 schematic parity issues; the raw DRC report contains 499 unconnected report rows (capped/report-level). A private in-memory pcbnew probe using `GetConnectivity().Build`, zone fill, `RecalculateRatsnest`, and `GetUnconnectedCount(False)` measured 14 unconnected items after refill (717 before refill). Board census: 340 footprints, 1002 pads, 11 tracks, 11 vias. P-LAND therefore stopped the engineering sequence despite clean physical DRC. No route import, promotion, seal, or approval.

Bindings: raw CircuitJSON `e0f1275799fd2fa1529fb11e2275d26a2775a4e390987eedb7ea12dccdcaf55d`; native SCH `b95cfca75a079b4b155a4fa24aa2c548fcaef779cd72271e5212a18529856674`; raw NET `3364e97284060bace699f887900baf1fc8fcc8090355f5f6b2c35332901bdb44`; PCB `89d33bae8eaf67457fde887eae9db187d9284ea54be386f0d31e3d7dfe92bf2e`; PRO `4a1040e34967d6610bd5032e46b3c2d0e24863370106f7e220d88d4dd633c61d`; DRU `94251d1c7cb043c66d402d55b5cf89bac74f7ae0927b012556113ae56d7a2471`; normalized NET `471b96bf68be1fc3e5425b97cdace0f4a11cf929929011cf55170248f2129f9a`; parts `2f76a9ca1a8b2e3cf948d3b43fbbbc6ad101f1fccd58de1d7ecd05c556b2f38d`; rules `672f0b9be3b3f9b6c2a9c9c1b1ea0e12ff4d91f061ede29ac36d6ac71965b8a4`. Compact handoff generated and validated rc=0. Original command stdout was only available as truncated tool output; no fabricated log was created. All owned processes ended; ownership returned to root.
