"""Read exact rules independently; native item overlap; per-pair rules in file order."""
import json,re,math
import pcbnew
from native_diagnosis import OUT,STEM,EXACT,CLEAR,sexp,child,val,uid,xy,dump

b=pcbnew.LoadBoard(str(OUT/'coupon'/f'{STEM}.kicad_pcb'))
areas={z.GetZoneName():z for z in b.Zones() if z.GetIsRuleArea()}
tree=sexp('('+ (EXACT/f'{STEM}.kicad_dru').read_text()+')')
rules=[]
for r in tree:
    if r[0]!='rule':continue
    cond=val(r,'condition') if len(child(r,'condition'))>1 else '1'
    for c in r:
        if isinstance(c,list) and c and c[0]=='constraint' and c[1] in ['clearance','track_width']:
            rules.append({'name':r[1],'kind':c[1],'min':float(val(c,'min').removesuffix('mm')),'condition':cond})

def expression(text,A,B):
    items={'A':A,'B':B}
    def area(m):
        p=items[m[1]];z=areas[m[2]]
        if p is None:return '0'
        # All tested coupon tracks and neighbors are F.Cu; retain layer scope.
        hit=z.IsOnLayer(pcbnew.F_Cu) and z.Outline().Collide(p.GetEffectiveShape(pcbnew.F_Cu),0)
        return '1' if hit else '0'
    text=re.sub(r"([AB])\.insideArea\('([^']+)'\)",area,text)
    def prop(m):
        p=items[m[1]]
        if p is None:return '0'
        got={'NetName':p.GetNetname(),'NetClass':p.GetNetClassName(),'Type':'Pad' if isinstance(p,pcbnew.PAD) else 'Track'}[m[2]]
        return '1' if got==m[3] else '0'
    text=re.sub(r"([AB])\.(NetName|NetClass|Type)\s*==\s*'([^']+)'",prop,text)
    toks=re.findall(r'&&|\|\||[()01]',text)
    assert ''.join(toks)==re.sub(r'\s','',text),text
    # KiCad's boolean operators use equal precedence, evaluated left-to-right.
    def seq(i):
        def atom(i):
            if toks[i]=='(':
                v,j=seq(i+1);assert toks[j]==')';return v,j+1
            return toks[i]=='1',i+1
        left,i=atom(i)
        while i<len(toks) and toks[i]!=')':
            op=toks[i];right,i=atom(i+1);left=left and right if op=='&&' else left or right
        return left,i
    return seq(0)[0]

def resolved(A,B,kind):
    hits=[]
    for r in rules:
        if r['kind']==kind and (expression(r['condition'],A,B) or (B is not None and expression(r['condition'],B,A))):hits.append(r)
    base=max(CLEAR.get(A.GetNetClassName(),0),CLEAR.get(B.GetNetClassName(),0) if B else 0)
    return {'base_pair_clearance':base if kind=='clearance' else None,'all_matching_rules':hits,'resolved_mm':hits[-1]['min'] if hits else base,'resolved_name':hits[-1]['name'] if hits else 'netclass pair maximum'}

items={f'{p.GetParentFootprint().GetReference()}.{p.GetNumber()}':p for f in b.GetFootprints() for p in f.Pads() if p.IsOnLayer(pcbnew.F_Cu)}
tracks={uid(t):t for t in b.GetTracks()}
rows=json.loads((OUT/'fourteen-native-launches.json').read_text())
for row in rows:
    t=tracks[row['source_launch'][0]['uuid']]
    row['native_overlap_width_resolution']=resolved(t,None,'track_width')
    for ob in row['obstacles']:
        q=items[ob['ref']+'.'+ob['pad']];ob['native_overlap_pair_rule']=resolved(t,q,'clearance')
        ob['clearance_margin_mm']=None if ob['native_gap_mm'] is None else round(ob['native_gap_mm']-ob['native_overlap_pair_rule']['resolved_mm'],6)
    row['minimum_pair_clearance_margin_mm']=min(x['clearance_margin_mm'] for x in row['obstacles'] if x['clearance_margin_mm'] is not None)
    if row['pin']=='U_BUCK.5':
        row['source_narrow_capsule_bbox_mm']=[43.225,65.625,44.875,66.375]
        row['source_scope_rect_mm']=[43.2,65.6,44.9,66.4]
        row['source_capsule_wholly_contained']=True
        row['scope_center_offset_mm']=43.2-row['center'][0]
        row['path_model_limit']='Authored narrow leg is 0.900 mm at 0.750 mm then 1.315 mm at 1.200 mm; P-LAND models one constant-width 1.000-mm leg. These are different path measures.'
    print(row['pin'],row['native_overlap_width_resolution']['resolved_name'],row['minimum_pair_clearance_margin_mm'],[(x['ref']+'.'+x['pad'],x['native_gap_mm'],x['native_overlap_pair_rule']['resolved_name'],x['native_overlap_pair_rule']['resolved_mm']) for x in row['obstacles'][:2]],flush=True)
dump('fourteen-pair-rule-classification.json',{'method':'Independent s-expression rule reader and boolean evaluator; retains both A/B conditions, pad/track types, net restrictions, native F.Cu item overlap, file-order last match. Boolean operators evaluated left-to-right per KiCad10 manual. Native DRC independently checks actual coupon; this resolver is explanatory evidence, not a replacement gate.','manual':'https://docs.kicad.org/10.0/en/pcbnew/pcbnew.html#custom-design-rules','rows':rows})
