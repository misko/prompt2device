"""Refine unchanged candidate evidence, repair library context, never alter copper."""
import collections, json, pathlib, sys, math
import pcbnew
from native_diagnosis import OUT,ROOT,PROJECT,STEM,EXACT,FLOOR,ROUTE,CLEAR,sha,dump,uid,xy,Union,run

def library_context():
    native=json.loads((OUT/'native-board-facts.json').read_text())
    libs=sorted({x['fpid'].split(':')[0] for x in native['footprints'].values()})
    custom={x['lib']:str(PROJECT/x['path']) for x in FLOOR.get('libraries',[]) if isinstance(x,dict)}
    rows=[]
    for lib in libs:
        path=pathlib.Path(custom.get(lib,f'/usr/share/kicad/footprints/{lib}.pretty'));assert path.is_dir(),path
        rows.append(f'  (lib (name "{lib}")(type "KiCad")(uri "{path}")(options "")(descr "private exact-context resolution"))')
    txt='(fp_lib_table\n  (version 7)\n'+'\n'.join(rows)+'\n)\n'
    out=[]
    for folder,label in [(EXACT,'exact'),(OUT/'coupon','coupon'),(OUT/'control','control')]:
        bound={ext:sha(folder/f'{STEM}.{ext}') for ext in ['kicad_pcb','kicad_pro','kicad_dru','kicad_sch']}
        (folder/'fp-lib-table').write_text(txt)
        target=OUT/f'{label}-context-drc.json'
        run(label+'-context-drc',['kicad-cli','pcb','drc','--format','json','--severity-all','--refill-zones','--schematic-parity','--exit-code-violations','-o',str(target),str(folder/f'{STEM}.kicad_pcb')])
        assert bound=={ext:sha(folder/f'{STEM}.{ext}') for ext in bound}
        doc=json.loads(target.read_text());out.append({'label':label,'unchanged':bound,'table_sha':sha(folder/'fp-lib-table'),'counts':dict(collections.Counter(x['type'] for x in doc['violations'])),'physical_rows':doc['violations'],'parity':doc['schematic_parity'],'raw_open_count':len(doc['unconnected_items'])})
    dump('context-repair.json',{'library_paths':custom,'results':out})

def native_zone_mapping(label,folder,rawfile):
    b=pcbnew.LoadBoard(str(folder/f'{STEM}.kicad_pcb'));c=b.GetConnectivity();c.Build(b);pcbnew.ZONE_FILLER(b).Fill(b.Zones());c.Build(b);c.RecalculateRatsnest()
    conn=json.loads((OUT/f'{label}-connectivity.json').read_text());index={x['uuid']:{'net':net,'component':i,'item':x} for net,v in conn['nets'].items() for i,part in enumerate(v['components']) for x in part}
    allitems=[p for f in b.GetFootprints() for p in f.Pads() if p.GetNetCode()>0]+list(b.GetTracks());zones={}
    for z in b.Zones():
        if z.GetIsRuleArea():continue
        polygons=[]
        for layer in z.GetLayerSet().CuStack():
            ps=z.GetFilledPolysList(layer)
            for n in range(ps.OutlineCount()):
                unit=ps.UnitSet(n);contacts=[]
                for item in allitems:
                    if item.GetNetCode()!=z.GetNetCode() or not item.IsOnLayer(layer):continue
                    if unit.Collide(item.GetEffectiveShape(layer),1):contacts.append(index[uid(item)])
                polygons.append({'layer':int(layer),'polygon_index':n,'components':sorted({x['component'] for x in contacts}),'contact_uuids':[x['item']['uuid'] for x in contacts],'vertices':[xy(ps.Outline(n).CPoint(i)) for i in range(ps.Outline(n).PointCount())]})
        comps=sorted({i for p in polygons for i in p['components']})
        zones[uid(z)]={'net':z.GetNetname(),'polygons':polygons,'physical_components':comps,'unique_component':comps[0] if len(comps)==1 else None}
    dump(label+'-filled-zone-islands.json',zones)
    doc=json.loads(pathlib.Path(rawfile).read_text());rows=[];unresolved=[];forests={net:Union(range(len(v['components']))) for net,v in conn['nets'].items()}
    for i,row in enumerate(doc['unconnected_items']):
        ends=[]
        for e in row['items']:
            mapped=index.get(e['uuid'])
            if not mapped and e['uuid'] in zones:
                z=zones[e['uuid']]
                mapped={'net':z['net'],'component':z['unique_component'],'zone_uuid':e['uuid'],'method':'Every separately filled polygon was intersected with actual native pad/via/track shapes. All connected polygons reach the same transitive item component; whole-zone UUID was never unioned.','polygon_component_sets':[p['components'] for p in z['polygons']]}
            if not mapped or mapped['component'] is None:unresolved.append({'row':i,'raw':e})
            ends.append({'raw':e,'native':mapped})
        nets={e['native']['net'] for e in ends if e['native']};assert len(nets)==1
        net=next(iter(nets));cs=[e['native']['component'] for e in ends if e['native'] and e['native']['component'] is not None]
        for cc in cs[1:]:forests[net].merge(cs[0],cc)
        rows.append({'row':i,'net':net,'endpoints':ends,'components':cs,'type':row['type'],'severity':row['severity']})
    omitted={}
    for net,f in forests.items():
        g=collections.defaultdict(list)
        for k in f.p:g[f.find(k)].append(k)
        if len(g)>1:omitted[net]={'missing_gaps':len(g)-1,'raw_connected_groups':list(g.values()),'all_native_components':conn['nets'][net]['components']}
    dump(label+'-complete-endpoints.json',{'rows':rows,'unresolved':unresolved,'omitted':omitted,'missing_total':sum(x['missing_gaps'] for x in omitted.values()),'physical_rows':doc['violations'],'parity':doc['schematic_parity']})
    print(label,'resolved',len(rows),'unresolved',len(unresolved),'missing',sum(x['missing_gaps'] for x in omitted.values()),'zone_components',[(k,v['physical_components']) for k,v in zones.items()],flush=True)

def shape_gap(a,b):
    # Native collision threshold binary search at one-nanometre resolution;
    # no shared P-LAND polygon/segment distance or clearance resolver.
    lo,hi=0,10000000
    if not a.Collide(b,hi):return None
    while hi-lo>1:
        m=(lo+hi)//2
        if a.Collide(b,m):hi=m
        else:lo=m
    return lo/1e6

def launch_measurements():
    b=pcbnew.LoadBoard(str(OUT/'coupon'/f'{STEM}.kicad_pcb'));allpads=[p for f in b.GetFootprints() for p in f.Pads() if p.IsOnLayer(pcbnew.F_Cu)]
    padmap={f'{p.GetParentFootprint().GetReference()}.{p.GetNumber()}':p for p in allpads}
    added=json.loads((OUT/'coupon-added-copper.json').read_text())['items'];tracks={uid(t):t for t in b.GetTracks()};failpins=[f'U_ADC.{i}' for i in [14,15,16,19,20,21,22,39,40,41,45,46,47]]+['U_BUCK.5']
    results=[]
    for pin in failpins:
        p=padmap[pin];cx,cy=xy(p.GetPosition());legs=[x for x in added if x['pin']==pin];t=tracks[legs[0]['uuid']];obs=[]
        for q in allpads:
            if q.GetNetCode()==p.GetNetCode():continue
            qx,qy=xy(q.GetPosition())
            if abs(qx-cx)>2.5 or abs(qy-cy)>2.5:continue
            gap=shape_gap(t.GetEffectiveShape(pcbnew.F_Cu),q.GetEffectiveShape(pcbnew.F_Cu))
            obs.append({'ref':q.GetParentFootprint().GetReference(),'pad':q.GetNumber(),'net':q.GetNetname(),'class':q.GetNetClassName(),'xy':[qx,qy],'size':xy(q.GetSize()),'class_clearance':CLEAR.get(q.GetNetClassName(),0),'pair_class_clearance':max(CLEAR.get(q.GetNetClassName(),0),CLEAR.get(p.GetNetClassName(),0)),'native_gap_mm':gap})
        areas=[]
        for z in b.Zones():
            if not z.GetIsRuleArea():continue
            name=z.GetZoneName()
            if name.startswith('ADC') or name=='BUCK_SW_EXIT':
                poly=z.Outline();bb=poly.BBox();areas.append({'name':name,'rect_min':xy(bb.GetPosition()),'rect_size':xy(bb.GetSize()),'pad_center_inside':poly.Contains(p.GetPosition()),'launch_start_inside':poly.Contains(t.GetStart()),'pad_intersects':poly.Collide(p.GetEffectiveShape(pcbnew.F_Cu),0),'track_intersects':poly.Collide(t.GetEffectiveShape(pcbnew.F_Cu),0)})
        results.append({'pin':pin,'net':p.GetNetname(),'center':[cx,cy],'size':xy(p.GetSize()),'shape':int(p.GetShape()),'source_launch':legs,'outward_direction_degrees':round(math.degrees(math.atan2(t.GetEnd().y-t.GetStart().y,t.GetEnd().x-t.GetStart().x)),6),'obstacles':sorted(obs,key=lambda x:x['native_gap_mm'] if x['native_gap_mm'] is not None else 999),'scopes':areas,'class_clearance':CLEAR.get(p.GetNetClassName(),0)})
    dump('fourteen-native-launches.json',results)
    for x in results:print(x['pin'],x['net'],x['center'],x['size'],x['outward_direction_degrees'],'nearest',[(o['ref']+'.'+o['pad'],o['native_gap_mm'],o['pair_class_clearance']) for o in x['obstacles'][:3]],flush=True)

if __name__=='__main__':
    library_context()
    for label,folder in [('exact',EXACT),('coupon',OUT/'coupon'),('control',OUT/'control')]:native_zone_mapping(label,folder,OUT/f'{label}-context-drc.json')
    launch_measurements()
