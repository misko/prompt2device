"""Private independent native geometry/connectivity experiment; no live board writes."""
import collections, datetime, hashlib, json, math, pathlib, re, shutil, subprocess, sys, time
import pcbnew, yaml

OUT = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path.cwd()
PROJECT = ROOT / 'projects/crow-audio-carrier-v1'
STEM = 'crow_audio_carrier_v1'
EXACT = OUT / 'exact/04_kicad'

def dump(name, obj):
    (OUT/name).write_text(json.dumps(obj, indent=2, sort_keys=True)+'\n')

def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def semantic(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(',',':')).encode()).hexdigest()

def mm(v): return pcbnew.ToMM(v)
def xy(p): return [mm(p.x),mm(p.y)]
def uid(item): return item.m_Uuid.AsString()

def sexp(text):
    tokens=re.findall(r'"(?:\\.|[^"\\])*"|[^\s()]+|[()]',text)
    stack=[]; root=None
    for t in tokens:
        if t=='(':
            n=[]
            if stack:stack[-1].append(n)
            stack.append(n)
        elif t==')':root=stack.pop()
        else:stack[-1].append(json.loads(t) if t.startswith('"') else t)
    return root

def child(a,k):return next((x for x in a if isinstance(x,list) and x and x[0]==k),[k])
def val(a,k):return child(a,k)[1]

NET = sexp((PROJECT/f'06_build/netlists/{STEM}.net').read_text())
SOURCE = {}
NETS = {}
for n in child(NET,'nets')[1:]:
    name=val(n,'name'); members=[]
    for x in n:
        if isinstance(x,list) and x and x[0]=='node':
            pin=(val(x,'ref'),val(x,'pin'));members.append('.'.join(pin));SOURCE[pin]=name
    NETS[name]=sorted(members)
COMPONENTS={val(x,'ref'):{'value':val(x,'value'),'footprint':val(x,'footprint')} for x in child(NET,'components')[1:]}
ROUTE=yaml.safe_load((PROJECT/'03_src/route.yaml').read_text())
FLOOR=yaml.safe_load((PROJECT/'03_src/floorplan.yaml').read_text())
CLASSES=json.loads((EXACT/f'{STEM}.kicad_pro').read_text())['net_settings']['classes']
CLEAR={x['name']:x.get('clearance',0) for x in CLASSES}

def facts(b):
    fps={};pads={}
    for f in b.GetFootprints():
        ref=f.GetReference()
        fps[ref]={'uuid':uid(f),'xy':xy(f.GetPosition()),'rotation':f.GetOrientationDegrees(),'value':f.GetValue(),'fpid':f.GetFPID().GetUniStringLibId()}
        for p in f.Pads():
            rec={'uuid':uid(p),'ref':ref,'pad':p.GetNumber(),'net':p.GetNetname(),'class':p.GetNetClassName(),'xy':xy(p.GetPosition()),'size':xy(p.GetSize()),'rotation':p.GetOrientationDegrees(),'shape':int(p.GetShape()),'copper':p.IsOnCopperLayer(),'layers':list(p.GetLayerSet().Seq()),'source_net':SOURCE.get((ref,p.GetNumber()))}
            if p.IsOnCopperLayer():
                o=p.GetEffectivePolygon(pcbnew.F_Cu if p.IsOnLayer(pcbnew.F_Cu) else list(p.GetLayerSet().CuStack())[0]).Outline(0)
                rec['polygon']=[xy(o.CPoint(i)) for i in range(o.PointCount())]
            pads[uid(p)]=rec
    return {'footprints':fps,'pads':pads}

class Union:
    def __init__(self,ks):self.p={k:k for k in ks}
    def find(self,k):
        while self.p[k]!=k:self.p[k]=self.p[self.p[k]];k=self.p[k]
        return k
    def merge(self,a,b):
        if a in self.p and b in self.p:self.p[self.find(a)]=self.find(b)

def connectivity(b,label):
    c=b.GetConnectivity();c.Build(b);c.RecalculateRatsnest();before=c.GetUnconnectedCount(False)
    start=time.monotonic();pcbnew.ZONE_FILLER(b).Fill(b.Zones());c.Build(b);c.RecalculateRatsnest();after=c.GetUnconnectedCount(False)
    allitems=[p for f in b.GetFootprints() for p in f.Pads() if p.GetNetCode()>0]+list(b.GetTracks())
    u=Union(uid(x) for x in allitems); byid={uid(x):x for x in allitems}
    for x in allitems:
        for y in c.GetConnectedItems(x):u.merge(uid(x),uid(y))
    group=collections.defaultdict(lambda:collections.defaultdict(list));index={}
    for x in allitems:
        rec={'uuid':uid(x),'net':x.GetNetname(),'xy':xy(x.GetPosition()),'kind':type(x).__name__}
        if isinstance(x,pcbnew.PAD):rec.update(ref=x.GetParentFootprint().GetReference(),pad=x.GetNumber(),source_net=SOURCE.get((x.GetParentFootprint().GetReference(),x.GetNumber())))
        group[x.GetNetname()][u.find(uid(x))].append(rec)
    result={}
    for net,groups in sorted(group.items()):
        parts=sorted([sorted(v,key=lambda x:x['uuid']) for v in groups.values()],key=lambda a:a[0]['uuid'])
        result[net]={'deficit':len(parts)-1,'components':parts,'source_members':NETS.get(net,[])}
        for n,part in enumerate(parts):
            for item in part:index[item['uuid']]={'net':net,'component':n,'item':item}
    derived=sum(x['deficit'] for x in result.values())
    out={'native_unfilled':before,'native_refilled':after,'transitive_deficit':derived,'fill_s':time.monotonic()-start,'nets':result,'net_count':len(result),'trace_segments':sum(not isinstance(t,pcbnew.PCB_VIA) for t in b.GetTracks()),'vias':sum(isinstance(t,pcbnew.PCB_VIA) for t in b.GetTracks())}
    dump(f'{label}-connectivity.json',out)
    print(label,'native',before,after,'union',derived,'nets',len(result),flush=True)
    return out,index

def map_raw(report, conn,index,label):
    report=json.loads(pathlib.Path(report).read_text()); rows=[];forests={n:Union(range(len(v['components']))) for n,v in conn['nets'].items()}
    unresolved=[]
    for i,row in enumerate(report['unconnected_items']):
        endpoints=[]
        for e in row['items']:
            mapped=index.get(e['uuid'])
            if mapped is None:unresolved.append({'row':i,'endpoint':e})
            endpoints.append({'raw':e,'native':mapped})
        nets={e['native']['net'] for e in endpoints if e['native']}
        assert len(nets)==1,(i,nets)
        net=next(iter(nets));cs=[e['native']['component'] for e in endpoints if e['native']]
        for v in cs[1:]:forests[net].merge(cs[0],v)
        rows.append({'row':i,'net':net,'endpoints':endpoints,'native_distinct_components':len(set(cs)),'type':row['type'],'severity':row['severity']})
    missing={}
    for net,forest in forests.items():
        groups=collections.defaultdict(list)
        for k in forest.p:groups[forest.find(k)].append(k)
        if len(groups)>1:missing[net]={'independent_gaps_missing_from_raw':len(groups)-1,'raw_edge_connected_component_groups':list(groups.values()),'components':conn['nets'][net]['components']}
    dump(label+'-raw-endpoints.json',{'violations':report['violations'],'parity':report['schematic_parity'],'raw_open_count':len(rows),'rows':rows,'unresolved':unresolved,'omitted_by_cap':missing,'omitted_deficit':sum(v['independent_gaps_missing_from_raw'] for v in missing.values())})
    print(label,'raw',len(rows),'unresolved',len(unresolved),'cap_missing',sum(v['independent_gaps_missing_from_raw'] for v in missing.values()),flush=True)

def run(label,cmd,timeout=90):
    t=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (OUT/f'{label}.stdout.log').open('w') as f:
        try:rc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=timeout).returncode
        except subprocess.TimeoutExpired:rc=124
    rec={'command':cmd,'start':start,'duration_s':time.monotonic()-t,'rc':rc,'stdout':f'{label}.stdout.log'};dump(label+'.receipt.json',rec);print(rec,flush=True)
    return rc

def drc(folder,label):
    target=OUT/f'{label}-drc.json'
    run(label+'-drc',['kicad-cli','pcb','drc','--format','json','--severity-all','--refill-zones','--schematic-parity','--exit-code-violations','-o',str(target),str(folder/f'{STEM}.kicad_pcb')])
    return target

def create_coupon(label,control=False):
    folder=OUT/label;folder.mkdir(exist_ok=True)
    b=pcbnew.LoadBoard(str(EXACT/f'{STEM}.kicad_pcb'))
    banks=[x for x in ROUTE['prep']['seed_stubs']['stubs'] if x['net'] in ['ADC'+str(i)+pol for i in range(1,9) for pol in 'PN'] or x.get('pin')=='U_BUCK.5']
    added=[]
    for bank in banks:
        for seg in bank['segments']:
            for a,z in zip(seg['pts'],seg['pts'][1:]):
                t=pcbnew.PCB_TRACK(b);t.SetStart(pcbnew.VECTOR2I(round(a[0]*1e6),round(a[1]*1e6)));t.SetEnd(pcbnew.VECTOR2I(round(z[0]*1e6),round(z[1]*1e6)));width=seg['width']
                if control and bank.get('pin')=='U_ADC.14':width=.30
                if control and bank.get('pin')=='U_BUCK.5' and width==.75:width=1.20
                t.SetWidth(round(width*1e6));t.SetLayer(pcbnew.F_Cu);t.SetNetCode(b.FindNet(bank['net']).GetNetCode());b.Add(t)
                added.append({'uuid':uid(t),'pin':bank.get('pin'),'net':bank['net'],'width':width,'start':a,'end':z,'source_width':seg['width']})
    pcbnew.SaveBoard(str(folder/f'{STEM}.kicad_pcb'),b)
    for ext in ['kicad_pro','kicad_dru','kicad_sch']:shutil.copy2(EXACT/f'{STEM}.{ext}',folder)
    bf=facts(b);assert bf==baseline_facts
    dump(label+'-added-copper.json',{'items':added,'footprints_pads_unchanged':True,'pro_sha':sha(folder/f'{STEM}.kicad_pro'),'dru_sha':sha(folder/f'{STEM}.kicad_dru'),'board_sha':sha(folder/f'{STEM}.kicad_pcb')})
    return folder

if __name__=='__main__':
    b=pcbnew.LoadBoard(str(EXACT/f'{STEM}.kicad_pcb'));baseline_facts=facts(b)
    dump('native-board-facts.json',baseline_facts)
    pads=baseline_facts['pads'];node_discrepancies=[]
    native_nodes={(x['ref'],x['pad']):x['net'] for x in pads.values() if x['net']}
    for pin,net in SOURCE.items():
        if native_nodes.get(pin)!=net:node_discrepancies.append([pin,net,native_nodes.get(pin)])
    dump('source-bindings.json',{'source_components':len(COMPONENTS),'source_pins':len(SOURCE),'source_nets':len(NETS),'source_identities':COMPONENTS,'source_net_members':NETS,'source_nodes_sha':semantic(sorted((r,p,n) for (r,p),n in SOURCE.items())),'native_pose_pad_semantic_sha':semantic(baseline_facts),'native_footprints':len(baseline_facts['footprints']),'physical_pads':len(pads),'netted_pads':len(native_nodes),'node_discrepancies':node_discrepancies,'raw':{ext:sha(EXACT/f'{STEM}.{ext}') for ext in ['kicad_pcb','kicad_pro','kicad_dru','kicad_sch']},'raw_net':sha(PROJECT/f'06_build/netlists/{STEM}.net')})
    conn,index=connectivity(b,'exact')
    map_raw(PROJECT/'06_build/drc/pre_route.json',conn,index,'saved')
    report=drc(EXACT,'exact');map_raw(report,conn,index,'exact')
    coupon=create_coupon('coupon');control=create_coupon('control',True)
    for folder,label in [(coupon,'coupon'),(control,'control')]:
        report=drc(folder,label)
        cb=pcbnew.LoadBoard(str(folder/f'{STEM}.kicad_pcb'));cc,ci=connectivity(cb,label);map_raw(report,cc,ci,label)
    root=json.loads((PROJECT/'06_build/verification/placement-post-review-root-census.json').read_text())
    canon=lambda groups:sorted(sorted(x['uuid'] for x in group) for group in groups)
    differences=[net for net in conn['nets'] if canon(conn['nets'][net]['components'])!=canon(root['nets'].get(net,[]))]
    dump('root-census-crosscheck.json',{'nets_compared':len(conn['nets']),'partition_discrepancies':differences,'native_counts_equal':root['refilled_native_count']==conn['native_refilled']})
    print('DONE',flush=True)
