"""Complete static scope and source ownership census; proposed private regressions."""
import collections,json,pathlib,re,sys,math
import pcbnew
from native_diagnosis import OUT,ROOT,PROJECT,STEM,EXACT,ROUTE,FLOOR,CLEAR,dump,run,sha
sys.path.insert(0,str(ROOT/'skills/kicad-pcb/scripts'))
import escape_check as old

def coverage():
    pads,unreadable,areas,pours,vias,tracks=old.read_board(EXACT/f'{STEM}.kicad_pcb');rules=old.read_dru_rules(EXACT/f'{STEM}.kicad_dru')
    native=json.loads((OUT/'native-board-facts.json').read_text());lookup={(p['ref'],p['pad']):p for p in native['pads'].values() if p['copper']}
    filled=json.loads((OUT/'exact-filled-zone-islands.json').read_text());touching={u for z in filled.values() for p in z['polygons'] for u in p['contact_uuids']}
    conn=json.loads((OUT/'exact-connectivity.json').read_text());component={x['uuid']:(net,i,len(part)) for net,v in conn['nets'].items() for i,part in enumerate(v['components']) for x in part}
    lines=(OUT/'pland-reproduction.stdout.log').read_text().splitlines();graded={}
    for line in lines:
        m=re.match(r'(ok\s+|FAIL) P-LAND \S+ (\S+) net=',line)
        if m:graded[m[2]]={'result':'FAIL' if m[1]=='FAIL' else 'PASS','line':line}
    result=[]
    for p in pads:
        floor,rule=old.resolve_min(rules,'track_width',p,areas)
        if not p['net']:bucket='no_net'
        elif floor is None:bucket='no_floor'
        elif any(net==p['net'] and lay & p['layers'] and old._point_in_poly(p['c'],poly) for net,lay,poly in pours):bucket='nominal_pour_fed'
        elif any(net==p['net'] and old._point_in_poly(pos,p['poly']) for net,pos,_ in vias):bucket='via_on_pad'
        else:bucket='graded'
        f=lookup[(p['ref'],p['num'])];row={'ref':p['ref'],'pad':p['num'],'uuid':f['uuid'],'net':p['net'],'center':p['c'],'class':p['cls'],'floor':floor,'rule':rule,'bucket':bucket,'native_filled_zone_contact':f['uuid'] in touching,'native_component':component.get(f['uuid']),'static_row':graded.get(p['ref']+'.'+p['num'])};result.append(row)
    omitted=[p for p in native['pads'].values() if not p['copper']]
    counts=collections.Counter(p['bucket'] for p in result)
    dump('complete-pad-denominator.json',{'counts':dict(counts),'copper_pads':result,'noncopper_pads':omitted,'unreadable':unreadable,'physical_pad_count':len(native['pads']),'vias':vias,'nominal_pour_without_actual_fill':[r for r in result if r['bucket']=='nominal_pour_fed' and not r['native_filled_zone_contact']]})
    print('denominator',dict(counts),'noncopper',len(omitted),'pour_without_fill',sum(p['bucket']=='nominal_pour_fed' and not p['native_filled_zone_contact'] for p in result),flush=True)
    ownership={};basis=[]
    for net,v in conn['nets'].items():
        groups=[g for g,nets in ROUTE['prep']['waves']['groups'].items() if net in nets]
        if net=='GND':owner='ground source returns + filled plane topology'
        elif net.startswith('unconnected-'):owner='intentional source NC; no connection owed'
        elif net in ROUTE['prep']['waves']['exclude']:owner='deterministic source prep.seed_stubs'
        elif groups:owner='generic route wave '+','.join(groups)+' after authored partial seeds'
        else:owner='unresolved source route owner'
        stubs=[x for x in ROUTE['prep']['seed_stubs']['stubs'] if x['net']==net]
        ownership[net]={'source_owner':owner,'gap_count':v['deficit'],'source_members':v['source_members'],'native_components':v['components'],'authored_banks':stubs}
        for i in range(1,len(v['components'])):
            basis.append({'id':f'{net}:component0--component{i}','net':net,'component_a':0,'component_b':i,'endpoint_a':v['components'][0][0],'endpoint_b':v['components'][i][0],'all_members_a':v['components'][0],'all_members_b':v['components'][i],'source_owner':owner,'cause':'unrouted separate native copper components; star edge is a mathematical independent gap basis, not a proposed route'})
    dump('complete-connectivity-ownership.json',{'nets':ownership,'independent_gap_basis':basis,'gap_count':len(basis),'GND_gaps':sum(x['net']=='GND' for x in basis),'other_gaps':sum(x['net']!='GND' for x in basis),'method':'Union of actual native connected items after refill, no union of whole zone UUIDs. Each net with k components contributes k-1 independent basis edges. No topology bottleneck inferred solely from open status.'})
    print('ownership',len(ownership),'basis',len(basis),collections.Counter(x['source_owner'] for x in basis),flush=True)
    native_gnd={x['ref']+'.'+x['pad']:x for part in conn['nets']['GND']['components'] if len(part)==1 for x in part if x['kind']=='PAD'}
    for pin,row in native_gnd.items():
        row['exact_pin_source_banks']=[s for s in ROUTE['prep']['seed_stubs']['stubs'] if s.get('pin')==pin];row['matching_ground_banks']=[s.get('pin') for s in ROUTE['prep']['seed_stubs']['stubs'] if s['net']=='GND']
    dump('fourteen-ground-components.json',native_gnd)

def regression():
    rc=run('coupon-pland-original',['/usr/bin/python3','-B',str(ROOT/'skills/kicad-pcb/scripts/escape_check.py'),'--board',str(OUT/'coupon'/f'{STEM}.kicad_pcb'),'--verbose'],90)
    text=(OUT/'coupon-pland-original.stdout.log').read_text();failures=[x for x in text.splitlines() if x.startswith('FAIL P-LAND')];refuted=[x for x in text.splitlines() if x.startswith('MODEL-REFUTED')]
    coupon=json.loads((OUT/'coupon-context-drc.json').read_text());control=json.loads((OUT/'control-context-drc.json').read_text());blocking=[x for x in coupon['violations'] if x['type'] in ['clearance','track_width','shorting_items']];bad=[x for x in control['violations'] if x['type']=='clearance']
    results={'original_method_sha':sha(ROOT/'skills/kicad-pcb/scripts/escape_check.py'),'original_rc':rc,'native_coupon_width_clearance_short_findings':blocking,'native_coupon_overall_rejected':True,'native_coupon_other_findings':coupon['violations'],'original_failing_rows':failures,'original_model_disagreements':refuted,'known_bad_native_clearance_rows':bad,'proposed_regression':'For each of these 14 native width/clearance-legal launch coupons, require its static resolved launch to accept the declared local width; separately require whole-board DRC rejection on the two starved thermals and known-bad rejection on 3 clearance rows. Never convert the whole coupon into a routed-board PASS.','original_regression_result':'RED' if failures and not blocking and len(bad)==3 else 'INCOMPLETE'}
    dump('private-regression-result.json',results)
    print('private regression',results['original_regression_result'],'original_fails',len(failures),'model_disagreements',len(refuted),'native_control_clearance',len(bad),flush=True)

if __name__=='__main__':coverage();regression()
