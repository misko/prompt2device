from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,subprocess,tarfile
r=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');p=r/'projects/crow-audio-carrier-v1';e=p/'01_docs/evidence/pland-backtrack-20260910';d=Path(__file__).parent
private=Path('/tmp/pland-native-owned-output-20260910T215831Z');packet=p/'06_build/handoffs/pland-native-owned-output-20260910T215831Z';run=private/'native-interface-run-jp3a0oer'
sha=lambda b:hashlib.sha256(b).hexdigest()
env=json.loads((packet/'task-envelope.json').read_text());changes=[]
for x in env['input_packet']:
 q=r/x['path'];b=q.read_bytes();assert q.is_file() and not q.is_symlink()
 if sha(b)!=x['sha256'] or len(b)!=x['size']:changes.append(x['path'])
assert not changes
source=json.loads((e/'native-interface-owned-output-manifest.json').read_text())
for x in source['entries']:
 q=private/'producer'/x['member'];b=q.read_bytes();assert sha(b)==x['sha256'] and len(b)==x['size']
out=json.loads((private/'output-manifest.json').read_text());assert out['count']==len(out['entries'])==34
for x in out['entries']:
 q=private/x['path'];b=q.read_bytes();assert not q.is_symlink() and sha(b)==x['sha256'] and len(b)==x['size'],x['path']
actual={q.relative_to(private).as_posix() for q in private.rglob('*') if q.is_file()}
assert actual-{x['path'] for x in out['entries']}=={'output-manifest.json'}
proc=json.loads((private/'process-audit.json').read_text());pids=[proc['outer_pid']]+[x['pid'] for x in proc['children']];assert all(not Path('/proc',str(pid)).exists() for pid in pids)
logs=(run/'002_census.log').read_text().splitlines();census=next(json.loads(line)['complete_census'] for line in logs if line.startswith('{"complete_census"'));assert len(census)==4
summary=[dict(board=x['board'],copper_pads=x['copper_pads'],graded=x['graded'],floorless=x['floorless'],tracks=x['tracks'],classes={z['pad']:z['class'] for z in x['native_pads']},native_records=len(x['native_pads'])) for x in census]
audit=dict(time=datetime.now(timezone.utc).isoformat(),input_count=len(env['input_packet']),changes=changes,verified_output_rows=34,report_sha256=sha((private/'result.md').read_bytes()),manifest_sha256=sha((private/'output-manifest.json').read_bytes()),producer_verified=3,all_pids_absent=pids,complete_native_census=summary,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip())
(d/'owned-output-root-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
sources=[(q,'worker/'+q.relative_to(private).as_posix()) for q in private.rglob('*') if q.is_file()]+[(q,'commission/'+q.relative_to(packet).as_posix()) for q in packet.rglob('*') if q.is_file()]+[(d/'owned-output-root-audit.json','coordinator/root-audit.json'),(Path(__file__),'coordinator/preserve.py')]
rows=[];temp=d/'owned-output-attempt.tar.gz'
with tarfile.open(temp,'w:gz') as tf:
 for q,name in sorted(sources,key=lambda x:x[1]):
  assert not q.is_symlink();b=q.read_bytes();tf.add(q,arcname=name,recursive=False);rows.append(dict(member=name,original_path=str(q),sha256=sha(b),size=len(b)))
digest=sha(temp.read_bytes())
with tarfile.open(temp) as tf:
 members=tf.getmembers();assert len(members)==len(rows)==len({m.name for m in members})
 for m,x in zip(members,rows):assert m.isfile() and m.name==x['member'] and m.size==x['size'] and sha(tf.extractfile(m).read())==x['sha256']
target=e/(digest+'.tar.gz');assert not target.exists();shutil.copy2(temp,target)
shutil.copy2(private/'result.md',e/'native-owned-output-worker-result.md')
(e/'native-owned-output-attempt-manifest.json').write_text(json.dumps(dict(schema=1,created_at=audit['time'],source_commit=audit['head'],tar_sha256=digest,tar_size=target.stat().st_size,count=len(rows),entries=rows),indent=2)+'\n')
c=e/'contracts.md';t=c.read_text();anchor='| `contracts.md` | this exact dated contract | no wildcard evidence namespace |';assert t.count(anchor)==1
c.write_text(t.replace(anchor,'\n'.join([f'| `{digest}.tar.gz` | exact owned-output attempt including complete native scalar census | all members reopen against native-owned-output-attempt-manifest.json |','| `native-owned-output-attempt-manifest.json` | complete original-path, SHA256 and size map | retains compound-class zero-floor census; no public or DRC execution inferred |','| `native-owned-output-worker-result.md` | verbatim failed mechanical admission report | coordinator separately corrects the false claim that hostile census did not run |','| `native-owned-output-adoption.md` | native-interface acceptance scope and fixture class-schema diagnosis | preserves all limits and separate production obligations |',anchor])))
print(json.dumps(dict(audit=audit,archive_sha256=digest,members=len(rows),size=target.stat().st_size),indent=2))
