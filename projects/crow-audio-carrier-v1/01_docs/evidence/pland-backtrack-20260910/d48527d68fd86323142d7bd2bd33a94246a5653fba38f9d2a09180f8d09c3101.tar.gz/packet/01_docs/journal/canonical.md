# Canonical execution journal

## 2026-09-11T03:59:43.272887+00:00 — start: retire archived stale checkpoints

- did: root reopened each old checkpoint/request/blank response against committed archive fbd7ea95714e2ab36034a95cc34ee9fdbcea9b4124896b02296725acb00d7a0f.tar.gz, then removed only the five exact existing copies. Allocation receipt remains absent; generated source stays for canonical replacement.
- result: MEASURED five exact preimages verified; checker accepted at 5de08b98, fresh tool qualification 4/4. Full conductor not yet run. Git whitespace check flagged only context-marker lines in the verbatim forensic patch; source whitespace has no reported defect. Exact forensic bytes are preserved.
- next: mandatory fresh mechanical full conductor, stop at first gate. No routing or release acceptance.

```json
[
  {
    "path": "06_build/checkpoints/prelayout-inputs.json",
    "size": 90431,
    "sha256": "28581244e7cca1837bd9aee131c428892c4f819fb02a57627e35cf52df6d133d"
  },
  {
    "path": "06_build/checkpoints/prelayout.json",
    "size": 1798,
    "sha256": "5c1ec6b2198d53ff321b90bcab39f8140337a9319ace10025c65916f78769069"
  },
  {
    "path": "06_build/checkpoints/schematic.json",
    "size": 1169,
    "sha256": "f5327aaa478d864250983e5dd1c9b4d2bd5478b2d12ac51db36079e6d84f7dc1"
  },
  {
    "path": "06_build/sourcing/prelayout_request.json",
    "size": 14246,
    "sha256": "b201db0e4ea1f7384c061816f67d5b549ad010a5af31246c1d0c0bef7bd1c101"
  },
  {
    "path": "06_build/sourcing/prelayout_response.csv",
    "size": 1647,
    "sha256": "2f7426cf5d959bd3fb9e4e0c944c03d7be3371ac2e64235fe36768ba8aa33d32"
  }
]
```
