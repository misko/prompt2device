# Canonical restart report

Inputs verified: PASS (13/13 packet hashes).
Execution recorded: PASS; processes closed: PASS.

First gate: `J-PCBA-PRELAYOUT` (expected external provider checklist). Actual return code: `2` (`INCOMPLETE`; not a board PASS). Runtime: 78.936 seconds. Gate counts: PRELAYOUT-INPUT 561/561; CHECKPOINT 11/11; JLC-PCBA REQUEST 51/51.

Outputs: `conductor.log`, `process.json`, `changes.json`, `report.md`, `result.json`.
