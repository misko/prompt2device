"""Read only exercised scalar/native polygon fields; flush each required row."""
from pathlib import Path
import json, sys
import pcbnew
repo = Path(sys.argv[1])
sys.path.insert(0, str(repo/'skills/kicad-pcb/scripts'))
import escape_check as old
all_rows = []
for raw in sys.argv[2:]:
    path = Path(raw)
    b = pcbnew.LoadBoard(str(path))
    rows = []
    for fp in b.GetFootprints():
        for pad in fp.Pads():
            layers = list(pad.GetLayerSet().CuStack())
            pos = pad.GetPosition()
            row = {'board': str(path), 'ref': fp.GetReference(),
                   'pad': pad.GetNumber(), 'net': pad.GetNetname(),
                   'class': pad.GetNetClassName(), 'layers': layers,
                   'center': [pos.x/1e6, pos.y/1e6], 'polygons': {}}
            for layer in layers:
                ps = pad.GetEffectivePolygon(layer)
                row['polygons'][str(layer)] = [
                    [[o.CPoint(i).x/1e6, o.CPoint(i).y/1e6]
                     for i in range(o.PointCount())]
                    for o in [ps.Outline(j) for j in range(ps.OutlineCount())]]
            print(json.dumps({'native_pad': row}), flush=True)
            rows.append(row)
    # This is explicitly the old declared-floor parser, not a native DRC oracle.
    pads, unreadable, areas, pours, vias, tracks = old.read_board(path)
    rules = old.read_dru_rules(path.with_suffix('.kicad_dru'))
    floor_rows = []
    for p in pads:
        floor, rule = old.resolve_min(rules, 'track_width', p, areas)
        floor_rows.append({'ref': p['ref'], 'pad': p['num'], 'net': p['net'],
                           'class': p['cls'], 'old_declared_floor': floor, 'rule': rule})
    result = {'board': str(path), 'native_pads': rows, 'floor_rows': floor_rows,
              'copper_pads': len(pads)+len(unreadable), 'unreadable': unreadable,
              'graded': sum(x['old_declared_floor'] is not None for x in floor_rows),
              'floorless': sum(x['old_declared_floor'] is None for x in floor_rows),
              'tracks': len(tracks), 'vias': len(vias), 'pours': len(pours)}
    print(json.dumps({'board_census': result}), flush=True)
    all_rows.append(result)
print(json.dumps({'complete_census': all_rows}), flush=True)
