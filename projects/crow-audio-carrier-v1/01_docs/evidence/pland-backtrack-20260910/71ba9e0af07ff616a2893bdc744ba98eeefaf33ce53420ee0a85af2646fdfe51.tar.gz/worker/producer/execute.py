"""One frozen native-interface admission run. No repair/retry branches."""
from pathlib import Path
from datetime import datetime, timezone
import collections, hashlib, json, os, re, signal, subprocess, sys, time
SOURCE = Path(__file__).parent
REPO = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
OUT.mkdir(parents=True, exist_ok=False)
CHECKER = REPO/'skills/kicad-pcb/scripts/escape_check.py'
EXPECTED_SHA = 'cb0d0cf6cb593b5f231fa372920e7dc6adf10bce95c0d734fac0900d3fd3ddf3'
def sha(q):
    return hashlib.sha256(q.read_bytes()).hexdigest()
def run(argv, stem, expected_rc):
    assert sha(CHECKER) == EXPECTED_SHA
    meta = {'argv': [str(x) for x in argv], 'cwd': str(REPO),
            'start': datetime.now(timezone.utc).isoformat(), 'timeout_seconds': 60,
            'checker_sha256_before': sha(CHECKER)}
    (OUT/(stem+'.start.json')).write_text(json.dumps(meta, indent=2)+'\n')
    began = time.monotonic()
    with (OUT/(stem+'.log')).open('wb') as stream:
        proc = subprocess.Popen(meta['argv'], cwd=REPO, stdout=stream,
                                stderr=subprocess.STDOUT, start_new_session=True)
        timeout = False
        try:
            rc = proc.wait(timeout=60)
        except subprocess.TimeoutExpired:
            timeout = True
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                rc = proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                rc = proc.wait()
    meta.update(rc=rc, timed_out=timeout, pid=proc.pid, process_reaped=True,
                duration_seconds=time.monotonic()-began,
                end=datetime.now(timezone.utc).isoformat(),
                checker_sha256_after=sha(CHECKER))
    (OUT/(stem+'.result.json')).write_text(json.dumps(meta, indent=2)+'\n')
    print(json.dumps(meta), flush=True)
    assert not timeout and rc == expected_rc, meta
    assert sha(CHECKER) == EXPECTED_SHA
    return (OUT/(stem+'.log')).read_text()
def main():
    run(['/usr/bin/python3', SOURCE/'fixture.py', OUT/'specimens'], '001_build', 0)
    boards = [OUT/'specimens'/label/(kind+'.kicad_pcb')
              for label in ['base', 'hostile'] for kind in ['public', 'oracle']]
    log = run(['/usr/bin/python3', SOURCE/'census.py', REPO, *boards], '002_census', 0)
    data = next(json.loads(line)['complete_census'] for line in log.splitlines()
                if line.startswith('{"complete_census"'))
    assert len(data) == 4
    for rec in data:
        assert (rec['copper_pads'], rec['graded'], rec['floorless']) == (5, 2, 3), rec
        assert not rec['unreadable'] and not rec['vias'] and not rec['pours'], rec
        assert rec['tracks'] == (1 if Path(rec['board']).stem == 'oracle' else 0), rec
        pads = {row['pad']: row for row in rec['native_pads']}
        assert len(pads) == 5 and all(p['layers'] == [0] for p in pads.values()), rec
        hostile = Path(rec['board']).parent.name == 'hostile'
        expected = {'1': ('TARGET', 'ADC'), '2': ('TARGET', 'ADC'),
                    '3': ('LEFT', 'High' if hostile else 'Low'),
                    '4': ('RIGHT', 'High' if hostile else 'Low'), '5': ('REMOTE', 'High')}
        assert {k: (v['net'], v['class']) for k, v in pads.items()} == expected, rec
        assert all(row['old_declared_floor'] == .2 for row in rec['floor_rows']
                   if row['pad'] in ('1', '2')), rec
    public = {}
    native = {}
    for i, label in enumerate(['base', 'hostile']):
        folder = OUT/'specimens'/label
        text = run(['/usr/bin/python3', CHECKER, '--board', folder/'public.kicad_pcb', '--verbose'],
                   f'00{3+i}_public_{label}', 1)
        assert '2 graded / 5 copper pads (3 no declared width floor' in text, text
        match = re.search(r'FAIL P-LAND public X1\.1 net=TARGET class=ADC floor=0\.200 .*?landable=([0-9.]+) @ clearance 0\.250', text)
        assert match and abs(float(match[1])-.12) < .002, text
        public[label] = {'named_central_failure': match[0], 'native_census': [5,2,3]}
    for i, label in enumerate(['base', 'hostile']):
        folder = OUT/'specimens'/label
        drc = folder/'drc.json'
        run(['kicad-cli', 'pcb', 'drc', '--severity-all', '--format', 'json',
             '--output', drc, '--exit-code-violations', folder/'oracle.kicad_pcb'],
            f'00{5+i}_native_{label}', 0 if label == 'base' else 5)
        report = json.loads(drc.read_text())
        categories = collections.Counter(x['type'] for x in report['violations'])
        native[label] = {'categories': dict(categories),
                         'unconnected': report['unconnected_items'],
                         'violations': report['violations'],
                         'parity': 'not invoked; no schematic specimen'}
        assert not report['unconnected_items'], native[label]
        assert categories == ({} if label == 'base' else {'clearance': 2}), native[label]
        if label == 'hostile':
            assert all(any('Track' in item['description'] for item in v['items'])
                       for v in report['violations']), native[label]
    result = {'status': 'NATIVE_INTERFACE_AND_DIAGNOSTIC_FIXTURE_ADMITTED',
              'scope': 'No maintained regression or production checker acceptance.',
              'public': public, 'native': native, 'checker_sha256': sha(CHECKER)}
    (OUT/'admission.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'ADMISSION': result}), flush=True)
if __name__ == '__main__':
    main()
