from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,subprocess,tarfile
r=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');p=r/'projects/crow-audio-carrier-v1';e=p/'01_docs/evidence/pland-backtrack-20260910';d=Path(__file__).parent
private=Path('/tmp/pland-native-interface-20260910T215034Z');packet=p/'06_build/handoffs/pland-native-interface-20260910T215034Z'
sha=lambda b:hashlib.sha256(b).hexdigest()
env=json.loads((packet/'task-envelope.json').read_text());changes=[]
for x in env['input_packet']:
 q=r/x['path'];b=q.read_bytes();assert q.is_file() and not q.is_symlink()
 if sha(b)!=x['sha256'] or len(b)!=x['size']:changes.append(x['path'])
assert not changes,changes
source=json.loads((e/'native-interface-producer-manifest.json').read_text())
for x in source['entries']:
 q=private/'producer'/x['member'];b=q.read_bytes();assert sha(b)==x['sha256'] and len(b)==x['size']
declared=json.loads((private/'output-manifest.json').read_text())['files'];bad=[]
for x in declared:
 q=private/x['path'];b=q.read_bytes()
 if sha(b)!=x['sha256'] or len(b)!=x['size']:bad.append(x['path'])
actual={q.relative_to(private).as_posix() for q in private.rglob('*') if q.is_file()}
not_listed=sorted(actual-{x['path'] for x in declared})
pid=json.loads((private/'command.json').read_text())['pid'];assert not Path('/proc',str(pid)).exists()
audit=dict(time=datetime.now(timezone.utc).isoformat(),inputs=len(env['input_packet']),changes=changes,producer_verified=3,report_sha256=sha((private/'result.md').read_bytes()),declared_output_manifest_mismatches=bad,actual_files_not_in_worker_manifest=not_listed,process_absent=pid,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip())
(d/'interface-failure-root-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
sources=[(q,'worker/'+q.relative_to(private).as_posix()) for q in private.rglob('*') if q.is_file()]
sources += [(q,'commission/'+q.relative_to(packet).as_posix()) for q in packet.rglob('*') if q.is_file()]
sources += [(d/'interface-failure-root-audit.json','coordinator/interface-failure-root-audit.json'),(Path(__file__),'coordinator/preserve_interface_failure.py')]
rows=[];temp=d/'interface-launch-failure.tar.gz'
with tarfile.open(temp,'w:gz') as tf:
 for q,name in sorted(sources,key=lambda x:x[1]):
  assert not q.is_symlink();b=q.read_bytes();tf.add(q,arcname=name,recursive=False);rows.append(dict(member=name,original_path=str(q),sha256=sha(b),size=len(b)))
digest=sha(temp.read_bytes())
with tarfile.open(temp) as tf:
 members=tf.getmembers();assert len(members)==len(rows)==len({m.name for m in members})
 for m,x in zip(members,rows):assert m.isfile() and m.name==x['member'] and m.size==x['size'] and sha(tf.extractfile(m).read())==x['sha256']
target=e/(digest+'.tar.gz');assert not target.exists();shutil.copy2(temp,target)
shutil.copy2(private/'result.md',e/'native-interface-worker-result.md')
(e/'native-interface-attempt-manifest.json').write_text(json.dumps(dict(schema=1,created_at=audit['time'],source_commit=audit['head'],tar_sha256=digest,tar_size=target.stat().st_size,count=len(rows),entries=rows),indent=2)+'\n')
c=e/'contracts.md';t=c.read_text();anchor='| `contracts.md` | this exact dated contract | no wildcard evidence namespace |';assert t.count(anchor)==1
c.write_text(t.replace(anchor,'\n'.join([f'| `{digest}.tar.gz` | complete failed native-interface launch and administrative corrections | all regular members rehashed against native-interface-attempt-manifest.json |','| `native-interface-attempt-manifest.json` | exact launch-failure archive membership | preserves original/corrected reports and manifest defects |','| `native-interface-worker-result.md` | verbatim corrected mechanical handback | no producer child ran; not a native or checker failure |','| `native-interface-adoption.md` | root executor-precondition diagnosis and next source decision | original one-attempt commission closed; no deletion of failed state |',anchor])))
print(json.dumps(dict(audit=audit,archive_sha256=digest,members=len(rows),size=target.stat().st_size),indent=2))
