# Fresh mechanical native-interface admission

agent-role: mechanical
context_mode: FRESH
source_commit: 07c381bdb367822922f613d0d2e1b7059a85b359
repository: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901
private_output_root: /tmp/pland-native-interface-20260910T215034Z
live tree: READ_ONLY; root retains exclusive live ownership

Verify exact task-envelope SHA, all input members and aggregate identities before
work. Read CLAUDE.md, copied flow/beacon/journal tail, pcb-design lifecycle and
compute references, and01_docs/evidence/pland-backtrack-20260910/native-interface-plan.md.
That plan is the adopted upstream interface dependency. Prior author/diagnosis
caps remain exhausted; this is not another API repair or replacement author.

Execute exactly one frozen producer command. Rehash
01_docs/evidence/pland-backtrack-20260910/06cf4fbec59d3357a39319af0d62b7a0635e8915e5dde27184b0601660b2aaa2.tar.gz
and all3 members against native-interface-producer-manifest.json. Safely extract
exactly the three regular files to/tmp/pland-native-interface-20260910T215034Z/producer, rejecting links, traversal,
duplicates, missing/extra files or SHA/size differences. Never edit these scripts.

Exact command:
/usr/bin/python3 /tmp/pland-native-interface-20260910T215034Z/producer/execute.py /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901 /tmp/pland-native-interface-20260910T215034Z/run

Overall420second process-group timeout; all children have60second timeouts.
Task hard deadline is now+10minutes as exact envelope; final60seconds reserved
for complete report/closure. One execution, no repairs, retries, alternative APIs,
extra fixtures, native scans or replacements. If ANY step fails, preserve all
outputs, stop and hand back. You may write an administrative timeout/log wrapper
but cannot change producer/fixture semantics or assertions. Write actual command
argv/start/PID/full stdout/stderr/rc/duration to files before/after execution.
The producer separately captures its6child commands. Keep administrative and
producer outcomes distinct. No invented pcb_flow logs or source acceptance.

The producer's native/basic census must have5copper/2declared-floor/3floorless,
exact scalar class names and F.Cu layer. The unchanged public checker must fail
named X1.1 geometrically at that nonzero denominator. Independent native DRC
must show0physical/0opens on base and exactly2track-clearance findings/0opens
on hostile; preserve ALL categories. No schematic exists, parity not invoked.
Read complete actual logs/admission.json if produced. A rc0 wrapper is not proof
of the underlying result. No maintained regression or production repair is
installed by this task even if diagnostic admission succeeds.

Report verified launch promptly and meaningful progress<=60seconds apart. Deliver
actual complete report to/tmp/pland-native-interface-20260910T215034Z/result.md with every command outcome, exact
source/fixture/result hashes and all unresolved rows. Final640+member exactpacket
audit and output SHA/size manifest are required (count this new envelope, not the
prior640). Verify original checker/test/native source unchanged, all extracted
producer files still exact and every child terminated/reaped. End all processes
and writes before handback. Do not write any live project file, commit, regenerate
board/source, change checkpoints/models/rules, launch reviews/routing or releases.
Root owns durable preservation, adoption and next separate source boundary.

Aggregate formula:
pipeline_identity.subject_identity('crow_pland_native_interface',1,
[TypedIdentityInput('packet','sequence',input_packet,json.dumps(input_packet,sort_keys=True).encode())]).
