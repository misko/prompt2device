import pathlib,json,hashlib,datetime
R=pathlib.Path(__file__).parent.parent;S=R/'scratch';O=R/'outputs';B=R.parents[2];P=B/'06_build/tmp/native-semantics-reassessment-20260911T021651Z'
def sha(b):return hashlib.sha256(b).hexdigest()
envelope=json.loads((R/'envelope.json').read_text());assert sha(json.dumps(envelope,sort_keys=True,separators=(',',':')).encode())=='40734d6cb88d264ab625d8df64639244d1e493d5899925f22d632b14068cc793'
inputs=[]
for row in envelope['input_packet']:
 p=B/row['path'];d=p.read_bytes();assert len(d)==row['size'] and sha(d)==row['sha256'];inputs.append(row)
archives=[]
for label,m in [('evaluator','evaluator-manifest.json'),('kernel','native-kernel-attempt-manifest.json'),('interrupted','kernel-contract-interruption-manifest.json')]:
 j=json.loads((P/m).read_text());entries=[]
 for r in j['entries']:
  p=S/label/r['member'];d=p.read_bytes();assert len(d)==r['size'] and sha(d)==r['sha256'],p;entries.append({k:r[k] for k in ['member','size','sha256']})
 archives.append({'label':label,'archive_sha256':j['tar_sha256'],'manifest_path':str(P/m),'manifest_sha256':sha((P/m).read_bytes()),'verified_regular_members':len(entries),'all_regular_members_verified_before_safe_extraction':True,'all_regular_members_reverified_at_delivery':True,'members':entries})
newfiles=[]
for p in S.iterdir():
 if p.is_file() and p.name!='finalize_evidence.py':newfiles.append(p)
for name in ['focused','public-red','public-red-v2','public-red-v3']:
 newfiles.extend(p for p in (S/name).rglob('*') if p.is_file())
inline=[];processes=[]
for p in sorted(set(newfiles)):
 d=p.read_bytes();inline.append({'path':str(p.relative_to(S)),'sha256':sha(d),'size':len(d),'text':d.decode('utf-8')})
 if p.name.endswith('process.json'):
  r=json.loads(d);pid=r.get('pid');exists=bool(pid and pathlib.Path('/proc',str(pid)).exists());processes.append({'receipt':str(p.relative_to(S)),'pid':pid,'present_at_delivery':exists});assert not exists,pid
native=[]
ir=S/'interrupted/reviewer'
for category in ['native-controls','semantics-controls']:
 for d in sorted((ir/category).iterdir()):
  if not d.is_dir() or not (d/'drc.json').exists():continue
  j=json.loads((d/'drc.json').read_text());native.append({'archive':'interrupted','member_directory':str(d.relative_to(S/'interrupted')),'violations':len(j['violations']),'opens':len(j['unconnected_items']),'violations_detail':j['violations'],'process':json.loads((d/'process.json').read_text()) if (d/'process.json').exists() else None})
primary='persistent-fixtures/land_complete_lb1ru2xz/worker/native-interface-run-u2jowhbt/specimens'
for label in ['base','hostile']:
 d=S/'kernel'/primary/label;j=json.loads((d/'fresh-drc.json').read_text());native.append({'archive':'kernel','member_directory':str(d.relative_to(S/'kernel')),'violations':len(j['violations']),'opens':len(j['unconnected_items']),'violations_detail':j['violations'],'metadata_limit':'fresh-drc.result.json records argv/rc but lacks child PID/timing; no metadata reconstructed'})
sourcefiles=[p for p in (ir/'authority').glob('*') if p.suffix in ['.cpp','.h','.lemon']]
sourcefiles += [ir/'extracted/fixture/coordinator'/f for f in ['drc_engine-10.0.4.cpp','pad-10.0.4.cpp','drc_test_provider_track_width-10.0.4.cpp']]
sourcefiles += [S/'kernel/coordinator/footprint-10.0.4.cpp']
sources=[]
for p in sourcefiles:
 label=p.relative_to(S).parts[0];member=str(p.relative_to(S/label));sources.append({'archive':label,'member':member,'sha256':sha(p.read_bytes()),'size':p.stat().st_size})
observations=[
 {'id':'canonical-input-integrity','finding':'Canonical envelope SHA and24 packet files match; three archives161+1266+2058 regular members verified before extraction and after all work.'},
 {'id':'native-string-precedence','finding':'Archived uppercase condition produces one width finding; bracket literal and mixed AND/OR conditions produce none. Exact compiler case-insensitive string behavior and Lemon OR-above-AND agree; rejected Python kernel disagrees.'},
 {'id':'native-area-epsilon','finding':'Archived touch and1IU area overlap do not match;2um matches with500IU epsilon. Prior relaxation script failed SyntaxError before native launch. Fresh area_relax_1iu gives one highbase0.4/actual0.2 width finding,0opens.'},
 {'id':'native-local-optionals','finding':'Ten archived controls reopened individually; absent and explicit zero differ. PAD0 masks FP, then falls through. Nonzero override is board-clamped before custom; explicit custom can relax below board.'},
 {'id':'width-below-board','finding':'Fresh actual0.075 explicitmin0.05:0violations/0opens; explicitmin0.1:1target width/0opens. Complete raw triples/results/receipts/logs included inline.'},
 {'id':'primary-public-false-rejection','finding':'Archived exact complete-class native base0violations/0opens and hostile2clearance/0opens reopened. Fresh original CLI base rc1 falsely reports X1.1 floor0.2 landable0.12 clearance0.25,2graded/5copper+3floorless; actual same-net track inventory2. Maintained behavioral RED/GREEN remains owed.'},
 {'id':'additional-public-false-pass','finding':'Fresh original CLI ring base and hostile both rc0,5graded0failed, source landable0.298 atclearance0.05; hostile rule merely unparsed. Native hostile48 distinct center track UUIDs each have clearance finding. Base has2unrelated violations/3opens; hostile241total violations/3opens including shorting/outline/dangling. No clean or full-start-search claim.'},
 {'id':'diagnostic-setup-failures','finding':'Two preserved public fixture child launches fail LSET constructor before native execution; third uses exact archived AddLayer construction. All are retained, no failed launch called engineering PASS.'},
 {'id':'corpus-demand','finding':'Verified archived native census and actual rule triples: current1002/940,CAL324/300,RX2291/272,CRC786/755 physical/copper. Native census script used rejected parser only for ancillary old_parse_count; shape/class/local counts are direct pcbnew. Actual rules reopened independently; CRC diff_pair_gap min/opt is validated downstream scope, not silently omitted.'},
 {'id':'bounded-search-contract','finding':'Policy-owned48directions,1mmreach,2mmwidthcap,finite declared-minimum widths and exact<=37proposal generator; no unsafe cmax pruning.30um is nominal generator scale, not guaranteed realized spacing under5-interval cap; documented policy ambiguity. Explicit supported/unsupported boundaries and seven-group regressions in judgment.'}
]
e={'schema':1,'verdict':'GO_BOUNDED_IMPLEMENTATION_CONTRACT_EXISTING_KERNEL_REJECTED','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'subject':envelope['subject'],'envelope':{'path':str(R/'envelope.json'),'canonical_sha256':sha(json.dumps(envelope,sort_keys=True,separators=(',',':')).encode()),'raw_sha256':sha((R/'envelope.json').read_bytes())},'verified_inputs':inputs,'archives':archives,'used_native_source_bindings':sources,'additional_source':json.loads((S/'additional-source.json').read_text()),'observations':observations,'archived_native_results_reopened':native,'fresh_focused_observations':json.loads((S/'focused/observations.json').read_text()),'fresh_public_diagnostic_observations':json.loads((S/'public-red-v3/observations.json').read_text()),'new_scripts_results_receipts_and_full_logs_inline':inline,'new_process_closure':processes,'process_limitations':'No new background work remains. Tool-invoked metadata-only Python readers/writers completed synchronously. Archived missing metadata is not recreated. Runtime status PASS means process rc0, not engineering acceptance; expected native rc5 remains runtime FAIL. No children agents spawned.','judgment_sha256':sha((O/'judgment.md').read_bytes()),'maintained_green_executed':False,'production_source_changed':False}
(O/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
(O/'result.json').write_text(json.dumps({'subject':envelope['subject'],'checks':{'inputs-verified':'PASS','judgment-complete':'PASS','processes-closed':'PASS'},'unresolved':[]},indent=2)+'\n')
print(json.dumps({'outputs':[{ 'name':p.name,'sha256':sha(p.read_bytes()),'size':p.stat().st_size} for p in sorted(O.iterdir())],'new_runtime_processes_closed':len(processes)}))
