import sys
sys.dont_write_bytecode=True
import pathlib,os,json
s=pathlib.Path(__file__).parent;p=s.parents[2]/'tmp/native-semantics-reassessment-20260911T021651Z'
sys.path.insert(0,str(p/'source/skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
argv=['/usr/bin/python3',str(s/'focused_controls.py')]
env={'PATH':os.environ['PATH'],'HOME':os.environ['HOME'],'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'}
r=run_stage({'id':'focused-controls','work_class':'local','timeout_s':110},argv,log_path=s/'focused-full.log',cwd=s,env=env).to_mapping();r.update(argv=argv,cwd=str(s));(s/'focused-process.json').write_text(json.dumps(r,indent=2))
