import sys
sys.dont_write_bytecode=True
import os,json,pathlib,hashlib
S=pathlib.Path(__file__).parent
P=S.parents[2]/'tmp/native-semantics-reassessment-20260911T021651Z'
sys.path.insert(0,str(P/'source/skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
import pcbnew
root=S/'interrupted/reviewer';base=S/'evaluator/reviewer/base/matrix.kicad_pcb'
out=S/'focused';out.mkdir()
env={'PATH':os.environ['PATH'],'HOME':os.environ['HOME'],'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'}
rows=[]
for name,src,width,rules in [
 ('width_below_board_allowed',base,.075,"(rule low (condition \"A.NetName == 'remote_high_T'\") (constraint track_width (min 0.05mm)))"),
 ('width_below_board_rejected',base,.075,"(rule low (condition \"A.NetName == 'remote_high_T'\") (constraint track_width (min 0.1mm)))"),
 ('area_relax_1iu',root/'semantics-controls/area_overlap_1iu/matrix.kicad_pcb',.2,"(rule highbase (condition \"A.NetName == 'remote_high_T'\") (constraint track_width (min 0.4mm)))\n(rule low (condition \"A.NetName == 'remote_high_T' && A.insideArea('CONTRACT_TOUCH')\") (constraint track_width (min 0.2mm)))")]:
 d=out/name;d.mkdir();bp=d/'matrix.kicad_pcb';b=pcbnew.LoadBoard(str(src))
 targets=[t for t in b.GetTracks() if t.GetNetname()=='remote_high_T'];assert len(targets)==1
 targets[0].SetWidth(round(width*1e6));target=targets[0].m_Uuid.AsString();pcbnew.SaveBoard(str(bp),b)
 bp.with_suffix('.kicad_pro').write_bytes(base.with_suffix('.kicad_pro').read_bytes())
 bp.with_suffix('.kicad_dru').write_text(base.with_suffix('.kicad_dru').read_text()+'\n'+rules+'\n')
 argv=['kicad-cli','pcb','drc','--severity-all','--all-track-errors','--exit-code-violations','--format','json','-o',str(d/'drc.json'),str(bp)]
 result=run_stage({'id':name,'work_class':'local','timeout_s':35},argv,log_path=d/'full.log',cwd=S,env=env,console=None).to_mapping()
 result.update(argv=argv,cwd=str(S));(d/'process.json').write_text(json.dumps(result,indent=2))
 report=json.loads((d/'drc.json').read_text());vs=[v for v in report['violations'] if any(x['uuid']==target for x in v['items'])]
 rows.append({'name':name,'target_uuid':target,'target_violations':vs,'all_violations':len(report['violations']),'opens':len(report['unconnected_items']),'native_schema':report.get('$schema'),'source':str(src),'result':result})
 print(json.dumps(rows[-1]),flush=True)
assert not rows[0]['target_violations']
assert len(rows[1]['target_violations'])==1 and rows[1]['target_violations'][0]['type']=='track_width'
assert len(rows[2]['target_violations'])==1 and rows[2]['target_violations'][0]['type']=='track_width'
(out/'observations.json').write_text(json.dumps(rows,indent=2))
