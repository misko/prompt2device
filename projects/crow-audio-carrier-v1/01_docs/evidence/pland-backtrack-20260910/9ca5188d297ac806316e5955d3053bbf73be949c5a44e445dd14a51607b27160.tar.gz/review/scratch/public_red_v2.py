import sys
sys.dont_write_bytecode=True
import os,json,pathlib,math
S=pathlib.Path(__file__).parent;P=S.parents[2]/'tmp/native-semantics-reassessment-20260911T021651Z'
sys.path.insert(0,str(P/'source/skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
import pcbnew
out=S/'public-red-v2';out.mkdir();env={'PATH':os.environ['PATH'],'HOME':os.environ['HOME'],'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'}
pro=json.loads((S/'evaluator/reviewer/base/matrix.kicad_pro').read_text());pro['net_settings']['classes']=[x for x in pro['net_settings']['classes'] if x['name']=='Default'];pro['net_settings']['classes'][0]['clearance']=.05;pro['net_settings']['netclass_assignments']={};pro['net_settings']['netclass_patterns']=[];pro['board']['design_settings']['rules']['min_clearance']=.05
rows=[]
for name,hostile,native in [('public_base',False,False),('public_hostile',True,False),('native_base',False,True),('native_hostile_48',True,True)]:
 d=out/name;d.mkdir();bp=d/'red.kicad_pcb';b=pcbnew.BOARD();b.SetCopperLayerCount(2)
 nets={}
 for n in ['TARGET','OBST']:
  net=pcbnew.NETINFO_ITEM(b,n);b.Add(net);nets[n]=net
 fp=pcbnew.FOOTPRINT(b);fp.SetReference('X1');b.Add(fp)
 for i,(x,y) in enumerate([(10,10),(10.42,10),(9.58,10),(10,10.42),(10,9.58)],1):
  p=pcbnew.PAD(fp);p.SetNumber(str(i));p.SetAttribute(pcbnew.PAD_ATTRIB_SMD);p.SetShape(pcbnew.PAD_SHAPE_CIRCLE);p.SetSize(pcbnew.VECTOR2I(200000,200000));p.SetPosition(pcbnew.VECTOR2I(round(x*1e6),round(y*1e6)));p.SetLayerSet(pcbnew.LSET([pcbnew.F_Cu]));p.SetNet(nets['TARGET' if i==1 else 'OBST']);fp.Add(p)
 if native:
  for k in (range(48) if hostile else [6]):
   a=2*math.pi*k/48;t=pcbnew.PCB_TRACK(b);t.SetStart(pcbnew.VECTOR2I(10000000,10000000));t.SetEnd(pcbnew.VECTOR2I(round((10+math.cos(a))*1e6),round((10+math.sin(a))*1e6)));t.SetLayer(pcbnew.F_Cu);t.SetWidth(200000);t.SetNet(nets['TARGET']);b.Add(t)
 pcbnew.SaveBoard(str(bp),b);bp.with_suffix('.kicad_pro').write_text(json.dumps(pro))
 dru='(version 1)\n(rule floor (condition "A.NetClass == \'Default\'") (constraint track_width (min 0.2mm)))\n'
 if hostile:dru+='(rule hostile (condition "A.Type == \'Track\' && B.Type == \'Pad\'") (constraint clearance (min 0.3mm)))\n'
 bp.with_suffix('.kicad_dru').write_text(dru)
 argv=(['kicad-cli','pcb','drc','--severity-all','--all-track-errors','--exit-code-violations','--format','json','-o',str(d/'drc.json'),str(bp)] if native else ['/usr/bin/python3',str(P/'source/skills/kicad-pcb/scripts/escape_check.py'),'--board',str(bp),'--verbose'])
 r=run_stage({'id':name,'work_class':'local','timeout_s':30},argv,log_path=d/'full.log',cwd=S,env=env,console=None).to_mapping();r.update(argv=argv,cwd=str(S));(d/'process.json').write_text(json.dumps(r,indent=2))
 if native:
  j=json.loads((d/'drc.json').read_text());uuids={x['uuid'] for v in j['violations'] if v['type']=='clearance' for x in v['items'] if x['description'].startswith('Track [TARGET]')};obs={'violations':len(j['violations']),'unconnected':len(j['unconnected_items']),'target_track_clearance_uuids':len(uuids),'types':sorted(set(v['type'] for v in j['violations']))}
 else:obs={'log':(d/'full.log').read_text()}
 rows.append({'name':name,'result':r,'observation':obs});print(json.dumps(rows[-1]),flush=True)
(out/'observations.json').write_text(json.dumps(rows,indent=2))
