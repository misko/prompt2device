from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,subprocess,tarfile
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';E=P/'01_docs/evidence/pland-backtrack-20260910';D=Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[];sources=[(q,'root-verification/'+q.relative_to(D/'kernel-root-verification-scratch').as_posix()) for q in (D/'kernel-root-verification-scratch').rglob('*') if q.is_file()]
for name in ['kernel-final-source-t1.log','kernel-final-source-t1.start.json','kernel-final-source-t1.result.json','kernel_parser_final_review.py','kernel-parser-final-reviewed-source.py','kernel-parser-final-review.json','kernel-parser-final-review.log','kernel-parser-final-review.start.json','kernel-parser-final-review.result.json']+[f'kernel-parser-final-review-{i}.kicad_dru' for i in range(4)]:sources.append((D/name,'coordinator/'+name))
sources.append((Path(__file__),'coordinator/close_kernel_boundary.py'))
tmp=D/'kernel-root-verification.tar.gz'
with tarfile.open(tmp,'w:gz') as tf:
 for q,name in sorted(sources,key=lambda x:x[1]):
  b=q.read_bytes();assert not q.is_symlink();tf.add(q,arcname=name,recursive=False);rows.append(dict(member=name,original_path=str(q),sha256=sha(b),size=len(b)))
with tarfile.open(tmp) as tf:
 ms=tf.getmembers();assert len(ms)==len(rows)==len({m.name for m in ms})
 for m,x in zip(ms,rows):assert m.isfile() and m.name==x['member'] and m.size==x['size'] and sha(tf.extractfile(m).read())==x['sha256']
digest=sha(tmp.read_bytes());dest=E/(digest+'.tar.gz');assert not dest.exists();shutil.copy2(tmp,dest)
(E/'native-kernel-root-verification-manifest.json').write_text(json.dumps(dict(schema=1,tar_sha256=digest,tar_size=dest.stat().st_size,count=len(rows),entries=rows),indent=2)+'\n')
# Restore only exact unadopted author paths after verifying every current byte against the durable attempt.
manifest=json.loads((E/'native-kernel-attempt-manifest.json').read_text());byname={x['member']:x for x in manifest['entries']}
for path in ['skills/kicad-pcb/scripts/land_witness.py','tests/t1_land_witness.py','skills/kicad-pcb/scripts/contracts.md','tests/README.md']:
 q=R/path;b=q.read_bytes();x=byname['unadopted-live/'+path];assert len(b)==x['size'] and sha(b)==x['sha256']
 if path.endswith(('land_witness.py','t1_land_witness.py')):q.unlink()
 else:q.write_bytes(subprocess.check_output(['git','show','HEAD:'+path],cwd=R))
now=datetime.now(timezone.utc).isoformat()
(E/'native-kernel-adoption.md').write_text(f'''# Native controls retained; complete kernel source rejected

MEASURED final author handback received2026-09-10T23:07:16Z, before original
23:09:40Z deadline. Root resumes sole live writer. The same original commission
was resumed after premature incomplete returns; no deadline, replacement or
nonimprovement allowance was enlarged. Authoring is closed. This is not full
kernel adoption, public P-LAND repair, placement acceptance or release progress.

MEASURED root reopened all666 launch inputs:663 unchanged and exactly three
permitted changes (scripts/contracts.md, tests/README.md, compact handoff).
Original public checker cb0d0cf6cb593b5f231fa372920e7dc6adf10bce95c0d734fac0900d3fd3ddf3
and tests424d6dd38567c99fb5ee457f01e1f2b0b071bed48c4b92d4a49b02e04816856c stayed exact.
Pre-edit audit50346d916dde3abe9c31ee58599b0e6715829a9a966420e8353f16d745004eec
records483/483 preimages,470 frozen, verified before first edit. The board,
schematic, project/rules, checkpoints, models, route and release were untouched.

MEASURED archive da81f0f730c19d4b77260fcf52ada0f35d2ed3d380463b455c463de8cb479048
reopens1266 regular members /3663151 archive bytes against
native-kernel-attempt-manifest.json. It includes all eight persistent test
folders, unadopted source/tests, packet, root diagnostics, source authorities,
administrative commission errors, early handback archive22fe65c4 and original
worker report de2d9198139a640286573ce0865d3fee3a746e9e438b582f8e2a90cc790a5a46.
The worker's275 manifest rows rehash, but omit two nested extracted manifests
and all external fixture bytes; root's complete archive includes them. The
worker process statement is not a complete PID/timing audit. Lost transient
outputs from earlier tests are not recreated or claimed retained.

ADOPTED MEASUREMENTS: exact complete-class native base0physical/0opens; hostile
2 Track TARGET–X1.3/X1.4 clearance findings/0opens when all-track-errors is used.
Final maintained search control visits48 directions at the specified center:
base has a witness and hostile none at0.2mm. The evaluator corpus matches18/18
base and18/18 hostile specified tracks, not general search completeness.
The corrected private circle BASE run has exactly1 clearance/0opens, rule
circle_gap required0.2210mm versus actual0.2200mm at Track remote_high_T–X1.3.
Earlier circle CLI accidentally ran HOSTILE; its18 findings are retained and
are not the injected base-rule control. The final maintained circle assertion
uses native shape distance, while its independent CLI is separate evidence.

MEASURED root independently ran exact final library eac679bd7b640b789bcba1a9fb7c5777b0658bf7d0a13c18511ecf01bb089882:
t1_land_witness6/6 PASS,3 known-bad, actualrc0/1.616677s at23:08:59.970210Z to
23:09:01.587051Z. Full stdout, root process receipt and two persistent fixture
folders are archived in {digest};
native-kernel-root-verification-manifest.json reopens all{len(rows)}members.
Child native stdout/stderr/JSON/argv/rc are retained, but the authored harness
still lacks child PID/start/end/duration. Do not reconstruct missing metadata.

UNRESOLVED SOURCE/VALIDATION CONTRACT: root's final exact parser challenge
rejects six tested malformed/unsupported forms, but still silently accepts
(rule x (constraint via_diameter malformed) (condition)) as an empty rule list.
Known out-of-scope constraints are not fully structurally validated/inventoried.
Local PAD/FP optional precedence is implemented without maintained native
controls for nonzero, explicit zero, competing custom rules or below-board
cases; compound-class equality/holes/multilayer guards lack focused coverage.
Search chooses the first native layer without an explicit layer API, caller
supplied directions need only be48 unit vectors, and caller widths need not
be the prescribed finite declared minima. Unsupported shape/sample behavior
and honest result scope need a closed interface. Its cmax omits local overrides
but is UNUSED by the all-obstacle search; that field is not a safe pruning bound.
The source is useful WIP, not a completed seven-group contract. Root restored
the two contract homes and removed the two unadopted source/test paths ONLY
after comparing them byte-for-byte to the durable archive.

REPORT CORRECTIONS: opening no-area/two-test assertions describe the early
handback, not the final source. Attempt2 failed missing class attrs;2b already
accepted base but falsely accepted hostile;2c was a syntax error;2d corrected
hostile. Initial main() ignored the harness return code; final SystemExit fixes
that. Native entry omitted exit-code-violations, so actualrc0 applies to both;
final maintained CLI uses the flag and actualbase0/hostile5. No public old-code
behavioral RED/finalGREEN has yet been installed or run.

SEPARATE INHERITED GOVERNANCE FINDINGS: t1_contracts16/1 failed on two untracked
units (now removed), not waived. t1_gate_contract35/2/1skipped failed on FIVE
actual obligations: jlc_pcba_availability G-RED; commission_project G-COVER;
project_report_audit G-COVER; enclosure_layout_audit G-COVER and G-RED.
Root's exact262-file HEAD5c89d76b skeleton reproduces all95 gate rows and these
same five failures. The owning audit actualrc1/1.818910s; baseline comparison
rc0/2.470059s. They are inherited CHECK FAILURES, not passing exceptions. They
must be repaired or otherwise resolved through their normal source contracts
before final validation. The audit is not weakened or put on a skip list.

D-BACK: reopen upstream native-kernel API, supported-language and verification
contract for fresh judgment. Question: can the adopted finite-witness model be
made fail-closed through a small exact native candidate interface and complete
supported syntax/semantic admission, or does it need a different native oracle?
The failed whole-method, whole-witness and kernel authoring histories/caps stay
closed. No replacement kernel author is commissioned by this record. Require
fresh private diagnosis and a concrete evidence-backed remedy before any further
production authoring. Public integration (including tool dependency identity),
all483 stale-checkpoint preimages/strict canonical restart and every later
placement/routing/orientation/release gate remain owed.
''')
c=E/'contracts.md';s=c.read_text();anchor='| `contracts.md` | this exact dated contract | no wildcard evidence namespace |';assert s.count(anchor)==1;c.write_text(s.replace(anchor,f'| `{digest}.tar.gz` | independent root final WIP test and parser challenge | reopen native-kernel-root-verification-manifest.json |\n| `native-kernel-root-verification-manifest.json` | exact root verification output inventory | source test was measured before removal; no production acceptance |\n'+anchor))
(P/'01_docs/STATUS.md').write_text(f'''# STATUS beacon — crow audio carrier v1

stage: placement
step: "Native kernel controls preserved; upstream API and validation contract reopened"
measure: "MEASURED6/6 library tests,36 specified tracks, exact2 hostile pairs and circle0.220/0.221; complete kernel rejected. Public checker unchanged."
state: blocked
next: "Fresh private D-BACK judgment; complete supported grammar, layer/search interface and native override controls before production authoring. Five inherited checker-contract failures separately open."
op_pid:
updated: {now}
''')
with (P/'01_docs/journal/placement.md').open('a') as f:f.write(f'''\n\n## {now} — native controls retained; full kernel rejected at source contract

- MEASURED final author handback23:07:16Z before original23:09:40 deadline;
  no replacement/budget extension. Root resumes sole writer.666 inputs reopened,
  663 unchanged/3 allowed contract/handoff changes; public files/native exact.
- MEASURED complete1266-member archive da81f0f7 retains eight persistent fixture
  trees and all failed/early outputs; supplementary{len(rows)}-member archive{digest[:8]}
  retains root6/6 PASS3known-bad1.616677s and final parser challenge. Original
  transient native outputs and missing child metadata remain explicitly missing.
- ADOPT only measured native two-pair,36 specified-track and corrected circle
  controls. Reject complete source: malformed irrelevant rule still disappears;
  native local/FP/zero/custom controls and precise layer/search API remain owed.
  WIP removed only after exact archived-byte verification; no public integration.
- MEASURED gate-contract failure is five inherited obligations on four scripts,
  reproduced across all95 gate rows on exact262-file HEAD baseline; not a waiver.
- D-BACK upstream API/supported-language/validation contract to fresh private
  judgment. All earlier author and fixture caps/history retained; no replacement
  author or renewed kernel repair loop. Native-kernel-adoption.md owns corrections.
''')
learn=P/'01_docs/learnings/placement.md'
with learn.open('a') as f:f.write(f'''\n\n## {now} — candidate canon: parser admission and native proof closure

A useful native fixture matrix does not validate syntax that the rule loader
silently discards. Validate the entire rule structure before per-constraint
scope filtering, and bind an explicit candidate layer/search contract. Native
local/footprint overrides require both value and optional-presence controls.
Preserve each child fixture and its actual process receipt; a harness return
value must reach the process exit status. Evidence and exact failed WIP:
../evidence/pland-backtrack-20260910/native-kernel-adoption.md. Proposal only;
no gate or threshold is waived, and no electrical finding closes from this work.
''')
print(json.dumps(dict(root_archive=digest,members=len(rows),removed_unadopted_source=True,restored_contract_homes=True,time=now),indent=2))
