from pathlib import Path
import hashlib,importlib.util,json
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');D=Path(__file__).parent;source=(R/'skills/kicad-pcb/scripts/land_witness.py').read_bytes();snap=D/'kernel-parser-final-reviewed-source.py';snap.write_bytes(source)
spec=importlib.util.spec_from_file_location('reviewed',snap);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
rows=[]
for label,s in [('property_comparison',"A.NetName == B.NetName"),('unsupported_escape',r"A.NetName == 'N\x'"),('literal_left',"'N*' == A.NetName")]:
 try: result=m.condition(s);rows.append(dict(case=label,outcome='accepted',ast=result))
 except Exception as ex: rows.append(dict(case=label,outcome=type(ex).__name__,why=str(ex)))
for i,(label,s) in enumerate([('condition_extra','(version 1)(rule x (condition "A.Type == \'Track\'" ignored) (constraint track_width (min 0.2mm)))'),('layer_extra','(version 1)(rule x (layer F.Cu ignored) (constraint track_width (min 0.2mm)))'),('irrelevant_malformed','(version 1)(rule x (constraint via_diameter malformed) (condition))'),('empty_form','(version 1)()')]):
 p=D/f'kernel-parser-final-review-{i}.kicad_dru';p.write_text(s)
 try: result=m.rules(p);rows.append(dict(case=label,outcome='accepted',rules=result))
 except Exception as ex:rows.append(dict(case=label,outcome=type(ex).__name__,why=str(ex)))
out=dict(source_sha256=hashlib.sha256(source).hexdigest(),rows=rows);(D/'kernel-parser-final-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
