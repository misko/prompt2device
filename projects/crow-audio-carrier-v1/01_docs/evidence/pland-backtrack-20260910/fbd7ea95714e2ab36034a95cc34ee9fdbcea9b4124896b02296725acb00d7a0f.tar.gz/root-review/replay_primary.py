from pathlib import Path
import sys,json,hashlib
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');W=Path('/tmp/carrier-native-kernel-implementation-20260911');D=Path(__file__).parent
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
p=W/'skills/kicad-pcb/scripts/escape_check.py';new=p.read_bytes();old=(R/'skills/kicad-pcb/scripts/escape_check.py').read_bytes();test=W/'tests/t1_land_witness.py';testsha=hashlib.sha256(test.read_bytes()).hexdigest();receipts=[]
assert hashlib.sha256(old).hexdigest()=='cb0d0cf6cb593b5f231fa372920e7dc6adf10bce95c0d3fd3ddf3ddf3' if False else True
assert hashlib.sha256(old).hexdigest()=='cb0d0cf6cb593b5f231fa372920e7dc6adf10bce95c0d734fac0900d3fd3ddf3'
try:
 for mode,code,expected in [('old',old,1),('new',new,0)]:
  p.write_bytes(code);assert hashlib.sha256(test.read_bytes()).hexdigest()==testsha
  argv=['/usr/bin/python3','tests/t1_land_witness.py','--only=native-clean complete-class public acceptance and census']
  binding={'mode':mode,'checker_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'test_sha256':testsha,'argv':argv}
  (D/f'primary-{mode}.binding.json').write_text(json.dumps(binding,indent=2)+'\n')
  result=run_stage({'id':f'root_primary_{mode}','work_class':'local','timeout_s':90},argv,cwd=W,log_path=D/f'primary-{mode}.log',console=None).to_mapping()
  (D/f'primary-{mode}.result.json').write_text(json.dumps(result,indent=2)+'\n')
  assert result['returncode']==expected,result
  print(mode,result['status'],result['returncode'],testsha,flush=True);receipts.append(binding|result)
finally:p.write_bytes(new)
assert p.read_bytes()==new
(D/'primary-replay.json').write_text(json.dumps({'same_test':True,'restored':True,'runs':receipts},indent=2)+'\n')
