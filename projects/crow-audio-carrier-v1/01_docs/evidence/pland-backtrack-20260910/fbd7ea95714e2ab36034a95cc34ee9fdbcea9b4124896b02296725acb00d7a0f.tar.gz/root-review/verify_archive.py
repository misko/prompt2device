from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,subprocess,datetime
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');W=Path('/tmp/carrier-native-kernel-implementation-20260911');D=Path(__file__).parent;O=R/'projects/crow-audio-carrier-v1/06_build/task_runs/native-kernel-integration-20260911T030619Z/outputs'
M=json.loads((O/'evidence-manifest.json').read_text());arc=O/'evidence.tar.gz'
assert hashlib.sha256(arc.read_bytes()).hexdigest()==M['archive']['sha256'];assert arc.stat().st_size==M['archive']['size']
seen=set();total=0
with tarfile.open(arc,'r:gz') as tf:
 for m in tf:
  p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts and m.name not in seen,m.name
  seen.add(m.name);b=tf.extractfile(m).read();assert {'sha256':hashlib.sha256(b).hexdigest(),'size':len(b)}==M['members'][m.name],m.name;total+=len(b)
  if m.name.startswith('source/'):
   rel=m.name.removeprefix('source/');assert (W/rel).read_bytes()==b,rel
  if m.name in ('scratch/iteration-record.json','scratch/final-source-manifest.json','scratch/process-closure.json') or (m.name.startswith('scratch/handback-') and m.name.endswith(('.json','.log'))):
   out=D/'selected'/m.name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
assert seen==set(M['members'])
allowed={'skills/kicad-pcb/scripts/land_witness.py','tests/t1_land_witness.py','skills/kicad-pcb/scripts/escape_check.py','tests/t1_escape_tier.py','skills/kicad-pcb/scripts/pcb_flow.py','tests/t2_pcb_flow.py','skills/kicad-pcb/scripts/contracts.md','tests/README.md','skills/kicad-pcb/references/design-policies.md','skills/pcb-design/templates/contracts/04_kicad/contracts.md','projects/crow-audio-carrier-v1/04_kicad/contracts.md'}
for rel,v in M['final_source'].items():
 assert rel in allowed or rel.startswith('tests/fixtures/land_witness/'),rel
 p=W/rel;assert not p.is_symlink();b=p.read_bytes();assert {'sha256':hashlib.sha256(b).hexdigest(),'size':len(b)}==v,rel
paths=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=W,text=True,timeout=30).splitlines();assert set(paths)==set(M['final_source'])
patch=subprocess.check_output(['git','diff','--cached','--binary','HEAD'],cwd=W,timeout=30);assert patch==(O/'patch.diff').read_bytes()
pre=json.loads((R/'projects/crow-audio-carrier-v1/06_build/tmp/native-kernel-integration-20260911T030619Z/source-preimages.json').read_text())
for row in pre['allowed_files']:
 p=R/row['path']
 if row['sha256'] is None:assert not p.exists(),str(p)
 else:assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],str(p)
for rel in paths:
 if rel.startswith('tests/fixtures/'):assert not (R/rel).exists(),rel
result={'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive_sha256':M['archive']['sha256'],'members':len(seen),'uncompressed_bytes':total,'source_files':len(paths),'patch_sha256':hashlib.sha256(patch).hexdigest(),'live_preimages_unchanged':True,'private_scope_pass':True}
(D/'archive-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
