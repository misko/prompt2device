# Isolated native kernel and public P-LAND implementation

Agent-role authoring, fresh context, no child agents. Root owns the live worktree;
you own source changes ONLY in /tmp/carrier-native-kernel-implementation-20260911. This external isolated checkout is explicitly
authorized private write scope; the envelope READ_ONLY detector covers the LIVE
project and is not a sandbox for this private checkout. Root will independently
check your patch/file scope. Other work goes in allocated scratch/outputs.
Never edit live /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901.
Do not modify or commit private native board/project/rules/schematic artifacts.
No network, releases, routing, canonical rebuild, model changes or child agents.

Work/delivery cutoff 2026-09-11T03:49:19.442585+00:00; hard coordinator deadline
2026-09-11T03:51:19.442585+00:00. One authoring attempt, three consecutive non-improving
evaluations maximum. Retain iteration record before/after each meaningful test
run; setup fixes have no engineering credit and cannot reset the cap. No
extension/replacement. Finish outputs and FINAL before the work cutoff; reserve
last two minutes of work for handback. Root closing buffer is not extra work.

First verify packet, four complete archive manifests and all source-preimages
against private and live files before any edit. The private checkout is
detached7d2c5d9d; live167bfa36 differs only in later workflow/evidence documents
for the scoped files, whose exact bytes root compared. Historical483preimages
remain in Git at the manifest source commit; independently rehash them via
bounded git cat-file before editing (do not overwrite present source with them).
Read accepted native-semantics-replacement-result.md completely, then owning
CLAUDE, tests/README and relevant policy/contracts in the private checkout.

The native semantic contract is accepted at167bfa36 after valid fresh review;
this is a revised evidence-backed implementation contract, not resumption of
any exhausted whole-method/witness/kernel commission. The archived library
eac679bd... is useful rejected WIP only; do not import its semantic defects.
The new library must remain clean, maintainable, generic and library-only.
Put supported-language and native/tolerance/search boundaries in its docs.

# Adopted bounded implementation scope

One isolated implementation owner carries the accepted finite-witness kernel
through public P-LAND integration. No new global model, backend experiment,
board edits or repeat of closed author commissions. The current review's exact
accepted contract controls supported syntax, native semantics and stop conditions.

Allowed candidate source: new skills/kicad-pcb/scripts/land_witness.py and
tests/t1_land_witness.py; existing escape_check.py, tests/t1_escape_tier.py,
pcb_flow.py, tests/t2_pcb_flow.py; scripts/contracts.md, tests/README.md,
design-policies.md, template04_kicad/contracts.md and current project's
04_kicad/contracts.md. Add focused fixture files under tests/fixtures only
with their explicit contract home. Do not change harnesses, audit checkers,
ratchets/debt, source geometry/rules, models, canonical artifacts or releases.

First install the primary maintained behavioral test expecting success for the
exact independently native-clean complete-class five-pad base, its nonzero
2graded/5copper/3floorless and X1.1 correct witness. Before altering the original
public checker, run SAME positive behavioral assertion RED for its existing
X1.1 geometric rejection. New missing-module/API failure is not this RED.
Native specified-track hostile remains two X1.3/X1.4 clearance pairs/zero opens;
free-search rejection must have its own complete prescribed-coverage evidence.

Implement syntax admission and native candidate validation before exposing the
public search. Keep routine source corrections with this owner within the
original deadline and at most three consecutive non-improving evaluations;
record actual runs, failure identities and remedies without resetting counts.
Test generators may use native APIs, but independent native CLI supplies the
oracle. Do not compare two uses of the same Python condition evaluator as proof.

Native tests must retain exact CLI flags/PIDs/start/end/exit/full logs and input
board/project/rules bytes (including failed setup/control files) under allocated
scratch. Use pipeline_runtime.run_stage or process_runner's bounded adapter;
no new timeout/process implementation. Test fixture children use60s limits,
full suites300s, with original overall deadline still binding. Keep stdout beyond
harness truncation; no logs silently deleted with TemporaryDirectory.

Implement public finite-witness results with exact start/end/layer/width/rule and
limiting pair evidence. Preserve eligibility/census/exemption bucket priorities,
physical/copper/noncopper counts, nominal-pour scope, native enabled-layer-aware
via bucket, no-net source exclusions and obstacles, unreadable/unsupported
blocking and actual same-net incident-track inventory. No maximum, SHORT BY,
MODEL-REFUTED or impossibility claim. Existing D-ESC/package/tier behavior stays
meaningfully equivalent. Missing explicit inputs, incoherent --project overrides,
malformed/unsupported rules or caller-selected weakened search limits must fail
legibly. New helper belongs in pcb_flow DEFAULT_TOOL_FILES; add behavioral
helper-only stale-handoff RED/GREEN rather than asserting filename membership.

Preserve existing maintained CAL stripped eleven IDs/floors and relaxed pass;
RX2 five clearance roundtrip IDs; CRC bucket equality >=30 nominal-pour,
>=40 via and >100 actual incident-track inventory; QSPI-only13graded/>250floorless;
zero-denominator and unreadable controls. Do not force inherited candidate counts
or weaken known-bad assertions. An unexpected corpus verdict requires native
causal evidence or a named blocked outcome, never silently altered expectations.

Final same-source validation: primary SAME regression GREEN, full t1_land_witness,
t1_escape_tier, t2_pcb_flow, t1_gate_contract, t1_contracts; authority/docs audits
if skill authority/reference changes require them. Tests are staged only in the
isolated checkout to allow contracts to see their actual membership. No commits
or pushes. Return patch.diff (including new files), report.md, evidence.tar.gz,
evidence-manifest.json and exact-subject result.json. Declare only actual final
source hashes, exact successful/failed command results, process cleanup and open
issues. Delivery PASS is not root source adoption. All authoring, board/release
and source-investigation histories remain preserved.


Boundary clarifications: native clearance uses native Collide with
max(0,required-epsilon), and reports raw gap/margin separately. Area tests
use native deflation once. Maintain exact-tolerance controls; no arbitrary
margin subtraction. Preserve13ADCzero-modeled-margin source witnesses and
all current custom/THT demand. Composite classes may be supported natively
or named blocking unsupported before folding; actual complete-class baseline
must still pass. Private direct inspection of the qualified pcbnew API is
allowed to implement the already-decided native contract, but no alternate
backend/framework research. Unknown actual corpus semantics is a blocker.
The five historically inherited gate-contract defects were repaired before
7d2c5d9d; use actual final tests, not stale historical failure prose.

Maintain a neutral primary behavioral test that can run unchanged against old
and new output conventions: assert native-clean fixture acceptance and census,
not a new-only status string before the old-code RED. Additional final witness
structure assertions can be separate. Keep exact failed run/source hashes.
Final native and public fixtures must not rely on a transient /tmp source or
this project's evidence folder; make generic maintained fixtures with a proper
contract or native fixture constructors. Copy only necessary exact approved
fixture bytes into the maintained test corpus, with provenance.

For full tests use TMPDIR in allocated scratch so native outputs persist.
Stage only allowed private changes before contract tests; do not commit.
Serialize all new files into patch.diff (git diff --cached --binary HEAD after
explicitly staging allowed files). Include actual test code, source and all
command outputs/fixtures in evidence.tar.gz with regular-member SHA/size map
in evidence-manifest.json; don't archive unchanged entire checkout or repeat
old source archives. Source patch acceptance is root's later decision.

Outputs exactly patch.diff,report.md,evidence.tar.gz,evidence-manifest.json,
result.json. Use result.json subject from envelope; checks inputs-verified,
implementation-complete,processes-closed with actual values and explicit
unresolved. Only mark implementation-complete PASS if accepted contract and
required checks are fulfilled; otherwise deliver a complete honest blocking
report and partial patch, with unresolved rows. Never disguise incomplete
engineering as completed implementation. Keep all processes closed before FINAL.
