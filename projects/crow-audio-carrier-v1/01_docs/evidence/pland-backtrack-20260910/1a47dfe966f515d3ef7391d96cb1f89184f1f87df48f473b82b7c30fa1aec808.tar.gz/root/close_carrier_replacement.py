from pathlib import Path
import sys,json
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_runtime import close_agent_attempt
j=json.loads(Path('/tmp/carrier-replacement-opened.json').read_text());e=TaskEnvelope.from_json(Path(j['envelope']).read_text())
state=sys.argv[1];assert state in ('completed','error','unknown')
r=close_agent_attempt(e,cwd=P,event={'host':'collaboration','agent_id':'/root/carrier_native_semantics_replacement','state':state,'envelope_sha256':j['envelope_sha256'],'cleanup':'confirmed' if state=='completed' else 'unknown','detail':'Coordinator observed real host FINAL_ANSWER and returned synchronous read/extract commands; no background process or native experiment commissioned.' if state=='completed' else 'Coordinator enforced earlier reviewer work cutoff; no timely complete delivery.'})
print(r.status,r.unresolved)
