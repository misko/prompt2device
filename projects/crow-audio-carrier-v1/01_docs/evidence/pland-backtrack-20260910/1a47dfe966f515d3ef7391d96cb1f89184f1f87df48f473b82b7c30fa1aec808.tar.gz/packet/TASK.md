# Fresh replacement D-BACK judgment

Agent-role judgment. User explicitly approved this one replacement. No history,
no child agents, no production edits or new experiments. Root owns live tree.
Use only allocated scratch/outputs for writes. Verify all envelope input SHA/size
and all four archive manifests before safe extraction. The supplied envelope
digest is canonical JSON SHA256, not raw serialized-file hash.

HARD WORK/DELIVERY CUTOFF 2026-09-11T02:59:23.654046+00:00. Finish and send FINAL by then.
The envelope deadline 2026-09-11T03:01:23.654046+00:00 reserves root closing time; it is
not additional reviewer work time. Start writing concise final outputs early.
No new native experiments/network research. If evidence is inadequate, deliver
a completed REASSESS judgment naming the missing evidence. No extension/retry.

Question: can the finite declared-width pad-launch witness model be implemented
through a small fail-closed native kernel supporting current/CAL/RX2/CRC, and
what precise bounded implementation/verification contract is necessary? Read
raw native evidence and exact official10.0.4 sources independently. Do NOT read
the earlier completed or interrupted reviewer judgment/result reports as a
preload or substitute. Historical coordinator adoption records label the
unaccepted source and exhausted attempts; preserve those boundaries.

Raw evidence locations: c059... archive contains archived native-controls.json
(ten PAD/FP precedence cases), semantics-controls.json (strings/Boolean/area),
corpus-census.json and official authority sources. da81... contains rejected
land_witness.py SHAeac679bd7b640b789bcba1a9fb7c5777b0658bf7d0a13c18511ecf01bb089882
and complete-class native base/hostile controls.887c... contains18-station
native matrix and prototype. New9ca... archive contains review/scratch/focused/
(width below board and area1IU relaxation native controls),
review/scratch/original-complete-class-full.log, additional native condition
source and public-red-v3 diagnostic. All new failed setup outputs remain.
Do not read review/outputs/judgment.md or prior report reasoning.

Adjudicate seven groups:1 complete syntax/condition grammar including malformed
irrelevant rules, B-dependent width before folding, case/wildcards/Boolean
precedence;2 resolved complete classes/native assignment and composite guards;
3 ordered actual Track width and Track-Pad clearance in both A/B orders;
4 absent/zero/nonzero PAD/FP/custom/board precedence;5 native circle/capsule and
area epsilon geometry;6 enabled layers, THT, custom pad shapes, holes and named
unsupported guards;7 policy-owned finite widths/starts/48directions/1mmreach/
2mmcap. Preserve actual adaptive sampling generator (37max proposals; .03mm
requested scale becomes coarser at capped intervals), no unsafe obstacle pruning.
Witness or NO_VALIDATED_WITNESS is never maximum-width or impossibility.
A minimal supported grammar may explicitly block unsupported inputs provided
all actual corpus demand is covered and no unknown becomes floorless/pass.

Primary public regression: complete-class five-pad native base0physical/0opens
is falsely rejected by original public checker atX1.1 floor.2/landable.12.
Exact native hostile specified track has two pair clearance findings/0opens.
Specify SAME maintained test actualRED thenGREEN; these observed diagnostics
are not yet a maintainedRED. Center-track evidence cannot prove all-start search.
Additional ring falsePASS diagnostic has unrelated native findings/opens; keep
those explicit. Preserve current1002/940physical/copper, CAL324/300, RX2291/272,
CRC786/755; CALeleven exact IDs/floors, RX2five .14clearance contrasts, CRC
>=30nominalpour/>=40via buckets/>100actualtrack inventory, QSPI13graded/>250
floorless, no-net/unreadable/zero-denominator coverage. Nominal pours do not
prove connectivity. Source/test/policy/contracts and tool identity must change
together, strict canonical restart required afterward. Do not invent missing
measurements, weaken tests, promote diagnostics, or clear downstream gates.

Deliver exactly judgment.md, evidence.json,result.json. judgment.md: concise
GO boundedcontract or REASSESS, evidence-backed semantics, mandatory tests,
remaining uncertainty/stop conditions and ordered implementation. evidence.json:
archive/member/SHA supporting each material finding, verified input counts,
process closure statement (only synchronous read/extract helpers expected).
Reference retained raw outputs instead of duplicating archives or prose.
result.json must bind envelope.subject and checks inputs-verified,
judgment-complete,processes-closed with PASS only for fulfilled DELIVERY
obligations and unresolved:[]; engineering blockers belong in the judgment.
No claim of implemented code, maintainedGREEN, placement or release acceptance.
