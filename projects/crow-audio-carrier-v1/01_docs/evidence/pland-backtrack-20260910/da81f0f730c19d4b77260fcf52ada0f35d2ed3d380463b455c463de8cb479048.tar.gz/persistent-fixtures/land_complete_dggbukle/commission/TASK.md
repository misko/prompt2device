# Fresh mechanical native-interface admission

agent-role: mechanical
context_mode: FRESH
source_commit: b803abc41086cf3ef78e9aceae344e20a9b7b848
repository: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901
private_output_root: /tmp/pland-native-complete-classes-20260910T222644Z
live tree: READ_ONLY; root retains exclusive live ownership

Verify exact task-envelope SHA, all input members and aggregate identities before
work. Read CLAUDE.md, copied flow/beacon/journal tail, pcb-design lifecycle and
compute references, and01_docs/evidence/pland-backtrack-20260910/native-complete-classes-plan.md.
That plan is the adopted upstream interface dependency. Prior author/diagnosis caps remain exhausted. This is the third and final local interface execution, with only complete class fields added after the compound-class census. If it fails, stop; no fourth local arrival or replacement. The earlier sparse-class defect stays a distinct production control.

Execute exactly one frozen producer command. Rehash
01_docs/evidence/pland-backtrack-20260910/3aa78234c2007b00d366a4af041ae7725bb0379682f07dd1d186d62703abe6b9.tar.gz
and all3 members against native-complete-classes-manifest.json. Safely extract
exactly the three regular files to/tmp/pland-native-complete-classes-20260910T222644Z/producer, rejecting links, traversal,
duplicates, missing/extra files or SHA/size differences. Never edit these scripts.

The last argument is the already existing private PARENT. The producer allocates its own unique child with tempfile.mkdtemp and prints OUTPUT_DIRECTORY; read the actual child path from that JSON line. Do not guess it.

Exact command:
/usr/bin/python3 /tmp/pland-native-complete-classes-20260910T222644Z/producer/execute.py /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901 /tmp/pland-native-complete-classes-20260910T222644Z

Overall420second process-group timeout; all children have60second timeouts.
Task hard deadline is now+10minutes as exact envelope; final60seconds reserved
for complete report/closure. One execution, no repairs, retries, alternative APIs,
extra fixtures, native scans or replacements. If ANY step fails, preserve all
outputs, stop and hand back. You may write an administrative timeout/log wrapper
but cannot change producer/fixture semantics or assertions. Write actual command
argv/start/PID/full stdout/stderr/rc/duration to files before/after execution.
The producer separately captures its6child commands. Keep administrative and
producer outcomes distinct. No invented pcb_flow logs or source acceptance.

The producer's native/basic census must have5copper/2declared-floor/3floorless,
exact scalar class names and F.Cu layer. The unchanged public checker must fail
named X1.1 geometrically at that nonzero denominator. Independent native DRC
must show0physical/0opens on base and exactly2track-clearance findings/0opens
on hostile; preserve ALL categories. No schematic exists, parity not invoked.
Read complete actual logs/admission.json if produced. A rc0 wrapper is not proof
of the underlying result. No maintained regression or production repair is
installed by this task even if diagnostic admission succeeds.

Report verified launch promptly and meaningful progress<=60seconds apart. Deliver
actual complete report to/tmp/pland-native-complete-classes-20260910T222644Z/result.md with every command outcome, exact
source/fixture/result hashes and all unresolved rows. Write process/input audits and final report BEFORE computing the output manifest; list every actual regular output except the manifest itself, and stop writing after its final emission. Final exactpacket
audit and output SHA/size manifest are required (count this new envelope, not the
prior640). Verify original checker/test/native source unchanged, all extracted
producer files still exact and every child terminated/reaped. End all processes
and writes before handback. Do not write any live project file, commit, regenerate
board/source, change checkpoints/models/rules, launch reviews/routing or releases.
Root owns durable preservation, adoption and next separate source boundary.

Aggregate formula:
pipeline_identity.subject_identity('crow_pland_native_complete_classes',1,
[TypedIdentityInput('packet','sequence',input_packet,json.dumps(input_packet,sort_keys=True).encode())]).
