"""No search: independently reopen every recorded witness and all close pairs."""
import sys,pathlib,json,time,pcbnew
ROOT=pathlib.Path('/tmp/pland-evaluator-dback-20260910T203349Z');sys.path.insert(0,str(ROOT));import witness_prototype as p
path=p.LIVE/'projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb';b,pads,unread,areas,pours,vias,tracks,census=p.load(path);rs=p.rules(path.with_suffix('.kicad_dru'));cl,mn=p.old.read_class_clearance(path.with_suffix('.kicad_pro'));ev=p.Evaluator(b,rs,areas,pads,cl,mn)
measured=json.loads((ROOT/'exhaustive-witness-geometry-audit.json').read_text());recorded=json.loads((ROOT/'fullboard-witness.json').read_text());byid={(q['ref'],q['num']):q for q in pads};byname={q['pad']:q for q in measured['records']};rows=[];fail=[];t0=time.monotonic();maxwidth=0;local=[]
for q in pads:
    for L in q['layers']:
        own=q['_native'].GetOwnClearance(L)/1e6
        if own>cl.get(q['cls'],0):local.append({'ref':q['ref'],'num':q['num'],'layer':b.GetLayerName(L),'own_clearance':own,'class_clearance':cl.get(q['cls'],0)})
for row in recorded['rows']:
    if row['status']!='VALIDATED_CONSTANT_WIDTH_WITNESS':continue
    q=byid[row['ref'],row['num']];w=row['witness'];L=b.GetLayerID(w['layer']);maxwidth=max(maxwidth,w['width']);candidate={'id':'CANDIDATE','net':q['net'],'cls':q['cls'],'type':'Track','layer':L,'layer_name':w['layer']}
    close=byname[row['ref']+'.'+row['num']]['pairs_below_global_ceiling'];obstacles=[byid[x['ref'],x['num']] for x in close];pairs=ev.pairs(candidate,obstacles);wr=ev.prepare(candidate);ok,detail=ev.validate(candidate,w['start'],w['end'],w['width'],wr,pairs)
    out={'pad':row['ref']+'.'+row['num'],'ok':ok,'detail':detail,'all_potentially_limiting_pairs':len(close)};rows.append(out)
    if not ok:fail.append(out)
result={'status':'RECORDED_WITNESSES_ONLY_NO_SEARCH','count':len(rows),'failed':fail,'all_pairs_previously_reopened':measured['all_same_layer_other_net_pair_checks'],'potential_limiters_resolved':sum(r['all_potentially_limiting_pairs'] for r in rows),'actual_width_max_mm':maxwidth,'actual_own_clearance_max_mm':measured['native_own_clearance_max_nm']/1e6,'original_expansion_mm':1+1+ev.cmax,'required_expansion_for_actual_witnesses_mm':1+maxwidth/2+measured['native_own_clearance_max_nm']/1e6,'local_clearance_rows':local,'elapsed_seconds':time.monotonic()-t0,'rows':rows,'prototype_unchanged_sha256':__import__('hashlib').sha256((ROOT/'witness_prototype.py').read_bytes()).hexdigest()}
(ROOT/'all-pair-rule-recheck.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ('rows','local_clearance_rows')},indent=2));print('LOCAL_CLEARANCE_ITEMS',len(local));assert not fail;assert len(rows)==677
