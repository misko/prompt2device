import pathlib,json,hashlib,sys,datetime,os
ROOT=pathlib.Path('/tmp/pland-evaluator-dback-20260910T203349Z')
LIVE=pathlib.Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
ep=LIVE/'projects/crow-audio-carrier-v1/06_build/handoffs/pland-evaluator-dback-20260910T203349Z/task-envelope.json';e=json.loads(ep.read_text());sys.path.insert(0,str(LIVE/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet
from pipeline_identity import subject_identity,TypedIdentityInput
strict=TaskEnvelope.from_json(ep.read_text());valid,errors=verify_input_packet(strict,LIVE)
subject=subject_identity('crow_pland_evaluator_dback',1,[TypedIdentityInput('packet','sequence',e['input_packet'],json.dumps(e['input_packet'],sort_keys=True).encode())]).to_mapping()
rows=[]
for item in e['input_packet']:
    p=LIVE/item['path'];actual=sha(p);size=p.stat().st_size;rows.append({'path':item['path'],'expected_sha256':item['sha256'],'actual_sha256':actual,'expected_size':item['size'],'actual_size':size,'unchanged':actual==item['sha256'] and size==item['size']})
commands=[];alive=[]
for rp in sorted(ROOT.glob('*.result.json')):
    d=json.loads(rp.read_text());commands.append({'name':rp.name.removesuffix('.result.json'),**d})
    pid=d.get('pid');proc=pathlib.Path('/proc')/str(pid)/'cmdline'
    if proc.exists():
        cmd=proc.read_bytes().replace(b'\0',b' ').decode(errors='replace')
        if str(ROOT) in cmd:alive.append({'pid':pid,'cmdline':cmd})
prototype=sha(ROOT/'witness_prototype.py');expected='718db2df83e9578c629e024bc9c02d30bffec6667eca02dfaf3cfefb6aeb6e90'
fixtures=[{'path':str(p.relative_to(ROOT)),'sha256':sha(p),'size':p.stat().st_size} for directory in ('base','hostile') for p in sorted((ROOT/directory).iterdir()) if p.is_file()]
closure={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'envelope_sha256':sha(ep),'strict_envelope_valid':valid,'strict_errors':errors,'aggregate_subject_actual':subject,'aggregate_subject_expected':e['subject'],'aggregate_subject_match':subject==e['subject'],'packet_count':len(rows),'changed_members':[r for r in rows if not r['unchanged']],'members':rows,'prototype_sha256':prototype,'prototype_matches_validated_bytes':prototype==expected,'native_fixture_final_members':fixtures,'active_recorded_diagnostic_processes':alive,'completed_commands_before_closure':len(commands),'logging_exception':'Initial pwd, TASK/envelope cat, and logger bootstrap preceded subprocess file capture; original long cat stdout was tool-truncated and is not reconstructed. See bootstrap-note.json.','writes_scope':'All deliberate task writes confined to this private root. Live packet remained read-only. No native full-board save/refill.','closure_semantics':'This closure script and its runner are the final processes. After the runner writes its actual result metadata and returns, all task processes and all task writes have ceased.'}
(ROOT/'closure-verification.json').write_text(json.dumps(closure,indent=2));(ROOT/'command-index.json').write_text(json.dumps(commands,indent=2))
assert valid and not errors and len(rows)==629 and not closure['changed_members'];assert subject==e['subject'];assert prototype==expected;assert not alive
manifest=[]
for p in sorted(ROOT.rglob('*')):
    if p.is_file() and p.name not in ('output-manifest.json','040_close_task.log','040_close_task.result.json'):
        manifest.append({'path':str(p.relative_to(ROOT)),'sha256':sha(p),'size':p.stat().st_size})
(ROOT/'output-manifest.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'members':manifest,'exclusions':['output-manifest.json (self)','040_close_task.log (still open until process exit)','040_close_task.result.json (runner writes after process exit)'],'root_preservation_requirement':'Preserve the entire directory including excluded self/final-log files; this manifest is not a claim those files do not exist.'},indent=2))
print(json.dumps({k:v for k,v in closure.items() if k not in ('members','native_fixture_final_members')},indent=2));print('MANIFEST_MEMBERS',len(manifest));print('FINAL_REPORT_SHA256',sha(ROOT/'result.md'));print('ALL_DIAGNOSTIC_PROCESSES_COMPLETED; ALL_WRITES_CEASE_WHEN_THIS_RUNNER_RETURNS')
