"""Standalone diagnostic only. No maintained checker/API changes or board writes.

Returns one validated constant-width sampled witness; never a maximum.
Geometry helpers/grid from original checker are reused, rule evaluation is new.
Native KiCad DRC is the independent oracle for the declared matrix.
"""
import sys,pathlib,json,re,math,fnmatch,time,collections,hashlib
LIVE=pathlib.Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
ROOT=pathlib.Path('/tmp/pland-evaluator-dback-20260910T203349Z')
sys.path.insert(0,str(LIVE/'skills/kicad-pcb/scripts'))
import escape_check as old
COUNT=collections.Counter()
class Unsupported(ValueError):pass

def sexprs(text):
    tokens=[];i=0
    while i<len(text):
        c=text[i]
        if c.isspace():i+=1;continue
        if c=='#':
            i=text.find('\n',i)
            if i<0:break
            continue
        if c in '()':tokens.append(c);i+=1;continue
        if c=='"':
            j=i+1
            while j<len(text):
                if text[j]=='\\':j+=2;continue
                if text[j]=='"':break
                j+=1
            if j>=len(text):raise Unsupported('unterminated double string')
            tokens.append(('str',json.loads(text[i:j+1])));i=j+1;continue
        j=i
        while j<len(text) and not text[j].isspace() and text[j] not in '()':j+=1
        tokens.append(('str',text[i:j]));i=j
    stack=[[]]
    for tok in tokens:
        if tok=='(':stack.append([])
        elif tok==')':
            if len(stack)<2:raise Unsupported('unbalanced s-expression')
            a=stack.pop();stack[-1].append(a)
        else:stack[-1].append(tok[1])
    if len(stack)!=1:raise Unsupported('unbalanced s-expression')
    return stack[0]

LEX=re.compile(r"\s*(?:(?P<string>'(?:\\.|[^'\\])*')|(?P<op>\&\&|\|\||==|!=|!|\(|\)|\.)|(?P<word>[A-Za-z_][A-Za-z0-9_]*))")
def condition(s):
    if not s.strip():return True
    ts=[];pos=0
    while pos<len(s):
        if not s[pos:].strip():break
        m=LEX.match(s,pos)
        if not m:raise Unsupported('unsupported condition token: '+s[pos:])
        ts.append(m.group(m.lastgroup));pos=m.end()
    at=0
    def take(value=None):
        nonlocal at
        if at>=len(ts):raise Unsupported('unexpected condition end')
        t=ts[at];at+=1
        if value is not None and t!=value:raise Unsupported('expected '+value+' got '+t)
        return t
    def operand():
        t=take()
        if t.startswith("'"):return ('literal',t[1:-1].replace("\\'","'").replace('\\\\','\\'))
        if t not in ('A','B'):raise Unsupported('unknown object '+t)
        take('.');p=take()
        if p in ('insideArea','intersectsArea'):
            take('(');a=take();take(')')
            if not a.startswith("'"):raise Unsupported('area name must be literal')
            return ('area',t,a[1:-1])
        if p not in ('NetName','NetClass','Type','Layer'):raise Unsupported('unsupported property '+p)
        return ('property',t,p)
    def term():
        if ts[at]=='!':take('!');return ('not',term())
        if ts[at]=='(':
            take('(');n=expr();take(')');return n
        left=operand()
        if at<len(ts) and ts[at] in ('==','!='):return (take(),left,operand())
        if left[0]=='area':return left
        raise Unsupported('nonboolean standalone property')
    def expr():
        left=term()
        while at<len(ts) and ts[at] in ('&&','||'):
            op=take();left=(op,left,term())
        return left
    result=expr()
    if at!=len(ts):raise Unsupported('trailing condition tokens')
    return result

def rules(path):
    result=[]
    for form in sexprs(pathlib.Path(path).read_text()):
        if form[0]=='version':
            if form!=['version','1']:raise Unsupported('rule version')
            continue
        if form[0]!='rule':raise Unsupported('top-level '+str(form[0]))
        attrs=form[2:];cons=[a for a in attrs if a[0]=='constraint' and a[1] in ('track_width','clearance')]
        if not cons:continue
        if any(a[0] not in ('condition','constraint','layer') for a in attrs):raise Unsupported(form[1]+': unsupported rule attribute')
        conds=[a for a in attrs if a[0]=='condition'];layers=[a for a in attrs if a[0]=='layer']
        if len(conds)>1 or len(layers)>1:raise Unsupported(form[1]+': duplicate condition/layer')
        ast=condition(conds[0][1] if conds else '')
        for con in cons:
            if len(con)!=3 or con[2][0]!='min' or len(con[2])!=2:raise Unsupported(form[1]+': supported constraints require exactly one min; max/opt/other fields unsupported')
            n=re.fullmatch(r'([0-9]+(?:\.[0-9]+)?)(mm|mil)',con[2][1])
            if not n:raise Unsupported(form[1]+': unsupported numeric quantity')
            result.append({'name':form[1],'kind':con[1],'value':float(n[1])*(.0254 if n[2]=='mil' else 1),'ast':ast,'layer':layers[0][1] if layers else None})
    return result

def fold(op,a,b=None):
    if op=='not':return not a if isinstance(a,bool) else ('not',a)
    if isinstance(a,bool) and isinstance(b,bool):return a and b if op=='&&' else a or b
    if op=='&&':
        if a is False or b is False:return False
        if a is True:return b
        if b is True:return a
    else:
        if a is True or b is True:return True
        if a is False:return b
        if b is False:return a
    return (op,a,b)

def scalar(n,objects):
    if isinstance(n,bool):return n
    op=n[0]
    if op=='literal':return n[1]
    if op=='property':
        o=objects[n[1]]
        if o is None:raise Unsupported('B-dependent single-item width rule')
        if n[2]=='NetClass' and ',' in o['cls']:raise Unsupported('composite NetClass equality needs native condition semantics')
        if n[2]=='Layer' and o['type']=='Pad' and len(o['layers'])>1:raise Unsupported('Layer property of multilayer pad requires native semantics')
        return o[{'NetName':'net','NetClass':'cls','Type':'type','Layer':'layer_name'}[n[2]]]
    if op=='area':return ('item_area',objects[n[1]]['id'],n[2]) if objects[n[1]] is not None else False
    if op=='not':return fold(op,scalar(n[1],objects))
    if op in ('&&','||'):return fold(op,scalar(n[1],objects),scalar(n[2],objects))
    if op in ('==','!='):
        a,b=scalar(n[1],objects),scalar(n[2],objects)
        match=fnmatch.fnmatchcase(a,b)
        return match if op=='==' else not match
    raise Unsupported(str(n))

def pd(poly,a,b):
    COUNT['polygon_segment_distance']+=1
    if old._point_in_poly(a,poly) or old._point_in_poly(b,poly):return 0.
    return old._poly_seg_dist(poly,a,b)
def overlap(p,q):
    if old._point_in_poly(p[0],q) or old._point_in_poly(q[0],p):return True
    return any(pd(q,p[i],p[(i+1)%len(p)])<=1e-10 for i in range(len(p)))
def bbox(polys):
    pts=[p for poly in polys for p in poly];return (min(p[0] for p in pts),min(p[1] for p in pts),max(p[0] for p in pts),max(p[1] for p in pts))
def separated(a,b,expand):return a[2]+expand<b[0] or b[2]+expand<a[0] or a[3]+expand<b[1] or b[3]+expand<a[1]

def load(path):
    import pcbnew
    b=pcbnew.LoadBoard(str(path));pads=[];unreadable=[];areas={};pours=[];physical=0;noncopper=0
    def polys(ps):
        out=[]
        for i in range(ps.OutlineCount()):
            if ps.HoleCount(i):raise Unsupported('polygon holes not implemented in diagnostic')
            o=ps.Outline(i);p=[(o.CPoint(j).x/1e6,o.CPoint(j).y/1e6) for j in range(o.PointCount())]
            if len(p)<3:raise Unsupported('outline has fewer than 3 vertices')
            out.append(p)
        if not out:raise Unsupported('empty polygon')
        return out
    for fp in b.GetFootprints():
        for p in fp.Pads():
            physical+=1
            if not p.IsOnCopperLayer():noncopper+=1;continue
            layers=list(p.GetLayerSet().CuStack());pos=p.GetPosition()
            rec={'id':p.m_Uuid.AsString(),'ref':fp.GetReference(),'num':p.GetNumber(),'net':p.GetNetname(),'cls':p.GetNetClassName(),'type':'Pad','layers':layers,'c':[pos.x/1e6,pos.y/1e6]}
            try:
                rec['polys']={L:polys(p.GetEffectivePolygon(L)) for L in layers}
                bb=p.GetBoundingBox();actualbb=(bb.GetX()/1e6,bb.GetY()/1e6,bb.GetRight()/1e6,bb.GetBottom()/1e6)
                rec['bbox']={L:actualbb for L in layers};rec['_native']=p
            except Exception as e:rec['why']=str(e);unreadable.append(rec);continue
            pads.append(rec)
    for z in b.Zones():
        ls=list(z.GetLayerSet().CuStack());ps=polys(z.Outline())
        if z.GetIsRuleArea():areas.setdefault(z.GetZoneName(),[]).append((ls,ps))
        else:pours.append((z.GetNetname(),ls,ps))
    vias=[];tracks=[]
    for t in b.GetTracks():
        pos=t.GetStart();e=t.GetEnd()
        rec={'id':t.m_Uuid.AsString(),'net':t.GetNetname(),'cls':t.GetNetClassName(),'type':'Track','layer':t.GetLayer(),'layer_name':b.GetLayerName(t.GetLayer()),'a':[pos.x/1e6,pos.y/1e6],'b':[e.x/1e6,e.y/1e6]}
        if t.GetClass()=='PCB_VIA':vias.append(rec)
        else:rec['width']=t.GetWidth()/1e6;tracks.append(rec)
    return b,pads,unreadable,areas,pours,vias,tracks,{'physical':physical,'copper':len(pads)+len(unreadable),'noncopper':noncopper}

class Evaluator:
    def __init__(self,b,rs,areas,pads,classes,minimum):
        self.b=b;self.rules=rs;self.areas=areas;self.pads={p['id']:p for p in pads};self.classes=classes;self.minimum=minimum;self.fixed_area={}
        self.native_areas={}
        for z in b.Zones():
            if z.GetIsRuleArea():self.native_areas.setdefault(z.GetZoneName(),[]).append(z)
        self.cmax=max([minimum,*classes.values(),*[r['value'] for r in rs if r['kind']=='clearance']])
    def onlayer(self,scope,L):
        if scope is None:return True
        name=self.b.GetLayerName(L)
        if scope=='outer':return name in ('F.Cu','B.Cu')
        if scope=='inner':return name.endswith('.Cu') and name not in ('F.Cu','B.Cu')
        return fnmatch.fnmatchcase(name,scope)
    def area_polys(self,name,L):
        names=[k for k in self.areas if fnmatch.fnmatchcase(k,name)]
        if not names:raise Unsupported('area absent or non-rule area: '+name)
        return [p for k in names for ls,ps in self.areas[k] if L in ls for p in ps]
    def native_area_hit(self,name,L,shape):
        matches=[k for k in self.native_areas if fnmatch.fnmatchcase(k,name)]
        if not matches:raise Unsupported('absent/non-rule area '+name)
        return any(z.IsOnLayer(L) and z.Outline().Collide(shape,0) for k in matches for z in self.native_areas[k])
    def geometry_partial(self,n,L):
        if isinstance(n,bool):return n
        op=n[0]
        if op=='item_area':
            ident,name=n[1:]
            if ident=='CANDIDATE':return ('area_distance',name)
            key=(ident,name,L)
            if key not in self.fixed_area:
                p=self.pads[ident]
                self.fixed_area[key]=self.native_area_hit(name,L,p['_native'].GetEffectiveShape(L))
                COUNT['fixed_obstacle_area_evaluations']+=1
            return self.fixed_area[key]
        if op=='not':return fold(op,self.geometry_partial(n[1],L))
        return fold(op,self.geometry_partial(n[1],L),self.geometry_partial(n[2],L))
    def prepare(self,candidate,obstacle=None,kind='track_width'):
        L=candidate['layer'];out=[]
        if obstacle:obstacle={**obstacle,'layer_name':self.b.GetLayerName(L)}
        for r in self.rules:
            COUNT['rule_prepare_visits']+=1
            if r['kind']!=kind or not self.onlayer(r['layer'],L):continue
            forward=scalar(r['ast'],{'A':candidate,'B':obstacle})
            node=fold('||',forward,scalar(r['ast'],{'A':obstacle,'B':candidate})) if obstacle else forward
            if node is False:continue
            node=self.geometry_partial(node,L)
            if node is not False:out.append((r['value'],r['name'],node))
        return out
    def node_value(self,n,a,b,r,L,distances):
        if isinstance(n,bool):return n
        op=n[0]
        if op=='area_distance':
            name=n[1];key=(name,round(r*2e6))
            if key not in distances:distances[key]=self.native_area_hit(name,L,self.active_shape);COUNT['candidate_area_native_checks']+=1
            return distances[key]
        if op=='not':return not self.node_value(n[1],a,b,r,L,distances)
        left=self.node_value(n[1],a,b,r,L,distances)
        return (left and self.node_value(n[2],a,b,r,L,distances)) if op=='&&' else (left or self.node_value(n[2],a,b,r,L,distances))
    def resolve(self,prepared,a,b,width,L,distances,default=None):
        for value,name,node in reversed(prepared):
            COUNT['candidate_rule_nodes']+=1
            if self.node_value(node,a,b,width/2,L,distances):return value,name
        return default,'baseline'
    def pairs(self,candidate,obstacles):
        import pcbnew
        if '_native' not in candidate:
            t=pcbnew.PCB_TRACK(self.b);t.SetLayer(candidate['layer']);t.SetNet(self.b.FindNet(candidate['net']));candidate['_native']=t
        own=candidate['_native'].GetOwnClearance(candidate['layer'])/1e6
        return [(q,self.prepare(candidate,q,'clearance'),max(self.minimum,own,q['_native'].GetOwnClearance(candidate['layer'])/1e6)) for q in obstacles]
    def validate(self,candidate,a,b,width,wr,pairs,distances=None,obdist=None):
        import pcbnew
        COUNT['candidates_validated']+=1;distances={} if distances is None else distances;obdist={} if obdist is None else obdist;L=candidate['layer']
        t=candidate['_native'];t.SetStart(pcbnew.VECTOR2I(round(a[0]*1e6),round(a[1]*1e6)));t.SetEnd(pcbnew.VECTOR2I(round(b[0]*1e6),round(b[1]*1e6)));t.SetWidth(round(width*1e6));self.active_shape=t.GetEffectiveShape()
        floor,name=self.resolve(wr,a,b,width,L,distances)
        if floor is None:return None,{'reason':'no_matching_floor'}
        if round(width*1e6)<round(floor*1e6):return False,{'reason':'track_width','floor':floor,'rule':name}
        best=float('inf');lim=None
        for q,prep,base in pairs:
            req,rul=self.resolve(prep,a,b,width,L,distances,base)
            gap=pcbnew.SHAPE.GetClearance(q['_native'].GetEffectiveShape(L),self.active_shape)/1e6;COUNT['obstacle_native_distances']+=1;margin=gap-req
            if margin<best:best=margin;lim={'ref':q['ref'],'num':q['num'],'net':q['net'],'gap':gap,'required':req,'rule':rul}
            if round(gap*1e6) < round(req*1e6):return False,{'reason':'clearance','limiter':lim}
        return True,{'floor':floor,'floor_rule':name,'minimum_margin':None if math.isinf(best) else best,'limiter':lim}

def matrix():
    result=[]
    for label in ('base','hostile'):
        path=ROOT/label/'matrix.kicad_pcb';b,pads,unread,areas,pours,vias,tracks,census=load(path);rs=rules(path.with_suffix('.kicad_dru'));cl,mn=old.read_class_clearance(path.with_suffix('.kicad_pro'));ev=Evaluator(b,rs,areas,pads,cl,mn)
        cases=json.loads((path.parent/'cases.json').read_text());native=json.loads((path.parent/'drc.json').read_text())
        assert not unread
        for case in cases:
            t=next(t for t in tracks if t['id']==case['track_uuid']);c={**t,'id':'CANDIDATE'};obs=[p for p in pads if p['net']!=t['net'] and t['layer'] in p['layers']]
            wr=ev.prepare(c);ok,detail=ev.validate(c,t['a'],t['b'],t['width'],wr,ev.pairs(c,obs));nv=[v for v in native['violations'] if any(i['uuid']==t['id'] for i in v['items'])]
            row={'label':label,'case':case['name'],'prototype_ok':ok,'detail':detail,'native':nv,'expected':case['expected_violation']};result.append(row)
            assert ok==(label=='base'),row
            assert ([v['type'] for v in nv]==[case['expected_violation']] if label=='hostile' else not nv),row
            print(label,case['name'],ok,detail)
    (ROOT/'matrix-comparison.json').write_text(json.dumps({'rows':result,'operations':COUNT},indent=2));print('MATRIX_MATCH',len(result))

def fullboard():
    path=LIVE/'projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb';t0=time.monotonic();b,pads,unread,areas,pours,vias,tracks,census=load(path);rs=rules(path.with_suffix('.kicad_dru'));cl,mn=old.read_class_clearance(path.with_suffix('.kicad_pro'));ev=Evaluator(b,rs,areas,pads,cl,mn);rows=[];s=collections.Counter();s['unreadable']=len(unread)
    for p in pads:
        row={'ref':p['ref'],'num':p['num'],'net':p['net'],'class':p['cls']};rows.append(row)
        if not p['net']:row['status']='no_net';s['no_net']+=1;continue
        prepared=[]
        for L in p['layers']:
            c={'id':'CANDIDATE','type':'Track','net':p['net'],'cls':p['cls'],'layer':L,'layer_name':b.GetLayerName(L)}
            wr=ev.prepare(c)
            if wr:prepared.append((c,wr))
        if not prepared:row['status']='no_declared_floor';s[row['status']]+=1;continue
        if any(net==p['net'] and set(ls)&set(p['layers']) and any(old._point_in_poly(p['c'],poly) for poly in ps) for net,ls,ps in pours):row['status']='nominal_pour_exclusion';s[row['status']]+=1;continue
        if any(v['net']==p['net'] and any(old._point_in_poly(v['a'],poly) for poly in p['polys'][p['layers'][0]]) for v in vias):row['status']='via_on_pad_bucket';s[row['status']]+=1;continue
        s['graded']+=1;found=False;counter0=COUNT.copy();potential=0
        for c,wr in prepared:
            L=c['layer'];widths=sorted(set(r[0] for r in wr if 0<r[0]<=old.CAP_MM));points=[]
            for poly in p['polys'][L]:points.extend(old.launch_points(poly))
            potential+=len(points)*48*len(widths)
            obs=[q for q in pads if q['net']!=p['net'] and L in q['layers'] and not separated(p['bbox'][L],q['bbox'][L],old.REACH_MM+old.CAP_MM/2+ev.cmax)]
            # Ordering affects cost only; no candidate is accepted before every pair is validated.
            obs.sort(key=lambda q:(q['c'][0]-p['c'][0])**2+(q['c'][1]-p['c'][1])**2)
            pairs=ev.pairs(c,obs)
            for a0 in points:
                a=tuple(round(x*1e6)/1e6 for x in a0)
                for k in range(48):
                    ang=2*math.pi*k/48;e=tuple(round((a[j]+old.REACH_MM*(math.cos(ang) if j==0 else math.sin(ang)))*1e6)/1e6 for j in (0,1));ds={};ods={}
                    for w in widths:
                        ok,detail=ev.validate(c,a,e,w,wr,pairs,ds,ods)
                        if ok:
                            row.update(status='VALIDATED_CONSTANT_WIDTH_WITNESS',witness={'start':a,'end':e,'width':w,'layer':c['layer_name'],'detail':detail,'candidate_obstacles':len(obs)});found=True;break
                    if found:break
                if found:break
            if found:break
        row['evaluated_candidates']=COUNT['candidates_validated']-counter0['candidates_validated'];row['potential_candidates_visited_layers']=potential
        if not found:row['status']='NO_VALIDATED_WITNESS'
        s[row['status']]+=1
        if s['graded']%50==0:print('PROGRESS',s['graded'],dict(s),round(time.monotonic()-t0,3),flush=True)
    report={'status':'DIAGNOSTIC_NOT_MAINTAINED','model':'finite declared-minimum width witnesses, no maximum/infeasibility claim','census':census,'buckets':s,'unreadable':unread,'physical_vias':len(vias),'physical_tracks':len(tracks),'rules':len(rs),'areas':len(areas),'operations':COUNT,'elapsed_seconds':time.monotonic()-t0,'rows':rows,'tolerance_mm':0,'prototype_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}
    (ROOT/'fullboard-witness.json').write_text(json.dumps(report,indent=2));print('FINAL',json.dumps({k:v for k,v in report.items() if k not in ('rows','unreadable')},indent=2));print('NO_WITNESS',[r for r in rows if r['status']=='NO_VALIDATED_WITNESS'])
if __name__=='__main__':
    if sys.argv[1]=='matrix':matrix()
    elif sys.argv[1]=='fullboard':fullboard()
