"""Private read-only exhaustive witness geometry audit; no solver rerun/save."""
import sys,pathlib,json,math,time,collections,pcbnew,hashlib
ROOT=pathlib.Path('/tmp/pland-evaluator-dback-20260910T203349Z')
LIVE=pathlib.Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
board=LIVE/'projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb'
initial=hashlib.sha256(board.read_bytes()).hexdigest();b=pcbnew.LoadBoard(str(board));allpads=[p for f in b.GetFootprints() for p in f.Pads()];pads=[p for p in allpads if p.IsOnCopperLayer()];bynum={(p.GetParentFootprint().GetReference(),p.GetNumber()):p for p in pads}
layers={b.GetLayerName(L):L for L in b.GetEnabledLayers().CuStack()}
data=json.loads((ROOT/'fullboard-witness.json').read_text());records=[];native_shapes={(p.m_Uuid.AsString(),L):p.GetEffectiveShape(L) for p in pads for L in p.GetLayerSet().CuStack()}
# Native effective own clearances independently validate the prototype's spatial ceiling.
native_own_max=max(p.GetOwnClearance(L) for p in pads for L in p.GetLayerSet().CuStack())
rule_ceiling=250000 # Independently reopened below from complete parsed native rule file.
sys.path.insert(0,str(ROOT));import witness_prototype as proto
rs=proto.rules(board.with_suffix('.kicad_dru'));rule_ceiling=max([round(r['value']*1e6) for r in rs if r['kind']=='clearance'])
global_ceiling=max(native_own_max,rule_ceiling)
allpair_checks=0;possible_limiter_checks=0;t0=time.monotonic();failures=[]
for row in data['rows']:
    if row['status']!='VALIDATED_CONSTANT_WIDTH_WITNESS':continue
    p=bynum[row['ref'],row['num']];w=row['witness'];L=layers[w['layer']];a=pcbnew.VECTOR2I(round(w['start'][0]*1e6),round(w['start'][1]*1e6));e=pcbnew.VECTOR2I(round(w['end'][0]*1e6),round(w['end'][1]*1e6))
    t=pcbnew.PCB_TRACK(b);t.SetNet(p.GetNet());t.SetLayer(L);t.SetStart(a);t.SetEnd(e);t.SetWidth(round(w['width']*1e6));shape=t.GetEffectiveShape();start_inside=native_shapes[p.m_Uuid.AsString(),L].Collide(a,0)
    if not start_inside:failures.append({'pad':row['ref']+'.'+row['num'],'reason':'start_outside_native_copper'})
    # All same-layer other-net pads are reopened, including every object discarded by the search bbox.
    near=[];min_gap=10**12
    for q in pads:
        if q.GetNetname()==p.GetNetname() or not q.IsOnLayer(L):continue
        gap=pcbnew.SHAPE.GetClearance(native_shapes[q.m_Uuid.AsString(),L],shape);allpair_checks+=1;min_gap=min(gap,min_gap)
        if gap<global_ceiling:
            possible_limiter_checks+=1
            near.append({'ref':q.GetParentFootprint().GetReference(),'num':q.GetNumber(),'gap_nm':gap})
    records.append({'pad':row['ref']+'.'+row['num'],'start_inside_native_copper':bool(start_inside),'full_capsule_reach_mm':math.hypot(e.x-a.x,e.y-a.y)/1e6,'minimum_all_pad_gap_nm':min_gap,'pairs_below_global_ceiling':near})
physical=[{'uuid':p.m_Uuid.AsString(),'ref':p.GetParentFootprint().GetReference(),'num':p.GetNumber(),'net':p.GetNetname(),'copper':p.IsOnCopperLayer(),'layers':[b.GetLayerName(L) for L in p.GetLayerSet().Seq()]} for p in allpads]
proof={'board_sha256':initial,'board_unchanged':hashlib.sha256(board.read_bytes()).hexdigest()==initial,'status':'READ_ONLY_GEOMETRY_CENSUS','witnesses':len(records),'native_own_clearance_max_nm':native_own_max,'rule_clearance_max_nm':rule_ceiling,'global_safe_clearance_ceiling_nm':global_ceiling,'all_same_layer_other_net_pair_checks':allpair_checks,'pairs_below_global_ceiling':possible_limiter_checks,'elapsed_seconds':time.monotonic()-t0,'failures':failures,'records':records,'physical_pad_census':physical,'physical_track_objects':len(list(b.GetTracks())),'baseline_was_11_vias_no_tracks':all(t.GetClass()=='PCB_VIA' for t in b.GetTracks())}
(ROOT/'exhaustive-witness-geometry-audit.json').write_text(json.dumps(proof,indent=2));print(json.dumps({k:v for k,v in proof.items() if k not in ('records','physical_pad_census')},indent=2));assert not failures;assert proof['board_unchanged'];assert len(records)==677
