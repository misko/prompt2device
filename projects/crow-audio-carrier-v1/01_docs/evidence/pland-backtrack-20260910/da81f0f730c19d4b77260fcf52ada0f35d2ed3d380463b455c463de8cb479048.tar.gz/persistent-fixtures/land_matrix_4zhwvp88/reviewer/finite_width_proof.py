"""Mathematical counterexamples, not another native coupon/maintained test."""
import json,pathlib
R=pathlib.Path('/tmp/pland-evaluator-dback-20260910T203349Z')
def between(w):
    floor=.2 if w/2>=.15 else .5
    clearance=.2;gap=.4-w/2
    return {'width':w,'floor':floor,'clearance':clearance,'gap':gap,'valid':w>=floor and gap>=clearance}
rows=[between(w) for w in [.2,.35,.5]]
assert [r['valid'] for r in rows]==[False,True,False]
def osc(w):
    c=.3 if w/2>=.16 else .1
    return {'width':w,'clearance':c,'next_fixed_point_width':2*(.4-c),'valid_at_width':.4-w/2>=c}
oscrows=[osc(.2),osc(.6)]
assert abs(oscrows[0]['next_fixed_point_width']-.6)<1e-12
assert abs(oscrows[1]['next_fixed_point_width']-.2)<1e-12
proof={'between_declared_widths':rows,'declared_set':[.2,.5],'conclusion':'valid .35 lies between declared minima; finite declared-width exhaustion is NO_VALIDATED_WITNESS, not impossibility','fixed_point_oscillation':oscrows,'global_monotonicity':'rejected','area_atom_monotonicity':'For fixed endpoints/layer, capsules K(r)=segment plus closed radius-r disk are nested. Intersecting a fixed area is monotone in r. Negation, ordered constraints, and width-dependent clearances do not preserve feasibility monotonicity.','event_partition':'With finitely many fixed polygon areas and constant numeric constraints, each atom changes at a distance threshold. On each open cell between thresholds all rule results are constant and feasibility is bounded by constant floors and pair distances. This could support a separate event solver, but exact native integer/tangency semantics and testing are additional work; no event solver is selected.'}
(R/'finite-width-proof.json').write_text(json.dumps(proof,indent=2));print(json.dumps(proof,indent=2))
