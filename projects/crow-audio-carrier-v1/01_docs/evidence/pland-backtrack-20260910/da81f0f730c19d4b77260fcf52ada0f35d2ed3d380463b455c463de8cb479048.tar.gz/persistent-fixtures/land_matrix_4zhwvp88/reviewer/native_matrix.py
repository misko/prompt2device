import pathlib,json,pcbnew,math
ROOT=pathlib.Path('/tmp/pland-evaluator-dback-20260910T203349Z')
def v(x,y):return pcbnew.VECTOR2I(round(x*1e6),round(y*1e6))
NAMES=['remote_high','b_side','reversal','both_area','offcenter','contained','padpad_guard','track_width','area_layer','last_match','boolean_left','negation','wildcard','multi_constraint','rule_layer','width_transition','oscillation','one_sided']
def build(hostile):
    label='hostile' if hostile else 'base'; folder=ROOT/label;folder.mkdir(exist_ok=True)
    b=pcbnew.BOARD(); b.SetCopperLayerCount(2)
    rules=['(version 1)','(rule "empty_baseline" (condition "") (constraint track_width (min 0.2mm)))']
    classes={'Default':.2,'Low':.2,'High':.25};patterns=[];records=[]
    def net(name,cls='Low'):
        n=pcbnew.NETINFO_ITEM(b,name);b.Add(n);patterns.append({'netclass':cls,'pattern':name});return n
    def rule(name,cond,cons,layer=None):
        rules.append('(rule '+json.dumps(name)+' '+(('(layer '+json.dumps(layer)+') ') if layer else '')+'(condition '+json.dumps(cond)+') '+cons+')')
    def area(name,x,y,rect,layer):
        z=pcbnew.ZONE(b);z.SetIsRuleArea(True);z.SetLayer(layer);z.SetZoneName(name)
        z.SetDoNotAllowTracks(False);z.SetDoNotAllowVias(False);z.SetDoNotAllowPads(False);z.SetDoNotAllowZoneFills(False)
        o=z.Outline();o.NewOutline()
        for px,py in [(rect[0],rect[1]),(rect[2],rect[1]),(rect[2],rect[3]),(rect[0],rect[3])]:o.Append(round((x+px)*1e6),round((y+py)*1e6))
        b.Add(z)
    for i,name in enumerate(NAMES):
        x=10+10*(i%6);y=10+10*(i//6);tn=f'{name}_T';bn=f'{name}_B';an=f'{name}_AREA';width=.2;layer=pcbnew.F_Cu;by=.42;baseline=.2
        if name in ('b_side','reversal','both_area','padpad_guard'):baseline=.25
        if name in ('area_layer','rule_layer'):layer=pcbnew.B_Cu
        if name in ('padpad_guard','one_sided'):by=.42 if hostile else .47
        if name=='width_transition':width=.2 if hostile else .4;by=1.3
        if name=='oscillation':width=.6 if hostile else .2;by=.5;baseline=.1
        if name in ('b_side','reversal') and hostile:bn+='_wrong'
        nt=net(tn);nb=net(bn,'High' if name=='remote_high' and hostile else 'Low')
        fp=pcbnew.FOOTPRINT(b);fp.SetReference('X'+str(i+1));fp.SetValue(name);fp.SetPosition(v(x,y));fp.SetAttributes(pcbnew.FP_SMD|pcbnew.FP_EXCLUDE_FROM_BOM|pcbnew.FP_EXCLUDE_FROM_POS_FILES)
        for number,dx,dy,n,size in [('1',0,0,nt,.16),('2',1,0,nt,.16),('3',.5,by,nb,.2)]:
            p=pcbnew.PAD(fp);p.SetNumber(number);p.SetAttribute(pcbnew.PAD_ATTRIB_SMD);p.SetShape(pcbnew.PAD_SHAPE_CIRCLE);p.SetSize(v(size,size));p.SetPosition(v(x+dx,y+dy));ls=pcbnew.LSET();ls.AddLayer(layer);p.SetLayerSet(ls);p.SetNet(n);fp.Add(p)
        if name=='remote_high':
            nr=net(name+'_REMOTE','Low' if hostile else 'High');p=pcbnew.PAD(fp);p.SetNumber('4');p.SetAttribute(pcbnew.PAD_ATTRIB_SMD);p.SetShape(pcbnew.PAD_SHAPE_CIRCLE);p.SetSize(v(.2,.2));p.SetPosition(v(x+.5,y+2));ls=pcbnew.LSET();ls.AddLayer(layer);p.SetLayerSet(ls);p.SetNet(nr);fp.Add(p)
        for a,c in [((-.5,-.6),(1.5,-.6)),((1.5,-.6),(1.5,2.5)),((1.5,2.5),(-.5,2.5)),((-.5,2.5),(-.5,-.6))]:
            sh=pcbnew.PCB_SHAPE(fp);sh.SetShape(pcbnew.SHAPE_T_SEGMENT);sh.SetLayer(pcbnew.F_CrtYd);sh.SetStart(v(x+a[0],y+a[1]));sh.SetEnd(v(x+c[0],y+c[1]));sh.SetWidth(50000);fp.Add(sh)
        b.Add(fp)
        tr=pcbnew.PCB_TRACK(b);tr.SetStart(v(x,y));tr.SetEnd(v(x+1,y));tr.SetWidth(round(width*1e6));tr.SetLayer(layer);tr.SetNet(nt);b.Add(tr)
        target=f"A.NetName == '{tn}'";track=f"A.Type == 'Track' && ({target})"
        if name!='remote_high':rule(name+'_pairbase',target,f'(constraint clearance (min {baseline}mm))')
        if name in ('b_side','reversal'):
            cond=f"B.NetName == '{name}_B'" if name=='b_side' else f"A.NetName == '{name}_B' && B.Type == 'Track'"
            rule(name+'_relax',cond,'(constraint clearance (min 0.2mm))')
        if name=='both_area':
            area(an,x,y,(-.2,-.2,1.2,.2 if hostile else .65),layer)
            rule(name+'_relax',f"A.insideArea('{an}') && B.insideArea('{an}') && ({target})",'(constraint clearance (min 0.2mm))')
        if name in ('offcenter','contained'):
            rule(name+'_wide',target,'(constraint track_width (min 0.4mm))')
            rect=(1.2,-.2,1.5,.2) if hostile else ((.3,-.2,1.3,.2) if name=='offcenter' else (-.2,-.2,1.2,.2))
            area(an,x,y,rect,layer);rule(name+'_local',f"A.insideArea('{an}') && ({target})",'(constraint track_width (min 0.2mm))')
        if name=='padpad_guard':rule(name+'_relax',f"A.Type == 'Pad' && B.Type == 'Pad' && ({target})",'(constraint clearance (min 0.15mm))')
        if name=='track_width':rule(name+'_width',track,f'(constraint track_width (min {0.3 if hostile else 0.2}mm))')
        if name=='area_layer':
            area(an,x,y,(-.2,-.2,1.2,.2),layer if hostile else pcbnew.F_Cu);rule(name+'_width',f"A.insideArea('{an}') && ({target})",'(constraint track_width (min 0.3mm))')
        if name=='last_match':
            for w in ([.2,.4] if hostile else [.4,.2]):rule(name+'_width_'+str(w),track,f'(constraint track_width (min {w}mm))')
        if name=='boolean_left':
            cond=f"{target} || (A.NetName == 'NEVER' && A.Type == 'Pad')" if hostile else f"{target} || A.NetName == 'NEVER' && A.Type == 'Pad'"
            rule(name+'_width',cond,'(constraint track_width (min 0.4mm))')
        if name in ('negation','wildcard'):
            rule(name+'_wide',target,'(constraint track_width (min 0.4mm))')
            cond=f"!(A.NetName != '{'WRONG' if hostile else tn}')" if name=='negation' else f"A.NetName == '{'WRONG*' if hostile else 'wildcard_*'}'"
            rule(name+'_local',cond,'(constraint track_width (min 0.2mm))')
        if name=='multi_constraint':rule(name+'_both',target,f'(constraint clearance (min 0.2mm)) (constraint track_width (min {0.3 if hostile else .2}mm))')
        if name=='rule_layer':rule(name+'_width',track,'(constraint track_width (min 0.4mm))','B.Cu' if hostile else 'F.Cu')
        if name=='width_transition':
            rule(name+'_wide',target,'(constraint track_width (min 0.6mm))');area(an,x,y,(-.3,.15,1.3,.3),layer)
            rule(name+'_local',f"A.insideArea('{an}') && ({target})",'(constraint track_width (min 0.2mm))')
        if name=='oscillation':
            area(an,x,y,(-.4,.16,1.4,.35),layer);rule(name+'_inside',f"A.Type == 'Track' && A.insideArea('{an}') && ({target})",'(constraint clearance (min 0.3mm))')
        if name=='one_sided':rule(name+'_custom',target,'(constraint clearance (min 0.25mm))')
        records.append({'name':name,'ref':fp.GetReference(),'net':tn,'obstacle_net':bn,'width':width,'layer':b.GetLayerName(layer),'start':[x,y],'end':[x+1,y],'obstacle':[x+.5,y+by],'track_uuid':tr.m_Uuid.AsString(),'expected_violation': None if not hostile else ('track_width' if name in ['offcenter','contained','track_width','area_layer','last_match','boolean_left','negation','wildcard','multi_constraint','rule_layer','width_transition'] else 'clearance')})
    for a,c in [((5,5),(70,5)),((70,5),(70,40)),((70,40),(5,40)),((5,40),(5,5))]:
        sh=pcbnew.PCB_SHAPE(b);sh.SetShape(pcbnew.SHAPE_T_SEGMENT);sh.SetLayer(pcbnew.Edge_Cuts);sh.SetStart(v(*a));sh.SetEnd(v(*c));sh.SetWidth(50000);b.Add(sh)
    path=folder/'matrix.kicad_pcb';pcbnew.SaveBoard(str(path),b)
    pro={'board':{'design_settings':{'rules':{'min_clearance':.1,'min_track_width':.1},'drc_exclusions':[]}},'net_settings':{'classes':[{'name':k,'clearance':c,'track_width':.2,'via_diameter':.6,'via_drill':.3} for k,c in classes.items()],'netclass_patterns':patterns},'meta':{'filename':'matrix.kicad_pro','version':1}}
    path.with_suffix('.kicad_pro').write_text(json.dumps(pro,indent=2));path.with_suffix('.kicad_dru').write_text('\n'.join(rules)+'\n');(folder/'cases.json').write_text(json.dumps(records,indent=2));print(label,len(records),'stations',path)
if __name__=='__main__':build(False);build(True)
