import sys, subprocess, time, json, datetime, pathlib, os, signal
root=pathlib.Path('/tmp/pland-evaluator-dback-20260910T203349Z')
def run(name, argv, cwd='/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901', timeout=120):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
    meta={'argv':argv,'cwd':cwd,'start':start,'timeout_seconds':timeout}
    (root/(name+'.start.json')).write_text(json.dumps(meta,indent=2)+'\n')
    with (root/(name+'.log')).open('wb') as out:
        p=subprocess.Popen(argv,cwd=cwd,stdout=out,stderr=subprocess.STDOUT,start_new_session=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        meta['pid']=p.pid
        try: rc=p.wait(timeout=timeout); meta['terminated']=False
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGTERM)
            try: p.wait(timeout=3)
            except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGKILL);p.wait()
            rc=p.returncode;meta['terminated']=True
    meta.update(rc=rc,duration_seconds=time.monotonic()-t,end=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (root/(name+'.result.json')).write_text(json.dumps(meta,indent=2)+'\n')
    print(json.dumps(meta));print((root/(name+'.log')).read_text())
    return rc
if __name__=='__main__':run(sys.argv[1],sys.argv[2:])
