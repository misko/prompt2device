#!/usr/bin/env python3
"""Native KiCad pad-launch kernel; library only, never a public gate verdict.

It owns board loading, preserved pcbnew pad/shape lifetimes and the deliberately
small supported .kicad_dru rule language.  Candidate geometry is always native
``PCB_TRACK.GetEffectiveShape`` versus native pad shapes; polygon data is never
used as the final clearance oracle.  Zones/vias/fill/simultaneous launches are
outside this one-pad/other-pad library and are named exclusions.
"""
from __future__ import annotations
from dataclasses import dataclass
import fnmatch, json, pathlib, re

NO_VALIDATED_WITNESS='NO_VALIDATED_WITNESS'
class UnsupportedCoverage(ValueError):
 def __init__(self,code,detail):self.code=code;self.detail=detail;super().__init__(code+': '+detail)
@dataclass
class Pad:
 ref:str; num:str; net:str; netclass:str; layers:tuple; native:object
@dataclass
class Rule: name:str; kind:str; minimum_iu:int; ast:object; layer:str|None
@dataclass
class Candidate: source_ref:str;source_number:str;start_iu:tuple;end_iu:tuple;width_iu:int;layer:int;width_rule:str
@dataclass
class Witness: candidate:Candidate;limiter:dict|None

def _sexpr(s):
 t=[];i=0
 while i<len(s):
  if s[i].isspace():i+=1;continue
  if s[i]=='#':i=s.find('\n',i);i=len(s) if i<0 else i;continue
  if s[i] in '()':t.append(s[i]);i+=1;continue
  if s[i]=='"':
   j=i+1
   while j<len(s) and s[j]!='"':j+=2 if s[j]=='\\' else 1
   if j==len(s):raise UnsupportedCoverage('MALFORMED_DRU','unterminated string')
   t.append(json.loads(s[i:j+1]));i=j+1;continue
  j=i
  while j<len(s) and not s[j].isspace() and s[j] not in '()':j+=1
  t.append(s[i:j]);i=j
 st=[[]]
 for x in t:
  if x=='(':st.append([])
  elif x==')':
   if len(st)==1:raise UnsupportedCoverage('MALFORMED_DRU','unbalanced )')
   st[-2].append(st.pop())
  else:st[-1].append(x)
 if len(st)!=1:raise UnsupportedCoverage('MALFORMED_DRU','unbalanced (')
 return st[0]
_lex=re.compile(r"\s*(?:(?P<s>'(?:\\.|[^'\\])*')|(?P<o>\&\&|\|\||==|!=|!|\(|\)|\.)|(?P<w>[A-Za-z_][A-Za-z0-9_]*))")
def compile_condition(s):
 ts=[];p=0
 while p<len(s):
  if not s[p:].strip():break
  m=_lex.match(s,p)
  if not m:raise UnsupportedCoverage('UNSUPPORTED_CONDITION',s[p:])
  ts.append(m.group(m.lastgroup));p=m.end()
 at=0
 def take(w=None):
  nonlocal at
  if at>=len(ts):raise UnsupportedCoverage('MALFORMED_CONDITION','end')
  x=ts[at];at+=1
  if w and x!=w:raise UnsupportedCoverage('MALFORMED_CONDITION',x)
  return x
 def term():
  if at<len(ts) and ts[at]=='!':take('!');return('!',term())
  if at<len(ts) and ts[at]=='(':take('(');n=expr();take(')');return n
  side=take();take('.');attr=take()
  if side not in ('A','B') or attr not in ('Type','NetName','NetClass','Layer'):raise UnsupportedCoverage('UNSUPPORTED_ATTRIBUTE',side+'.'+attr)
  op=take();v=take()
  if op not in ('==','!=') or not v.startswith("'"):raise UnsupportedCoverage('UNSUPPORTED_CONDITION',str((op,v)))
  if '\\' in v:raise UnsupportedCoverage('UNSUPPORTED_ESCAPE',v)
  return('cmp',side,attr,op,v[1:-1])
 def expr():
  n=term()
  while at<len(ts) and ts[at] in ('&&','||'):n=(take(),n,term())
  return n
 if not ts:return True
 n=expr()
 if at!=len(ts):raise UnsupportedCoverage('MALFORMED_CONDITION','trailing')
 return n
def _b(n):return n[1]=='B' if isinstance(n,tuple) and n[0]=='cmp' else isinstance(n,tuple) and any(_b(x) for x in n[1:] if isinstance(x,tuple))
def _layer_ref(n):return isinstance(n,tuple) and ((n[0]=='cmp' and n[2]=='Layer') or any(_layer_ref(x) for x in n[1:] if isinstance(x,tuple)))
def _eval(n,a,b,layer):
 if n is True:return True
 if n[0]=='!':return not _eval(n[1],a,b,layer)
 if n[0]=='&&':return _eval(n[1],a,b,layer) and _eval(n[2],a,b,layer)
 if n[0]=='||':return _eval(n[1],a,b,layer) or _eval(n[2],a,b,layer)
 _,side,attr,op,w=n;x=a if side=='A' else b
 if x is None:raise UnsupportedCoverage('B_DEPENDENT_WIDTH','B referenced by width rule')
 track=isinstance(x,tuple) and x[0]=='TRACK'; item=x[1] if track else x
 val={'Type':'Track' if track else 'Pad','NetName':item.net,'NetClass':item.netclass,'Layer':layer}[attr]
 if attr=='NetClass' and val and ',' in val:raise UnsupportedCoverage('UNSUPPORTED_COMPOUND_NETCLASS',val)
 yes=fnmatch.fnmatchcase(val,w) if val is not None else False
 return yes if op=='==' else not yes
def read_rules(path):
 out=[]
 for f in _sexpr(pathlib.Path(path).read_text()):
  if f[0]=='version':continue
  if f[0]!='rule' or len(f)<2:raise UnsupportedCoverage('MALFORMED_DRU',str(f[:1]))
  attrs=f[2:];bad=[x[0] for x in attrs if not isinstance(x,list) or x[0] not in ('condition','constraint','layer')]
  if bad:raise UnsupportedCoverage('UNSUPPORTED_RULE_ATTRIBUTE',bad[0])
  cs=[x for x in attrs if x[0]=='condition'];ls=[x for x in attrs if x[0]=='layer']
  if len(cs)>1 or len(ls)>1:raise UnsupportedCoverage('MALFORMED_DRU',f[1])
  ast=compile_condition(cs[0][1] if cs else '')
  for c in [x for x in attrs if x[0]=='constraint']:
   if c[1] not in ('track_width','clearance'):continue # unrelated constraints are inventoried outside launch scope
   if len(c)!=3 or not isinstance(c[2],list) or c[2][0]!='min' or len(c[2])!=2:raise UnsupportedCoverage('UNSUPPORTED_CONSTRAINT',f[1]+': '+str(c[1]))
   m=re.fullmatch(r'([0-9]+(?:\.[0-9]+)?)(mm|mil)',c[2][1])
   if not m:raise UnsupportedCoverage('UNSUPPORTED_QUANTITY',str(c[2][1]))
   out.append(Rule(f[1],c[1],round(float(m[1])*(1e6 if m[2]=='mm' else 25400)),ast,ls[0][1] if ls else None))
 return tuple(out)
class NativeKernel:
 def __init__(self,board_path):
  import pcbnew
  self.board=pcbnew.LoadBoard(str(board_path));self.layers={self.board.GetLayerName(i):i for i in range(pcbnew.PCB_LAYER_ID_COUNT)};self.pads=[];self.physical_pads=0;self.noncopper_pads=[];self.unreadable_pads=[]
  pro=pathlib.Path(board_path).with_suffix('.kicad_pro')
  try:
   data=json.loads(pro.read_text()); settings=data['board']['design_settings']['rules'];self.board_minimum_iu=round(float(settings['min_clearance'])*1e6)
   self.class_clearance={x['name']:round(float(x['clearance'])*1e6) for x in data['net_settings']['classes']}
  except Exception as e:raise UnsupportedCoverage('UNREADABLE_PROJECT_RULES',str(e))
  for fp in self.board.GetFootprints():
   for p in fp.Pads():
    self.physical_pads+=1
    if not p.IsOnCopperLayer():self.noncopper_pads.append((fp.GetReference(),p.GetNumber()));continue
    layers=tuple(p.GetLayerSet().CuStack())
    try:
     for L in layers:p.GetEffectiveShape(L)
     self.pads.append(Pad(fp.GetReference(),p.GetNumber(),p.GetNetname(),p.GetNetClassName(),layers,p))
    except Exception as e:self.unreadable_pads.append((fp.GetReference(),p.GetNumber(),str(e)))
 def validate(self,source,start_iu,end_iu,width_iu,layer_name,width_rules,clearance_rules,board_minimum_iu):
  import pcbnew
  L=self.layers[layer_name]
  if L not in source.layers:raise UnsupportedCoverage('UNSUPPORTED_PAD_LAYER',source.ref+'.'+source.num)
  # GetOwnClearance is a singleton rule result, never a pair oracle.  A local
  # override whose precedence cannot be resolved from the public pcbnew API is
  # a fail-closed named block, rather than an invented global clamp.
  if source.native.GetOwnClearance(L) > board_minimum_iu:
   raise UnsupportedCoverage('UNSUPPORTED_LOCAL_CLEARANCE_PRECEDENCE',source.ref+'.'+source.num)
  widths=[r for r in width_rules if r.layer in (None,layer_name)]
  if len(source.layers)>1 and any(_layer_ref(r.ast) for r in widths):
   raise UnsupportedCoverage('UNSUPPORTED_MULTILAYER_PAD_LAYER',source.ref+'.'+source.num)
  if any(_b(r.ast) for r in widths):raise UnsupportedCoverage('B_DEPENDENT_WIDTH','width rule')
  trial=('TRACK',source)
  chosen=[r for r in widths if _eval(r.ast,trial,None,layer_name)]
  if not chosen:raise UnsupportedCoverage('MISSING_WIDTH_RULE',source.ref+'.'+source.num)
  wr=chosen[-1]
  if width_iu<wr.minimum_iu:return None
  t=pcbnew.PCB_TRACK(self.board);t.SetNet(source.native.GetNet());t.SetLayer(L);t.SetStart(pcbnew.VECTOR2I(*start_iu));t.SetEnd(pcbnew.VECTOR2I(*end_iu));t.SetWidth(width_iu);shape=t.GetEffectiveShape()
  if not source.native.GetEffectiveShape(L).Collide(pcbnew.VECTOR2I(*start_iu),0):raise UnsupportedCoverage('NATIVE_START_OUTSIDE_PAD',source.ref+'.'+source.num)
  limiter=None
  for q in self.pads:
   if q.net==source.net or L not in q.layers:continue
   rs=[r for r in clearance_rules if r.layer in (None,layer_name) and (_eval(r.ast,trial,q,layer_name) or _eval(r.ast,q,trial,layer_name))]
   r=rs[-1] if rs else None
   # The .pro class scalars are authoritative baseline input; GetOwnClearance
   # remains only a singleton diagnostic and is never used as pair resolution.
   req=r.minimum_iu if r else max(board_minimum_iu,self.class_clearance.get(source.netclass,0),self.class_clearance.get(q.netclass,0))
   gap=pcbnew.SHAPE.GetClearance(q.native.GetEffectiveShape(L),shape);margin=gap-req
   if limiter is None or margin<limiter['margin_iu']:limiter={'other_ref':q.ref,'other_number':q.num,'rule':r.name if r else 'board-minimum','gap_iu':gap,'required_iu':req,'margin_iu':margin}
   if gap<req:return None
  return Witness(Candidate(source.ref,source.num,start_iu,end_iu,width_iu,L,wr.name),limiter)
 def search(self,source,points_iu,directions,widths,layer_name,width_rules,clearance_rules,board_minimum_iu):
  """Finite declared-width trials: no hit means unresolved, never impossible."""
  pts=tuple(points_iu);dirs=tuple(directions);ws=tuple(widths)
  if len(pts)>37:raise UnsupportedCoverage('SAMPLE_CAP_EXCEEDED',str(len(pts)))
  if len(dirs)>48:raise UnsupportedCoverage('DIRECTION_CAP_EXCEEDED',str(len(dirs)))
  hits=[]
  for a in pts:
   for dx,dy in dirs:
    for w in ws:
     hit=self.validate(source,a,(a[0]+dx,a[1]+dy),w,layer_name,width_rules,clearance_rules,board_minimum_iu)
     if hit is not None:hits.append(hit)
  return ('VALIDATED_CONSTANT_WIDTH_WITNESS',tuple(hits)) if hits else (NO_VALIDATED_WITNESS,())
