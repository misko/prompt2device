# Fresh native kernel authoring

agent-role: authoring
context_mode: FRESH
source_commit: 3cfbc0556e04ce4e652d7aefc007ee5c8e3fad96
repository: /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901
private_output_root: /tmp/pland-native-kernel-20260910T223440Z
sole_live_writer: /root/carrier_pland_native_kernel_author
root_coordinator: READ_ONLY after dispatch until complete handback

Verify strict envelope SHA, ALL input members and aggregate before any source
write. Read CLAUDE.md, copied flow/beacon/latest journal, pcb-design lifecycle /
compute tiers, tests/README.md and P-LAND canon/script contract. Then read
01_docs/evidence/pland-backtrack-20260910/native-kernel-plan.md IN FULL: it is the
exact adopted scope, seven guards, validation entry and caps. Read native-complete-
classes-adoption.md and evaluator-adoption.md for source authority and limitations.
This task follows upstream decomposition, not another attempt at the exhausted
whole-checker author. No conversation or prior agent context is supplied.

Before frozen edits verify all483 original regular preimages in
06_build/archives/pland-source-preimage-20260910T200208Z from preimage-manifest.json,
including470 frozen inputs; they were copied and reopened from Git127f13d69.
Safe private extraction of archive files must reject links/traversal/duplicates
and verify every member SHA/size. Complete-class fixture source archive3aa78234c2007b00d366a4af041ae7725bb0379682f07dd1d186d62703abe6b9
has native-complete-classes-manifest.json. Its executed specimen and complete
outputs are in96f680152d8f1edd66b485c54fb31da033edb15aa52e0858a861d3cd47228859.tar.gz,
with native-complete-classes-attempt-manifest.json. All4 census5/2/3; public0tracks,
oracle1track. Use copies inside your private tree. Sparse class defect is retained
in e43378bb archive/native-owned-output-attempt-manifest.json. Prototype/matrix
archive887c61662cbdc291a68c03bdbfb4569d5c93eb830989f31393338c14a128b3db uses evaluator-manifest.json
(or the exact manifest filename named by evaluator-adoption/contracts; inspect it).
Prototype is diagnostic, NOT production authority. Full original evaluator
report is evaluator-result.md; read its mandatory guard rows, not merely numbers.
Official10.0.4 source files (drc_engine.cpp, pad.cpp, board_connected_item.cpp)
are preserved in54425eabb555ce98d481454683edcdac086efcaf4c6b076c3c34e13be713cfb0.tar.gz,
with fixture-dback-manifest.json. No need to fetch or guess new APIs.

Allowed live implementation: skills/kicad-pcb/scripts/land_witness.py (new),
skills/kicad-pcb/scripts/contracts.md (library home), tests/t1_land_witness.py
(new), tests/README.md (suite description). Administrative permission:
01_docs/STATUS.md, 01_docs/journal/placement.md,06_build/agent_handoff.yaml and
06_build/verification/pland-native-kernel-20260910T223440Z-result.md. No other live paths without explicit root
scope decision. In particular escape_check.py SHAcb0d0cf6cb593b5f231fa372920e7dc6adf10bce95c0d734fac0900d3fd3ddf3
and t1_escape_tier.py SHA424d6dd38567c99fb5ee457f01e1f2b0b071bed48c4b92d4a49b02e04816856c
must remain exact throughout. All native/source/checkpoint/model/review/routing/
release and original evidence bytes READ_ONLY. Do not commit or regenerate.

ENTRY validation: on copies of exact complete-class oracle board/pro/dru, run
native base andhostile with --severity-all --all-track-errors and preserve every
finding. Exactbase0/0,hostile2 Track-to-X1.3/X1.4 clearance/0opens remain mandatory.
No parity exists. This corrects the upstream native reporting command contract;
it is NOT another frozen-interface execution. Do not rerun execute.py. If entry
fails unexpectedly, report full evidence and stop before production creation.
Then implement and validate library per native-kernel-plan.md. Source semantics
come from native independent fixtures, not a missing new API RED; old public
behavioral RED/Green and full t1_escape_tier are a later boundary, not this one.
Do not claim public production repair or placement acceptance.

One bounded standard authoring task, max3consecutive nonimproving implementation
iterations, no automatic extension/replacement,35minute hard deadline in envelope,
final120seconds reserved closure. NativeDRC60s each, new suite300s max, contracts120s;
all process-group bounded by task remaining time. Keep each actual command's full
stdout/stderr/start/argv/PID/rc/duration and exact source hashes to private files.
Do not let harness tail truncation discard native reports/child output. Failed
or killed runs remain in complete history. Report verified launch promptly and
meaningful progress<=60s. No unrelated whole-repo suites or liveboard nativeDRC.

Finish with full result.md and exact designated06 verification copy, patchSHA /
changed paths, native categories/denominators, each guard supported/rejected /
unresolved, final suite outcomes and source identities, complete input mutation
inventory, preimage verification and process closure. Refresh actual STATUS /
placement journal, generate AND validate compact pcb_flow handoff naming old
public integration and stale-checkpoint canonical restart still owed. Preserve
full actual logs. Write report/audits before output manifest last. Stop all
processes/writes before handback. Root adopts/reviews/commits or rejects.

Aggregate formula: pipeline_identity.subject_identity('crow_pland_native_kernel',1,
[TypedIdentityInput('packet','sequence',input_packet,json.dumps(input_packet,sort_keys=True).encode())]).
