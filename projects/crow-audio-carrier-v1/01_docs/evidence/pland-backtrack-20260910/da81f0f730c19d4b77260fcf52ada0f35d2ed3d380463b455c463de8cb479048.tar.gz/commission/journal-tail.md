## 2026-09-10T22:31:58.031940+00:00 — counterexample measured; upstream native reporting contract reopened

- MEASURED: all4nativecensuses5/2/3 and exactclasses; botholdpublic X1.1 failures
  floor0.2/landable0.12 at0.25. Nativebase0physical/0opens; hostile1clearance/0opens,
  candidateTrack–X1.3 actual0.21 required0.25. Producer exact2assertion failedrc1.
- MEASURED:661inputs unchanged,51output rows complete,7PIDs absent,63archive
  members independently rehashed in96f68015. Full worker report7bd01c34 preserved.
- ADOPTED only native schema/interface and geometric counterexample. No full
  runneradmission, maintainedtest, secondhostilepair or productionrepair claim.
- D-BACK one stage upstream to native validation-command contract: installedhelp
  and official10.0.4provider show --all-track-errors is separate fromseverity-all.
  Thirdinterfaceexecution closed; no fourthlocalarrival. Separate kernel suite
  must retain exact2pairassertion and explicitlyrequest complete track reports.
- Next fresh standard authoring of reusable land_witness library/nativecontrols
  under native-kernel-plan.md; currentpublicchecker/tests stayexact. All prior
  caps/history, seven guards, canonical restart and later release holds retained.

- MEASURED: contracts17/17PASS13known-bad rc0/4.428944s; handoff
  rc0/1.166782s andvalidate rc0/1.268100s ended22:32:27Z. Full records
  in native-kernel-plan.md; no kernel/public source acceptance yet.
