from pathlib import Path
from datetime import datetime,timezone,timedelta
import hashlib,json,shutil,subprocess,sys
r=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');p=r/'projects/crow-audio-carrier-v1'
now=datetime.now(timezone.utc).replace(microsecond=0);rid='pland-native-kernel-'+now.strftime('%Y%m%dT%H%M%SZ');d=p/'06_build/handoffs'/rid;d.mkdir(parents=True);private=Path('/tmp')/rid;private.mkdir()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
for src,dst in [('06_build/agent_handoff.yaml','flow.yaml'),('01_docs/STATUS.md','beacon.md')]:shutil.copy2(p/src,d/dst)
j=(p/'01_docs/journal/placement.md').read_text();(d/'journal-tail.md').write_text('## '+j.rsplit('\n## ',1)[1])
(d/'TASK.md').write_text(f'''# Fresh native kernel authoring

agent-role: authoring
context_mode: FRESH
source_commit: {head}
repository: {r}
private_output_root: {private}
sole_live_writer: /root/carrier_pland_native_kernel_author
root_coordinator: READ_ONLY after dispatch until complete handback

Verify strict envelope SHA, ALL input members and aggregate before any source
write. Read CLAUDE.md, copied flow/beacon/latest journal, pcb-design lifecycle /
compute tiers, tests/README.md and P-LAND canon/script contract. Then read
01_docs/evidence/pland-backtrack-20260910/native-kernel-plan.md IN FULL: it is the
exact adopted scope, seven guards, validation entry and caps. Read native-complete-
classes-adoption.md and evaluator-adoption.md for source authority and limitations.
This task follows upstream decomposition, not another attempt at the exhausted
whole-checker author. No conversation or prior agent context is supplied.

Before frozen edits verify all483 original regular preimages in
06_build/archives/pland-source-preimage-20260910T200208Z from preimage-manifest.json,
including470 frozen inputs; they were copied and reopened from Git127f13d69.
Safe private extraction of archive files must reject links/traversal/duplicates
and verify every member SHA/size. Complete-class fixture source archive3aa78234c2007b00d366a4af041ae7725bb0379682f07dd1d186d62703abe6b9
has native-complete-classes-manifest.json. Its executed specimen and complete
outputs are in96f680152d8f1edd66b485c54fb31da033edb15aa52e0858a861d3cd47228859.tar.gz,
with native-complete-classes-attempt-manifest.json. All4 census5/2/3; public0tracks,
oracle1track. Use copies inside your private tree. Sparse class defect is retained
in e43378bb archive/native-owned-output-attempt-manifest.json. Prototype/matrix
archive887c61662cbdc291a68c03bdbfb4569d5c93eb830989f31393338c14a128b3db uses evaluator-manifest.json
(or the exact manifest filename named by evaluator-adoption/contracts; inspect it).
Prototype is diagnostic, NOT production authority. Full original evaluator
report is evaluator-result.md; read its mandatory guard rows, not merely numbers.
Official10.0.4 source files (drc_engine.cpp, pad.cpp, board_connected_item.cpp)
are preserved in54425eabb555ce98d481454683edcdac086efcaf4c6b076c3c34e13be713cfb0.tar.gz,
with fixture-dback-manifest.json. No need to fetch or guess new APIs.

Allowed live implementation: skills/kicad-pcb/scripts/land_witness.py (new),
skills/kicad-pcb/scripts/contracts.md (library home), tests/t1_land_witness.py
(new), tests/README.md (suite description). Administrative permission:
01_docs/STATUS.md, 01_docs/journal/placement.md,06_build/agent_handoff.yaml and
06_build/verification/{rid}-result.md. No other live paths without explicit root
scope decision. In particular escape_check.py SHAcb0d0cf6cb593b5f231fa372920e7dc6adf10bce95c0d734fac0900d3fd3ddf3
and t1_escape_tier.py SHA424d6dd38567c99fb5ee457f01e1f2b0b071bed48c4b92d4a49b02e04816856c
must remain exact throughout. All native/source/checkpoint/model/review/routing/
release and original evidence bytes READ_ONLY. Do not commit or regenerate.

ENTRY validation: on copies of exact complete-class oracle board/pro/dru, run
native base andhostile with --severity-all --all-track-errors and preserve every
finding. Exactbase0/0,hostile2 Track-to-X1.3/X1.4 clearance/0opens remain mandatory.
No parity exists. This corrects the upstream native reporting command contract;
it is NOT another frozen-interface execution. Do not rerun execute.py. If entry
fails unexpectedly, report full evidence and stop before production creation.
Then implement and validate library per native-kernel-plan.md. Source semantics
come from native independent fixtures, not a missing new API RED; old public
behavioral RED/Green and full t1_escape_tier are a later boundary, not this one.
Do not claim public production repair or placement acceptance.

One bounded standard authoring task, max3consecutive nonimproving implementation
iterations, no automatic extension/replacement,35minute hard deadline in envelope,
final120seconds reserved closure. NativeDRC60s each, new suite300s max, contracts120s;
all process-group bounded by task remaining time. Keep each actual command's full
stdout/stderr/start/argv/PID/rc/duration and exact source hashes to private files.
Do not let harness tail truncation discard native reports/child output. Failed
or killed runs remain in complete history. Report verified launch promptly and
meaningful progress<=60s. No unrelated whole-repo suites or liveboard nativeDRC.

Finish with full result.md and exact designated06 verification copy, patchSHA /
changed paths, native categories/denominators, each guard supported/rejected /
unresolved, final suite outcomes and source identities, complete input mutation
inventory, preimage verification and process closure. Refresh actual STATUS /
placement journal, generate AND validate compact pcb_flow handoff naming old
public integration and stale-checkpoint canonical restart still owed. Preserve
full actual logs. Write report/audits before output manifest last. Stop all
processes/writes before handback. Root adopts/reviews/commits or rejects.

Aggregate formula: pipeline_identity.subject_identity('crow_pland_native_kernel',1,
[TypedIdentityInput('packet','sequence',input_packet,json.dumps(input_packet,sort_keys=True).encode())]).
''')
old=json.loads((p/'06_build/handoffs/pland-native-complete-classes-20260910T222644Z/task-envelope.json').read_text());paths={r/x['path'] for x in old['input_packet'] if '/06_build/handoffs/' not in x['path']};paths.update(q for q in (p/'01_docs/evidence/pland-backtrack-20260910').rglob('*') if q.is_file());paths.update(d.iterdir());items=[]
for i,q in enumerate(sorted(paths)):
 assert q.is_file() and not q.is_symlink();b=q.read_bytes();items.append(dict(name=f'artifact_{i:04}',path=q.relative_to(r).as_posix(),sha256=hashlib.sha256(b).hexdigest(),size=len(b)))
sys.path.insert(0,str(r/'skills/pcb-design/scripts'));from pipeline_identity import TypedIdentityInput,subject_identity;from pipeline_execution import TaskEnvelope,verify_input_packet
subject=subject_identity('crow_pland_native_kernel',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
writepaths=['skills/kicad-pcb/scripts/land_witness.py','skills/kicad-pcb/scripts/contracts.md','tests/t1_land_witness.py','tests/README.md']+[str((p/q).relative_to(r)) for q in ['01_docs/STATUS.md','01_docs/journal/placement.md','06_build/agent_handoff.yaml',f'06_build/verification/{rid}-result.md']]
env=TaskEnvelope.from_mapping(dict(schema=1,task_id=rid,stage_id='KICAD-PLACEMENT',run_id=rid,subject=subject.to_mapping(),executor='agent',execution_class='local',recommended_agent_role='authoring',agent_role='authoring',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=rid,input_packet=items,deadline_at=(now+timedelta(minutes=35)).isoformat().replace('+00:00','Z'),max_nonimproving_attempts=3,replacement_limit=0,writer_scope=dict(mode='EXCLUSIVE',paths=writepaths),output_path=str((p/'06_build/verification'/f'{rid}-result.md').relative_to(r))))
assert verify_input_packet(env,r)==(True,[]);(d/'task-envelope.json').write_text(env.to_json()+'\n');out=dict(packet=str(d),private=str(private),source_commit=head,members=len(items),envelope_sha256=hashlib.sha256((d/'task-envelope.json').read_bytes()).hexdigest(),deadline=env.deadline_at)
(Path(__file__).parent/'kernel-launch.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
