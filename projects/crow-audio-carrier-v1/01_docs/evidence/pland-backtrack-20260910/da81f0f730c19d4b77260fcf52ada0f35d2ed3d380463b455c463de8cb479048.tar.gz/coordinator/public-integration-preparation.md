# Read-only preparation for the later public integration boundary

Prepared by root while the separate native-kernel author owns the live tree.
NOT an adopted commission or permission to edit; wait for complete kernel review.
Original escape checker SHA cb0d0cf6cb593b5f231fa372920e7dc6adf10bce95c0d734fac0900d3fd3ddf3,
original t1_escape_tier SHA424d6dd38567c99fb5ee457f01e1f2b0b071bed48c4b92d4a49b02e04816856c.

## Behavioral RED entry

Use exact admitted complete-class five-pad base/hostile geometry through the
maintained public CLI. Native base specified0.2mm track is already0physical/
0opens; native hostile two0.21-vs0.25 clearance pairs are required in the new
kernel suite. The old CLI already demonstrably fails base X1.1 at floor0.2,
landable0.12 with2graded/5copper/3floorless and exactly1 failing. Write the new
maintained property to require base CLI success at this nonzero denominator,
then run it with original cb0d0cf6 BEFORE public integration. Its failure must
be the named geometric rejection, not a missing helper or output vocabulary.
The old CLI's normal rc1 is evidence only when the new test expects the native-
accepted result and actually fails. Preserve all child output to durable private
logs. Restore pre-fix source only transactionally if it was already changed.
After integration, the SAME test must pass on final source; contrast hostile
search must still block the constrained central pad. Native specified-track
controls and public free-search controls prove different facts.

## Compatibility and scope

Keep D-ESC/package methods and command behavior byte/semantically unchanged.
P-LAND main CLI flags --board repeatable, --project, --dru, --dirs, --reach,
--verbose are existing public seams. Missing board, bad/missing project/rule,
invalid limits, unsupported rules/shapes must produce named nonzero findings,
not traceback or vacuous pass. Check every explicit input's native meaning:
LoadBoard reads stem project; a different --project must not silently mix new
clearances with old netclass assignments. Either preserve a tested coherent
contract or explicitly reject unsupported mismatched project identity.

Public check_board currently returns(lines,stats,inputs). Only its local CLI
calls it; no external maintained callers found. tests' UNREACHED seam injects
read_board returning six legacy lists. That test should migrate to the actual
new load/shape seam and still name/count exactly one unreadable copper pad.
Do not keep the old first-layer-only geometry reader merely to satisfy an
injected implementation seam. Actual landing points remain original grid.

Output rows should name VALIDATED_CONSTANT_WIDTH_WITNESS or NO_VALIDATED_WITNESS,
actual selected constant width and start/end/layer, applied width rule and
limiting pair/gap/required/margin. Failure is finite-search unresolved, not a
maximum/deficit/impossibility claim. Deletion of MODEL-REFUTED requires replacing
its actual >100 graded-pad track-presence coverage with a truthful inventory or
separately validated existing-track check; a finite witness is not an upper
bound on existing copper. Do not report every row's selected limiter as the
clearance for unrelated obstacles. Current denominator fields can be preserved
where honest, but nominal zone and via bucket wording must state scope rather
than actual filled contact. Add physical/noncopper/via/track inventory and all
unsupported items; sum all mutually exclusive copper buckets back to copper.

## Existing maintained corpus to preserve

CAL_ELEVEN exact identities/floors:
U_SW1.5/U_SW2.5 .360; U_MCU46/47 .330;
U_MCU10/22/26/33/23/45/50 .400.
Historical .25/.30 maximum numbers stay historical evidence only, not new
witness output assertions. Stripping scoped rules must name those eleven
failures (or diagnose any actual changed identity before changing expectations).
Restored real CAL board must pass, >100graded and>=11scoped, inputs named.
Center-only ablation's six corner-pad failures motivated original landing grid.

RX2 clearance roundtrip: strip seven scoped_clr_rf prefixes to expose named
U_SW2/4/15/17/22. Add A.NetClass RF50 clearance0.14 -> all five clear; scoped
count positive and failing count decreases. Native board minclearance0.1,
so0.14 is not a custom-below-board case. Other three historical failures need
causal treatment, never blind expectation recopy.

CRC original suite: pass; nominal pour>=30, via>=40; copper bucket equality;
>100graded pads have same-net track endpoints. CRC constraints include
track_width and diff_pair_gap; inventory diff_pair_gap explicitly outside
launch scope. Board minclearance0.1, mintrack0.09.

Zero denominator: stripped all floors -> named M-COVER failure0graded.
No-floor partial VACUITY: retain only QSPI_width -> pass13graded,>250floorless;
restore all class floors without scoped relaxations -> fail eleven. Do not
invent width needs from default class width or turn unknown conditions into
this valid no-floor exemption. Preserve VACUITY docstring/test binding.

LAND_FIX_ORDER historically ranks GRID, CLEARANCE, WIDTH and documents the
failed neckdown experiment149.832mm narrow/0.000mm full width. Existing string
assertions can remain historical advice, but final sentence must not assert
that NO_VALIDATED_WITNESS means the pad cannot emit its width. Historical facts
can be shortened only while retaining meaningful order/causality coverage.

## Source/docs and final boundary

Update all public P-LAND maximum/deficit/routed claims in escape_check.py
module doc, comments, CLI help/summary; scripts/contracts.md P-LAND section;
design-policies.md P-LAND row; t1_escape_tier.py and testsREADME. Add synchronized
P-LAND home to skills/pcb-design/templates/contracts/04_kicad/contracts.md and
project04_kicad/contracts.md. The current template and project had no home.
Do not hand-write native geometry or imply policy_audit itself executes P-LAND.
No harness/auditor/ratchet/debt weakening. Geometry authority remains source.

Final same-source validation: targeted maintained RED then GREEN, full
 t1_escape_tier, t1_land_witness as appropriate if kernel changes, t1_gate_contract,
 t1_contracts. All exact source hashes/logs/durations; no routine whole-repo run.
Full suite process-group300s cap, tinyDRC60s. Native current-board evaluation
should use a private exact source copy; original native baseline remains
0physical/514complete gaps/0parity until canonical re-entry. Expected evaluator
prototype677witnesses is inherited, not an assertion to force in production.
Source acceptance requires guard review and actual counts, then fresh exclusive
mechanical full canonical restart with483 preimages preserved, no stale resume.

## Additional verified dependency: compact handoff tool closure

pcb_flow.py DEFAULT_TOOL_FILES is an explicit list containing escape_check.py
but not a future land_witness.py. tools_hash uses only that list plus configured
extra tools. The current carrier route.yaml adds no flow.inputs.tools override.
Once escape_check imports the library, add it to the default tool closure in
the same integration and prove a helper-only semantic edit invalidates an
otherwise-current compact handoff (private copied tool root, never live edits
just for a test). This needs a concrete scope addition for pcb_flow.py and the
applicable tests/t2_pcb_flow.py test; existing extra_tool stale test is at230.
Do not merely assert that the filename appears in its own constant list.

The full crow prelayout_input_checkpoint.py already add_tree-censuses all three
skill script trees including additions (lines153–158), so it will automatically
invalidate on the new helper. No modification needed there, and no restamp.
Kernel-only phase does not yet make the old public gate consume the library;
its explicit TaskEnvelope/source patch is the temporary authority until the
public integration adds the normal compact handoff tool dependency.

Tool-closure regression sequencing: after public code actually imports the
accepted kernel, retain the pre-fix pcb_flow.py and make a private helper-only
semantic mutation. A current handoff must go stale; unchanged tools_hash is the
causal RED. Then add the helper to DEFAULT_TOOL_FILES and prove stale rejection.
Use owning handoff_document/write_handoff/validate_handoff APIs or a private
copied script root; do not monkeypatch tool_files to force the expected member.
An alternative safe test can redirect _canonical_bytes only for the real
helper path, then verify full handoff validation notices that changed method
input. No live helper modification during tests and no new source restamp.
