from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,tarfile
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901'); P=R/'projects/crow-audio-carrier-v1';D=Path(__file__).parent; W=Path('/tmp/pland-native-kernel-20260910T223440Z'); PACK=P/'06_build/handoffs/pland-native-kernel-20260910T223440Z'
sha=lambda b:hashlib.sha256(b).hexdigest()
env=json.loads((PACK/'task-envelope.json').read_text()); changes=[]
for x in env['input_packet']:
 q=R/x['path']; b=q.read_bytes();assert q.is_file() and not q.is_symlink()
 if sha(b)!=x['sha256'] or len(b)!=x['size']:changes.append(dict(path=x['path'],old_sha256=x['sha256'],sha256=sha(b),size=len(b)))
fixed={'skills/kicad-pcb/scripts/escape_check.py':'cb0d0cf6cb593b5f231fa372920e7dc6adf10bce95c0d734fac0900d3fd3ddf3','tests/t1_escape_tier.py':'424d6dd38567c99fb5ee457f01e1f2b0b071bed48c4b92d4a49b02e04816856c'}
for path,digest in fixed.items():assert sha((R/path).read_bytes())==digest,path
manifest=json.loads((W/'output-manifest.json').read_text());rows=manifest.get('entries',manifest.get('files')); mismatches=[]
for x in rows:
 q=W/x.get('path',x.get('member','')); b=q.read_bytes()
 if sha(b)!=x['sha256'] or len(b)!=x['size']:mismatches.append(x['path'])
actual={q.relative_to(W).as_posix() for q in W.rglob('*') if q.is_file()};listed={x.get('path',x.get('member')) for x in rows}
report=P/'06_build/verification/pland-native-kernel-20260910T223440Z-result.md'
pre=json.loads((W/'preimage-audit.json').read_text())
audit=dict(time=datetime.now(timezone.utc).isoformat(),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),packet_count=len(env['input_packet']),changes=changes,original_public_files_unchanged=True,manifest_rows=len(rows),output_mismatches=mismatches,unlisted=sorted(actual-listed),missing=sorted(listed-actual),report_sha256=sha(report.read_bytes()),preimage_audit_sha256=sha((W/'preimage-audit.json').read_bytes()))
(D/'kernel-root-handback-audit.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps(audit,indent=2))
