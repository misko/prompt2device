from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,tarfile
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';E=P/'01_docs/evidence/pland-backtrack-20260910';D=Path(__file__).parent;W=Path('/tmp/pland-native-kernel-20260910T223440Z');PACK=P/'06_build/handoffs/pland-native-kernel-20260910T223440Z'
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((W/'output-manifest.json').read_text());audit=json.loads((D/'kernel-root-handback-audit.json').read_text());assert not audit['output_mismatches'] and audit['packet_count']==666
sources=[(q,'worker/'+q.relative_to(W).as_posix()) for q in W.rglob('*') if q.is_file()]
for path in manifest['persistent_fixture_paths']:
 root=Path(path);assert root.is_dir() and root.parent==Path('/tmp') and root.name.startswith(('land_complete_','land_matrix_'))
 sources += [(q,'persistent-fixtures/'+root.name+'/'+q.relative_to(root).as_posix()) for q in root.rglob('*') if q.is_file()]
sources += [(q,'commission/'+q.relative_to(PACK).as_posix()) for q in PACK.rglob('*') if q.is_file()]
live=['skills/kicad-pcb/scripts/land_witness.py','tests/t1_land_witness.py','skills/kicad-pcb/scripts/contracts.md','tests/README.md','projects/crow-audio-carrier-v1/01_docs/STATUS.md','projects/crow-audio-carrier-v1/01_docs/journal/placement.md','projects/crow-audio-carrier-v1/06_build/agent_handoff.yaml','projects/crow-audio-carrier-v1/06_build/verification/pland-native-kernel-20260910T223440Z-result.md']
sources += [(R/x,'unadopted-live/'+x) for x in live]
rootnames=['audit_kernel_handback.py','kernel-root-handback-audit.json','kernel-early-handback-1.tar.gz','kernel-early-handback-1-manifest.json','commission_kernel.invalid-mode.py','commission_kernel.unsorted-scope.py','commission_kernel.py','commission-kernel-invalid-mode.md','kernel-commission.log','kernel-commission.start.json','kernel-commission.result.json','kernel-commission-corrected.log','kernel-commission-corrected.start.json','kernel-commission-corrected.result.json','public-integration-preparation.md','footprint-10.0.4.cpp','authority-footprint-10.0.4-fetch.log','authority-footprint-10.0.4-fetch.start.json','authority-footprint-10.0.4-fetch.result.json','kernel-gca-triage.log','kernel-gca-triage.json','kernel-gca-triage.start.json','kernel-gca-triage.result.json','gca_baseline.py','kernel-gca-baseline.log','kernel-gca-baseline.start.json','kernel-gca-baseline.result.json','kernel-gca-baseline-comparison.json','kernel_parser_review.py','kernel-parser-reviewed-source.py','kernel-parser-review.json','kernel-parser-review.log','kernel-parser-review.start.json','kernel-parser-review.result.json']
rootnames += [f'kernel-parser-review-{i}.kicad_dru' for i in range(4)]
for name in rootnames:
 q=D/name;assert q.is_file(),name;sources.append((q,'coordinator/'+name))
sources.append((Path(__file__),'coordinator/preserve_kernel.py'))
rows=[];tmp=D/'native-kernel-attempt.tar.gz'
with tarfile.open(tmp,'w:gz') as tf:
 for q,name in sorted(sources,key=lambda x:x[1]):
  assert not q.is_symlink();b=q.read_bytes();tf.add(q,arcname=name,recursive=False);rows.append(dict(member=name,original_path=str(q),sha256=sha(b),size=len(b)))
assert len(rows)==len({x['member'] for x in rows})
with tarfile.open(tmp) as tf:
 ms=tf.getmembers();assert len(ms)==len(rows)
 for m,x in zip(ms,rows):assert m.isfile() and m.name==x['member'] and m.size==x['size'] and sha(tf.extractfile(m).read())==x['sha256']
digest=sha(tmp.read_bytes());dest=E/(digest+'.tar.gz');assert not dest.exists();shutil.copy2(tmp,dest)
report=P/'06_build/verification/pland-native-kernel-20260910T223440Z-result.md';shutil.copy2(report,E/'native-kernel-worker-result.md')
(E/'native-kernel-attempt-manifest.json').write_text(json.dumps(dict(schema=1,created_at=datetime.now(timezone.utc).isoformat(),source_commit=audit['head'],tar_sha256=digest,tar_size=dest.stat().st_size,count=len(rows),entries=rows),indent=2)+'\n')
c=E/'contracts.md';s=c.read_text();anchor='| `contracts.md` | this exact dated contract | no wildcard evidence namespace |';assert s.count(anchor)==1
s=s.replace(anchor,'\n'.join([f'| `{digest}.tar.gz` | unadopted native kernel attempt, all persistent outputs and coordinator evidence | exact members reopen against native-kernel-attempt-manifest.json |','| `native-kernel-attempt-manifest.json` | complete kernel evidence byte manifest | all original paths, SHA256, sizes and archive identity |','| `native-kernel-worker-result.md` | verbatim incomplete author handback | historical contradictions corrected only in coordinator adoption |','| `native-kernel-adoption.md` | limited measured controls, rejection of complete source and fresh D-BACK | no production gate acceptance or budget reset |',anchor]));c.write_text(s)
print(json.dumps(dict(archive_sha256=digest,members=len(rows),size=dest.stat().st_size,report_sha256=sha(report.read_bytes()),persistent_dirs=len(manifest['persistent_fixture_paths'])),indent=2))
