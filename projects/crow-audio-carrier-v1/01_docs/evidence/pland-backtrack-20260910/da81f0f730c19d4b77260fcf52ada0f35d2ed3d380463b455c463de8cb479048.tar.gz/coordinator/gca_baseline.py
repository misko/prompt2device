from pathlib import Path
import hashlib,io,json,subprocess,sys,tarfile
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');D=Path(__file__).parent;B=D/'kernel-gca-head-baseline';B.mkdir(exist_ok=False)
files=subprocess.check_output(['git','ls-files',':(glob)skills/*/scripts/*.py',':(glob)tests/t*.py'],cwd=R,text=True).splitlines()
raw=subprocess.check_output(['git','archive','HEAD','--',*files],cwd=R)
with tarfile.open(fileobj=io.BytesIO(raw)) as tf:tf.extractall(B,filter='data')
sys.path.insert(0,str(R/'skills/kicad-pcb/scripts'));import gate_contract_audit as g
old=g.audit(B);now=g.audit(R)
result={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'baseline_files':len(files),'archive_sha256':hashlib.sha256(raw).hexdigest(),'baseline':old,'current':now,'same_failures':old['fails']==now['fails'],'same_gate_rows':old['gates']==now['gates'],'extra_unparsed':now['unparsed']}
(D/'kernel-gca-baseline-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('baseline','current')},indent=2));print(json.dumps(old['fails'],indent=2))
assert result['same_failures'] and result['same_gate_rows'] and not now['unparsed']
