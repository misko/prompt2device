#!/usr/bin/env python3
"""T1 library parser controls for the native pad-launch kernel."""
import sys, json, math, hashlib, subprocess, tarfile, tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'skills/kicad-pcb/scripts'))
from harness import check, main, test, tmpdir
from land_witness import Unsupported, condition, scalar, search_witness, specified_track_witness
DIRS=[(math.cos(2*math.pi*k/48),math.sin(2*math.pi*k/48)) for k in range(48)]
class Persist:
    """Harness scratch directory context that deliberately never deletes logs."""
    def __init__(self,p): self.p=p
    def __enter__(self): return self.p
    def __exit__(self,*unused): return False

@test("land witness accepts KiCad single-quoted supported literals")
def t_supported_literal():
    check(condition("A.NetClass == 'ADC' && B.Type != 'Pad'"), 'supported AST')

@test("land witness rejects an unsupported property by name", kind="known_bad")
def t_unsupported_property():
    try:
        condition("A.Footprint == 'X1'")
    except Unsupported as e:
        check('unsupported property' in str(e), 'named unsupported property')
    else:
        raise AssertionError('unsupported property was silently accepted')

@test("width B-side area dependency rejects before boolean folding", kind="known_bad")
def t_width_b_area_rejected():
    try:
        scalar(condition("A.Type == 'Pad' || B.insideArea('X')"),{'A':{'type':'Pad','net':'N','cls':'Default','layers':[0],'layer_name':'F.Cu'},'B':None})
    except Unsupported as e:
        check('B-dependent width rule' in str(e),'named B dependency')
    else:
        raise AssertionError('B-side width dependency was folded away')

@test("unsupported rule-language forms are named rejects", kind="known_bad")
def t_parser_named_rejects():
    for text in ("A.NetName == B.NetName", "'X' == A.NetName", "A.NetName == 'N\\x'", "A.NetName == 'N' extra"):
        try:
            condition(text)
        except Unsupported:
            pass
        else:
            raise AssertionError('accepted '+text)

@test("native complete-class fixture keeps base witness and hostile two-track oracle")
def t_native_complete_class_oracle():
    archive=Path(__file__).resolve().parents[1]/'projects/crow-audio-carrier-v1/01_docs/evidence/pland-backtrack-20260910/96f680152d8f1edd66b485c54fb31da033edb15aa52e0858a861d3cd47228859.tar.gz'
    check(hashlib.sha256(archive.read_bytes()).hexdigest()==archive.name.split('.')[0],'complete fixture archive SHA')
    with Persist(tmpdir('land_complete_')) as td:
        root=Path(td)
        with tarfile.open(archive,'r:gz') as tf:
            members=tf.getmembers()
            names=[m.name for m in members]
            check(len(names)==len(set(names)) and all(m.isfile() and not m.issym() and not m.islnk() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members),'safe exact fixture archive')
            tf.extractall(root,filter='data')
        specimen=next(root.rglob('specimens'))
        for label,want,rc in (('base','VALIDATED_CONSTANT_WIDTH_WITNESS',0),('hostile','NO_VALIDATED_WITNESS',5)):
            d=specimen/label; board=d/'oracle.kicad_pcb'; result=search_witness(board,d/'oracle.kicad_dru',('X1','1'),[(10.,10.)],DIRS,[.2])
            check(result['status']==want,label+' library outcome')
            out=d/'fresh-drc.json'; run=subprocess.run(['kicad-cli','pcb','drc','--severity-all','--all-track-errors','--exit-code-violations','--format','json','-o',str(out),str(board)],capture_output=True,text=True,timeout=60)
            (d/'fresh-drc.stdout').write_text(run.stdout); (d/'fresh-drc.stderr').write_text(run.stderr)
            (d/'fresh-drc.result.json').write_text(json.dumps({'argv':run.args,'rc':run.returncode}))
            report=json.loads(out.read_text()); check(run.returncode==rc,label+' native rc')
            check(len(report['violations'])==(0 if label=='base' else 2) and not report['unconnected_items'],label+' native denominator')
            if label=='hostile':
                check({v['items'][1]['description'].split()[1] for v in report['violations']}=={'3','4'},'both hostile pad identities')
        try:
            search_witness(specimen/'base'/'oracle.kicad_pcb',specimen/'base'/'oracle.kicad_dru',('X1','1'),[(20.,20.)],DIRS,[.2])
        except Unsupported as e:
            check('NATIVE_START_OUTSIDE_PAD' in str(e),'outside start is native rejected')
        else:
            raise AssertionError('outside candidate start was accepted')

@test("native evaluator matrix resolves all 36 declared tracks")
def t_native_evaluator_matrix():
    archive=Path(__file__).resolve().parents[1]/'projects/crow-audio-carrier-v1/01_docs/evidence/pland-backtrack-20260910/887c61662cbdc291a68c03bdbfb4569d5c93eb830989f31393338c14a128b3db.tar.gz'
    check(hashlib.sha256(archive.read_bytes()).hexdigest()==archive.name.split('.')[0],'evaluator archive SHA')
    with Persist(tmpdir('land_matrix_')) as td:
        with tarfile.open(archive,'r:gz') as tf:
            members=tf.getmembers(); names=[m.name for m in members]
            check(len(names)==len(set(names)) and all(m.isfile() and not m.issym() and not m.islnk() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members),'safe evaluator archive')
            tf.extractall(td,filter='data')
        root=next(Path(td).rglob('reviewer'))
        for label,want in (('base','VALIDATED_CONSTANT_WIDTH_WITNESS'),('hostile','NO_VALIDATED_WITNESS')):
            cases=json.loads((root/label/'cases.json').read_text())
            got=[]
            for c in cases:
                dx=c['end'][0]-c['start'][0];dy=c['end'][1]-c['start'][1]
                got.append(specified_track_witness(root/label/'matrix.kicad_pcb',root/label/'matrix.kicad_dru',(c['ref'],'1'),tuple(c['start']),tuple(c['end']),c['width'])['status'])
            check(len(got)==18 and set(got)=={want},label+' 18-track native matrix')
        dru=root/'base'/'matrix.kicad_dru'
        dru.write_text(dru.read_text()+"\n(rule \"circle_gap\" (condition \"A.NetName == 'remote_high_T'\") (constraint clearance (min 0.221mm)))\n")
        circle=specified_track_witness(root/'base'/'matrix.kicad_pcb',dru,('X1','1'),(10.,10.),(11.,10.),.2)
        check(circle['status']=='NO_VALIDATED_WITNESS','native circle 0.220mm rejects 0.221mm rule')

if __name__ == '__main__':
    raise SystemExit(main())
