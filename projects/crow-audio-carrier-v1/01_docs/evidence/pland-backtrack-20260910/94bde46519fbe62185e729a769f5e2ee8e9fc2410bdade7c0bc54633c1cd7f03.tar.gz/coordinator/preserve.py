from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, subprocess, tarfile
r=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
p=r/'projects/crow-audio-carrier-v1'
e=p/'01_docs/evidence/pland-backtrack-20260910'
d=Path(__file__).parent
a=Path('/tmp/pland-witness-author-20260910T210755Z')
packet=p/'06_build/handoffs/pland-witness-author-20260910T210755Z'
sha=lambda b:hashlib.sha256(b).hexdigest()
report=a/'result.md'
copy=p/'06_build/verification/pland-witness-author-20260910T210755Z-result.md'
assert report.read_bytes()==copy.read_bytes()
env=json.loads((packet/'task-envelope.json').read_text())
assert sha((packet/'task-envelope.json').read_bytes())=='30eafbd595d8ee283ae2303a2047a0f8805d47eefcd70a7d877f9c7d670a0630'
changes=[]
for row in env['input_packet']:
 q=r/row['path']; b=q.read_bytes()
 assert q.is_file() and not q.is_symlink()
 if sha(b)!=row['sha256'] or len(b)!=row['size']:
  changes.append(dict(path=row['path'],expected=row['sha256'],actual=sha(b),size=len(b)))
allowed={'tests/t1_escape_tier.py',str((p/'01_docs/STATUS.md').relative_to(r)),str((p/'01_docs/journal/placement.md').relative_to(r)),str((p/'06_build/agent_handoff.yaml').relative_to(r))}
assert {x['path'] for x in changes}<=allowed,changes
assert sha((r/'skills/kicad-pcb/scripts/escape_check.py').read_bytes())=='cb0d0cf6cb593b5f231fa372920e7dc6adf10bce95c0d734fac0900d3fd3ddf3'
patch=subprocess.check_output(['git','diff','--binary'],cwd=r)
(d/'author-all-wip.diff').write_bytes(patch)
subprocess.run(['git','diff','--numstat'],cwd=r,stdout=(d/'author-wip-numstat.txt').open('wb'),check=True)
shutil.copy2(r/'tests/t1_escape_tier.py',d/'t1_escape_tier.py.wip')
subprocess.run(['ps','-eo','pid,ppid,lstart,args'],stdout=(d/'process-snapshot.txt').open('wb'),check=True)
scratch=[Path('/tmp')/x for x in ('pland_witness_buor9qaj','pland_witness_c6rfmpgs','pland_witness_mvyf2gld')]
assert all(q.is_dir() for q in scratch)
audit=dict(time=datetime.now(timezone.utc).isoformat(),input_count=len(env['input_packet']),changes=changes,report_sha256=sha(report.read_bytes()),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),scratch_directories=[str(q) for q in scratch],patch_sha256=sha(patch))
(d/'root-input-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
sources=[(q,'author/'+q.relative_to(a).as_posix()) for q in a.rglob('*') if q.is_file()]
sources += [(q,'commission/'+q.relative_to(packet).as_posix()) for q in packet.rglob('*') if q.is_file()]
sources += [(q,'coordinator/'+q.name) for q in d.iterdir() if q.is_file()]
sources += [(copy,'author/project-result.md')]
sources += [(q,'scratch/'+base.name+'/'+q.relative_to(base).as_posix()) for base in scratch for q in base.rglob('*') if q.is_file()]
for rel in sorted(allowed):
 sources.append((r/rel,'live-handback/'+rel))
rows=[]
temp=d/'rejected-attempt.tar.gz'
with tarfile.open(temp,'w:gz') as tf:
 for q,member in sorted(sources,key=lambda pair:pair[1]):
  assert not q.is_symlink()
  b=q.read_bytes();tf.add(q,arcname=member,recursive=False)
  rows.append(dict(member=member,original_path=str(q),sha256=sha(b),size=len(b)))
digest=sha(temp.read_bytes())
with tarfile.open(temp,'r:gz') as tf:
 members=tf.getmembers()
 assert len(members)==len(rows)==len({m.name for m in members})
 for m,row in zip(members,rows):
  assert m.isfile() and m.name==row['member'] and m.size==row['size']
  assert not m.name.startswith('/') and '..' not in Path(m.name).parts
  assert sha(tf.extractfile(m).read())==row['sha256']
target=e/(digest+'.tar.gz');assert not target.exists()
shutil.copy2(temp,target);assert sha(target.read_bytes())==digest
shutil.copy2(report,e/'witness-author-result.md')
manifest=dict(schema=1,created_at=audit['time'],source_commit=audit['head'],tar_sha256=digest,tar_size=target.stat().st_size,count=len(rows),entries=rows,scope='Rejected fixture-author attempt; no production method or placement acceptance.')
(e/'witness-attempt-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
c=e/'contracts.md';t=c.read_text();anchor='| `contracts.md` | this exact dated contract | no wildcard evidence namespace |';assert t.count(anchor)==1
new=[f'| `{digest}.tar.gz` | complete rejected witness-author work, logs, scratch fixtures and WIP | every regular member reopens against witness-attempt-manifest.json; no links |','| `witness-attempt-manifest.json` | original-path, SHA256 and size map for failed witness-author attempt | preserves both invalid fixture outcomes and intermediate reports |','| `witness-author-result.md` | verbatim incomplete author handback | zero-denominator failures are not behavioral RED evidence |','| `witness-adoption.md` | coordinator rejection, correction and restoration | no production or placement acceptance; all prior caps retained |',anchor]
c.write_text(t.replace(anchor,'\n'.join(new)))
print(json.dumps(dict(audit=audit,archive_sha256=digest,members=len(rows),size=target.stat().st_size),indent=2))
