# Bootstrap capture exception

The initial envelope/TASK inspection, preimage/archive checks, and the first
`t1_escape_tier.py` run occurred before this task created command metadata.
Their terminal transcript is unavailable as a complete capture. The retained
`t1_escape_tier.log` is a mixed-source diagnostic: the process began while an
incorrect `MAX_LAUNCH_PTS=37` implementation changed the adaptive grid, then
the source was restored while the process remained active. It is not a
baseline, RED, GREEN, or suite result.

The erroneous source edit was reverted. Subsequent commands are captured
before execution; this note deliberately does not reconstruct missing argv,
start, duration, or return-code metadata.
