import importlib.util
from pathlib import Path

p = Path('tests/t1_escape_tier.py')
spec = importlib.util.spec_from_file_location('t1_escape_tier', p)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.t_pland_public_witness_uses_actual_limiting_pair()
