import hashlib, json, os, sys
p=sys.argv[1]
x=json.load(open(p))
bad=[]
for e in x['input_packet']:
    try:
        s=os.stat(e['path'])
        h=hashlib.sha256(open(e['path'],'rb').read()).hexdigest()
        if s.st_size != e['size'] or h != e['sha256']:
            bad.append(e['path'])
    except Exception as exc:
        bad.append(e['path']+': '+str(exc))
print(json.dumps({'checked':len(x['input_packet']),'bad_count':len(bad),'bad':bad},sort_keys=True))
sys.exit(bool(bad))
