from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, signal, subprocess, time
ROOT = Path(__file__).parent
REPO = Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
def run(argv, stem, timeout=120):
    source = REPO / 'skills/kicad-pcb/scripts/escape_check.py'
    meta = dict(argv=[str(x) for x in argv], cwd=str(REPO),
                start=datetime.now(timezone.utc).isoformat(), timeout_seconds=timeout,
                source_sha256_before=hashlib.sha256(source.read_bytes()).hexdigest())
    (ROOT/(stem+'.start.json')).write_text(json.dumps(meta, indent=2)+'\n')
    t=time.monotonic()
    with (ROOT/(stem+'.log')).open('wb') as out:
        p=subprocess.Popen(meta['argv'], cwd=REPO, stdout=out, stderr=subprocess.STDOUT, start_new_session=True)
        timed_out=False
        try: rc=p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out=True; os.killpg(p.pid, signal.SIGTERM)
            try: rc=p.wait(timeout=5)
            except subprocess.TimeoutExpired: os.killpg(p.pid, signal.SIGKILL); rc=p.wait()
    meta.update(rc=rc,timed_out=timed_out,duration_seconds=time.monotonic()-t,end=datetime.now(timezone.utc).isoformat(),pid=p.pid,
                source_sha256_after=hashlib.sha256(source.read_bytes()).hexdigest())
    (ROOT/(stem+'.result.json')).write_text(json.dumps(meta,indent=2)+'\n'); print(json.dumps(meta),flush=True); return rc
