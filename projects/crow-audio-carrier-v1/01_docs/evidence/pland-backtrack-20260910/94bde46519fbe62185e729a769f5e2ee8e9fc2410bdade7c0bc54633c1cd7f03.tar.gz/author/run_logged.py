#!/usr/bin/env python3
import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

out = Path(sys.argv[1])
cwd = sys.argv[2]
argv = sys.argv[3:]
source = Path(cwd) / "skills/kicad-pcb/scripts/escape_check.py"
record = {"argv": argv, "cwd": cwd,
          "start": datetime.now(timezone.utc).isoformat(),
          "source_sha256_before": hashlib.sha256(source.read_bytes()).hexdigest()}
t0 = time.monotonic()
with out.with_suffix(".log").open("wb") as log:
    proc = subprocess.run(argv, cwd=cwd, stdout=log, stderr=subprocess.STDOUT,
                          timeout=300)
record.update({"rc": proc.returncode, "duration_seconds": time.monotonic() - t0,
               "end": datetime.now(timezone.utc).isoformat(),
               "source_sha256_after": hashlib.sha256(source.read_bytes()).hexdigest()})
out.write_text(json.dumps(record, indent=2) + "\n")
sys.exit(proc.returncode)
