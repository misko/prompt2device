from pathlib import Path
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');D=Path(__file__).parent;pre=D/'governance-preimages';pre.mkdir()
paths=['skills/pcb-design/scripts/commission_project.py','skills/pcb-design/scripts/project_report_audit.py','skills/pcb-enclosure/scripts/enclosure_layout_audit.py','tests/t1_pcb_commission.py','tests/t1_project_reports.py','tests/t1_enclosure_layout.py','tests/t1_pcba_availability.py','skills/pcb-design/contracts.md','skills/pcb-enclosure/contracts.md','skills/jlcpcb-fab/scripts/contracts.md','tests/README.md']
for path in paths:
 q=pre/path;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((R/path).read_bytes())
def append_test(path,code):
 p=R/path;s=p.read_text();anchor='if __name__ == "__main__":';assert s.count(anchor)==1;p.write_text(s.replace(anchor,code+'\n\n'+anchor))
append_test('tests/t1_project_reports.py','''@test("report CLI coverage names the one report actually graded")
def t_cli_coverage():
    """RED against 18c96c58: successful audit had no coverage denominator."""
    _, report = fixture()
    result = must_pass(run([KPY, AUDIT, report]), "report coverage")
    contains(result.out, "coverage=1/1 report", "actual report denominator")
''')
append_test('tests/t1_pcb_commission.py','''@test("scaffold CLI coverage matches the complete written file population")
def t_cli_coverage():
    """RED against 18c96c58: scaffold success only printed an isolated count."""
    root = tmpdir("commission-coverage-")
    brief = root / "brief.txt"
    brief.write_text("A simple two-layer board.\\n")
    destination = root / "projects"
    destination.mkdir()
    result = must_pass(invoke(destination, brief), "scaffold coverage")
    written = sum(path.is_file() for path in (destination / "fresh-board").rglob("*"))
    check(written > 0, "empty scaffold population")
    contains(result.out, f"coverage={written}/{written} scaffold files written",
             "filesystem-measured scaffold denominator")
''')
append_test('tests/t1_enclosure_layout.py','''@test("enclosure layout CLI coverage includes every project path and names root exclusions")
def t_cli_coverage():
    """RED against 18c96c58: neither clean nor failing scan printed coverage."""
    from harness import KPY, must_pass, must_fail, run as run_cli
    root = fixture()
    args = [KPY, AUDIT, "--root", root]
    result = must_pass(run_cli(args), "layout coverage")
    contains(result.out, "coverage=4/4 project paths", "complete project path population")
    contains(result.out, "unscoped_entries=1", "root contract exclusion")
    mesh = root / "projects/demo/06_build/mechanical/base.stl"
    mesh.parent.mkdir(parents=True)
    mesh.write_text("solid base\\nendsolid base\\n")
    subprocess.run(["git", "-C", str(root), "add", "-f", str(mesh)], check=True)
    rejected = must_fail(run_cli(args), "misplaced generated STL",
                         expect="generated 06_build meshes stay ignored")
    contains(rejected.out, "coverage=5/5 project paths", "failure retains full census")


@test("empty enclosure layout population is incomplete", kind="known_bad")
def t_empty_coverage():
    """RED against 18c96c58: an empty Git index falsely reported PASS."""
    from harness import KPY, must_fail, run as run_cli
    root = tmpdir("enclosure-layout-empty-")
    subprocess.run(["git", "init", "-q", str(root)], check=True)
    result = must_fail(run_cli([KPY, AUDIT, "--root", root]),
                       "empty layout population", expect="NOTHING GRADED")
    contains(result.out, "coverage=0/0 project paths", "explicit empty census")
''')
append_test('tests/t1_pcba_availability.py','''@test("PCBA CLI accepts complete stock and rejects a real insufficient row", kind="known_bad")
def t_cli_stock_rejection():
    """Exercise real CLI exits; library-only checks did not satisfy G-RED."""
    from harness import KPY, must_pass, must_fail, run
    current = datetime.now(timezone.utc)
    root, _, _, response, _, _ = fixture(now=current, checked=current.isoformat())
    tool = ROOT / "skills/jlcpcb-fab/scripts/jlc_pcba_availability.py"
    good_path = root / "cli-good.json"
    args = [KPY, tool, "grade", root / "request.json", response]
    good = must_pass(run([*args, "--out", good_path]), "complete CLI stock")
    contains_good = json.loads(good_path.read_text())
    eq(contains_good["coverage"], {"passing": 2, "graded": 2, "total": 2},
       "clean CLI population")
    rows = list(csv.DictReader(response.open(newline="")))
    rows[0]["Available Qty"] = rows[0]["Public Stock Qty"] = "0"
    with response.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=pcba.RESPONSE_FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    bad_path = root / "cli-bad.json"
    bad = must_fail(run([*args, "--out", bad_path]), "insufficient stock CLI",
                    expect="REJECTED")
    eq(bad.rc, 1, "stock rejection exit code")
    rejected = json.loads(bad_path.read_text())
    eq(rejected["coverage"], {"passing": 1, "graded": 2, "total": 2},
       "one insufficient row remains graded")
''')
