from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,subprocess,tarfile
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-audio-carrier-v1';E=P/'01_docs/evidence/pland-backtrack-20260910';D=Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest()
sourcepaths=[q.relative_to(D/'governance-preimages').as_posix() for q in (D/'governance-preimages').rglob('*') if q.is_file()]
for path,digest in {'skills/kicad-pcb/scripts/escape_check.py':'cb0d0cf6cb593b5f231fa372920e7dc6adf10bce95c0d734fac0900d3fd3ddf3','tests/t1_escape_tier.py':'424d6dd38567c99fb5ee457f01e1f2b0b071bed48c4b92d4a49b02e04816856c','projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb':'89d33bae8eaf67457fde887eae9db187d9284ea54be386f0d31e3d7dfe92bf2e'}.items():assert sha((R/path).read_bytes())==digest,path
stems=['gca-red-commission','gca-red-reports','gca-red-layout','gca-pcba-cli-existing','gca-final-commission','gca-final-reports','gca-final-layout','gca-final-pcba','gca-final-gate-contract','gca-final-contracts']
measurements=[]
for stem in stems:
 meta=json.loads((D/(stem+'.result.json')).read_text());assert not Path('/proc',str(meta['pid'])).exists();measurements.append(dict(stem=stem,**meta))
(D/'governance-process-audit.json').write_text(json.dumps(dict(time=datetime.now(timezone.utc).isoformat(),wrapper_pids_absent=True,measurements=measurements),indent=2)+'\n')
sources=[]
for path in sourcepaths:sources += [(D/'governance-preimages'/path,'preimage/'+path),(R/path,'tested-source/'+path)]
for stem in stems:
 for ext in ['log','start.json','result.json']:sources.append((D/(stem+'.'+ext),'execution/'+stem+'.'+ext))
for name in ['governance-process-audit.json','add_governance_tests.py','preserve_governance.py']:sources.append((D/name,'coordinator/'+name))
rows=[];tmp=D/'governance-repair.tar.gz'
with tarfile.open(tmp,'w:gz') as tf:
 for q,name in sorted(sources,key=lambda x:x[1]):
  b=q.read_bytes();assert not q.is_symlink();tf.add(q,arcname=name,recursive=False);rows.append(dict(member=name,original_path=str(q),sha256=sha(b),size=len(b)))
with tarfile.open(tmp) as tf:
 ms=tf.getmembers();assert len(ms)==len(rows)==len({m.name for m in ms})
 for m,x in zip(ms,rows):assert m.isfile() and m.name==x['member'] and m.size==x['size'] and sha(tf.extractfile(m).read())==x['sha256']
digest=sha(tmp.read_bytes());dest=E/(digest+'.tar.gz');assert not dest.exists();shutil.copy2(tmp,dest)
(E/'checker-contract-repair-manifest.json').write_text(json.dumps(dict(schema=1,tar_sha256=digest,tar_size=dest.stat().st_size,count=len(rows),entries=rows),indent=2)+'\n')
(E/'checker-contract-repair.md').write_text(f'''# Five inherited checker-contract failures repaired

MEASURED baseline: root reproduced five obligations and all95 gate rows on the
exact262-file HEAD18c96c58-era tool/test cohort (the direct comparison used
5c89d76b, whose generic source was unchanged). Baseline output and source hashes
are preserved in native-kernel-attempt archive da81f0f7. The audit was correct:
three tools lacked CLI coverage denominators; two suites used assertions the
explicit G-RED invocation contract did not recognize. Their prior bad-input
library/CLI assertions are retained; no claim that these gates lacked ALL tests.

CHANGED: scaffold output now states the complete written file population;
report audit names its one-report denominator. Enclosure layout counts all
tracked project paths, names unscoped root entries, prints its denominator on
success and findings, and returns INCOMPLETE/rc2 over an empty population.
A maintained PCBA CLI case accepts two exact stock rows, then rejects one
insufficient row with actualrc1 and coverage1passing/2graded/2total. Enclosure
coverage likewise uses the actual CLI and an added tracked misplaced mesh.
Gate-contract auditor, skip list, regexes, thresholds and vacuity floor unchanged.

MEASURED behavioral RED before source edits: scaffold lacked44/44 count;
report lacked1/1; enclosure lacked4/4 and falsely passed an empty index.
All four new coverage assertions failed for those exact reasons. The PCBA CLI
clean/bad control already passed unchanged production code, as expected for
making existing behavior visible to G-RED. Its failure was the audit's missing
recognized CLI fixture, not a newly claimed stock-verdict bug.

MEASURED final same tests and full relevant suites:
- t1_pcb_commission:8/8 PASS,4 known-bad,1.467311s.
- t1_project_reports:6/6 PASS,3 known-bad,0.364192s.
- t1_enclosure_layout:11/11 PASS,7 known-bad,0.915200s.
- t1_pcba_availability:45/45 PASS,32 known-bad,0.414442s.
- t1_gate_contract:37/37 PASS,24 known-bad,1 declared blind spot reproduced,
  1 default slow test skipped;6.578949s. The existing audit itself now passes.
- t1_contracts:17/17 PASS,13 known-bad,5.026799s.
All ten wrapper processes reaped; actual argv/start/end/PID/rc/duration and full
stdout are retained. Normal test harness semantics were used; no native oracle
run is claimed from these generic checker tests.

MEASURED archive {digest},
{len(rows)} regular members, {dest.stat().st_size} archive bytes; every member reopened
against checker-contract-repair-manifest.json. It contains exact before/after
source/tests/contracts and every RED/GREEN log/receipt. Root is sole live writer.
No board, old escape checker, native model, rule, checkpoint or release changed.
Generic tool source changes keep the already-stale canonical checkpoint stale;
normal full regeneration remains mandatory. This closes these five generic
checker obligations only, with no kernel/P-LAND/placement acceptance implied.
''')
c=E/'contracts.md';s=c.read_text();anchor='| `contracts.md` | this exact dated contract | no wildcard evidence namespace |';assert s.count(anchor)==1;c.write_text(s.replace(anchor,f'| `{digest}.tar.gz` | five inherited checker-contract repairs, source preimages and executions | exact members in checker-contract-repair-manifest.json |\n| `checker-contract-repair-manifest.json` | complete repair byte inventory | source, tests, actual RED/GREEN outputs and process receipts |\n| `checker-contract-repair.md` | causal diagnosis and measured checker-contract closure | no native placement or release credit |\n'+anchor))
now=datetime.now(timezone.utc).isoformat();(P/'01_docs/STATUS.md').write_text(f'''# STATUS beacon — crow audio carrier v1

stage: placement
step: "Five checker-contract failures repaired; fresh kernel contract diagnosis running"
measure: "MEASURED70/70 affected tests,37/37 gate-contract,17/17 structure-contract; fresh kernel reviewer verified672 inputs."
state: running
next: "Await complete private kernel judgment by23:48:49Z, reserve23:46:49Z. Old public P-LAND still unchanged; no production kernel adoption."
op_pid:
updated: {now}
''')
with (P/'01_docs/journal/placement.md').open('a') as f:f.write(f'''\n\n## {now} — inherited checker obligations closed through source and CLI controls

- MEASURED three missing denominators and two unrecognized CLI failure fixtures
  fixed without changing the owning gate-contract auditor, skip list or floor.
  Empty enclosure index previously falsely passed; now INCOMPLETE/rc2.
- MEASURED four coverage regressions RED on original source; final full suites
  8/8,6/6,11/11,45/45, then gate-contract37/37 and structure-contract17/17 PASS.
  Known-bad counts4,3,7,32,24,13 respectively; existing1 vacuity reproduced and
  default1 slow test skipped. Exact{len(rows)}-member archive{digest[:8]} retained.
- No native board, old public escape checker, models or rules changed. Fresh
  private kernel contract reviewer remains active on immutable archives with
  original23:48:49 deadline; generic tools are explicitly coordinator mutations.
''')
print(json.dumps(dict(archive=digest,members=len(rows),bytes=dest.stat().st_size,source_files=len(sourcepaths)),indent=2))
