import urllib.request,pathlib,json,hashlib,time
O=pathlib.Path(__file__).parent/'authority';O.mkdir(exist_ok=True);rows=[]
for path in ['pcbnew/pcbexpr_functions.cpp','pcbnew/pcbexpr_evaluator.cpp','common/libeval/libeval_compiler.cpp','common/libeval/libeval.cpp','pcbnew/drc/drc_rule_parser.cpp']:
 url='https://raw.githubusercontent.com/KiCad/kicad-source-mirror/10.0.4/'+path;t=time.time()
 try:
  data=urllib.request.urlopen(url,timeout=15).read();p=O/path.replace('/','__');p.write_bytes(data);rows.append({'url':url,'path':p.name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest(),'seconds':time.time()-t})
 except Exception as e:rows.append({'url':url,'error':repr(e),'seconds':time.time()-t})
print(json.dumps(rows,indent=2));(O/'sources.json').write_text(json.dumps(rows,indent=2)+'\n')
