import urllib.request,pathlib,json,hashlib,time
O=pathlib.Path(__file__).parent/'authority';rows=[]
for path in ['common/libeval_compiler/libeval_compiler.cpp','include/libeval_compiler/libeval_compiler.h','common/libeval_compiler/grammar.lemon']:
 url='https://raw.githubusercontent.com/KiCad/kicad-source-mirror/10.0.4/'+path;t=time.time();data=urllib.request.urlopen(url,timeout=15).read();p=O/path.replace('/','__');p.write_bytes(data);rows.append({'url':url,'path':p.name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest(),'seconds':time.time()-t})
print(json.dumps(rows,indent=2));(O/'sources2.json').write_text(json.dumps(rows,indent=2)+'\n')
