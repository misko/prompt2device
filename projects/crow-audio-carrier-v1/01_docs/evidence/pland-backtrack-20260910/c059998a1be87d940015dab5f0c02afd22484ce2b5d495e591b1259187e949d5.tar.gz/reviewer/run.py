#!/usr/bin/python3
import os,sys,subprocess,time,json,datetime,pathlib,signal
O=pathlib.Path(__file__).parent
name=sys.argv[1]; argv=sys.argv[2:]; start=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
with (O/(name+'.stdout')).open('wb') as so,(O/(name+'.stderr')).open('wb') as se:
 p=subprocess.Popen(argv,cwd=O,env=env,stdout=so,stderr=se,start_new_session=True)
 receipt={'name':name,'argv':argv,'cwd':str(O),'pid':p.pid,'start':start,'timeout_seconds':90}
 (O/(name+'.process.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 try: rc=p.wait(timeout=90); timeout=False
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM)
  try: rc=p.wait(timeout=3)
  except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGKILL); rc=p.wait()
  timeout=True
 receipt.update(rc=rc,timed_out=timeout,end=datetime.datetime.now(datetime.timezone.utc).isoformat(),duration_seconds=time.monotonic()-t)
 (O/(name+'.process.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt)); print((O/(name+'.stdout')).read_text(errors='replace')); print((O/(name+'.stderr')).read_text(errors='replace'),file=sys.stderr)
sys.exit(rc)
