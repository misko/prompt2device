import pathlib,sys,json,collections,hashlib,shutil
import pcbnew
O=pathlib.Path(__file__).parent; R=pathlib.Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');sys.path.insert(0,str(O/'extracted/kernel/unadopted-live/skills/kicad-pcb/scripts')); import land_witness as w
sources={'current':R/'projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_pcb'}
for n,s in [('CAL','pluto-cal-switch'),('RX2','pluto-rx2-8way'),('CRC','crow-recorder-central-v2')]:sources[n]=next((R/'archived_projects'/s/'04_kicad').glob('*.kicad_pcb'))
rows={};inputs=[]
for name,p in sources.items():
 d=O/'corpus'/name;d.mkdir(parents=True,exist_ok=True)
 for ext in ['.kicad_pcb','.kicad_pro','.kicad_dru']:
  source=p.with_suffix(ext);data=source.read_bytes();dest=d/source.name;dest.write_bytes(data);inputs.append({'path':str(source),'private':str(dest.relative_to(O)),'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 q=d/p.name;b=pcbnew.LoadBoard(str(q));text=q.with_suffix('.kicad_dru').read_text();forms=w.sexprs(text);attrs=collections.Counter();kinds=collections.Counter();conditions=[];layers=[]
 for f in forms:
  if f[0]!='rule':continue
  for a in f[2:]:
   attrs[a[0]]+=1
   if a[0]=='constraint':kinds[str(a[1:])]+=1
   if a[0]=='condition':conditions.append(a[1])
   if a[0]=='layer':layers.append(a[1])
 pads=[];shapes=collections.Counter();classes=collections.Counter();multis=collections.Counter();locals=[];holes=[];unread=[];fps=[]
 for fp in b.GetFootprints():
  if fp.GetLocalClearance() is not None:fps.append([fp.GetReference(),fp.GetLocalClearance()])
  for p in fp.Pads():
   if not p.IsOnCopperLayer():continue
   ident=fp.GetReference()+'.'+p.GetNumber(); ls=list(p.GetLayerSet().CuStack());classes[p.GetNetClassName()]+=1;multis[str([b.GetLayerName(L) for L in ls])]+=1;shapes[str(p.GetShape())]+=1
   if p.GetLocalClearance() is not None:locals.append([ident,p.GetLocalClearance()])
   try:
    for L in ls:
     poly=p.GetEffectivePolygon(L)
     if any(poly.HoleCount(i) for i in range(poly.OutlineCount())):holes.append([ident,b.GetLayerName(L)])
     if poly.OutlineCount()!=1:unread.append([ident,b.GetLayerName(L),'outlines',poly.OutlineCount()])
   except Exception as e:unread.append([ident,str(e)])
 result={'physical':sum(len(list(f.Pads())) for f in b.GetFootprints()),'copper':sum(classes.values()),'classes':dict(classes),'layer_sets':dict(multis),'shapes':dict(shapes),'pad_local':locals,'fp_local':fps,'holes':holes,'nonsimple_or_unreadable':unread,'rule_attributes':dict(attrs),'constraints':dict(kinds),'conditions':conditions,'rule_layers':layers,'board_min':json.loads(q.with_suffix('.kicad_pro').read_text())['board']['design_settings']['rules']['min_clearance']}
 try: result['old_parse_count']=len(w.rules(q.with_suffix('.kicad_dru')))
 except Exception as e: result['old_parse_error']=repr(e)
 rows[name]=result;print(name,json.dumps({k:v for k,v in result.items() if k not in ['conditions','constraints']},indent=2))
(O/'corpus-census.json').write_text(json.dumps(rows,indent=2)+'\n');(O/'supplemental-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
