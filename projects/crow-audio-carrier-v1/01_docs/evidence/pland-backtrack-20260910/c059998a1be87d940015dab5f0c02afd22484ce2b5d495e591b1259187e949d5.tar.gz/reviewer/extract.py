from pathlib import Path,PurePosixPath
import json,hashlib,tarfile
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901'); E=R/'projects/crow-audio-carrier-v1/01_docs/evidence/pland-backtrack-20260910'; O=Path(__file__).parent
summary=[]
for key,mname in [('kernel','native-kernel-attempt-manifest.json'),('kernel-final','native-kernel-root-verification-manifest.json'),('evaluator','evaluator-manifest.json'),('complete','native-complete-classes-attempt-manifest.json'),('fixture','fixture-dback-manifest.json')]:
 m=json.loads((E/mname).read_text()); a=E/(m['tar_sha256']+'.tar.gz'); assert len(a.read_bytes())==m['tar_size']; assert hashlib.sha256(a.read_bytes()).hexdigest()==m['tar_sha256']; target=O/'extracted'/key; target.mkdir(parents=True,exist_ok=True)
 expected={x['member']:x for x in m['entries']}; actual=[]
 with tarfile.open(a,'r:gz') as tar:
  for member in tar.getmembers():
   n=PurePosixPath(member.name); assert not n.is_absolute() and '..' not in n.parts; assert member.isfile(), (key,member.name,member.type); assert member.name in expected
   data=tar.extractfile(member).read(); x=expected[member.name]; assert len(data)==x['size'] and hashlib.sha256(data).hexdigest()==x['sha256']; p=target/member.name; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(data); actual.append(member.name)
 assert len(actual)==len(set(actual))==len(expected)==m['count']; assert set(actual)==set(expected)
 summary.append({'key':key,'manifest':mname,'archive_sha256':m['tar_sha256'],'count':len(actual),'all_verified':True})
(O/'archive-verification.json').write_text(json.dumps(summary,indent=2)+'\n'); print(json.dumps(summary,indent=2))
