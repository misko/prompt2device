import pathlib,json,sys,subprocess,time,datetime,os,hashlib
import pcbnew
O=pathlib.Path(__file__).parent; source=O/'extracted/evaluator/reviewer/base/matrix.kicad_pcb'; basepro=source.with_suffix('.kicad_pro').read_bytes(); basedru=source.with_suffix('.kicad_dru').read_text()
cases=[
 ('pad_nonzero_wins',.15,None,.30,.22,False),
 ('fp_nonzero_wins',None,.30,.15,.22,True),
 ('pad_masks_fp',.15,.30,.30,.22,False),
 ('pad_zero_masks_fp',0,.30,.15,.22,False),
 ('pad_zero_then_custom',0,None,.30,.22,True),
 ('fp_zero_then_custom',None,0,.30,.22,True),
 ('custom_below_board',None,None,.05,.075,False),
 ('local_below_board',.05,None,.05,.075,True),
 ('zero_below_board',0,.30,.05,.075,False),
 ('zero_without_custom',0,.30,None,.075,True),
]
rows=[]
for name,padval,fpval,custom,gap,want in cases:
 d=O/'native-controls'/name;d.mkdir(parents=True,exist_ok=True); boardpath=d/'matrix.kicad_pcb';b=pcbnew.LoadBoard(str(source));fp=next(f for f in b.GetFootprints() if f.GetReference()=='X1');pad=next(p for p in fp.Pads() if p.GetNumber()=='3')
 if padval is not None:pad.SetLocalClearance(round(padval*1e6))
 if fpval is not None:fp.SetLocalClearance(round(fpval*1e6))
 pad.SetPosition(pcbnew.VECTOR2I(10500000,round((10+.2+gap)*1e6)))
 pcbnew.SaveBoard(str(boardpath),b)
 boardpath.with_suffix('.kicad_pro').write_bytes(basepro)
 rule='' if custom is None else '\n(rule "control_custom" (condition "A.NetName == \'remote_high_T\'") (constraint clearance (min '+str(custom)+'mm)))\n'
 boardpath.with_suffix('.kicad_dru').write_text(basedru+rule)
 del pad,fp,b
 reopen=pcbnew.LoadBoard(str(boardpath)); f=next(f for f in reopen.GetFootprints() if f.GetReference()=='X1'); p=next(p for p in f.Pads() if p.GetNumber()=='3')
 observed={'pad_local':p.GetLocalClearance(),'fp_local':f.GetLocalClearance(),'native_class':p.GetNetClassName()}; assert observed['pad_local']==(None if padval is None else round(padval*1e6)); assert observed['fp_local']==(None if fpval is None else round(fpval*1e6));del p,f,reopen
 argv=['kicad-cli','pcb','drc','--severity-all','--all-track-errors','--exit-code-violations','--format','json','-o',str(d/'drc.json'),str(boardpath)]
 t=time.monotonic();receipt={'argv':argv,'start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(O),'timeout_seconds':40}
 with (d/'stdout').open('wb') as so,(d/'stderr').open('wb') as se:
  child=subprocess.Popen(argv,stdout=so,stderr=se);receipt['pid']=child.pid
  try:receipt['rc']=child.wait(timeout=40)
  except subprocess.TimeoutExpired:child.kill();receipt['rc']=child.wait();receipt['timed_out']=True
 receipt.update(end=datetime.datetime.now(datetime.timezone.utc).isoformat(),duration_seconds=time.monotonic()-t)
 (d/'process.json').write_text(json.dumps(receipt,indent=2)+'\n')
 report=json.loads((d/'drc.json').read_text());target=[]
 for v in report['violations']:
  desc=[x['description'] for x in v.get('items',[])]
  if any('Track [remote_high_T]' in s for s in desc) and any('Pad 3 [remote_high_B]' in s for s in desc):target.append(v)
 row={'case':name,'pad_mm':padval,'fp_mm':fpval,'custom_mm':custom,'gap_mm':gap,'reopened':observed,'target_expected_violation':want,'target_findings':target,'all_violations':len(report['violations']),'unconnected':len(report['unconnected_items']),'process':receipt,'property_pass':bool(target)==want and not report['unconnected_items']}
 rows.append(row);print(json.dumps(row),flush=True)
(O/'native-controls.json').write_text(json.dumps(rows,indent=2)+'\n'); assert all(r['property_pass'] for r in rows)
