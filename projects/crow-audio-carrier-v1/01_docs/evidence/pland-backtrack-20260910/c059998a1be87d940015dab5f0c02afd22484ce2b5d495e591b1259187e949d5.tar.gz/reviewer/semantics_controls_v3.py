import pathlib,json,sys,subprocess,time,datetime,os
import pcbnew
O=pathlib.Path(__file__).parent;source=O/'extracted/evaluator/reviewer/base/matrix.kicad_pcb';sys.path.insert(0,str(O/'extracted/kernel/unadopted-live/skills/kicad-pcb/scripts'));import land_witness as w
cases=[('case_insensitive',"A.NetName == 'REMOTE_HIGH_T'",None,True),('bracket_literal',"A.NetName == 'remote_high_[T]'",None,False),('mixed_and_or',"A.NetName == 'NEVER' && A.Type == 'Track' || A.NetName == 'remote_high_T'",None,None),('area_touch',"A.NetName == 'remote_high_T' && A.insideArea('CONTRACT_TOUCH')",100000,False),('area_overlap_1iu',"A.NetName == 'remote_high_T' && A.insideArea('CONTRACT_TOUCH')",99999,False),('area_overlap_2um',"A.NetName == 'remote_high_T' && A.insideArea('CONTRACT_TOUCH')",98000,True)]
rows=[json.loads(line) for line in (O/"semantics-controls.stdout").read_text().splitlines() if line.startswith(chr(123))]
cases=cases[3:]
for name,cond,bottom,want in cases:
 d=O/'semantics-controls'/name;d.mkdir(parents=True,exist_ok=True);p=d/'matrix.kicad_pcb';b=pcbnew.LoadBoard(str(source))
 if bottom is not None:
  z=pcbnew.ZONE(b);z.SetIsRuleArea(True);z.SetZoneName('CONTRACT_TOUCH');z.SetLayer(pcbnew.F_Cu);z.SetDoNotAllowTracks(False);z.SetDoNotAllowVias(False);z.SetDoNotAllowZoneFills(False);z.SetDoNotAllowPads(False);z.SetDoNotAllowFootprints(False);poly=z.Outline();poly.NewOutline()
  for x,y in [(10400000,10000000+bottom),(10600000,10000000+bottom),(10600000,10300000),(10400000,10300000)]:poly.Append(x,y)
  b.Add(z)
 epsilon=b.GetDesignSettings().GetDRCEpsilon();pcbnew.SaveBoard(str(p),b);p.with_suffix('.kicad_pro').write_bytes(source.with_suffix('.kicad_pro').read_bytes());p.with_suffix('.kicad_dru').write_text(source.with_suffix('.kicad_dru').read_text()+'\n(rule "contract_semantics" (condition '+json.dumps(cond)+') (constraint track_width (min 0.4mm)))\n')
 argv=['kicad-cli','pcb','drc','--severity-all','--all-track-errors','--exit-code-violations','--format','json','-o',str(d/'drc.json'),str(p)];t=time.monotonic();receipt={'argv':argv,'cwd':str(O),'start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout_seconds':40}
 with (d/'stdout').open('wb') as so,(d/'stderr').open('wb') as se:
  child=subprocess.Popen(argv,stdout=so,stderr=se);receipt['pid']=child.pid;receipt['rc']=child.wait(timeout=40)
 receipt.update(end=datetime.datetime.now(datetime.timezone.utc).isoformat(),duration_seconds=time.monotonic()-t);(d/'process.json').write_text(json.dumps(receipt,indent=2)+'\n');r=json.loads((d/'drc.json').read_text());target=[v for v in r['violations'] if v['type']=='track_width' and any('Track [remote_high_T]' in x['description'] for x in v['items'])]
 try:old=w.specified_track_witness(p,p.with_suffix('.kicad_dru'),('X1','1'),(10,10),(11,10),.2)
 except Exception as e:old={'error':repr(e)}
 row={'case':name,'condition':cond,'epsilon_iu':epsilon,'native_target':target,'expected_target':want,'all_violations':len(r['violations']),'opens':len(r['unconnected_items']),'wip':old};rows.append(row);print(json.dumps(row),flush=True)
(O/'semantics-controls.json').write_text(json.dumps(rows,indent=2)+'\n')
assert all(x['expected_target'] is None or bool(x['native_target'])==x['expected_target'] for x in rows)
