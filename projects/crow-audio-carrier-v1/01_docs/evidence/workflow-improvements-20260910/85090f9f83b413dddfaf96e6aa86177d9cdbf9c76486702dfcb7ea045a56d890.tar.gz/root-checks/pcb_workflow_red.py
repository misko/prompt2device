import importlib.util, subprocess, sys, tempfile, runpy
from pathlib import Path
root=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
old=subprocess.check_output(['git','show',sys.argv[1]+':skills/pcb-design/scripts/pipeline_runtime.py'],cwd=root)
path=Path(tempfile.mkdtemp(prefix='pcb-workflow-red-'))/'pipeline_runtime.py';path.write_bytes(old)
sys.path.insert(0,str(root/'skills/pcb-design/scripts'))
spec=importlib.util.spec_from_file_location('pipeline_runtime',path)
module=importlib.util.module_from_spec(spec);sys.modules['pipeline_runtime']=module;spec.loader.exec_module(module)
sys.argv=['t1_pipeline_runtime.py','--only='+sys.argv[2]]
runpy.run_path(str(root/'tests/t1_pipeline_runtime.py'),run_name='__main__')
