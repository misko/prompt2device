from pathlib import Path
import sys, shutil, tempfile, json, hashlib, os
from datetime import datetime,timedelta,timezone
repo=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
sys.path.insert(0,str(repo/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import execute_attempt
root=Path(tempfile.mkdtemp(prefix='pcb-workflow-carrier-canary-'))
for suffix in ('pcb','pro','dru','sch'):
 source=repo/f'projects/crow-audio-carrier-v1/04_kicad/crow_audio_carrier_v1.kicad_{suffix}'
 shutil.copy2(source,root/source.name)
producer=root/'producer.py'
producer.write_text('''import os,json,sys
from pathlib import Path
import pcbnew
sys.path.insert(0, %r)
from pipeline_runtime import run_stage
out=Path(os.environ['PCB_TASK_OUTPUT_DIR']); scratch=Path(os.environ['PCB_TASK_SCRATCH_DIR'])
board=Path('crow_audio_carrier_v1.kicad_pcb').resolve()
r=run_stage({'id':'PCB-COMMISSION','work_class':'local','timeout_s':60},
 ['kicad-cli','pcb','drc','--severity-all','--all-track-errors','--schematic-parity',
 '--exit-code-violations','--format','json','-o',str(out/'drc.json'),str(board)],
 log_path=scratch/'native.log',console=None)
(scratch/'native-runtime.json').write_text(json.dumps(r.to_mapping()))
if r.status not in ('PASS','FAIL') or r.returncode not in (0,5):
 raise RuntimeError('native process incomplete')
d=json.loads((out/'drc.json').read_text()); b=pcbnew.LoadBoard(str(board))
census={'footprints':len(list(b.GetFootprints())), 'pads':sum(len(list(f.Pads())) for f in b.GetFootprints()),
 'tracks':len(list(b.GetTracks())), 'violations':len(d['violations']),
 'unconnected':len(d['unconnected_items']), 'parity':len(d['schematic_parity']),
 'native_exit_code':r.returncode, 'native_domain_status': 'PASS' if r.returncode==0 else 'FAIL'}
(out/'census.json').write_text(json.dumps(census,sort_keys=True))
(out/'result.json').write_text(json.dumps({'subject':json.loads(os.environ['PCB_TASK_SUBJECT_JSON']),
 'checks':{'native-report-complete':'PASS'},'unresolved':[]}))
print(json.dumps(census,sort_keys=True))
''' % str(repo/'skills/pcb-design/scripts'))
files=sorted(root.iterdir())
packet=[dict(name=f'input_{i}',path=p.name,size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for i,p in enumerate(files)]
subject=subject_identity('carrier-canary',1,[TypedIdentityInput('files','mapping',{'files':packet},json.dumps(packet).encode())])
e=TaskEnvelope(schema=2,task_id='carrier-canary',stage_id='PCB-COMMISSION',run_id='carrier-canary',subject=subject,
 executor='subprocess',execution_class='local',recommended_agent_role=None,agent_role=None,role_escalation_reason=None,
 context_mode='NOT_APPLICABLE',input_handoff_id=None,input_packet=packet,
 deadline_at=(datetime.now(timezone.utc)+timedelta(seconds=90)).isoformat().replace('+00:00','Z'),
 max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'EXCLUSIVE','paths':['crow_audio_carrier_v1.kicad_prl']},
 output_path='06_build/task_runs/carrier-canary/attempt.json',completion={'outputs':['census.json','drc.json'],'checks':['native-report-complete']})
r=execute_attempt(e,['/usr/bin/python3',str(producer)],cwd=root,env={k:os.environ[k] for k in ('PATH','HOME','LANG') if k in os.environ},console=None)
print(root);print(r.status);print(r.unresolved)
if r.status!='PASS':sys.exit(1)
out=root/Path(e.output_path).parent/'outputs'
census=json.loads((out/'census.json').read_text())
comparison={'producer_executions':1,'legacy_process_outcome':r.output['runtime']['status'],
 'validated_delivery_outcome':r.status,'native_domain_status':census['native_domain_status'],
 'census':census,'live_board_unchanged':all(hashlib.sha256((repo/'projects/crow-audio-carrier-v1/04_kicad'/p.name).read_bytes()).hexdigest()==hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.name!='producer.py')}
(root/'comparison.json').write_text(json.dumps(comparison,indent=2)+'\n');print(json.dumps(comparison))
