import os,json,sys
from pathlib import Path
import pcbnew
sys.path.insert(0, '/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_runtime import run_stage
out=Path(os.environ['PCB_TASK_OUTPUT_DIR']); scratch=Path(os.environ['PCB_TASK_SCRATCH_DIR'])
board=Path('crow_audio_carrier_v1.kicad_pcb').resolve()
r=run_stage({'id':'PCB-COMMISSION','work_class':'local','timeout_s':60},
 ['kicad-cli','pcb','drc','--severity-all','--all-track-errors','--schematic-parity',
 '--exit-code-violations','--format','json','-o',str(out/'drc.json'),str(board)],
 log_path=scratch/'native.log',console=None)
(scratch/'native-runtime.json').write_text(json.dumps(r.to_mapping()))
if r.status not in ('PASS','FAIL') or r.returncode not in (0,5):
 raise RuntimeError('native process incomplete')
d=json.loads((out/'drc.json').read_text()); b=pcbnew.LoadBoard(str(board))
census={'footprints':len(list(b.GetFootprints())), 'pads':sum(len(list(f.Pads())) for f in b.GetFootprints()),
 'tracks':len(list(b.GetTracks())), 'violations':len(d['violations']),
 'unconnected':len(d['unconnected_items']), 'parity':len(d['schematic_parity']),
 'native_exit_code':r.returncode, 'native_domain_status': 'PASS' if r.returncode==0 else 'FAIL'}
(out/'census.json').write_text(json.dumps(census,sort_keys=True))
(out/'result.json').write_text(json.dumps({'subject':json.loads(os.environ['PCB_TASK_SUBJECT_JSON']),
 'checks':{'native-report-complete':'PASS'},'unresolved':[]}))
print(json.dumps(census,sort_keys=True))
