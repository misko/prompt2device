import json, os, sys
from pathlib import Path
p=Path(os.environ['PCB_TASK_OUTPUT_DIR'])
q=json.loads(Path(sys.argv[1]).read_text())
assert q['status']=='PASS'
s=json.loads(Path('subject.json').read_text())
(p/'report.md').write_text('# Bounded environment report\n\nNative compatibility: '+q['native']['status']+'\nRepository audits: '+q['repository']['status']+'\nReviewer availability: '+q['reviewer']['status']+'\n\nThis report proves delivery only. No device or release acceptance.\n')
(p/'result.json').write_text(json.dumps({'subject':s,'checks':{'report-delivered':'PASS'},'unresolved':[]}))
print('Produced report.md and exact-subject result.json')
