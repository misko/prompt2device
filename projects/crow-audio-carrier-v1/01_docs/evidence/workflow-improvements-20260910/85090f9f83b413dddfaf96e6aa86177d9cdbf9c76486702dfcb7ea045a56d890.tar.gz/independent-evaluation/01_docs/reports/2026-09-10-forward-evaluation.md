---
schema: 1
kind: pcb-human-report
report_id: 2026-09-10-forward-evaluation
title: Independent bounded PCB workflow evaluation
subtitle: Native qualification, report delivery, and same-owner setup recovery in scratch
project: pcb-forward-evaluation-8ljwYv
date: 2026-09-10
status: DRAFT
evidence_status: INCOMPLETE
---

## Executive conclusion

**MEASURED:** The realistic forward workflow succeeded in an isolated scratch project: native qualification PASS, two repository compatibility audits PASS, and bounded report delivery PASS after one preserved setup failure. The recovered task delivered its declared report and exact-subject handback, with a 1/1 completion check census. Reopening the attempt chain confirmed 10/10 ownership, identity, deadline, and accounting invariants. No runtime correctness defect was established by this narrow evaluation.

**OWED:** These outcomes establish tool compatibility and delivery consistency only. Reviewer availability remains UNKNOWN. No device, schematic, PCB, release, publication, or physical acceptance was attempted or adopted. The host assigned this independent evaluator directly; it was not a qualified agent-open/agent-close reviewer probe. No child agents were launched.

## Question and scope

Original request, preserved verbatim in [BRIEF.md](../BRIEF.md): “Qualify my tool environment, run a small bounded task that produces a report, and recover from an ordinary setup error while preserving the task's evidence and ownership.”

**MEASURED:** Scratch root is `/tmp/pcb-forward-evaluation-8ljwYv`. Executed repository tooling came from `/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901`. All intentional writes were in scratch. The evaluator did not edit live repository source, product boards, or releases. Qualification generated its independent native fixture in scratch.

The selected bounded task used stage identifier `PCB-COMMISSION` solely as its execution label. It did not commission a product. No product target, source commit, seal commit, or release path applies. The scratch Git index exists only to validate report links; no release authority or repository change was created.

## Evidence boundary

**MEASURED:** The [qualification receipt](../../06_build/task_runs/qualify-ce9c8a2da5144b5b93ff53d1b858dec8/qualification.json) binds actual executable, imported module/library, configuration, and runtime source fingerprints. Native versions include pcbnew 10.0.4 and Python 3.12.3. The native probe ran fresh, with `cached: false`, from 2026-09-11T01:50:33.928814Z to 01:50:35.474592Z (September 10 in the user's timezone).

The bounded task's semantic subject is `be0aea3e0a644d4c69b7be624e809bbad5aa9927b9496066efcbda864f8fbbe7`; raw subject is `38175339e3083e405bd42cc1efadb560285f3f0e54813440980294b1c6413c35`. The [original allocated envelope](../../06_build/task_runs/report-evaluation-5d99ef586800478e9e57a01cca7c3a28/envelope.json) bound brief, producer, qualification receipt, and subject bytes. Writer scope was READ_ONLY, with runtime-owned output/scratch directories. Same-owner policy admitted two total executions and the `wrong_cwd` setup remedy before launch.

**OWED:** This runtime is bounded and detects project writes after execution; it is not a hermetic sandbox. This evaluation did not test hostile network access, foreign-session process escape, or every engineering stage. The report's DRAFT and INCOMPLETE labels preserve these limits.

## Findings

| Observed check | Result and denominator | Meaning |
|---|---|---|
| **MEASURED:** Native clean/hostile fixture | PASS, 2/2 fixture cases | Both serialize and reload two netclasses. Clean has 0 clearance findings; hostile has 1 involving identified J1.1/J2.1 pads. |
| **MEASURED:** Repository compatibility | PASS, 2/2 audits | Contract and authority audits pass; does not grade a product. |
| **MEASURED:** Initial task | FAIL, attempt index 0 | Actual FileNotFoundError from wrong relative input path; child rc=1, CLI rc=2; 703 log bytes retained. |
| **MEASURED:** Assessment validation | Refused before dispatch | Evidence name `failed-path-lookup` violates PacketItem's underscore-only name grammar. Original invalid assessment and failed invocation remain available. |
| **MEASURED:** Same-owner repair | PASS, attempt index 1, 1/1 delivery checks | Corrected relative input path; producer unchanged; report.md plus result.json delivered; 49 log bytes retained. |
| **MEASURED:** Chain verification | 10/10 assertions true | Task, subject, packet, deadline, scope, owner/hypothesis policy retained; predecessor digest valid; failure and nonimproving=1 retained. |
| **MEASURED:** Duplicate successor dispatch | Refused, CLI rc=1 | Existing repair claim prevents a second successor; no new producer execution. |
| **OWED:** Engineering acceptance | No domain items graded | No denominator was converted into an engineering PASS. |

Actual primary commands, with the shell working directory independent of the project argument:

```text
python3 /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/kicad-pcb/scripts/pcb_flow.py qualify /tmp/pcb-forward-evaluation-8ljwYv --timeout-s 90
# rc=0, status PASS; reviewer UNKNOWN

python3 /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/kicad-pcb/scripts/pcb_flow.py task-run /tmp/pcb-forward-evaluation-8ljwYv --envelope /tmp/pcb-forward-evaluation-8ljwYv/task-envelope.json -- /usr/bin/python3 producer.py wrong-working-directory/qualification.json
# rc=2, task FAIL, original evidence retained
```

The exact full repair argv and rc=0 stdout/stderr are in [repair-valid-command.json](../../repair-valid-command.json). Its only producer argument change selected the real retained qualification path. The assessment's evidence-token correction was a pre-dispatch schema fix, not a charged producer retry or a bypass of failed evidence. No accepted output existed before this task; both attempt directories remain intact.

The evaluator read the complete skill, execution-runtime, execution-graph, project-reports, and report contract, then inspected `pcb_flow.py --help`, `qualify --help`, `task-run --help`, `task-repair --help`, and `project_report_audit.py --help`. Schema construction required consulting repository examples in `tests/t1_pipeline_runtime.py` and `pipeline_execution.py`.

## Recommendations

1. **PROPOSED, P2 usability:** Add one complete schema-2 task envelope plus repair assessment example to execution-runtime.md, or provide a non-authoritative envelope construction command. The existing prose names fields but omits the base schema, subject construction, and PacketItem name grammar; the first-time evaluator had to read tests/source. Explicitly distinguish hyphen-capable task/check identifiers from underscore-only PacketItem names. Tradeoff: examples need schema tests to prevent drift.
2. **PROPOSED, P3 documentation:** Show `-- COMMAND [ARGS...]` in task-run/task-repair help and add a short example. Current help omits the mandatory producer command even though the skill makes CLI help the syntax authority. The command works when the reference's separator instruction is followed.
3. **PROPOSED, P3 diagnosis:** Replace duplicate-repair raw `File exists: .../.repair-claim.json` with “predecessor already claimed” and the successor attempt path. The refusal is correct; a clearer message would make ownership recovery easier without weakening admission.

These are workflow/documentation findings, not evidence that a domain check can be bypassed. No live repository fix was attempted because the parent retained sole write ownership. After this evaluation, the parent reported that PacketItem name syntax was clarified and that runtime campaign admission now binds stage/subject/hypothesis against task/owner relabeling. Those subsequent changes were not re-evaluated here; the complete-envelope example, CLI command-help, and duplicate-claim diagnostic remain recommendations. This report does not certify the newer campaign guard.

## Validation plan

**OWED:** A new evaluator should be able to produce and repair a declared-output task from only SKILL.md, its selected runtime reference, and CLI help. Falsify recommendation 1 by supplying complete currently documented schema instructions without consulting tests/source. Verify future help includes the command separator, then run its example verbatim.

**MEASURED:** Reopened both attempt JSON files and envelopes after repair; checked exact predecessor hash and 10 invariants in [chain-verification.json](../../chain-verification.json). Repeated the same predecessor repair to establish single-successor refusal. Read the delivered Markdown directly; it accurately separates tool PASS and reviewer UNKNOWN from domain acceptance. The formal human report audit command is recorded in the source register; its result is retained beside this scratch project report.

**OWED:** Independently qualify a fresh host reviewer before engineering review. Run the relevant owning domain gates on exact product bytes before any design or release claim. Preserve this complete attempt chain before deleting scratch/build evidence.

## Source register

- [Source provenance](../../source-provenance.json): repository HEAD and qualification identity caveat for uncommitted source.
- [Qualification receipt](../../06_build/task_runs/qualify-ce9c8a2da5144b5b93ff53d1b858dec8/qualification.json): exact tool/runtime fingerprints and two audit records.
- [Native fixture outcomes](../../06_build/task_runs/qualify-ce9c8a2da5144b5b93ff53d1b858dec8-native/outputs/native.json): clean and hostile findings with pad identifiers.
- [Initial failed attempt](../../06_build/task_runs/report-evaluation-5d99ef586800478e9e57a01cca7c3a28/attempt.json) and [lossless failure log](../../06_build/task_runs/report-evaluation-5d99ef586800478e9e57a01cca7c3a28/attempt.json.log).
- [Rejected assessment command](../../repair-command.json), [initial assessment](../../repair-assessment.json), and [valid assessment](../../repair-assessment-valid.json).
- [Successful repair attempt](../../06_build/task_runs/report-evaluation-bd5da2f7a38a42a7a1f258ada352505e/attempt.json), [allocated successor envelope](../../06_build/task_runs/report-evaluation-bd5da2f7a38a42a7a1f258ada352505e/envelope.json), and [delivered report](../../06_build/task_runs/report-evaluation-bd5da2f7a38a42a7a1f258ada352505e/outputs/report.md).
- [Duplicate successor refusal](../../duplicate-repair-command.json) and [chain checks](../../chain-verification.json).
- [Report contract](contracts.md), copied verbatim from the skill-owned template for this scratch project.
- Audit command: `python3 /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts/project_report_audit.py /tmp/pcb-forward-evaluation-8ljwYv/01_docs/reports/2026-09-10-forward-evaluation.md`.
