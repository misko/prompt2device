Qualify my tool environment, run a small bounded task that produces a report, and recover from an ordinary setup error while preserving the task's evidence and ownership.
