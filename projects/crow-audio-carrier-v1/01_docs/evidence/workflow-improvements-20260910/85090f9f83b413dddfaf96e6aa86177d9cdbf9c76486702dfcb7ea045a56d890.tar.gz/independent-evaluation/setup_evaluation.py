import json, hashlib, sys, subprocess
from pathlib import Path
from datetime import datetime, timezone, timedelta
root=Path(__file__).parent
repo=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
sys.path.insert(0,str(repo/'skills/pcb-design/scripts'))
from pipeline_identity import subject_identity, TypedIdentityInput
from pipeline_execution import TaskEnvelope
brief="Qualify my tool environment, run a small bounded task that produces a report, and recover from an ordinary setup error while preserving the task's evidence and ownership."
(root/'01_docs').mkdir(exist_ok=True)
(root/'01_docs/BRIEF.md').write_text(brief+'\n')
subject=subject_identity('forward-evaluation',1,[TypedIdentityInput('brief','mapping',{'brief':brief},brief.encode())]).to_mapping()
(root/'subject.json').write_text(json.dumps(subject))
qualification=next(root.glob('06_build/task_runs/qualify-*/qualification.json'))
producer='''import json, os, sys\nfrom pathlib import Path\np=Path(os.environ['PCB_TASK_OUTPUT_DIR'])\nq=json.loads(Path(sys.argv[1]).read_text())\nassert q['status']=='PASS'\ns=json.loads(Path('subject.json').read_text())\n(p/'report.md').write_text('# Bounded environment report\\n\\nNative compatibility: '+q['native']['status']+'\\nRepository audits: '+q['repository']['status']+'\\nReviewer availability: '+q['reviewer']['status']+'\\n\\nThis report proves delivery only. No device or release acceptance.\\n')\n(p/'result.json').write_text(json.dumps({'subject':s,'checks':{'report-delivered':'PASS'},'unresolved':[]}))\nprint('Produced report.md and exact-subject result.json')\n'''
(root/'producer.py').write_text(producer)
packet=[]
for name,path in [('brief',root/'01_docs/BRIEF.md'),('producer',root/'producer.py'),('qualification',qualification),('subject',root/'subject.json')]:
 b=path.read_bytes();packet.append({'name':name,'path':str(path.relative_to(root)),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
envelope=TaskEnvelope(schema=2,task_id='bounded-report',stage_id='PCB-COMMISSION',run_id='report-evaluation',subject=subject,executor='subprocess',execution_class='local',recommended_agent_role=None,agent_role=None,role_escalation_reason=None,context_mode='NOT_APPLICABLE',input_handoff_id=None,input_packet=packet,deadline_at=(datetime.now(timezone.utc)+timedelta(seconds=180)).isoformat().replace('+00:00','Z'),max_nonimproving_attempts=3,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path='06_build/task_runs/report-evaluation/attempt.json',completion={'outputs':['report.md'],'checks':['report-delivered']},repair={'owner_id':'workflow-forward-evaluation','hypothesis_sha256':hashlib.sha256(b'Correct input pathname permits qualified environment report delivery').hexdigest(),'max_attempts':2,'setup_remedies':['wrong_cwd'],'finding_id':None})
(root/'task-envelope.json').write_text(envelope.to_json())
(root/'selected-input.txt').write_text(str(qualification.relative_to(root)))
print('Prepared schema-2 task envelope, producer, and bound inputs')
