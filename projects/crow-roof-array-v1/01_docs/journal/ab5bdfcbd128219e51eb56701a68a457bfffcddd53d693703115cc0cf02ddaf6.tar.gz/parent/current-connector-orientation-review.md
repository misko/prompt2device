# Connector orientation review — top-only carrier and pod

The user approved these current connector orientations on 2026-09-14 UTC: “All connectors look great!” Both owning orientation gates accepted that confirmation against the exact subjects and images below.

Both boards place all fitted SMD parts on top. Factory Cat6A RJ45 patch cords carry custom analog/DC here, not Ethernet or PoE. Mate with power off. This confirmation covers orientation; it does not establish physical cable fit or approve a completed release.

## Carrier

Exact review subject: `be323026cc8a14092edb7d75aae8508759108c25b504794df5aa2b2fb3458d45`.

J1–J4 form the north RJ45 row; J5–J8 form the south row. J9 is the west-facing power connector. Its current mating face is approximately 3.08 mm inside the west board edge; inspect the cable approach in its views.

### J1, J2, J3, J4 — representative J1

![Carrier J1: Top and cable direction](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J1_top.png)

![Carrier J1: Cable-facing mouth and keying](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J1_outside.png)

![Carrier J1: Rear of connector](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J1_inside.png)

### J5, J6, J7, J8 — representative J5

![Carrier J5: Top and cable direction](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J5_top.png)

![Carrier J5: Cable-facing mouth and keying](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J5_outside.png)

![Carrier J5: Rear of connector](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J5_inside.png)

### J9 — representative J9

![Carrier J9: Top and cable direction](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J9_top.png)

![Carrier J9: Cable-facing mouth and keying](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J9_outside.png)

![Carrier J9: Rear of connector](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J9_inside.png)

![Carrier J9: First side profile](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J9_profile_a.png)

![Carrier J9: Opposite side profile](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J9_profile_b.png)

## Pod

Exact review subject: `54ff09c6c9f55e8d467b35ad346f3dfdd715c9a1a5aa7029ebe9dab931e200b6`.

### J1 — representative J1

![Pod J1: Top and cable direction](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-mic-pod-v3/06_build/pre_route/orientation/views/J1_top.png)

![Pod J1: Cable-facing mouth and keying](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-mic-pod-v3/06_build/pre_route/orientation/views/J1_outside.png)

![Pod J1: Rear of connector](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-mic-pod-v3/06_build/pre_route/orientation/views/J1_inside.png)

![Pod J1: First side profile](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-mic-pod-v3/06_build/pre_route/orientation/views/J1_profile_a.png)

![Pod J1: Opposite side profile](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-mic-pod-v3/06_build/pre_route/orientation/views/J1_profile_b.png)

