from pathlib import Path
import pcbnew,json,re,math,hashlib
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-mic-pod-v3';T=P/'06_build/release_twin/v0.2.0-2026-09-15';S=Path('/tmp/pod-twin-completion');B=P/'04_kicad/crow_mic_pod_v3.kicad_pcb'
b=pcbnew.LoadBoard(str(B));out={'board_sha256':hashlib.sha256(B.read_bytes()).hexdigest(),'parts':{}}
for ref,code,inner,outer,half in [('D1','C144860',.945,2.64,.825),('D2','C83846',1.085,2.795,1.1)]:
 f=b.FindFootprintByReference(ref);f.SetOrientationDegrees(0);f.SetPosition(pcbnew.VECTOR2I(0,0));pads=[];margins=[]
 for p in f.Pads():
  cx,cy=p.GetPosition().x/1e6,p.GetPosition().y/1e6;sx,sy=p.GetSize().x/1e6,p.GetSize().y/1e6;r=p.GetRoundRectCornerRadius()/1e6
  pads.append({'number':p.GetNumber(),'center':[cx,cy],'size':[sx,sy],'radius':r,'net':p.GetNetname()})
  for x in ((-outer,-inner) if cx<0 else (inner,outer)):
   for y in (-half,half):
    qx=abs(x-cx)-(sx/2-r);qy=abs(y-cy)-(sy/2-r);margins.append(-(math.hypot(max(qx,0),max(qy,0))+min(max(qx,qy),0)-r))
 w=next((T/'easyeda'/code/'jlc.3dshapes').glob('*.wrl'));meshes=[]
 for i,s in enumerate(w.read_text().split('Shape{')[1:]):
  match=re.search(r'point\s*\[([^]]*)\]',s,re.S);pts=[[float(x)*2.54 for x in a.strip().split()] for a in match[1].split(',') if a.strip()]
  color=re.search(r'diffuseColor\s+([^\n]+)',s)[1].strip();bb=[[min(v[a] for v in pts),max(v[a] for v in pts)] for a in range(3)]
  meshes.append({'index':i,'color':color,'bbox_mm':bb,'vertices':len(pts)})
 out['parts'][ref]={'pads':pads,'terminal_envelope':{'inner':inner,'outer':outer,'half_width':half},'corner_aware_min_margin_mm':min(margins),'model_path':str(w),'model_sha256':hashlib.sha256(w.read_bytes()).hexdigest(),'meshes':meshes}
for ref in ('J1','U2'):
 f=b.FindFootprintByReference(ref);rows=[]
 for m in f.Models():
  p=Path(m.m_Filename.replace('${KIPRJMOD}',str(B.parent)))
  rows.append({'path':m.m_Filename,'resolved':str(p.resolve()),'exists':p.is_file(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None,'offset':[m.m_Offset.x,m.m_Offset.y,m.m_Offset.z],'rotation':[m.m_Rotation.x,m.m_Rotation.y,m.m_Rotation.z],'scale':[m.m_Scale.x,m.m_Scale.y,m.m_Scale.z]})
 out['parts'][ref]={'models':rows}
(S/'measurements.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
