from pathlib import Path
import re,json,math
S=Path(__file__).parent;m=json.loads((S/'measurements.json').read_text());out={}
for ref in ('D1','D2'):
 d=m['parts'][ref];s=Path(d['model_path']).read_text().split('Shape{')[2];pts=[[float(x)*2.54 for x in a.strip().split()] for a in re.search(r'point\s*\[([^]]*)\]',s,re.S)[1].split(',') if a.strip()];rows=[]
 for sign in (-1,1):
  v=[p for p in pts if p[0]*sign>0];p=d['pads'][0 if sign<0 else 1];cx,cy=p['center'];sx,sy=p['size'];r=p['radius'];margins=[]
  for x,y,z in v:
   qx=abs(x-cx)-(sx/2-r);qy=abs(y-cy)-(sy/2-r);margins.append(-(math.hypot(max(qx,0),max(qy,0))+min(max(qx,qy),0)-r))
  bbox=[[min(q[a] for q in v),max(q[a] for q in v)] for a in range(3)];rows.append({'sign':sign,'bbox_mm':bbox,'x_center':sum(bbox[0])/2,'native_center_x':cx,'min_projected_copper_margin_mm':min(margins),'all_vertices_contained':min(margins)>=0})
 out[ref]=rows
(S/'terminal-mesh.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
