from pathlib import Path
from datetime import datetime,timezone,timedelta
import sys,json,hashlib,shutil,tempfile
sys.dont_write_bytecode=True
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
name='rj45-jack-fab-source-review';assert not (N/(name+'-opened.json')).exists()
author=json.loads((N/'rj45-jack-fab-feature-source-opened.json').read_text())
probe=json.loads((N/'rj45-jack-fab-source-review-availability-opened.json').read_text())
for m in [author,probe]:assert json.loads(Path(m['attempt']).read_text())['status']=='PASS'
assert (N/'rj45-jack-fab-feature-source-closeout-summary.json').is_file()
D=Path(tempfile.mkdtemp(prefix=name+'-'))
shutil.copytree(Path(author['project'])/'input',D/'input')
diagnosis=json.loads((N/'rj45-jack-envelope-diagnosis-opened.json').read_text())
assert json.loads(Path(diagnosis['attempt']).read_text())['status']=='PASS'
diag_root=Path(diagnosis['project'])
diag_envelope=json.loads(Path(diagnosis['envelope']).read_text())
for row in diag_envelope['input_packet']:
 if '/06_build/pre_route/native_registration/' in row['path']:
  p=diag_root/row['path'];b=p.read_bytes()
  assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256']
  q=D/row['path'];q.parent.mkdir(parents=True,exist_ok=True)
  assert not q.exists() or q.read_bytes()==b
  q.write_bytes(b)
shutil.copytree(Path(author['output_dir']),D/'author')
shutil.copy2(Path(author['envelope']),D/'author-envelope.json')
shutil.copy2(N/'rj45-jack-fab-feature-source-closeout-summary.json',D/'author-closeout.json')
shutil.copy2(Path(author['project'])/'preflight.py',D/'preflight.py')
now=datetime.now(timezone.utc);cut=now+timedelta(minutes=20);hard=now+timedelta(minutes=30)
(D/'TASK.md').write_text('''# Independent exact shared RJ45 Fab source review

Fresh READ_ONLY engineering judgment after actual author FINAL/closure and
fresh live delivery qualification. Root owns live source; input/ and author/
are immutable. Scratch measurements only; no children/replacements/source
repairs/Git/live edits. Work cutoff CUT; hard HARD. Deliver complete honest
five-file handback and actual FINAL promptly. Prior source, model and camera
campaign budgets remain unchanged; do not authorize a new geometry search.

Read CLAUDE, applicable canon/runtime/PCB skill, digital-twin and tests contract.
Reopen exact source candidate and all author archive members against manifest;
independently verify live preimages for changed files. Judge actual bytes, not
the author's verdict. Source scope is faithful nominal CAD spring-finger plan
detail in both identical Wurth615008160221 F.Fab footprints, retained nominal
shell rectangle and courtyard, matching exact-part provenance. All physical
model/pad/drill/copper/silk/position/transform/tolerance/camera source remains
unchanged. native_model_registration.py may change only its module docstring
to declare measured sampling vacuity; extraction/threshold/wrapper/approval
semantics are unchanged. Corresponding one new maintained vacuity fixture,
tests README and relevant reference prose may change. Report any deviation.

Primary drawing p1 dimensions main shell15x13.45x14.7mm and depicts exterior
free fingers; the full finger span is not dimensioned. Official unchanged
STEP supplies nominal CAD coordinates. Verify actual feature detail rather
than blessing an enlarged arbitrary box. M1 permits distinct BRep/drawing and
native raster methods; it does not turn nominal CAD into manufactured tolerance.
Inspect actual PDF and native geometry. Independently check the nominal shell,
all physical drill/slot/post/signal identities, both source footprints, all9
board instances and full occupied envelope against unchanged courtyard.
Carrier4instances180deg versus coupon0deg must remain explicit. Thin free tips
can have only0.001919mm nominal courtyard margin; do not claim physical clearance
or tolerance qualification. Preserve existing first-article obligations.

Assess the complete paired-control behavior. Original pod measured1.059223mm
Fab excursion; original carrier loses7934real lateral finger pixels under
fixed2pxerosion. New native Fab union includes outside details; nominal shell
recognition is not a newly established universal machine property. Exact-product
supplemental proof must independently retain shell/hole registration and full
extent on all9instances, even where eroded raster omits fingers. A real thin
feature outside courtyard must fail that supplemental method or be INCOMPLETE,
not inherit ordinary pixel PASS. Independently challenge a translated model
against the unchanged physical datums/containment. Never derive measured body
from expected Fab or clip pixels to expectation. Current ordinary P-MODEL-REG
still must pass after accepted source; supplemental evidence cannot skip it.

Verify native fixture reality for the new declared blind spot: first assertion
must establish falsePASS on a real thin exterior feature; a physically thick
same-extent contrast must FAIL. Inspect actual native construction/exports,
transforms/units and pixels, not intended fixture dimensions. Existing14tests
and original buried-model vacuity remain intact and pass. No required-fail
existing control may be reclassified. Confirm documentation/fixture bidirectional
binding through owning G-VACUOUS audit. Independently run focused maintained
model tests and meaningful exact-product native/hostile controls; reuse verified
unchanged evidence explicitly but do not substitute hashes for geometry judgment.
Missing-model/shift/scale/mount-side controls must retain applicable behavior.

Reopen normally generated source-candidate native boards and native DRC;
classify every remaining row and do not call unrouted connections clean.
Confirm copper/pads/positions/pin/nets and shell/mouth transforms unchanged.
Verify proposed source change does not silently alter model geometry, courtyard,
registration tolerance, hole floor or switch libraries. Assess footprint extent
effects on dependent orientation/twin/placement evidence. Current user approval
is absent/deferred; reviewer may not mint it. All downstream normal checkpoint,
schematic and placement renewals are still owed after root adoption.

No candidate edits in this review. Return SOUND or CORRECTION_REQUIRED with
exact files, measured scope, failures/limits and concrete next owner. Use
shared pipeline_runtime.run_stage for native/tests, explicit cwd/env,
/usr/bin/python3 -B, finite<=300s. Additional read-only dependencies from RROOT
must be hashed. Preserve failed runs and uncertainty. No render recipe sweep,
new source campaign or general CAD framework. Five outputs EXACTLY report.md,
evidence.json,evidence-manifest.json,evidence.tar.gz,result.json. domain_result
nonempty string separate from delivery. Archive new review methods/results/
native evidence only, reference original author archive; no nested archives.
Manifest archive_sha256/archive_size/member_count/members(path,size,sha256);
reopen every regular member and reject symlinks/traversal/duplicates. result
exact envelope subject/checks evidence-complete,inputs-verified,review-complete
for honest complete handback. Supplied preflight then actual FINAL. No live
adoption, routing/layout/release/order or physical acceptance.
'''.replace('CUT',cut.isoformat()).replace('HARD',hard.isoformat()).replace('RROOT',str(R)))
items=[]
for p in sorted(D.rglob('*')):
 if p.is_file():b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(D).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput,subject_identity
from pipeline_runtime import open_agent_attempt
s=subject_identity('jack_fab_source_review',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
e=TaskEnvelope(schema=2,task_id=name,stage_id='KICAD-PLACEMENT',run_id=name,subject=s,executor='agent',execution_class='review_wait',recommended_agent_role='judgment',agent_role='judgment',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']})
o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),agent_id='/root/carrier_rj45_jack_fab_source_review',work_cutoff=cut.isoformat())
(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2));print(len(items),'frozen inputs')
