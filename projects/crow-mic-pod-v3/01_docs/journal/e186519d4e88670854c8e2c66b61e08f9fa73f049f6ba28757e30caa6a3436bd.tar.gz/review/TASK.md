# Independent exact shared RJ45 Fab source review

Fresh READ_ONLY engineering judgment after actual author FINAL/closure and
fresh live delivery qualification. Root owns live source; input/ and author/
are immutable. Scratch measurements only; no children/replacements/source
repairs/Git/live edits. Work cutoff 2026-09-13T04:53:00.116093+00:00; hard 2026-09-13T05:03:00.116093+00:00. Deliver complete honest
five-file handback and actual FINAL promptly. Prior source, model and camera
campaign budgets remain unchanged; do not authorize a new geometry search.

Read CLAUDE, applicable canon/runtime/PCB skill, digital-twin and tests contract.
Reopen exact source candidate and all author archive members against manifest;
independently verify live preimages for changed files. Judge actual bytes, not
the author's verdict. Source scope is faithful nominal CAD spring-finger plan
detail in both identical Wurth615008160221 F.Fab footprints, retained nominal
shell rectangle and courtyard, matching exact-part provenance. All physical
model/pad/drill/copper/silk/position/transform/tolerance/camera source remains
unchanged. native_model_registration.py may change only its module docstring
to declare measured sampling vacuity; extraction/threshold/wrapper/approval
semantics are unchanged. Corresponding one new maintained vacuity fixture,
tests README and relevant reference prose may change. Report any deviation.

Primary drawing p1 dimensions main shell15x13.45x14.7mm and depicts exterior
free fingers; the full finger span is not dimensioned. Official unchanged
STEP supplies nominal CAD coordinates. Verify actual feature detail rather
than blessing an enlarged arbitrary box. M1 permits distinct BRep/drawing and
native raster methods; it does not turn nominal CAD into manufactured tolerance.
Inspect actual PDF and native geometry. Independently check the nominal shell,
all physical drill/slot/post/signal identities, both source footprints, all9
board instances and full occupied envelope against unchanged courtyard.
Carrier4instances180deg versus coupon0deg must remain explicit. Thin free tips
can have only0.001919mm nominal courtyard margin; do not claim physical clearance
or tolerance qualification. Preserve existing first-article obligations.

Assess the complete paired-control behavior. Original pod measured1.059223mm
Fab excursion; original carrier loses7934real lateral finger pixels under
fixed2pxerosion. New native Fab union includes outside details; nominal shell
recognition is not a newly established universal machine property. Exact-product
supplemental proof must independently retain shell/hole registration and full
extent on all9instances, even where eroded raster omits fingers. A real thin
feature outside courtyard must fail that supplemental method or be INCOMPLETE,
not inherit ordinary pixel PASS. Independently challenge a translated model
against the unchanged physical datums/containment. Never derive measured body
from expected Fab or clip pixels to expectation. Current ordinary P-MODEL-REG
still must pass after accepted source; supplemental evidence cannot skip it.

Verify native fixture reality for the new declared blind spot: first assertion
must establish falsePASS on a real thin exterior feature; a physically thick
same-extent contrast must FAIL. Inspect actual native construction/exports,
transforms/units and pixels, not intended fixture dimensions. Existing14tests
and original buried-model vacuity remain intact and pass. No required-fail
existing control may be reclassified. Confirm documentation/fixture bidirectional
binding through owning G-VACUOUS audit. Independently run focused maintained
model tests and meaningful exact-product native/hostile controls; reuse verified
unchanged evidence explicitly but do not substitute hashes for geometry judgment.
Missing-model/shift/scale/mount-side controls must retain applicable behavior.

Reopen normally generated source-candidate native boards and native DRC;
classify every remaining row and do not call unrouted connections clean.
Confirm copper/pads/positions/pin/nets and shell/mouth transforms unchanged.
Verify proposed source change does not silently alter model geometry, courtyard,
registration tolerance, hole floor or switch libraries. Assess footprint extent
effects on dependent orientation/twin/placement evidence. Current user approval
is absent/deferred; reviewer may not mint it. All downstream normal checkpoint,
schematic and placement renewals are still owed after root adoption.

No candidate edits in this review. Return SOUND or CORRECTION_REQUIRED with
exact files, measured scope, failures/limits and concrete next owner. Use
shared pipeline_runtime.run_stage for native/tests, explicit cwd/env,
/usr/bin/python3 -B, finite<=300s. Additional read-only dependencies from /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901
must be hashed. Preserve failed runs and uncertainty. No render recipe sweep,
new source campaign or general CAD framework. Five outputs EXACTLY report.md,
evidence.json,evidence-manifest.json,evidence.tar.gz,result.json. domain_result
nonempty string separate from delivery. Archive new review methods/results/
native evidence only, reference original author archive; no nested archives.
Manifest archive_sha256/archive_size/member_count/members(path,size,sha256);
reopen every regular member and reject symlinks/traversal/duplicates. result
exact envelope subject/checks evidence-complete,inputs-verified,review-complete
for honest complete handback. Supplied preflight then actual FINAL. No live
adoption, routing/layout/release/order or physical acceptance.
