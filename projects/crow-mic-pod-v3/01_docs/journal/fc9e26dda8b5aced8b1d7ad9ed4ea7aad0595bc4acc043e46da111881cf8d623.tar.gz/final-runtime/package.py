from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,io,shutil,datetime
S=Path(__file__).parent;R=S.parents[3];OUT=S.parent/'outputs'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=json.loads((S.parent/'envelope.json').read_text());expected=json.loads((R/'expected-subject.json').read_text())
rows=[]
for x in env['input_packet']:
 p=R/x['path'];rows.append({'path':x['path'],'size':p.stat().st_size,'sha256':sha(p),'match':p.stat().st_size==x['size'] and sha(p)==x['sha256']})
assert len(rows)==294 and all(x['match'] for x in rows)
(S/'inputs-after.json').write_text(json.dumps(rows,indent=2))
prior=(R/'preceding-receipts/readability/report.md').read_text();priorhash=[x.split(':',1)[1].strip() for x in prior.splitlines() if x.startswith('schematic_pdf_sha256:')][0]
assert sha(R/'preceding-subject/03_tscircuit/build/schematic.pdf')==priorhash
prior_receipt=json.loads((R/'preceding-receipts/readability/delivery-attempt.json').read_text())
assert prior_receipt['status']=='PASS'
assert prior_receipt['output']['completion']['outputs']['report.md']['sha256']==sha(R/'preceding-receipts/readability/report.md')
assert prior_receipt['output']['completion']['outputs']['evidence-manifest.json']['sha256']==sha(R/'preceding-receipts/readability/evidence-manifest.json')
pixels=json.loads((S/'pixel-equivalence-final.json').read_text());census=json.loads((S/'native-inventory.json').read_text());parity=json.loads((S/'pin-parity.json').read_text())
observations=[{'page':1,'refs':['J1','F1','D1','D2','R14','TP1','TP2'],'viewed':['current-1.png','header-1.png','jack-detail.png'],'judgment':'Legible ten-pin RJ45 with isolated shell; polarity, fuse and protected rail traceable.'},{'page':2,'refs':['C1','C2','U2','R1','R2','C3','C4','C5','C6','TP3','TP7'],'viewed':['current-2.png','header-2.png','ldo-detail.png'],'judgment':'Legible input boundary, IN/EN, OUT/FB/NR_SS, NC/DNC, grounded EP and bypasses.'},{'page':3,'refs':['R3','C7','R4','MK1','C8','R5','R6','R7','C9','TP4'],'viewed':['current-3.png','header-3.png'],'judgment':'Legible capsule polarity, bias/coupling, divider and reference probe.'},{'page':4,'refs':['U1','C10','C11','R8','R9','R10','R11','R12','R13','U3','TP5','TP6'],'viewed':['current-4.png','header-4.png','opamp-detail.png','clamp-detail.png'],'judgment':'Legible opamp pins and spare feedback, output polarity/series resistors and ESD NC/channel pins.'}]
(S/'visual-observations.json').write_text(json.dumps(observations,indent=2))
files_extra={str(p.relative_to(R/'project')) for p in (R/'project').rglob('*') if p.is_file()}-{str(p.relative_to(R/'preceding-subject')) for p in (R/'preceding-subject').rglob('*') if p.is_file()}
(S/'current-only-packet-paths.json').write_text(json.dumps(sorted(files_extra),indent=2))
ev={'schema':1,'review_stage':'pre-route','review_kind':'schematic_render','revieweridentity':'/root/carrier_rj45_native_pod_readability_none1','context':'FRESH','date':datetime.datetime.now(datetime.timezone.utc).isoformat(),'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','verdict':'SOUND','subject':env['subject'],'hashes':expected,'methods':['Frozen input size/SHA-256 census before and after','Owning pre_route_review_check.py hash functions and exact aggregate parts implementation','Independent identical pdftoppm RGB rasterization at 144 dpi; PIL full-page and precisely bounded identity-header exclusion comparison','Actual host image inspection of every current integrated page, all headers and four enlarged pin details','Independent S-expression current/prior component-net-pin inventory and UUID-normalized native schematic comparison','Complete CircuitJSON record-class comparison and source-port to native pin-net parity','Maintained current electrical invariants checker','Independent archive member reopening and hash/size validation'],'counts':{'frozen_inputs':294,'verified_before':294,'verified_after':294,'owning_hashes':7,'pages':4,'pages_inspected':4,'page_components':[7,11,10,12],'parts_dossiers':34,'comparable_preceding_files':118,'unchanged_comparable_authored_files':114,'changed_generated_files':4,'changed_comparable_authored_files':0,'circuitjson_records':1188,'native_components':40,'native_component_pins':103,'native_nets':24,'named_nets':20,'explicit_nc':4,'native_placed_symbols':64,'native_placed_symbol_pins':127,'smd_intent':31,'manual_jack':1,'offboard_capsule':1,'bare_probe_pads':7,'invariants_passed':39,'invariants_total':39,'body_pixels_equal':7848000,'body_pixels_total':7848000,'outside_identity_line_pixels_equal':8717060,'erc_errors':0,'erc_warnings':158,'supplier_footprint_warnings':15},'visual_observations':observations,'pixel_equivalence':pixels,'source_delta':{'pod_comparable_authored_delta':[],'generated_changed_files':['03_tscircuit/build/circuit.json','03_tscircuit/build/schematic.pdf','04_kicad/crow_mic_pod_v3.kicad_sch','06_build/netlists/crow_mic_pod_v3.net'],'circuitjson_changes':['source_project_metadata.source_filesystem_md5_hash','supplier_footprint_mismatch_warning random IDs and ordering only'],'native_schematic_change':'439 UUID occurrences only','external_shared_generator_acceptance':'INHERITED frozen source-adoption receipt; complete checkpoint verification owned by root'},'findings':[],'preserved_limits':['SOURCE PASS is not FULL; current supplied FULL INCOMPLETE with nine physical unknowns','Current physical five-view human orientation pending separately','No native PCB, route, locator, fabrication, allocation, release or physical mating acceptance','Custom analog/DC factory Cat6A RJ45, NOT Ethernet/PoE; power-off mating','FIRST-ARTICLE-ONLY / DO-NOT-ORDER'],'preceding_readability_receipt_binding_verified':True,'preceding_pdf_sha256':priorhash,'notes':['Initial narrow hash-only rectangle correctly failed outside-header equality; final expanded rectangle includes only shifted generated identity-line suffix, with raw initial result retained.','Current-only packet paths are separately inventoried; missing preceding packet context is not called a source addition.','Delivery PASS concerns honest complete review evidence, not engineering promotion.']}
(OUT/'evidence.json').write_text(json.dumps(ev,indent=2))
# Preserve the exact external execution/checker implementations used, without modifying them.
toolsroot=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
for rel in ['skills/pcb-design/scripts/pipeline_runtime.py','skills/kicad-pcb/scripts/electrical_invariants.py']:
 src=toolsroot/rel;dest=S/('used-'+src.name);dest.write_bytes(src.read_bytes())
# All completed engineering raw logs/runtime receipts enter the archive. The currently running packaging log/receipt is not a completed analysis record.
members={}
for p in sorted(S.iterdir()):
 if p.is_file() and p.name not in ('package.log','package.runtime.json'):
  members['methods-and-evidence/'+p.name]=p.read_bytes()
for rel in ['context/skills/kicad-pcb/scripts/pre_route_review_check.py','expected-subject.json','project/03_tscircuit/build/schematic.pdf','preceding-subject/03_tscircuit/build/schematic.pdf','project/03_tscircuit/src/crow_mic_pod_v3.tsx','project/03_tscircuit/manifest.yaml','project/03_src/rules/electrical_invariants.yaml','project/06_build/netlists/crow_mic_pod_v3.net','preceding-subject/06_build/netlists/crow_mic_pod_v3.net','project/04_kicad/crow_mic_pod_v3.kicad_sch','project/06_build/erc.rpt','preceding-receipts/readability/delivery-attempt.json']:
 members['inputs/'+rel]=(R/rel).read_bytes()
members['review/report.md']=(OUT/'report.md').read_bytes();members['review/evidence.json']=(OUT/'evidence.json').read_bytes()
archive=OUT/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,data in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
manifest={'archive_sha256':sha(archive),'archive_size':archive.stat().st_size,'member_count':len(members),'members':[]}
with tarfile.open(archive,'r:gz') as t:
 seen=set()
 for m in t.getmembers():
  path=PurePosixPath(m.name)
  assert m.isfile() and not m.issym() and not m.islnk() and not path.is_absolute() and '..' not in path.parts and m.name not in seen and not m.name.endswith(('.tar','.tar.gz','.tgz'))
  seen.add(m.name);data=t.extractfile(m).read();assert data==members[m.name] and len(data)==m.size
  manifest['members'].append({'path':m.name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 assert seen==set(members)
(OUT/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2))
(OUT/'result.json').write_text(json.dumps({'subject':env['subject'],'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]},indent=2))
assert {p.name for p in OUT.iterdir()}=={'report.md','evidence.json','evidence-manifest.json','evidence.tar.gz','result.json'}
print(json.dumps({'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'reopened_members':len(manifest['members']),'output_files':sorted(p.name for p in OUT.iterdir()),'current_only_packet_paths':sorted(files_extra)},indent=2))
