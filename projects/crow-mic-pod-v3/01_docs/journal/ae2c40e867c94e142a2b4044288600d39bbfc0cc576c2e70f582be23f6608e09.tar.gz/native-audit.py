import pcbnew,json,math
from pathlib import Path
def mm(v): return round(pcbnew.ToMM(v),6)
def fid(f):
 x=f.GetFPID();return str(x.GetUniStringLibNickname())+':'+str(x.GetLibItemName())
def census(path):
 b=pcbnew.LoadBoard(str(path)); fps={}
 for f in b.GetFootprints():
  fps[f.GetReference()]={'value':f.GetValue(),'footprint':fid(f),'layer':pcbnew.LayerName(f.GetLayer()),'pos':[mm(f.GetPosition().x),mm(f.GetPosition().y)],'orientation':f.GetOrientationDegrees(),'pads':sorted([{'num':p.GetNumber(),'net':p.GetNetname(),'pos':[mm(p.GetPosition().x),mm(p.GetPosition().y)],'size':[mm(p.GetSize().x),mm(p.GetSize().y)],'attr':int(p.GetAttribute())} for p in f.Pads()],key=lambda x:(x['num'],x['pos']))}
 return b,fps
base,bf=census(Path('projects/crow-mic-pod-v3/04_kicad/crow_mic_pod_v3.kicad_pcb'))
r0,rf=census(Path('projects/crow-mic-pod-v3/06_build/route/r0.kicad_pcb'))
smd_top=[];smd_bottom=[];tht=[]
for f in r0.GetFootprints():
 pads=list(f.Pads())
 if any(p.GetAttribute()==pcbnew.PAD_ATTRIB_SMD for p in pads):
  (smd_top if f.GetLayer()==pcbnew.F_Cu else smd_bottom).append(f.GetReference())
 if any(p.GetAttribute() in (pcbnew.PAD_ATTRIB_PTH,pcbnew.PAD_ATTRIB_NPTH) for p in pads): tht.append(f.GetReference())
tracks=[]
for t in r0.GetTracks():
 d={'kind':'via' if isinstance(t,pcbnew.PCB_VIA) else 'segment','net':t.GetNetname()}
 if isinstance(t,pcbnew.PCB_VIA): d|={'pos':[mm(t.GetPosition().x),mm(t.GetPosition().y)],'size':mm(t.GetWidth(t.GetLayer())),'drill':mm(t.GetDrillValue())}
 else: d|={'start':[mm(t.GetStart().x),mm(t.GetStart().y)],'end':[mm(t.GetEnd().x),mm(t.GetEnd().y)],'width':mm(t.GetWidth()),'layer':pcbnew.LayerName(t.GetLayer())}
 tracks.append(d)
targets={}
for ref,num in [('R12','1'),('R3','2'),('R13','2'),('TP6','1')]:
 f=next(x for x in r0.GetFootprints() if x.GetReference()==ref);p=next(x for x in f.Pads() if x.GetNumber()==num)
 targets[f'{ref}.{num}']={'net':p.GetNetname(),'pos':[mm(p.GetPosition().x),mm(p.GetPosition().y)],'size':[mm(p.GetSize().x),mm(p.GetSize().y)],'value':f.GetValue(),'layer':pcbnew.LayerName(f.GetLayer())}
print(json.dumps({'footprint_identity_equal':bf==rf,'changed_footprints':[x for x in sorted(set(bf)|set(rf)) if bf.get(x)!=rf.get(x)],'footprints':len(rf),'tracks':len(tracks),'segments':sum(x['kind']=='segment' for x in tracks),'vias':sum(x['kind']=='via' for x in tracks),'via_list':[x for x in tracks if x['kind']=='via'],'targets':targets,'target_tracks':[x for x in tracks if x['net'] in ('OUTP_DRV','MIC_BIAS','AUDIO_N')],'smd_top':sorted(smd_top),'smd_bottom':sorted(smd_bottom),'tht':sorted(tht)},indent=2,sort_keys=True))
