from pathlib import Path
import json,hashlib,tarfile,shutil,collections,datetime,copy
S=Path(__file__).resolve().parent;R=S.parents[3];T=R/'06_build/task_runs/rj45-pod-local-launch-review';M=S/'measured';A=S/'archive';O=T/'outputs';O.mkdir(exist_ok=True);bundle=S/'review-evidence';bundle.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());env=read(T/'envelope.json');author=read(R/'author/evidence.json');ind=read(M/'raw/independent-review.json');nc=read(M/'raw/native-census.json');ver=read(M/'raw/verification.json');oracle=read(M/'raw/oracle.json');manifest=read(R/'author/evidence-manifest.json')
assert manifest['archive_sha256']==sha(R/'author/evidence.tar.gz') and manifest['archive_size']==(R/'author/evidence.tar.gz').stat().st_size and manifest['member_count']==462
assert sha(A/'repo/projects/crow-mic-pod-v3/04_kicad/crow_mic_pod_v3.kicad_pcb')==ind['board_sha256']
assert author['candidate_history']['candidate4']['candidate_number']==4
checks=['stage.py','native-census.py','owning.py','verify-native-diagnosis.py','ground-and-bypass.py','independent-review.py','independent-review-diagnosis.py','independent-review-complete.py','replay-compare.py']
methods=[]
for f in checks:
 p=M/'methods'/f;methods.append({'path':'methods/'+f,'sha256':sha(p),'frozen_author_sha256':sha(A/'methods'/f) if (A/'methods'/f).is_file() else None,'role':'Review harness; unchanged owning checker and thresholds'})
failures=[{'stage':'independent-review','cause':'Overstrict byte/row identity assumption failed on three DRC alternate endpoint selections. Original method/log preserved. Diagnosis proves same native copper components with exact old/new UUIDs retained.'},{'stage':'independent-review-diagnosis','cause':'Review selector mistakenly expected ground prefix owner J1.6. Source names this bank U3.4. Corrected selector only, full bank bytes still required equal to both source predecessors; original method/log preserved.'}]
e={
 'schema':1,'subject':env['subject'],'domain_result':'SOUND: exact candidate4 combined floorplan.yaml and route.yaml source is supported within the admitted local launch scope; full routing and release remain unaccepted.','candidate_verdict':'SOUND','delivery_result':'COMPLETE independent exact-source review',
 'envelope_canonical_sha256':hashlib.sha256(json.dumps(env,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
 'input_verification':{'count':344,'all_verified':True,'rows':read(S/'inputs.json'),'author_archive':{'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'regular_members_reopened':462,'member_verification':read(S/'author-archive-verified.json'),'links_traversal_duplicates':0}},
 'exact_source_subject':ind['source_files'],'saved_board_sha256':ind['board_sha256'],
 'source_scope_measured':{'only_candidate3_change':'Three shared U2.1 OUT fork coordinate occurrences y47.700 to47.850 plus matching comment; C6 and every other source byte unchanged. Combined floorplan exactly candidate3.','fixed_files':ind['fixed_source_checker_part_files'],'three_clamp_prefixes':ind['exact_three_prefixes'],'prior_vin_and_c2_c9_combined_changes':'Retained exact; beforeimage diffs included. Full GND modes measured on saved board.'},
 'candidate_history':{'prior_candidates_spent':3,'candidate3':'REJECTED; historical native 0.145791 mm versus unchanged 0.150 floor; remains rejected','candidate4':4,'review_new_source_candidates':0,'review_replacements':0,'remaining_source_candidates':0,'author_admission':read(R/'author-allocation/admission.json'),'author_completion':read(R/'author-allocation/attempt.json')},
 'measured':{'native_census':nc,'native_verification':ver,'independent_native_analytic_clearance':ind['local_independent_geometry'],'all44footprints113pads_models_poses_vs_frozen_live':ind['native_projection_vs_frozen_live'],'owning22':oracle,'stock_same_source_replay':read(M/'raw/replay-comparison.json'),'ground_returns':read(M/'raw/ground-comparison.json'),'all20_contact_dispositions':ind['all20'],'native_drc':{'counts':{'violations':4,'unconnected':33,'parity':0},'exit_code':5,'full_board_verdict':'FAIL unfinished routing; not full-route PASS','rows':ind['all_drc_rows'],'changed_rows_vs_author':ind['drc_changed_rows_against_author_saved_candidate4']},'controls':{'wrong_pad':oracle['negative_controls'],'bypass':read(M/'raw/bypass-controls.json'),'native_clean':read(M/'raw/native-control-clean.json'),'native_hostile':read(M/'raw/native-control-hostile.json'),'maintained_tests':'10/10 PASS:9 negative,1 positive'},'visual_binding':read(M/'raw/native-image-binding.json')},
 'inherited_explicitly':{'candidate1_candidate2_review_history':'Historical source decisions reopened in author history; not rerun as new candidates. Candidate3 remains REJECTED.','generator_execution':'Author generated candidate4 through stock generator after missing fab_tiers.yaml setup dependency. Review reopens exact generated/native/source preimages and independently replays rules+whole-config prep; it does not claim a fresh generator invocation.','author_archives_older_than_immediate':'Older900/16-member archive verifications are author historical claims. Their retained history evidence/source beforeimages are reopened; this review independently reopens all462 immediate archive members, no omitted older archive claimed reopened.','historical95_native_drc_rows':ind['historical_drc_rows_reopened'],'physical_qualification':'9 pod and23 carrier physical obligations remain inherited OPEN; parts/cable pinmap/product limits unchanged.'},
 'method_provenance':{'executed_harnesses':methods,'unchanged_owning_checker_sha256':sha(M/'repo/skills/kicad-pcb/scripts/critical_path_check.py'),'runtime_sha256':sha(M/'repo/skills/pcb-design/scripts/pipeline_runtime.py'),'adaptations':[{'method':'verify-native-diagnosis.py','change':'Baseline path only: missing prior-author generated board to exact archived candidate4 generated board. Complete native projection additionally compared independently against frozen live board; no geometry/model/pose change.'},{'method':'independent-review-complete.py','change':'Fresh review math derives corner from actual saved native pad, verifies all source bytes and exact native DRC component identity. Original two harness assumption failures retained.'}],'supplemental_dependencies':author['supplemental_dependencies'],'new_readonly_dependencies':[],'runtime_contract':'Every native/check invocation runs under shared pipeline_runtime.run_stage with explicit cwd/env and180s maximum; Python uses /usr/bin/python3 -B.'},
 'review_setup_failures_retained':failures,'author_failures_retained':author['all_new_failures_retained'],'prior_failures_retained':author['prior_failures_retained'],
 'visual_inspection':{'actually_opened':['U2 OUT/C3 launch and adjacent U2.2','U1.4/C10.1 ordinary via','C2 full ground return','C9 full ground return'],'finding':'Native SVG copper, pads, filled zones and Fab were inspected. Fresh native SVG geometry exactly matches those inspected images after title date only; not synthetic illustration. C2 east0.4mm sample lies outside its land in unchanged VIN clearance cutout, retained as false.'},
 'scope_limits':['Foreign census explicitly excludes unchanged pad/pad pairs; separate full native DRC is4/33/0 and FAIL.','No new failed scope predicate found. Six unfinished downstream audio declarations remain REFUSED, not PASS.','No source adoption, normal current schematic/placement gate acceptance, routed-board acceptance, release, or order authority.'],
 'next_owner':'Root closes actual review host FINAL, then separately adopts exact two-source result if desired, performs normal regeneration and current schematic/placement reviews, routing/stitching/native0/0/0 and remaining release gates.',
 'boundary':'FIRST-ARTICLE-ONLY / DO-NOT-ORDER. All9pod/23carrier physical obligations, selected parts, cable pin map and limits unchanged.'}
assert e['envelope_canonical_sha256']=='20411b810db2069736bdcfff1f107d1a0021a6d9c20b693ae41ae769d4dd7219'
(O/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
report=[]
def add(x=''):report.append(x)
add('SOUND for the exact candidate4 combined source. Delivery is complete. This is a bounded local-source acceptance, with full routing and normal current-source adoption/review obligations still open. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.')
add('\nThe fourth cumulative source candidate changes only the U2.1 shared OUT fork from (34.025,47.700) to (34.025,47.850): three coordinate occurrences and the matching comment. Floorplan is byte-identical to candidate3. C6 and all other candidate3 route geometry remain exact. Prior three candidates remain spent; candidate3 remains REJECTED. This review constructed zero source candidates and used zero replacements.')
for x in ind['source_files']:add(f"\n`{x['path']}`: candidate4 `{x['candidate4_sha256']}`; candidate3 `{x['candidate3_sha256']}`; frozen live beforeimage `{x['live_beforeimage_sha256']}`.")
add(f"\nActual saved native board SHA256 `{ind['board_sha256']}`. All344 inputs and all462 regular immediate author archive members were reopened and verified by size/SHA256; no links, traversal or duplicates. Canonical review envelope `{e['envelope_canonical_sha256']}`. Author allocation/admission and completed actual host FINAL were reopened. Older900/16-member archive verification remains explicitly inherited; this review does not claim reopening omitted older archives.")
add('\nIndependent native-pad arithmetic derives U2.2 inner corner (34.550,47.750) from center (34.675,47.150), size1.450×0.500mm, rotation90°, radius0.125mm. The actual saved0.500mm F.Cu launch (34.025,47.850)–(34.120,49.200) gives0.159438958mm clearance. Native collision bisection independently gives0.159439mm:0.009439mm above unchanged0.150mm. The fork is inside the actual U2.1 rounded pad. No tolerance or tangency waiver was used; unchanged straight throat remains at the specified floor.')
add('\nFresh rules-before and unchanged-source whole-config stock prep replay served12/12 banks, saved86 primitives (78 tracks/8 vias),0 refused. Every resulting saved primitive matches both author prepared and actual saved filled copper exactly. Generator/fill/rules-last execution itself is inherited from reopened author runtime evidence, with its missing-read-only-fab-tier setup failure retained. Review independently checks its actual output and native fill, rather than treating an in-memory intention as saved evidence.')
add('\nFresh native census:12 seeded nets,76 seeded pads,78 tracks,8 vias;1816 same-net layer comparisons,141 actual contacts,0 unrepresented contacts. One J1.6/GND conservative-box false positive remains explicitly noncontact. All8500 foreign-net track/via/pad comparisons clear0.150mm. Foreign pad/pad comparisons are explicitly excluded; all44 footprints/113 pads and full model/pose projections independently match the frozen live board. Whole-board native DRC remains separate and FAIL.')
add('\nExact stock serialization binds78/78 tracks and8/8 vias by integer coordinates, net, layer, width and drill. Raw source-coordinate mismatch caused by stock3-decimal quantization and VECTOR2I_MM integer serialization is retained, with no set-rounding waiver. All728 ordinary-via/SMD annulus and drill comparisons have no intersection. At U1 via(53.7,49.0), annulus/drill clearances are0.050001/0.200001mm toU1.4 and0.040001/0.190001mm toC10.1. Native partitions connect all11 5V terminals and all4 FB terminals.')
add('\nOwning checker is unchanged and freshly measures16 PASS,0 FAIL,6 REFUSED across all22 declarations. All28 VIN terminal pairs and five TVS-first dominance declarations PASS. Source prefixes are exact against both candidate3 and live beforeimage. C2/C9 local GND modes are FULL and native filled land samples match the reviewed baseline. The off-land C2 east0.4mm sample remains false and has not been relabeled as copper.')
add('\n|#|Declaration|Disposition|Exact measurement / cause|\n|---|---|---|---|')
for i,x in enumerate(oracle['rows'],1):
 d=x['declaration'];label=d['from']+' → '+(d.get('to') or d['targets'][0]);label+=(' through '+d['through']) if 'through'in d else ''
 details=x.get('cause')
 if details is None:
  vals=[]
  for y in x['measurements']:
   if 'length_mm' in y:vals.append(f"{y['length_mm']:.6f}mm, {','.join(y['layers'])}, vias{y['via_count']}")
   else:vals.append(f"prefix edges{y['prefix_edge_count']}, missing{y['missing_prefix_edge_count']}, bypassed{y['bypassed_prefix_edge_count']}")
  details='; '.join(vals)
 add(f"|{i}|{label}|{x['verdict']}|{details}|")
add('\nAll20 original native contact objects and source causes are retained in evidence.json. Each row below was assessed against the complete fresh contact census and exact source/native bijection, not accepted solely from prior explanation.')
add('\n|Original ID|Exact original endpoints/objects|Fresh disposition|\n|---|---|---|')
def obj(x):
 return x['id']+' '+str(x.get('at',x.get('start')))+((' → '+str(x['end'])) if 'end'in x else '')
for x in ind['all20']:add(f"|{x['finding_id']}|{obj(x['a'])}; {obj(x['b'])}|RESOLVED. {x.get('specific_correction','')}|")
add('\nFresh native DRC with severity-all/refill/schematic-parity/exit-code returns5:4 dangling warnings,33 unconnected items,0 parity. All37 actual rows are individually classified below with exact UUID/native objects in evidence.json. Historical baseline4/33/0 and rejected candidate3 empty0/58/0 remain historical; all95 historical rows are reopened in evidence, not used as the new measurement. No new failure cause appears in candidate4: the outstanding VREF/PRE_OUT/OUTP_FB/MIC_AC seeds and listed downstream nets remain unfinished.')
add('\nThe reviewer’s initial strict list-equality assertion failed because native DRC selected alternate same-component objects in three unconnected rows:2 and3 use VREF track8f5ccc22-6487-49e1-87b7-09e6fd9ca3f3 instead of U1.2 pad061251e2-6571-446f-96b9-b0a32a33c1f7; row15 uses AUDIO_P tracka7854636-229e-4060-b50c-7611d0f1eb45 instead of1502244e-df25-4fc8-b2b0-a76213cd5ea1. Complete measured native contact components prove each pair belongs to the same connected copper. Exact before/after rows remain in evidence. This changes the report representative, not the physical connectivity.')
add('\n|ID|Exact current native endpoints|Cause and disposition|\n|---|---|---|')
for x in ind['all_drc_rows']:
 endpoints='; '.join(v['description']+' @'+str(v['pos'])+' ['+v['uuid']+']' for v in x['endpoints']);add(f"|{x['id']}|{endpoints}|{x['cause']} OPEN: downstream routing/stitching.|")
add('\nFresh negative controls: native clean0/0; hostile exact J1.1/PROBE_0 versus J2.1/PROBE_1 clearance failure; both wrong-pad queries refuse; allfive separately injected preclamp bypasses FAIL with one missing and one bypassed prefix edge; maintained policy tests10/10 PASS (nine negative,one positive). No checker, threshold, source or model change was used to pass a control.')
add('\nNative U2/U1/C2/C9 copper/Fab/filled-zone images were actually opened. A fresh KiCad SVG export matches their native geometry exactly after excluding title date only. C2/C9 full returns and the actual off-land U1 via are visible; the report does not approve a synthetic drawing.')
add('\nMethods, hashes, all runtime logs and setup diagnostics are archived. The frozen native-census, owning and ground/bypass methods were rerun unchanged. The verification harness changes only its baseline path, with an additional independent full projection against frozen live. The new review harness preserves its two failed assumptions: strict DRC representative identity and mistaken ground-bank selector J1.6 instead of source owner U3.4. Diagnosis changes only review bookkeeping; complete source-bank equality and native component checks remain enforced. Every native run used shared pipeline_runtime.run_stage, explicit cwd/env,180s maximum and /usr/bin/python3 -B for Python. No live source/checker edits, children, KRT, route import or adoption occurred.')
add('\nRoot must close this actual review FINAL before adoption. Source adoption, normal regeneration/current schematic and placement reviews, full routing/stitching/native0/0/0, normal downstream gates and release remain root obligations. The9 pod/23 carrier physical obligations, parts, cable pin map and limits remain unchanged. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.')
(O/'report.md').write_text('\n'.join(report)+'\n');(O/'result.json').write_text(json.dumps({'subject':env['subject'],'checks':{x:'PASS' for x in env['completion']['checks']},'unresolved':[]},indent=2)+'\n')
# Fresh archive only: newly measured artifacts plus minimal exact source/history witnesses; no ancestor archive.
def cp(src,dst):
 q=bundle/dst;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,q)
for f in checks:cp(M/'methods'/f,Path('methods')/f)
for d in ['raw','logs','images']:
 for p in (M/d).rglob('*'):
  if p.is_file():cp(p,Path(d)/p.relative_to(M/d))
for f in ['u2-launch','u1-via','c2-ground','c9-ground']:cp(A/'images'/f'{f}.png',Path('images')/f'{f}.png')
for d in ['source_candidate','beforeimages','baseline-source']:
 for p in (A/d).rglob('*'):
  if p.is_file():cp(p,Path(d)/p.relative_to(A/d))
for p in (S/'replay/logs').glob('*'):cp(p,Path('stock-replay/logs')/p.name)
for p in (S/'replay/raw').glob('*'):cp(p,Path('stock-replay/raw')/p.name)
cp(S/'replay/repo/projects/crow-mic-pod-v3/06_build/route/r0.kicad_pcb','stock-replay/saved-r0.kicad_pcb')
for p,d in [(M/'repo/projects/crow-mic-pod-v3/04_kicad/crow_mic_pod_v3.kicad_pcb','native/saved-candidate4.kicad_pcb'),(A/'raw/candidate-generated.kicad_pcb','native/candidate4-generated.kicad_pcb'),(A/'controls/variant2-filled.kicad_pcb','native/reviewed-baseline-filled.kicad_pcb'),(R/'input/projects/crow-mic-pod-v3/04_kicad/crow_mic_pod_v3.kicad_pcb','native/frozen-live.kicad_pcb'),(S/'inputs.json','verification/inputs.json'),(S/'author-archive-verified.json','verification/author-archive-reopened.json'),(T/'envelope.json','verification/envelope.json'),(R/'author-allocation/admission.json','history/author-admission.json'),(R/'author-allocation/attempt.json','history/author-completed-attempt.json')]:cp(p,d)
for f in ['critical_path_check.py','copper_length_audit.py','copper_graph.py']:cp(M/'repo/skills/kicad-pcb/scripts'/f,Path('owning-methods')/f)
cp(M/'repo/projects/crow-mic-pod-v3/03_src/rules/critical_paths.yaml','owning-methods/critical_paths.yaml')
for f in ['generate.log','verify-native.log']:
 if (A/'logs'/f).is_file():cp(A/'logs'/f,Path('history/author-setup-failures')/f)
for f in ['report.md','evidence.json','result.json']:cp(O/f,Path('delivery')/f)
cp(Path(__file__),'methods/package_review.py')
rows=[]
for p in sorted(bundle.rglob('*')):
 if p.is_file():assert not p.is_symlink();rows.append({'path':str(p.relative_to(bundle)),'size':p.stat().st_size,'sha256':sha(p)})
with tarfile.open(O/'evidence.tar.gz','w:gz') as tar:
 for row in rows:tar.add(bundle/row['path'],arcname=row['path'],recursive=False)
with tarfile.open(O/'evidence.tar.gz') as tar:
 seen=set();actual=[]
 for x in tar.getmembers():
  assert x.isfile() and not Path(x.name).is_absolute() and '..' not in Path(x.name).parts and x.name not in seen
  seen.add(x.name);bb=tar.extractfile(x).read();actual.append({'path':x.name,'size':len(bb),'sha256':hashlib.sha256(bb).hexdigest()})
 assert actual==rows
out={'schema':1,'subject':env['subject'],'domain_result':'SOUND','archive_sha256':sha(O/'evidence.tar.gz'),'archive_size':(O/'evidence.tar.gz').stat().st_size,'member_count':len(rows),'members':rows,'reopen_verification':{'status':'PASS','all_regular_members_reopened':len(rows),'no_links_traversal_duplicates':True}}
(O/'evidence-manifest.json').write_text(json.dumps(out,indent=2)+'\n');print('PACKAGED',len(rows),'members',out['archive_size'],'bytes',out['archive_sha256']);print('outputs',sorted(p.name for p in O.iterdir()))
