import pcbnew,yaml,json,math
from pathlib import Path
def mm(v):return round(pcbnew.ToMM(v),6)
def fid(f):x=f.GetFPID();return str(x.GetUniStringLibNickname())+':'+str(x.GetLibItemName())
def census(path):
 b=pcbnew.LoadBoard(str(path));o={}
 for f in b.GetFootprints():
  o[f.GetReference()]={'value':f.GetValue(),'fp':fid(f),'layer':pcbnew.LayerName(f.GetLayer()),'pos':[mm(f.GetPosition().x),mm(f.GetPosition().y)],'orientation':f.GetOrientationDegrees(),'pads':sorted([{'num':p.GetNumber(),'net':p.GetNetname(),'pos':[mm(p.GetPosition().x),mm(p.GetPosition().y)],'size':[mm(p.GetSize().x),mm(p.GetSize().y)],'attr':int(p.GetAttribute())} for p in f.Pads()],key=lambda x:(x['num'],x['pos']))}
 return b,o
base,bf=census(Path('projects/crow-mic-pod-v3/04_kicad/crow_mic_pod_v3.kicad_pcb'));r0,rf=census(Path('projects/crow-mic-pod-v3/06_build/route/r0.kicad_pcb'))
tracks=[];vias=[]
for t in r0.GetTracks():
 if isinstance(t,pcbnew.PCB_VIA): vias.append({'net':t.GetNetname(),'pos':[mm(t.GetPosition().x),mm(t.GetPosition().y)],'size':mm(t.GetWidth(t.GetLayer())),'drill':mm(t.GetDrillValue())})
 else: tracks.append({'net':t.GetNetname(),'layer':pcbnew.LayerName(t.GetLayer()),'width':mm(t.GetWidth()),'a':[mm(t.GetStart().x),mm(t.GetStart().y)],'b':[mm(t.GetEnd().x),mm(t.GetEnd().y)]})
hits=[]
for v in vias:
 for f in r0.GetFootprints():
  for p in f.Pads():
   px,py=mm(p.GetPosition().x),mm(p.GetPosition().y);sx,sy=mm(p.GetSize().x),mm(p.GetSize().y)
   if abs(v['pos'][0]-px)<=sx/2 and abs(v['pos'][1]-py)<=sy/2:hits.append({'via':v,'ref':f.GetReference(),'pad':p.GetNumber(),'pad_net':p.GetNetname()})
smd_top=[];smd_bottom=[]
for f in r0.GetFootprints():
 if any(p.GetAttribute()==pcbnew.PAD_ATTRIB_SMD for p in f.Pads()):(smd_top if f.GetLayer()==pcbnew.F_Cu else smd_bottom).append(f.GetReference())
anchors=[('AUDIO_P',[49.6,34.25]),('AUDIO_N',[47.288,36.25]),('AUDIO_N',[62.913,34.7]),('OUTP_DRV',[55,36]),('MIC_BIAS',[66,39])]
def near(a,b,t=.0011):return abs(a[0]-b[0])<=t and abs(a[1]-b[1])<=t
ar=[]
for net,pos in anchors:
 ar.append({'net':net,'pos':pos,'vias':[v for v in vias if v['net']==net and near(v['pos'],pos)],'segments':[s for s in tracks if s['net']==net and (near(s['a'],pos) or near(s['b'],pos))]})
print(json.dumps({'footprint_identity_equal':bf==rf,'changed_footprints':[x for x in sorted(set(bf)|set(rf)) if bf.get(x)!=rf.get(x)],'footprints':len(rf),'segments':len(tracks),'vias':len(vias),'via_pad_bbox_hits':hits,'anchors':ar,'smd_top_count':len(smd_top),'smd_bottom':sorted(smd_bottom)},indent=2,sort_keys=True))
