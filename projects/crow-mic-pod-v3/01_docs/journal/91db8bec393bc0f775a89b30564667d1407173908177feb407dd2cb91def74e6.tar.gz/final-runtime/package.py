from pathlib import Path,PurePosixPath
import json,hashlib,sys,tarfile,datetime,subprocess
P=Path.cwd();R=P.parents[1];D=P/'06_build/task_runs/rj45-pod-placement-after-none1';S=D/'scratch';O=D/'outputs'; H=P/'06_build/handoffs/rj45-pod-placement-after-none1'
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet,writer_scope_receipt
from pipeline_runtime import _tree_snapshot,_changed_paths,_snapshot_sha256

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat();E=TaskEnvelope.from_json((D/'envelope.json').read_text());env=json.loads((D/'envelope.json').read_text());native=json.loads((S/'native-audit.json').read_text());rt=json.loads((S/'runtime.json').read_text());drc=json.loads((S/'drc-classification.json').read_text());orient=json.loads((P/'06_build/pre_route/orientation/orientation_receipt.json').read_text())
(P/'01_docs/STATUS.md').write_text(f'''# STATUS beacon — crow-mic-pod-v3

stage: placement
step: Ordinary accepted-source placement renewal stopped at current human orientation gate
measure: MEASURED: canonical continuation rc=1 in 7.528s; P-ORIENT machine 1/1 PASS, current human approval pending/stale. S-COUNT 40 components; P-PINMAP 38 physical pin identities PASS. Fitted SMD 31/31 F.Cu. Placement DRC 0 violations / 58 opens / 0 parity.
state: blocked
next: Root owns closure and current five-view human orientation review; exact placement reviews and routing remain owed. Compact handoff blocked by preserved stale DRC gate. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.
op_pid:
updated: {now}
''')
with (P/'01_docs/journal/placement.md').open('a') as f:f.write(f'''\n## {now} — one canonical accepted-source placement continuation, first refusal preserved

MEASURED: Exclusive worker rj45-pod-placement-after-none1 verified 338/338 frozen inputs, 319 protected live preimages, commit 0fda660855458023602601486d79a30a3eaef3d3, canonical handoff and exact schematic checkpoint before one finite pipeline_runtime execution of the specified resume-after-schematic-review conductor with the explicit KiCad10 model root. Inner rc=1 in 7.528s; outer rc=1 in 7.634379s. First refusal was GATE FAILED [5e] P-ORIENT: machine 1/1 PASS; approval subject or denominator stale. Verified current five-view bundle was reused; no new images and no inherited human approval. Current human orientation review remains pending.

Schematic PR-REVIEW 2/2 PASS; 40-component count parity 4/4 PASS; P-PINMAP 38 physical pin identities PASS; placement feasibility 7/7 accepted; model coverage 32/32; P-PADSEP and placement policy PASS; authoritative all-severity/refill/parity placement DRC 0 violations / 58 opens / 0 parity; P-LAND 69/103 copper pads graded with 0 failures, 34 without declared width floor; tier preflight 0 FAIL / 1 WARN (PF-LEGALIZE clearance). Model registration 2/2 PASS. All 31 fitted SMD, including manual/consigned, occupy F.Cu. Source geometry unchanged; this was ordinary accepted-source reconstruction, zero new exploratory candidates.

Canonical board {native['canonical']['sha256']} retains 0 tracks and 2 zones. Prepared r0 {native['prepared_r0']['sha256']} carries 92 seed track/via primitives and is not imported or accepted routing. Every one of 58 raw current DRC opens has a separate native UUID/position/net/refdes-verified same-net missing-copper classification; preserved gate rows exactly match. No violation or parity row exists. Placement reviews, route import/taps/stitch, realized route checks, final route acceptance and release stages NOT RUN after the first refusal. Physical connector FULL remains INCOMPLETE with 9 obligations.

Post-run pcb_flow validate rc=2: source hash changed after promotion of the accepted schematic and DRC gate is stale. The old gate is preserved byte-identically; no handoff generation or freshness fabrication. Evidence and exact logs/results are under 06_build/task_runs/rj45-pod-placement-after-none1/outputs/. Current physical fit/service and human orientation are separate owed obligations. FIRST-ARTICLE-ONLY / DO-NOT-ORDER; no commit or release created by worker.\n''')
verified=verify_input_packet(E,P);assert verified[0],verified
initial=json.loads((S/'input-verification.json').read_text());protected=[]
for row in initial['protected']:
 actual=sha(row['path']);protected.append({**row,'final_sha256':actual,'unchanged':actual==row['sha256']});assert actual==row['sha256'],row['path']
dump(S/'protected-final.json',{'status':'PASS','count':len(protected),'rows':protected})
a=json.loads((D/'admission.json').read_text());after=_tree_snapshot(P,ignored=frozenset(a['ignored']));changed=_changed_paths(a['before'],after);scope=writer_scope_receipt(E.writer_scope,changed,before_sha256=_snapshot_sha256(a['before']),after_sha256=_snapshot_sha256(after),protected_paths=tuple(sorted((E.output_path,a['claim']))));assert scope['status']=='PASS',scope
dump(S/'writer-scope.json',scope)
dump(S/'handoff-blocker.json',{'command':['/usr/bin/python3','-B',str(R/'skills/kicad-pcb/scripts/pcb_flow.py'),'validate','.'],'returncode':2,'output':'STALE handoff: source hash changed; DRC gate is stale','gate_preserved_sha256':sha(P/'06_build/drc/gate.json'),'handoff_regeneration':'NOT RUN: freshness prerequisite failed; no deletion or touch of gate'})
notrun=['placement PR-REVIEW and P-ROUTEBASE','route import','route taps','stitch','R-CRITESC connected','R-POD-PATH realized routes','final rules/realized RF','atomic route acceptance','layout seal','fabrication/release/order','fresh r0 DRC']
paths=['04_kicad/crow_mic_pod_v3.kicad_pcb','04_kicad/crow_mic_pod_v3.kicad_sch','04_kicad/crow_mic_pod_v3.kicad_pro','04_kicad/crow_mic_pod_v3.kicad_dru','03_tscircuit/kicad/crow_mic_pod_v3.kicad_sch','03_tscircuit/build/circuit.json','03_tscircuit/manifest.yaml','06_build/netlists/crow_mic_pod_v3.net','06_build/drc/pre_route.json','06_build/drc/gate.json','06_build/route/r0.kicad_pcb','06_build/route/r0.kicad_pro','06_build/route/r0.kicad_dru','06_build/agent_handoff.yaml','06_build/placement_policy_audit.md','06_build/verification/placement_routability_receipt.json','06_build/verification/model_coverage.json','06_build/pre_route/model_registration.md','01_docs/STATUS.md','01_docs/journal/placement.md']
for rel in changed:
 if rel.startswith('06_build/task_runs/'):continue
 if (P/rel).is_file() and rel not in paths:paths.append(rel)
for folder in ['06_build/pre_route/orientation','06_build/pre_route/model_registration_bundle','06_build/checkpoints']:
 for p in (P/folder).rglob('*'):
  if p.is_file() and not p.is_symlink() and str(p.relative_to(P)) not in paths:paths.append(str(p.relative_to(P)))
for rel in ['06_build/verification/connector_assembly_contract.json','06_build/verification/connector_assembly_source_gate.json','06_build/verification/connector_assembly_full_gate.json']:
 paths.append(rel)
records=[]
for rel in sorted(set(paths)):
 p=P/rel;assert p.is_file() and not p.is_symlink(),p;records.append({'path':rel,'absolute_path':str(p),'size':p.stat().st_size,'sha256':sha(p)})
evidence={'schema':1,'task_id':E.task_id,'subject':env['subject'],'envelope_path':str(D/'envelope.json'),'envelope_sha256':sha(D/'envelope.json'),'domain_result':'INCOMPLETE; first canonical refusal P-ORIENT','stopping_gate':'GATE FAILED [5e] P-ORIENT','canonical_runs':1,'new_exploratory_candidates':0,'source_edits':0,'native_hand_edits':0,'routing_imports':0,'replacements':0,'command':json.loads((S/'command.json').read_text()),'runtime':rt,'inner_runtime':json.loads((P/'06_build/pipeline_state/rj45_renewed_placement.json').read_text()),'input_verification':{'frozen_inputs':338,'status':'PASS','protected_live_preimages':len(protected),'protected_final':'PASS','head':initial['head']},'native':native,'orientation':{'machine':'PASS 1/1','human':'PENDING; approval subject or denominator is stale','subject_sha256':orient['subject_sha256'],'observed_board_sha256':orient['observed_board_sha256'],'rendered_board_sha256':orient['rendered_board_sha256'],'views':orient['evidence'],'measurements':orient['measurements'],'reused_verified_bundle':True,'images_regenerated':False},'drc':drc,'physical_connector_FULL':'INCOMPLETE; 9 obligations retained','handoff':json.loads((S/'handoff-blocker.json').read_text()),'not_run':notrun,'scope':scope,'outputs':records,'delivery':'Complete honest execution evidence; domain incomplete is separate from delivery PASS','final_preflight_command':['/usr/bin/python3','-B',str(H/'preflight.py'),str(D/'envelope.json')],'post_run_audit_parser_correction':json.loads((S/'audit-parser-correction.json').read_text())}
dump(O/'evidence.json',evidence)
report=f'''# Pod canonical placement continuation — INCOMPLETE at P-ORIENT

One authorized canonical resume ran and stopped at its first refusal, GATE FAILED [5e] P-ORIENT. Machine geometry passed 1/1; current human approval is pending because the approval subject or denominator is stale. The verified five-view bundle was reused. No routing import, source repair, native hand edit, extra candidate, retry, replacement, commit or release occurred. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.

Inner conductor rc=1, 7.528 s; outer pipeline_runtime rc=1, 7.634379 s, start {rt['started_at']}, finish {rt['finished_at']}, timeout 660 s (inner budget/timeout 600 s). Exact argv and complete 19065-byte raw output are preserved in the archive at task/command.json and task/command.log; runtime at task/runtime.json. The wrapper process delivered its evidence successfully; that is separate from child rc=1.

Inputs: 338/338 frozen packet files verified; 319 protected live method/source preimages unchanged; exact commit {initial['head']}; initial canonical handoff validation PASS, schematic checkpoint 7/7. Conductor independently verified prelayout checkpoint 11/11, complete inputs 313/313, schematic checkpoint 7/7 and schematic reviews 2/2.

S-COUNT 4/4 across 40 components PASS. P-PINMAP 4 multi-pin references / 38 physical pin identities PASS. Native census: 44 footprints including 4 mounting holes, 113 physical pads, 32 fitted footprints. All 31 fitted SMD (including manual/consigned) on F.Cu, 0 on B.Cu. Component census SHA256 {native['component_census_sha256']}; pin census SHA256 {native['pin_census_sha256']}.

Canonical generated PCB: {native['canonical']['sha256']}, 0 tracks / 2 zones. Prepared r0: {native['prepared_r0']['sha256']}, 92 seed track/via primitives / 2 zones. Generated placement and prepared seed copper are separate subjects; r0 is not routed or accepted. Current r0 DRC NOT RUN.

Placement feasibility 7/7 accepted; model coverage 32/32 PASS; P-PADSEP and placement policy PASS; P-LAND 69/103 copper pads graded, 34 without declared width floor, 0 failures. Tier preflight 0 FAIL / 1 WARN: PF-LEGALIZE placement clearance 0.25 mm below advisory 0.8 mm rescue-via allowance. Model registration 2/2 PASS. KiCad enum/debug diagnostics remain in raw log; they did not stop generation.

Authoritative all-severity/refill/schematic-parity DRC: 0 violations, 58 unconnected rows, 0 parity rows. All 58 rows are separately classified in task/drc-classification.json and evidence.json, with raw rows and every endpoint's native UUID, position, refdes and net verified. Each is an explicit required same-net open on the unrouted generated board; no open is waived or described as accepted. Counts by net: {json.dumps(drc['net_open_counts'],sort_keys=True)}. Preserved gate rows exactly match these 58 rows, but the gate remains stale. Raw pre_route report SHA256 {drc['report_sha256']}.

Current orientation subject {orient['subject_sha256']}. J1 machine north-facing access axis [0,-1,0], mating-plane edge offset 0.5 mm, native/model alignment 1.0. Five top/outside/inside/profile views are hash-bound and preserved. These machine results do not establish human orientation approval or physical service fit. Connector FULL remains INCOMPLETE with 9 physical obligations.

Post-run pcb_flow validate returned 2: “STALE handoff: source hash changed; DRC gate is stale”. Promotion of the accepted schematic changes the canonical source fingerprint; protected authored source remains unchanged. The old gate {sha(P/'06_build/drc/gate.json')} was not deleted, changed or touched to manufacture freshness. Compact handoff regeneration NOT RUN due to that blocker.

Subsequent stages NOT RUN: {', '.join(notrun)}. Placement evidence and routing acceptance remain owed. Beacon and placement journal record this measured state. Exclusive writer scope PASS; protected preimages PASS. Delivery checks execution-recorded, inputs-verified, outputs-preserved are PASS for complete honest handback, separate from engineering INCOMPLETE. The provided preflight.py is run after packaging; its final receipt resides beside the outputs in scratch/final-preflight.json.
'''
(O/'report.md').write_text(report)
dump(O/'result.json',{'subject':env['subject'],'checks':{x:'PASS' for x in env['completion']['checks']},'unresolved':[]})
entries={}
for rec in records:entries['project/'+rec['path']]=P/rec['path']
for p in S.iterdir():
 if p.is_file() and p.name not in ['package.py','final-preflight.json']:entries['task/'+p.name]=p
for name in ['TASK.md','flow.yaml','beacon.md','journal-tail.md','normal-renewal-decision.json','preflight.py']:entries['handoff/'+name]=H/name
entries['task/envelope.json']=D/'envelope.json'
for name in ['report.md','evidence.json','result.json']:entries['delivery/'+name]=O/name
assert not any(p.is_symlink() for p in entries.values())
with tarfile.open(O/'evidence.tar.gz','w:gz') as tf:
 for name,p in sorted(entries.items()):tf.add(p,arcname=name,recursive=False)
members=[];seen=set()
with tarfile.open(O/'evidence.tar.gz','r:gz') as tf:
 for m in tf.getmembers():
  assert m.isfile() and m.name not in seen and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts
  assert not m.name.endswith(('.tar','.tar.gz','.tgz'));seen.add(m.name);data=tf.extractfile(m).read();assert len(data)==m.size
  h=hashlib.sha256(data).hexdigest();assert h==sha(entries[m.name]);members.append({'path':m.name,'size':m.size,'sha256':h})
assert seen==set(entries)
dump(O/'evidence-manifest.json',{'schema':1,'archive_sha256':sha(O/'evidence.tar.gz'),'archive_size':(O/'evidence.tar.gz').stat().st_size,'member_count':len(members),'members':members,'independent_reopen':'PASS; every regular member size/hash checked; no links, duplicate paths, traversal, or nested archive'})
print(json.dumps({'archive_sha256':sha(O/'evidence.tar.gz'),'archive_size':(O/'evidence.tar.gz').stat().st_size,'member_count':len(members),'scope':scope['status'],'protected':len(protected)},indent=2))
