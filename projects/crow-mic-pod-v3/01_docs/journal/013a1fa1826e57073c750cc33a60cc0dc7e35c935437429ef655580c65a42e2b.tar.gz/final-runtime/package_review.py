import json,hashlib,tarfile,io
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
R=Path('/tmp/rj45-pod-readability-review-fabfeatures1-vr3j_phk');B=R/'06_build/task_runs/rj45-pod-readability-review-fabfeatures1';S=B/'scratch';O=B/'outputs'
sha=lambda b:hashlib.sha256(b).hexdigest()
e=json.loads((B/'envelope.json').read_text()); checks=[]
for x in e['input_packet']:
 p=R/x['path'];data=p.read_bytes();checks.append({'path':x['path'],'size':len(data),'sha256':sha(data),'pass':len(data)==x['size'] and sha(data)==x['sha256']})
assert len(checks)==293 and all(x['pass'] for x in checks)
(S/'inputs-after.json').write_text(json.dumps({'checked_at':datetime.now(timezone.utc).isoformat(),'count':len(checks),'checks':checks},indent=2)+'\n')
for name,p in [('allocated-envelope.json',B/'envelope.json'),('owning-hash-algorithm.py',R/'context/skills/kicad-pcb/scripts/pre_route_review_check.py'),('expected-subject.json',R/'expected-subject.json')]: (S/name).write_bytes(p.read_bytes())
n=json.loads((S/'native-review.json').read_text());v=json.loads((S/'pixel-equivalence.json').read_text());sc=json.loads((S/'source-scope.json').read_text());sub=json.loads((S/'subjects.json').read_text())
assert all(x['outside_band_changed_pixels']==0 for x in v['pages'])
assert all(x['pass'] for x in n['invariants']) and n['circuit_native_pin_groups_equal'] and n['delta']['graph_equal'] and not sc['full_checkpoint_subject']['mismatches']
ev={'schema':1,'review_stage':'pre-route','review_kind':'schematic_render','reviewer_identity':'/root/carrier_rj45_native_pod_readability_fabfeatures1','context':'FRESH','created_at':datetime.now(timezone.utc).isoformat(),'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','subject':e['subject'],'envelope_sha256':sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode()),'exact_hashes':{k:v for k,v in sub['project'].items() if k.endswith('_sha256')},'methods':['Frozen owning hash algorithm for all seven subject identities','293 input file size/SHA256 checks before and after','pdftoppm RGB 144 dpi independent current/accepted four-page rasterization','PIL exact RGB max differences; only identity header band excluded','Actual host image inspection of four current integrated pages, padded headers and four connector/active details','Independent S-expression native component and pin graph parsing','Independent CircuitJSON source-port connectivity grouping and record multiset comparison','Independent maintained electrical invariants and first-power population reconciliation','Complete paired source-file inventory and reading every changed source hunk','Independent archive regular-member reopen, size and hash verification'],'counts':{'frozen_inputs':293,'current_pages':4,'accepted_pages':4,'current_visual_full_pages':4,'visual_detail_crops':4,'components':40,'nets':24,'physical_pins':103,'source_components':40,'schematic_components':40,'source_ports':103,'schematic_ports':103,'sheet_component_counts':[7,11,10,12],'installed_refs':33,'testpoints_excluded':7,'board_only_holes':2,'part_dossiers':34,'invariant_pass':39,'invariant_total':39,'pixels_outside_identity_band':8575200,'changed_pixels_outside_identity_band':0,'body_pixels':7884000,'changed_body_pixels':0,'source_files_compared':118,'source_files_equal':110,'paired_changed_files':8,'authored_changed_files':4,'current_only_packet_files':35},'pixel_equivalence':v,'native_review':n,'source_review':sc,'visual_observations':'raw/visual-observations.md','findings':[],'limitations':['Schematic readability authority only; no layout, routing, human orientation, release, purchasing or physical qualification acceptance','Current full checkpoint identity has 311 entries; 133 supplied project files reopened, 178 omitted/external entries identity-only; no accepted full checkpoint manifest supplied','ERC zero errors retains 158 classified warnings; CircuitJSON warnings preserved','SOURCE PASS and FULL INCOMPLETE with nine pod physical obligations retained; carrier 23 and LAYOUT001 3/3 preserved as commissioned context','FIRST-ARTICLE-ONLY/DO-NOT-ORDER; custom analog/power RJ45, not Ethernet/PoE, power-off mating','Nominal CAD spring-finger extent is not manufacturing tolerance or physical-fit guarantee','Startup wrapper errors and an accidental unbounded read-only import side effect are disclosed in raw/observed-startup-failures.md; only successful complete bounded measurements counted'],'inputs_verified':{'before':293,'after':293,'mismatches':0},'archive_scope':'Completed engineering methods/logs/runtime records, evidence observations, current and accepted page rasters and differences. Active packaging and subsequent preflight logs remain in allocated scratch; no recursive/self archive.'}
(O/'evidence.json').write_text(json.dumps(ev,indent=2)+'\n')
(O/'result.json').write_text(json.dumps({'subject':e['subject'],'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]},indent=2)+'\n')
files=[('raw/'+p.name,p) for p in sorted(S.iterdir()) if p.is_file() and p.name not in ['package-review.log','package-review.runtime.json']]
files += [('report.md',O/'report.md'),('evidence.json',O/'evidence.json')]
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,p in files:
  assert not p.is_symlink() and name not in ['evidence.tar.gz','evidence-manifest.json']
  b=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;t.addfile(info,io.BytesIO(b))
members=[];seen=set()
with tarfile.open(archive,'r:gz') as t:
 for m in t.getmembers():
  q=PurePosixPath(m.name);assert m.isfile() and not q.is_absolute() and '..' not in q.parts and m.name not in seen
  seen.add(m.name);b=t.extractfile(m).read();assert len(b)==m.size
  original=next(p for name,p in files if name==m.name);assert b==original.read_bytes()
  members.append({'path':m.name,'size':m.size,'sha256':sha(b)})
manifest={'schema':1,'archive_sha256':sha(archive.read_bytes()),'archive_size':archive.stat().st_size,'member_count':len(members),'members':members,'verification':'Every regular member independently reopened and compared to source bytes; no symlinks, traversal, duplicates or recursive archive.'}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert sorted(p.name for p in O.iterdir())==['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md','result.json']
print(json.dumps({'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'member_count':manifest['member_count'],'inputs_after':len(checks),'outputs':sorted(p.name for p in O.iterdir())},indent=2))
