from pathlib import Path, PurePosixPath
import sys, json, hashlib, tarfile, gzip, io, os, stat
from datetime import datetime, timezone

root=Path('/tmp/rj45-pod-topology-review-s1m1-2dwqo7_0')
run=root/'06_build/task_runs/rj45-pod-topology-review-s1m1'; out=run/'outputs'; s=run/'scratch'; cur=root/'project'
repo=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');sys.path.insert(0,str(repo/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet
e=TaskEnvelope.from_json((run/'envelope.json').read_text()); subject=e.subject.to_mapping()
ok,detail=verify_input_packet(e,root)
(s/'input-after.json').write_text(json.dumps({'status':'PASS' if ok else 'FAIL','count':len(e.input_packet),'detail':detail},indent=2,default=str)+'\n')
if not ok: raise SystemExit('input packet changed')

hashes=json.loads((root/'expected-subject.json').read_text())
report='''review_stage: pre-route
review_kind: topology
revieweridentity: carrier_rj45_native_pod_topology_s1m1
context: FRESH
date: 2026-09-13
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
netlist_sha256: b4edc879929e85fb35953e06f24ca6f8ade42b14d777b7751cbda47bc84aadff
parts_sha256: d0d0026dd67cbfaa98176799ea34ea3bfde384675d74d58d8cf8f0c88e41fd89
design_rules_sha256: 474e5d0a81baf576aefac32e9c60bce37704bb138961c16bf92573843b6409c4
schematic_pdf_sha256: a85a9a1e79dac95aa48a639bc7738986848ed8c14e8673441967dfe62ed6bb13
exact_netlist_sha256: 26f5b5819dda308da4d7f6df3e8a06f88c5b806c1e71f25cf600b6a56b78ee02
circuit_json_sha256: 9a1871284a29fa2fd63d58acdd6c6411bdc49797288b949161f49a24caa957b7
kicad_schematic_sha256: 1182894e471c6d7c2b86060359a02ce95288c647542b90ca9d2e5a8fe63e12b4

The exact frozen crow-mic-pod-v3 schematic is SOUND for the commissioned pre-route topology lens after the S1M-E3/61T renewal. No electrical-topology defect was found. This does not accept placement, copper, mechanical mating, fabrication, stock allocation, release, or ordering. FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains in force.

Independent measured coverage

- Verified all 297/297 frozen envelope inputs by declared size and SHA-256 before analysis and again immediately before packaging. The owning frozen pre_route_review_check.py independently reproduced all seven expected subject hashes.
- Parsed the current CircuitJSON and native KiCad netlist directly: 40/40 components, 103/103 physical pins, 99 connected endpoints, 20 connected source nets, and four explicit NC pins. Native representation contains 24 nets and 103 nodes because U2.3, U2.7, U3.1 and U3.2 each have a one-pin unconnected net. The maintained electrical invariants grade 39/39 PASS.
- Compared 118 paths common to the supplied current and preceding subsets: 111 are byte-identical and seven differ. Forty current files have no preceding counterpart because the preceding snapshot is intentionally partial; the D1 renewal itself adds the Vishay dossier/PDF and footprint. No preceding file was removed from the current packet.
- CircuitJSON remains 1,188 records. Its substantive changes are D1 manufacturer/supplier identity and its rendered value text. Fifteen unrelated supplier-footprint warning rows reorder/regenerate IDs and source metadata changes. Port, trace, net, schematic wire and PCB geometry records are unchanged. The native netlist changes D1 value/MPN/supplier/footprint plus exporter timestamps/UUIDs; every net and node is unchanged.

Current component and population inventory

The 40 schematic identities comprise 11 capacitors, 14 resistors, three ICs, two diodes, one fuse, J1, MK1 and seven test pads. The exact first-power list contains 33 refs: 31 fitted SMD, manually fitted J1, and MK1 as the off-board capsule represented by its two-wire board landing. Board-mounted fitted population is therefore 32; the machine SMD population is 31. TP1–TP7 are bare copper pads and are excluded from BOM/CPL. The source tree contains 35 part.yaml dossiers because the preceding JKSEMI dossier remains present as unused source evidence while the Vishay dossier is added; it is not a second D1.

Exact S1M source delta and electrical judgment

D1 changes from Shenzhen Jinkaisheng 1N4007(M7)SMA / C2972759 / crow_mic_pod_v3:JKSEMI_1N4007_M7_SMA to Vishay General Semiconductor S1M-E3/61T / C144860 / crow_mic_pod_v3:Vishay_S1M_SMA. The current four-page Vishay document 88711 is hash-bound in the new dossier. Its pages were inspected as images: page 1 explicitly states that the color band denotes the cathode end and rates S1M at 1 kV, 1 A, 1.1 V maximum forward drop at 1 A and 30 A for the specified 8.3 ms surge; page 2 gives 5 uA maximum reverse current at 25 C and 50 uA at 125 C; page 3 identifies the cathode band on the package outline.

The D1 footprint keeps the preceding 2.50 x 1.80 mm pads at 4.00 mm centers and all geometric primitives; only identity/description/value text changes. Pad 1 is the left pad beside the cathode-side silk line and is K/VIN_PROTECTED. Pad 2 is A/12V_FUSED. TSX, CircuitJSON, native schematic and exact netlist all agree. Thus correct-polarity current flows 12V_POD -> F1 -> 12V_FUSED -> D1 anode/pad 2 -> D1 cathode/pad 1 -> VIN_PROTECTED. D2 cathode, C1/C2, R14, TP2 and U2 IN/EN remain on VIN_PROTECTED; D2 anode and R14 return to GND.

The new S1M limits are numerically identical to the preceding rectifier limits relevant here. At the published 50 uA hot reverse-leakage maximum and R14's +1% value of 4.747 kohm, the protected node can reach -0.23735 V. The current TI U2 dossier now records the primary-source -0.3 V IN-to-GND absolute minimum, visibly confirmed on TI PDF page 5, leaving 62.65 mV margin. R14 worst-resistance dissipation is 37.45 mW at 13.2 V and 127.95 mW at the retained 24.4 V clamp boundary, below 250 mW. The 1 kV/1 A diode ratings remain above the 24.4 V protected boundary and 100 mA spoke maximum.

Retained topology and ratings

J1's complete map is unchanged and independently found in all generated domains: pins 1/3/7 = 12V_POD, 2/6/8 = GND, 5 = AUDIO_P, 4 = AUDIO_N, and shell pins 9/10 = POD_SHIELD. POD_SHIELD has exactly J1.9 and J1.10 and no GND node. This is custom analog/DC on a factory Cat6A cable, not Ethernet or PoE, and mating remains power-off.

U2 pins 8/5 remain on VIN_PROTECTED, pin 1 on 5V_QUIET, pins 4/9 on GND, pin 6 on LDO_NR, and pins 3 NC / 7 DNC remain open. The 324 kohm / 100 kohm feedback network and 10 nF feed-forward path are unchanged; independently recalculated worst corners are 4.792587–5.229513 V. Microphone bias/coupling, VREF buffer, 18k/22k inverting preamp, equal 10k polarity restore, private spare follower and the two 100-ohm audio legs remain unchanged. U3 pins 3/5 clamp AUDIO_P/AUDIO_N, pin 4 returns to GND, and pins 1/2 remain open.

Rendered review and equality

All 4/4 current PDF pages were rendered at 144 dpi to 1800 x 1215 RGB images and visually inspected, covering 7 + 11 + 10 + 12 = 40 components. Connector labels and wires, D1/D2 polarity, shield isolation, U2 NC/DNC/PowerPAD, capsule polarity, signal paths, U3 NCs and all page headers are legible. The current header carries CircuitJSON prefix 9a1871284a29fa2f and correct page/component counts.

All four images were pixel-compared with the preceding accepted PDF render. Pages 2–4 are exactly equal below y=125: 5,886,000/5,886,000 body pixels. Page 1 has exactly 784 changed body pixels, confined to [1001,332,1105,345), the changed D1 value text. The generated hash identity line differs only within [349,100,797,117) on every page. Excluding that identity line and the D1-value rectangle gives 8,491,375/8,491,375 equal pixels. Fresh visual review, rather than equality alone, covers the changed D1 drawing and every page.

Warnings, observation and remaining limits

ERC is 0 errors and 158 classified warnings: 64 lib_symbol_issues and 94 endpoint_off_grid. Zero errors is not an all-severity-clean claim. CircuitJSON retains 15 supplier footprint mismatch warnings unrelated to D1.

One nonblocking source-documentation observation remains: unchanged electrical_invariants.yaml rationale text for D1.1/D1.2 still says “1N4007” although the executable assertions address ref D1 and correctly pass for S1M. The stale noun does not alter a pin, net, rating, hash, or the topology verdict, but should be renamed to the current rectifier in a later source cleanup.

The connector SOURCE gate is PASS while FULL is authentically INCOMPLETE with nine physical obligations. Routing/return/ESD geometry, the current conditional 23-locator exception's atlas/render acceptance, physical cable/capsule mating, solder-fillet validation for the retained land, stock allocation, first-article rail/noise/gain/polarity/EMC/thermal tests, and release acceptance remain owed at their owning gates. No board claim is made from this schematic evidence.

Evidence integrity

Every engineering and image-analysis subprocess was launched with finite direct argv through pipeline_runtime.run_stage, explicit cwd/environment, raw log, duration and runtime receipt in allocated scratch. One initial direct netlist parser attempt failed on a tuple-unpack assumption; its log and runtime receipt are retained, the parser was corrected, and the complete census then passed. Host image viewing covered the four schematic pages, all four Vishay PDF pages, and TI page 5. The evidence archive reopens every regular member and rejects symlinks, traversal, duplicates and embedded archives. The supplied preflight is run after packaging. Delivery PASS establishes complete exact-subject evidence, not engineering adoption.
'''
(out/'report.md').write_text(report)

analysis=json.loads((s/'analysis.json').read_text()); pixels=json.loads((s/'pixel-equivalence.json').read_text()); inv=json.loads((s/'invariant-results.json').read_text())
evidence={
 'schema':1,'review_stage':'pre-route','review_kind':'topology','revieweridentity':'carrier_rj45_native_pod_topology_s1m1','context':'FRESH','date':'2026-09-13',
 'verdict':{'design':'SOUND','order':'DO-NOT-ORDER'},'subject':subject,'hashes':hashes,
 'methods':['297-item envelope size/SHA-256 verification before work and before packaging','frozen owning pre_route_review_check.py hash algorithms','independent CircuitJSON source component/port/net census','independent KiCad netlist net/node parser','39-row authored electrical-invariant evaluation','current/preceding recursive file hash comparison and unified diffs','144-dpi four-page RGB render, visual inspection and pixel equality','visual inspection of all four Vishay datasheet pages and TI absolute-maximum page','independent leakage, voltage-margin, resistor-power and LDO-corner calculations'],
 'counts':{'inputs_verified':'297/297 twice','component_identities':'40/40','physical_pins':'103/103','connected_endpoints':'99/99','source_nets':'20/20','native_nets':'24/24','native_nodes':'103/103','explicit_nc':'4/4','electrical_invariants':'39/39 PASS','pdf_pages':'4/4','page_components':['7/7','11/11','10/10','12/12'],'part_dossiers':35,'first_power_refs':33,'fitted_smd':31,'board_mounted_fitted':32,'erc_errors':0,'erc_warnings':158,'connector_full_obligations':9},
 'source_delta':{'old':{'manufacturer':'Shenzhen Jinkaisheng Electronics','mpn':'1N4007(M7)SMA','lcsc':'C2972759','footprint':'crow_mic_pod_v3:JKSEMI_1N4007_M7_SMA'},'new':{'manufacturer':'Vishay General Semiconductor','mpn':'S1M-E3/61T','lcsc':'C144860','footprint':'crow_mic_pod_v3:Vishay_S1M_SMA','datasheet_sha256':'49c11fe1f333fda1bcdacc72754927dda4ee5bf977bf88d3c46eb1cd6ffe9277','datasheet_pages':4},'topology_unchanged':True,'numeric_limits_unchanged':True,'footprint_geometry_unchanged':True,'u2_added_authority':'IN to GND absolute minimum -0.3 V'},
 'd1_mapping':{'pad1':{'function':'K','net':'VIN_PROTECTED','band_side':True},'pad2':{'function':'A','net':'12V_FUSED'},'source_chain':['12V_POD','F1','12V_FUSED','D1.A/pad2','D1.K/pad1','VIN_PROTECTED'],'cathode_band_authority':['Vishay 88711 page 1 polarity statement','Vishay 88711 page 3 package outline'],'leakage_drop_v':0.23735,'u2_negative_limit_v':-0.3,'margin_v':0.06265,'r14_power_w_at_13v2':0.0374468,'r14_power_w_at_24v4':0.1279519},
 'inventory':{'components':analysis['components'],'pin_net_map_file':'evidence/pin-net-map.json','native_net_map_file':'evidence/native-net-map.json','explicit_nc':analysis['nc'],'source_nets':analysis['source_nets']},
 'comparison':analysis['file_delta'],'pixel_equivalence':pixels,'invariants':{'graded':inv['graded'],'passed':inv['passed']},
 'findings':[{'severity':'P2','status':'OPEN_NONBLOCKING','finding':'electrical_invariants.yaml D1 rationale retains the old noun 1N4007; executable ref/pin/net assertions remain correct for S1M and all pass.'}],
 'limits':['schematic review only; no PCB generation or board claim','connector FULL physical evidence incomplete with nine obligations','routing, locator atlas/render acceptance, physical mating, allocation, first article, fabrication and release remain unaccepted','FIRST-ARTICLE-ONLY / DO-NOT-ORDER']}
(out/'evidence.json').write_text(json.dumps(evidence,indent=2,sort_keys=True)+'\n')

# Build a nonrecursive evidence archive with explicit safe names.
members=[]
def add(src,arc): members.append((Path(src),arc))
add(out/'report.md','review/report.md'); add(out/'evidence.json','review/evidence.json')
for name in ['analysis.json','component-inventory.json','pin-net-map.json','native-net-map.json','invariant-results.json','pixel-equivalence.json','input-before.json','input-after.json']:
 add(s/name,'evidence/'+name)
for name in ['analyze_subject.py','verify_inputs.py','compare_images.py','validate_invariants.py','artifact_deltas.py','run_tools.py','run_compare.py','run_more.py','run_vishay_all.py']:
 add(s/name,'methods/'+name)
for p in sorted(s.glob('*.log'))+sorted(s.glob('*.runtime.json'))+sorted(s.glob('delta-*.txt')):
 add(p,'runtime/'+p.name)
for i in range(1,5):
 add(s/f'current-{i}.png',f'images/current-schematic-{i}.png'); add(s/f'preceding-{i}.png',f'images/preceding-schematic-{i}.png'); add(s/f'vishay-{i}.png',f'images/vishay-datasheet-{i}.png')
add(s/'ti-page5.png','images/ti-u2-page5.png')
add(cur/'02_parts/S1M-E3-61T/part.yaml','source/S1M-E3-61T-part.yaml')
add(cur/'02_parts/TPS7A4901DGNR/part.yaml','source/TPS7A4901DGNR-part.yaml')
add(cur/'03_src/lib/crow_mic_pod_v3.pretty/Vishay_S1M_SMA.kicad_mod','source/Vishay_S1M_SMA.kicad_mod')
add(cur/'03_src/rules/electrical_invariants.yaml','source/electrical_invariants.yaml')
seen=set()
for src,arc in members:
 pp=PurePosixPath(arc)
 if pp.is_absolute() or '..' in pp.parts or arc in seen or not src.is_file() or src.is_symlink() or arc.endswith(('.tar','.tar.gz','.tgz')): raise SystemExit('unsafe member '+arc)
 seen.add(arc)
archive=out/'evidence.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tf:
   for src,arc in members:
    data=src.read_bytes(); ti=tarfile.TarInfo(arc);ti.size=len(data);ti.mode=0o644;ti.mtime=0;ti.uid=ti.gid=0;ti.uname=ti.gname='';tf.addfile(ti,io.BytesIO(data))
records=[]
with tarfile.open(archive,'r:gz') as tf:
 names=[]
 for m in tf.getmembers():
  pp=PurePosixPath(m.name)
  if not m.isfile() or pp.is_absolute() or '..' in pp.parts or m.name in names or m.name.endswith(('.tar','.tar.gz','.tgz')): raise SystemExit('invalid archive member')
  names.append(m.name); data=tf.extractfile(m).read(); records.append({'path':m.name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 if set(names)!=seen: raise SystemExit('archive census mismatch')
manifest={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_size':archive.stat().st_size,'member_count':len(records),'members':records}
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
result={'subject':subject,'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]}
(out/'result.json').write_text(json.dumps(result,sort_keys=True,separators=(',',':'))+'\n')
print(json.dumps({'verdict':'SOUND','archive_members':len(records),'archive_size':archive.stat().st_size,'inputs':len(e.input_packet)}))
