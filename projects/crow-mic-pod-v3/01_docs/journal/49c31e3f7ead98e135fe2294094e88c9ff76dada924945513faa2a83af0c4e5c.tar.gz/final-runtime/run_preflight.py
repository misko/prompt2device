from pathlib import Path
import os,sys,json
repo=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');sys.path.insert(0,str(repo/'skills/pcb-design/scripts'))
from pipeline_runtime import run_stage
root=Path('/tmp/rj45-pod-topology-review-s1m1-2dwqo7_0');s=root/'06_build/task_runs/rj45-pod-topology-review-s1m1/scratch';env={'PATH':os.environ['PATH'],'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','HOME':os.environ['HOME'],'PYTHONDONTWRITEBYTECODE':'1'}
o=run_stage({'id':'delivery_preflight','work_class':'local','timeout_s':180},['/usr/bin/python3','-B',str(root/'preflight.py'),str(root/'06_build/task_runs/rj45-pod-topology-review-s1m1/envelope.json')],log_path=s/'delivery_preflight.log',cwd=root,env=env,heartbeat_s=10,console=None)
(s/'delivery_preflight.runtime.json').write_text(json.dumps(o.to_mapping(),indent=2)+'\n')
print(o.status)
raise SystemExit(0 if o.status=='PASS' else 1)
