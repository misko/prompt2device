from run import *
import io,tarfile

OUT=SCR.parent/'outputs'
envelope=json.loads((SCR.parent/'envelope.json').read_text())
subject=envelope['subject']
measurements=json.loads((SCR/'measurements.json').read_text())
report='''review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_pod_diodes_mountedframe1 (fresh independent agent)
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: a44b769b1a5ad5fa959b476bd30f91a64aeaba9ad64d7868fa4e60ffbb62ee48
parts_sha256: adf3f7221a131e270f963fab153a2e2f56262932f1e272af9cbc0e4814d5c8a6
design_rules_sha256: 02c4ed58432368b92e3019a06bf20c137dbf90765af16c96c458790e88d54a9f

Coverage is limited to commissioned refs D1 and D2. Both PASS. This is not whole-board acceptance, routing review, assembly inspection, or permission to order. The three hashes above are immutable subject bindings, not independently reviewed conclusions. Exact envelope subject is retained in evidence.json.

D1 — VERDICT: PASS

Primary: JKSEMI 1N4007(M7)SMA, 2021-10-21 revision c; SHA-256 f893d8385c6fee5af85b9053653bd8e93547c335c031cbab9ecb592c0bb5eddd. Inspected page 1 product illustration, page 2 characteristic figures, page 3 PACKAGE OUTLINE and recommended mounting pads, including an enlarged page-3 render.

The page-1 oblique top illustration shows an end band on a two-terminal SMA rectifier. I interpret this visible band as the conventional cathode mark. The PDF does not literally label that band cathode and does not assign numeric pin IDs; neither omission establishes an ambiguous mark or a pin error. Page 3 explicitly identifies two leads and shows the two opposed terminations and two mounting lands. No exposed pad or fused group is shown. Top/side/end and underside mechanical projections are not numbered pin diagrams and were not mirrored to derive polarity. The banded terminal is K, and the opposite terminal is A; local numeric IDs are compared through those physical functions.

D1 pin 1 (K): expected banded cathode at one end, receiving forward current from A; observed W land at component-top (-2.000,0.000), VIN_PROTECTED. This is consistent with the output of the series rectifier fed by 12V_FUSED.
D1 pin 2 (A): expected opposite terminal and upstream positive supply for forward series conduction; observed E land (+2.000,0.000), 12V_FUSED. Forward direction is 12V_FUSED -> A -> K -> VIN_PROTECTED.

Measured from native dossier: 2 copper pad records, 2 unique numeric pad identities, 2 separate physical terminal identities, 0 EP, 0 collapsed identities, 0 fused aliases. Pad centers are 4.000 mm apart; each land is 2.5 x 1.8 mm. A two-terminal collinear part has no pin-1 corner or CW/CCW winding; the dossier's n/a is correct. Orienting the banded end west requires only rotation of the top component, with no mirror. Front mount at (39.500,35.600), native rotation 0 degrees, gives pad 1 (37.500,35.600) and pad 2 (41.500,35.600), exactly as observed.

D2 — VERDICT: PASS

Primary: Littelfuse SMBJ series v4, revised JC.07/04/25; SHA-256 d7df155be4b1f612085401e8c946f065e284d65a0e7de22b9225a7b73946e51b. Inspected page 1 Functional Diagram and product images, page 2 exact SMBJ15A row, page 5 Physical Specifications and Dimensions, page 6 Part Numbering/Marking System and tape polarity figure.

Page 5 depicts the package top with cathode band at the left end and the other lead at the right; its lower body drawing is a side profile. Page 6 shows a top marking view with cathode band at the upper end, reconciled with page 5 by a 90-degree rotation, not a reflection. The page-1 unidirectional diagram independently identifies K and A. SMBJ15A is the unidirectional variant, with 15 V standoff in its exact table row. Two opposed SMB J-bend terminals and no EP or fused identities are shown. Manufacturer numeric pin numbering is absent; physical K/A identities provide the comparison.

D2 pin 1 (K): expected banded terminal on the positive protected rail for reverse-biased shunt protection; observed W land (-2.150,0.000), VIN_PROTECTED.
D2 pin 2 (A): expected opposite terminal on return; observed E land (+2.150,0.000), GND. This maps the unidirectional TVS correctly across the protected positive rail and ground.

Measured from native dossier: 2 copper pad records, 2 unique numeric pad identities, 2 separate physical terminal identities, 0 EP, 0 collapsed identities, 0 fused aliases. Pad centers are 4.300 mm apart; lands are 2.5 x 2.3 mm. Two collinear terminals establish no winding or pin-1 corner; dossier n/a is correct. Front mount at (27.300,38.000), native rotation -90 degrees, gives K/pad 1 (27.300,35.850) and A/pad 2 (27.300,40.150). In component-top coordinates K remains west; native north is the rotated board-front projection, not a mirroring defect.

Pairwise check: these are different parts and different circuit roles, not duplicate instances. Both use pad 1 = K and pad 2 = A; both cathodes connect to VIN_PROTECTED. D1's A connects to the upstream 12V_FUSED rail, while D2's A connects to ground, consistent with series rectification versus shunt TVS protection. No unexplained instance asymmetry is present.

Method and limits: inspected actual PDF images before comparing the dossier tables; extracted text was used to locate pages. Both dossiers explicitly declare mounted side and component-top convention. Native counts were measured by parsing their pad records, and native positions reconstructed using the stated translations and KiCad rotations. No live design, schematic, historical review, or unrelated primary document was inspected. The dossiers' verification-note claims were not treated as evidence. Only the commissioned pin/package identity and function-net sanity questions are graded. All original input hashes and sizes were verified before and after review. There are no unresolved engineering findings within this scope.
'''
findings=[
 {'ref':'D1','verdict':'PASS','expected':'Two opposed SMA terminals; visible conventional cathode band identifies K, opposite terminal A; series forward feed A to K.','observed':'pad 1 W K VIN_PROTECTED; pad 2 E A 12V_FUSED; front mount native geometry matches.','polarity_evidence':'JKSEMI p1 conventional rectifier band interpretation; no literal polarity label or numeric pin assignment claimed.','primary_pages':[1,2,3]},
 {'ref':'D2','verdict':'PASS','expected':'Two opposed SMB terminals; labeled cathode band K at left in top view, A opposite; positive-rail shunt K to positive, A to return.','observed':'pad 1 W K VIN_PROTECTED; pad 2 E A GND; front mount native geometry matches.','polarity_evidence':'Littelfuse p1 Functional Diagram, p5 Dimensions/Polarity, p6 marking diagram.','primary_pages':[1,2,5,6]},
]
evidence={'schema':1,'subject':subject,'review_stage':'pre-route','review_kind':'pin','reviewer':'/root/rj45_pin_pod_diodes_mountedframe1','context':'FRESH','verdict':'SOUND','order_verdict':'DO-NOT-ORDER','coverage':['D1','D2'],'whole_board_acceptance':False,'findings':findings,'measured_counts':measurements,'primary_documents':[i for i in envelope['input_packet'] if i['path'].endswith('.pdf')],'methods':['Verify every input SHA-256 and size before and after review.','Locate datasheet figures with pdftotext and render exact pages with pdftoppm; inspect with view_image before dossier comparison.','Interpret conventional rectifier band as cathode without imposing an unsupported literal-label requirement.','Compare physical K/A, collinear geometry, no EP, no collapsed aliases, mounted front-side frame and function-net mapping.','Parse all native pad records, reconstruct board positions and compare both commissioned instances.','Create and reopen evidence archive, reject unsafe members and verify every member SHA-256 and size.'],'unresolved_findings':[]}
(OUT/'report.md').write_text(report)
(OUT/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(OUT/'result.json').write_text(json.dumps({'subject':subject,'checks':{c:'PASS' for c in envelope['completion']['checks']},'unresolved':[]},indent=2)+'\n')
verify('after')
for name in ['TASK.md','pin-review-protocol.md','preflight.py']:
    (SCR/name).write_bytes((ROOT/name).read_bytes())
(SCR/'envelope.json').write_bytes((SCR.parent/'envelope.json').read_bytes())
members=[]
archive=OUT/'evidence.tar.gz'
files=[(p,'scratch/'+p.relative_to(SCR).as_posix()) for p in sorted(SCR.rglob('*')) if p.is_file()]
files += [(OUT/n,n) for n in ['report.md','evidence.json','result.json']]
with tarfile.open(archive,'w:gz') as tf:
    for p,name in files:
        assert not p.is_symlink() and not name.endswith(('.tar','.tar.gz','.tgz'))
        b=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644
        tf.addfile(info,io.BytesIO(b));members.append({'path':name,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
with tarfile.open(archive,'r:gz') as tf:
    seen=set()
    for m,row in zip(tf.getmembers(),members,strict=True):
        assert m.isfile() and m.name not in seen and not m.name.startswith('/') and '..' not in Path(m.name).parts
        seen.add(m.name);b=tf.extractfile(m).read()
        assert m.name==row['path'] and len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256']
b=archive.read_bytes()
(OUT/'evidence-manifest.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(b).hexdigest(),'archive_size':len(b),'member_count':len(members),'members':members},indent=2)+'\n')
print(json.dumps({'verdict':'SOUND','archive_sha256':hashlib.sha256(b).hexdigest(),'archive_size':len(b),'member_count':len(members)}))
