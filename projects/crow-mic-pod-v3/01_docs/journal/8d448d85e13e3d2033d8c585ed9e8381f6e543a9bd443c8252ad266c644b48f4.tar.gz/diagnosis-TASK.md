# Independent RJ45 envelope diagnosis

Fresh READ_ONLY D-BACK judgment on one newly observed exact-product failure.
Root owns both live boards. Work cutoff 2026-09-13T04:15:41.724606+00:00; hard deadline 2026-09-13T04:25:41.724606+00:00. Reserve final
10 minutes for complete evidence delivery. No children, replacements, live edits,
gate/schema/tolerance changes, geometry variants or camera searches.

Read input/CLAUDE.md, pcb-design skill, supplied lifecycle/canon/runtime and
relevant model-registration sources. Current pod normal placement stops at
P-MODEL-REG: J1 outward Fab 1.059223mm versus 0.50mm. U2 passes. Carrier current
same official model and byte-identical source footprint passes at all 8 refs,
Fab outward about .03-.084mm versus .35mm. Both retain normal native coupon,
native STEP, plan/side images and raw receipts. Do not inherit either verdict
as physical truth. Existing 8-coupon and singleton renders have visibly
different measured lateral envelopes; root has not established the cause.

Independently reconcile the exact footprint Fab and courtyard, official STEP,
manufacturer drawing, transforms and the measurement consumer. Distinguish
main shell from side features, pins and posts using real geometry. Quantify
which physical features lie outside Fab, whether original part datum/source
or checker classification is wrong, and whether same physical extent is
measured consistently for both boards. Inspect actual retained images and
native exported solids, not only intended model dimensions. Verify source
footprint byte equality and native normalized datums separately. Read actual
segmentation logic; image/component size, sampling and search window are
possible causes, not conclusions. Do not import the checker's transform or
envelope predicate as an independent geometry proof.

Use one bounded read-only census of the complete affected feature population.
Reuse existing images and native exports first. Any additional native geometry
measurement runs only in scratch with shared pipeline_runtime.run_stage,
explicit cwd/environment and <=300s timeout. Preserve exact commands, native
tool IDs, parsed shape/solid counts, units, transforms and uncertainty. If a
single focused diagnostic render is necessary, specify the discriminating
hypothesis before running; no recipe sweep or candidate source patch.
Independent primary drawing/native geometry should decide whether to correct
footprint datum, model representation or measurement semantics. Explain effects
on both boards and which downstream evidence would invalidate. Do not enlarge
Fab or relax tolerance to pass; an engineering-source correction needs actual
manufacturer evidence and later independent source acceptance.

This is diagnosis, not a third fuse-model method or third orientation-camera
variant. Their exhausted histories remain unchanged. No automatic reset of
any earlier source campaign, and no new implementation authorized by this
commission. If diagnosis supports a new distinct scope, state exact causality,
minimal owning source changes, strongest relevant negative controls and a
bounded implementation hypothesis. If evidence cannot decide, report INCOMPLETE
with the missing fact rather than prescribe a generic CAD parser/framework.
No waiver, human orientation approval, placement/routing acceptance, release,
order or physical qualification. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.

Only inputs frozen here are provided as prior context. Extra read-only exact
dependencies may be copied from /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901 but must be hashed and named. Use
/usr/bin/python3 -B. Outputs EXACTLY report.md, evidence.json,
evidence-manifest.json, evidence.tar.gz, result.json under allocated outputs.
Evidence domain_result is a string causal verdict, separate from delivery.
Archive only new reviewer methods/measurements, referencing frozen inherited
evidence rather than nesting archives. Manifest archive_sha256/archive_size/
member_count/members(path,size,sha256). Reopen every regular member; reject
symlinks/traversal/duplicate members. Verify all frozen inputs before/after.
result.json exact envelope subject and checks evidence-complete,inputs-verified,
review-complete PASS only for honest complete handback; unresolved findings may
remain explicit in the engineering report. Run supplied preflight.py, then
actual FINAL immediately. Root handles closure/preservation/adoption.
