from pathlib import Path
from datetime import datetime, timezone, timedelta
import sys, json, hashlib, shutil, tempfile
sys.dont_write_bytecode = True
R = Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
N = Path(__file__).parent
name = 'rj45-jack-envelope-diagnosis'
assert not (N / (name + '-opened.json')).exists()
probe = json.loads((N/'rj45-jack-envelope-diagnosis-availability-opened.json').read_text())
assert json.loads(Path(probe['attempt']).read_text())['status'] == 'PASS'
D = Path(tempfile.mkdtemp(prefix=name+'-'))
def copy(rel):
    p = R/rel
    q = D/'input'/rel
    assert p.exists(), p
    if p.is_dir():
        for f in sorted(p.rglob('*')):
            if f.is_file() and '__pycache__' not in f.parts:
                assert not f.is_symlink(), f
                dest=q/f.relative_to(p);dest.parent.mkdir(parents=True, exist_ok=True);shutil.copy2(f,dest)
    else:
        assert not p.is_symlink()
        q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for rel in ['CLAUDE.md', 'skills/pcb-design/SKILL.md', 'skills/pcb-design/references/lifecycle-and-backtrack.md', 'skills/pcb-design/references/execution-runtime.md', 'skills/kicad-pcb/references/design-policies.md', 'skills/jlcpcb-fab/references/digital-twin.md', 'skills/jlcpcb-fab/references/connector-orientation.md', 'tests/README.md', 'tests/t1_model_registration.py', 'skills/jlcpcb-fab/scripts', 'skills/pcb-design/scripts']:
    copy(rel)
for slug, board, lib in [('crow-audio-carrier-v1','crow_audio_carrier_v1','crow_audio_carrier'),('crow-mic-pod-v3','crow_mic_pod_v3','crow_mic_pod_v3')]:
    prefix='projects/'+slug+'/'
    for rel in ['01_docs/STATUS.md','01_docs/findings.yaml','03_src/floorplan.yaml','03_src/rules/model_registration.yaml','03_src/lib/'+lib+'.pretty/Wurth_615008160221_RJ45.kicad_mod','03_src/lib/3dmodels/wurth/J_Wurth_WR-MJ_615008160221.step','02_parts/615008160221','04_kicad/'+board+'.kicad_pcb','06_build/pre_route/model_registration.md']:
        copy(prefix+rel)
copy('projects/crow-audio-carrier-v1/06_build/pre_route/native_registration/wurth-615008160221-side-entry')
copy('projects/crow-mic-pod-v3/06_build/pre_route/native_registration/failed_attempts/j1_wurth_615008160221_official_step-20260913T033812Z-c43712688cf4')
for slug,task in [('crow-audio-carrier-v1','rj45-carrier-placement-after-orientation1'),('crow-mic-pod-v3','rj45-pod-placement-after-orientation1')]:
    for f in ['report.md','evidence.json','evidence-manifest.json']:
        copy('projects/'+slug+'/06_build/task_runs/'+task+'/outputs/'+f)
    shutil.copy2(N/(task+'-closeout-summary.json'),D/(task+'-closeout-summary.json'))
shutil.copy2('/tmp/carrier-locator-implementation-availability-6c_4vwal/preflight.py',D/'preflight.py')
now=datetime.now(timezone.utc);cut=now+timedelta(minutes=20);hard=now+timedelta(minutes=30)
(D/'TASK.md').write_text('''# Independent RJ45 envelope diagnosis

Fresh READ_ONLY D-BACK judgment on one newly observed exact-product failure.
Root owns both live boards. Work cutoff CUT; hard deadline HARD. Reserve final
10 minutes for complete evidence delivery. No children, replacements, live edits,
gate/schema/tolerance changes, geometry variants or camera searches.

Read input/CLAUDE.md, pcb-design skill, supplied lifecycle/canon/runtime and
relevant model-registration sources. Current pod normal placement stops at
P-MODEL-REG: J1 outward Fab 1.059223mm versus 0.50mm. U2 passes. Carrier current
same official model and byte-identical source footprint passes at all 8 refs,
Fab outward about .03-.084mm versus .35mm. Both retain normal native coupon,
native STEP, plan/side images and raw receipts. Do not inherit either verdict
as physical truth. Existing 8-coupon and singleton renders have visibly
different measured lateral envelopes; root has not established the cause.

Independently reconcile the exact footprint Fab and courtyard, official STEP,
manufacturer drawing, transforms and the measurement consumer. Distinguish
main shell from side features, pins and posts using real geometry. Quantify
which physical features lie outside Fab, whether original part datum/source
or checker classification is wrong, and whether same physical extent is
measured consistently for both boards. Inspect actual retained images and
native exported solids, not only intended model dimensions. Verify source
footprint byte equality and native normalized datums separately. Read actual
segmentation logic; image/component size, sampling and search window are
possible causes, not conclusions. Do not import the checker's transform or
envelope predicate as an independent geometry proof.

Use one bounded read-only census of the complete affected feature population.
Reuse existing images and native exports first. Any additional native geometry
measurement runs only in scratch with shared pipeline_runtime.run_stage,
explicit cwd/environment and <=300s timeout. Preserve exact commands, native
tool IDs, parsed shape/solid counts, units, transforms and uncertainty. If a
single focused diagnostic render is necessary, specify the discriminating
hypothesis before running; no recipe sweep or candidate source patch.
Independent primary drawing/native geometry should decide whether to correct
footprint datum, model representation or measurement semantics. Explain effects
on both boards and which downstream evidence would invalidate. Do not enlarge
Fab or relax tolerance to pass; an engineering-source correction needs actual
manufacturer evidence and later independent source acceptance.

This is diagnosis, not a third fuse-model method or third orientation-camera
variant. Their exhausted histories remain unchanged. No automatic reset of
any earlier source campaign, and no new implementation authorized by this
commission. If diagnosis supports a new distinct scope, state exact causality,
minimal owning source changes, strongest relevant negative controls and a
bounded implementation hypothesis. If evidence cannot decide, report INCOMPLETE
with the missing fact rather than prescribe a generic CAD parser/framework.
No waiver, human orientation approval, placement/routing acceptance, release,
order or physical qualification. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.

Only inputs frozen here are provided as prior context. Extra read-only exact
dependencies may be copied from RROOT but must be hashed and named. Use
/usr/bin/python3 -B. Outputs EXACTLY report.md, evidence.json,
evidence-manifest.json, evidence.tar.gz, result.json under allocated outputs.
Evidence domain_result is a string causal verdict, separate from delivery.
Archive only new reviewer methods/measurements, referencing frozen inherited
evidence rather than nesting archives. Manifest archive_sha256/archive_size/
member_count/members(path,size,sha256). Reopen every regular member; reject
symlinks/traversal/duplicate members. Verify all frozen inputs before/after.
result.json exact envelope subject and checks evidence-complete,inputs-verified,
review-complete PASS only for honest complete handback; unresolved findings may
remain explicit in the engineering report. Run supplied preflight.py, then
actual FINAL immediately. Root handles closure/preservation/adoption.
'''.replace('CUT',cut.isoformat()).replace('HARD',hard.isoformat()).replace('RROOT',str(R)))
items=[]
for p in sorted(D.rglob('*')):
    if p.is_file():
        b=p.read_bytes();items.append({'name':f'input_{len(items):04d}','path':p.relative_to(D).as_posix(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput, subject_identity
from pipeline_runtime import open_agent_attempt
s=subject_identity('jack_envelope_diagnosis',1,[TypedIdentityInput('packet','sequence',items,json.dumps(items,sort_keys=True).encode())])
e=TaskEnvelope(schema=2,task_id=name,stage_id='KICAD-PLACEMENT',run_id=name,subject=s,executor='agent',execution_class='review_wait',recommended_agent_role='judgment',agent_role='judgment',role_escalation_reason=None,context_mode='FRESH',input_handoff_id=name,input_packet=items,deadline_at=hard.isoformat().replace('+00:00','Z'),max_nonimproving_attempts=1,replacement_limit=0,writer_scope={'mode':'READ_ONLY','paths':[]},output_path=f'06_build/task_runs/{name}/attempt.json',completion={'outputs':['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md'],'checks':['evidence-complete','inputs-verified','review-complete']})
o=open_agent_attempt(e,cwd=D);o.update(project=str(D),envelope=str(D/e.output_path).replace('attempt.json','envelope.json'),task=str(D/'TASK.md'),agent_id='/root/carrier_rj45_jack_envelope_diagnosis',work_cutoff=cut.isoformat())
(N/(name+'-opened.json')).write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2));print(len(items),'frozen inputs')
