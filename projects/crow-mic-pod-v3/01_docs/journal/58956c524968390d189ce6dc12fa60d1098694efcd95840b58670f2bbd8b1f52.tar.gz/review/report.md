review_stage: source
review_kind: exact-part
reviewer: /root/rj45_pod_s1m_source_review1
context: FRESH
design_verdict: INCOMPLETE
order_verdict: DO-NOT-ORDER
candidate_binding candidate/03_tscircuit/src/crow_mic_pod_v3.tsx: 0a3649381ee95ec7b1e6f0e65f9891d55218b5bd7d6089b77603a3c0dde86c08
candidate_binding candidate/03_src/rules/protection_paths.yaml: 53762a56d6e655249b261170e0d8b3743ffd42cf4534e0765a8042362599c5f5
candidate_binding candidate/03_src/lib/Vishay_S1M_SMA.kicad_mod: 10684446429362a4fce09698640950790eacf5949f4f9484bc4479add283fd9e
candidate_binding candidate/02_parts/S1M-E3-61T/part.yaml: 5cacc48aa84a7bc577221a1a5bbf5fa26fbd04bd34bd9d3ec481713b4fec46d9
candidate_binding candidate/02_parts/S1M-E3-61T/Vishay_S1_88711.pdf: 49c11fe1f333fda1bcdacc72754927dda4ee5bf977bf88d3c46eb1cd6ffe9277
candidate_binding candidate/01_docs/ARCHITECTURE.md: de1ab65364efe29a7d966be1a5135ce81db163b3c9194859222dc2544f4c7083

# Exact source review

The supplied composition is INCOMPLETE and may not yet be adopted into subsequent schematic/native generation. The diode identity, polarity, ratings, mapping, and retained-land claims check out, but the frozen packet lacks independent primary evidence for U2's claimed -0.300 V negative absolute limit. This is DO-NOT-ORDER.

## Source and identity

Expected: replace JKSEMI `1N4007(M7)SMA` / LCSC `C2972759` with orderable Vishay `S1M-E3/61T` / LCSC `C144860`, in SMA (DO-214AC), while gaining an explicit primary-source polarity statement.

Observed: the filesystem-safe directory `candidate/02_parts/S1M-E3-61T/` retains the slash-free name while its `part.yaml` declares the exact slash-containing MPN `S1M-E3/61T`, manufacturer Vishay General Semiconductor, package SMA DO-214AC, and LCSC C144860. The Vishay family datasheet identifies S1M, defines E3 as the commercial-grade RoHS base-part suffix, and uses `/61T` for 1800-piece 7-inch tape-and-reel delivery in its ordering example. Page 1 states that the color band denotes the cathode end; page 3 labels the cathode band. The old JKSEMI PDF shows package artwork but contains no equivalent written cathode-band statement.

All 17 envelope inputs matched their expected size and SHA-256 before judgment. All 14 BINDINGS entries matched the envelope; the six candidate bindings are reproduced above exactly.

## Electrical and polarity facts

| Fact | Expected | Observed in Vishay 88711 | Result |
|---|---:|---:|---|
| Device/package | S1M, SMA DO-214AC | S1M family column; SMA DO-214AC | PASS |
| Repetitive/DC reverse voltage | 1000 V | 1000 V | PASS |
| Average forward current | 1 A | 1.0 A | PASS |
| Forward drop | <=1.1 V at 1 A | maximum 1.1 V at 1.0 A | PASS |
| 8.3 ms surge | 30 A | S1M maximum 30 A | PASS |
| Reverse current, 25 C | <=5 uA | maximum 5.0 uA at rated blocking voltage | PASS |
| Reverse current, 125 C | <=50 uA | maximum 50 uA at rated blocking voltage | PASS |
| Cathode identification | explicit primary statement | color band denotes cathode end | PASS |

The baseline JKSEMI values are the same for these governed limits: 1000 V, 1 A, 1.1 V at 1 A, 30 A for 8.3 ms, 5 uA at 25 C, and 50 uA at 125 C. The replacement therefore retains the electrical envelope while improving the polarity evidence.

D1 pad 2 is anode on `12V_FUSED`; pad 1 is cathode on `VIN_PROTECTED`. Positive input therefore forward-biases D1 into the board, while reversed input reverse-biases it. At the published 125 C maximum reverse leakage and R14's +1% corner:

`R14_hot = 4700 ohm x 1.01 = 4747 ohm`

`VIN_PROTECTED_min = -(50 uA x 4747 ohm) = -0.23735 V`

The candidate D1 dossier claims a TPS7A49 negative absolute floor of -0.300 V, against which the computed node would retain 0.06265 V margin. At 25 C, 5 uA gives -0.023735 V. The arithmetic is correct and depends on R14 remaining fitted at 4.7 kohm, 1%. However, the frozen U2 dependency dossier does not state any negative VIN absolute limit and the TI datasheet is not supplied. The -0.300 V threshold therefore cannot be independently source-verified from this packet; repeating it in the D1 dossier is not independent U2 evidence.

## Pad mapping and retained land

Both KiCad footprints have pad 1 at (-2.00, 0) mm and pad 2 at (+2.00, 0) mm, each 2.50 x 1.80 mm. After removing only identity text (footprint name, description, tags, and displayed value), their byte projections are identical with SHA-256 `1e142216265053ad2a4cf7dae18aea985c9c8911ed8b0f8257847ea7b3371a27`. Silk, courtyard, fab outline, pads, layer sets, corner ratio, and 3D model reference are unchanged. The TSX `SmaDiode` independently encodes the same two pad numbers, dimensions, and 4.00 mm center spacing.

Vishay gives body length 3.99-4.50 mm, body width 2.54-2.79 mm, and total terminal span 4.93-5.28 mm. Its mounting layout gives 1.68 mm minimum land height, 1.88 mm maximum land length, 1.52 mm minimum inner gap, and 5.28 mm reference outer span. The retained land gives 1.80 mm height, 2.50 mm length, 1.50 mm inner gap, and 6.50 mm outer span. It covers the Vishay terminal region across the stated package limits and is physically compatible. It is deliberately larger than Vishay's layout: length is +0.62 mm over the stated maximum, inner gap is 0.02 mm below the stated minimum, and outer span is +1.22 mm over reference. Solder paste volume, toe fillets, centering, and first-article assembly inspection remain mandatory; this source review does not qualify the retained land for production.

## Composition consistency

The TSX declares D1 MPN `S1M-E3/61T`, JLCPCB `C144860`, pin 1 `K` on `VIN_PROTECTED`, pin 2 `A` on `12V_FUSED`, and the retained SMA land. The part dossier declares the same identity, sourcing code, package, pin functions, values, limitation, and footprint identity `crow_mic_pod_v3:Vishay_S1M_SMA`. The protection rule names the exact MPN and 1000 V rating. The architecture names a Vishay S1M reverse-polarity rectifier followed by R14's reverse-leakage pull-down. These claims are mutually consistent.

## Scope and unresolved engineering acceptance

Unresolved source finding: add the exact TI primary-source page or an equivalently exact frozen U2 source extract that states the TPS7A49 negative VIN absolute minimum, then re-review the -0.23735 V comparison. Until then, the composition is INCOMPLETE and cannot proceed under this exact review. This is not schematic, placement, routing, sourcing-stock, fabrication, physical-fit, solder-joint, first-article, or release acceptance. Stock status was not supplied or reviewed. The retained-land solder-fillet and first-article limitation remains in force, as do the wider architecture's stated transient, thermal, and system holds.
