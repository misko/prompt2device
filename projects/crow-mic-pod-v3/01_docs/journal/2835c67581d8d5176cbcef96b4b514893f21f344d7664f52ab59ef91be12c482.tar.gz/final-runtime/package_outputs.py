#!/usr/bin/env python3
import hashlib,json,tarfile
from pathlib import Path

scratch=Path(__file__).resolve().parent
out=scratch.parent/'outputs'
evidence_dir=scratch/'evidence_files'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

# Bind the human-readable and structured conclusions into the forensic archive.
for name in ('report.md','evidence.json'):
    (evidence_dir/name).write_bytes((out/name).read_bytes())

archive=out/'evidence.tar.gz'
members=[]
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tf:
    for p in sorted(evidence_dir.rglob('*')):
        if not p.is_file() or p.is_symlink():
            continue
        rel=p.relative_to(evidence_dir).as_posix()
        tf.add(p,arcname=rel,recursive=False)
        members.append({'path':rel,'size':p.stat().st_size,'sha256':sha(p)})

# Reopen every regular member, rejecting links, traversal, duplicates and drift.
seen=set()
with tarfile.open(archive,'r:gz') as tf:
    regular=[m for m in tf.getmembers() if m.isfile()]
    if len(regular)!=len(members): raise RuntimeError('regular member count drift')
    expected={m['path']:m for m in members}
    for m in regular:
        if m.name in seen or m.name.startswith('/') or '..' in Path(m.name).parts:
            raise RuntimeError('unsafe/duplicate archive member '+m.name)
        seen.add(m.name)
        if m.issym() or m.islnk(): raise RuntimeError('archive link '+m.name)
        data=tf.extractfile(m).read()
        row=expected[m.name]
        if len(data)!=row['size'] or hashlib.sha256(data).hexdigest()!=row['sha256']:
            raise RuntimeError('archive member mismatch '+m.name)

manifest={'schema':1,'archive_sha256':sha(archive),'archive_size':archive.stat().st_size,'member_count':len(members),'members':members}
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
subject={'raw_sha256':'7ad855b4592a755b23fc6323ccde5100124bf2d30e2b479dc653466d0161324a','semantic_sha256':'6a5eaf3ea44f1dbbaac0a468f30cd860406bb68164f5cc3668679251c7bdb400'}
result={'subject':subject,'checks':{'inputs-verified':'PASS','review-complete':'PASS','evidence-complete':'PASS'},'unresolved':[]}
(out/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
