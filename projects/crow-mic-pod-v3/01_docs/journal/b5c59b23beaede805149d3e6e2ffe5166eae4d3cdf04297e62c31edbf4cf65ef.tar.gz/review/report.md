review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_pod_interface_toponly1 (actual fresh independent agent)
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 0131d5756ed1bb390280558718af114d5d32842d909cf5a73d67330804a39101
parts_sha256: 24c1d667aa95629d5dabb75f306a3b1f1e2b4293e40230d6c448d4e53da5a287
design_rules_sha256: 7f661d2ef79dd9004962238eac953f194ac18722cd344d1c91443cab29402ca9

Limited group coverage: J1 and U3 only, every commissioned instance checked. This is no whole-board acceptance and no order authorization. No unresolved pin-domain findings.

J1 — VERDICT: PASS
Primary: Würth 615008160221 revision 001.003, PDF page 1, Dimensions and Recommended Hole Pattern; SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048.
Measured: 10 numbered native pads / 10 distinct numbered physical identities (8 contacts and 2 separate shield tabs), plus 2 reported unnumbered mechanical pads: 12 total reported pads. No EP, no fused aliases. The manufacturer does not number the shell tabs; native9/10 are local identities SHIELD_S1/SHIELD_S2, retained separately on POD_SHIELD.
Manufacturer-first image derivation: recommended pattern upper row left-to-right8,6,4,2; lower row7,5,3,1. Pitch2.04 mm within each row, stagger1.02 mm, row separation4 mm, total span7.14 mm, shell spacing14.8 mm. The pattern has no literal TOP VIEW label. Its view is resolved from the exposed-terminal underside drawing: underside port is at page top and near-port contact row shifted right; vertical reflection into component-top puts port at page bottom and upper row shifted left, matching the recommended pattern. The metal-top drawing corroborates port-at-bottom orientation. This conversion establishes the manufacturer component-side pattern before native comparison.
The front-mounted component-top dossier (+x right/+y down) then matches the manufacturer pattern by 180-degree rotation and translation only. Pin1 moves from lower-right in the page pattern to native local(0,0), with odd contacts increasing x at y0 and even contacts increasing x at y4. No mirror is applied to native coordinates. Shell positions transform to(10.97,-2.35) and(-3.83,-2.35). Native positions match board translation(45.5,25.86), rotation0, without reflection. A connector zigzag sequence has no useful IC-perimeter winding; the dossier's CCW summary was not used as evidence. No magnetic winding exists here.
J1 pin 1 (CONTACT_1): expected generic independent connector contact at rotated manufacturer position; observed local(0.0, 0.0), net 12V_POD — PASS.
J1 pin 2 (CONTACT_2): expected generic independent connector contact at rotated manufacturer position; observed local(1.02, 4.0), net GND — PASS.
J1 pin 3 (CONTACT_3): expected generic independent connector contact at rotated manufacturer position; observed local(2.04, 0.0), net 12V_POD — PASS.
J1 pin 4 (CONTACT_4): expected generic independent connector contact at rotated manufacturer position; observed local(3.06, 4.0), net AUDIO_N — PASS.
J1 pin 5 (CONTACT_5): expected generic independent connector contact at rotated manufacturer position; observed local(4.08, 0.0), net AUDIO_P — PASS.
J1 pin 6 (CONTACT_6): expected generic independent connector contact at rotated manufacturer position; observed local(5.1, 4.0), net GND — PASS.
J1 pin 7 (CONTACT_7): expected generic independent connector contact at rotated manufacturer position; observed local(6.12, 0.0), net 12V_POD — PASS.
J1 pin 8 (CONTACT_8): expected generic independent connector contact at rotated manufacturer position; observed local(7.14, 4.0), net GND — PASS.
J1 pin 9 (SHIELD_S1): expected separate shield contact at rotated manufacturer position; observed local(10.97, -2.35), net POD_SHIELD — PASS.
J1 pin 10 (SHIELD_S2): expected separate shield contact at rotated manufacturer position; observed local(-3.83, -2.35), net POD_SHIELD — PASS.

The connector manufacturer assigns generic contacts, not a mandatory application power/audio pin allocation. The listed rail/return/audio/shell net kinds are compatible with those passive contact functions. Cable-end pin compatibility is outside this frozen pin review. The two unnumbered mechanical pads are counted from the dossier's notice; their coordinates were not supplied and are not claimed independently measured.

U3 — VERDICT: PASS
Primary: TI TPD2E2U06, SLLSEG9C, PDF page3 DRL Package / 5-Pin SOT / Top View and Pin Functions; PDF pages17–18 DRL0005A Package Outline and Example Board Layout, drawing420753/E11/2024. SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed.
Measured: 5 native pads / 5 distinct physical identities, 2 NCs, 2 IO channels, 1 ground, 0 EP, 0 aliases. Manufacturer top view has pin1 upper-left,2 middle-left,3 lower-left,4 lower-right,5 upper-right: CCW, three left and two right. Native component-top coordinates match without rotation or reflection; native board coordinates independently match the front-mounted180-degree placement about(48,34.75). No missing or collapsed leads.
U3 pin 1 (NC): expected NC; floating permitted; observed local(-0.7125, -0.5), net unconnected-(U3-NC1-Pad1) — PASS.
U3 pin 2 (NC): expected NC; floating permitted; observed local(-0.7125, 0.0), net unconnected-(U3-NC2-Pad2) — PASS.
U3 pin 3 (IO1): expected IO1; protected signal line; observed local(-0.7125, 0.5), net AUDIO_P — PASS.
U3 pin 4 (GND): expected GND; ground net; observed local(0.7125, 0.5), net GND — PASS.
U3 pin 5 (IO2): expected IO2; protected signal line; observed local(0.7125, -0.5), net AUDIO_N — PASS.

NC nets are explicitly named unconnected-(U3-NC1-Pad1) and unconnected-(U3-NC2-Pad2), with no functional assignment in the supplied dossier. TI explicitly permits floating NC pins (also GND/VCC, although unused here). IO1/IO2 map to AUDIO_P/AUDIO_N, with GND on pin4. No power pin or EP is invented. TI example land-center spacing1.48 mm differs from dossier1.425 mm by0.055 mm; vertical pitch0.5 mm agrees. Dossier0.68x0.35 mm pads differ slightly from example0.67x0.30 mm; these do not alter physical pin identity or winding. This review does not qualify the solder process.

Instance symmetry: only one instance of each distinct part is commissioned. U3's two protected audio channels have symmetric signal kinds. No unexplained same-part instance divergence.

Methods and evidence: manufacturer-first derivation preceded dossier access; all five opened figure images are retained in the archive, with exact source-PDF digest bindings, native dossiers, parsed measurements, finite direct-argv runtime receipts and raw combined stdout/stderr. All seven immutable input files matched SHA-256 and size before/after. Embedded author verification notes were not used as evidence. No live project, schematic or prior review was consulted.
