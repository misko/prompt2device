from pathlib import Path, PurePosixPath
from datetime import datetime,timezone
import json,hashlib,tarfile,io
R=Path('/tmp/rj45-pod-readability-review-top_only1-pnt6zgup');B=R/'06_build/task_runs/rj45-pod-readability-review-top_only1';S=B/'scratch';O=B/'outputs'
def sha(b):return hashlib.sha256(b).hexdigest()
E=json.loads((B/'envelope.json').read_text());h=json.loads((S/'seven-hashes.json').read_text());c=json.loads((S/'census.json').read_text());f=json.loads((S/'fidelity.json').read_text());a=json.loads((S/'final-audit.json').read_text());px=json.loads((S/'pixel-equivalence.json').read_text())
verify=[]
for x in E['input_packet']:
 p=R/x['path'];b=p.read_bytes();verify.append({'path':x['path'],'size':len(b),'sha256':sha(b),'pass':len(b)==x['size'] and sha(b)==x['sha256']})
assert len(verify)==293 and all(x['pass'] for x in verify)
(S/'inputs-after.json').write_text(json.dumps(verify,indent=2))
date=datetime.now(timezone.utc).isoformat()
report='\n'.join(['review_stage: pre-route','review_kind: schematic_render','revieweridentity: /root/carrier_rj45_native_pod_readability_top_only1','context: FRESH','date: '+date,'design_verdict: SOUND','order_verdict: DO-NOT-ORDER']+[k+': '+v for k,v in h.items()])+'''

Fresh independent POD-only readability review of the frozen crow-mic-pod-v3 project. SOUND applies to the exact delivered schematic and its readability, not placement, realized routing, native physical fit, release, sourcing allocation or production. Root owns checkpoint renewal and adoption. No source/live edits, child agents or prior reviewer reasoning were used.

Measured rendered coverage

The delivered PDF has four 900 x 607.5 point landscape pages. Both current PDF 062878cc6755eb779e1ada9ea6cadf562433a2046754b569a887495c3de65ab8 and immediately accepted PDF 0d56fe5c00b772ab4b1e071afb010e3c243bafe06c40a55393d20682be8849dc were independently rendered with the same pdftoppm command at 144 dpi to four 1800 x 1215 RGB images each. All four full images were compared: 8,748,000 pixels total. The only differences are in the generated identity line, confined to half-open rectangle [349,100,799,117] on every page. Outside that precisely identified 450 x 17 rectangle, 8,717,400/8,717,400 pixels match exactly. The full page-body rectangles [0,125,1800,1215] independently match 7,848,000/7,848,000 pixels. Per-page raw difference counts are 3656, 3692, 3755 and 3717 pixels; per-page difference bounds and RGB body digests are retained. Text extraction was not used to establish equality.

I inspected all four current integrated page images, all identity headers, and enlarged J1 and U1 detail crops. Header page numbers, titles and 7/11/10/12 component counts agree with the actual reference census, totaling 40/40. The current displayed CircuitJSON prefix 0823177ef256d91f agrees with the full independently calculated hash above. Headers and drawings remain legible; title/layout geometry is unchanged. No clipping, ambiguous crossings, reference/value collision or unreadable pin label was found within this scope.

Page 1: J1,F1,D1,D2,R14,TP1,TP2 (7/7) inspected. All ten RJ45 pins are readable and separately identifiable: power 1/3/7 to 12V_POD, return 2/6/8 to GND, positive audio 5, negative audio 4, shell 9/10 to POD_SHIELD. The shell branch is visibly separate from GND. Fuse input/output, D1 K/A orientation toward the protected rail, D2 K/A and grounded bleed path, and testpoint rail labels can be followed despite the intentionally broad page spacing. The 10.5–13.2 V pod input and no-hot-plug header remain intact.

Page 2: C1,C2,U2,R1,R2,C3,C4,C5,C6,TP3,TP7 (11/11) inspected. VIN_PROTECTED, 5V_QUIET, LDO_FB, LDO_NR and GND labels, U2 IN/EN/OUT/FB/NR_SS/EP_GND, intentional NC/DNC pins, feedback values and capacitor values are readable. Wiring and endpoint dots distinguish branches and local returns.

Page 3: R3,C7,R4,MK1,C8,R5,R6,R7,C9,TP4 (10/10) inspected. Capsule positive/negative labels, MIC_BIAS/MIC_RAW/MIC_AC, filtered-bias values, equal reference divider, ground returns and VREF testpoint remain legible. MK1 denotes off-board capsule wiring to a landing rather than a fictitious board-mounted terminal pitch.

Page 4: U1,C10,C11,R8,R9,R10,R11,R12,R13,U3,TP5,TP6 (12/12) inspected. Dense OPA1679 pin names and physical numbers were enlarged and checked, including private spare-follower feedback and GND separate from OUTD. PRE_OUT and OUTP_DRV paths through the two 100-ohm resistors to AUDIO_N/AUDIO_P are readable. U3 channel pins 3/5, GND 4 and open NC1/NC2 are clear. The gain 18/11 V/V differential header is consistent with R9/R8=18k/22k and the equal 10k polarity-restoring stage.

Source and native fidelity

Independent S-expression census finds 40 component references, 103 component pins, and 24 native nets: 20 named nets plus four intentional single-pin NC nets. Native schematic has 64 placed symbols and 127 symbol pins including 24 power/flag helper symbols; these helper symbols are not additional fitted parts. The four explicit NC marks correspond to U2.3,U2.7,U3.1,U3.2. Every prior/current component value and footprint, physical pin/function/type/net row and net endpoint census is unchanged: 0 additions, 0 removals, 0 changed components, 0 changed pins, 0 changed nets. The hand-authored manifest agrees with all 40 references.

All 103/103 CircuitJSON source ports were checked against native net endpoints: 99 named-net pins plus four explicit NC pins. Three explicit presentation aliases are recorded (N12V_POD/12V_POD, N12V_FUSED/12V_FUSED, N5V_QUIET/5V_QUIET); no arbitrary renaming was allowed. POD_SHIELD contains exactly J1.9 and J1.10, with no GND node. The unchanged TSX source and 39/39 maintained electrical invariants support this integrated check. Independent equality across the 1188 CircuitJSON records finds only supplier-warning ID/order churn and the source filesystem MD5 metadata change; electrical and schematic drawing records are unchanged. Native schematic bytes differ only in 439 UUID occurrences, confirmed by exact equality after UUID normalization. This normalization supplements rather than substitutes for rendered comparison.

Population is derived afresh: 31 fitted SMD references, one manually fitted RJ45, one off-board capsule represented by its two-wire board landing, seven bare copper test pads. Therefore the schematic denominator is 40, the machine-assembly-intent denominator is 31, and the functional fitted device/capsule denominator is 33. J1,MK1,TP1–TP7 are intentionally excluded from machine BOM/CPL; the test pads are not physical parts. Mounting holes and other board-only features are outside the schematic component count. No board population or CPL has been accepted here.

Actual source renewal

The changed U3 dossier retains its exact pin map, package/footprint and electrical limits, while moving its authored layout guidance to the top rear clamp cell and changing connector-to-clamp center-distance budgets from 4.0 mm to 8.6/5.7 mm. These are engineering layout budgets, not TI distance ratings. U3 moves from (49.07,27.86,0) bottom to (48,34.75,180) top; the pod outline remains 60 x 40 mm. Assembly metadata now says top-only, with matching manual-jack sequence and contracts wording.

Critical AUDIO_P/AUDIO_N path layers change B.Cu to F.Cu, path budgets 4.2/4.2 to 9.0/7.5 mm, and pad-center budgets 4.0/4.0 to 8.6/5.7 mm. BALANCED_AUDIO routing wording changes accordingly. Route-bank comparison explicitly identifies changed J1.4,J1.5,U3.4 prefixes/ground launch and added U3.3,U3.5 post-clamp continuations plus the new R13.2 launch; the detailed old/new point lists are archived. Other existing banks are unchanged. The added R13.2 F.Cu 0.26-mm segment ends at (62.913,34.7) with a 0.60/0.30-mm via. The remaining R13.2-to-TP6.1 F.Cu <=5-mm requirement remains ESTIMATED and executable; neither this source nor this readability witness proves completed copper. Rule-contract/test fixture changes are source maintenance, not schematic topology changes.

Seven relevant pod source postimages in the independent top-only acceptance receipt match the frozen current files exactly, including final ADR0009. Proposed-labelled historical prose in that ADR and route flow metadata is not taken as rejection or acceptance of current native bytes; the exact source receipt controls its own limited adoption. Root separately verifies current checkpoint/renewal evidence. All 34/34 part dossiers retain identical limits, pin maps and footprint identity, and no voltage/current limit rose. The accepted input range, fuse/rectifier/clamp/quiet-rail and output-impedance facts remain unchanged.

Warnings and findings

No actionable readability defect was found. The current maintained findings ledger has no open schematic-readability defect (POD-F3 is recorded closed); broader RJ45/native-envelope/placement/route-renewal findings remain open and are not closed by pixel equality. Fresh visual inspection covers every current page rather than copying prior reasoning.

ERC is explicitly not all-severity clean: 0 errors and 158 warnings, classified as 64 lib_symbol_issues (unavailable configured external elt library despite embedded symbols) and 94 endpoint_off_grid rows. The supplied zero-error-only report is not used to erase these warnings. CircuitJSON retains 15 supplier-footprint mismatch warnings plus its other source diagnostic classes; their content is unchanged and they are not silently promoted into a footprint/assembly pass.

Limits and evidence handling

This is a custom analog/power factory Cat6A RJ45 spoke, not Ethernet/PoE. Mate only with power off. Physical tolerances, mating/latch/tool access, source SOURCE PASS versus authentic FULL INCOMPLETE with nine pod physical obligations, exact supplier allocation, layout, thermal/fill/route, EMC/audio and first-article evidence remain separate. FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains; this review imposes no new physical-measurement prerequisite before fabrication. Catalog-only design admission with blank operator allocation response is not allocated stock. Historical Micro-Fit releases are not current drawings. LAYOUT001 closure is outside this witness and is not reopened by an unchanged drawing body.

All 293/293 frozen packet files were SHA-256/size verified before work and again immediately before packaging. All engineering/image-analysis subprocesses used pipeline_runtime.run_stage with direct argv, explicit cwd/environment, 180-second finite stage bounds, /usr/bin/python3 -B and PYTHONDONTWRITEBYTECODE=1; read-only file discovery and host image viewing are recorded separately. The runtime is bounded, not hermetic. Exploratory census logs include failed parser assumptions for omitted optional pin-function/connectivity fields, generated net aliases and source metadata; these were corrected in scratch and retained verbatim, without changing checked inputs or suppressing an engineering delta. Final full censuses pass. No unrelated checker suite was rerun.

The archive contains methods, raw logs, terminal runtime receipts, input verifications, pixel metrics, current/accepted raster images and native/source comparison evidence. Each regular archive member is independently reopened and checked against its manifest; symlinks, traversal, duplicate names and recursive archives are rejected. Delivery checks establish completed, exact-subject evidence; owning engineering adoption remains separate.
'''
(O/'report.md').write_text(report)
evidence={'verdict':'SOUND','design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','review_stage':'pre-route','review_kind':'schematic_render','revieweridentity':'/root/carrier_rj45_native_pod_readability_top_only1','context':'FRESH','date':date,'subject':E['subject'],'exact_subject_hashes':h,'methods':['same-renderer 144dpi all-page RGB pixel comparison','all four current integrated PDF pages and identity headers visually inspected','J1/U1 enlarged detail inspection','independent S-expression component/pin/net census','CircuitJSON source-port/native-net parity with explicit three aliases','maintained electrical invariants 39/39','owning seven-hash algorithm recomputed','all frozen inputs verified before/after'],'counts':{'inputs_verified':293,'parts_dossiers':34,'pages':4,'page_components':[7,11,10,12],'schematic_refs':40,'smd_refs':31,'native_component_pins':103,'named_nets':20,'nc_nets':4,'native_helper_symbols':24,'unmasked_equal_pixels':8717400,'body_equal_pixels':7848000,'electrical_invariants':39,'erc_errors':0,'erc_warnings':158},'pixel_comparison':px,'precise_identity_masks':c['tight_header_equivalence'],'page_reference_census':a['page_reference_census'],'component_additions':[],'component_removals':[],'component_deltas':[],'pin_deltas':[],'net_deltas':[],'findings':[],'limitations':['DO-NOT-ORDER; FIRST-ARTICLE-ONLY prototype boundary','No placement, realized routing, physical fit, release or supplier allocation acceptance','SOURCE/FULL physical gate distinction preserved; nine pod physical obligations remain','R13.2-to-TP6.1 <=5 mm is an ESTIMATED routing constraint, not completed copper','64 library and 94 off-grid ERC warnings remain classified','Current checkpoint renewal/adoption belongs to root'],'prior_evidence_usage':'Immediately accepted raw PDF/native/source bytes only for independent comparison; no prior reviewer reasoning inherited; current findings ledger consulted.'}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(O/'result.json').write_text(json.dumps({'subject':E['subject'],'checks':{k:'PASS' for k in E['completion']['checks']},'unresolved':[]},indent=2)+'\n')
members=[]
with tarfile.open(O/'evidence.tar.gz','w:gz') as tf:
 for p in sorted(S.iterdir()):
  if p.is_file() and p.name not in ['package.log','package.runtime.json']:
   assert not p.is_symlink() and not p.name.endswith(('.tar','.tar.gz','.tgz'));b=p.read_bytes();name='scratch/'+p.name;info=tarfile.TarInfo(name);info.size=len(b);info.mtime=0;tf.addfile(info,io.BytesIO(b));members.append({'path':name,'size':len(b),'sha256':sha(b)})
 for p in [O/'report.md',O/'evidence.json']:
  b=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(b);info.mtime=0;tf.addfile(info,io.BytesIO(b));members.append({'path':p.name,'size':len(b),'sha256':sha(b)})
with tarfile.open(O/'evidence.tar.gz','r:gz') as tf:
 got=tf.getmembers();assert len(got)==len(members);expected={x['path']:x for x in members};seen=set()
 for m in got:
  assert m.isfile() and not m.issym() and not m.islnk() and m.name not in seen and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts
  seen.add(m.name);b=tf.extractfile(m).read();x=expected[m.name];assert m.size==len(b)==x['size'] and sha(b)==x['sha256']
archive=(O/'evidence.tar.gz').read_bytes();manifest={'archive_sha256':sha(archive),'archive_size':len(archive),'member_count':len(members),'members':members,'verification':'Independently reopened every regular member; no symlinks/hardlinks/traversal/duplicates/recursive archive.'};(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert sorted(x.name for x in O.iterdir())==['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md','result.json']
print(json.dumps({'outputs':str(O),'verdict':'SOUND','inputs_verified':len(verify),'archive_sha256':sha(archive),'archive_size':len(archive),'member_count':len(members)}))
