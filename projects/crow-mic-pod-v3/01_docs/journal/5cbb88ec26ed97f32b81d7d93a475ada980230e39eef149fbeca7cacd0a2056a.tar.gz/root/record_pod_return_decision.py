from pathlib import Path
from datetime import datetime,timezone
import json
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path('/tmp/carrier-rj45-20260912');now=datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S');h='0af80497152923b20263b051e83421b4b067582b0004b723e69c664aa5cfef38'
r={'at':now,'decision':'ADMIT_FIXED_ADDITIVE_R13_SOURCE_BANK_ONLY','review_archive':h,'old_source_bank':None,'new_source_bank':{'net':'AUDIO_N','pin':'R13.2','segments':[{'layer':'F.Cu','width':.26,'pts':[[62.913,36.],[62.913,34.7]]}],'via':{'size':.6,'drill':.3},'vias':[[62.913,34.7]]},'c10':'No source addition; preserve connected existing broad F return and final routed revalidation.','actual_ground_open':'R7.2/C9.2 F island to broad GND component; source stitch/island-rescue and final route acceptance still owe closure.','budget':'One fixed implementation only, combined into the already conditional cumulative top-only candidate4. Preserve3 historical routing failures and1 interrupted unqualified source proposal; no routing pilot or additional native allowance.','native_limit':'Reviewer memory-only fill included optional C10 copper; exact minimal and combined generated/prepared native fill acceptance remains owed.'};(N/'pod-return-fixed-source-admission.json').write_text(json.dumps(r,indent=2)+'\n')
entry=f'''

## {now} UTC — pod source escape admitted; C10 ground diagnosis corrected

MEASURED: fresh independent pod return review actual FINAL closed PASS18:53:59Z. Root read the complete report and reopened all663 frozen inputs and107 inner members. Pod archive{h} preserves5,837,412 bytes/18 outer members. SOUND admits one additive R13.2 AUDIO_N source bank: F.Cu0.26 mm from(62.913,36.000) to(62.913,34.700), explicit0.6/0.3 mm through-via at the latter point. Actual source rounding is62.9125→62.913, verified against all90 existing native prep copper objects. Current source has no R13 bank; the bad62.4,35.6 via exists only in the three historical routed outputs. Preserve that exact known-bad contact and all three spent route candidates. The one interrupted historical source proposal remains unqualified, with no native generation or pilot.

The fixed escape has0.300000 mm annulus-to-own-land gap,1.183000 mm nearest foreign F segment clearance,1.229176 mm nearest foreign F annulus clearance and8.991339 mm nearest drill gap. Each proposed geometry has649 layer/shape comparisons plus all drilled objects and source regions. One finite memory-only control, with no Save, yields R13 annulus-to-GND fill clearance0.300499 mm on both layers. That control included the optional C10 copper; it is not exact minimal-batch fill acceptance. Full combined regenerated native, probe≤5 mm F.Cu path, clamp-first topology and final route proof remain required.

C10 is not an isolated pad in the current prepared pod. Independent33-node/36-edge ground graph has two components:20 GND pads reach the broad component, including C10.2 and U1.11; R7.2/C9.2 form the other F.Cu island. C10 has two measured0.499 mm thermal-spoke cross sections and zero fresh thermal DRC rows with error severity and minimum2 spokes unchanged. The raw GND unrouted row names the F-zone UUID6533c1db-df8e-4064-9734-bb826be8a0c6 and C10.2 UUIDdd5a6bb2-349f-4bd8-9f7b-51d1db0e16c1; one zone UUID spans several disconnected filled polygons. The missing connection is the R7/C9 island to broad GND, with C10 reported on the other side. Retain that actual route/stitch obligation; do not perpetuate a C10-isolated-pad diagnosis from the endpoint label alone.

Root admits the minimal R13-only source correction and leaves C10 unchanged. This fits inside the already conditionally admitted top-only candidate4, with no additional native trial or routing pilot. The source owner received exact report/manifest/archive paths as a hashed read-only supplement; original1,761 frozen inputs remain unchanged. Full source/native independent acceptance precedes adoption. FIRST-ARTICLE-ONLY / DO-NOT-ORDER; neither new release minted.
'''
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 p=R/'projects'/slug/'01_docs/journal/placement.md';p.write_text(p.read_text()+entry)
p=R/'projects/crow-mic-pod-v3/01_docs/learnings/routing.md';p.write_text(p.read_text()+f'''

## A zone DRC endpoint does not identify its disconnected fill component
- what happened: an unrouted GND row naming C10.2 was carried forward as a possible local capacitor-return problem. Fresh independent native polygon/graph review found C10 already on broad ground through two0.499 mm spokes; the disconnected component actually held R7.2/C9.2. Exact review evidence: `01_docs/journal/{h}.tar.gz`.
- root cause: one KiCad zone UUID covers multiple disconnected fill polygons, and its reported nearest opposite endpoint is not the isolated component's identity. Pad/UUID lookup alone cannot assign the root cause.
- avoid next time: when a DRC endpoint is a zone, enumerate its filled polygon components and each component's pads, vias and graph connections before selecting the source correction. Preserve the raw row and distinguish the reported endpoint from the disconnected network.
- candidate-canon: yes — extend the existing all-unconnected classification guidance with component-aware zone diagnosis; do not invent a new pass or infer RF performance from DC connectivity.
''')
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3','crow-roof-array-v1']:
 p=R/'projects'/slug/'01_docs/STATUS.md';t=p.read_text();t=t.replace('Source owner cutoff19:32:04Z; pod return review18:56:53Z.','Source owner cutoff19:32:04Z; pod R13-only decision accepted, C10 unchanged and R7/C9 island closure owed.');t=t[:t.index('updated: ')]+f'updated: {now}\n';p.write_text(t)
print(now)
