#!/usr/bin/env python3
import hashlib
import io
import json
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
SCRATCH = Path(__file__).resolve().parent
OUTPUTS = SCRATCH.parent / "outputs"
OUTPUTS.mkdir(parents=True, exist_ok=True)

def digest(data):
    return hashlib.sha256(data).hexdigest()

input_rows = []
envelope = json.loads((ROOT / "06_build/task_runs/rj45-pin-pod-analog-s1m1/envelope.json").read_text())
for item in envelope["input_packet"]:
    data = (ROOT / item["path"]).read_bytes()
    actual = digest(data)
    if actual != item["sha256"] or len(data) != item["size"]:
        raise RuntimeError(f"input mismatch: {item['path']}")
    input_rows.append(f"{actual}  {item['path']}")

members = {
    "evidence/report.md": (SCRATCH / "report.md").read_bytes(),
    "evidence/evidence.json": (SCRATCH / "evidence.json").read_bytes(),
    "evidence/protocol/pin-review-protocol.md": (ROOT / "pin-review-protocol.md").read_bytes(),
    "evidence/dossiers/U1.md": (ROOT / "dossiers/U1.md").read_bytes(),
    "evidence/dossiers/U2.md": (ROOT / "dossiers/U2.md").read_bytes(),
    "evidence/figures/opa1679-page-05.png": (SCRATCH / "opa1679-page-05.png").read_bytes(),
    "evidence/figures/tps7a49-page-04.png": (SCRATCH / "tps7a49-page-04.png").read_bytes(),
    "evidence/text/opa1679-page5.txt": (SCRATCH / "opa1679-page5.txt").read_bytes(),
    "evidence/text/tps7a49-pages4-5.txt": (SCRATCH / "tps7a49-pages4-5.txt").read_bytes(),
    "evidence/runtime/render_sources.py": (SCRATCH / "render_sources.py").read_bytes(),
    "evidence/runtime/source-runtime.json": (SCRATCH / "source-runtime.json").read_bytes(),
    "evidence/runtime/source-v3-1.log": (SCRATCH / "source-v3-1.log").read_bytes(),
    "evidence/runtime/source-v3-2.log": (SCRATCH / "source-v3-2.log").read_bytes(),
    "evidence/runtime/source-v3-3.log": (SCRATCH / "source-v3-3.log").read_bytes(),
    "evidence/runtime/source-v3-4.log": (SCRATCH / "source-v3-4.log").read_bytes(),
    "evidence/input-sha256.txt": ("\n".join(input_rows) + "\n").encode(),
}

archive = OUTPUTS / "evidence.tar.gz"
with tarfile.open(archive, "w:gz", format=tarfile.PAX_FORMAT) as stream:
    for name, data in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        stream.addfile(info, io.BytesIO(data))

seen = set()
reopened = []
with tarfile.open(archive, "r:gz") as stream:
    for info in stream.getmembers():
        if not info.isfile() or info.issym() or info.islnk():
            raise RuntimeError(f"non-regular archive member: {info.name}")
        path = Path(info.name)
        if path.is_absolute() or ".." in path.parts or info.name in seen:
            raise RuntimeError(f"unsafe or duplicate archive member: {info.name}")
        seen.add(info.name)
        handle = stream.extractfile(info)
        if handle is None:
            raise RuntimeError(f"cannot reopen member: {info.name}")
        data = handle.read()
        reopened.append({"path": info.name, "size": len(data), "sha256": digest(data)})
if seen != set(members):
    raise RuntimeError("archive member census mismatch")

archive_data = archive.read_bytes()
manifest = {
    "schema": 1,
    "archive_sha256": digest(archive_data),
    "archive_size": len(archive_data),
    "member_count": len(reopened),
    "members": sorted(reopened, key=lambda row: row["path"]),
}
(OUTPUTS / "report.md").write_bytes((SCRATCH / "report.md").read_bytes())
(OUTPUTS / "evidence.json").write_bytes((SCRATCH / "evidence.json").read_bytes())
(OUTPUTS / "evidence-manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
result = {
    "subject": envelope["subject"],
    "checks": {
        "inputs-verified": "PASS",
        "review-complete": "PASS",
        "evidence-complete": "PASS"
    },
    "unresolved": []
}
(OUTPUTS / "result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
