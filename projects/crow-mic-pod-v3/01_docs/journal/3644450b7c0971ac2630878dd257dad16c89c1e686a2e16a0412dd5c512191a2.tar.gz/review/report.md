review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_pod_analog_s1m1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: af9bb3c0dcf5e9be20239d725d10dd4d4c1bf95cc0b7518badc3e27bd6523938
parts_sha256: d0d0026dd67cbfaa98176799ea34ea3bfde384675d74d58d8cf8f0c88e41fd89
design_rules_sha256: 474e5d0a81baf576aefac32e9c60bce37704bb138961c16bf92573843b6409c4
completed_at: 2026-09-14T03:40:27Z

# Fresh independent pin review: pod analog group

Scope is limited to U1 and U2 on the immutable subject above. This is not whole-board acceptance and does not authorize ordering.

## U1 — OPA1679IDR

VERDICT: PASS

Primary source: TI OPA1677/OPA1678/OPA1679 SBOS855E, SHA-256 `4072daad4ebc4ec9a74ba6547d721b05db8d0cfc12924bda79e828271aeaec3b`, PDF page 5, Figure 5-5 and the OPA1679 pin-functions table. The actual figure image was rendered and inspected before comparing the dossier.

The source is explicitly a **top view**. Pin 1 is at the upper-left corner; pins 1–7 descend the left edge, and pins 8–14 ascend the right edge. In the dossier's component-top frame (+x right, +y down), this is CCW and matches the observed footprint without mirroring. The figure has seven pins per long side.

Measured native identities: 14 numbered copper pads; 14 distinct physical pin identities; 0 exposed pads; 0 declared or required fused aliases; 0 unnumbered footprint features.

| Pin | Datasheet expectation | Native dossier observation | Result |
|---|---|---|---|
| 1 OUTA | Channel-A output | `VREF`, paired with pin 2 `VREF` and pin 3 `VREF_RAW`; valid follower structure | PASS |
| 2 IN_A_NEG | Channel-A inverting input | `VREF`, same net as OUTA for feedback | PASS |
| 3 IN_A_POS | Channel-A noninverting input | `VREF_RAW`, signal input to the follower | PASS |
| 4 V_PLUS | Highest supply | `5V_QUIET`, a positive rail | PASS |
| 5 IN_B_POS | Channel-B noninverting input | `VREF`, a bias/reference signal | PASS |
| 6 IN_B_NEG | Channel-B inverting input | `PRE_FB`, a feedback net | PASS |
| 7 OUTB | Channel-B output | `PRE_OUT`, distinct output net structurally paired with `PRE_FB` | PASS |
| 8 OUTC | Channel-C output | `OUTP_DRV`, output/drive net | PASS |
| 9 IN_C_NEG | Channel-C inverting input | `OUTP_FB`, a feedback net | PASS |
| 10 IN_C_POS | Channel-C noninverting input | `VREF`, a bias/reference signal | PASS |
| 11 V_MINUS | Lowest supply | `GND`, valid for single-supply use | PASS |
| 12 IN_D_POS | Channel-D noninverting input | `VREF`, a bias/reference signal | PASS |
| 13 IN_D_NEG | Channel-D inverting input | `SPARE_BUF`, same net as OUTD for feedback | PASS |
| 14 OUTD | Channel-D output | `SPARE_BUF`, valid follower feedback | PASS |

All four amplifier channels preserve the same input/output role structure; no channel has a power pin, output, or inverting/noninverting input exchanged with another function.

## U2 — TPS7A4901DGNR

VERDICT: PASS

Primary source: TI TPS7A49 SBVS121E, SHA-256 `0a5e198966ab05ebb39f4512355352c0946af5f52e1fbd2e9ec554041123a126`, PDF page 4, DGN Package 8-Pin HVSSOP PowerPAD top-view figure and pin-functions table. The actual figure image was rendered and inspected before comparing the dossier.

The source is explicitly a **top view**. Pin 1 is at the upper-left corner; pins 1–4 descend the left edge, and pins 5–8 ascend the right edge. In the dossier's component-top frame (+x right, +y down), this is CCW and matches the observed footprint without mirroring. The figure has four leads per side.

Measured native identities: 8 lead pads plus 1 distinct numbered PowerPAD copper identity (pad 9), for 9 numbered copper identities total; 4 unnumbered paste-only features; 0 fused aliases. The four anonymous features are paste subdivisions, not missing or collapsed electrical pins.

| Pin | Datasheet expectation | Native dossier observation | Result |
|---|---|---|---|
| 1 OUT | Regulator output and output capacitor rail | `5V_QUIET`, an output rail | PASS |
| 2 FB | Feedback/error-amplifier input | `LDO_FB`, a dedicated feedback net | PASS |
| 3 NC | Open or GND is allowed | Explicit unconnected net `unconnected-(U2-NC-Pad3)` | PASS |
| 4 GND | Ground | `GND` | PASS |
| 5 EN | Enable input; may connect to IN | `VIN_PROTECTED`, the same supply net as IN | PASS |
| 6 NR/SS | Noise-reduction/soft-start capacitor node | `LDO_NR`, a dedicated node | PASS |
| 7 DNC | Must not connect to any electrical net | Explicit unconnected net `unconnected-(U2-DNC-Pad7)` | PASS |
| 8 IN | Input supply | `VIN_PROTECTED`, a protected input rail | PASS |
| PowerPAD / native pad 9 | May be open or tied to ground; soldering to a plane improves thermal performance | `GND`, a permitted and thermally useful connection | PASS |

Only one U2 instance is commissioned, so no multi-instance symmetry comparison applies. All nine manufacturer electrical/thermal identities remain distinct in native copper; no same-net collapse is present.

## Domain conclusion

U1 and U2 both PASS. The commissioned pod-analog group is SOUND. Coverage remains limited to these two references. Order verdict remains DO-NOT-ORDER.
