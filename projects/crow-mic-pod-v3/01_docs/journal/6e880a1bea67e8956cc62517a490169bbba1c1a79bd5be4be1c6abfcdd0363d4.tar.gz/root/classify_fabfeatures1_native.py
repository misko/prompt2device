from pathlib import Path
from collections import Counter, defaultdict
import hashlib
import json
import pcbnew

R = Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
N = Path(__file__).parent
key = lambda row: json.dumps(row, sort_keys=True)
for slug, prior_name in [
    ('crow-audio-carrier-v1', 'crow-audio-carrier-v1-orientation1-closed-classification.json'),
    ('crow-mic-pod-v3', 'crow-mic-pod-v3-orientation1-closed-classification.json'),
]:
    P = R / 'projects' / slug
    board_path = next((P / '04_kicad').glob('*.kicad_pcb'))
    assert board_path.read_bytes() == (N / 'fabfeatures1-native-before' / slug / board_path.relative_to(P)).read_bytes()
    gate_path = P / '06_build/drc/gate.json'
    gate = json.loads(gate_path.read_text())
    prior = json.loads((N / prior_name).read_text())
    previous = prior['rows'] if 'rows' in prior else prior['unconnected_items']
    previous_raw = [row['raw'] for row in previous]
    assert not gate['schematic_parity']
    assert Counter(map(key, previous_raw)) == Counter(map(key, gate['unconnected_items']))
    causes = defaultdict(list)
    for row in previous:
        causes[key(row['raw'])].append(row)
    board = pcbnew.LoadBoard(str(board_path))
    footprints = {fp.m_Uuid.AsString(): fp for fp in board.GetFootprints()}
    violations=[];refs=[]
    for index,raw in enumerate(gate['violations'],1):
        assert raw['type']=='lib_footprint_mismatch' and raw['severity']=='warning'
        assert "Wurth_615008160221_RJ45" in raw['description'] and len(raw['items'])==1
        item=raw['items'][0];fp=footprints[item['uuid']];ref=fp.GetReference();refs.append(ref)
        assert item['description']=='Footprint '+ref
        pos={'x':fp.GetPosition().x/1e6,'y':fp.GetPosition().y/1e6}
        assert all(abs(pos[a]-item['pos'][a])<=0.000002 for a in ['x','y'])
        violations.append({'index':index,'raw':raw,'ref':ref,'uuid':item['uuid'],'native_position_mm':pos,'cause':'The unchanged preceding placement embeds the previously accepted nominal-shell footprint. The independently accepted source library now adds18 Fab spring-finger marks. Normal current-source PCB regeneration is owed after schematic acceptance; this warning is not waived.','disposition':'OPEN old/current library mismatch; no current placement acceptance.'})
    assert sorted(refs)==(['J1'] if 'pod' in slug else ['J'+str(i) for i in range(1,9)])
    pads = {pad.m_Uuid.AsString(): pad for fp in board.GetFootprints() for pad in fp.Pads()}
    tracks = list(board.GetTracks())
    assert all(isinstance(item, pcbnew.PCB_VIA) for item in tracks)
    zones = {zone.m_Uuid.AsString(): zone for zone in board.Zones()}
    objects = {**pads, **zones, **{item.m_Uuid.AsString(): item for item in tracks}}
    rows = []
    checked_positions = 0
    for index, raw in enumerate(gate['unconnected_items'], 1):
        previous_row = causes[key(raw)].pop()
        ends = []
        for item in raw['items']:
            uuid = item['uuid']
            obj = objects[uuid]
            net = obj.GetNetname()
            assert '[' + net + ']' in item['description']
            position = {'x': obj.GetPosition().x / 1e6, 'y': obj.GetPosition().y / 1e6}
            kind = 'pad' if uuid in pads else 'zone' if uuid in zones else 'via'
            if kind != 'zone':
                assert all(abs(position[axis] - item['pos'][axis]) <= 0.000002 for axis in ['x', 'y'])
                checked_positions += 1
            ends.append({
                'uuid': uuid, 'net': net, 'kind': kind,
                'ref': obj.GetParentFootprint().GetReference() if kind == 'pad' else None,
                'pin': obj.GetNumber() if kind == 'pad' else None,
                'native_position_mm': position, 'reported_position_mm': item['pos'],
            })
        assert len({end['net'] for end in ends}) == 1
        rows.append({'index': index, 'raw': raw, 'endpoints': ends,
                     'cause': previous_row['cause'],
                     'explanation': previous_row.get('explanation', previous_row['cause']),
                     'disposition': 'OPEN unrouted connection; no routing acceptance or feasibility claim.'})
    result = {
        'project': slug, 'report_sha256': hashlib.sha256(gate_path.read_bytes()).hexdigest(),
        'board_sha256': hashlib.sha256(board_path.read_bytes()).hexdigest(),
        'counts': {'violations': len(violations), 'unconnected_items': len(rows), 'schematic_parity': 0,
                   'tracks': 0, 'vias': len(tracks), 'uuid_net_endpoints': sum(len(row['endpoints']) for row in rows),
                   'pad_via_positions_checked': checked_positions},
        'method': 'Fresh native severity-all/refill/parity DRC; each library mismatch independently mapped to its unchanged native jack ref/UUID/position and accepted source Fab delta. Exact unconnected raw-row multiset matches individually classified prior rows. Reopened unchanged native PCB and independently verified every UUID/net and every pad/via position. Zone report points and native anchors retained separately.',
        'prior_classification': prior_name, 'ignored_checks': gate['ignored_checks'],
        'violations': violations, 'unconnected_items': rows, 'schematic_parity': [],
        'limits': 'Current failed measurement of unchanged preceding placement:8carrier/1pod embedded-library mismatches plus499/58 unrouted connections. Source/checkpoint renewal is not current placement or route acceptance.',
    }
    (N / (slug + '-fabfeatures1-classification.json')).write_text(json.dumps(result, indent=2) + '\n')
    print(slug, json.dumps(result['counts']))
