review_stage: pre-route
review_kind: layout
reviewer: Codex /root/rj45_pod_layout_toponly1 (fresh independent reviewer)
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 0131d5756ed1bb390280558718af114d5d32842d909cf5a73d67330804a39101
design_rules_sha256: 7f661d2ef79dd9004962238eac953f194ac18722cd344d1c91443cab29402ca9
prepared_board_sha256: 8ba635bf9f1287f42ec169aa705a1f5bc87d48b3b330a5e5a196d36b1f61a536

# Fresh independent pod top-only pre-route layout review

The exact native placement is sound for pre-route continuation. This is not a routing acceptance or an order authorization. The prepared `r0` contains only deterministic local copper and remains intentionally incomplete.

## Independently measured census and geometry

- Nominal Edge.Cuts centerline outline: 60.000 x 40.000 mm, x=20..80 mm and y=20..60 mm. Including the 0.10 mm edge stroke, pcbnew reports 60.100 x 40.100 mm.
- Native board: 44 footprints, 113 pads, 0 tracks and 0 vias. The functional census is 31 fitted SMD footprints, all on F.Cu/F.Paste; one fitted THT jack J1; one off-board microphone represented only by the two-hole MK1 wire landing; seven bare SMD test pads TP1..TP7; and four bare NPTH mounting holes H1..H4. No fitted SMD is on B.Cu.
- Prepared `r0`: the same 44 footprints and 113 pads, plus 80 segments and 12 vias. Its minimum segment width is 0.26 mm; vias are 0.60/0.30 mm diameter/drill.
- Independent placement-gate reopening measured the tightest copper-pad-to-outline margin as 2.26 mm at J1.9 against the 0.15 mm minimum. It graded 32 assembled footprint envelopes, found zero courtyard/body-to-foreign-pad conflicts, and reported at least 0.100 mm body clearance. The worst routability cut carries 6 nets against an estimated 121-track capacity (ratio 0.05).
- Independent pad separation reopening covered 109 copper pads on 44 footprints, 5,654 inter-footprint pad pairs and 8,642 paste-to-foreign-copper pairs. All cleared the 0.127 mm fabrication-tier floor; no foreign paste intrusion was found.
- The four M3 NPTH centers are 4.0 mm from their two adjacent board edges. The declared router screw keepout is radius 3.0 mm and is limited to H* refs; the closest obvious bare probe feature is TP4, whose 1.5 mm land center is 5.0 mm from H3, leaving 1.25 mm beyond the declared keepout radius. Native DRC found no hole, edge, courtyard or clearance violation.

## Electrical placement

All source-owned short-path pad-center budgets pass on the actual native board:

| Path | Measured (mm) | Limit (mm) | Disposition |
|---|---:|---:|---|
| D1.1 to D2.1 | 10.203 | 12.0 | PASS; input reverse diode to TVS order remains spatially compact |
| J1.5 to U3.3 (AUDIO_P) | 8.435 | 8.6 | PASS |
| J1.4 to U3.5 (AUDIO_N) | 5.538 | 5.7 | PASS |
| U2.8 to C1.1 | 2.531 | 3.0 | PASS |
| U2.8 to C2.1 | 2.052 | 3.0 | PASS |
| U2.1 to C5.1 | 2.748 | 3.0 | PASS |
| U2.1 to C6.1 | 1.552 | 3.0 | PASS |
| U2.6 to C4.1 | 1.870 | 3.0 | PASS |
| U2.2 to C3.2 | 2.090 | 3.0 | PASS |
| U2.1 to C3.1 | 2.052 | 3.0 | PASS |
| U1.4 to C10.1 | 1.945 | 3.0 | PASS |
| R12.2 to TP5.1 | 3.930 | 5.0 | PASS |
| R13.2 to TP6.1 | 3.500 | 5.0 | PASS |

The J1-to-U3 launch copper in `r0` preserves the required connector-first clamp order. AUDIO_P runs entirely on F.Cu from J1.5 at (49.58,25.86) through (49.58,31.50), (48.712,32.367) to U3.3 at (48.7125,34.25), with its first via only after the clamp at (49.60,34.25). AUDIO_N runs entirely on F.Cu from J1.4 at (48.56,29.86) through (48.56,30.70), (46.40,32.86), (46.40,34.90), (46.75,35.25) to U3.5 at (47.2875,35.25), with its first via only after the clamp at (47.288,36.25). U3.4 has a 0.85 mm, 0.50 mm-wide GND launch to a dedicated 0.60/0.30 mm via at (47.288,33.40). No probe or output branch precedes either clamp pad.

Prepared widths respect their declared floors: 5V_QUIET uses at least 0.40 mm; VIN_PROTECTED and the local GND launch use 0.50 mm; AUDIO_P, AUDIO_N, LDO_FB, LDO_NR and quiet analog seeds use 0.26 mm against their 0.25 mm/default intent. Native DRC found no clearance or width violation at placement; prepared `r0` also found no clearance, width, hole or edge violation.

The remaining analog placement is coherent: MK1's wire landing, bias parts R3/R4/C7, coupling C8, the VREF cell R6/R7/C9, U1/C10/C11 and paired output resistors R12/R13 occupy compact, separable cells with ample cut capacity. Actual routing must still preserve uninterrupted return and quiet-node isolation; `r0` is not evidence that the global route does so.

## Native DRC classification

- Exact native board: 0 violations, 79 unconnected item pairs, 0 schematic-parity issues. Every open is expected because this is the track-free placement artifact.
- Exact prepared `r0`: 8 warning violations, 53 unconnected item pairs, 0 schematic-parity issues. The warnings are four deliberately dangling preparation vias and four deliberately dangling seed tracks: GND via (47.288,33.40); AUDIO_N vias (47.288,36.25) and (62.913,34.70); AUDIO_P via (49.60,34.25); VREF track end (55.025,46.46); PRE_OUT track end (55.025,52.81); OUTP_FB track end (64.00,53.49); and MIC_AC track end (64.50,43.51). These are preparation endpoints awaiting the global route, not placement violations.

The complete unmodified KiCad JSON reports are archived as `raw/native_drc.json` and `raw/r0_drc.json`. They retain every exact raw violation item and all 79/53 unconnected node pairs with descriptions, UUIDs and coordinates; no pair was reduced to a count in the evidence record.

## Render and connector disposition

I independently inspected the exact supplied top and bottom native renders, archived byte-for-byte with their identities. The top view shows the north-edge J1 mouth, top-only SMT population, readable functional labels and clear mounting-hole regions. The bottom view shows no placed bottom-side land pattern or bottom assembly population. J1 mouth/orientation is covered by the exact-board user approval receipt; I did not reuse that approval for any other placement judgment.

The following are order-blocking first-article checks, not PCB placement failures:

1. **FA-01 — ORDER-BLOCKING FIRST ARTICLE.** J1 pads 9/10 at (56.47,23.51)/(41.67,23.51): the project-derived 2.5 x 1.5 mm shell lands retain only 0.018639 mm nominal margin above the 0.25 mm hole-to-copper floor at the adjacent 3.18 mm locating holes. Tolerance/manufacturer acceptance is unresolved. Next owner: PCB fabrication and connector-process owner.
2. **FA-02 — ORDER-BLOCKING FIRST ARTICLE.** J1 at (45.50,25.86), north mouth/board edge y=20: nominal free spring-finger extent has only 0.001919 mm right-courtyard centerline margin and is not a tolerance envelope. Plug access, panel bond, finger clearance and installed mating fit require physical qualification. Next owner: mechanical/enclosure owner.
3. **FA-03 — ORDER-BLOCKING FIRST ARTICLE.** J1 pads 1..10: manual THT soldering, eight contact joints, two shell slots, locating guides, shell isolation, and the factory Cat6A cord's 1-to-1 through 8-to-8 plus shield continuity remain unqualified. Next owner: assembly/test owner.
4. **FA-04 — ORDER-BLOCKING FIRST ARTICLE.** MK1 wire pads 1/2 at (73.0,45.0)/(73.0,40.0): capsule mounting is off-board. Enclosure strain relief, drainage, polarity and acoustic placement remain unqualified. Next owner: enclosure/acoustic owner.
5. **FA-05 — ORDER-BLOCKING FIRST ARTICLE.** Completed routing and assembled hardware must pass the retained rail, noise, gain, clipping, cable, EMC and roof-environment tests. These commissioning measurements are not required to accept the present placement. Next owner: routing, bring-up and system-test owners in sequence.

## Limitations

This review accepts placement only. It does not accept the 53 remaining `r0` opens, global return-plane continuity, completed analog trace geometry, production THT process, sourcing, assembly allocation, enclosure fit or environmental performance. Nominal STEP/Fab/courtyard geometry is not a manufacturing tolerance envelope. The order verdict remains DO-NOT-ORDER.
