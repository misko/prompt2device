#!/usr/bin/env python3
import gzip, hashlib, io, json, os, stat, tarfile
from pathlib import Path, PurePosixPath

root=Path('/tmp/rj45-pod-layout-toponly1-jvu7b186')
scratch=root/'06_build/task_runs/rj45-pod-layout-toponly1/scratch'
outputs=root/'06_build/task_runs/rj45-pod-layout-toponly1/outputs'
members={
  'methods/measure_board.py': scratch/'measure_board.py',
  'methods/run_stage.py': scratch/'run_stage.py',
  'raw/native_measurements.json': scratch/'native_measurements.json',
  'raw/r0_measurements.json': scratch/'r0_measurements.json',
  'raw/audio_launches.json': scratch/'audio_launches.json',
  'raw/native_drc.json': scratch/'native_drc2.json',
  'raw/r0_drc.json': scratch/'r0_drc2.json',
  'raw/placement_gates.json': scratch/'placement_gates.json',
  'images/native_top.png': scratch/'inspected_native_top.png',
  'images/native_bottom.png': scratch/'inspected_native_bottom.png',
  'source/critical_paths.yaml': root/'project/03_src/rules/critical_paths.yaml',
  'source/nets.yaml': root/'project/03_src/rules/nets.yaml',
  'source/floorplan.yaml': root/'project/03_src/floorplan.yaml',
  'source/assembly.yaml': root/'project/03_src/rules/assembly.yaml',
  'source/connector_orientation.yaml': root/'project/08_reviews/connector_orientation.yaml',
}
for p in sorted(scratch.glob('*.runtime.log')):
  if p.name in {'final_package.runtime.log', 'preflight.runtime.log'}:
    continue
  members['runtime/'+p.name]=p
records=[]
archive=outputs/'evidence.tar.gz'
with archive.open('wb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
    with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
      for name,path in sorted(members.items()):
        pp=PurePosixPath(name)
        if pp.is_absolute() or '..' in pp.parts or name==archive.name:
          raise SystemExit('unsafe member '+name)
        info=path.lstat()
        if not stat.S_ISREG(info.st_mode) or path.is_symlink():
          raise SystemExit('nonregular '+str(path))
        data=path.read_bytes()
        ti=tarfile.TarInfo(name); ti.size=len(data); ti.mtime=0; ti.mode=0o644; ti.uid=0; ti.gid=0; ti.uname=''; ti.gname=''
        tar.addfile(ti,io.BytesIO(data))
        records.append({'path':name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
# Reopen and verify names, regular files, bytes, no duplicates/traversal/recursion.
seen=set()
with tarfile.open(archive,'r:gz') as tar:
  got=[]
  for m in tar.getmembers():
    pp=PurePosixPath(m.name)
    if m.name in seen or pp.is_absolute() or '..' in pp.parts or not m.isfile() or m.issym() or m.islnk() or m.name.endswith('evidence.tar.gz'):
      raise SystemExit('unsafe reopened member '+m.name)
    seen.add(m.name); data=tar.extractfile(m).read(); got.append({'path':m.name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
if got != records: raise SystemExit('reopen records differ')
adata=archive.read_bytes()
manifest={'schema':1,'archive_sha256':hashlib.sha256(adata).hexdigest(),'archive_size':len(adata),'member_count':len(records),'members':records}
(outputs/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps({'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'member_count':manifest['member_count']}))
