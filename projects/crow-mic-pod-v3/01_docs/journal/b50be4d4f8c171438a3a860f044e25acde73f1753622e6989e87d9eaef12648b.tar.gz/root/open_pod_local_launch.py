from pathlib import Path
from datetime import datetime, timezone, timedelta
import sys, json, hashlib, shutil, tempfile
sys.dont_write_bytecode = True
R = Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
N = Path(__file__).parent
name = 'rj45-pod-local-launch-source'
sys.path.insert(0, str(R / 'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope
from pipeline_identity import TypedIdentityInput, subject_identity
from pipeline_runtime import open_agent_attempt
prior = json.loads((N / 'rj45-pod-launch-reassessment-opened.json').read_text())
assert json.loads((Path(prior['envelope']).parent / 'attempt.json').read_text())['status'] == 'PASS'
D = Path(tempfile.mkdtemp(prefix=name + '-'))
shutil.copytree(Path(prior['project']) / 'input', D / 'input')
def copy(src, rel):
    dst = D / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
import tarfile
author_meta = json.loads((N / 'rj45-pod-two-net-normalization-opened.json').read_text())
with tarfile.open(Path(author_meta['output_dir']) / 'evidence.tar.gz') as archive:
    for kind, folder in [('source_candidate', 'baseline-source'), ('beforeimages', 'beforeimages')]:
        for filename in ['route.yaml', 'floorplan.yaml']:
            rel = 'projects/crow-mic-pod-v3/03_src/' + filename
            b = archive.extractfile(kind + '/' + rel).read()
            if kind == 'beforeimages': assert b == (R / rel).read_bytes()
            dst = D / folder / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(b)
for p in Path(prior['output_dir']).iterdir():
    if p.is_file():
        copy(p, 'prior-review/' + p.name)
for p in (Path(prior['envelope']), Path(prior['envelope']).parent / 'attempt.json'):
    copy(p, 'prior-review/allocation/' + p.name)
author = json.loads((N / 'rj45-pod-two-net-normalization-opened.json').read_text())
for p in Path(author['output_dir']).iterdir():
    if p.is_file():
        copy(p, 'prior-author/' + p.name)
for rel in ('skills/pcb-design/references/lifecycle-and-backtrack.md', 'skills/kicad-pcb/references/routing-pipeline.md', 'projects/crow-mic-pod-v3/01_docs/findings.yaml'):
    copy(R / rel, 'input/' + rel)
copy(N / 'pod-local-launch-admission.json', 'admission.json')
copy(Path('/tmp/carrier-locator-implementation-availability-6c_4vwal/preflight.py'), 'preflight.py')
now = datetime.now(timezone.utc)
cut = now + timedelta(minutes=25)
hard = now + timedelta(minutes=35)
(D / 'TASK.md').write_text((N / 'pod_local_launch_task.txt').read_text().format(cut=cut.isoformat(), hard=hard.isoformat()))
items = []
for p in sorted(D.rglob('*')):
    if p.is_file():
        b = p.read_bytes()
        items.append({'name': f'input_{len(items):04d}', 'path': p.relative_to(D).as_posix(), 'size': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
subject = subject_identity('pod_local_launch_source_decision', 1, [TypedIdentityInput('packet', 'sequence', items, json.dumps(items, sort_keys=True).encode())])
e = TaskEnvelope(schema=2, task_id=name, stage_id='KICAD-PLACEMENT', run_id=name, subject=subject, executor='agent', execution_class='local', recommended_agent_role='authoring', agent_role='authoring', role_escalation_reason=None, context_mode='FRESH', input_handoff_id=name, input_packet=items, deadline_at=hard.isoformat().replace('+00:00', 'Z'), max_nonimproving_attempts=1, replacement_limit=0, writer_scope={'mode': 'READ_ONLY', 'paths': []}, output_path=f'06_build/task_runs/{name}/attempt.json', completion={'outputs': ['evidence-manifest.json', 'evidence.json', 'evidence.tar.gz', 'report.md'], 'checks': ['evidence-complete', 'inputs-verified', 'review-complete']})
o = open_agent_attempt(e, cwd=D)
o.update(project=str(D), envelope=str(D / e.output_path).replace('attempt.json', 'envelope.json'), task=str(D / 'TASK.md'), agent_id='/root/carrier_rj45_pod_local_launch_source', work_cutoff=cut.isoformat())
(N / (name + '-opened.json')).write_text(json.dumps(o, indent=2) + '\n')
print(json.dumps(o, indent=2))
print(len(items), 'frozen inputs')
