# INCOMPLETE — historical source proposal, superseded by top-only SMD requirement

Engineering stopped immediately when root relayed the user requirement that all SMD components occupy one side on both boards. Pod U3 must move from the bottom to the top. Root owns new placement and downstream renewal. No source adoption or native pose acceptance occurred.

One isolated route.yaml candidate was authored: a proposed R13.2 northward F.Cu escape to (62.9125,34.7) and a proposed C10.2 ground return to a 0.6/0.3 mm via at (51.2,49). The R13 north edge y35.3 comes from the reopened native 1.025 x 1.4 mm pad at (62.9125,36). A theoretical 0.3 mm annulus-to-pad gap is arithmetic only. Full capsule/foreign-copper/drill clearance and ordinary-router usability were not qualified. C10's proposed site was not installed or accepted. Existing source banks, including C5.2 and the audio clamp prefixes, remain unchanged in this historical candidate.

All 370 frozen inputs verified before and after. Exact copied-input comparison found only route.yaml changed. Native read-only inventory covers 13 neighboring pads. No native candidate generation/preparation, guard, critical-path checker, DRC, graph proof, changed geometry view, library restoration or routing pilot ran. No new FINAL exists. Earlier failed route evidence is preserved by exact reference, with no recursive archive. Source candidate count is 1; pilot count is 0; prior budgets remain spent.

Author self-check readiness is never independent source acceptance. This task claims neither readiness nor independent review. The source comments are proposed design rationale, not clearance proof. Complete qualification belongs after the new top-only placement; none of the historic geometry transfers acceptance to it.

Two setup wrapper errors are recorded: a local inspect.py name shadowed Python's standard library and accidentally executed read-only inventory before runtime initialization; after renaming, the bounded inventory passed, then its wrapper reported a nonexistent exit_code attribute. The original wrapper is retained and corrected to returncode. This did not start routing or change a board.

The archive contains exact before/post route source, its diff, all task scripts/logs/runtime/inventory, frozen native board context, exact envelope/input hashes, inherited qualification identity and historical failure references. Every regular archive member was reopened and hashed; no symlink, duplicate, traversal or nested archive is present. Delivery PASS, if returned by supplied preflight, means this honest interrupted handback is complete, never engineering acceptance.

FIRST-ARTICLE-ONLY / DO-NOT-ORDER. Existing user orientation approval is retained; no release, order or physical acceptance.
