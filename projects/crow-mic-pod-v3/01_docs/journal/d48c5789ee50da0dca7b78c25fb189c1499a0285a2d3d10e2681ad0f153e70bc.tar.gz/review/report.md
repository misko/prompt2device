review_stage: pre-route
review_kind: topology
revieweridentity: carrier_rj45_native_pod_topology_none1
context: FRESH
date: 2026-09-14
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
netlist_sha256: b82a49919941a654940e371ae6860e2429c349316f3aed8d8c503ee075656227
parts_sha256: 24c1d667aa95629d5dabb75f306a3b1f1e2b4293e40230d6c448d4e53da5a287
design_rules_sha256: 7f661d2ef79dd9004962238eac953f194ac18722cd344d1c91443cab29402ca9
schematic_pdf_sha256: 0d7270bbfb7965524ce0a872750a968b0e28bd1d4498b777bdde8358dcc7e605
exact_netlist_sha256: 37062213ddeb1c474ea4cb583004c5c3c34b347cd10137d6b387043ee5c604cf
circuit_json_sha256: 7178651c18b71227d731403b9993f1c17ada455b977994776f8b2a624c4a98f1
kicad_schematic_sha256: 38620864e9bdf7c30cb7422715e4af8019f60f15aaafc1d1a8b835726273d04d

The exact current pod schematic is SOUND for the commissioned pre-route topology lens. No electrical topology defect was found. FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains in force. This review accepts neither a board nor physical orientation, routing, fabrication, stock allocation, release, or ordering.

Measured scope and source delta

All 294/294 envelope input files verified by SHA-256 and size at entry and packaging. All seven subject hashes were independently recomputed with the frozen owning pre_route_review_check.py algorithms; the parts denominator is 34 dossiers. Root's separate 313-input owning-checkpoint audit is not this reviewer's measurement.

The complete supplied preceding-subject inventory has 118 files: 114 are byte-identical to current counterparts, four generated files differ, and none are missing. All paired authored TSX, source scripts, floorplan, route policy, electrical/assembly/first-article rules, footprints, models, and part dossiers are unchanged. The current packet has 37 files without preceding counterparts; these are unpaired context/evidence, not a claim of 37 design additions. The adopted nine-file carrier/shared-generator correction is independently accepted provenance supplied in decision-context. Those external source postimages are outside this pod packet. Its effect does not create a pod electrical change, as the current artifact comparisons below establish. This review does not revalidate carrier source, its 23-member conditional locator exception, or candidate6.

The four changed generated files are circuit.json, schematic.pdf, the native .kicad_sch and exported .net. All 1,188 CircuitJSON records were compared by type: only the one source_project_metadata record and the 15 supplier_footprint_mismatch_warning records differ. Electrical, pin, geometry and drawing record classes are identical. The complete native schematic text becomes identical after normalizing only generated UUID strings and their references. The complete native exported component records, including values, footprints and all non-sheet properties, and every node/pin-function/type assignment are identical to the preceding export. Only generated sheet/path/clock/UUID metadata is excluded from the owning normalized identity. A fresh KiCad CLI export of this frozen native schematic independently yields the same complete component and node inventory.

Independent electrical census

A reviewer-written direct TSX parser derives every literal component, passive connection, chip connection and generated testpoint entry without importing the generator. Its 40 identities and values/MPNs match the hand-authored manifest, CircuitJSON, native symbols and netlist. All 103 physical pins match across TSX, CircuitJSON and native export: 99 connected endpoints on 20 named nets and four intentional NCs, U2.3, U2.7, U3.1 and U3.2. KiCad represents those four as separate singleton NC nets, making 24 nets and 103 nodes. The native schematic contains 64 symbols (40 physical identities and 24 generated power symbols), 120 wires, 49 global labels, six junctions, four text items and four explicit no_connect records.

All 39 maintained electrical invariant declarations were independently evaluated against the source-derived map and native matching inventory. The 12 value-invariant tolerance limits were additionally checked against the exact MPN dossiers. The first-power installed list independently measures 33 unique references, exactly the 40 electrical identities minus TP1–TP7. They are 31 fitted SMD, manually fitted J1, and the off-board MK1 capsule represented by two wire landings. The 31 SMD source disposition is top only. J1, MK1 and the seven bare copper testpoints are excluded from machine assembly; board-mounted fitted population is 32. Four mounting holes belong to mechanical board intent, not this schematic census. No physical board population measurement was made here.

Integrated topology and ratings judgment

The custom analog/DC spoke is preserved: J1 pins 1/3/7 are 12V_POD; 2/6/8 are GND; 5 is AUDIO_P; 4 is AUDIO_N; 9/10 are POD_SHIELD. The entire POD_SHIELD net contains exactly J1.9 and J1.10 and has no GND connection. The contract preserves isolated carrier CHASSIS. The factory Weidmüller 8909650150 Cat6A cord has straight-through T568B identity and audio pair 4/5. This is NOT Ethernet or PoE; mating is power off. Jack-only 1.5 A and 20 mΩ figures do not establish plug, cord or installed contact performance. The 150 VAC manufacturer row is not converted to DC. The retained 28.5 V project insulation ceiling is an explicitly qualified inference; its 24.4 V clamp plus 10% screen is 26.84 V.

The source/native chain is 12V_POD → F1 → 12V_FUSED → D1 anode → D1 cathode/VIN_PROTECTED. D2's cathode, R14, C1/C2 and U2 IN/EN join the protected node; D2/R14/capacitor returns are GND. D1 hot leakage at 50 µA through R14's +1% corner produces a 0.23735 V reverse magnitude, below the retained 0.3 V U2 limit. R14 dissipation is 37.45 mW at 13.2 V and 127.95 mW at 24.4 V with minimum resistance, below its dossier's 250 mW at 70 C. F1 remains 0.10 A hold / 0.25 A trip at 23 C, with a 10 A prospective-fault ceiling; that does not prove 0.10 A hold over roof temperature.

D2's 15 V standoff exceeds the 13.2 V normal input ceiling. The retained 24.4 V component clamp is below U2's 35 V operating/36 V absolute input ratings and C1/C2's 50 V ratings. The admitted component transient is 10 A / 244 W for the stated waveform, with source coordination and installed waveform still owed. There is no lightning or system surge qualification. Connector-side nominal capacitance remains 10.1 µF against the 47 µF cap. The 10.5–13.2 V header range, 0.10 A spoke allocation, 20 mA expected load and 30 mA first-power current limit remain unchanged.

Fresh images of TI OPA1679 Figure 5-5/page 5, TPS7A49 DGN configuration/page 4 and TPD2E2U06 DRL configuration/page 3 were inspected. U2 pins 4/9 are grounded, pin 7 DNC is open, pin 3 NC is open, pin 6 has C4, and pins 1/2 use the 324 kΩ/100 kΩ feedback network with 10 nF feed-forward. Independent 16-corner feedback calculation, using signed current into the device and Vout = Vref(1+Rt/Rb)+Ifb·Rt, gives 4.792587–5.229513 V, within 4.79–5.23 V. C5's explicitly assumed derated floor is 3.825 µF against 2.2 µF; exact effective-capacitance and thermal measurements remain owed.

R3 3.9 kΩ/C7 100 µF filter capsule bias; R4 is 2.2 kΩ, MK1 polarity is MIC_RAW/GND, and C8/R5 AC couple to buffered VREF. U1A buffers the R6/R7 divider. U1B has inverting gain −18k/22k; U1C restores polarity using equal 10 kΩ resistors. Two 100 Ω output resistors preserve nominal differential gain 18/11. At 1.2 Vrms differential, each balanced leg swings approximately 0.849 V peak about VREF. U1's supply stays above its 4.5 V minimum and the inverting inputs remain near half-rail rather than following the capsule excursion. U1D has private SPARE_BUF unity feedback and does not parallel another output. U3 pins 3/5 clamp AUDIO_P/AUDIO_N, pin 4 is GND, pins 1/2 are open. Its 5.5 V working limit and 12.4 V TLP clamp do not prove system ESD immunity. The physical no-stub path, return inductance, long-cable stability, gain/noise/clipping/acoustic polarity and temperature behavior remain first-article or layout obligations.

Current visual integration and ERC

All four delivered PDF pages were freshly viewed as images, covering 7 + 11 + 10 + 12 = 40 components. Connector labels and the isolated shell net, diode K/A direction, the VIN_PROTECTED page-2 input label, LDO NC/DNC labels, capsule polarity, reference buffer, both audio legs and spare follower were legible. Current identity headers show circuit hash prefix 7178651c18b71227 and the correct page/component census. This is a topology integration inspection, not substitution for the separately commissioned readability witness or human PCB orientation.

Both PDFs were rendered by Poppler at 2400 × 1620. Every pixel outside the precise generated identity-header strip [0,130,2400,160) is equal: 3,816,000 RGB pixels/page, 15,264,000/15,264,000 total. Actual changed-pixel boxes are [465,134,1059,157) on page 1 and [465,134,1071,157) on pages 2–4. No changed body remains uninspected.

Retained ERC measures zero errors and 158 warnings: 64 lib_symbol_issues and 94 endpoint_off_grid. Embedded symbols and fresh exported node parity support the classification, but do not erase it. Generated passive IC pin typing limits ERC coverage; the explicit datasheet/source/native pin review supplies the topology judgment. This is not an all-severity-clean claim.

Preserved physical and release holds

The frozen connector SOURCE receipt is PASS for one assembly/J1 while FULL is INCOMPLETE with nine distinct physical obligations: installed cable routing, realized interface fit, mating, unmating, latch/pull operation, reaction load, connector/enclosure stack, installed plug/boot axial stack and radial stack. Current five-view human orientation is pending. No inherited approval is asserted. The source's R-POUR disposition remains exactly the three pod input-chain nets; its physical copper numbers were not renewed by this schematic review. Carrier's conditional 23-reference locator exception cannot become effective through this pod verdict and remains subject to its current atlas/render gate.

Actual routing/returns, placement and service access, machine/human orientation, live sourcing allocation, manual soldering, capsule mounting/strain relief, cord continuity/loop resistance, UV/environmental suitability and first-article electrical/EMC/thermal tests remain owed under their existing owners. No extra physical prerequisite is introduced here. No live source/native-board edits, producer/checkpoint restamps, children or commits were performed.

Evidence integrity and method limits

The archive retains independent scripts, complete inventories, input checks, native re-export, exact source/render context, comparison proofs, datasheet figures, bounded runtime receipts and raw logs. A PyMuPDF probe failed because fitz is unavailable; Poppler/Pillow completed the actual image work. An initial value comparison required explicit removal of the rendered Ω unit suffix. An initial exploratory feedback calculation used the opposite sign convention; the corrected KCL equation and final 16-corner result above are authoritative, and both raw outputs remain retained. A wrapper bootstrap rejected the invalid work-class label before any child ran; its corrected finite local runtime is used for all engineering subprocesses. These diagnostics are not engineering failures or hidden passing gates.

Every archive regular member was reopened and checked for path/type/size/hash; traversal, duplicates, links and recursive archives are excluded. The five-output delivery and supplied preflight are independently validated after packaging. Delivery PASS describes completed honest evidence, not physical or order acceptance.
