from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,io
R=Path.cwd();T=R/'06_build/task_runs/rj45-pod-topology-review-none1';S=T/'scratch';O=T/'outputs'
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,d):p.write_text(json.dumps(d,indent=2,sort_keys=True))
envelope=json.loads((T/'envelope.json').read_text());verified=[]
for x in envelope['input_packet']:
 p=R/x['path'];verified.append({'path':x['path'],'valid':p.is_file() and p.stat().st_size==x['size'] and sha(p.read_bytes())==x['sha256']})
assert all(x['valid'] for x in verified);save(S/'inputs-after.json',verified)
summary=json.loads((S/'validation-summary.json').read_text());ratings=json.loads((S/'ratings-population.json').read_text())
evidence={'schema':1,'revieweridentity':'carrier_rj45_native_pod_topology_none1','review_stage':'pre-route','review_kind':'topology','context':'FRESH','design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','subject':envelope['subject'],'subject_hashes':json.loads((R/'expected-subject.json').read_text()),'methods':['Independent complete packet SHA-256/size verification before and after','Frozen owning seven-subject-hash calculation','Complete preceding/current paired-file comparison','Independent direct TSX component/MPN/value/pin parser compared with CircuitJSON and native netlist','Fresh KiCad native schematic netlist export; complete component properties and node identities compared','39 independent electrical invariant evaluations and 12 exact-dossier tolerances','Native UUID-only structural equality and all CircuitJSON row-class comparison','Actual viewing of all four current PDF pages and three TI package figures','Full-page Poppler/Pillow RGB equality excluding only the generated identity-header line','Independent first-power population and signed-feedback-corner/rating calculations'],'counts':dict(summary,input_files=294,paired_subject_files=118,unchanged_paired_files=114,changed_generated_files=4,current_unpaired_files=37,first_power_refs=33,smd_refs=31,visual_pages=4,physical_full_obligations=9),'findings':[],'preserved_holds':['FIRST-ARTICLE-ONLY','DO-NOT-ORDER','Connector FULL INCOMPLETE: nine physical obligations','Current five-view human orientation pending','No native board/routing/physical release/order acceptance'],'limitations':['Source gate PASS is retained frozen evidence, not re-executed physical qualification','Root owns separate 313-input checkpoint authority audit','Carrier source/candidate6/23-reference conditional locator exception are outside pod measurement','ERC retained zero errors, 64 library warnings and 94 off-grid warnings; not all-severity clean','Exact effective capacitance, power-off cord/mating/contact/UV/environmental and first-article tests remain owed'],'calculations':ratings['calculations'],'diagnostics':['fitz unavailable; Poppler/Pillow successfully used','Initial value parse failed on native Ω suffix; explicit unit handling corrected','Exploratory feedback sign corrected by KCL; ratings2 is final','Initial wrapper rejected work_class check before child launch; corrected to finite local runtime']}
save(O/'evidence.json',evidence)
save(O/'result.json',{'subject':envelope['subject'],'checks':{k:'PASS' for k in envelope['completion']['checks']},'unresolved':[]})
files={}
for p in S.rglob('*'):
 if p.is_file() and p.name not in ['package.log','package-runtime.json']:
  assert not p.is_symlink();files['review/'+p.relative_to(S).as_posix()]=p
for n in ['report.md','evidence.json']:files['judgment/'+n]=O/n
for n in ['TASK.md','expected-subject.json','06_build/task_runs/rj45-pod-topology-review-none1/envelope.json','context/skills/kicad-pcb/scripts/pre_route_review_check.py']:
 files['inputs/'+n]=R/n
for x in envelope['input_packet']:
 n=x['path'];p=R/n
 if n.startswith(('project/03_src/rules/','project/02_parts/','project/03_tscircuit/','project/04_kicad/','project/06_build/netlists/','project/06_build/verification/','preceding-receipts/')) and p.suffix not in ['.pdf','.step','.stp','.wrl']:
  files['inputs/'+n]=p
for n in ['project/03_tscircuit/build/schematic.pdf','preceding-subject/03_tscircuit/build/schematic.pdf','preceding-subject/03_tscircuit/build/circuit.json','preceding-subject/04_kicad/crow_mic_pod_v3.kicad_sch','preceding-subject/06_build/netlists/crow_mic_pod_v3.net']:
 files['inputs/'+n]=R/n
members=[];a=O/'evidence.tar.gz'
with tarfile.open(a,'w:gz') as tar:
 for name,p in sorted(files.items()):
  assert not p.is_symlink() and '..' not in PurePosixPath(name).parts and not name.endswith(('.tar.gz','.tgz','.tar'))
  b=p.read_bytes();t=tarfile.TarInfo(name);t.size=len(b);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(b));members.append({'path':name,'size':len(b),'sha256':sha(b)})
seen=set()
with tarfile.open(a,'r:gz') as tar:
 for t,row in zip(tar.getmembers(),members,strict=True):
  assert t.isfile() and t.name not in seen and t.name==row['path'];seen.add(t.name)
  assert not PurePosixPath(t.name).is_absolute() and '..' not in PurePosixPath(t.name).parts
  b=tar.extractfile(t).read();assert len(b)==row['size']==t.size and sha(b)==row['sha256']
manifest={'archive_sha256':sha(a.read_bytes()),'archive_size':a.stat().st_size,'member_count':len(members),'members':members}
save(O/'evidence-manifest.json',manifest)
print(json.dumps({'inputs_verified':len(verified),'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'regular_members_reopened':len(members),'outputs':sorted(p.name for p in O.iterdir())},indent=2))
