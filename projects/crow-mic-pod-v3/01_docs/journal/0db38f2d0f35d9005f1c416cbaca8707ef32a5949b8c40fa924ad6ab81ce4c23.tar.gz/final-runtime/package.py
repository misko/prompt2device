import json,hashlib,sys,tarfile,io,re,xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime,timezone
import pcbnew
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');P=R/'projects/crow-mic-pod-v3';D=P/'06_build/task_runs/rj45-pod-placement-after-orientation1';S=D/'scratch';O=D/'outputs';sys.path.insert(0,str(R/'skills/pcb-design/scripts'))
from pipeline_execution import TaskEnvelope,verify_input_packet,envelope_sha256,writer_scope_receipt
from pipeline_runtime import _tree_snapshot,_changed_paths,_snapshot_sha256

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,d):p.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
def digest(d):return hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def record(p):return {'path':str(p.relative_to(P)),'size':p.stat().st_size,'sha256':sha(p)}
e=TaskEnvelope.from_json((D/'envelope.json').read_text());a=json.loads((D/'admission.json').read_text());pre=json.loads((S/'preflight.json').read_text());assert verify_input_packet(e,P)[0]
for row in pre['protected_files']:assert sha(R/row['path'])==row['sha256'],row['path']
boardpath=P/'04_kicad/crow_mic_pod_v3.kicad_pcb';board=pcbnew.LoadBoard(str(boardpath));rawpads=[]
for fp in board.GetFootprints():
 for p in fp.Pads():
  rawpads.append({'uuid':p.m_Uuid.AsString(),'ref':fp.GetReference(),'pin':p.GetNumber(),'net':p.GetNetname(),'x':round(pcbnew.ToMM(p.GetPosition().x),6),'y':round(pcbnew.ToMM(p.GetPosition().y),6),'layers':[board.GetLayerName(i) for i in p.GetLayerSet().Seq()]})
rawpads.sort(key=lambda r:(r['ref'],r['pin'],r['uuid']));bypin={r['uuid']:r for r in rawpads};assert len(bypin)==len(rawpads)
tracks=list(board.GetTracks());zones=[{'net':z.GetNetname(),'rule_area':z.GetIsRuleArea()} for z in board.Zones()];assert len(tracks)==0 and all(z['net']=='GND' and not z['rule_area'] for z in zones)
def parse_sexpr(text):
 tokens=re.findall(r'"(?:\\.|[^"\\])*"|[()]|[^\s()]+',text);stack=[];root=None
 for token in tokens:
  if token=='(':
   new=[]
   if stack:stack[-1].append(new)
   else:root=new
   stack.append(new)
  elif token==')':stack.pop()
  else:stack[-1].append(json.loads(token) if token.startswith('"') else token)
 assert not stack
 return root
def children(node,key):return [c for c in node if isinstance(c,list) and c and c[0]==key]
def child(node,key):return children(node,key)[0]
def value(node,key):return child(node,key)[1]
root=parse_sexpr((P/'06_build/netlists/crow_mic_pod_v3.net').read_text());netrows=children(child(root,'nets'),'net');components=sorted([{'ref':value(c,'ref'),'value':value(c,'value'),'footprint':value(c,'footprint')} for c in children(child(root,'components'),'comp')],key=lambda r:r['ref']);pins=sorted([{'net':value(n,'name'),'ref':value(q,'ref'),'pin':value(q,'pin')} for n in netrows for q in children(n,'node')],key=lambda r:(r['ref'],r['pin'],r['net']));assert len(components)==40 and len(pins)==103

for p in pins:assert any(q['ref']==p['ref'] and q['pin']==p['pin'] and q['net']==p['net'] for q in rawpads),p
census={'component_count':len(components),'pin_count':len(pins),'nets':len(netrows),'component_sha256':digest(components),'pin_map_sha256':digest(pins),'semantic_digest_method':'SHA-256 of sorted-key compact JSON UTF-8; component rows sorted ref; pin rows sorted ref,pin,net','components':components,'pin_map':pins,'native_pad_count':len(rawpads),'native_pads':rawpads,'native_pad_sha256':digest(rawpads),'pcb':record(boardpath),'tracks_and_vias':len(tracks),'zones':zones}
put(S/'native-census.json',census)
oldpath=P/'06_build/handoffs/rj45-pod-placement-after-orientation1/context/projects/crow-mic-pod-v3/04_kicad/crow_mic_pod_v3.kicad_pcb';oldboard=pcbnew.LoadBoard(str(oldpath));oldpads={p.m_Uuid.AsString():(f.GetReference(),p.GetNumber(),p.GetNetname(),pcbnew.ToMM(p.GetPosition().x),pcbnew.ToMM(p.GetPosition().y)) for f in oldboard.GetFootprints() for p in f.Pads()};assert len(list(oldboard.GetTracks()))==0
classified=[]
for report_path,subject,sourcepads,label in [(P/'06_build/drc/pre_route.json',boardpath,bypin,'fresh placement'),(P/'06_build/drc/gate.json',oldpath,oldpads,'inherited stale canonical gate')]:
 raw=json.loads(report_path.read_text());assert not raw['violations'] and not raw['schematic_parity'] and len(raw['unconnected_items'])==58
 rows=[]
 for idx,row in enumerate(raw['unconnected_items'],1):
  matches=[]
  for item in row['items']:
   actual=sourcepads[item['uuid']]
   if isinstance(actual,tuple):actual=dict(zip(['ref','pin','net','x','y'],actual))
   assert abs(actual['x']-item['pos']['x'])<0.00001 and abs(actual['y']-item['pos']['y'])<0.00001
   assert f"[{actual['net']}]" in item['description'] and f"of {actual['ref']}" in item['description']
   matches.append(actual)
  assert len(matches)==2 and matches[0]['net']==matches[1]['net'] and matches[0]['net']!='GND'
  endpoints=' to '.join(f"{m['ref']}.{m['pin']}" for m in matches);net=matches[0]['net']
  cause=f"Unrouted {net} connection {endpoints}: exact placement has zero track/via primitives and only GND zones, so no authored copper connects these distinct {net} pads. Routing import/stitch was not reached."
  rows.append({'row':idx,'raw':row,'native_endpoints':matches,'cause':cause,'classification':'unrouted-net-edge','disposition':'OPEN; future routing after owning placement gates; no waiver','native_uuid_net_position_verified':True})
 classified.append({'report':record(report_path),'subject_board':record(subject),'authority':label,'violations':[],'schematic_parity':[],'unconnected_items':rows,'coverage':{'violations':0,'unconnected_items':58,'endpoints_verified':116,'schematic_parity':0},'raw_metadata':{k:v for k,v in raw.items() if k not in ['violations','unconnected_items','schematic_parity']}})
put(S/'drc-classification.json',classified)
lines=['# Individual native DRC classification','', 'Fresh placement and inherited stale canonical gate are separate subjects. Each raw row and all 116 endpoints per report are preserved in drc-classification.json.','']
for c in classified:
 lines += [f"## {c['authority']}",'',f"Board `{c['subject_board']['sha256']}`. Native violations 0, unconnected 58, parity 0.",'','| Row | Net | Endpoints | Cause |','|---|---|---|---|']
 for r in c['unconnected_items']:lines.append(f"| {r['row']} | {r['native_endpoints'][0]['net']} | "+' ↔ '.join(f"{x['ref']}.{x['pin']}" for x in r['native_endpoints'])+' | '+r['cause']+' |')
(S/'drc-classification.md').write_text('\n'.join(lines)+'\n')
stale={'validate_argv':['/usr/bin/python3','-B',str(R/'skills/kicad-pcb/scripts/pcb_flow.py'),'validate',str(P)],'returncode':2,'stdout':'STALE handoff: source hash changed; board hash changed; DRC gate is stale\n','gate':record(P/'06_build/drc/gate.json'),'gate_mtime_ns':(P/'06_build/drc/gate.json').stat().st_mtime_ns,'current_subject_mtimes_ns':{str(f.relative_to(P)):f.stat().st_mtime_ns for f in [boardpath,boardpath.with_suffix('.kicad_sch'),boardpath.with_suffix('.kicad_pro'),boardpath.with_suffix('.kicad_dru')]},'handoff_generation':'NOT RUN: owning freshness condition fails; existing gate and handoff preserved'}
assert stale['gate_mtime_ns']<max(stale['current_subject_mtimes_ns'].values());put(S/'handoff-blocker.json',stale)
now=datetime.now(timezone.utc).isoformat();(P/'01_docs/STATUS.md').write_text(f'''# STATUS beacon — crow-mic-pod-v3

stage: placement
step: Normal continuation stopped at P-MODEL-REG J1 F.Fab mismatch
measure: MEASURED: one continuation rc1 in15.927s;40components103pins, placement7/7, nativeDRC0/58/0 individually classified. J1 body exceeds F.Fab1.059mm versus0.500mm tolerance; U2PASS.
state: blocked
next: Root closes exact evidence handback and owns disposition of P-MODEL-REG. P-ORIENT and placement review NOT RUN; no current user orientation approval. Canonical gate/handoff stale and preserved. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.
op_pid:
updated: {now}
''')
with (P/'01_docs/journal/placement.md').open('a') as f:f.write(f'''\n## {now} — single reviewed-schematic continuation stopped normally\n\nMEASURED: task rj45-pod-placement-after-orientation1 verified335/335 frozen inputs and231 live source/method preimages before ONE exact normal continuation. Resume reverified311/311 source/prelayout-input,11/11 prelayout and7/7 schematic checkpoint bindings; current schematic reviews2/2PASS. Promoted reviewed schematic and generated40-component PCB7dc54ff1004aaae5e94d87088469b30f228a8684145869ba15b8b092e1e49962 normally. Placement feasibility7/7 passing or N-A; physical placement3/3PASS; fitted model coverage32/32PASS; native placementDRC0/58/0. Every58 unconnected raw row and116 endpointUUID/net/positions individually checked and classified against the exact current native board: zero tracks/vias, onlyGND zones, each missing non-GND connection remains unrouted. The preserved inherited gate0/58/0 is separately bound/classified against frozen priorPCB3c472e80 and is stale for currentPCB.\n\nThe normal route-prep stage passed0.564s, producing r0 with86 seed segments/vias; no routing import, taps, stitch or acceptance executed. First blocking gate [5d] P-MODEL-REG failed: J1 body exceeds F.Fab by1.059mm against0.500mm tolerance; centre delta0.014mm, courtyard excess0.000mm,12/12 drilled centres inside, minimum pad margin1.181mm, mount-side fraction0.967526. U2 groupPASS; aggregate1/2. Full raw failure coupon/model/images/receipt preserved. P-ORIENT and placement review NOT RUN; no approval inferred. Inner runtime15.927s rc1; outer15.999674s rc1,22610B/234lines retained. No retry, source/config edit, TSX rerun, checkpoint restamp, stale route import, camera search or model reset. LAYOUT001closed3/3 unchanged. Source semantic inventories:40components103pins24nets; hashes in handback.\n\nCompact handoff generation blocked by stale canonicalDRC gate; pcb_flow validate rc2 names source/board hashes and staleDRC. The prior gate and handoff are preserved. Root owns closure and disposition; worker retains exclusive ownership until actualFINAL. Outputs:06_build/task_runs/rj45-pod-placement-after-orientation1/outputs/{{report.md,evidence.json,evidence-manifest.json,evidence.tar.gz,result.json}}. FIRST-ARTICLE-ONLY/DO-NOT-ORDER; connectorFULL9 physical unknowns remain deferred.\n''')
# Capture final source and exclusive scope evidence before packaging; output/scratch are admission-ignored.
after=_tree_snapshot(P,ignored=frozenset(a['ignored']));scope=writer_scope_receipt(e.writer_scope,_changed_paths(a['before'],after),before_sha256=_snapshot_sha256(a['before']),after_sha256=_snapshot_sha256(after),protected_paths=tuple(sorted((e.output_path,a['claim']))));assert scope['status']=='PASS',scope
put(S/'final-scope.json',scope)
for row in pre['protected_files']:assert sha(R/row['path'])==row['sha256']
assert verify_input_packet(e,P)[0]
put(S/'protected-postflight.json',{'input_count':335,'verified':True,'protected_count':len(pre['protected_files']),'unchanged':True,'files':pre['protected_files']})
files=set()
for name in _changed_paths(a['before'],after):
 p=P/name
 if p.is_file():files.add(p)
# Include complete owned registration subjects, including unchanged render/model files.
for folder in ['04_kicad','06_build/pre_route/native_registration/failed_attempts/j1_wurth_615008160221_official_step-20260913T033812Z-c43712688cf4','06_build/pre_route/native_registration/u2_ti_dgn0008g_official_step','06_build/verification/pipeline/bundles/placement_feasibility']:
 for p in (P/folder).rglob('*'):
  if p.is_file():files.add(p)
for name in ['03_tscircuit/build/circuit.json','03_tscircuit/build/schematic.pdf','03_tscircuit/manifest.yaml','03_src/floorplan.yaml','03_src/route.yaml','03_src/rebuild_all.sh','06_build/netlists/crow_mic_pod_v3.net','06_build/checkpoints/schematic.json','06_build/checkpoints/prelayout.json','06_build/checkpoints/prelayout-inputs.json','06_build/drc/gate.json','06_build/agent_handoff.yaml','06_build/verification/connector_assembly_contract.json','06_build/verification/connector_assembly_source_gate.json','06_build/verification/connector_assembly_full_gate.json','06_build/verification/model_coverage.json','08_reviews/pre-route_schematic_render.md','08_reviews/pre-route_topology.md']:
 files.add(P/name)
files.add(oldpath);files.add(D/'envelope.json');files.add(D/'admission.json')
for p in S.iterdir():
 if p.is_file():files.add(p)
for p in files:assert p.is_file() and not p.is_symlink(),p
runtime=json.loads((S/'runtime.json').read_text());assert runtime['returncode']==1 and runtime['status']=='FAIL'
notrun=['P-ORIENT','placement PR-REVIEW/P-ROUTEBASE','route_import','route_taps','stitch','realized route checks','route_acceptance','layout seal','fabrication','release','physical qualification']
evidence={'schema':1,'envelope_sha256':envelope_sha256(e),'subject':e.subject.to_mapping(),'domain_result':'FAIL','stopping_gate':'[5d] P-MODEL-REG','failure':'J1 native body exceeds F.Fab by 1.059 mm; tolerance 0.500 mm','aggregate_registration':{'graded':1,'total':2,'J1':'FAIL','U2':'PASS'},'command':json.loads((S/'command.json').read_text()),'runtime':runtime,'inner_runtime':json.loads((P/'06_build/pipeline_state/rj45_renewed_placement.json').read_text()),'inputs':{'frozen':335,'verified':335,'protected_live_preimages':231,'protected_unchanged':True},'writer_scope':scope,'source_and_board_census':census,'drc_classification':classified,'handoff':stale,'not_run':notrun,'route_prep':{'status':'PASS','elapsed_s':0.564,'seed_primitives_vias':86,'path':'06_build/route/r0.kicad_pcb','routing_acceptance':False},'claims':{'first_article_only':True,'do_not_order':True,'orientation_approval':False,'physical_full_unknowns':9,'retry_count':0},'preserved_files':[record(p) for p in sorted(files)]}
put(O/'evidence.json',evidence)
report=f'''# Pod normal placement continuation\n\nMEASURED domain result **FAIL at [5d] P-MODEL-REG**. The single authorized continuation exited1 after15.927s (outer15.999674s;2026-09-13T03:38:07.178903Z to03:38:23.178582Z). J1 native body exceeds F.Fab by1.059mm against0.500mm tolerance. Its centre delta is0.014mm, courtyard excess0.000mm, drilled centres12/12 inside, minimum pad margin1.181mm, and mounted-side fraction0.967526. U2PASS; aggregate1/2. No source repair or retry occurred.\n\n335/335 frozen inputs,231/231 live source/method preimages and exact7/7 schematic checkpoint bindings verified before launch. Normal driver reverified311/311 inputs,11/11 prelayout checkpoint bindings and schematic reviews2/2. Final frozen inputs and protected source/method preimages remain unchanged; exclusive writer scopePASS.\n\n40components103pins24nets; native board113physical pads. Component semantic SHA256 `{census['component_sha256']}`; pin-map semantic SHA256 `{census['pin_map_sha256']}`. These hash compact sorted-key JSON inventories retained in evidence.json/native-census.json. Current PCB SHA256 `{sha(boardpath)}`. Exact netlist SHA256 `{sha(P/'06_build/netlists/crow_mic_pod_v3.net')}`.\n\nThe generated PCB passed placement feasibility7/7 passing or N-A, physical placement3/3, fitted model coverage32/32, pad-separation, placement policy and native placement DRC0/58/0. All58 unconnected rows are individually classified with raw descriptions, UUIDs, nets and coordinates,116/116 endpoint checks. Every row is an open non-GND connection on this zero-track/via placement with onlyGND zones. This establishes unrouted placement, not routing acceptance. The inherited canonical gate0/58/0 is separately preserved/classified against priorPCB `{sha(oldpath)}`; it is stale for the current board.\n\nNormal route-prepPASS0.564s produced86 seed primitives/vias in06_build/route/r0.kicad_pcb. **NOT RUN:** {', '.join(notrun)}. No current user orientation approval exists. ConnectorSOURCE admission remains prototype-only;FULL9 physical unknowns deferred. FIRST-ARTICLE-ONLY / DO-NOT-ORDER. LAYOUT001closed3/3 unchanged.\n\nCanonical compact handoff generation is blocked by its staleDRC gate. Final pcb_flow validate rc2: source hash changed; board hash changed; DRC gate stale. Protected source/method bytes are unchanged; the permitted promoted schematic and generated PCB changed. Existing gate and handoff remain intact. No gate deletion/restamp, source/config edit, TSX rerun, camera search, new model reset, stale route import, or unreviewed routing occurred.\n\nFailure report:06_build/pre_route/model_registration.md. Native J1 failure subjects:06_build/pre_route/native_registration/failed_attempts/j1_wurth_615008160221_official_step-20260913T033812Z-c43712688cf4/. FreshDRC:06_build/drc/pre_route.json. Raw continuation and runtime:06_build/task_runs/rj45-pod-placement-after-orientation1/scratch/continuation.log andruntime.json. Complete handback:{str(O)}.\n\nDelivery checks concern complete honest evidence delivery; engineering failure remains explicit and is not converted toPASS. Root owns final closure and archive/commit.\n'''
(O/'report.md').write_text(report)
# Archive a fixed, nonrecursive file set, including report/evidence but excluding itself/manifest/result.
files.update([O/'evidence.json',O/'report.md']);members=[]
with tarfile.open(O/'evidence.tar.gz','w:gz',format=tarfile.PAX_FORMAT) as tar:
 for p in sorted(files):
  name=p.relative_to(P).as_posix();data=p.read_bytes();t=tarfile.TarInfo(name);t.size=len(data);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(data));members.append({'path':name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
reopened=[]
with tarfile.open(O/'evidence.tar.gz','r:gz') as tar:
 seen=set()
 for m in tar.getmembers():
  assert m.isfile() and m.name not in seen and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  assert not m.name.endswith('/evidence.tar.gz');seen.add(m.name);data=tar.extractfile(m).read();reopened.append({'path':m.name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
assert reopened==members
put(O/'evidence-manifest.json',{'schema':1,'archive_sha256':sha(O/'evidence.tar.gz'),'archive_size':(O/'evidence.tar.gz').stat().st_size,'member_count':len(members),'members':members,'all_regular_members_independently_reopened':True})
put(O/'result.json',{'subject':e.subject.to_mapping(),'checks':{k:'PASS' for k in e.completion['checks']},'unresolved':[]})
print(json.dumps({'domain':'FAIL P-MODEL-REG','component_sha256':census['component_sha256'],'pin_sha256':census['pin_map_sha256'],'board_sha256':sha(boardpath),'archive_sha256':sha(O/'evidence.tar.gz'),'members':len(members),'output_dir':str(O),'scope':scope['status']}))
