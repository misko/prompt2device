#!/usr/bin/python3
import gzip, hashlib, io, json, os, stat, sys, tarfile
from pathlib import Path, PurePosixPath

root = Path(sys.argv[1]).resolve()
archive_path = Path(sys.argv[2]).resolve()
manifest_path = Path(sys.argv[3]).resolve()

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''): h.update(chunk)
    return h.hexdigest()

members=[]
for path in sorted(root.rglob('*')):
    info=path.lstat()
    if stat.S_ISLNK(info.st_mode): raise RuntimeError(f'symlink refused: {path}')
    if path.is_dir(): continue
    if not stat.S_ISREG(info.st_mode): raise RuntimeError(f'special file refused: {path}')
    rel=path.relative_to(root).as_posix()
    pp=PurePosixPath(rel)
    if pp.is_absolute() or any(p in ('','.','..') for p in pp.parts): raise RuntimeError(f'unsafe path: {rel}')
    members.append({'path':rel,'size':info.st_size,'sha256':sha(path)})
if len({m['path'] for m in members}) != len(members): raise RuntimeError('duplicate member')

with archive_path.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tf:
            for row in members:
                path=root/row['path']
                ti=tf.gettarinfo(str(path), arcname=row['path'])
                ti.uid=ti.gid=0; ti.uname=ti.gname=''; ti.mtime=0
                with path.open('rb') as f: tf.addfile(ti,f)

seen=[]
with tarfile.open(archive_path,'r:gz') as tf:
    for ti in tf:
        pp=PurePosixPath(ti.name)
        if pp.is_absolute() or any(p in ('','.','..') for p in pp.parts): raise RuntimeError(f'unsafe archive member: {ti.name}')
        if not ti.isfile() or ti.issym() or ti.islnk(): raise RuntimeError(f'non-regular archive member: {ti.name}')
        f=tf.extractfile(ti)
        data=f.read() if f else b''
        got={'path':ti.name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        seen.append(got)
if seen != members: raise RuntimeError('archive reopen census mismatch')

manifest={'schema':1,'archive':'evidence.tar.gz','archive_sha256':sha(archive_path),'archive_size':archive_path.stat().st_size,'member_count':len(members),'members':members,'validation':{'all_members_reopened':True,'regular_only':True,'no_symlinks':True,'no_traversal':True,'no_duplicates':True,'no_recursive_archive':True}}
manifest_path.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps({'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'member_count':len(members)},sort_keys=True))
