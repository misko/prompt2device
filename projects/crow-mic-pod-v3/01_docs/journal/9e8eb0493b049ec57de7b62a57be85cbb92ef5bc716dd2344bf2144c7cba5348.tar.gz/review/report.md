review_stage: pre-route
review_kind: render
reviewer: Codex /root/rj45_pod_render_toponly1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 0131d5756ed1bb390280558718af114d5d32842d909cf5a73d67330804a39101
design_rules_sha256: 7f661d2ef79dd9004962238eac953f194ac18722cd344d1c91443cab29402ca9
prepared_board_sha256: 8ba635bf9f1287f42ec169aa705a1f5bc87d48b3b330a5e5a196d36b1f61a536

# Fresh independent pod top-only pre-route render review

The placement is visually and mechanically sound for the commissioned pre-route scope. This is a first-article placement verdict only. It is not routing acceptance, manufacturing-fit proof, sourcing acceptance, or permission to order.

## Independent measurements

- Reopened native board: `crow_mic_pod_v3.kicad_pcb`, SHA-256 `0131d5756ed1bb390280558718af114d5d32842d909cf5a73d67330804a39101`.
- Reopened prepared r0: SHA-256 `8ba635bf9f1287f42ec169aa705a1f5bc87d48b3b330a5e5a196d36b1f61a536`.
- The native and r0 boards have identical footprint refs, positions, rotations, sides, pad geometry, attributes, reference presentation, and model transforms for all 44 footprints.
- Edge-line centres are X 20.00–80.00 mm and Y 20.00–60.00 mm: nominal board size 60.00 × 40.00 mm. The pcbnew edge-stroke bounding box is 60.10 × 40.10 mm because the Edge.Cuts stroke is 0.10 mm.
- Footprint census: 44 total, 44 front, 0 back. Population census: 31 fitted SMD on F.Cu; J1 is the sole fitted THT component; MK1 is a two-pad off-board wire landing; TP1–TP7 are seven bare probe features; H1–H4 are four bare 3.20 mm NPTH mounting holes.
- Model census: 32 models resolve, corresponding to the 31 fitted SMD and J1. MK1, TP1–TP7, and H1–H4 correctly have no component body model.
- J1 is at (45.50, 25.86) mm, 0°, front. Its footprint has eight 0.80 mm signal drills, two 3.18 mm NPTH guides, and two 2.00 × 1.00 mm oval shell slots in 2.50 × 1.50 mm lands. The manufacturer-derived model/body is nominally 15.00 × 13.45 × 14.70 mm above the PCB. The measured mouth plane is 0.50 mm outside the north edge, with access axis toward local/board −Y.
- J1 model registration reopens as PASS: 12/12 attachment centres graded, centre delta 0.024 mm, 0.000 mm beyond F.Fab/courtyard, and 0.968 measured front-side fraction. This establishes registration only; it does not prove manufactured seating or cord/enclosure fit.
- U2 model registration reopens as PASS: 13/13 pad centres graded, centre delta 0.000 mm, 0.000 mm beyond courtyard. The 0.903 mm beyond the 3 × 3 mm Fab body is the official gull-wing lead envelope and remains within the courtyard.
- Mounting holes are at (24,24), (76,24), (24,56), and (76,56) mm. Conservative nearest footprint-bounding-box gaps from the 3.20 mm drill edges are 4.125 mm (H1→TP1), 7.991 mm (H2→C7), 2.125 mm (H3→TP4), and 7.653 mm (H4→MK1). TP1/TP4/MK1 are bare features; fitted component bodies do not obstruct mounting access in the full-board renders.

## Visual judgment

All two approved-native images, five populated cardinal views, five focused J1 views, six J1 registration images, and four U2 registration images were opened individually. One additional full-scene bottom-oblique render was generated from a byte-identical scratch copy with real occlusion retained.

J1’s receptacle mouth is visibly open toward the outside/cable side at board −Y. The latch/key geometry, shield shell, guides, signal pins, and two shell tabs correspond to the footprint and official STEP in top, inside, outside, and both profile views. The body projects beyond the board as intended, while the rear pin field and adjacent U3 remain inside the board. The explicit user-approved P-ORIENT receipt is bound to this same board subject; this review independently reaches the same physical orientation judgment.

The top assembly is coherent and serviceable. D1/D2 cathode bands, U1/U2/U3 pin-one marks, MK1 `+ / −`, A+/A− testpoints, and the J1 contact map are visible. The functional text `NOT ETHERNET / NOT POE`, `J1 RJ45 1/3/7:12V 2/6/8:G 5:+ 4:-`, `PTC`, rail names, and wire-landing polarity is legible in the approved top/native and populated top views. Every fitted component has a visible F.SilkS reference at 0.60 mm text size. Hidden references are limited to H1–H4, MK1, and TP1–TP7; those are intentionally bare features and retain functional labels where a user probes or wires them.

The populated side views show no body collision or implausible seating. J1 has clearance to the adjacent SMD field, including U3 at (48.00, 34.75) mm. The four mounting holes are visually unobstructed. MK1 correctly renders as a bare two-pad landing rather than a microphone body. There are no bottom-side fitted SMD parts.

## Findings

- **P2 — evidence-presentation limitation, U3 at (48.00, 34.75) mm; next owner: render-pipeline maintainer.** `approved_native_bottom.png` (SHA-256 `1cea2146dda219ab757bbb57398dd402d89e220261d61dffdc8aa1dfce69440a`) visually exposes U3-like package geometry although the exact board says U3 and all five pads are front-side. This single orthographic image cannot support a bottom-absence claim by itself. The exact footprint/pad-side reopen, the five populated views, and the fresh full-scene bottom-oblique render (SHA-256 `d0654c5e29737d00a5306c89c28b9166f4939e413d83dd9784e91feb1db548ce`) show the underside free of U3 and all other SMD bodies. Regenerate or annotate the approved bottom view before reusing it as standalone evidence. This does not change the board design verdict.

## Limitations and order boundary

Unrouted nets are expected and were not graded. The review does not prove routing, copper-current adequacy, DRC closure after routing, component tolerances, solder fillets, connector seating, plug-boot clearance, latch operation, reaction load, enclosure stack, water/condensation behavior, cable continuity, audio performance, EMC, environmental suitability, JLC allocation, or manual J1 process capability. Manufacturer nominal CAD and model-registration pixels are not manufacturing tolerances.

The source explicitly retains cord routing, manufactured mating, latch/unmate operation, connector/enclosure stack, manual J1 soldering, MK1 strain relief and acoustic integration, live sourcing, and electrical/environmental first-article tests as owed. Therefore the order verdict remains DO-NOT-ORDER.
