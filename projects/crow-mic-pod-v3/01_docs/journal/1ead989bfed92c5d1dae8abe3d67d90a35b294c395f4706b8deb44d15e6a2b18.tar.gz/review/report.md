review_stage: pre-route
review_kind: pin
reviewer: actual fresh agent /root/rj45_pin_pod_interface_mountedframe1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: a44b769b1a5ad5fa959b476bd30f91a64aeaba9ad64d7868fa4e60ffbb62ee48
parts_sha256: adf3f7221a131e270f963fab153a2e2f56262932f1e272af9cbc0e4814d5c8a6
design_rules_sha256: 02c4ed58432368b92e3019a06bf20c137dbf90765af16c96c458790e88d54a9f

Coverage is limited to J1 and U3, one instance of each, in the supplied frozen native dossiers. This is no whole-board acceptance, routing review, mating-system review, or order authorization. The immutable hashes above are commissioned subject metadata, not independently reviewed whole-board conclusions.

The primary figure images were rendered and inspected before opening the native dossiers. Dossier author verification notes were not used as evidence. Only the supplied protocol, native dossiers, and exact SHA-selected primary PDFs informed engineering judgment. See independent-figure-derivation.md, measurements.json, and the archived actual rendered PNGs.

J1 VERDICT: PASS

Primary: Wurth_615008160221_rev001003.pdf, SHA-256 6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048; PDF page 1/6, Dimensions and Recommended Hole Pattern, revision 001.003 dated 2025-07-09. Page 2 states 8P8C. Page 1 images were inspected at 120 and 180 dpi.

View derivation: the recommended hole pattern is interpreted as the mounting/component-top pattern from the mechanical multiview, not as the adjacent underside view. In the upper-left underside drawing the contact tails are toward the lower/rear edge with the mouth above; in the top/body drawing below the mating-face view the mouth is below. The hole pattern likewise places the contact rows toward the rear/upper edge and shield slots toward the mouth/lower edge. This relation distinguishes the top pattern from the underside drawing; the pattern itself does not carry a literal TOP VIEW caption. The underside mechanical image would require reflection to become top view, and was not directly compared as though top. The actual numbered recommended hole pattern is compared by a single 180-degree rotation, without a mirror. J1 is explicitly front-mounted, so its native-to-component-top frame has no reflection.

The manufacturer pattern, using x=0 on its centerline and y=0 on the even row, gives pin 1 at (3.57,4.00), 2 at (2.55,0), 3 at (1.53,4), 4 at (0.51,0), 5 at (-0.51,4), 6 at (-1.53,0), 7 at (-2.55,4), 8 at (-3.57,0). Rotate 180 degrees about pin 1 and translate to its local origin: (x_local,y_local)=(3.57-x,4-y). Every dossier contact center agrees, residual below 1e-6 mm. Pin 1 becomes the upper-left contact; odds run left-to-right on y=0, evens on y=4. The manufacturer's zigzag numbering is not a perimeter sequence, so the dossier's computed CCW label and coarse W/S/N/E side classifications are not independent winding evidence. Individual identities and row offsets are decisive.

J1 pin 1 (CONTACT_1): expected distinct passive contact at (0,0); observed pad 1 at (0,0), 12V_POD.
J1 pin 2 (CONTACT_2): expected distinct passive contact at (1.02,4); observed pad 2 at (1.02,4), GND.
J1 pin 3 (CONTACT_3): expected distinct passive contact at (2.04,0); observed pad 3 at (2.04,0), 12V_POD.
J1 pin 4 (CONTACT_4): expected distinct passive contact at (3.06,4); observed pad 4 at (3.06,4), AUDIO_N.
J1 pin 5 (CONTACT_5): expected distinct passive contact at (4.08,0); observed pad 5 at (4.08,0), AUDIO_P.
J1 pin 6 (CONTACT_6): expected distinct passive contact at (5.10,4); observed pad 6 at (5.10,4), GND.
J1 pin 7 (CONTACT_7): expected distinct passive contact at (6.12,0); observed pad 7 at (6.12,0), 12V_POD.
J1 pin 8 (CONTACT_8): expected distinct passive contact at (7.14,4); observed pad 8 at (7.14,4), GND.
J1 pad 9 (SHIELD_S1): expected one separate shield leg at (10.97,-2.35) after the same rotation; observed pad 9 there on POD_SHIELD.
J1 pad 10 (SHIELD_S2): expected the other shield leg at (-3.83,-2.35); observed pad 10 there on POD_SHIELD.

The primary drawing does not number the two shield legs 9/10; those are artifact identities assigned to the two physically distinct legs, which remain separate. No fused alias is needed or inferred. Both shield pads have the same appropriate shield-net kind. The eight numbered contacts are passive and have no manufacturer-imposed power/data polarity; the observed rail, ground, and audio nets do not conflict with their intrinsic functions. This finding does not certify an external cable pinout, load-current budget, or audio-system polarity.

Measured census: 10 numbered native pad rows and 10 unique electrical/metal-terminal identities (8 contacts plus 2 shield legs), plus 2 dossier-reported unnumbered mechanical/paste pads, total 12 native pads reported. The latter two are omitted from the native position table and were not independently measured as locating holes. The primary depicts two locating holes; their drill dimensions/locations and fabrication clearances are outside this electrical pin-identity verdict. No exposed pad or collapsed physical pin identity exists in the reviewed map. Native-board coordinates equal local plus (45.50,25.86), within 1e-6 mm for all ten rows.

U3 VERDICT: PASS

Primary: tpd2e2u06.pdf, SHA-256 a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed; PDF page 3 section 5 DRL Package 5-Pin SOT Top View and Pin Functions; PDF pages 17 and 18 DRL0005A Package Outline and Example Board Layout (4220753/E 11/2024). The DCK pinout on the same page is not applicable to TPD2E2U06DRLR.

Expected top view: left side top-to-bottom pins 1,2,3; right side bottom-to-top 4,5. Pin 1 upper left, numbers wind CCW. Observed component-top coordinates and W/E sides match directly without any extra mirror: 1=(-0.7125,-0.5), 2=(-0.7125,0), 3=(-0.7125,+0.5), 4=(+0.7125,+0.5), 5=(+0.7125,-0.5). The explicitly back-mounted 180-degree instance has native x=49.07-local_x and native y=27.86+local_y; all five rows satisfy this conversion within 1e-6 mm. Its native front projection is appropriately mirrored relative to the mounted-side top view, and was not substituted for that view.

U3 pin 1 (NC): expected no internal connection; datasheet permits floating, GND, or VCC; observed distinct unconnected-(U3-NC1-Pad1) net.
U3 pin 2 (NC): same expectation; observed distinct unconnected-(U3-NC2-Pad2) net.
U3 pin 3 (IO1): expected protected data channel; observed AUDIO_P.
U3 pin 4 (GND): expected ground; observed GND.
U3 pin 5 (IO2): expected protected data channel; observed AUDIO_N.

Measured census: 5 native pad rows, 5 unique pad IDs and 5 physical lead identities, no omitted or fused leads, no EP required or observed. Primary DRL outline and example layout show five individual lands and no center thermal land. Dossier land-column separation 1.425 mm is 0.055 mm smaller than TI's 1.48 mm example; 0.68 x 0.35 mm pads also differ from the example 0.67 x 0.30 mm. The 0.5 mm row pitch, lead identity, sidedness and top-view winding agree; these small alternate land dimensions are not represented as an exact copy of TI's example or as a pin-map defect.

Instance symmetry: each commissioned part has one instance, so no same-part cross-instance comparison is available. Within U3, IO1 and IO2 both see the same kind of audio data net. J1's repeated power/ground contacts remain physically distinct; both shield legs remain distinct on POD_SHIELD. U3 IO1/AUDIO_P corresponds to J1 contact 5/AUDIO_P, and U3 IO2/AUDIO_N to J1 contact 4/AUDIO_N in the supplied net names.

No unresolved pin-review findings. SOUND applies only because both commissioned refs PASS. DO-NOT-ORDER remains mandatory for this pre-route limited review. Evidence archive retains the exact inspected figure images, native dossiers, primary input hashes, derivation, measurements, methods and raw engineering execution records. Full primary PDFs remain digest-bound in the frozen packet.
