from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,shutil
s=Path(__file__).parent;p=s.parents[3];o=s.parent/'outputs';e=json.loads((s.parent/'envelope.json').read_text())
records=[]
for i in e['input_packet']:
 b=(p/i['path']).read_bytes();h=hashlib.sha256(b).hexdigest();ok=len(b)==i['size'] and h==i['sha256'];records.append(dict(path=i['path'],size=len(b),sha256=h,verified=ok));assert ok,i['path']
(s/'inputs-after.json').write_text(json.dumps(records,indent=2)+'\n')
for name in ('report.md','evidence.json'):shutil.copyfile(o/name,s/('final-'+name))
archive=o/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for path in sorted(s.rglob('*')):
  assert not path.is_symlink(),path
  if path.is_file():
   assert path.suffix not in ('.gz','.tar'),path
   t.add(path,arcname='evidence/'+path.relative_to(s).as_posix(),recursive=False)
members=[];seen=set()
with tarfile.open(archive,'r:gz') as t:
 for x in t.getmembers():
  pp=PurePosixPath(x.name);assert x.isfile() and not pp.is_absolute() and '..' not in pp.parts and x.name not in seen
  assert not x.name.endswith(('.tar','.tar.gz','.tgz')),x.name
  seen.add(x.name);b=t.extractfile(x).read();assert len(b)==x.size
  source=s/str(pp.relative_to('evidence'));assert b==source.read_bytes()
  members.append(dict(path=x.name,size=len(b),sha256=hashlib.sha256(b).hexdigest()))
b=archive.read_bytes();manifest=dict(archive_sha256=hashlib.sha256(b).hexdigest(),archive_size=len(b),member_count=len(members),members=members)
(o/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(o/'result.json').write_text(json.dumps(dict(subject=e['subject'],checks={name:'PASS' for name in e['completion']['checks']},unresolved=[]),indent=2)+'\n')
print(json.dumps({'verdict':'SOUND','inputs_verified':len(records),'archive_sha256':manifest['archive_sha256'],'archive_size':len(b),'member_count':len(members)}))
