review_stage: pre-route
review_kind: pin
reviewer: rj45_pin_pod_diodes_s1m1 fresh independent agent
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: af9bb3c0dcf5e9be20239d725d10dd4d4c1bf95cc0b7518badc3e27bd6523938
parts_sha256: d0d0026dd67cbfaa98176799ea34ea3bfde384675d74d58d8cf8f0c88e41fd89
design_rules_sha256: 474e5d0a81baf576aefac32e9c60bce37704bb138961c16bf92573843b6409c4
completed_at: 2026-09-14T03:43:20.350047+00:00

# Fresh independent pin review — pod diodes

Coverage is deliberately limited to commissioned refs D1 and D2. This report does not accept the whole board or any unreviewed part group.

## D1 — S1M-E3/61T

VERDICT: PASS

- Measured native identities: 2 pads, 2 distinct physical terminals, 0 aliases or fused identities, 0 exposed pads. Mounted front on F.Cu. The two terminals are collinear, so winding is not established or required; comparison uses individual cathode/anode identity.
- Primary source: Vishay document 88711, SHA-256 `49c11fe1f333fda1bcdacc72754927dda4ee5bf977bf88d3c46eb1cd6ffe9277`, PDF page 1 cathode/anode circuit figure and `Polarity: color band denotes cathode end`, plus PDF page 3 SMA package-outline figure labeled `Cathode Band`.
- Expected: the banded physical terminal is cathode K, the opposite terminal is anode A, with two independent lands and no EP. In this series-feed topology, 12V_FUSED must enter A and VIN_PROTECTED must leave K.
- Observed: native pad 1 at component-top W is K on VIN_PROTECTED; native pad 2 at component-top E is A on 12V_FUSED. This matches the manufacturer polarity by rotation only; no mirror is needed.
- D1 pin 1 (K): expected banded cathode on downstream protected output vs dossier K on VIN_PROTECTED — match.
- D1 pin 2 (A): expected unbanded anode on upstream fused supply vs dossier A on 12V_FUSED — match.

## D2 — SMBJ15A

VERDICT: PASS

- Measured native identities: 2 pads, 2 distinct physical terminals, 0 aliases or fused identities, 0 exposed pads. Mounted front on F.Cu. The two terminals are collinear, so winding is not established or required; comparison uses individual cathode/anode identity.
- Primary source: Littelfuse SMBJ v4, SHA-256 `d7df155be4b1f612085401e8c946f065e284d65a0e7de22b9225a7b73946e51b`, PDF page 2 exact SMBJ15A electrical row; PDF page 5 physical-specification and DO-214AA dimension figures identifying the cathode band; PDF page 6 part-marking and tape figures identifying the cathode.
- Expected: for the exact unidirectional SMBJ15A, the banded terminal is cathode K and the opposite terminal is anode A. A positive-rail shunt clamp requires K on VIN_PROTECTED and A on GND.
- Observed: native pad 1 at component-top W is K on VIN_PROTECTED; native pad 2 at component-top E is A on GND. This matches the manufacturer polarity and the positive-rail clamp function by rotation only; no mirror is needed.
- D2 pin 1 (K): expected banded cathode on the protected positive rail vs dossier K on VIN_PROTECTED — match.
- D2 pin 2 (A): expected anode on ground for unidirectional positive clamping vs dossier A on GND — match.

## Symmetry and scope

There is one commissioned instance of each exact part, so same-part multi-instance symmetry is not applicable. Across the two different devices, the shared VIN_PROTECTED node consistently lands on each cathode while their anodes perform their distinct series-feed and shunt-clamp roles. All commissioned refs PASS; group verdict is SOUND. The order verdict remains DO-NOT-ORDER as required by the commission.
