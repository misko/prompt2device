import json,hashlib,tarfile,io,sys
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
S=Path(__file__).parent;R=S.parents[3];O=S.parent/'outputs'
def sha(b):return hashlib.sha256(b).hexdigest()
env=json.loads((S.parent/'envelope.json').read_text());ad=json.loads((S.parent/'admission.json').read_text())
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_execution import TaskEnvelope,verify_input_packet
te=TaskEnvelope.from_json((S.parent/'envelope.json').read_text());assert verify_input_packet(te,R)[0]
data={p.name:json.loads(p.read_text()) for p in sorted(S.glob('*.json')) if not p.name.endswith('-runtime.json')}
evidence={'schema':1,'review_stage':'pre-route','review_kind':'topology','reviewer_identity':'/root/carrier_rj45_native_pod_topology_mixedside1','context':'FRESH','created_at':datetime.now(timezone.utc).isoformat(),'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','subject':env['subject'],'envelope_sha256':ad['envelope_sha256'],'exact_hashes':data['hashes.json'],'methods':['Independent S-expression native component/pin graph parsing','Independent authored TSX pin assignment parsing','CircuitJSON complete multiset and connectivity-group parity','Frozen owning seven-hash algorithm','Current integrated 39 invariant and 12 tolerance checks','Current full checkpoint entry inventory and supplied-byte verification','Lossless all-page RGB equality and direct human image inspection','Current rating and fitted-population calculations'],'counts':{'frozen_inputs':293,'paired_paths':118,'unchanged_paired_paths':114,'changed_generated_files':4,'parts':34,'rule_yaml':16,'components':40,'nets':24,'pin_nodes':103,'tsx_connected_assignments':99,'intentional_nc_pins':4,'invariants':39,'tolerances':12,'fitted':33,'testpoint_exclusions':7,'mechanical_holes':2,'rendered_current_pages':4,'rendered_accepted_pages':4,'schematic_checkpoint_entries':7,'prelayout_checkpoint_entries':11,'prelayout_manifest_entries':311,'reopened_manifest_entries':133,'identity_only_manifest_entries':178},'findings':[],'scope_limits':['No placement/route/release/order/physical fit acceptance','Manufacturer rendered source coverage inherited only where exact compared primary/dossier bytes are unchanged','Carrier route.krt preimage/postimage absent; carrier-only path delta and population not independently measured by pod reviewer','Prior full checkpoint manifest absent; 178 external/omitted current manifest entries identity-only','SOURCE PASS/FULL INCOMPLETE with nine pod physical obligations retained','Public catalog with blank operator response is not allocated stock'],'measurements':data}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2,sort_keys=True)+'\n')
members=[]
for p in sorted(S.iterdir()):
 if p.is_file() and not p.is_symlink() and p.name not in {'pack.log','pack-runtime.json'} and not p.name.startswith('preflight'):
  members.append(('methods-and-measurements/'+p.name,p.read_bytes()))
members += [('report.md',(O/'report.md').read_bytes()),('evidence.json',(O/'evidence.json').read_bytes())]
with tarfile.open(O/'evidence.tar.gz','w:gz') as t:
 for name,b in members:
  info=tarfile.TarInfo(name);info.size=len(b);info.mtime=0;info.mode=0o644;t.addfile(info,io.BytesIO(b))
# Independent reopen of every regular member; closed paths, no links, duplicates or nested archives.
seen=set();rows=[]
with tarfile.open(O/'evidence.tar.gz','r:gz') as t:
 for m in t.getmembers():
  pp=PurePosixPath(m.name);assert m.isfile() and not pp.is_absolute() and '..' not in pp.parts and m.name not in seen and not m.name.endswith(('.tar','.tar.gz','.tgz'));seen.add(m.name)
  b=t.extractfile(m).read();assert len(b)==m.size
  rows.append({'path':m.name,'size':len(b),'sha256':sha(b)})
assert len(rows)==len(members)
expected={n:(len(b),sha(b)) for n,b in members};assert all(expected[x['path']]==(x['size'],x['sha256']) for x in rows)
archive=(O/'evidence.tar.gz').read_bytes();manifest={'schema':1,'archive_sha256':sha(archive),'archive_size':len(archive),'member_count':len(rows),'members':rows}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
(O/'result.json').write_text(json.dumps({'subject':env['subject'],'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]},indent=2,sort_keys=True)+'\n')
assert verify_input_packet(te,R)[0]
print(json.dumps({'output_files':sorted(p.name for p in O.iterdir()),'archive_sha256':manifest['archive_sha256'],'archive_size':len(archive),'reopened_members':len(rows),'frozen_inputs_verified':293},indent=2))
