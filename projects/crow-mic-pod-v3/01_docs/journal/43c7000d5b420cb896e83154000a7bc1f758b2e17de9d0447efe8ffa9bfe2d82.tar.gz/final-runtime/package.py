#!/usr/bin/python3
import hashlib,json,shutil,tarfile
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path('/tmp/rj45-pod-render-s1m1-vnhxxacr')
RUN=ROOT/'06_build/task_runs/rj45-pod-render-s1m1'
SCR=RUN/'scratch'; OUT=RUN/'outputs'; EVD=SCR/'evidence'
SUBJECT={'raw_sha256':'7a291ac12e793af0a9f3472a2cf16883c685ab7b8632577f36e671d28543ed5c','semantic_sha256':'c4f94ac98e7058139c6984c4ed8c59c6d2344c0383072ddb5718df1b84c2fd1d'}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def cp(src,rel):
    dst=EVD/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(ROOT/src if not Path(src).is_absolute() else src,dst)

env=json.loads((RUN/'envelope.json').read_text())
bad=[]
for item in env['input_packet']:
    p=ROOT/item['path']; b=p.read_bytes(); got=hashlib.sha256(b).hexdigest()
    if got!=item['sha256'] or len(b)!=item['size']: bad.append(item['path'])
after={'count':len(env['input_packet']),'bad':bad,'verdict':'PASS' if not bad else 'FAIL'}
(SCR/'input-verification-after.json').write_text(json.dumps(after,indent=2)+'\n')
if bad: raise SystemExit('stale inputs')

completed=datetime.now(timezone.utc).isoformat()
report=f'''review_stage: pre-route
review_kind: render
reviewer: rj45_pod_render_s1m1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: af9bb3c0dcf5e9be20239d725d10dd4d4c1bf95cc0b7518badc3e27bd6523938
design_rules_sha256: 474e5d0a81baf576aefac32e9c60bce37704bb138961c16bf92573843b6409c4
prepared_board_sha256: fad0f345909d3169bd2e371896b6b0491c4c981f98725303b5aa3fad9c292a81
completed_at: {completed}

# Fresh independent pod pre-route render review

The exact 60 x 40 mm pod placement is visually and natively coherent for pre-route acceptance. I found no actionable render, placement-visibility, polarity, connector-access, or side-population defect.

## Coverage and measurements

- Reopened 468/468 frozen envelope inputs before and after review; every size and SHA-256 matched.
- Reopened the native board and deterministic prepared r0 with pcbnew. Both have the required exact hashes, 44 footprints, and matching placement. The population census is 31 fitted SMD on F.Cu, zero fitted SMD on B.Cu, one fitted THT J1, seven bare testpoints, four bare mounting holes, and the off-board MK1 two-wire landing. The 32 fitted bodies have 32 resolved model declarations.
- Opened both full-board approved-native images, all five current populated orientation renders, and all five J1 focused views at their frozen identities. All 12 required images were inspected individually. Labels remain readable at useful board scale: CROW POD V3; NOT ETHERNET / NOT POE; 12V, PROT, 5V, VREF and GND test labels; the J1 pin-use line; and MK1 WIRE LANDING + / -.
- Independently rendered top and bottom from a byte-identical board copy through the supplied render_board.py under the shared bounded runtime. Both runs resolved 32/32 models. The independent top render agrees with the approved top population and polarity; the independent bottom render agrees with approved_native_bottom.png and shows no fitted SMD body beneath the board. Render hashes differ because the supplied wrapper used its own exact renderer environment/color preset, while geometry and side population agree.
- Reopened the complete aggregate registration bundle and the J1/U2 receipts and imagery. J1 registers 12/12 attachment centres with 0.024 mm centre delta, no measured Fab/courtyard overrun, and 0.968 mounted-side pixel fraction. U2 registers 13/13 pad centres with zero centre delta and no courtyard overrun. These checks support view geometry; they are not manufacturing-fit proof.
- Independently compared J1 native pad centres to Wurth drawing 615008160221 revision 001.003. The board reproduces the 2.04 mm signal pitch, 4.00 mm stagger, 13.70 mm guide-hole spacing, 14.80 mm shell spacing and 3.05 mm shell-to-guide offset. The current model and all five focused views consistently put the RJ45 mouth toward the north board edge. The receipt measures a [0,-1,0] access axis, 0.5 mm mating-plane edge offset, and 1.0 footprint/model alignment. The exterior/cable view is unobstructed; the rear and two profiles show the latch/keying and through-board pins consistently.
- D1 at (39.5,35.6) mm shows its cathode band at the pad-1/VIN_PROTECTED end, consistent with the Vishay S1M source statement that the color band denotes cathode. D2's cathode stripe is visible. U1, U2 and U3 pin-1 marks are visible and agree with their footprint marks. Mounting holes H1-H4 at (24,24), (76,24), (24,56), and (76,56) mm are visually open from both faces.

## Findings

No findings.

## Limitations

This is a pre-route render/placement judgment. Expected unrouted opens were not treated as defects. Nominal CAD models and registration images do not establish housing tolerance, solderability, stencil outcome, enclosure/panel fit, cable bend clearance, or production process qualification. J1 remains a manually soldered first-article part, MK1 remains an off-board wired capsule, and all order-facing qualification remains owed. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.
'''

evidence={
 'schema':1,'verdict':'SOUND','review_stage':'pre-route','review_kind':'render','reviewer':'rj45_pod_render_s1m1','context':'FRESH','order_verdict':'DO-NOT-ORDER','completed_at':completed,'subject':SUBJECT,
 'bindings':{'board_sha256':'af9bb3c0dcf5e9be20239d725d10dd4d4c1bf95cc0b7518badc3e27bd6523938','design_rules_sha256':'474e5d0a81baf576aefac32e9c60bce37704bb138961c16bf92573843b6409c4','prepared_board_sha256':'fad0f345909d3169bd2e371896b6b0491c4c981f98725303b5aa3fad9c292a81'},
 'methods':['SHA-256 and byte-count verification of all frozen envelope inputs before and after review','pcbnew reopen and independent footprint/pad/side/model census of native board and prepared r0','individual visual inspection of 12 required full-board/orientation/J1 views','reopen and inspect aggregate model-registration report, J1 and U2 receipts, bundles and registration imagery','two independent full-scene render_board.py runs from a byte-identical scratch copy under pipeline_runtime.run_stage','manufacturer drawing comparison for J1 hole geometry and Vishay D1 polarity mark'],
 'measured_counts':{'envelope_inputs_verified':468,'native_footprints':44,'prepared_footprints':44,'fitted_smd':31,'fitted_smd_front':31,'fitted_smd_bottom':0,'fitted_tht':1,'bare_testpoints':7,'bare_mounting_holes':4,'offboard_wire_landings':1,'declared_models_resolved':32,'required_images_inspected':12,'registration_images_inspected':8,'independent_renders':2,'registration_groups_reopened':2,'j1_registration_centres':'12/12','u2_registration_centres':'13/13'},
 'findings':[],
 'observations':[{'severity':'INFO','scope':'board','detail':'All fitted SMD are on F.Cu; approved and independent bottom renders show zero fitted SMD bodies.'},{'severity':'INFO','ref':'J1','coordinates_mm':[45.5,25.86],'detail':'North-edge mouth and [0,-1,0] access direction are consistent across all focused views; native hole pattern matches the Wurth drawing dimensions.'},{'severity':'INFO','ref':'D1','coordinates_mm':[39.5,35.6],'detail':'Visible cathode band agrees with pad 1 VIN_PROTECTED and the Vishay source marking convention.'}],
 'limitations':['Pre-route render scope only; unrouted opens expected.','Nominal model registration does not prove manufacturing fit or tolerance.','No solder, stencil, enclosure, panel, cable-bend, environmental, or production-process qualification.','FIRST-ARTICLE-ONLY / DO-NOT-ORDER.']
}
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'report.md').write_text(report)
(OUT/'evidence.json').write_text(json.dumps(evidence,indent=2,sort_keys=True)+'\n')

# Preserve the actual methods, raw measurements, runtime, reviewed identities and cited source evidence.
for name in ['analyze.py','run_analysis.py','analysis.log','analysis-runtime.json','board-measurements.json','image-identities.json','required-contact-sheet.jpg','registration-contact-sheet.jpg','input-verification-before.json','input-verification-after.json','run_docs.py','doc-runtime.json','j1-datasheet.txt','d1-datasheet.txt','u2-datasheet.txt','j1-page1.png','run_analysis.py','render_independent.py','independent-render-runtime.json','independent-top.log','independent-bottom.log','independent-top.png','independent-bottom.png']:
    if (SCR/name).exists(): cp(SCR/name,'methods/'+name)
for rel in [
 'project/06_build/pre_route/approved_native_top.png','project/06_build/pre_route/approved_native_bottom.png',
 'project/06_build/pre_route/orientation/renders/populated_top.png','project/06_build/pre_route/orientation/renders/populated_front.png','project/06_build/pre_route/orientation/renders/populated_back.png','project/06_build/pre_route/orientation/renders/populated_left.png','project/06_build/pre_route/orientation/renders/populated_right.png',
 'project/06_build/pre_route/orientation/views/J1_top.png','project/06_build/pre_route/orientation/views/J1_inside.png','project/06_build/pre_route/orientation/views/J1_outside.png','project/06_build/pre_route/orientation/views/J1_profile_a.png','project/06_build/pre_route/orientation/views/J1_profile_b.png',
 'project/06_build/pre_route/model_registration.md','project/06_build/pre_route/model_registration.stage.json','project/06_build/pre_route/model_registration_bundle/bundle.json','project/06_build/pre_route/model_registration_bundle/model_registration_index.json',
 'project/06_build/pre_route/orientation/orientation_receipt.json','project/06_build/pre_route/orientation/orientation_review.md','project/08_reviews/connector_orientation.yaml',
 'project/06_build/pre_route/native_registration/j1_wurth_615008160221_official_step/model_registration_receipt.json','project/06_build/pre_route/native_registration/j1_wurth_615008160221_official_step/native_model_registration.md','project/06_build/pre_route/native_registration/j1_wurth_615008160221_official_step/native_top.png','project/06_build/pre_route/native_registration/j1_wurth_615008160221_official_step/native_overlay_J1.png','project/06_build/pre_route/native_registration/j1_wurth_615008160221_official_step/native_top_registration_overlay.png','project/06_build/pre_route/native_registration/j1_wurth_615008160221_official_step/native_side_front.png','project/06_build/pre_route/native_registration/j1_wurth_615008160221_official_step/native_side_right.png',
 'project/06_build/pre_route/native_registration/u2_ti_dgn0008g_official_step/model_registration_receipt.json','project/06_build/pre_route/native_registration/u2_ti_dgn0008g_official_step/native_model_registration.md','project/06_build/pre_route/native_registration/u2_ti_dgn0008g_official_step/native_top.png','project/06_build/pre_route/native_registration/u2_ti_dgn0008g_official_step/native_overlay_U2.png','project/06_build/pre_route/native_registration/u2_ti_dgn0008g_official_step/native_top_registration_overlay.png',
 'root-render/pod-s1m-resolved-top-render-command.json','root-render/pod-s1m-resolved-top-render-runtime.json','root-render/pod-s1m-resolved-top-render.log','root-render/pod-s1m-resolved-bottom-render-command.json','root-render/pod-s1m-resolved-bottom-render-runtime.json','root-render/pod-s1m-resolved-bottom-render.log',
 'project/02_parts/615008160221/part.yaml','project/02_parts/615008160221/primary-source-record.md','project/02_parts/S1M-E3-61T/part.yaml','project/03_src/rules/assembly.yaml']:
    cp(rel,'reviewed/'+rel)
cp(OUT/'report.md','report.md'); cp(OUT/'evidence.json','evidence.json')

members=[]
for p in sorted(x for x in EVD.rglob('*') if x.is_file()):
    rel=p.relative_to(EVD).as_posix()
    if '..' in Path(rel).parts or p.is_symlink(): raise SystemExit('unsafe member')
    members.append({'path':rel,'size':p.stat().st_size,'sha256':sha(p)})
archive=OUT/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tf:
    for row in members: tf.add(EVD/row['path'],arcname=row['path'],recursive=False)
seen=[]
with tarfile.open(archive,'r:gz') as tf:
    names=[]
    for m in tf.getmembers():
        if not m.isfile() or m.issym() or m.islnk() or m.name.startswith('/') or '..' in Path(m.name).parts: raise SystemExit('unsafe archive')
        if m.name in names: raise SystemExit('duplicate archive member')
        names.append(m.name); b=tf.extractfile(m).read(); seen.append({'path':m.name,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
if seen!=members: raise SystemExit('archive reopen mismatch')
manifest={'schema':1,'archive_sha256':sha(archive),'archive_size':archive.stat().st_size,'member_count':len(members),'members':members}
(OUT/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
(OUT/'result.json').write_text(json.dumps({'subject':SUBJECT,'checks':{'evidence-complete':'PASS','inputs-verified':'PASS','review-complete':'PASS'},'unresolved':[]},indent=2,sort_keys=True)+'\n')
