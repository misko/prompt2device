from pathlib import Path
import sys,json,copy,hashlib
N=Path(__file__).parent;D=N/'pod-probe-bound-addendum';Q=Path('/tmp/candidate4-root-full-qualification')
sys.path.insert(0,str(Q/'skills/kicad-pcb/scripts'));import adr_bound_provenance as gate
blocks,errors=gate.parse_blocks((D/'after.md').read_text(),'pod0009');assert not errors and len(blocks)==1
results={}
for name,delta in [('positive',{}),('wrong_published_limit',{'value':5.1}),('wrong_named_endpoint',{'command':blocks[0]['command'].replace("=='R13.2'","=='R12.2'")})]:
 b=copy.deepcopy(blocks[0]);b.update(delta);failures,grade,notes=gate.grade_bound(b,Q,'pod0009',regen=True,timeout=30)
 results[name]={'failures':failures,'grade':grade,'notes':notes}
assert results['positive']['failures']==[] and results['positive']['grade']=='ESTIMATED'
assert any('B-REGEN' in x for x in results['wrong_published_limit']['failures'])
assert results['wrong_named_endpoint']['grade']=='UNVERIFIED'
assert (D/'after.md').read_bytes().startswith((D/'before.md').read_bytes())
(D/'controls.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
