from pathlib import Path
import json,hashlib,shutil,subprocess
N=Path(__file__).parent;Q=Path('/tmp/candidate4-root-full-qualification')
S=Path('/tmp/rj45-coherent-top-only-source1-dz0edoky/06_build/task_runs/rj45-coherent-top-only-source1/scratch')
assert subprocess.check_output(['git','status','--porcelain'],cwd=Q)==b''
rows=json.loads((S/'source-pre-post-manifest.json').read_text());copied=[]
for row in rows:
 dst=Q/row['path'];before=row['before'];after=row['after']
 assert not dst.exists() if before is None else hashlib.sha256(dst.read_bytes()).hexdigest()==before['sha256']
 src=Path(after['path']);assert hashlib.sha256(src.read_bytes()).hexdigest()==after['sha256']
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);copied.append({'path':row['path'],'sha256':after['sha256']})
follow=json.loads((S/'nongeometry-followup/manifest.json').read_text())
for row in follow['files']:
 rel='projects/crow-audio-carrier-v1/'+row['path'];dst=Q/rel
 assert hashlib.sha256(dst.read_bytes()).hexdigest()==row['before_sha256']
 src=Path(row['proposal_path']);assert hashlib.sha256(src.read_bytes()).hexdigest()==row['after_sha256']
 shutil.copyfile(src,dst);copied.append({'path':rel,'sha256':row['after_sha256']})
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 for rel in ['04_kicad','06_build/netlists']:
  src=S/'work/projects'/slug/rel;dst=Q/'projects'/slug/rel
  shutil.copytree(src,dst,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
manifest={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=Q,text=True).strip(),'purpose':'Complete detached qualification checkout; exact30 proposed source files and same saved candidate4 native copies, no regeneration or live adoption.','source':copied}
(N/'candidate4-full-qualification-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'source_files':len(copied),'worktree':str(Q),'native_generation':False}))
