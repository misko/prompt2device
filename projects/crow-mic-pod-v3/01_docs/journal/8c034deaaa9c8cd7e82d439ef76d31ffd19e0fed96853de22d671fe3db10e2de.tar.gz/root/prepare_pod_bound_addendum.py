from pathlib import Path
import json,hashlib
N=Path(__file__).parent;Q=Path('/tmp/candidate4-root-full-qualification')
rel='projects/crow-mic-pod-v3/01_docs/decisions/0009-proposed-top-side-rj45-protection-geometry.md'
P=Q/rel;before=P.read_bytes();assert b'<!-- bound' not in before
addition='''

## Probe-route budget provenance

The retained 5 mm limit is an engineering routing constraint from
`03_src/rules/critical_paths.yaml`, not a manufacturer rating or a measured
completed route. The command below independently reopens the exact named
F.Cu rule so this document cannot silently change its configured ceiling.
The final `check_realized_routes.py` gate must still measure the actual
R13.2-to-TP6.1 copper path; the prepared candidate does not complete it.

<!-- bound: POD_AUDIO_N_PROBE_ROUTE -->
```yaml
id: POD_AUDIO_N_PROBE_ROUTE
claim: Retained engineering maximum for the final R13.2-to-TP6.1 F.Cu probe branch
relation: "<="
value: 5.0
unit: mm
corner: nominal
grade: ESTIMATED
why_not_rerunnable: >-
  The configured ceiling is reproducible, but no manufacturer or physical
  performance derivation establishes five millimetres as a sufficient limit.
  The completed route is still absent and must pass the owning realized-path
  gate. Source consistency does not establish routed length or signal integrity.
command: >-
  /usr/bin/python3 -B -c "import yaml; p='projects/crow-mic-pod-v3/03_src/rules/critical_paths.yaml'; d=yaml.safe_load(open(p)); r=[x for x in d['paths'] if x.get('from')=='R13.2' and x.get('to')=='TP6.1']; assert len(r)==1 and r[0]['layer']=='F.Cu'; print(r[0]['max_length_mm'])"
governs:
  budget: "<= 5.0"
  unit: mm
  note: >-
    Final native copper length is graded by check_realized_routes.py using
    this exact critical_paths.yaml entry. No completed-path evaluation is
    claimed by this source budget record.
standard_value:
  explicit: [5.0]
  series_why: >-
    Routing length is continuous geometry, not an E-series component.
    The singleton records only the retained project limit and makes no
    claim about physical sufficiency or a selected component value.
chosen: 5.0
requires:
  - projects/crow-mic-pod-v3/03_src/rules/critical_paths.yaml
```
'''
after=before+addition.encode();D=N/'pod-probe-bound-addendum';D.mkdir(exist_ok=False)
(D/'before.md').write_bytes(before);(D/'after.md').write_bytes(after)
manifest={'path':rel,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'source_rule_sha256':hashlib.sha256((Q/'projects/crow-mic-pod-v3/03_src/rules/critical_paths.yaml').read_bytes()).hexdigest(),'scope':'Append provenance only. Exact prior ADR text, critical path source,5mm ceiling, all engineering source and native bytes remain unchanged. Independently reviewed addendum required before adoption.'}
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');P.write_bytes(after);print(json.dumps(manifest))
