from pathlib import Path
from collections import Counter
import json,hashlib,sys
import pcbnew
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
slug=sys.argv[1];P=R/'projects'/slug;old=N/'mixedside1-native-before'/slug
bp=next((P/'04_kicad').glob('*.kicad_pcb'));before=bp.read_bytes();assert before==(old/bp.relative_to(P)).read_bytes()
gp=P/'06_build/drc/gate.json';g=json.loads(gp.read_text());prior=json.loads((old/'06_build/drc/gate.json').read_text())
assert not g['violations'] and not g['schematic_parity']
key=lambda x:json.dumps(x,sort_keys=True)
assert Counter(map(key,g['unconnected_items']))==Counter(map(key,prior['unconnected_items']))
b=pcbnew.LoadBoard(str(bp));pads={p.m_Uuid.AsString():p for f in b.GetFootprints() for p in f.Pads()};zones={z.m_Uuid.AsString():z for z in b.Zones()};tracks={x.m_Uuid.AsString():x for x in b.GetTracks()};objects={**pads,**zones,**tracks};rows=[]
for idx,row in enumerate(g['unconnected_items'],1):
 ends=[]
 for end in row['items']:
  uid=end['uuid'];o=objects[uid];net=o.GetNetname();assert '['+net+']' in end['description'];pos={'x':o.GetPosition().x/1e6,'y':o.GetPosition().y/1e6}
  if uid not in zones:assert all(abs(pos[k]-end['pos'][k])<=.000002 for k in pos)
  fp=o.GetParentFootprint() if uid in pads else None
  ends.append({'uuid':uid,'net':net,'kind':'pad' if uid in pads else 'zone' if uid in zones else o.GetClass(),'ref':fp.GetReference() if fp else None,'pin':o.GetNumber() if fp else None,'native_position_mm':pos,'reported_position_mm':end['pos']})
 assert len({x['net'] for x in ends})==1
 rows.append({'index':idx,'raw':row,'endpoints':ends,'cause':'Unrouted edge between these exact independently verified same-net endpoints on unchanged canonical placement; deterministic prepared r0 is a separate artifact.','disposition':'OPEN: fresh routing and route acceptance owed.'})
assert len(rows)==(58 if 'pod' in slug else 499);assert all(x.GetClass()=='PCB_VIA' for x in tracks.values());assert bp.read_bytes()==before
res={'project':slug,'board_sha256':hashlib.sha256(before).hexdigest(),'gate_sha256':hashlib.sha256(gp.read_bytes()).hexdigest(),'counts':{'violations':0,'unconnected':len(rows),'parity':0,'native_endpoints':sum(len(x['endpoints']) for x in rows),'native_pad_via_positions':sum(x['kind']!='zone' for r in rows for x in r['endpoints']),'footprints':len(list(b.GetFootprints())),'tracks':0,'vias':len(tracks)},'method':'Fresh severity-all/refill/parity report compared by complete raw-row multiset to exact preserved current report; every native UUID/net/ref/pin and pad/via coordinate independently reopened. Zone native anchors and reported attachment positions retained separately. Board bytes unchanged.','rows':rows,'limits':'Current unrouted measurement, not route acceptance. User-approved connector subject is separately preserved; no approval restamp.'}
(N/(slug+'-routing-handoff-native-classification.json')).write_text(json.dumps(res,indent=2)+'\n');print(slug,json.dumps(res['counts']))
