# Connector orientation review

Current review: carrier subject `3388c531a98d6bab`; pod subject `5e2631d88395ccb9`. These replace the deferred earlier views.

Please confirm the visible connector mouths, mounting on the top of the PCB, latch/keying, and outward cable approach. Green arrows show intended cable approach. This confirms orientation only; routing, physical service/tolerance qualification and release acceptance remain separate.

Carrier RJ45 J1–J4 face north; J5–J8 face south. Carrier power J9 faces west. Pod RJ45 J1 faces north. Each repeated carrier RJ45 row shares an exact model/pose representative; every instance was machine-checked.

Carrier elevated rear views show upper rear shells; nearby film capacitors obscure some lower rear areas. Flag any required feature you cannot judge.

## Carrier

Subject: `3388c531a98d6babf6a144e24849dd78224f6a86054d98d71c7dddc5172555f8`

### Carrier J1

![Carrier J1: Top and cable arrow](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J1_top.png)

![Carrier J1: Mouth and keying](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J1_outside.png)

![Carrier J1: Rear](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J1_inside.png)

### Carrier J5

![Carrier J5: Top and cable arrow](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J5_top.png)

![Carrier J5: Mouth and keying](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J5_outside.png)

![Carrier J5: Rear](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J5_inside.png)

### Carrier J9

![Carrier J9: Top and cable arrow](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J9_top.png)

![Carrier J9: Mouth and keying](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J9_outside.png)

![Carrier J9: Rear](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J9_inside.png)

![Carrier J9: Side profile A](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J9_profile_a.png)

![Carrier J9: Side profile B](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-audio-carrier-v1/06_build/pre_route/orientation/views/J9_profile_b.png)

## Pod

Subject: `5e2631d88395ccb907028bd6dfbd4d66deb2c38ba9b11fa20bd0b500d19e591f`

### Pod J1

![Pod J1: Top and cable arrow](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-mic-pod-v3/06_build/pre_route/orientation/views/J1_top.png)

![Pod J1: Mouth and keying](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-mic-pod-v3/06_build/pre_route/orientation/views/J1_outside.png)

![Pod J1: Rear](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-mic-pod-v3/06_build/pre_route/orientation/views/J1_inside.png)

![Pod J1: Side profile A](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-mic-pod-v3/06_build/pre_route/orientation/views/J1_profile_a.png)

![Pod J1: Side profile B](/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-mic-pod-v3/06_build/pre_route/orientation/views/J1_profile_b.png)

The PCB design skill requires explicit human confirmation at this gate. A machine PASS or an earlier stage approval does not provide it.
