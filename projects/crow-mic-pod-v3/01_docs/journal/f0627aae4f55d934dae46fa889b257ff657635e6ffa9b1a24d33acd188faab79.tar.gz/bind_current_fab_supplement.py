from pathlib import Path
from collections import Counter
import hashlib,json,re,tarfile,sys
import pcbnew
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent
D=Path('/tmp/rj45-jack-fab-source-review-akx73co4');O=D/'06_build/task_runs/rj45-jack-fab-source-review/outputs'
close=json.loads((N/'rj45-jack-fab-source-review-closeout-summary.json').read_text());assert close['delivery_status']=='PASS';assert hashlib.sha256(Path(close['archive']).read_bytes()).hexdigest()==close['sha256']
manifest=json.loads((O/'evidence-manifest.json').read_text());raw=(O/'evidence.tar.gz').read_bytes();assert hashlib.sha256(raw).hexdigest()==manifest['archive_sha256'];index={x['path']:x for x in manifest['members']}
with tarfile.open(O/'evidence.tar.gz','r:gz') as t:
 data={}
 for name in ['geometry.json','native-measure.json']:
  b=t.extractfile(name).read();assert len(b)==index[name]['size'] and hashlib.sha256(b).hexdigest()==index[name]['sha256'];data[name]=json.loads(b)
g=data['geometry.json'];native=data['native-measure.json'];assert len(g['all9_instances'])==9 and native['matched_solids']==99

def mm(p):return [p.x/1e6,p.y/1e6]
def pad(p):return {'n':p.GetNumber(),'at':mm(p.GetPosition()),'size':mm(p.GetSize()),'drill':mm(p.GetDrillSize()),'angle':p.GetOrientationDegrees(),'shape':int(p.GetShape()),'attribute':int(p.GetAttribute()),'drill_shape':int(p.GetDrillShape()),'layers':p.GetLayerSet().FmtBin(),'net':p.GetNetname()}
def pose(m):return [[getattr(m,k).x,getattr(m,k).y,getattr(m,k).z] for k in ('m_Scale','m_Offset','m_Rotation')]
def serialized(item):
 f=pcbnew.STRING_FORMATTER();w=pcbnew.PCB_IO_KICAD_SEXPR();w.SetOutputFormatter(f);w.Format(item)
 return re.sub(r'\((?:uuid|tstamp)\s+"?[-a-fA-F0-9]+"?\)', '(uuid ID)',f.GetString())
def shapes(fp):return Counter(serialized(x) for x in fp.GraphicalItems() if x.GetClass()=='PCB_SHAPE')
rows=[];boards={}
for slug in ['crow-audio-carrier-v1','crow-mic-pod-v3']:
 P=R/'projects'/slug;bp=next((P/'04_kicad').glob('*.kicad_pcb'));before=bp.read_bytes();board=pcbnew.LoadBoard(str(bp));receipt=json.loads((P/'06_build/pre_route/orientation/orientation_receipt.json').read_text())
 assert hashlib.sha256(before).hexdigest()==receipt['observed_board_sha256']
 fpfile=next((P/'03_src/lib').glob('*.pretty/Wurth_615008160221_RJ45.kicad_mod'));assert hashlib.sha256(fpfile.read_bytes()).hexdigest()=='c8286c258474bde37022ef16730c7976e488d5fd7312699870ed54ee0dccc7d6'
 source=pcbnew.FootprintLoad(str(fpfile.parent),fpfile.stem);source.SetPosition(pcbnew.VECTOR2I(0,0));source.SetOrientationDegrees(0)
 expected=[x for x in g['all9_instances'] if x['project']==slug]
 actual=[f for f in board.GetFootprints() if 'Wurth_615008160221_RJ45'==str(f.GetFPID().GetLibItemName())];assert {f.GetReference() for f in actual}=={x['ref'] for x in expected}
 for row in expected:
  fp=board.FindFootprintByReference(row['ref']);assert mm(fp.GetPosition())==row['board_position'] and fp.GetOrientationDegrees()==row['board_angle'];assert fp.GetLayer()==pcbnew.F_Cu
  n=pcbnew.Cast_to_FOOTPRINT(fp.Duplicate(False));n.SetOrientationDegrees(0);n.SetPosition(pcbnew.VECTOR2I(0,0))
  assert sorted([pad(p) for p in n.Pads()],key=str)==sorted(row['normalized_pads'],key=str),row['ref']
  assert [pose(m) for m in n.Models()]==row['models'];assert shapes(n)==shapes(source),('shapes',slug,row['ref'])
  scene=next(x for x in receipt['scene']['placements'] if x['ref']==row['ref']);assert len(scene['models'])==1
  model=scene['models'][0];assert model['sha256']=='3f902b89d4bd756b121be056782deff312efb127c9c48f2c798ebd6db0e59f49';assert hashlib.sha256(Path(model['resolved']).read_bytes()).hexdigest()==model['sha256']
  assert min(row['margins'])>0
  rows.append({'project':slug,'ref':row['ref'],'native_position_mm':mm(fp.GetPosition()),'angle':fp.GetOrientationDegrees(),'side':fp.GetLayerName(),'pad_model_pose_and_source_shapes_equal':True,'model_sha256':model['sha256'],'full_local_extent':row['full_local_model_extent'],'courtyard':row['courtyard'],'nominal_margins_mm':row['margins']})
 assert bp.read_bytes()==before
 boards[slug]={'board_sha256':hashlib.sha256(before).hexdigest(),'orientation_subject_sha256':receipt['subject_sha256'],'board_thickness_mm':board.GetDesignSettings().GetBoardThickness()/1e6}
result={'status':'PASS','method':'Reopen independently accepted native geometry/99-solid supplement from its verified archive; match every current native jack position/angle/side, normalized pad/drill/net array and model pose; complete graphical shape multiset equals the accepted c828 source footprint; resolve exact unchanged model hash through current scene receipt. Reuses unchanged source-relative geometry evidence; not a new BRep export or physical qualification.','source_review_archive':close['sha256'],'inner_archive_sha256':manifest['archive_sha256'],'source_geometry_sha256':index['geometry.json']['sha256'],'native_measure_sha256':index['native-measure.json']['sha256'],'instances':rows,'boards':boards,'coverage':{'instances':len(rows),'inherited_native_solids':native['matched_solids'],'inherited_Fab_paths':len(g['fab_paths'])},'limits':'Ordinary current P-MODEL-REG remains separately required and passed. Nominal right-tip margin0.001919mm is not a manufacturing tolerance; native volume discrepancy and declared sampling blind spots remain. No physical service, mating-force, solder-access, routing or release acceptance.'}
assert len(rows)==9
(N/'fabfeatures1-current-supplement-binding.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS9/9 current native jack instances bound to accepted18path/99solid nominal supplement')
