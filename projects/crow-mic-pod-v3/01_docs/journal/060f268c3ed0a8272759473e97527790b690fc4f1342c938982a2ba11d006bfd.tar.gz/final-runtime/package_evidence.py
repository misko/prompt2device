from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,io,sys
s=Path(__file__).parent;o=s.parent/"outputs";archive=o/"evidence.tar.gz"
files=[]
for p in sorted(s.rglob("*")):
 if p.is_symlink():raise RuntimeError("Symlink refused "+str(p))
 if p.is_file():
  if p.name.startswith("package-") and (p.name.endswith(".log") or p.name.endswith(".runtime.json")):continue
  if p.name.startswith("preflight-final"):continue
  if p.suffix in [".gz",".tar"]:raise RuntimeError("Recursive archive refused")
  files.append(("scratch/"+p.relative_to(s).as_posix(),p))
files += [("report.md",o/"report.md"),("evidence.json",o/"evidence.json"),("result.json",o/"result.json")]
records=[]
with tarfile.open(archive,"w:gz") as t:
 for name,p in files:
  data=p.read_bytes();q=tarfile.TarInfo(name);q.size=len(data);q.mode=0o644;q.mtime=0;t.addfile(q,io.BytesIO(data));records.append({"path":name,"size":len(data),"sha256":hashlib.sha256(data).hexdigest()})
seen=set()
with tarfile.open(archive,"r:gz") as t:
 members=t.getmembers();assert len(members)==len(records)
 for m,row in zip(members,records):
  pp=PurePosixPath(m.name);assert m.isfile() and not m.issym() and not m.islnk() and not pp.is_absolute() and ".." not in pp.parts and m.name not in seen;seen.add(m.name)
  data=t.extractfile(m).read();assert m.name==row["path"] and len(data)==row["size"] and hashlib.sha256(data).hexdigest()==row["sha256"]
a=archive.read_bytes();manifest={"archive_sha256":hashlib.sha256(a).hexdigest(),"archive_size":len(a),"member_count":len(records),"members":records};(o/"evidence-manifest.json").write_text(json.dumps(manifest,indent=2));print(json.dumps({k:v for k,v in manifest.items() if k!="members"}));print("Every regular archive member reopened and verified; no links, traversal, duplicate or recursive archive")
