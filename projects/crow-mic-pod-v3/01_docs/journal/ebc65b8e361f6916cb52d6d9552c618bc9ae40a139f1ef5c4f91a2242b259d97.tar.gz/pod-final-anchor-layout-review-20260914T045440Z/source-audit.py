import json,yaml,pcbnew,hashlib
from pathlib import Path
from collections import Counter
root=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');p=root/'projects/crow-mic-pod-v3';route=yaml.safe_load((p/'03_src/route.yaml').read_text());b=pcbnew.LoadBoard(str(p/'06_build/route/r0.kicad_pcb'))
def pos(v):return [round(x,6) for x in pcbnew.ToMM(v)]
def via(net,at):return next(t for t in b.GetTracks() if isinstance(t,pcbnew.PCB_VIA) and t.GetNetname()==net and pos(t.GetPosition())==at)
def pad(ref,num):return next(x for x in b.FindFootprintByReference(ref).Pads() if x.GetNumber()==str(num))
def obs(layer,net):
 out=[]
 for f in b.GetFootprints():
  for x in f.Pads():
   if x.GetNetname()!=net and x.IsOnLayer(layer):out.append((f'{f.GetReference()}.{x.GetNumber()} {x.GetNetname()}',x.GetEffectiveShape(layer)))
 for t in b.GetTracks():
  if t.GetNetname()==net:continue
  if isinstance(t,pcbnew.PCB_VIA) and t.IsOnLayer(layer):out.append((f'via {t.GetNetname()} {pos(t.GetPosition())}',t.GetEffectiveShape(layer)))
  elif not isinstance(t,pcbnew.PCB_VIA) and t.GetLayer()==layer:out.append((f'track {t.GetNetname()}',t.GetEffectiveShape(layer)))
 return out
def nearest(sh,items):return min((sh.GetClearance(x)/1e6,n) for n,x in items)
anchors=[]
for net,at,ref,num in [('AUDIO_P',[49.6,34.25],'U3',3),('AUDIO_N',[47.288,36.25],'U3',5),('AUDIO_N',[62.913,34.7],'R13',2),('OUTP_DRV',[55.,36.],'R12',1),('MIC_BIAS',[66.,39.],'R3',2)]:
 v=via(net,at);q=pad(ref,num);dist=((v.GetPosition().x-q.GetPosition().x)**2+(v.GetPosition().y-q.GetPosition().y)**2)**.5/1e6
 anchors.append({'net':net,'via_mm':at,'source_pad':f'{ref}.{num}','pad_center_mm':pos(q.GetPosition()),'center_distance_mm':dist,
 'via_size_mm':v.GetWidth(pcbnew.F_Cu)/1e6,'drill_mm':v.GetDrillValue()/1e6,
 'nearest_foreign_FCu_mm':nearest(v.GetEffectiveShape(pcbnew.F_Cu),obs(pcbnew.F_Cu,net)),
 'nearest_foreign_BCu_mm':nearest(v.GetEffectiveShape(pcbnew.B_Cu),obs(pcbnew.B_Cu,net))})
ed=route['stitch']['canonicalize_chains']['edits'];passes=route['stitch']['passes']
res={'anchors':anchors,'pre_out_stub_absent':not any(not isinstance(t,pcbnew.PCB_VIA) and t.GetNetname()=='PRE_OUT' and {tuple(pos(t.GetStart())),tuple(pos(t.GetEnd()))}=={(55.025,52.81),(53.5,52.81)} for t in b.GetTracks()),
'canonicalization':{'edit_count':len(ed),'remove_count':sum(len(x['remove']) for x in ed),'add_count':sum(len(x['add']) for x in ed),'nets':[x['net'] for x in ed],'all_fcu':all(x['layer']=='F.Cu' for x in ed)},
'pass_order':passes,'janitor_index':passes.index('via_janitor'),'canonical_index':passes.index('canonicalize_chains'),'janitor_immediately_after_canonical':passes.index('via_janitor')==passes.index('canonicalize_chains')+1,
'splitter_sha256':hashlib.sha256((root/'skills/kicad-pcb/scripts/route_and_stitch_generic.py').read_bytes()).hexdigest(),
'parts_sha256':hashlib.sha256(b''.join(x.relative_to(p).as_posix().encode()+b'\0'+x.read_bytes()+b'\0' for x in sorted((p/'02_parts').glob('*/part.yaml')))).hexdigest()}
Path('/tmp/pod-final-anchor-layout-review-20260914T045440Z/source-audit.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n');print(json.dumps(res,indent=2,sort_keys=True))
