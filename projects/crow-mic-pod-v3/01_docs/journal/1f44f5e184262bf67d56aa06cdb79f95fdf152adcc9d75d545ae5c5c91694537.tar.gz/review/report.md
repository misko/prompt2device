review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_pod_analog_toponly1
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: 0131d5756ed1bb390280558718af114d5d32842d909cf5a73d67330804a39101
parts_sha256: 24c1d667aa95629d5dabb75f306a3b1f1e2b4293e40230d6c448d4e53da5a287
design_rules_sha256: 7f661d2ef79dd9004962238eac953f194ac18722cd344d1c91443cab29402ca9

Coverage is limited to the commissioned U1/U2 pin review. Both references PASS. This is no whole-board acceptance or ordering authorization; the three header digests are immutable subject bindings, not independently reviewed board conclusions.

U1 — VERDICT: PASS
Primary: TI SBOS855E, opa1679.pdf SHA-256 4072daad4ebc4ec9a74ba6547d721b05db8d0cfc12924bda79e828271aeaec3b. PDF page 5 Figure 5-5 and Pin Functions: OPA1679; PDF pages 44–45 D0014A outline and example board layout (4220718/A).
Manufacturer Figure 5-5 explicitly says TOP VIEW: pin 1 upper left, 1–7 down the left, 8–14 up the right, CCW. D/SOIC has 14 leads and no EP; the adjacent QFN figure and its thermal-pad requirement do not apply. Observed: front F.Cu, rotation 0; component-top coordinates have exactly that arrangement without reflection. Pin 1 is (-2.475,-3.810) mm. Fourteen unique numbered native pads preserve all fourteen physical identities, seven per side, pitch 1.27 mm; no aliases/collapsed identities or EP. Signed area is -37.719 mm² with +y down, confirming CCW. Every native position agrees with the supplied translation/rotation (maximum error 0 mm). Dossier N/S side labels for extreme leads are radial labels; the measured x coordinates unambiguously put seven leads in each left/right column. No mirror correction was used.
The D0014A manufacturer example has 1.55 x 0.6 mm lands and 5.4 mm row-center spacing; the dossier uses 1.95 x 0.6 mm and 4.95 mm respectively. These preserve pin identities/pitch and span the package leads; this pin review does not require identical example-land dimensions or grade solder-joint optimization.
U1 pin 1 (OUT A): expected amplifier output; observed VREF; shared with pin 2 for reference follower. PASS.
U1 pin 2 (-IN A): expected inverting feedback input; observed VREF; tied to output A. PASS.
U1 pin 3 (+IN A): expected noninverting signal/reference input; observed VREF_RAW. PASS.
U1 pin 4 (V+): expected positive supply; observed 5V_QUIET. PASS.
U1 pin 5 (+IN B): expected noninverting signal/reference input; observed VREF. PASS.
U1 pin 6 (-IN B): expected inverting feedback input; observed PRE_FB. PASS.
U1 pin 7 (OUT B): expected amplifier output; observed PRE_OUT. PASS.
U1 pin 8 (OUT C): expected amplifier output; observed OUTP_DRV. PASS.
U1 pin 9 (-IN C): expected inverting feedback input; observed OUTP_FB. PASS.
U1 pin 10 (+IN C): expected noninverting signal/reference input; observed VREF. PASS.
U1 pin 11 (V-): expected lowest supply; observed GND. PASS.
U1 pin 12 (+IN D): expected noninverting signal/reference input; observed VREF. PASS.
U1 pin 13 (-IN D): expected inverting feedback input; observed SPARE_BUF; tied to output D. PASS.
U1 pin 14 (OUT D): expected amplifier output; observed SPARE_BUF; shared with pin 13 for follower. PASS.

U2 — VERDICT: PASS
Primary: TI SBVS121E, tps7a49.pdf SHA-256 0a5e198966ab05ebb39f4512355352c0946af5f52e1fbd2e9ec554041123a126. PDF page 4 section 5 DGN 8-Pin HVSSOP PowerPAD Top View and Pin Functions; PDF pages 33–34 DGN0008D outline and example board layout (4225481/A).
Manufacturer DGN TOP VIEW: pin 1 upper left, 1–4 down the left, 5–8 up the right, CCW; PowerPAD is centered. Mechanical outline page 33 additionally labels the thermal pad 9 in the underside drawing. That lower drawing is a bottom view: pins 4/5 are at its top and 1/8 at its bottom; reversing its vertical axis converts it to the already explicit top-view configuration. No underside mirror was applied to the dossier.
Observed: front F.Cu, native rotation 90 degrees; component-top pin 1 (-2.150,-0.975) mm and pins 1–4 left, 5–8 right at 0.65 mm pitch. Eight unique peripheral native pads plus centered pad 9 preserve all nine physical identities. Four additional unnumbered paste/mechanical objects are disclosed and do not replace electrical leads or create four extra EP identities. No fused-pin aliases are needed. Numbered-pad total 9; dossier object census including those four is 13. Perimeter signed area -8.385 mm² confirms CCW. Native x = 35 + local y and native y = 45 - local x, maximum residual 0 mm, with no reflection. Center pad 9 is 1.57 x 1.89 mm on GND, matching DGN0008D exposed-metal dimensions in the example land pattern.
U2 pin 1 (OUT): expected regulated output rail; observed 5V_QUIET. PASS.
U2 pin 2 (FB): expected output-set feedback node; observed LDO_FB. PASS.
U2 pin 3 (NC): expected open or GND permitted by datasheet; observed unconnected-(U2-NC-Pad3), explicit no-connect label. PASS.
U2 pin 4 (GND): expected ground; observed GND. PASS.
U2 pin 5 (EN): expected enable input; permitted tie to IN; observed VIN_PROTECTED, same as pin 8. PASS.
U2 pin 6 (NR/SS): expected noise-reduction capacitor node; observed LDO_NR. PASS.
U2 pin 7 (DNC): expected no external electrical connection, including GND/IN; observed unconnected-(U2-DNC-Pad7), distinct explicit no-connect label. PASS.
U2 pin 8 (IN): expected input supply; observed VIN_PROTECTED. PASS.
U2 pin 9 (PowerPAD): expected center exposed pad; open or GND per pin table; observed center 1.57 x 1.89 mm land on GND. PASS.

Function-net sanity and symmetry: U1 A and D each join their own inverting input to their own output, consistent with followers. B and C each retain a separate inverting-feedback node, output, and VREF noninverting input. No supply/input/output interchange appears. U2 IN and EN intentionally share the same supply, an expressly allowed configuration. U2 OUT and U1 V+ both name 5V_QUIET, while U2 GND/EP and U1 V- name GND. U1 and U2 are different devices; there are no duplicate instances of either part within the commissioned group.
The explicit unconnected labels on U2 pins 3 and 7 are assessed as no-connect declarations in this pre-route dossier. No unrelated ground or supply is assigned to either. Dossier review establishes assigned pin/function/net types; it does not establish external capacitor values, feedback resistor values, completed routing, or full circuit performance, which were not supplied and are outside this pin commission.

No FAIL or QUESTION findings. Engineering review is complete for U1/U2 only. Delivery PASS denotes complete honest evidence handback, not permission to order.

Methods:
- Verified SHA-256 and byte size of all seven frozen envelope inputs before and after review.
- Used finite direct-argv pdftotext/pdftoppm calls under pipeline_runtime.run_stage, explicit scratch cwd and environment, raw combined output and runtime JSON retained.
- Inspected rendered manufacturer pin figure images with view_image before opening either native dossier; recorded manufacturer-first.json.
- Inspected mechanical outline and example land-pattern images; separated top and bottom projections explicitly.
- Parsed every numbered dossier row; measured identity census, perimeter winding, and native mount transform residuals; compared every function/net individually.
- No schematic, live board, prior review, or author reasoning used. Embedded dossier verification notes were not evidence for any conclusion.
