from pathlib import Path,PurePosixPath
import hashlib,json,tarfile
s=Path(__file__).parent;out=s.parent/"outputs"
archive=out/"evidence.tar.gz"
paths=[(p,"scratch/"+p.relative_to(s).as_posix()) for p in sorted(s.rglob("*")) if p.is_file() and not p.name.startswith("final-preflight")]
paths += [(out/n,n)for n in ["report.md","evidence.json","result.json"]]
assert all(not p.is_symlink() for p,n in paths)
assert all(not n.endswith((".tar.gz",".tar"))for p,n in paths)
with tarfile.open(archive,"w:gz")as t:
 for p,n in paths:t.add(p,arcname=n,recursive=False)
records=[];seen=set()
with tarfile.open(archive,"r:gz")as t:
 for m in t:
  p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and ".." not in p.parts and m.name not in seen;seen.add(m.name)
  b=t.extractfile(m).read();assert len(b)==m.size
  records.append({"path":m.name,"size":len(b),"sha256":hashlib.sha256(b).hexdigest()})
assert len(records)==len(paths)
for (p,n),rec in zip(paths,records):assert n==rec["path"] and hashlib.sha256(p.read_bytes()).hexdigest()==rec["sha256"]
manifest={"archive_sha256":hashlib.sha256(archive.read_bytes()).hexdigest(),"archive_size":archive.stat().st_size,"member_count":len(records),"members":records}
(out/"evidence-manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(json.dumps({k:v for k,v in manifest.items() if k!="members"}))
