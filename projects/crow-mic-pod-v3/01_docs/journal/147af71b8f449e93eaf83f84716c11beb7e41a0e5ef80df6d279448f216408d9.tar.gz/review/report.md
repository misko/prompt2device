# Pod renewed placement handback

MEASURED: normal continuation stopped at **[5e] P-ORIENT REVIEW REQUIRED**. Machine1/1PASS, current approval subject or denominator stale. Driver rc1 /27.874s; bounded outer rc1 /27.955341s. No conductor retry.

MEASURED: final current-board native DRC **0violations /58unconnected /0parity**, rc5 /0.485486s, after root authorized one measurement. PCB bytes unchanged by DRC. Prior stale1/58/0 gate retained in scratch; genuine final DRC allowed normal placement handoff generation and validation PASS.

MEASURED: S-COUNT4/4 over40components; source103pins; P-PINMAP38physical pin identities across4multi-pin refs; P-FEASIBILITY7/7; model coverage32/32; P-MODEL-REG2/2; P-LAND69/103graded,0failures. Canonical PCB has0tracks/vias. Separate deterministic r0 seed prep has86primitives and is not routed acceptance.

Identities:

- PCB `a44b769b1a5ad5fa959b476bd30f91a64aeaba9ad64d7868fa4e60ffbb62ee48`
- Components canonical JSON `754fe5a20aa77fc507f02cb137dee1bc6a91c319b1a29079a06ecedce11a8cb0`
- Pins canonical JSON `44ddc1f7fa134171437476099544c24a68f3cf928bc61b36c4fa2574f1fb65db`
- Orientation subject `5e2631d88395ccb907028bd6dfbd4d66deb2c38ba9b11fa20bd0b500d19e591f`

Current artifacts: `04_kicad/crow_mic_pod_v3.kicad_pcb`, `06_build/drc/gate.json`, `06_build/drc/pre_route.json`, `06_build/pre_route/orientation/orientation_review.md`, `06_build/pre_route/orientation/orientation_receipt.json`, `06_build/pre_route/model_registration.md`, `06_build/agent_handoff.yaml`. All paths are project-relative to `/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/projects/crow-mic-pod-v3`. Exact output and image hashes are in evidence.json.

MEASURED:335/335 frozen inputs reverified;329protected source/method preimages unchanged. The330th copied input is the PCB regenerated within scope. EXCLUSIVE writer-scope PASS; protected attempt/claim untouched. Complete lossless raw command logs, runtime records, current/old DRC subjects and native model/raster results retained.

NOT RUN: placement human reviews, route import/taps/stitch, final routed acceptance, layout seal, fabrication, release, order and physical acceptance. Supplemental native shell/attachment/full-extent proof remains owed if not already supplied to owning review. Current orientation images require explicit user approval. **FIRST-ARTICLE-ONLY / DO-NOT-ORDER.**

The initial compact-handoff attempt honestly refused the stale gate. Root subsequently authorized final native DRC; no timestamp manipulation, gate waiver or approval fabrication occurred. Diagnostic classification helper corrections in scratch are recorded, including its initial failure; no engineering source/gate method was changed.

## Every current final DRC row

All58rows preserve116native endpoints with matching UUID/ref/pad/net/position. Each connection remains OWED_ROUTING on the zero-track canonical placement.

| Row | Endpoint A | Endpoint B | Net | Cause |
|---|---|---|---|---|
|final_gate:unconnected_items:001|TP4.1|U1.5|VREF|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:002|U1.2|U1.1|VREF|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:003|U1.2|U1.5|VREF|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:004|U1.5|U1.10|VREF|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:005|U1.12|U1.10|VREF|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:006|U1.12|R5.2|VREF|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:007|R6.2|R7.1|VREF_RAW|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:008|R7.1|C9.1|VREF_RAW|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:009|U1.3|C9.1|VREF_RAW|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:010|TP3.1|C6.1|5V_QUIET|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:011|C6.1|U2.1|5V_QUIET|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:012|C5.1|C3.1|5V_QUIET|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:013|U2.1|C3.1|5V_QUIET|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:014|R1.1|C3.1|5V_QUIET|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:015|R6.1|R1.1|5V_QUIET|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:016|C10.1|R6.1|5V_QUIET|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:017|U1.4|C10.1|5V_QUIET|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:018|U1.4|C11.1|5V_QUIET|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:019|R3.1|C11.1|5V_QUIET|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:020|R8.2|R9.2|PRE_FB|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:021|U1.6|R8.2|PRE_FB|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:022|R9.1|U1.7|PRE_OUT|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:023|R10.1|U1.7|PRE_OUT|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:024|R10.1|R13.1|PRE_OUT|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:025|R12.1|U1.8|OUTP_DRV|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:026|U1.8|R11.1|OUTP_DRV|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:027|R10.2|U1.9|OUTP_FB|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:028|R11.2|R10.2|OUTP_FB|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:029|U1.14|U1.13|SPARE_BUF|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:030|U2.2|C3.2|LDO_FB|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:031|C3.2|R1.2|LDO_FB|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:032|R2.1|R1.2|LDO_FB|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:033|U3.5|J1.4|AUDIO_N|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:034|J1.4|TP6.1|AUDIO_N|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:035|R13.2|TP6.1|AUDIO_N|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:036|TP2.1|R14.1|VIN_PROTECTED|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:037|D2.1|TP2.1|VIN_PROTECTED|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:038|C2.1|C1.1|VIN_PROTECTED|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:039|C2.1|U2.8|VIN_PROTECTED|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:040|C2.1|R14.1|VIN_PROTECTED|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:041|U2.8|U2.5|VIN_PROTECTED|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:042|U2.5|D1.1|VIN_PROTECTED|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:043|J1.5|U3.3|AUDIO_P|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:044|R12.2|TP5.1|AUDIO_P|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:045|TP5.1|U3.3|AUDIO_P|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:046|TP1.1|F1.1|12V_POD|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:047|F1.1|J1.1|12V_POD|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:048|J1.3|J1.1|12V_POD|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:049|J1.7|J1.3|12V_POD|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:050|J1.10|J1.9|POD_SHIELD|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:051|C4.1|U2.6|LDO_NR|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:052|R3.2|R4.1|MIC_BIAS|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:053|C7.1|R3.2|MIC_BIAS|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:054|R5.1|R8.1|MIC_AC|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:055|C8.2|R5.1|MIC_AC|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:056|C8.1|MK1.1|MIC_RAW|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:057|R4.2|C8.1|MIC_RAW|No routed track/via connection on canonical placement; retain native error.|
|final_gate:unconnected_items:058|F1.2|D1.2|12V_FUSED|No routed track/via connection on canonical placement; retain native error.|

Current violations and parity denominators are0, with no omitted nodes. The pre_route report separately retains all58rows; prior preserved gate retains its58unconnected rows and the one J1 lib_footprint_mismatch warning. Each of all175report findings is individually represented in evidence.json with original row and cause. Prior J1 warning is the old embedded Fab footprint; regeneration removed it in both fresh native reports.
