# D-BACK source proposal: SOUND

Candidate 1 is ready for independent integrity review. The frozen and live source trees were not edited. This finding does not approve a pin review, integrate source, or renew a checkpoint.

## Reproduction and chosen frame

Actual frozen pod U3 is native B.Cu / IsFlipped=True at 180 degrees. The original extractor produces `CW (top view)` and pin 1 at approximately (-0.71,+0.50), without declaring mounted side. Native observations are retained in `native-probe-complete.log`.

The inspected TI SLLSEG9C page 3 DRL five-pin Top View places pin 1 upper-left, pins 1/2/3 down the left side and 4/5 up the right: CCW. `manufacturer-page3.png` and the exact digest-selected PDF are retained. The corrected U3 dossier declares back mounting, component-top coordinates, and the native back-mount y reflection. Its pin 1 is (-0.712500,-0.500000); pin 3 is (-0.712500,+0.500000); pin 4 is (+0.712500,+0.500000). Winding is CCW. Pin 3 remains AUDIO_P, pin 4 GND, pin 5 AUDIO_N, and the two NC net identities remain intact.

The extractor reads native `GetFPRelativePosition()` instead of rotating the footprint object. These native relative coordinates already undo translation and rotation but retain back-mount reflection. It negates local y only when native `IsFlipped()` is true. It never selects a transform from expected winding, manufacturer function, pin number, or net name. Both local and native board coordinates are emitted at native nanometre precision in mm. N/S/E/W and winding consistently refer to component-top. The protocol requires regeneration for missing-frame legacy dossiers and forbids a second mirror to rationalize mismatched winding.

## Measured validation

- Valid RED: `red-property-suite.log`, old source SHA `c4acef1e9b0527b80eafe72fe7464ef6e615a9db2fc68f6d4318ffdd774b8ff4`: eight maintained tests pass and all three new regressions fail. The good native control reports 72 back-frame coordinate/winding defects; 12 deliberately mirrored back instances are falsely labelled CCW; the CLI lacks mounted-side/frame fields.
- GREEN: `green-candidate1-suite.log`: 11 passed, 0 failed, 8 known-bad controls. Existing exact PDF/MPN, alias/fused shell and collinear safeguards are maintained.
- `matrix-proof.log` / `matrix-measurements.json`: 48 native instances and 240 pads across front/back, both native flip axes, and 0/30/37.5/90/180/270-degree rotations. All 48 new results match the independently prescribed winding; 24 old results do not. A true physical-pin mirror stays CW on both mounted sides. All 48 old and 48 new CLI dossiers, native fixture boards, and per-pad results are retained. These fixture PDFs are explicitly synthetic, not manufacturer authority.
- `actual-boards.log`: all 384 footprints, including 17 back-mounted instances, and 1,163 native pads from the two actual boards preserve exact in-memory positions, rotations, layer sets, pin numbers and net names. Complete native before/after snapshots match. Pad/net/size/drill fields match original extraction. Both PCB byte digests remain unchanged. All 67 requested actual dossiers were regenerated under old and new code.
- All 437 envelope inputs match their exact SHA-256/size before and after. Only the three proposed source files differ in the scratch repo.

The earliest probe/test runs contain instrumentation mistakes and are retained for honesty, not counted as RED: unsupported Duplicate signature; LSET constructor forms; the runtime wrapper return-code key; and the native pad iteration order assumption. The valid identity-indexed tests were then rerun against the still-unchanged original extractor before candidate 1 was written. There was one coherent source candidate and no replacements.

## Exact source proposal

The archive contains `proposal.patch`, `source-manifest.json`, originals under `original/`, and complete proposed files under `proposal/`. No locator code, board geometry, part identity, footprint/model, approval, pre-route gate, physical limit, or test catalog was edited.

| Source | Before SHA-256 | Proposed SHA-256 |
|---|---|---|
| `skills/kicad-pcb/scripts/pin_audit.py` | `c4acef1e9b0527b80eafe72fe7464ef6e615a9db2fc68f6d4318ffdd774b8ff4` | `af0520dc3e4e77da123c4627174df57ae54230c0b96d2e712965080b56995cd7` |
| `tests/t1_pin_audit.py` | `ddf6f216d9fc010cd1c5604a3560cd0f0a1a5e1e8c5a375310a4842b1803f596` | `941ede5a42b36a680a2ea2ffcce8658f079ec8759937c63aed2f377db731aac9` |
| `skills/kicad-pcb/references/pin-review-protocol.md` | `5116cfeb9e9d4c34d4f714d74bc1668f7a8febbb4a24cd638c42d2dca33f2b94` | `d3155c46b0a1e67f7fd121f164e6285cd9d59c133b1cdff5d72dcc4bd6da33c5` |

Root integration should add this test-catalog description to `tests/README.md`: “Pin-audit mounted-frame regressions use native asymmetric front/back footprints under both flip axes and six rotations; prove a deliberate physical-pin mirror retains wrong winding, preserve native positions/nets and declared aliases, and require mounted-side/component-top/native-board-coordinate dossier fields. RED against c4acef1e; GREEN after mounted-frame extraction.”

## Reproduction and delivery

Methods are retained as `setup.py`, `probe.py`, `suite.py`, `actual_boards.py`, `matrix.py`, `source_manifest.py`, `run.py`, and `package.py`. Every engineering Python launch used `/usr/bin/python3 -B`; direct subprocesses use shared `pipeline_runtime.run_stage` with finite timeouts, explicit working directory and environment, and retained raw merged stdout/stderr plus runtime receipts. The focused suite wrapper routes its CLI children through that same runtime. The packet's authoritative inputs and absolute method paths are recorded in the envelope and input manifests. Source-only replay uses the unchanged harness and original packet dependencies.

The archive includes engineering methods, complete raw evidence/runtime, both actual native boards, the inspected PDF/PNG, three original/proposed source files, patch, manifest, and test fixture outputs. Each regular member is reopened and SHA-256 checked; duplicate paths, symlinks, traversal, recursive archives and nonregular members are rejected. Output checks grade complete honest handback only. No unresolved source finding remains in this proposal; independent acceptance and fresh pin review remain the next owners' work.
