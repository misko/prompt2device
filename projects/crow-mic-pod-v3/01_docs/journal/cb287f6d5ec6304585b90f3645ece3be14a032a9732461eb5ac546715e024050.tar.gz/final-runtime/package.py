import hashlib, io, json, tarfile
from pathlib import Path, PurePosixPath
base=Path(__file__).resolve().parent;out=base.parent/'outputs'
envelope=json.loads((base.parent/'envelope.json').read_text())
manifest=json.loads((base/'source-manifest.json').read_text())
boards=json.loads((base/'actual-board-measurements.json').read_text())
matrix=json.loads((base/'matrix-measurements.json').read_text())
evidence={
 'verdict':'SOUND','subject':envelope['subject'],
 'scope':'One scratch-only source proposal, ready for independent integrity review; no pin-review approval or checkpoint/source renewal.',
 'methods':[
   'SHA-256 and size of every 437 envelope input before/after; complete proposal-tree diff permits exactly three source files.',
   'Native pcbnew actual U3 inspection; GetFPRelativePosition compared to native unflip on both axes, no manufacturer-dependent normalization.',
   'Rendered and visually inspected digest-selected TI tpd2e2u06.pdf page 3, DRL 5-pin SOT Top View. Retained full PNG and PDF.',
   'Maintained t1_pin_audit suite plus three new native regression properties: old extractor RED, candidate1 GREEN; shared runtime direct-argv wrapper retained.',
   'Independent matrix retains 48 native instances, all 240 pad rows, correct and physical-mirror CLI dossiers under both old and new extractors.',
   'Actual pod/carrier all-footprint extraction with complete native before/after snapshots, pad/net/size/drill equality to original extraction and full board byte preservation.',
   'Archive every regular evidence member, reopen and hash each member; reject duplicate, symlink, traversal or recursive archive members.'
 ],
 'findings':[
   {'id':'D-BACK','status':'REPRODUCED_AND_CORRECTED_IN_PROPOSAL','detail':'Actual bottom-mounted U3 was CW board-front projection mislabelled as top view, with no mount field. Component-top y reflection conditioned only on native IsFlipped yields CCW and unchanged pad identities/nets.'},
   {'id':'MIRROR','status':'PRESERVED','detail':'A deliberately wrong physical x mirror remains CW on front and back at every tested rotation. The old extractor mislabels the 12 mirrored back instances CCW.'},
   {'id':'AUTHORITY_AND_ALIASES','status':'PRESERVED','detail':'Existing digest/exact-MPN, alias, fused-land and collinear safeguards remain unchanged and all eight maintained tests pass.'},
   {'id':'INDEPENDENCE','status':'BOUNDARY','detail':'SOUND grades only proposed source. Manufacturer electrical sanity, fresh-context pin-review verdicts, source integration and checkpoint renewal require independent owners.'}
 ],
 'measured_counts':{'inputs_verified_before_after':437,'coherent_source_candidates':1,
   'source_files_changed':3,'maintained_tests_passed':8,'new_tests_old_code_failed':3,
   'new_tests_new_code_passed':3,'green_suite_passed':11,'green_suite_failed':0,
   'green_suite_known_bad':8,'native_matrix_instances':48,'native_matrix_pads':240,
   'matrix_new_correct_winding':48,'matrix_old_wrong_winding':24,
   'matrix_dossiers_each_phase':48,'actual_footprints':384,'actual_back_footprints':17,
   'actual_native_pads_preserved':1163,'actual_dossiers_each_phase':67,
   'pcb_files_unchanged':2,'native_snapshot_pairs_identical':2},
 'source_manifest':manifest,'actual_board_measurements':boards,
 'instrumentation_exclusions':[
   'native-probe first run stopped on wrong Duplicate() signature after printing actual U3; corrected native-probe-complete retained.',
   'red-suite and red-valid-suite had fixture LSET constructor / wrapper returncode-key errors; excluded as RED evidence.',
   'red-native-suite had a pad-enumeration assumption in its positive geometry assertion; excluded. Corrected identity-indexed red-property-suite is the valid baseline.'
 ],
 'valid_runs':{'red':'red-property-suite.log','green':'green-candidate1-suite.log',
               'matrix':'matrix-proof.log','actual':'actual-boards.log'},
 'unresolved_findings':[]
}
(out/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
rows='\n'.join(f"| `{r['path']}` | `{r['before_sha256']}` | `{r['after_sha256']}` |" for r in manifest)
report=f'''# D-BACK source proposal: SOUND

Candidate 1 is ready for independent integrity review. The frozen and live source trees were not edited. This finding does not approve a pin review, integrate source, or renew a checkpoint.

## Reproduction and chosen frame

Actual frozen pod U3 is native B.Cu / IsFlipped=True at 180 degrees. The original extractor produces `CW (top view)` and pin 1 at approximately (-0.71,+0.50), without declaring mounted side. Native observations are retained in `native-probe-complete.log`.

The inspected TI SLLSEG9C page 3 DRL five-pin Top View places pin 1 upper-left, pins 1/2/3 down the left side and 4/5 up the right: CCW. `manufacturer-page3.png` and the exact digest-selected PDF are retained. The corrected U3 dossier declares back mounting, component-top coordinates, and the native back-mount y reflection. Its pin 1 is (-0.712500,-0.500000); pin 3 is (-0.712500,+0.500000); pin 4 is (+0.712500,+0.500000). Winding is CCW. Pin 3 remains AUDIO_P, pin 4 GND, pin 5 AUDIO_N, and the two NC net identities remain intact.

The extractor reads native `GetFPRelativePosition()` instead of rotating the footprint object. These native relative coordinates already undo translation and rotation but retain back-mount reflection. It negates local y only when native `IsFlipped()` is true. It never selects a transform from expected winding, manufacturer function, pin number, or net name. Both local and native board coordinates are emitted at native nanometre precision in mm. N/S/E/W and winding consistently refer to component-top. The protocol requires regeneration for missing-frame legacy dossiers and forbids a second mirror to rationalize mismatched winding.

## Measured validation

- Valid RED: `red-property-suite.log`, old source SHA `c4acef1e9b0527b80eafe72fe7464ef6e615a9db2fc68f6d4318ffdd774b8ff4`: eight maintained tests pass and all three new regressions fail. The good native control reports 72 back-frame coordinate/winding defects; 12 deliberately mirrored back instances are falsely labelled CCW; the CLI lacks mounted-side/frame fields.
- GREEN: `green-candidate1-suite.log`: 11 passed, 0 failed, 8 known-bad controls. Existing exact PDF/MPN, alias/fused shell and collinear safeguards are maintained.
- `matrix-proof.log` / `matrix-measurements.json`: 48 native instances and 240 pads across front/back, both native flip axes, and 0/30/37.5/90/180/270-degree rotations. All 48 new results match the independently prescribed winding; 24 old results do not. A true physical-pin mirror stays CW on both mounted sides. All 48 old and 48 new CLI dossiers, native fixture boards, and per-pad results are retained. These fixture PDFs are explicitly synthetic, not manufacturer authority.
- `actual-boards.log`: all 384 footprints, including 17 back-mounted instances, and 1,163 native pads from the two actual boards preserve exact in-memory positions, rotations, layer sets, pin numbers and net names. Complete native before/after snapshots match. Pad/net/size/drill fields match original extraction. Both PCB byte digests remain unchanged. All 67 requested actual dossiers were regenerated under old and new code.
- All 437 envelope inputs match their exact SHA-256/size before and after. Only the three proposed source files differ in the scratch repo.

The earliest probe/test runs contain instrumentation mistakes and are retained for honesty, not counted as RED: unsupported Duplicate signature; LSET constructor forms; the runtime wrapper return-code key; and the native pad iteration order assumption. The valid identity-indexed tests were then rerun against the still-unchanged original extractor before candidate 1 was written. There was one coherent source candidate and no replacements.

## Exact source proposal

The archive contains `proposal.patch`, `source-manifest.json`, originals under `original/`, and complete proposed files under `proposal/`. No locator code, board geometry, part identity, footprint/model, approval, pre-route gate, physical limit, or test catalog was edited.

| Source | Before SHA-256 | Proposed SHA-256 |
|---|---|---|
{rows}

Root integration should add this test-catalog description to `tests/README.md`: “Pin-audit mounted-frame regressions use native asymmetric front/back footprints under both flip axes and six rotations; prove a deliberate physical-pin mirror retains wrong winding, preserve native positions/nets and declared aliases, and require mounted-side/component-top/native-board-coordinate dossier fields. RED against c4acef1e; GREEN after mounted-frame extraction.”

## Reproduction and delivery

Methods are retained as `setup.py`, `probe.py`, `suite.py`, `actual_boards.py`, `matrix.py`, `source_manifest.py`, `run.py`, and `package.py`. Every engineering Python launch used `/usr/bin/python3 -B`; direct subprocesses use shared `pipeline_runtime.run_stage` with finite timeouts, explicit working directory and environment, and retained raw merged stdout/stderr plus runtime receipts. The focused suite wrapper routes its CLI children through that same runtime. The packet's authoritative inputs and absolute method paths are recorded in the envelope and input manifests. Source-only replay uses the unchanged harness and original packet dependencies.

The archive includes engineering methods, complete raw evidence/runtime, both actual native boards, the inspected PDF/PNG, three original/proposed source files, patch, manifest, and test fixture outputs. Each regular member is reopened and SHA-256 checked; duplicate paths, symlinks, traversal, recursive archives and nonregular members are rejected. Output checks grade complete honest handback only. No unresolved source finding remains in this proposal; independent acceptance and fresh pin review remain the next owners' work.
'''
(out/'report.md').write_text(report)
(out/'result.json').write_text(json.dumps({'subject':envelope['subject'],
    'checks':{k:'PASS' for k in envelope['completion']['checks']},'unresolved':[]},indent=2)+'\n')
members={}
for p in base.rglob('*'):
    if not p.is_file():continue
    rel=p.relative_to(base).as_posix()
    if rel.startswith('proposal/') and rel.removeprefix('proposal/') not in {r['path'] for r in manifest}:continue
    if rel in {'packaging.log','packaging.runtime.json','archive-validation.json'}:continue
    assert not p.is_symlink()
    assert not rel.endswith(('.tar.gz','.tgz','.tar'))
    members[rel]=p.read_bytes()
members['report.md']=(out/'report.md').read_bytes()
members['evidence.json']=(out/'evidence.json').read_bytes()
members['envelope.json']=(base.parent/'envelope.json').read_bytes()
archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for rel,data in sorted(members.items()):
        assert not PurePosixPath(rel).is_absolute() and '..' not in PurePosixPath(rel).parts
        info=tarfile.TarInfo(rel);info.size=len(data);info.mode=0o644
        tar.addfile(info,io.BytesIO(data))
measured=[];seen=set()
with tarfile.open(archive,'r:gz') as tar:
    for item in tar:
        assert item.isfile() and item.name not in seen
        assert not PurePosixPath(item.name).is_absolute() and '..' not in PurePosixPath(item.name).parts
        seen.add(item.name)
        data=tar.extractfile(item).read()
        assert data==members[item.name] and len(data)==item.size
        measured.append({'path':item.name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
assert seen==set(members)
result={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'archive_size':archive.stat().st_size,'member_count':len(measured),'members':measured}
(out/'evidence-manifest.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='members'},indent=2))
