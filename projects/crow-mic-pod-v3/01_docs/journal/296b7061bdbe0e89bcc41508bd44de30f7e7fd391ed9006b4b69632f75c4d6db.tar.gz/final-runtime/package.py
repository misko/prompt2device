from pathlib import Path
import json,hashlib,tarfile,shutil,io
S=Path(__file__).parent;B=S.parents[3];O=S.parent/'outputs';E=json.loads((S.parent/'envelope.json').read_text());M=json.loads((S/'measurements.json').read_text())
report='''SOUND — limited method-only checkpoint re-admission.

The proposal checks exact equality of the complete input-key sets and exactly the four approved before/after hash-and-size pairs. Independent read-only measurement found 317 current and saved inputs, four approved method changes, and 313 identical inputs. All 18 envelope inputs passed before/after identity guards. Both existing stage checkpoints were independently reopened: 11 prelayout entries and seven schematic entries matched live bytes. Isolated tests of the actual check_delta function rejected additions, deletions, unrelated content drift, and an incorrect approved-method after hash.

Control-flow review: an exclusive nonblocking project-directory lock precedes the census; every old prelayout artifact is checked before renewal. Existing schematic review and source-provenance gates run before checkpoint mutation. Both old checkpoint files and the exact method-delta record are archived. The owning input recorder produces a fresh census; exact delta is checked again, then its owning verifier runs before publication. The stage recorder retains the old artifact path set, and normal resume admission re-verifies prelayout, the complete input census, the schematic checkpoint, sourcing request/authority and readiness. Caught failure after publication restores both original checkpoints. Pre-publication failure leaves checkpoint originals intact.

This verdict admits only running the unchanged pod source with these exact changed methods through the normal conductor. It does not certify equivalent generated geometry, accept fresh native output, or transfer a prior release decision. Generator/routing/checker changes must be graded by their normal downstream native gates. The proposal was not run, and no design or checkpoint was changed by this review. Project-directory locking is cooperative; root remains sole writer. Rollback reviewed here covers caught exceptions, not power loss or SIGKILL. The trusted root must bind its closeout summary to this exact review packet.

No actionable defect found in this limited admission scope. This is not a broad PCB, native-output, or release review. Delivery checks attest complete handback, separately from domain acceptance.
'''
(O/'report.md').write_text(report)
evidence={'verdict':'SOUND','subject':E['subject'],'methods':['SHA256 and size of every envelope input before/after','Owning authored_census read-only evaluation against live unchanged pod checkout, with owner implementation matched to packet','Exact set and four approved before/after pairs','Independent prelayout and schematic stage artifact reopening','Isolated AST extraction of actual pure check_delta function: positive and four negative cases','Manual control-flow review of renewal, owner record/verify, stage checkpoint and normal resume gate; no mutation proposal execution','Archive regular-member reopening and exact output preflight'],'findings':[],'measured_counts':M,'limitations':['Limited method admission only; changed native outputs require normal conductor grading.','Exception rollback is not crash-atomic durability.','Trusted root closeout must refer to this exact packet.']}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(O/'result.json').write_text(json.dumps({'subject':E['subject'],'checks':{x:'PASS' for x in E['completion']['checks']},'unresolved':[]},indent=2)+'\n')
items={}
for x in E['input_packet']:items['packet/'+x['path']]=B/x['path']
items['packet/envelope.json']=S.parent/'envelope.json'
for p in sorted(S.iterdir()):
 if p.is_file() and p.name not in ('archive-check.json',):items['review/'+p.name]=p
for n in ('report.md','evidence.json','result.json'):items['outputs/'+n]=O/n
with tarfile.open(O/'evidence.tar.gz','w:gz') as t:
 for n,p in sorted(items.items()):
  assert not p.is_symlink();t.add(p,arcname=n,recursive=False)
members=[];seen=set()
with tarfile.open(O/'evidence.tar.gz','r:gz') as t:
 for m in t.getmembers():
  assert m.isfile() and m.name not in seen and not m.name.startswith('/') and '..' not in Path(m.name).parts and not m.name.endswith(('.tar','.tar.gz'))
  seen.add(m.name);d=t.extractfile(m).read();assert len(d)==m.size
  members.append({'path':m.name,'size':len(d),'sha256':hashlib.sha256(d).hexdigest()})
a=O/'evidence.tar.gz';manifest={'archive_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'archive_size':a.stat().st_size,'member_count':len(members),'members':members}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for x in E['input_packet']:
 p=B/x['path'];assert p.stat().st_size==x['size'] and hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256']
print(json.dumps({'archive_members':len(members),'archive_sha256':manifest['archive_sha256'],'inputs_after':18}))
