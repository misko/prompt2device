review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_pod_diodes_toponly1 (actual fresh agent)
context: FRESH
design_verdict: INCOMPLETE
order_verdict: DO-NOT-ORDER
board_sha256: 0131d5756ed1bb390280558718af114d5d32842d909cf5a73d67330804a39101
parts_sha256: 24c1d667aa95629d5dabb75f306a3b1f1e2b4293e40230d6c448d4e53da5a287
design_rules_sha256: 7f661d2ef79dd9004962238eac953f194ac18722cd344d1c91443cab29402ca9

Coverage is limited to D1 and D2 pin/package review against the frozen native dossiers and selected primary datasheets. This is not whole-board acceptance. No schematic, live design, historical review, or author reasoning was inspected. Subject hashes above are immutable metadata, not independently reviewed conclusions.

D1 — VERDICT: QUESTION

Primary: JKSEMI 1N4007(M7)SMA, 2021-10-21 rev c, SHA-256 f893d8385c6fee5af85b9053653bd8e93547c335c031cbab9ecb592c0bb5eddd. Inspected page 1 package perspective and page 3 Package Outline/recommended mounting pattern as rendered figure images.

The figures establish an SMA body with two opposite leads and no EP. Page 1 shows a band at one end, but this exact PDF does not identify the band as cathode or supply a numbered K/A pinout. The mechanical datum A on page 3 is not an anode designation. A conventional band=cathode interpretation is consistent with the drawing, but is not explicitly established by this selected manufacturer's evidence; no reversed connection is proven.

D1 pin 1 (K): expected the physical cathode terminal on the downstream protected rail; observed local (-2.000, 0.000), west, VIN_PROTECTED, native (37.500, 35.600). Electrical assignment is consistent with series rectification, but exact manufacturer identification of the banded physical terminal remains unverified.
D1 pin 2 (A): expected the physical anode terminal on the source rail; observed local (+2.000, 0.000), east, 12V_FUSED, native (41.500, 35.600). Electrical assignment is consistent with the net names, subject to the same unresolved physical polarity identity.

Measured: 2 native copper pads, 2 unique numeric pad identities, 2 physical terminals in primary drawings, 0 EP, 0 declared aliases/fused identities. Native pad dimensions are 2.5 x 1.8 mm each; center spacing is 4.000 mm. Both terminals are individually represented. Explicit front mounting, rotation 0 degrees, and +x-right/+y-down component-top frame agree with native coordinates; no reflection is applied. Two collinear pads establish no CW/CCW winding, matching the dossier's n/a. Manufacturer numeric pin 1 is not specified and cannot be inferred from a mechanical datum or pad shape.

Missing fact Q-D1-POLARITY: exact manufacturer-controlled evidence identifying the banded end of JKSEMI 1N4007(M7)SMA as cathode (and the opposite end as anode), allowing the physical K/A identities to be bound conclusively to the native pad map. This is an evidence question, not an asserted electrical defect.

D2 — VERDICT: PASS

Primary: Littelfuse SMBJ series v4, revised JC.07/04/25, SHA-256 d7df155be4b1f612085401e8c946f065e284d65a0e7de22b9225a7b73946e51b. Inspected page 1 Functional Diagram, page 5 Dimensions/Physical Specifications, and page 6 Part Marking System as rendered figure images; page 2 electrical table was inspected in text for exact SMBJ15A identity.

The marked component-top drawing on page 5 has cathode band on the left and anode at the opposite right terminal. Page 6 shows the same top face rotated 90 degrees, with band at the top. The side profile on page 5 establishes J-bend geometry; it is not a bottom-view pinout. The functional diagram explicitly distinguishes K and A. SMBJ15A is the unidirectional variant. Two opposite terminals and no EP are present. Numeric 1/2 labels are design identifiers, not a manufacturer numbered winding.

D2 pin 1 (K): expected the banded cathode at the positive rail for a unidirectional shunt TVS; observed local (-2.150, 0.000), west, VIN_PROTECTED, native (27.300, 35.850). This matches manufacturer K-left top geometry and the appropriate rail net.
D2 pin 2 (A): expected opposite unbanded anode at ground; observed local (+2.150, 0.000), east, GND, native (27.300, 40.150). This matches the manufacturer and expected shunt topology.

Measured: 2 native copper pads, 2 unique numeric pad identities, 2 physical terminals in primary drawings, 0 EP, 0 declared aliases/fused identities. Native pad dimensions are 2.5 x 2.3 mm each; center spacing is 4.300 mm. Front mounting at native rotation -90 degrees correctly places local west K north of the origin and local east A south; no reflection is required. Manufacturer marked-top figure compares by rotation only. Two collinear pads have no meaningful winding; dossier n/a is correct.

Group comparison: both instances preserve separate K/A identities with K on VIN_PROTECTED. D1's A on 12V_FUSED is consistent with a series rectifier; D2's A on GND is consistent with a shunt TVS. These are different part types and roles, so the different anode net kinds are not a symmetry defect. This pin review does not establish protection ratings, routing, assembly placement-mark accuracy, or whole-circuit performance.

Methods: manufacturer figures were rendered and visually inspected first; primary-derivation.md was recorded before either dossier was read. Native dossier rows were then counted and transcribed independently by a bounded direct-argv Python stage. Every envelope input was SHA-256/size verified before and after; exact native dossiers, inspected figures, derivation, measurements, methods and runtime logs are retained in the archive. All engineering evidence uses the frozen packet. The failed absolute /usr/bin/rg lookup was a tooling-location failure; a bounded Python text-page locator succeeded and its raw evidence is retained.

Delivery completeness is PASS with the honest INCOMPLETE engineering finding above. No source or live project was modified. DO-NOT-ORDER remains in force.
