import json,hashlib,tarfile,io
from pathlib import Path,PurePosixPath
s=Path(__file__).parent; o=s.parent/'outputs'; archive=o/'evidence.tar.gz'; members=[]
paths=[(p,'scratch/'+p.relative_to(s).as_posix()) for p in sorted(s.rglob('*')) if p.is_file()]
paths += [(o/n,'review/'+n) for n in ['report.md','evidence.json','result.json']]
with tarfile.open(archive,'w:gz') as t:
 for p,name in paths:
  assert not p.is_symlink(); assert not name.endswith(('.tar.gz','.tgz','.tar'))
  b=p.read_bytes(); i=tarfile.TarInfo(name); i.size=len(b); i.mode=0o644; t.addfile(i,io.BytesIO(b)); members.append(dict(path=name,size=len(b),sha256=hashlib.sha256(b).hexdigest()))
with tarfile.open(archive,'r:gz') as t:
 seen=set()
 for item in t.getmembers():
  assert item.isfile(); pp=PurePosixPath(item.name); assert not pp.is_absolute() and '..' not in pp.parts and item.name not in seen; seen.add(item.name)
  data=t.extractfile(item).read(); expected=next(x for x in members if x['path']==item.name); assert len(data)==expected['size'] and hashlib.sha256(data).hexdigest()==expected['sha256']
 assert len(seen)==len(members)
b=archive.read_bytes(); manifest=dict(archive_sha256=hashlib.sha256(b).hexdigest(),archive_size=len(b),member_count=len(members),members=members)
(o/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='members'}))
