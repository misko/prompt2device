from pathlib import Path
import json,hashlib,tarfile,shutil,ast,collections
S=Path(__file__).parent;P=S.parents[3];R=S/'repo';O=S.parent/'outputs';A=S/'archive';A.mkdir(exist_ok=True)
e=json.loads((S.parent/'envelope.json').read_text());changed=[]
for rel in ('skills/jlcpcb-fab/scripts/native_model_registration.py','tests/t1_model_registration.py','tests/README.md','skills/jlcpcb-fab/references/digital-twin.md'):
 changed.append(rel)
for project in ('crow-mic-pod-v3','crow-audio-carrier-v1'):
 changed.extend([str(p.relative_to(R)) for p in (R/'projects'/project).glob('03_src/lib/*.pretty/Wurth_615008160221_RJ45.kicad_mod')]);changed.extend([f'projects/{project}/02_parts/615008160221/part.yaml',f'projects/{project}/02_parts/615008160221/primary-source-record.md',f'projects/{project}/03_src/lib/3dmodels/wurth/provenance.md'])
def copy(p,rel):
 q=A/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
def tree(p,rel):
 for f in p.rglob('*'):
  if f.is_file() and not f.is_symlink() and not f.name.endswith(('.tar.gz','.zip')):copy(f,Path(rel)/f.relative_to(p))
for rel in changed:copy(R/rel,Path('source_candidate')/rel);copy(P/'input'/rel,Path('beforeimages')/rel)
def clean_ast(p):
 a=ast.parse(p.read_text());a.body=a.body[1:];return ast.dump(a,include_attributes=False)
engine='skills/jlcpcb-fab/scripts/native_model_registration.py';assert clean_ast(R/engine)==clean_ast(P/'input'/engine)
old=ast.parse((P/'input/tests/t1_model_registration.py').read_text());new=ast.parse((R/'tests/t1_model_registration.py').read_text());oldfunc={n.name:ast.dump(n,include_attributes=False) for n in old.body if isinstance(n,ast.FunctionDef)};newfunc={n.name:ast.dump(n,include_attributes=False) for n in new.body if isinstance(n,ast.FunctionDef)};assert all(newfunc[k]==v for k,v in oldfunc.items())
checks={'changed_files':changed,'engine_algorithm_ast_unchanged':True,'all_previous_test_function_asts_unchanged':True,'previous_test_count':14,'new_total_tests':15,'contracts':'Existing footprint, exact-part provenance and G-VACUOUS homes cover change; no schema/check-ID/algorithm semantics changed. Governing scripts/tests/lib contracts inspected; no contract text change needed.'}
(S/'source-scope-checks.json').write_text(json.dumps(checks,indent=2))
for p in S.glob('*.py'):copy(p,Path('methods')/p.name)
for p in S.glob('*.json'):copy(p,Path('measurements')/p.name)
for p in S.glob('*.step'):copy(p,Path('native')/p.name)
for p in S.glob('*.kicad_pcb'):copy(p,Path('native')/p.name)
for directory in ('runtime','test-native','test-native-full','test-native-slow','tmp','candidate1','pixel-replay','original-pixels'):
 if (S/directory).exists():tree(S/directory,directory)
copy(S/'diagnosis-reopened/drawing-page1.png','primary/drawing-page1.png')
for project in ('crow-mic-pod-v3','crow-audio-carrier-v1'):
 tree(R/'projects'/project/'04_kicad',Path('generated')/project/'04_kicad')
 tree(R/'projects'/project/'06_build/pre_route',Path('generated')/project/'pre_route')
tree(S/'baseline-pod/06_build/pre_route','original-pod-replay')
# Reverify every frozen byte at close, without changing the admitted packet.
for r in e['input_packet']:
 b=(P/r['path']).read_bytes();assert len(b)==r['size'] and hashlib.sha256(b).hexdigest()==r['sha256']
copy(S/'inputs-before.json','measurements/inputs-after.json')
# Explicitly retained setup failures are not source candidates and never erased.
(A/'measurements/setup-failures.json').write_text(json.dumps({'runtime_initial':'run_stage refused console_tail_lines20 with console_line_limit8 before native launch; changed orchestration display budget to20.','derive_initial':'Pre-candidate edge selection wrongly excluded negative-model-Y finger tips; native section inspection retained. No footprint was written until assertion passed.','candidate1':'Polyline draft retained; candidate2 compact native arcs selected, geometry frozen thereafter.','missing_dependency':'First stock board generation lacked fab_tiers.yaml; copied exact missing dependencies from authorized worktree, hashes retained.','pixel_path':'Original raw files absent from784packet; first replay failed; root authorized35hash-verified files from original144packet, then replay passed.'},indent=2))
# Every regular member reopened and checked; no links, duplicates or traversal.
paths=sorted(p for p in A.rglob('*') if p.is_file());members=[]
for p in paths:
 assert not p.is_symlink();rel=p.relative_to(A).as_posix();assert '..' not in Path(rel).parts and not Path(rel).is_absolute();b=p.read_bytes();members.append({'path':rel,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for p in paths:t.add(p,arcname=p.relative_to(A).as_posix(),recursive=False)
with tarfile.open(archive) as t:
 ms=t.getmembers();assert len(ms)==len(members) and len({m.name for m in ms})==len(ms)
 for m,r in zip(ms,members):
  assert m.isfile() and m.name==r['path'];b=t.extractfile(m).read();assert len(b)==r['size'] and hashlib.sha256(b).hexdigest()==r['sha256']
manifest={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_size':archive.stat().st_size,'member_count':len(members),'members':members};(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2))
supp=json.loads((S/'supplement.json').read_text());final=json.loads((S/'final-measurements.json').read_text());drc=json.loads((S/'drc-classification.json').read_text());pixels=json.loads((S/'pixel-replay/pixel-census.json').read_text())
evidence={'domain_result':'SOURCE_PROPOSAL_READY_FOR_INDEPENDENT_REVIEW; NOT_PLACEMENT_OR_ROUTING_ACCEPTANCE','source_scope':checks,'candidate_count':2,'selected_candidate':2,'native_registration':{'carrier':'PASS 6/6 groups','pod':'PASS 2/2 groups','original_pod':'FAIL J1 outward1.059222798mm'},'tests':{'total':15,'passed':15,'existing_unchanged':14,'known_bad':10,'vacuities':2},'supplement':supp,'controls':final,'drc':drc,'original_raw_pixels':pixels,'manufacturing':'Nominal CAD only. Right courtyard tip margin0.001919mm is not a manufacturing tolerance guarantee. Existing first-article obligations and DO-NOT-ORDER remain.','delivery':'Engineering limits and unconnected rows remain explicit; delivery checks do not accept the boards.'};(O/'evidence.json').write_text(json.dumps(evidence,indent=2))
(O/'report.md').write_text('''# Exact RJ45 Fab spring-finger source proposal

FIRST-ARTICLE-ONLY / DO-NOT-ORDER. Scratch source proposal for fresh independent selection; no live source, routing, approval, release or physical acceptance.

**Candidate 2 is ready for independent source review.** Both normally generated boards pass their complete unchanged P-MODEL-REG configurations: carrier6/6 groups, pod2/2 groups, including all9 exact jacks. The fresh original pod control remains FAIL at1.059222798mm. No threshold, extraction algorithm, camera, model, courtyard, pad, drill, copper, position or net change was made.

## Source and exact geometry

The18 added F.Fab primitives comprise16 circular arcs and2end lines. Native shell sections at z4.14 and10.62mm represent all4 lateral fingers. Two exact end-line duplicates are omitted; upper/lower arcs are retained separately, including opposite edge directions and submicrometre rounding differences. This is a faithful section-derived plan detail, not an enlarged generic rectangle. The original nominal shell rectangle remains byte-preserved. Candidate1's770-segment polygon draft and failed preliminary section selection are retained. Candidate2geometry was fixed before native generation and never searched further.

Drawing615008160221rev001.003 page1 was directly reopened: main shell15±0.15 by13.45±0.15 by14.7±0.15mm; free fingers depicted but their span not dimensioned. Circular coordinates are MEASURED manufacturer nominal/free-state STEP, rounded to1e-6mm, not drawing tolerance limits. Full occupied local extent rederived as X[-5.058081,12.218081], Y[-6.360054,7.090000]mm. Exact model bytes and transforms remain unchanged. The Fab union now measures exterior tips; it does not separately recognize the retained nominal shell. Independent shell faces, drawing leaders and all14 native attachment sections retain that separate datum evidence:8signals,2shield tabs,4split-post lobes. Complete per-section nearest-pad correspondences and all9native source pad/drill arrays are delivered.

Both boards were generated with frozen source/netlist through unchanged generate_board_generic.py, with generate_rules_generic.py last. Independent native inspection finds zero pad shape/size/drill/position/rotation/net differences across44pod and340carrier footprints, and no connector/model transform change. All99native exported coupon solids match transformed source extrema to maximum1.31e-12mm. This establishes nominal occupied extent and datum placement, not full BRep equality or manufactured fit. The unchanged courtyard contains the nominal model, with right tip margin only0.001919mm. Tolerances, free deflection, mating, soldering and first-article qualification remain owed.

## Measurement limits and controls

All14existing tests remain unchanged and pass; the new maintained G-VACUOUS fixture also passes:15total,10known-bad controls,2declared blind spots. The previous buried-volume blind spot is retained unchanged. The new fixture constructs direct-coordinate native mesh with an exterior0.01mm-wide feature extending to x3mm beyond its unchanged courtyard; the ordinary native gate falsely passes. Native VRML output is reopened, transform assumptions checked and actual feature dimensions asserted. At56.315789px/mm,57original exterior pixels exist and all are removed by erosion. The same endpoint/depth with width0.6mm is the single contrast and makes the unchanged native gate FAIL. No parameter sweep was run.

The exact-product supplemental control exports a native J1 model translated only+0.05mm in X: measured right extent12.268081mm exceeds unchanged courtyard12.22mm by0.048081mm and supplemental acceptance FAILs. The supplemental method measures original/native STEP solids independently of Fab or expected-region pixel masks, and expressly fails actual thin geometry beyond courtyard even where erosion would pass. It supplements ordinary P-MODEL-REG rather than bypassing it.

Original image dependencies were missing from the784-file packet. Root explicitly authorized35exact frozen dependency files from the closed diagnosis144-item envelope; all hashes/sizes verified. Original pixel replay reproduces all9results: carrier7934lateral pixels become0; pod981of3233survive. Carrier scales18.344811/18.342804px/mm; pod35.543278/35.525992px/mm. Two-pixel per-edge raster uncertainty is approximately±0.109023mm carrier and±0.056269mm pod. This is diagnostic sampling uncertainty, not a changed gate tolerance or proof of manufacturing containment.

## Native DRC and completeness

Final native all-severity/refill/parity DRC: pod0violations,58unconnected,0parity; carrier0violations,499reported unconnected,0parity. Both return exit5 and remain unrouted FAILs. Every native violation/unconnected/parity row is retained and individually classified with exact endpoints, positions and comparison to the frozen snapshot. The pod's58rows match exactly. Carrier reporting substitutes37endpoint pairs while total remains499; all native pad/net/position/copper invariants are unchanged. This is a changed reported row selection, not routing progress; no claim of a complete solved connectivity population is made. The full before/after rows support reviewer inspection instead of totals alone.

Initial generated DRC produced8clearance rows on each board because stock board serialization loses netclass assignments; unchanged generate_rules last restores source-owned rules and clears them. The isolated frozen snapshots additionally reported44pod/199carrier missing-library-table warnings. Those initial environment and intermediate rule-state outputs remain retained and are not counted as source geometry repairs.

## Delivery and boundary

All784frozen input hashes/sizes verified before and after. Archive contains source_candidate/12changed files, beforeimages, both candidates, methods, native/raw outputs, original-pixel dependencies, complete fixture products and bounded-runtime commands/results. Native/tests ran through shared pipeline_runtime.run_stage with explicit cwd/environment, /usr/bin/python3 -B and ≤300second native stages. Setup failures are explicitly retained. Engine non-docstring AST and every existing test-function AST are unchanged. Existing contracts already govern these same files and G-VACUOUS behavior; no schema or check-ID change is introduced.

Delivery completeness is independent of the domain result. Fresh independent source selection, root live adoption, full downstream regeneration, schematic/placement/orientation reviews and every existing first-article hold remain outside this scratch handback. No signatures or new orientation views were minted.
''')
(O/'result.json').write_text(json.dumps({'subject':e['subject'],'checks':{k:'PASS' for k in e['completion']['checks']},'unresolved':[]},sort_keys=True))
print(json.dumps({'outputs':str(O),'archive':manifest['archive_sha256'],'bytes':manifest['archive_size'],'members':manifest['member_count'],'changed':len(changed)}))
