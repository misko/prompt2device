"""Preserve one completed review once, without duplicating its expanded archive."""
from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io,sys
from datetime import datetime,timezone
N=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');I=Path('/tmp/carrier-connector-integration-20260911');name=sys.argv[1];meta=json.loads((N/(name+'-opened.json')).read_text());D=Path(meta['project']);E=Path(meta['envelope']);O=Path(meta['output_dir']);A=E.parent;env=json.loads(E.read_text());attempt=json.loads((A/'attempt.json').read_text());assert attempt['status'] in ['PASS','TIMED_OUT']
for row in env['input_packet']:
 p=D/row['path'];b=p.read_bytes();assert not p.is_symlink() and len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256']
m=json.loads((O/'evidence-manifest.json').read_text());raw=(O/'evidence.tar.gz').read_bytes();assert hashlib.sha256(raw).hexdigest()==m['archive_sha256'] and len(raw)==m['archive_size'];idx={x['path']:x for x in m['members']}
with tarfile.open(O/'evidence.tar.gz','r:gz') as t:
 ms=t.getmembers();assert len(ms)==len({x.name for x in ms})==len(idx)==m['member_count']
 for member in ms:
  assert member.isfile() and not PurePosixPath(member.name).is_absolute() and '..' not in PurePosixPath(member.name).parts
  b=t.extractfile(member).read();row=idx[member.name];assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256']
payload={}
def add(path,key):
 assert path.is_file() and not path.is_symlink() and key not in payload;payload[key]=path.read_bytes()
for p in O.iterdir():
 if p.is_file():add(p,'review/'+p.name)
for p in A.iterdir():
 if p.is_file():add(p,'allocation/'+p.name)
for p in Path(meta['scratch_dir']).glob('*'):
 if p.is_file() and ('preflight' in p.name or p.name.startswith('package')):add(p,'final-runtime/'+p.name)
for suffix in ['-opened.json','-host-final.json']:add(N/(name+suffix),'root/'+name+suffix)
for p in I.glob(name+'-close*'):
 if p.is_file():add(p,'root/'+p.name)
evidence=json.loads((O/'evidence.json').read_text());verdict=evidence.get('verdict',evidence.get('design_verdict'));assert verdict in ['ACCEPT','REJECT','INCOMPLETE','SOUND','DEFECTIVE'];record={'created_at':datetime.now(timezone.utc).isoformat(),'task':name,'subject':env['subject'],'delivery_status':attempt['status'],'engineering_verdict':verdict,'frozen_inputs_reverified':len(env['input_packet']),'review_archive_members_reopened':len(idx),'scope':'Completed original review and final runtime retained; expanded archive is stored once. No later source bytes inherit this verdict. No native/release/order acceptance.'};payload['CLOSEOUT.json']=(json.dumps(record,indent=2)+'\n').encode()
manifest={'files':[{'path':k,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()} for k,b in sorted(payload.items())]};payload['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode();out=N/(name+'-closeout.tmp')
with out.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for k,b in sorted(payload.items()):
    info=tarfile.TarInfo(k);info.size=len(b);info.mode=0o644;t.addfile(info,io.BytesIO(b))
with tarfile.open(out,'r:gz') as t:
 ms=t.getmembers();assert len(ms)==len(payload)==len({x.name for x in ms})
 for member in ms:assert member.isfile() and t.extractfile(member).read()==payload[member.name]
b=out.read_bytes();h=hashlib.sha256(b).hexdigest();folder=R/'projects'/(sys.argv[2] if len(sys.argv)>2 else 'crow-audio-carrier-v1')/'01_docs/journal';assert folder.is_dir() and folder.resolve().is_relative_to(R/'projects');dest=folder/(h+'.tar.gz');assert not dest.exists();dest.write_bytes(b);summary={'archive':str(dest),'sha256':h,'size':len(b),'regular_members':len(payload),**record};(N/(name+'-closeout-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
with (folder/'contracts.md').open('a') as f:f.write(f'\n## Allowed {name} completed review\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Original {verdict} source review, exact frozen subject, full evidence archive and final delivery/runtime closure; no later-byte or native acceptance |\n\nAudit: SHA-256 equals filename; {len(b)}bytes/{len(payload)}regular outer members including MANIFEST, all reopened; inner{len(idx)}members reverified against review manifest. CLOSEOUT retains domain verdict separately from actual delivery status; TIMED_OUT is not admissible review acceptance.\n')
print(json.dumps(summary,indent=2))
