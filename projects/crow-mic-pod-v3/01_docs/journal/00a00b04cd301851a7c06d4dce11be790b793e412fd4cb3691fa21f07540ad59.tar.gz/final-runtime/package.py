import json,hashlib,tarfile
from pathlib import Path, PurePosixPath
from datetime import datetime,timezone
r=Path('/tmp/rj45-pin-pod-analog-approved-ibx3y2t3');base=r/'06_build/task_runs/rj45-pin-pod-analog-approved';s=base/'scratch';out=base/'outputs'
envelope=json.loads((base/'envelope.json').read_text());subject=envelope['subject'];measure=json.loads((s/'native-measurements.json').read_text());derived=json.loads((s/'independent-derivation-before-dossiers.json').read_text())
expect={'U1':['reference-drive output','reference-buffer feedback, same net as OUT A','reference input','positive supply rail','signal/reference input','feedback sense','signal output','signal-drive output','feedback sense','signal/reference input','lowest supply rail','signal/reference input','buffer feedback, same net as OUT D','buffer output'],'U2':['regulated output rail','feedback divider/sense node','open or ground','ground','enable logic; may connect to IN','noise-reduction capacitor node','no electrical connection','input supply rail','open or ground thermal pad']}
findings=[]
for ref,data in measure.items():
 for row,expected in zip(data['rows'],expect[ref]): findings.append(dict(ref=ref,pin=str(row['pad']),verdict='PASS',function=row['function'],expected=expected,observed=row['net']))
package_findings={'U1':'Expected D SOIC14: 7 leads per side, pin1 upper-left, CCW top view, no EP or fused pins. Observed 14 numbered native pad rows, 14 unique identities and centers; pins1..7 x=-2.48 and pins8..14 x=+2.48; pin1=(-2.48,-3.81); signed area -37.7952 mm2 in +y-down frame; CCW. No missing or duplicate pins or alias declarations.','U2':'Expected DGN: 8 leads plus separate PowerPAD9; 4 leads per side, pin1 upper-left, CCW top view. Observed 9 numbered native pad rows, 9 unique identities and centers; pins1..4 x=-2.15, pins5..8 x=+2.15; pin1=(-2.15,-0.97); peripheral signed area -8.342 mm2 in +y-down frame; CCW. Center pad9 GND. No missing or duplicate pins or alias declarations. Four unnumbered paste/mechanical pads reported omitted: 13 total pad objects reported, but 9 electrical identities independently counted.'}
for ref,detail in package_findings.items():findings.append(dict(ref=ref,pin='package',verdict='PASS',detail=detail))
methods=['Verified all seven envelope inputs by size/SHA-256 before and after review; initial dossier hashing did not read dossier content for judgment.','Used only frozen primary PDFs, protocol and native dossiers for engineering judgment. Shared runtime and output validator inspected solely for delivery mechanics. No live project artifacts, schematic, historical review, author rationale, child agents or background jobs.','Extracted text to locate figures and package-order mapping; rendered actual PDF pages with pdftoppm -png -r 120 and opened all six PNGs with view_image. Text alone did not establish winding.','Recorded independent derivation from OPA PDF page5 Figure5-5 and TPS PDF page4 Section5 images before opening native dossier content; independent-derivation-before-dossiers.json retained.','Parsed all native rows, counted numbered identities and centers, compared every function, computed shoelace area excluding central EP; negative signed area in +y-DOWN frame means CCW.','Inspected OPA D0014A PDF pages44/45 and TPS DGN0008D PDF pages33/34 package/land images. TPS upper drawing is top view; lower exposed-pad drawing is underside, pin1 lower-left, and must not mirror the top-view land pattern.','Dossier coordinates explicitly read as top view of mounted part with rotation undone: U1 0deg, U2 90deg. Separate layer metadata is not supplied; declared mounted frame used.','Electrical scope is native per-pin function versus net kind. Net names do not independently establish rail voltages, capacitor values/presence, copper topology or analog performance.','Finite direct argv subprocesses use pipeline_runtime.run_stage, explicit cwd/environment, raw combined stdout/stderr logs and runtime receipts. Console argument initialization failed before one measurement launch; corrected without engineering-state change and retained.','Explicit regular evidence members are archived; every member is reopened and byte/hash checked, with no symlinks, traversal, duplicates or recursive archives. Frozen PDF sources remain digest-bound and are not copied wholesale.']
source=[x for x in envelope['input_packet'] if x['path'].endswith('.pdf')]
limitations=['Limited to U1/U2 pin review; not whole-board, placement, routing, voltage/performance or assembly release acceptance.','U2 four omitted unnumbered paste/mechanical pads are reported, not independently geometrically measured; they add no electrical physical pin identities.','NC/DNC native net names are unconnected markers; dossier-only review does not prove absence of external routed copper or additional net members.']
evidence=dict(schema=1,review_stage='pre-route',review_kind='pin',reviewer='/root/rj45_pin_pod_analog_approved (actual fresh independent agent)',context='FRESH',verdict='SOUND',order_verdict='DO-NOT-ORDER',subject=subject,coverage=['U1','U2'],whole_board_acceptance=False,methods=methods,primary_sources=source,measured_counts=measure,independent_derivation=derived,findings=findings,per_ref_verdict={'U1':'PASS','U2':'PASS'},limitations=limitations,instance_symmetry='One commissioned instance of each part. Cross-instance same-part comparison not applicable. U1 A/D show output-to-inverting-input buffer feedback, B/C show matching output/feedback net kinds.',completed_at=datetime.now(timezone.utc).isoformat())
report="""review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_pod_analog_approved (actual fresh independent agent)
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: a44b769b1a5ad5fa959b476bd30f91a64aeaba9ad64d7868fa4e60ffbb62ee48
parts_sha256: adf3f7221a131e270f963fab153a2e2f56262932f1e272af9cbc0e4814d5c8a6
design_rules_sha256: 02c4ed58432368b92e3019a06bf20c137dbf90765af16c96c458790e88d54a9f
"""
report+='subject_raw_sha256: '+subject['raw_sha256']+'\nsubject_semantic_sha256: '+subject['semantic_sha256']+'\n\n'
report+='Limited group coverage: U1 and U2 only, every commissioned instance checked. SOUND means these two parts pass the commissioned pin/function/net-kind review. No whole-board acceptance or permission to order. Board/parts/rules hashes above are immutable subject metadata, not independently reviewed conclusions.\n\n'
for ref in ['U1','U2']:
 report+=f'## {ref}\n\nVERDICT: PASS\n\n';doc=source[0 if ref=='U1' else 1]
 report+=f"Primary PDF: `{doc['path']}`; SHA-256 `{doc['sha256']}`.\n\n"
 if ref=='U1':
  report+='Sources: PDF page 5 Figure 5-5 and Pin Functions: OPA1679; PDF pages 44/45 D0014A package outline/example board layout. PDF page 29 package option addendum maps OPA1679IDR to SOIC (D), 14 pins.\n\n'
 else:
  report+='Sources: PDF page 4 Section 5 DGN top-view pin drawing and Pin Functions; PDF pages 33/34 DGN0008D package outline/example board layout. PDF page 24 package option addendum maps TPS7A4901DGNR to HVSSOP (DGN), 8 leads.\n\n'
 report+=package_findings[ref]+'\n\n'
 if ref=='U1':
  report+='Some dossier side labels say N/S because of directional sectors; actual coordinates establish two vertical lead rows and correct winding. Native pitch is 1.27 mm, agreeing with the package. The native 1.95 x 0.60 mm lands centered 4.96 mm apart span the manufacturer lead locations; no identity or mirror defect. D package has no thermal pad; QFN pad requirements are not applied to this SOIC.\n\n'
 else:
  report+='The native 90-degree placement rotation is undone in the dossier and does not mirror the package. On PDF page 33, the upper package drawing has pin1 upper-left; lower drawing shows underside exposed pad with pin1 lower-left. Board top-view numbering uses the upper drawing and PDF page34 land pattern. Native center pad9 is 1.57 x 1.89 mm, consistent with the DGN0008D exposed-pad land, and connected to GND as permitted. Rounded lead coordinates agree with 0.65 mm pitch. Physical PowerPAD identity9 is retained separately from GND pin4.\n\n'
 for f in findings:
  if f['ref']==ref and f['pin'].isdigit():report+=f"- {ref} pin {f['pin']} ({f['function']}): expected {f['expected']}; observed `{f['observed']}` — PASS.\n"
 report+='\n'
report+='## Scope and retained evidence\n\nExactly one instance of each part is commissioned; same-part cross-instance symmetry is not applicable. U1 channels A/D have matching output/inverting-input buffer nets; B/C have corresponding output and feedback net kinds. All 23 physical electrical identities are individually retained.\n\nU2 NC pin3 and DNC pin7 carry native `unconnected-(...)` markers, consistent with no-connect intent. These markers are not evidence of a routed external connection. This review accepts per-pin net kinds and does not establish hidden topology, required output/NR capacitor presence or values, rail magnitudes, or analog loop behavior. No pin/function mismatch or required pin-review QUESTION was identified.\n\nIndependent pin derivation was recorded from source images before dossier content was read. All six inspected PNGs, extracted primary text, native dossier copies, exact input digests, derivation, measured rows, methods, finite subprocess commands/raw logs/runtime, report and evidence JSON are retained in evidence.tar.gz. Whole PDFs remain in the digest-bound frozen input packet. Every envelope input is size/hash verified before and after review. The three checks in result.json describe complete honest handback, not whole-board engineering acceptance.\n'
(out/'report.md').write_text(report);(out/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n');(s/'methods.json').write_text(json.dumps(methods,indent=2)+'\n')
for p in s.glob('*-runtime.json'):
 d=json.loads(p.read_text());d.setdefault('cwd',str(s));d.setdefault('environment',{'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8'});p.write_text(json.dumps(d,indent=2)+'\n')
checks=[]
for x in envelope['input_packet']:
 b=(r/x['path']).read_bytes();sha=hashlib.sha256(b).hexdigest();assert len(b)==x['size'] and sha==x['sha256'];checks.append(dict(path=x['path'],size=len(b),sha256=sha,verified=True))
(s/'inputs-after.json').write_text(json.dumps(checks,indent=2)+'\n')
archive=out/'evidence.tar.gz';files=[(p,'evidence/'+p.relative_to(s).as_posix()) for p in sorted(s.rglob('*')) if p.is_file() and not p.name.startswith(('package-run','preflight-run'))];files += [(out/'report.md','report.md'),(out/'evidence.json','evidence.json')]
assert len({name for p,name in files})==len(files)
with tarfile.open(archive,'w:gz') as tf:
 for p,name in files:assert not p.is_symlink();tf.add(p,arcname=name,recursive=False)
members=[];filemap={name:p for p,name in files}
with tarfile.open(archive,'r:gz') as tf:
 seen=set()
 for m in tf.getmembers():
  assert m.isfile() and not m.issym() and not m.islnk();assert not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts and m.name not in seen;assert not m.name.endswith(('.tar','.tar.gz','.tgz'));seen.add(m.name);b=tf.extractfile(m).read();assert len(b)==m.size and b==filemap[m.name].read_bytes();members.append(dict(path=m.name,size=len(b),sha256=hashlib.sha256(b).hexdigest()))
manifest=dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_size=archive.stat().st_size,member_count=len(members),members=members)
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(out/'result.json').write_text(json.dumps(dict(subject=subject,checks={c:'PASS' for c in envelope['completion']['checks']},unresolved=[]),indent=2)+'\n')
print(json.dumps(dict(verdict='SOUND',outputs=str(out),archive_sha256=manifest['archive_sha256'],archive_size=manifest['archive_size'],member_count=manifest['member_count']),indent=2))
