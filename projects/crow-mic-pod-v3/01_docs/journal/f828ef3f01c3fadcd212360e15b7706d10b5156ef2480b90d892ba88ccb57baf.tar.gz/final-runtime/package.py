from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,datetime,shutil,re
R=Path('/tmp/rj45-pod-topology-review-fabfeatures1-wbde9ygx');S=Path(__file__).parent;O=S.parent/'outputs';E=json.loads((S.parent/'envelope.json').read_text());hashes=json.loads((S/'recomputed-hashes.json').read_text());delta=json.loads((S/'file-comparison.json').read_text());graph=json.loads((S/'graph-evidence.json').read_text());rating=json.loads((S/'source-rating-evidence.json').read_text());pixel=json.loads((S/'pixel-equivalence.json').read_text());tol=json.loads((S/'tolerance-evidence.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(json.dumps(E,sort_keys=True,separators=(',',':')).encode())=='5838ad85acb9286472a3b1f01b840cc583626cc18e4c1adf5b78fca3149934ea'
checks=[]
for row in E['input_packet']:
 b=(R/row['path']).read_bytes();checks.append({'path':row['path'],'size':len(b),'sha256':sha(b),'pass':len(b)==row['size'] and sha(b)==row['sha256']})
assert all(x['pass'] for x in checks);(S/'input-verification-after.json').write_text(json.dumps({'count':len(checks),'verified':len(checks),'files':checks},indent=2))
assert len(graph['current']['components'])==40 and graph['nets_equal'] and not graph['component_deltas'] and all(x['pass'] for x in graph['invariants']) and all(x['pass'] for x in tol)
assert all(x['outside_band_changed_pixels']==0 and x['body_sha256_current']==x['body_sha256_accepted'] for x in pixel)
assert hashes==json.loads((R/'expected-subject.json').read_text())
assert 4.79<rating['maths']['ldo_min_v']<rating['maths']['ldo_max_v']<5.23
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
body=(S/'review-body.md').read_text().replace('Of 124 common supplied paths, 116 are byte-identical',f"Of {len(delta['equal'])+len(delta['changed'])} common supplied paths, {len(delta['equal'])} are byte-identical").replace('3302/3366/3407/3379','/'.join(str(x['changed_pixels']) for x in pixel))
body=body.replace('Full-page changed-pixel counts are','Using any nonzero RGB-channel difference, full-page changed-pixel counts are')
report='\n'.join(['review_stage: pre-route','review_kind: topology','reviewer: /root/carrier_rj45_native_pod_topology_fabfeatures1','reviewer_identity: /root/carrier_rj45_native_pod_topology_fabfeatures1','context: FRESH','date: '+now,'design_verdict: SOUND','order_verdict: DO-NOT-ORDER']+[k+': '+v for k,v in hashes.items()])+'\n\n'+body
(O/'report.md').write_text(report)
evidence={'schema':1,'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','review_stage':'pre-route','review_kind':'topology','reviewer_identity':'/root/carrier_rj45_native_pod_topology_fabfeatures1','context':'FRESH','date':now,'subject':E['subject'],'envelope_canonical_sha256':'5838ad85acb9286472a3b1f01b840cc583626cc18e4c1adf5b78fca3149934ea','subject_hashes':hashes,'inputs_verified_before_and_after':293,'methods':['Independent s-expression parser for native full component/node census and UUID-only schematic comparison','Independent TSX pin extraction and CircuitJSON connectivity-key mapping against current native graph','All 39 maintained invariant rows applied to current native graph plus 12 independent dossier tolerance checks','All 34 dossier semantic comparisons and 33 fitted-ref footprint/supplier reconciliation','Complete frozen common-path byte comparison, all changed source hunks and adopted before/after hashes','130 dpi Poppler rendering, any-nonzero RGB-channel equality of all four accepted/current pages and visual current-page/header/detail inspection','Manufacturer pin figures visually rederived for J1/U1/U2/U3; signed-feedback KCL and current rating arithmetic','Frozen owner recomputation of all seven exact review hashes and all seven schematic-checkpoint file receipts'],'counts':{'components_current':40,'components_accepted':40,'nets_current':24,'nets_accepted':24,'nodes_current':103,'nodes_accepted':103,'authored_connected_pins':99,'no_connects':4,'invariants_passed':39,'invariants_total':39,'tolerances_passed':12,'fitted_first_power':33,'machine_smt':31,'manual':2,'testpads_excluded':7,'board_only_holes':2,'part_dossiers':34,'rendered_pages':4,'rendered_body_pixels':sum(x['body_pixel_count'] for x in pixel),'changed_body_pixels':0},'file_comparison':delta,'graph_evidence':graph,'rating_evidence':rating,'pixel_equivalence':pixel,'tolerance_checks':tol,'findings':[],'limitations':['Pre-route schematic judgment only; no routing, placement, human orientation, release, allocation or order authority','SOURCE PASS; pod FULL INCOMPLETE nine physical obligations; carrier 23 and LAYOUT001 closed3/3 are preserved commissioned context','FIRST-ARTICLE-ONLY/DO-NOT-ORDER; no additional physical-measurement prerequisite before fabrication','Full nominal Fab extent and native sampling limitations do not prove manufacturing or installed fit','ERC remains zero errors and158 classified warnings, not all-severity clean','Native files independently parsed and compared; delivered ERC read and classified, not rerun','Runtime bounded, not hermetic'],'method_corrections':['Initial reviewer parts hash omitted path/NUL framing; corrected to frozen owner and all seven hashes verified','Initial reviewer feedback-current arithmetic had the wrong sign; KCL and TI page6 note3 corrected final corners to4.79258697..5.22951273V','Final pixel census uses any nonzero RGB channel rather than luminance rounding; outside-band and body equality remain zero'],'unchanged_evidence_provenance':{'accepted_subject':'accepted-subject orientation1 frozen input packet','accepted_readability_receipt_sha256':sha((R/'accepted-receipts/readability/report.md').read_bytes()),'use':'prior unresolved readability check only; independently measured current equality and visual inspection','source_adoption_sha256':sha((R/'decision-context/jack-fab-source-adoption.json').read_bytes())}}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(O/'result.json').write_text(json.dumps({'subject':E['subject'],'checks':{k:'PASS' for k in E['completion']['checks']},'unresolved':[]},indent=2)+'\n')
shutil.copyfile(S.parent/'envelope.json',S/'frozen-envelope.json')
shutil.copyfile(R/'expected-subject.json',S/'frozen-expected-subject.json')
skip={'package.log','package-runtime.json'}
members=[]
for p in sorted(S.iterdir()):
 if p.name in skip or p.name.startswith('preflight'):continue
 assert p.is_file() and not p.is_symlink() and not p.name.endswith(('.tar','.gz','.zip'))
 members.append(('scratch/'+p.name,p))
members.extend((p.name,p) for p in [O/'report.md',O/'evidence.json',O/'result.json'])
manifest_rows=[{'path':name,'size':p.stat().st_size,'sha256':sha(p.read_bytes())} for name,p in members]
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for name,p in members:tf.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 seen=set();opened=[]
 for m in tf.getmembers():
  path=PurePosixPath(m.name);assert m.isfile() and not m.issym() and not m.islnk() and not path.is_absolute() and '..' not in path.parts and m.name not in seen;seen.add(m.name)
  b=tf.extractfile(m).read();opened.append({'path':m.name,'size':len(b),'sha256':sha(b)});assert len(b)==m.size
 assert opened==manifest_rows
manifest={'archive_sha256':sha(archive.read_bytes()),'archive_size':archive.stat().st_size,'member_count':len(manifest_rows),'members':manifest_rows,'verification':'Every regular member independently reopened after archive close; sizes/digests equal expected bytes; no links, traversal, duplicates or recursive archives.'}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert set(x.name for x in O.iterdir())=={'report.md','evidence.json','evidence-manifest.json','evidence.tar.gz','result.json'}
print(json.dumps({'verdict':'SOUND','outputs':str(O),'archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'member_count':manifest['member_count'],'common_files':len(delta['equal'])+len(delta['changed']),'unchanged_files':len(delta['equal']),'current_rating_corners':[rating['maths']['ldo_min_v'],rating['maths']['ldo_max_v']]},indent=2))
