from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[4]
RUN = ROOT / "06_build/task_runs/rj45-pin-pod-interface-s1m1"
SCRATCH = RUN / "scratch"
OUTPUTS = RUN / "outputs"
ENVELOPE_PATH = RUN / "envelope.json"
sys.path.insert(0, "/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts")
from pipeline_execution import TaskEnvelope, verify_input_packet


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


envelope = TaskEnvelope.from_json(ENVELOPE_PATH.read_text())
ok_before, findings_before = verify_input_packet(envelope, ROOT)
if not ok_before:
    raise SystemExit("input verification failed before packaging: " + "; ".join(findings_before))

completed_at = datetime.now(timezone.utc).isoformat()
bindings = {
    "board_sha256": "af9bb3c0dcf5e9be20239d725d10dd4d4c1bf95cc0b7518badc3e27bd6523938",
    "parts_sha256": "d0d0026dd67cbfaa98176799ea34ea3bfde384675d74d58d8cf8f0c88e41fd89",
    "design_rules_sha256": "474e5d0a81baf576aefac32e9c60bce37704bb138961c16bf92573843b6409c4",
}
datasheet = ROOT / "projects/crow-mic-pod-v3/02_parts/TPD2E2U06DRLR/tpd2e2u06.pdf"
dossier = ROOT / "dossiers/U3.md"
report = f"""review_stage: pre-route
review_kind: pin
reviewer: rj45_pin_pod_interface_s1m1 fresh independent reviewer
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: {bindings['board_sha256']}
parts_sha256: {bindings['parts_sha256']}
design_rules_sha256: {bindings['design_rules_sha256']}
completed_at: {completed_at}

# Fresh independent pin review — pod-interface

Limited group coverage: **U3 only** (`TPD2E2U06DRLR`). This is not whole-board acceptance.

## U3 — VERDICT: PASS

- Measured native identities: **5 pads / 5 physical pin identities / 0 aliases / 0 fused identities**. Datasheet expects five pins; there is no exposed pad.
- Primary document: Texas Instruments `TPD2E2U06` SLLSEG9C, SHA-256 `{sha(datasheet)}`. Actual figure inspection used PDF page 3, **DRL Package 5-Pin SOT Top View** and **Pin Functions**; PDF page 17, **DRL0005A Package Outline** with PIN 1 ID AREA; and PDF page 18, **DRL0005A Land Pattern Example**.
- Package and winding: expected top view pin 1 at the upper-left, pins 1/2/3 on the west edge from north to south, and pins 4/5 on the east edge from south to north, giving CCW winding. Observed component-top dossier is front-mounted and uses exactly NW/W/SW/SE/NE for pins 1/2/3/4/5, also CCW. No mirror or bottom-view conversion is involved.
- U3 pin 1 (NC): expected NC, permissible left floating; observed dedicated pad 1 on `unconnected-(U3-NC1-Pad1)`. PASS.
- U3 pin 2 (NC): expected NC, permissible left floating; observed dedicated pad 2 on `unconnected-(U3-NC2-Pad2)`. PASS.
- U3 pin 3 (IO1): expected one protected data-line channel; observed `AUDIO_P`. PASS.
- U3 pin 4 (GND): expected ground; observed `GND`. PASS.
- U3 pin 5 (IO2): expected the other protected data-line channel; observed `AUDIO_N`. PASS.
- Pairwise symmetry: not applicable because the commissioned group contains one instance. IO1/IO2 form the two protected channels and map symmetrically to the positive and negative audio conductors.

No unresolved findings. The domain verdict is SOUND because the sole commissioned reference passes package winding, pin-1, identity census, and function-to-net checks. The order verdict remains DO-NOT-ORDER as commissioned.
"""

evidence = {
    "verdict": "SOUND",
    "subject": dict(envelope.subject.to_mapping()),
    "immutable_subject_bindings": bindings,
    "scope": {"group": "pod-interface", "refs": ["U3"], "whole_board_acceptance": False},
    "methods": [
        "Verified every envelope input by size and SHA-256 before and after the review packaging step.",
        "Rendered exact SHA-selected TI datasheet PDF pages with pdftoppm at 160 dpi under pipeline_runtime.run_stage.",
        "Inspected rendered PDF page 3 pin configuration and functions, page 17 package outline and pin-1 ID area, and page 18 land pattern figure visually.",
        "Derived the expected top-view pin sequence independently before comparing the front-mounted component-top dossier.",
        "Compared every physical pin identity and function to the dossier net; checked exposed-pad requirements, aliases, and applicable instance symmetry.",
    ],
    "sources": [{
        "path": "projects/crow-mic-pod-v3/02_parts/TPD2E2U06DRLR/tpd2e2u06.pdf",
        "sha256": sha(datasheet),
        "pages_and_figures": [
            "PDF page 3: DRL Package 5-Pin SOT Top View and Pin Functions",
            "PDF page 17: DRL0005A Package Outline and PIN 1 ID AREA",
            "PDF page 18: DRL0005A Land Pattern Example",
        ],
    }],
    "measured_counts": {
        "commissioned_refs": 1,
        "refs_pass": 1,
        "refs_fail": 0,
        "refs_question": 0,
        "native_pads": 5,
        "physical_pin_identities": 5,
        "declared_aliases": 0,
        "fused_identities": 0,
        "exposed_pads_expected": 0,
        "exposed_pads_observed": 0,
    },
    "findings": [{
        "ref": "U3",
        "verdict": "PASS",
        "part": "TPD2E2U06DRLR",
        "package": "DRL 5-pin SOT",
        "mounted_side": "front",
        "expected": {
            "view": "manufacturer top view",
            "pin1_corner": "upper-left / northwest",
            "winding": "CCW",
            "sides": {"1": "W/NW", "2": "W", "3": "W/SW", "4": "E/SE", "5": "E/NE"},
            "functions": {"1": "NC", "2": "NC", "3": "IO1", "4": "GND", "5": "IO2"},
        },
        "observed": {
            "component_top_winding": "CCW",
            "sides": {"1": "W/NW", "2": "W", "3": "W/SW", "4": "E/SE", "5": "E/NE"},
            "functions_and_nets": {
                "1": "NC -> unconnected-(U3-NC1-Pad1)",
                "2": "NC -> unconnected-(U3-NC2-Pad2)",
                "3": "IO1 -> AUDIO_P",
                "4": "GND -> GND",
                "5": "IO2 -> AUDIO_N",
            },
        },
        "physical_identity_counts": {"expected": 5, "observed": 5, "aliases": 0, "fused": 0},
        "exposed_pad": "none expected; none observed",
        "instance_symmetry": "not applicable; one commissioned instance",
        "unresolved": [],
    }],
    "unresolved": [],
    "completed_at": completed_at,
}

OUTPUTS.mkdir(parents=True, exist_ok=True)
(OUTPUTS / "report.md").write_text(report)
write_json(OUTPUTS / "evidence.json", evidence)
write_json(OUTPUTS / "result.json", {
    "subject": dict(envelope.subject.to_mapping()),
    "checks": {"inputs-verified": "PASS", "review-complete": "PASS", "evidence-complete": "PASS"},
    "unresolved": [],
})

stage = SCRATCH / "evidence_stage"
stage.mkdir(parents=True, exist_ok=True)
copies = {
    dossier: stage / "inputs/U3.md",
    SCRATCH / "page-03.png": stage / "figures/page-03-pin-configuration.png",
    SCRATCH / "page-17.png": stage / "figures/page-17-package-outline.png",
    SCRATCH / "page-18.png": stage / "figures/page-18-land-pattern.png",
    SCRATCH / "render_inputs.py": stage / "methods/render_inputs.py",
    SCRATCH / "render_page17.py": stage / "methods/render_page17.py",
    SCRATCH / "package_review.py": stage / "methods/package_review.py",
    SCRATCH / "render-runtime.json": stage / "runtime/render-runtime.json",
    SCRATCH / "page17-runtime.json": stage / "runtime/page17-runtime.json",
    SCRATCH / "pdfinfo.log": stage / "runtime/pdfinfo.log",
    SCRATCH / "pdftotext.log": stage / "runtime/pdftotext.log",
    SCRATCH / "page3.log": stage / "runtime/page3.log",
    SCRATCH / "page17.log": stage / "runtime/page17.log",
    SCRATCH / "page18.log": stage / "runtime/page18.log",
    OUTPUTS / "report.md": stage / "conclusions/report.md",
    OUTPUTS / "evidence.json": stage / "conclusions/evidence.json",
    OUTPUTS / "result.json": stage / "conclusions/result.json",
}
for source, target in copies.items():
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)

input_records = [{"path": item.path, "size": item.size, "sha256": item.sha256} for item in envelope.input_packet]
write_json(stage / "inputs/input-verification.json", {
    "before": "PASS",
    "after": "PENDING",
    "envelope_sha256": sha(ENVELOPE_PATH),
    "records": input_records,
})

ok_after, findings_after = verify_input_packet(envelope, ROOT)
if not ok_after:
    raise SystemExit("input verification failed after packaging: " + "; ".join(findings_after))
write_json(stage / "inputs/input-verification.json", {
    "before": "PASS",
    "after": "PASS",
    "envelope_sha256": sha(ENVELOPE_PATH),
    "records": input_records,
})

archive = OUTPUTS / "evidence.tar.gz"
with archive.open("wb") as raw:
    with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode="w") as tar:
            for path in sorted(p for p in stage.rglob("*") if p.is_file()):
                rel = path.relative_to(stage).as_posix()
                info = tar.gettarinfo(str(path), arcname=rel)
                info.uid = info.gid = 0
                info.uname = info.gname = ""
                info.mtime = 0
                with path.open("rb") as stream:
                    tar.addfile(info, stream)

members = []
seen = set()
with tarfile.open(archive, "r:gz") as tar:
    for member in tar.getmembers():
        if not member.isfile() or member.issym() or member.islnk():
            raise SystemExit(f"non-regular evidence member: {member.name}")
        pure = Path(member.name)
        if pure.is_absolute() or ".." in pure.parts or member.name in seen:
            raise SystemExit(f"unsafe/duplicate evidence member: {member.name}")
        seen.add(member.name)
        extracted = tar.extractfile(member)
        if extracted is None:
            raise SystemExit(f"could not reopen evidence member: {member.name}")
        data = extracted.read()
        members.append({"path": member.name, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()})

write_json(OUTPUTS / "evidence-manifest.json", {
    "archive_sha256": sha(archive),
    "archive_size": archive.stat().st_size,
    "member_count": len(members),
    "members": members,
})
