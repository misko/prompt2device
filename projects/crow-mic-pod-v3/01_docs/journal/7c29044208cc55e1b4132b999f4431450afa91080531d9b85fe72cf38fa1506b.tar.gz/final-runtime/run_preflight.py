from pathlib import Path
import json
import os
import sys

ROOT = Path(__file__).resolve().parents[4]
SCRATCH = Path(__file__).resolve().parent
sys.path.insert(0, "/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts")
from pipeline_runtime import run_stage

spec = {"id": "REVIEW-PREFLIGHT", "work_class": "local", "timeout_s": 60, "produces": []}
outcome = run_stage(
    spec,
    ["/usr/bin/python3", "-B", str(ROOT / "preflight.py"), str(ROOT / "06_build/task_runs/rj45-pin-pod-interface-s1m1/envelope.json")],
    log_path=SCRATCH / "preflight.log",
    cwd=ROOT,
    env=dict(os.environ),
    run_id="final-preflight",
)
(SCRATCH / "preflight-runtime.json").write_text(json.dumps(outcome.to_mapping(), indent=2, sort_keys=True) + "\n")
if outcome.status != "PASS":
    raise SystemExit(1)
