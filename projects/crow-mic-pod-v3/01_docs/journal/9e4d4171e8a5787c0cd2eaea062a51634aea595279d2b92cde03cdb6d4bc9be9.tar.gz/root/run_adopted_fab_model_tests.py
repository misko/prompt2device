from pathlib import Path
import os,sys,json,dataclasses,types,runpy
N=Path(__file__).parent
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
assert (N/'jack-fab-source-adoption.json').is_file()
sys.path[:0]=[str(R/'tests'),str(R/'skills/pcb-design/scripts')]
import harness
from pipeline_runtime import run_stage
out=N/'adopted-fab-model-tests';out.mkdir(exist_ok=False)
tmp=out/'tmp';tmp.mkdir();os.environ['TMPDIR']=str(tmp)
base={k:os.environ[k] for k in ['PATH','HOME']}
base.update(LANG='C.UTF-8',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(tmp))
counter=0
def bounded(args,cwd=None,env=None,timeout=300):
    global counter
    counter+=1;name=f'child-{counter:04d}';args=[str(a) for a in args]
    if args[0]=='/usr/bin/python3' and '-B' not in args:args.insert(1,'-B')
    e=dict(base);e.update(env or {});cwd=str(cwd or R)
    (out/(name+'-command.json')).write_text(json.dumps({'argv':args,'cwd':cwd,'environment_keys':sorted(e),'timeout_s':min(timeout,300)},indent=2)+'\n')
    r=run_stage({'id':name,'work_class':'local','timeout_s':min(timeout,300)},args,log_path=out/(name+'.log'),cwd=cwd,env=e,console=None)
    (out/(name+'-result.json')).write_text(json.dumps(dataclasses.asdict(r),default=str,indent=2)+'\n')
    return harness.Run(types.SimpleNamespace(returncode=r.returncode if r.returncode is not None else 99,stdout=(out/(name+'.log')).read_text(),stderr=''))
harness.run=bounded
sys.argv=[str(R/'tests/t1_model_registration.py'),'--slow']
runpy.run_path(str(R/'tests/t1_model_registration.py'),run_name='__main__')
