"""Adopt exact independently accepted source; never use pending author output."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,tarfile,ast
N=Path(__file__).parent
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
sha=lambda b:hashlib.sha256(b).hexdigest()
metas={}
for name in ['rj45-jack-fab-feature-source','rj45-jack-fab-source-review']:
 m=json.loads((N/(name+'-opened.json')).read_text());E=Path(m['envelope']);D=Path(m['project']);env=json.loads(E.read_text())
 assert json.loads((E.parent/'attempt.json').read_text())['status']=='PASS'
 for row in env['input_packet']:
  p=D/row['path'];b=p.read_bytes();assert not p.is_symlink() and len(b)==row['size'] and sha(b)==row['sha256']
 c=json.loads((N/(name+'-closeout-summary.json')).read_text())
 assert c['delivery_status']=='PASS' and sha(Path(c['archive']).read_bytes())==c['sha256']
 metas[name]=(m,c,env)
am,ac,ae=metas['rj45-jack-fab-feature-source'];rm,rc,re=metas['rj45-jack-fab-source-review']
review=json.loads((Path(rm['output_dir'])/'evidence.json').read_text())
assert review['subject']==re['subject']
assert review['domain_result']=='SOUND — exact 12-file nominal Fab source proposal only; downstream and physical holds remain.'
author_archive=Path(am['output_dir'])/'evidence.tar.gz'
assert sha(author_archive.read_bytes())==sha((Path(rm['project'])/'author/evidence.tar.gz').read_bytes())
expected=json.loads((N/'jack-fab-candidate-files.json').read_text())
assert expected and len({row['path'] for row in expected})==len(expected)
allowed={
 'skills/jlcpcb-fab/scripts/native_model_registration.py',
 'skills/jlcpcb-fab/references/digital-twin.md',
 'skills/jlcpcb-fab/scripts/contracts.md',
 'tests/t1_model_registration.py','tests/README.md',
}
for slug,lib in [('crow-audio-carrier-v1','crow_audio_carrier'),('crow-mic-pod-v3','crow_mic_pod_v3')]:
 for rel in ['03_src/lib/'+lib+'.pretty/Wurth_615008160221_RJ45.kicad_mod','02_parts/615008160221/part.yaml','02_parts/615008160221/primary-source-record.md','03_src/lib/3dmodels/wurth/provenance.md']:
  allowed.add('projects/'+slug+'/'+rel)
plans=[]
with tarfile.open(author_archive) as t:
 names=[m.name for m in t.getmembers() if m.name.startswith('source_candidate/')]
 assert sorted(n.removeprefix('source_candidate/') for n in names)==sorted(row['path'] for row in expected)
 for row in expected:
  rel=row['path'];assert rel in allowed and not Path(rel).is_absolute() and '..' not in Path(rel).parts
  before=t.extractfile('beforeimages/'+rel).read();after=t.extractfile('source_candidate/'+rel).read()
  assert sha(before)==row['before_sha256'] and sha(after)==row['after_sha256']
  assert (R/rel).read_bytes()==before
  if rel.endswith('/native_model_registration.py'):
   old=ast.parse(before);new=ast.parse(after)
   assert isinstance(old.body[0],ast.Expr) and isinstance(new.body[0],ast.Expr)
   assert isinstance(old.body[0].value,ast.Constant) and isinstance(old.body[0].value.value,str)
   assert isinstance(new.body[0].value,ast.Constant) and isinstance(new.body[0].value.value,str)
   old.body=old.body[1:];new.body=new.body[1:]
   assert ast.dump(old)==ast.dump(new),'Extraction implementation must remain unchanged'
  if rel=='tests/t1_model_registration.py':
   old={n.name:ast.dump(n) for n in ast.parse(before).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
   new={n.name:ast.dump(n) for n in ast.parse(after).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
   assert all(new.get(k)==v for k,v in old.items()),'Previous test/helper bodies must remain unchanged'
  plans.append((rel,before,after))
footprints=[after for rel,before,after in plans if rel.endswith('Wurth_615008160221_RJ45.kicad_mod')]
assert len(footprints)==2 and footprints[0]==footprints[1]
record={'created_at':datetime.now(timezone.utc).isoformat(),'author_archive':ac['sha256'],'review_archive':rc['sha256'],'review_subject':re['subject'],'files':expected,'claim':'Exact independently SOUND shared Fab feature source adopted. Original extraction implementation and all old tests remain unchanged; new sampling vacuity is explicit. Exact-product supplemental geometry evidence applies only to reviewed inputs. Normal shared renewal and final explicit user orientation review remain owed; no routing/release/order/physical acceptance.'}
for rel,before,after in plans:assert (R/rel).read_bytes()==before
for rel,before,after in plans:(R/rel).write_bytes(after)
for rel,before,after in plans:assert (R/rel).read_bytes()==after
(N/'jack-fab-source-adoption.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
