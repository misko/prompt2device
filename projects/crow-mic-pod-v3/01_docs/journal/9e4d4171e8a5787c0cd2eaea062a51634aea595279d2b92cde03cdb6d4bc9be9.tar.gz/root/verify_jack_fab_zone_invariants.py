from pathlib import Path
import re,json,tarfile,hashlib,collections
N=Path(__file__).parent
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
m=json.loads((N/'rj45-jack-fab-feature-source-opened.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
def parse(text):
    tokens=re.findall(r'"(?:\\.|[^"\\])*"|[()]|[^\s()]+',text)
    stack=[];roots=[]
    for token in tokens:
        if token=='(':
            node=[]
            (stack[-1] if stack else roots).append(node);stack.append(node)
        elif token==')':
            assert stack;stack.pop()
        else:
            assert stack;stack[-1].append(token)
    assert not stack and len(roots)==1 and roots[0][0]=='kicad_pcb'
    return roots[0]
def without_id(node):
    if not isinstance(node,list):return node
    return [without_id(x) for x in node if not (isinstance(x,list) and x and x[0] in ['uuid','tstamp'])]
def key(node):return json.dumps(without_id(node),separators=(',',':'))
rows=[]
with tarfile.open(Path(m['output_dir'])/'evidence.tar.gz') as t:
    for slug,board in [('crow-audio-carrier-v1','crow_audio_carrier_v1'),('crow-mic-pod-v3','crow_mic_pod_v3')]:
        live=R/'projects'/slug/'04_kicad'/(board+'.kicad_pcb')
        old=live.read_bytes();new=t.extractfile('generated/'+slug+'/04_kicad/'+board+'.kicad_pcb').read()
        trees=[parse(b.decode()) for b in [old,new]]
        zones=[[x for x in tree if isinstance(x,list) and x and x[0]=='zone'] for tree in trees]
        multisets=[collections.Counter(map(key,z)) for z in zones]
        missing=list((multisets[0]-multisets[1]).elements());added=list((multisets[1]-multisets[0]).elements())
        row={'project':slug,'before_sha256':sha(old),'candidate_sha256':sha(new),'zones_before':len(zones[0]),'zones_after':len(zones[1]),'complete_zone_serialization_equal_excluding_uuid':multisets[0]==multisets[1], 'missing_zones':[json.loads(x) for x in missing],'added_zones':[json.loads(x) for x in added], 'method':'Parse every top-level native serialized zone, preserving all source properties, contours, holes, layer/net identifiers and actual stored filled polygons; compare multisets after removing only uuid/tstamp fields. This does not grade routing completion.'}
        rows.append(row)
        print(slug,'zone count',len(zones[0]),len(zones[1]),'full source/fill equal',row['complete_zone_serialization_equal_excluding_uuid'],'missing/added',len(missing),len(added))
(N/'jack-fab-zone-invariants.json').write_text(json.dumps(rows,indent=2)+'\n')
