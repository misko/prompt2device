# Native model physical registration — `native_top.png`

board_sha256: a9b454cf9951e4c8e62c3ea1e73bbcaf40eaf2476bf5df13fb844997ffda8501
coupon_sha256: df299e7fcf3f3f9b2f4e66e4f99a2ec195d5a3b333f53d39bc82a9a853bca692
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 17cbdea22e6ca94e56fb0facf4c7642df6b57fb94bc9835af2bbe51b7e712aba
footprint_registration_datum_sha256: e49c775a4163d6d43bd082b2ece99253a248f7472b2146c6ea813ce8d20cbf93
model_transform_sha256: 7bec69e2383a2ada8dc687bc933257dbc1493ae260d58b3b60be9bbc2f0127c7
registration_contract_sha256: 042e9ef939d33180e4b9689fcd0e60ed3058e3a124bd8e0f1886b020afd63444
tuple_cache_key: b859fccab5d71934399091f7f6d567b51ba6a7c936e392a5091f27c8aa509149
calibration_px_per_mm: 20.4061 x, 20.4017 y
anisotropy: 1.0002
fit_tolerance_mm: 1.000
courtyard_containment_tolerance_mm: 0.250
registration_datum: drilled_centres
mount_side: not-graded
actual_footprint_side: front
plan_camera: top
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: N/A
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected drilled_centres field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | registration centres inside | min pad margin mm |
|---|---:|---:|---:|---:|---:|
| J2 | 5.001 | 4.609 | 4.164 | 2/5 | -4.378 |

## Failures

- J2: body/F.Fab centre delta 5.001 mm
- J2: body exceeds F.Fab by 4.609 mm
- J2: body exceeds F.CrtYd by 4.164 mm
- J2: drilled_centres outside body: ['1', '2', '4']
