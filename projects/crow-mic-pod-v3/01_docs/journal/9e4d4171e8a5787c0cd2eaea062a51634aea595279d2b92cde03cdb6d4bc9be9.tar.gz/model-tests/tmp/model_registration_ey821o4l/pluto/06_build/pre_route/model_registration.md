# Project native model physical registration

board_sha256: 8e95d03ff973c5b80cba72d16decc09312c60400b0bd88678091e484f01d80ef
a-render_verdict: PASS
registration_kind: P-MODEL-REG
config_sha256: 500cfab99e5300c40ab9136ae027393a8d0ce0cc5662a9cdcb13c0d5c421e6df
stage_receipt: 06_build/pre_route/model_registration.stage.json
accepted_bundle: 06_build/pre_route/model_registration_bundle/bundle.json

This aggregate is independent physical-registration evidence. Each group uses an origin-centred coupon and compares native-model pixels with mounted-side Fab/courtyard and each group's declared drilled-centre, all-pad-centre or SMD-overlap datum. Catalog-twin renderer fidelity is a separate gate.

| group | refs | tuple cache key | group report | result |
|---|---|---|---|---|
| shifted_sma | J2 | `0287e2ede22a8b0d1cb43a74b90519e8098f14327c34b65ac3cd05a11ea9f2eb` | `06_build/pre_route/native_registration/shifted_sma/native_model_registration.md` | PASS |
