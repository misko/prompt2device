# Twin render faithfulness — twin_top.png (`--side top`)

board_sha256: 8e95d03ff973c5b80cba72d16decc09312c60400b0bd88678091e484f01d80ef
a-render_verdict: PASS
- calibration: **10.7103 px/mm** x, **10.6912 px/mm** y, anisotropy **1.0018** (tol 0.02) — orthographic, projection valid
- board edge: 19.950..110.050 x, 19.950..85.050 y mm
- courtyards drawn (F.CrtYd): **37**; footprints with no courtyard on EITHER layer: 0
- **COVERAGE: 1 measured / 1 refs with an expected body** (0 unresolvable, 0 resolvable but NOT measured, 0 with no JLC model at all)
- tolerance: **1.00 mm** on both the centre delta and the outward excursion
- pixel measurement: **populated-minus-same-camera-bare RGB delta** (threshold 12)
- expected-model register: `adjudications.yaml` (1 LCSC transform entry)
- overlay: `twin_top_courtyard_overlay.png`

**Red** = footprint courtyard (what gets fabricated). **Amber** = a ref jlc_twin flagged. **Green** = EXPECTED body (mesh x JLC's own model transform x board placement). **Magenta** = MEASURED body (pixels). **Blue** = board edge.

A body outside its red box with green and magenta AGREEING is a **3D-model** defect with no board exposure — gerbers and CPL derive from pads, never from the model. Green and magenta DISAGREEING is a **render** defect: the picture is not the board, and any visual review done on it is void.

## Graded refs (1)

| ref | LCSC | fit | centre delta mm | outward mm | edge deltas L,T,R,B mm | body px | courtyard excursion mm |
|---|---|---|---|---|---|---|---|
| `J2` | C123 | UNAVAILABLE (no vendor pad comparison) | 0.262 | 0.094 | +0.33,-0.09,-0.42,-0.42 | 9074 | 0.150 |

