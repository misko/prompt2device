# Native model physical registration — `native_top.png`

board_sha256: 8e95d03ff973c5b80cba72d16decc09312c60400b0bd88678091e484f01d80ef
coupon_sha256: b3a73e4153be5167e4b74fd73c7d4a3fb87dd0e32c12417678016789301e94b6
a-render_verdict: PASS
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 17cbdea22e6ca94e56fb0facf4c7642df6b57fb94bc9835af2bbe51b7e712aba
footprint_registration_datum_sha256: 89702858239b94f9ec7f239b45d8ec82e16db9823bb582178e4306fcfbc1ac6f
model_transform_sha256: 233c621e94a0d847ccc36c7ceaac3f4abf8c6446c5ad7610b23212d7e1aa1af9
registration_contract_sha256: dd603f13805af2a7ba5b8ccc47896aeff6b70966d43f153d5eb803e13f2decf5
tuple_cache_key: 0287e2ede22a8b0d1cb43a74b90519e8098f14327c34b65ac3cd05a11ea9f2eb
calibration_px_per_mm: 20.4061 x, 20.4017 y
anisotropy: 1.0002
fit_tolerance_mm: 1.000
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_pad_centres
mount_side: front
actual_footprint_side: front
plan_camera: top
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 0.941769
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_pad_centres field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | registration centres inside | min pad margin mm |
|---|---:|---:|---:|---:|---:|
| J2 | 0.169 | 0.000 | 0.000 | 5/5 | 0.618 |

## Failures

- none
