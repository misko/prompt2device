# Project native model physical registration

board_sha256: 86a20d184738146abf6fb61d74782e73bb3d6536c4b24bcba4fbd6482b416869
a-render_verdict: PASS
registration_kind: P-MODEL-REG
config_sha256: ae97df6eff4c3374bd647383a37ba2dbc5753126473a76fba9e3837ae43eeb5c
stage_receipt: 06_build/pre_route/model_registration.stage.json
accepted_bundle: 06_build/pre_route/model_registration_bundle/bundle.json

This aggregate is independent physical-registration evidence. Each group uses an origin-centred coupon and compares native-model pixels with mounted-side Fab/courtyard and each group's declared drilled-centre, all-pad-centre or SMD-overlap datum. Catalog-twin renderer fidelity is a separate gate.

| group | refs | tuple cache key | group report | result |
|---|---|---|---|---|
| mounted | R1,R2,R3 | `eae18cc9ab17df62fefb6c0bea981e4b6913344621a065ea1e6409d808d162d5` | `06_build/pre_route/native_registration/mounted/native_model_registration.md` | PASS |
