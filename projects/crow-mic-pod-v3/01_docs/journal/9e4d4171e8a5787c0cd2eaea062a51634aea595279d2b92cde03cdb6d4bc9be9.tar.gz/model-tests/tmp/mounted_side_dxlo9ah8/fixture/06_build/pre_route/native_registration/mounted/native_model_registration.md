# Native model physical registration — `native_top.png`

board_sha256: 86a20d184738146abf6fb61d74782e73bb3d6536c4b24bcba4fbd6482b416869
coupon_sha256: d0347863f1f111aa7349072c842e243239ff08c26fd04dd08249f60aeb2fd7d3
a-render_verdict: PASS
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 34fdb7f7b0f1526f182eaf5666b8525ac77de01f2e17c0cf1ac501673d08af25
footprint_registration_datum_sha256: 950085ad69a62f72e98b327b655e19ce0c2c3c55f898c0f9dd3d365abc141f08
model_transform_sha256: b37be3f11458466bc6a2e172c3af793cd24dca6934fcce08cb6a702dd3ca01b2
registration_contract_sha256: 62fd96674e981b6c7120dc7d92f34e7255fb44fef2ff44e74b49fa5ec639a233
tuple_cache_key: eae18cc9ab17df62fefb6c0bea981e4b6913344621a065ea1e6409d808d162d5
calibration_px_per_mm: 43.5214 x, 43.4987 y
anisotropy: 1.0005
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_smd_pad_overlap
mount_side: back
actual_footprint_side: back
plan_camera: bottom
plan_projection: X-MIRRORED
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 1.000000
overlay: native_top_registration_overlay.png

Orange is B.CrtYd; green is the independent B.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_smd_pad_overlap field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond B.Fab mm | measured beyond courtyard mm | SMD pads overlapping model plan | minimum overlap mm2 |
|---|---:|---:|---:|---:|---:|
| R1 | 0.024 | 0.000 | 0.000 | 2/2 | 0.287 |
| R2 | 0.030 | 0.000 | 0.000 | 2/2 | 0.276 |
| R3 | 0.011 | 0.000 | 0.000 | 2/2 | 0.280 |

## Failures

- none
