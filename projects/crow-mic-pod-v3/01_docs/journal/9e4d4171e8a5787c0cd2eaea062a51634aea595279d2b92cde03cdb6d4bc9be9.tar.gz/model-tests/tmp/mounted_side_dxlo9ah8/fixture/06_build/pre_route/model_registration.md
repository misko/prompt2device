# Project native model physical registration

board_sha256: 86a20d184738146abf6fb61d74782e73bb3d6536c4b24bcba4fbd6482b416869
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
config_sha256: e7f527206545b91874b91db1333bd71fd6a7289ea6f018fb9e805fad91443ffc
stage_receipt: 06_build/pre_route/model_registration.stage.json
aggregate_bundle_unavailable: 06_build/pre_route/model_registration_bundle/bundle.json

This aggregate is independent physical-registration evidence. Each group uses an origin-centred coupon and compares native-model pixels with mounted-side Fab/courtyard and each group's declared drilled-centre, all-pad-centre or SMD-overlap datum. Catalog-twin renderer fidelity is a separate gate.

| group | refs | tuple cache key | group report | result |
|---|---|---|---|---|
| mounted | R1,R2,R3 | `450b4d11408cdd54775b88112a311f3ac992522dab38616845ca586e9805c3e4` | `06_build/pre_route/native_registration/failed_attempts/mounted-20260913T045401Z-c85a2b586a8d/native_model_registration.md` | FAIL |
