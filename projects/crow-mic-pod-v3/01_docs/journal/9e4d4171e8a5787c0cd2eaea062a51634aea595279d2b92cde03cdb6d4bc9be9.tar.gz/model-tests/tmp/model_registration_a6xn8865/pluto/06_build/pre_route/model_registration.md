# Project native model physical registration

board_sha256: b6c68a3e9b42ea38592193880c7e6e07d7a4f236594febbeee84661e784f8c84
a-render_verdict: PASS
registration_kind: P-MODEL-REG
config_sha256: a19df95c41049aee20472e3510a7e3b01e4b0fbcf24f4f6e9a03a0324ba967e5
stage_receipt: 06_build/pre_route/model_registration.stage.json
accepted_bundle: 06_build/pre_route/model_registration_bundle/bundle.json

This aggregate is independent physical-registration evidence. Each group uses an origin-centred coupon and compares native-model pixels with mounted-side Fab/courtyard and each group's declared drilled-centre, all-pad-centre or SMD-overlap datum. Catalog-twin renderer fidelity is a separate gate.

| group | refs | tuple cache key | group report | result |
|---|---|---|---|---|
| zeta_group | J2 | `8ddac13b446ed95330465d0fbf794c0c5b0eb85923f56dfa1f3dd975adf7c29e` | `06_build/pre_route/native_registration/zeta_group/native_model_registration.md` | PASS |
| alpha_group | J3 | `ddeded142e495c1dbd6e736a5d57d749b19af7c5d453dcdc8b485f2ccc64e983` | `06_build/pre_route/native_registration/alpha_group/native_model_registration.md` | PASS |
