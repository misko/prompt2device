# Native model physical registration — `native_top.png`

board_sha256: b6c68a3e9b42ea38592193880c7e6e07d7a4f236594febbeee84661e784f8c84
coupon_sha256: d8dbb32b7b1f43e2b681d68f82e77b2bb1b8f780041eed39a73bc18956f37f52
a-render_verdict: PASS
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 17cbdea22e6ca94e56fb0facf4c7642df6b57fb94bc9835af2bbe51b7e712aba
footprint_registration_datum_sha256: e49c775a4163d6d43bd082b2ece99253a248f7472b2146c6ea813ce8d20cbf93
model_transform_sha256: 233c621e94a0d847ccc36c7ceaac3f4abf8c6446c5ad7610b23212d7e1aa1af9
registration_contract_sha256: 7626611d454047b74093f7f635aaf0711d891ca59b55cbe9de3629e6a3d3f8e7
tuple_cache_key: ddeded142e495c1dbd6e736a5d57d749b19af7c5d453dcdc8b485f2ccc64e983
calibration_px_per_mm: 20.4061 x, 20.4017 y
anisotropy: 1.0002
fit_tolerance_mm: 1.000
courtyard_containment_tolerance_mm: 0.250
registration_datum: drilled_centres
mount_side: not-graded
actual_footprint_side: front
plan_camera: top
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: N/A
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected drilled_centres field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | registration centres inside | min pad margin mm |
|---|---:|---:|---:|---:|---:|
| J3 | 0.169 | 0.000 | 0.000 | 5/5 | 0.618 |

## Failures

- none
