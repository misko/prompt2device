# Project native model physical registration

board_sha256: afb51b50f499eef8c85a37c8ff303683555c1df907481fa8ace6f06ebd0df3a2
a-render_verdict: PASS
registration_kind: P-MODEL-REG
config_sha256: e7f527206545b91874b91db1333bd71fd6a7289ea6f018fb9e805fad91443ffc
stage_receipt: 06_build/pre_route/model_registration.stage.json
accepted_bundle: 06_build/pre_route/model_registration_bundle/bundle.json

This aggregate is independent physical-registration evidence. Each group uses an origin-centred coupon and compares native-model pixels with mounted-side Fab/courtyard and each group's declared drilled-centre, all-pad-centre or SMD-overlap datum. Catalog-twin renderer fidelity is a separate gate.

| group | refs | tuple cache key | group report | result |
|---|---|---|---|---|
| mounted | R1,R2,R3 | `fc117ca6bc84aee203b8fd2336bcf76d949c3cdd21f8907f5ec93cdf4de0e7da` | `06_build/pre_route/native_registration/mounted/native_model_registration.md` | CACHE-HIT |
