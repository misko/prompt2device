# Native model physical registration — `native_top.png`

board_sha256: 6ffc24dff4e0c99613a7ec8dd62dc115815135f63a8cac490fce229364b932c2
coupon_sha256: 76d325f8dc58cffa495ecc8c0da8bf129aea1c6d14d7215fce2f795791a7aaf2
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 9aad51b1476dcde92f8ffe57b0ab34c377bfe3d576809677d9068cad26f1a3db
footprint_registration_datum_sha256: 950085ad69a62f72e98b327b655e19ce0c2c3c55f898c0f9dd3d365abc141f08
model_transform_sha256: 0551057cb4f1cc7609786b9bcfa224963a6fb3b9f71bd62720455ba5f0721cb0
registration_contract_sha256: bd1214ee90e7efeecda23d84e0d3ce8546d3b70eee583fdcbdd13dfac591f1aa
tuple_cache_key: cb85996c0447aab91ca8e44360c455e6bc58962127dd312cff80c696bf575b43
calibration_px_per_mm: 43.5214 x, 43.4987 y
anisotropy: 1.0005
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_smd_pad_overlap
mount_side: back
actual_footprint_side: back
plan_camera: bottom
plan_projection: X-MIRRORED
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 1.000000
overlay: native_top_registration_overlay.png

Orange is B.CrtYd; green is the independent B.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_smd_pad_overlap field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond B.Fab mm | measured beyond courtyard mm | SMD pads overlapping model plan | minimum overlap mm2 |
|---|---:|---:|---:|---:|---:|
| R1 | 2.291 | 1.510 | 0.835 | 0/2 | 0.000 |
| R2 | 2.293 | 1.501 | 0.826 | 0/2 | 0.000 |
| R3 | 2.291 | 1.510 | 0.835 | 0/2 | 0.000 |

## Failures

- R1: body/B.Fab centre delta 2.291 mm
- R1: body exceeds B.Fab by 1.510 mm
- R1: body exceeds B.CrtYd by 0.835 mm
- R1: body measurement touched search window
- R1: all_smd_pad_overlap no positive model-plan overlap: ['1', '2']
- R2: body/B.Fab centre delta 2.293 mm
- R2: body exceeds B.Fab by 1.501 mm
- R2: body exceeds B.CrtYd by 0.826 mm
- R2: body measurement touched search window
- R2: all_smd_pad_overlap no positive model-plan overlap: ['1', '2']
- R3: body/B.Fab centre delta 2.291 mm
- R3: body exceeds B.Fab by 1.510 mm
- R3: body exceeds B.CrtYd by 0.835 mm
- R3: body measurement touched search window
- R3: all_smd_pad_overlap no positive model-plan overlap: ['1', '2']
