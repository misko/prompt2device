# Project native model physical registration

board_sha256: 6bf07433c1727e6eb4b41c177abcff5740c78a111e590696787ef926c9f9e92e
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
config_sha256: e7f527206545b91874b91db1333bd71fd6a7289ea6f018fb9e805fad91443ffc
stage_receipt: 06_build/pre_route/model_registration.stage.json
aggregate_bundle_unavailable: 06_build/pre_route/model_registration_bundle/bundle.json

This aggregate is independent physical-registration evidence. Each group uses an origin-centred coupon and compares native-model pixels with mounted-side Fab/courtyard and each group's declared drilled-centre, all-pad-centre or SMD-overlap datum. Catalog-twin renderer fidelity is a separate gate.

| group | refs | tuple cache key | group report | result |
|---|---|---|---|---|
| mounted | R1,R2,R3 | `59941e442c4096d4e2d168cccc422428748109df9f2630e10a2c7aa82f5f25d3` | `06_build/pre_route/native_registration/failed_attempts/mounted-20260913T045340Z-c85537cba03f/native_model_registration.md` | FAIL |
