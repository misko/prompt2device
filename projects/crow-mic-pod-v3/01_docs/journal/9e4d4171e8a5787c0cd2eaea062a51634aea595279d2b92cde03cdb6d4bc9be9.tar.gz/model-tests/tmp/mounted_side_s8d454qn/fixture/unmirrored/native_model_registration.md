# Native model physical registration — `native_top.png`

board_sha256: afb51b50f499eef8c85a37c8ff303683555c1df907481fa8ace6f06ebd0df3a2
coupon_sha256: 52f9f33979c8ab44bbca65cac17b577b2f18102a6a696c0f654aa85955ac4e25
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 9aad51b1476dcde92f8ffe57b0ab34c377bfe3d576809677d9068cad26f1a3db
footprint_registration_datum_sha256: 950085ad69a62f72e98b327b655e19ce0c2c3c55f898c0f9dd3d365abc141f08
model_transform_sha256: 80a66bce7f27ce9ae59930467fef85ee65532be289948f5447ae054d422ef85d
registration_contract_sha256: 213e8af8d4f59aa96d6ccb552fc902e2882146b903992c6a6eaa9168669a1a7b
tuple_cache_key: 97c1a6ec346c8aef627b53663ff39d7b7d7a8f8f93a35ecf9775dd95416bab9f
calibration_px_per_mm: 43.5214 x, 43.4987 y
anisotropy: 1.0005
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_smd_pad_overlap
mount_side: back
actual_footprint_side: back
plan_camera: bottom
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 1.000000
overlay: native_top_registration_overlay.png

Orange is B.CrtYd; green is the independent B.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_smd_pad_overlap field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond B.Fab mm | measured beyond courtyard mm | SMD pads overlapping model plan | minimum overlap mm2 |
|---|---:|---:|---:|---:|---:|
| R1 | 0.030 | 0.000 | 0.000 | 2/2 | 0.276 |
| R2 | 0.024 | 0.000 | 0.000 | 2/2 | 0.287 |
| R3 | N/A | N/A | N/A | 0/2 | N/A |

## Failures

- R3: native body pixels were not measured
