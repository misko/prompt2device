# Native model physical registration — `native_top.png`

board_sha256: 6bf07433c1727e6eb4b41c177abcff5740c78a111e590696787ef926c9f9e92e
coupon_sha256: 33b6bec7aad259ab691e2ca19c00d1f504f8da1ca2f147e491026477d557bb94
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 9aad51b1476dcde92f8ffe57b0ab34c377bfe3d576809677d9068cad26f1a3db
footprint_registration_datum_sha256: 950085ad69a62f72e98b327b655e19ce0c2c3c55f898c0f9dd3d365abc141f08
model_transform_sha256: a110ff6cc2d8bb772f2012d7fcea95cfcba6f737333e6327e95e908dd6fc587c
registration_contract_sha256: bd1214ee90e7efeecda23d84e0d3ce8546d3b70eee583fdcbdd13dfac591f1aa
tuple_cache_key: 59941e442c4096d4e2d168cccc422428748109df9f2630e10a2c7aa82f5f25d3
calibration_px_per_mm: 43.5214 x, 43.4987 y
anisotropy: 1.0005
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_smd_pad_overlap
mount_side: back
actual_footprint_side: back
plan_camera: bottom
plan_projection: X-MIRRORED
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 1.000000
overlay: native_top_registration_overlay.png

Orange is B.CrtYd; green is the independent B.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_smd_pad_overlap field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond B.Fab mm | measured beyond courtyard mm | SMD pads overlapping model plan | minimum overlap mm2 |
|---|---:|---:|---:|---:|---:|
| R1 | 0.024 | 0.355 | 0.042 | 0/2 | 0.000 |
| R2 | 0.038 | 0.355 | 0.042 | 0/2 | 0.000 |
| R3 | 0.005 | 0.332 | 0.019 | 0/2 | 0.000 |

## Failures

- R1: body exceeds B.Fab by 0.355 mm
- R1: all_smd_pad_overlap no positive model-plan overlap: ['1', '2']
- R2: body exceeds B.Fab by 0.355 mm
- R2: all_smd_pad_overlap no positive model-plan overlap: ['1', '2']
- R3: body exceeds B.Fab by 0.332 mm
- R3: all_smd_pad_overlap no positive model-plan overlap: ['1', '2']
