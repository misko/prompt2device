# Project native model physical registration

board_sha256: a9b454cf9951e4c8e62c3ea1e73bbcaf40eaf2476bf5df13fb844997ffda8501
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
config_sha256: b5075a303d4f3a45788e94251420d841f443927fa14752624281759bb97f4859
stage_receipt: 06_build/pre_route/model_registration.stage.json
aggregate_bundle_unavailable: 06_build/pre_route/model_registration_bundle/bundle.json

This aggregate is independent physical-registration evidence. Each group uses an origin-centred coupon and compares native-model pixels with mounted-side Fab/courtyard and each group's declared drilled-centre, all-pad-centre or SMD-overlap datum. Catalog-twin renderer fidelity is a separate gate.

| group | refs | tuple cache key | group report | result |
|---|---|---|---|---|
| shifted_sma | J2 | `14f90d073544f89eee8331fbfc374a2dd6819b2589f3526a38e987581f7bca0e` | `06_build/pre_route/native_registration/failed_attempts/shifted_sma-20260913T045310Z-c84e2dfd8ce0/native_model_registration.md` | FAIL |
