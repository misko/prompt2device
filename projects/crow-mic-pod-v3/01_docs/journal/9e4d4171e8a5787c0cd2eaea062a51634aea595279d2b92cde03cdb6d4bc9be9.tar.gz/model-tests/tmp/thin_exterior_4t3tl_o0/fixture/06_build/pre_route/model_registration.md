# Project native model physical registration

board_sha256: 3580c0054377fafdd64a7a69fe6e3f96b3dde0e9d8bffca97459090f09d9dc4e
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
config_sha256: d28c914f99e2e2ccd1c09b29bf55b3fbc378f030382f8cc4f06ed4e6362df97d
stage_receipt: 06_build/pre_route/model_registration.stage.json
aggregate_bundle_unavailable: 06_build/pre_route/model_registration_bundle/bundle.json

This aggregate is independent physical-registration evidence. Each group uses an origin-centred coupon and compares native-model pixels with mounted-side Fab/courtyard and each group's declared drilled-centre, all-pad-centre or SMD-overlap datum. Catalog-twin renderer fidelity is a separate gate.

| group | refs | tuple cache key | group report | result |
|---|---|---|---|---|
| thin | R1 | `f0d304dac112748c9a43b32817e50df71bbcb5640dfaa6a9b8c13baf80005708` | `06_build/pre_route/native_registration/failed_attempts/thin-20260913T045408Z-c85badc6fa5a/native_model_registration.md` | FAIL |
