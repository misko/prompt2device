# Native model physical registration — `native_top.png`

board_sha256: 3580c0054377fafdd64a7a69fe6e3f96b3dde0e9d8bffca97459090f09d9dc4e
coupon_sha256: 0dcd8b1b3c3fe05847c2aba148b7dbd0d8f99847873b90776d16fb6dedc4e8b7
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 720a09c44d720118374568d55b404f9e8c05b0f9304dfb6890e699b21ea6041d
footprint_registration_datum_sha256: 3bac16835ce0e457260fc3a70698e2a23ca239e7342ad35ff42c8c2eb7718133
model_transform_sha256: 6cf53f0e2e5e9c07c31120b0a7392007f28e50daeb9d9b4fabcff69a71234dd2
registration_contract_sha256: 33f2e5057fecd1a81e5791c34b6690429b2028c28323ddcfa6c33bbeb980f2a7
tuple_cache_key: f0d304dac112748c9a43b32817e50df71bbcb5640dfaa6a9b8c13baf80005708
calibration_px_per_mm: 56.3158 x, 56.3462 y
anisotropy: 0.9995
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_smd_pad_overlap
mount_side: front
actual_footprint_side: front
plan_camera: top
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 1.000000
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_smd_pad_overlap field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | SMD pads overlapping model plan | minimum overlap mm2 |
|---|---:|---:|---:|---:|---:|
| R1 | 1.092 | 2.142 | 1.467 | 2/2 | 0.301 |

## Failures

- R1: body/F.Fab centre delta 1.092 mm
- R1: body exceeds F.Fab by 2.142 mm
- R1: body exceeds F.CrtYd by 1.467 mm
