# Project native model physical registration

board_sha256: ca93bd161c50dcd093c4a26cb2a73ff00d7b479fd826a83634c12134cec57bc2
a-render_verdict: PASS
registration_kind: P-MODEL-REG
config_sha256: b80f0e70d4c8fd244383b6d6e6491d32ecda857db383c3046ecd282e3e58b4d3
stage_receipt: 06_build/pre_route/model_registration.stage.json
accepted_bundle: 06_build/pre_route/model_registration_bundle/bundle.json

This aggregate is independent physical-registration evidence. Each group uses an origin-centred coupon and compares native-model pixels with mounted-side Fab/courtyard and each group's declared drilled-centre, all-pad-centre or SMD-overlap datum. Catalog-twin renderer fidelity is a separate gate.

| group | refs | tuple cache key | group report | result |
|---|---|---|---|---|
| thin | R1 | `6f232065384febfe0f5d7dfd07f469d842bd3d0312f86b39d8342b08d5a5945e` | `06_build/pre_route/native_registration/thin/native_model_registration.md` | PASS |
