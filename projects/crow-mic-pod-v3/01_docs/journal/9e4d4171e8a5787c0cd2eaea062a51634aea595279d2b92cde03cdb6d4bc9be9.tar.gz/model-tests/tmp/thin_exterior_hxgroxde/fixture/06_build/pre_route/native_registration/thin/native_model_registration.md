# Native model physical registration — `native_top.png`

board_sha256: ca93bd161c50dcd093c4a26cb2a73ff00d7b479fd826a83634c12134cec57bc2
coupon_sha256: 8ba951d2ec404c3512c455f962afe3194be5acfe7378783db0db06015598cc77
a-render_verdict: PASS
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: d5ff4afa47e532fd9ebdfb37bd85c36b727722c4e7881bf85a0bd56e2f4ff687
footprint_registration_datum_sha256: 3bac16835ce0e457260fc3a70698e2a23ca239e7342ad35ff42c8c2eb7718133
model_transform_sha256: 6cf53f0e2e5e9c07c31120b0a7392007f28e50daeb9d9b4fabcff69a71234dd2
registration_contract_sha256: f64ecc63e2ad18a1d22867f48df1905265bea1990c23ac677158f7272d9f11ad
tuple_cache_key: 6f232065384febfe0f5d7dfd07f469d842bd3d0312f86b39d8342b08d5a5945e
calibration_px_per_mm: 56.3158 x, 56.3462 y
anisotropy: 0.9995
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_smd_pad_overlap
mount_side: front
actual_footprint_side: front
plan_camera: top
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 1.000000
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_smd_pad_overlap field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | SMD pads overlapping model plan | minimum overlap mm2 |
|---|---:|---:|---:|---:|---:|
| R1 | 0.020 | 0.000 | 0.000 | 2/2 | 0.287 |

## Failures

- none
