# Project native model physical registration

board_sha256: 0283ab3c0ab67a430f3abbafab1b55ed81b5a3467a1cc22b1314a40b86a12e21
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
config_sha256: 401552c634444a0076b42347a4e27a634a86cce25ff148ecbca1c975471f322f
stage_receipt: 06_build/pre_route/model_registration.stage.json
aggregate_bundle_unavailable: 06_build/pre_route/model_registration_bundle/bundle.json

This aggregate is independent physical-registration evidence. Each group uses an origin-centred coupon and compares native-model pixels with mounted-side Fab/courtyard and each group's declared drilled-centre, all-pad-centre or SMD-overlap datum. Catalog-twin renderer fidelity is a separate gate.

| group | refs | tuple cache key | group report | result |
|---|---|---|---|---|
| mounted | R1,R2,R3 | `e33930a765b26a6fbb25abaa04844027d2da13c947c6ba7a6e8a2b9836487245` | `06_build/pre_route/native_registration/failed_attempts/mounted-20260913T045355Z-c858bc9f2665/native_model_registration.md` | FAIL |
