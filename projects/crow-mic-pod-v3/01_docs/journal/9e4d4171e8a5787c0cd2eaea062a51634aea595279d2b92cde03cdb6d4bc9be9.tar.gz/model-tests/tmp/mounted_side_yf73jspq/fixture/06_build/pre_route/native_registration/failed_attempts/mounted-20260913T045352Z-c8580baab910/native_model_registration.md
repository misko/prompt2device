# Native model physical registration — `native_top.png`

board_sha256: a4edcc015a3a5cced2e1e39443884f112c150ffa5f1b6ffd9ec7a524fe963083
coupon_sha256: 75ea6c4dbd13f1c846a65068c128437e98bc73f36dba93de8fb2f3011a1e2887
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 9aad51b1476dcde92f8ffe57b0ab34c377bfe3d576809677d9068cad26f1a3db
footprint_registration_datum_sha256: ecb92086eb8cbab32b4676b8410344463d3f23c48d4b73ea2a9cbb52bf638b38
model_transform_sha256: b37be3f11458466bc6a2e172c3af793cd24dca6934fcce08cb6a702dd3ca01b2
registration_contract_sha256: c32717c4521ead6f2dfba93e6f0a62f5cf67d112903ba04556e8509f5a2ec9b6
tuple_cache_key: d02194430b052d6e33cdde7efc42e612cc0c3614a3ae683c343d5a95114ad860
calibration_px_per_mm: 43.5214 x, 43.4987 y
anisotropy: 1.0005
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_smd_pad_overlap
mount_side: front
actual_footprint_side: front
plan_camera: top
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 0.683611
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_smd_pad_overlap field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | SMD pads overlapping model plan | minimum overlap mm2 |
|---|---:|---:|---:|---:|---:|
| R1 | 0.030 | 0.000 | 0.000 | 2/2 | 0.276 |
| R2 | 0.024 | 0.000 | 0.000 | 2/2 | 0.287 |
| R3 | 0.021 | 0.000 | 0.000 | 2/2 | 0.269 |

## Failures

- native body occupies only 0.684 of measured side-view solid on front mount side; minimum is 0.750
