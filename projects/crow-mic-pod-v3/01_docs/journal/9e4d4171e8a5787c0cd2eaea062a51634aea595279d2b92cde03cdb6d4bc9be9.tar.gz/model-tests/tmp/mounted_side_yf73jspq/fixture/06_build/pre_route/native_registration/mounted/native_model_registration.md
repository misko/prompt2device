# Native model physical registration — `native_top.png`

board_sha256: 5e718ba1076f37c22d84169004cb7e9549146b852c7ebe5613175ebc7c64b88a
coupon_sha256: 29701a62469b9095fb39b0a3bc496c93a5055b51e521ca3b41a5fbcac2a9d635
a-render_verdict: PASS
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 9aad51b1476dcde92f8ffe57b0ab34c377bfe3d576809677d9068cad26f1a3db
footprint_registration_datum_sha256: ecb92086eb8cbab32b4676b8410344463d3f23c48d4b73ea2a9cbb52bf638b38
model_transform_sha256: 80a66bce7f27ce9ae59930467fef85ee65532be289948f5447ae054d422ef85d
registration_contract_sha256: c32717c4521ead6f2dfba93e6f0a62f5cf67d112903ba04556e8509f5a2ec9b6
tuple_cache_key: 211014597ab015b0635b91ec254a13ac693fa6d7999ace189736770771290cc3
calibration_px_per_mm: 43.5214 x, 43.4987 y
anisotropy: 1.0005
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_smd_pad_overlap
mount_side: front
actual_footprint_side: front
plan_camera: top
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 1.000000
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_smd_pad_overlap field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | SMD pads overlapping model plan | minimum overlap mm2 |
|---|---:|---:|---:|---:|---:|
| R1 | 0.030 | 0.000 | 0.000 | 2/2 | 0.276 |
| R2 | 0.024 | 0.000 | 0.000 | 2/2 | 0.287 |
| R3 | 0.021 | 0.000 | 0.000 | 2/2 | 0.269 |

## Failures

- none
