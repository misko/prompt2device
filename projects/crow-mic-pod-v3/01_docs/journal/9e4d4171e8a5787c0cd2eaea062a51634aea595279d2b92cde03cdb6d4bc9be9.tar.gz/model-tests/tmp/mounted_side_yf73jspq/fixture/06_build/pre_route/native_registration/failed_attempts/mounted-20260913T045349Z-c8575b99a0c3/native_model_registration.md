# Native model physical registration — `native_top.png`

board_sha256: bdbb7a76a0e26b3e1bef4c4178e3f4e4af0d8f1cc6f235c71539aaa15d357f6e
coupon_sha256: fc43a911ad026c76e6a32450c21d2264fb3640b71d1cc91f65465ed5013be4b5
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 9aad51b1476dcde92f8ffe57b0ab34c377bfe3d576809677d9068cad26f1a3db
footprint_registration_datum_sha256: ecb92086eb8cbab32b4676b8410344463d3f23c48d4b73ea2a9cbb52bf638b38
model_transform_sha256: 0551057cb4f1cc7609786b9bcfa224963a6fb3b9f71bd62720455ba5f0721cb0
registration_contract_sha256: c32717c4521ead6f2dfba93e6f0a62f5cf67d112903ba04556e8509f5a2ec9b6
tuple_cache_key: cc061f53c53a276033d119dd59be7e5cc5de34e20e749e417df7ed353b384c1d
calibration_px_per_mm: 43.5214 x, 43.4987 y
anisotropy: 1.0005
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_smd_pad_overlap
mount_side: front
actual_footprint_side: front
plan_camera: top
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 1.000000
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_smd_pad_overlap field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | SMD pads overlapping model plan | minimum overlap mm2 |
|---|---:|---:|---:|---:|---:|
| R1 | 2.268 | 1.510 | 0.835 | 0/2 | 0.000 |
| R2 | 2.270 | 1.501 | 0.826 | 0/2 | 0.000 |
| R3 | 2.268 | 1.510 | 0.835 | 0/2 | 0.000 |

## Failures

- R1: body/F.Fab centre delta 2.268 mm
- R1: body exceeds F.Fab by 1.510 mm
- R1: body exceeds F.CrtYd by 0.835 mm
- R1: body measurement touched search window
- R1: all_smd_pad_overlap no positive model-plan overlap: ['1', '2']
- R2: body/F.Fab centre delta 2.270 mm
- R2: body exceeds F.Fab by 1.501 mm
- R2: body exceeds F.CrtYd by 0.826 mm
- R2: body measurement touched search window
- R2: all_smd_pad_overlap no positive model-plan overlap: ['1', '2']
- R3: body/F.Fab centre delta 2.268 mm
- R3: body exceeds F.Fab by 1.510 mm
- R3: body exceeds F.CrtYd by 0.835 mm
- R3: body measurement touched search window
- R3: all_smd_pad_overlap no positive model-plan overlap: ['1', '2']
