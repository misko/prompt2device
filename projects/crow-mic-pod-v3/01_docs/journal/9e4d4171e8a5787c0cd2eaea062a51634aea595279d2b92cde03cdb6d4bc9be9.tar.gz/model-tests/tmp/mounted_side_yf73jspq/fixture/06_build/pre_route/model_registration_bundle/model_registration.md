# Project native model physical registration

board_sha256: 5e718ba1076f37c22d84169004cb7e9549146b852c7ebe5613175ebc7c64b88a
a-render_verdict: PASS
registration_kind: P-MODEL-REG
config_sha256: 401552c634444a0076b42347a4e27a634a86cce25ff148ecbca1c975471f322f
stage_receipt: 06_build/pre_route/model_registration.stage.json
accepted_bundle: 06_build/pre_route/model_registration_bundle/bundle.json

This aggregate is independent physical-registration evidence. Each group uses an origin-centred coupon and compares native-model pixels with mounted-side Fab/courtyard and each group's declared drilled-centre, all-pad-centre or SMD-overlap datum. Catalog-twin renderer fidelity is a separate gate.

| group | refs | tuple cache key | group report | result |
|---|---|---|---|---|
| mounted | R1,R2,R3 | `211014597ab015b0635b91ec254a13ac693fa6d7999ace189736770771290cc3` | `06_build/pre_route/native_registration/mounted/native_model_registration.md` | CACHE-HIT |
