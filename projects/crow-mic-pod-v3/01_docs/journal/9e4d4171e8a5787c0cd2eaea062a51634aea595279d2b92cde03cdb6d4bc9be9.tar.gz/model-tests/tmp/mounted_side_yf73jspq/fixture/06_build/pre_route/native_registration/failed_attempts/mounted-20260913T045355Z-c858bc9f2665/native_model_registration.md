# Native model physical registration — `native_top.png`

board_sha256: 0283ab3c0ab67a430f3abbafab1b55ed81b5a3467a1cc22b1314a40b86a12e21
coupon_sha256: 99149b7414509ab21359babc1d6f09220dd022cab3d21b3f9a75a3a6edc688a9
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 9aad51b1476dcde92f8ffe57b0ab34c377bfe3d576809677d9068cad26f1a3db
footprint_registration_datum_sha256: ecb92086eb8cbab32b4676b8410344463d3f23c48d4b73ea2a9cbb52bf638b38
model_transform_sha256: a110ff6cc2d8bb772f2012d7fcea95cfcba6f737333e6327e95e908dd6fc587c
registration_contract_sha256: c32717c4521ead6f2dfba93e6f0a62f5cf67d112903ba04556e8509f5a2ec9b6
tuple_cache_key: e33930a765b26a6fbb25abaa04844027d2da13c947c6ba7a6e8a2b9836487245
calibration_px_per_mm: 43.5214 x, 43.4987 y
anisotropy: 1.0005
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_smd_pad_overlap
mount_side: front
actual_footprint_side: front
plan_camera: top
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 1.000000
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_smd_pad_overlap field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | SMD pads overlapping model plan | minimum overlap mm2 |
|---|---:|---:|---:|---:|---:|
| R1 | 0.038 | 0.355 | 0.042 | 0/2 | 0.000 |
| R2 | 0.024 | 0.355 | 0.042 | 0/2 | 0.000 |
| R3 | 0.030 | 0.332 | 0.019 | 0/2 | 0.000 |

## Failures

- R1: body exceeds F.Fab by 0.355 mm
- R1: all_smd_pad_overlap no positive model-plan overlap: ['1', '2']
- R2: body exceeds F.Fab by 0.355 mm
- R2: all_smd_pad_overlap no positive model-plan overlap: ['1', '2']
- R3: body exceeds F.Fab by 0.332 mm
- R3: all_smd_pad_overlap no positive model-plan overlap: ['1', '2']
