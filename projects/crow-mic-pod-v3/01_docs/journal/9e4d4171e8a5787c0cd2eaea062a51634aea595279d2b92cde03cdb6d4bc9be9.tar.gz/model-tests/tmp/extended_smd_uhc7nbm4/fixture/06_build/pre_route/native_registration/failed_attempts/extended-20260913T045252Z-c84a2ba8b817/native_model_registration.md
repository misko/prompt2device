# Native model physical registration — `native_top.png`

board_sha256: 15849e425cd88fe72eee6d3f90157e60f5021c501624e769b969d4439b8b08c2
coupon_sha256: 7d9d00b3d94facafc698fc11a7b9663aeddee01d069cfda820d4b20c57e9a8aa
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: d9f43e70f196e49679bc38bdbca39ee1edf56d98c720d704913b3c6c2e98a4c8
footprint_registration_datum_sha256: 78f090c4ff785defb2b31eea5e2f131b8f53eac70089b5e43bc2f6acc7c98420
model_transform_sha256: 6cf53f0e2e5e9c07c31120b0a7392007f28e50daeb9d9b4fabcff69a71234dd2
registration_contract_sha256: cc6f65db0008c10c04dadc2287c9673f18cb32118863568fe4de6355ef97ce63
tuple_cache_key: a6f1c8d347c1b506439b0fe35328482c318b69d42b421c51fc4363593e6717e3
calibration_px_per_mm: 127.1901 x, 127.1698 y
anisotropy: 1.0002
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_smd_pad_overlap
mount_side: front
actual_footprint_side: front
plan_camera: top
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 0.790903
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_smd_pad_overlap field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | SMD pads overlapping model plan | minimum overlap mm2 |
|---|---:|---:|---:|---:|---:|
| R1 | 0.004 | 0.000 | 0.000 | 1/2 | 0.000 |

## Failures

- R1: all_smd_pad_overlap no positive model-plan overlap: ['1']
