# Native model physical registration — `native_top.png`

board_sha256: 79a825592282b6f38ecbaf9b21012b550eb8390384fc764bc3e478c965f8cd19
coupon_sha256: 289995d1989a51fefe4124ed7d3c7bbd2593dd9c8d30811a1c250f785f5d885a
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: d9f43e70f196e49679bc38bdbca39ee1edf56d98c720d704913b3c6c2e98a4c8
footprint_registration_datum_sha256: 3bac16835ce0e457260fc3a70698e2a23ca239e7342ad35ff42c8c2eb7718133
model_transform_sha256: ae5a453342882ea01b056a34a756d2f65a2307f32740326272af2a6a15519d6a
registration_contract_sha256: cc6f65db0008c10c04dadc2287c9673f18cb32118863568fe4de6355ef97ce63
tuple_cache_key: ddc57228d8137242fe5947ec9d2b79de5c42cd49d1bbd6b345f90e6378e4649b
calibration_px_per_mm: 127.1901 x, 127.1698 y
anisotropy: 1.0002
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_smd_pad_overlap
mount_side: front
actual_footprint_side: front
plan_camera: top
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 0.713022
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_smd_pad_overlap field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | SMD pads overlapping model plan | minimum overlap mm2 |
|---|---:|---:|---:|---:|---:|
| R1 | 0.004 | 0.000 | 0.000 | 2/2 | 0.295 |

## Failures

- native body occupies only 0.713 of measured side-view solid on front mount side; minimum is 0.750
