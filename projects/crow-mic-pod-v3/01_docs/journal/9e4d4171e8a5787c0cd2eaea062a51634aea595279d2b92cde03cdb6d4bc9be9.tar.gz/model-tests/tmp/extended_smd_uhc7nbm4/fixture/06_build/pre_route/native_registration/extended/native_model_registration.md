# Native model physical registration — `native_top.png`

board_sha256: e79de059ec298f0a49e30722bb9394e7c407e94de60b379189af4ecd5d506124
coupon_sha256: 2c7d0a2337e590bc9e813971b2c19d9a2e401bffe87081e5a2f9d31825ef1ef8
a-render_verdict: PASS
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: d9f43e70f196e49679bc38bdbca39ee1edf56d98c720d704913b3c6c2e98a4c8
footprint_registration_datum_sha256: 3bac16835ce0e457260fc3a70698e2a23ca239e7342ad35ff42c8c2eb7718133
model_transform_sha256: 6cf53f0e2e5e9c07c31120b0a7392007f28e50daeb9d9b4fabcff69a71234dd2
registration_contract_sha256: cc6f65db0008c10c04dadc2287c9673f18cb32118863568fe4de6355ef97ce63
tuple_cache_key: d0300394649b4610ac8e527e453bd721b7a062fca96f487b98b54d80a0ab6748
calibration_px_per_mm: 127.1901 x, 127.1698 y
anisotropy: 1.0002
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_smd_pad_overlap
mount_side: front
actual_footprint_side: front
plan_camera: top
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 0.787752
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_smd_pad_overlap field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | SMD pads overlapping model plan | minimum overlap mm2 |
|---|---:|---:|---:|---:|---:|
| R1 | 0.004 | 0.000 | 0.000 | 2/2 | 0.295 |

## Failures

- none
