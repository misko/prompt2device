# Project native model physical registration

board_sha256: e79de059ec298f0a49e30722bb9394e7c407e94de60b379189af4ecd5d506124
a-render_verdict: PASS
registration_kind: P-MODEL-REG
config_sha256: f36b8635b678aae3838a67a6c37f800bc761362f38f8ca943fe61b92f6b73b44
stage_receipt: 06_build/pre_route/model_registration.stage.json
accepted_bundle: 06_build/pre_route/model_registration_bundle/bundle.json

This aggregate is independent physical-registration evidence. Each group uses an origin-centred coupon and compares native-model pixels with mounted-side Fab/courtyard and each group's declared drilled-centre, all-pad-centre or SMD-overlap datum. Catalog-twin renderer fidelity is a separate gate.

| group | refs | tuple cache key | group report | result |
|---|---|---|---|---|
| extended | R1 | `d0300394649b4610ac8e527e453bd721b7a062fca96f487b98b54d80a0ab6748` | `06_build/pre_route/native_registration/extended/native_model_registration.md` | CACHE-HIT |
