# Native model physical registration — `native_top.png`

board_sha256: e79de059ec298f0a49e30722bb9394e7c407e94de60b379189af4ecd5d506124
coupon_sha256: 45b52fcda1464469db5de32b6d69a7913baf4166a5c8ba72d7cc4d451ceb95f3
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: d9f43e70f196e49679bc38bdbca39ee1edf56d98c720d704913b3c6c2e98a4c8
footprint_registration_datum_sha256: 95357a5ca38ba6a79ba5f5f118c95848b5b6ae23a21883ef55fcb17d19c4c398
model_transform_sha256: 6cf53f0e2e5e9c07c31120b0a7392007f28e50daeb9d9b4fabcff69a71234dd2
registration_contract_sha256: 8cdbfb05090ac77875c78fb0b904242bdb0d4e91913bd829fd564463cf4fe869
tuple_cache_key: be8ae33c7766d2cfb3b4b89ff9ea0e664662046987206c11c3ba8bbc38172d92
calibration_px_per_mm: 127.1901 x, 127.1698 y
anisotropy: 1.0002
fit_tolerance_mm: 0.200
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_pad_centres
mount_side: front
actual_footprint_side: front
plan_camera: top
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 0.787752
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_pad_centres field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | registration centres inside | min pad margin mm |
|---|---:|---:|---:|---:|---:|
| R1 | 0.004 | 0.000 | 0.000 | 0/2 | -0.027 |

## Failures

- R1: all_pad_centres outside body: ['1', '2']
