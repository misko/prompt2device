# Project native model physical registration

board_sha256: 79a825592282b6f38ecbaf9b21012b550eb8390384fc764bc3e478c965f8cd19
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
config_sha256: f36b8635b678aae3838a67a6c37f800bc761362f38f8ca943fe61b92f6b73b44
stage_receipt: 06_build/pre_route/model_registration.stage.json
aggregate_bundle_unavailable: 06_build/pre_route/model_registration_bundle/bundle.json

This aggregate is independent physical-registration evidence. Each group uses an origin-centred coupon and compares native-model pixels with mounted-side Fab/courtyard and each group's declared drilled-centre, all-pad-centre or SMD-overlap datum. Catalog-twin renderer fidelity is a separate gate.

| group | refs | tuple cache key | group report | result |
|---|---|---|---|---|
| extended | R1 | `ddc57228d8137242fe5947ec9d2b79de5c42cd49d1bbd6b345f90e6378e4649b` | `06_build/pre_route/native_registration/failed_attempts/extended-20260913T045259Z-c84bb21af133/native_model_registration.md` | FAIL |
