# Native model physical registration — `native_top.png`

board_sha256: b89a1f49782c68cb2a67f12f16db2825bc046187996f65d214ae15602425cf22
coupon_sha256: c048cd062a9e8ef0af0ad7d364e56d81e415e5ea3d69e38c566287400f0a07e7
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 17cbdea22e6ca94e56fb0facf4c7642df6b57fb94bc9835af2bbe51b7e712aba
footprint_registration_datum_sha256: e49c775a4163d6d43bd082b2ece99253a248f7472b2146c6ea813ce8d20cbf93
model_transform_sha256: de258c7599a7af3daf0b9167e33273b9c3d8904849d0e3fdeae5278ed4ce51ac
registration_contract_sha256: 355c8a05ec843c3521a24b7fed983557a571f0edcb9cbf0d838b6fdb105d568f
tuple_cache_key: 9f33139717f3f59327d68b65dd1e902b985b404b1670095fa6c3d3f41686de50
calibration_px_per_mm: 20.4061 x, 20.4017 y
anisotropy: 1.0002
fit_tolerance_mm: 1.000
courtyard_containment_tolerance_mm: 0.250
registration_datum: drilled_centres
mount_side: front
actual_footprint_side: front
plan_camera: top
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 0.117308
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected drilled_centres field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | registration centres inside | min pad margin mm |
|---|---:|---:|---:|---:|---:|
| J2 | 3.949 | 0.000 | 0.000 | 5/5 | 0.618 |

## Failures

- native body occupies only 0.117 of measured side-view solid on front mount side; minimum is 0.750
- J2: body/F.Fab centre delta 3.949 mm
