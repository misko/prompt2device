# Project native model physical registration

board_sha256: b89a1f49782c68cb2a67f12f16db2825bc046187996f65d214ae15602425cf22
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
config_sha256: 90b2d76e0dde19d6a34e351e3dea375e1eaefc9d777306ab751d438c0be1815e
stage_receipt: 06_build/pre_route/model_registration.stage.json
aggregate_bundle_unavailable: 06_build/pre_route/model_registration_bundle/bundle.json

This aggregate is independent physical-registration evidence. Each group uses an origin-centred coupon and compares native-model pixels with mounted-side Fab/courtyard and each group's declared drilled-centre, all-pad-centre or SMD-overlap datum. Catalog-twin renderer fidelity is a separate gate.

| group | refs | tuple cache key | group report | result |
|---|---|---|---|---|
| shifted_sma | J2 | `9f33139717f3f59327d68b65dd1e902b985b404b1670095fa6c3d3f41686de50` | `06_build/pre_route/native_registration/failed_attempts/shifted_sma-20260913T045318Z-c8500688a1e3/native_model_registration.md` | FAIL |
