# Native model physical registration — `native_top.png`

board_sha256: b89a1f49782c68cb2a67f12f16db2825bc046187996f65d214ae15602425cf22
coupon_sha256: 8795084a707fc61486c9440615c4998b9cc0721e6af8876819b6196824738766
a-render_verdict: FAIL
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 17cbdea22e6ca94e56fb0facf4c7642df6b57fb94bc9835af2bbe51b7e712aba
footprint_registration_datum_sha256: e49c775a4163d6d43bd082b2ece99253a248f7472b2146c6ea813ce8d20cbf93
model_transform_sha256: de258c7599a7af3daf0b9167e33273b9c3d8904849d0e3fdeae5278ed4ce51ac
registration_contract_sha256: f373f0294cea76b74a96bc909063e0df5782e51368909d4d276ba2bed37afdd5
tuple_cache_key: fc425a46bb918f23707ce8710dbd4ad42672698f078ddf27bbed551996d48b3d
calibration_px_per_mm: 20.4061 x, 20.4017 y
anisotropy: 1.0002
fit_tolerance_mm: 1.000
courtyard_containment_tolerance_mm: 0.250
registration_datum: drilled_centres
mount_side: front
actual_footprint_side: front
plan_camera: top
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: 0.117308
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected drilled_centres field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | registration centres inside | min pad margin mm |
|---|---:|---:|---:|---:|---:|
| J2 | 3.949 | 0.000 | 0.000 | 5/5 | 0.618 |

## Failures

- native body occupies only 0.117 of measured side-view solid on front mount side; minimum is 0.750
- J2: body/F.Fab centre delta 3.949 mm
