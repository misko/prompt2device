# Project native model physical registration

board_sha256: 721e07e43b7f407eed151f9d3cfd7fcfa7f83ba3ebd4af56b30d99976b6653d8
a-render_verdict: PASS
registration_kind: P-MODEL-REG
config_sha256: 5aa15115b0311cb76857745aca22ff60911a52dc97f729a3b94222b3fe1e85ee
stage_receipt: 06_build/pre_route/model_registration.stage.json
accepted_bundle: 06_build/pre_route/model_registration_bundle/bundle.json

This aggregate is independent physical-registration evidence. Each group uses an origin-centred coupon and compares native-model pixels with mounted-side Fab/courtyard and each group's declared drilled-centre, all-pad-centre or SMD-overlap datum. Catalog-twin renderer fidelity is a separate gate.

| group | refs | tuple cache key | group report | result |
|---|---|---|---|---|
| shifted_sma | J2 | `f90e07cfc0742b0464113f362bb49e34481ddd2751969b74a8aeae9c08d31d1c` | `06_build/pre_route/native_registration/shifted_sma/native_model_registration.md` | PASS |
