# Native model physical registration — `native_top.png`

board_sha256: 721e07e43b7f407eed151f9d3cfd7fcfa7f83ba3ebd4af56b30d99976b6653d8
coupon_sha256: 543e52e43a3559f21bf7dc9dc11dd4384ff673d017509dba3450c2a09d92a924
a-render_verdict: PASS
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 17cbdea22e6ca94e56fb0facf4c7642df6b57fb94bc9835af2bbe51b7e712aba
footprint_registration_datum_sha256: 89702858239b94f9ec7f239b45d8ec82e16db9823bb582178e4306fcfbc1ac6f
model_transform_sha256: 233c621e94a0d847ccc36c7ceaac3f4abf8c6446c5ad7610b23212d7e1aa1af9
registration_contract_sha256: b2e51be740147940799e29fb4e61ac959fca88bdc40349a1ac11a8ecd6bee896
tuple_cache_key: f90e07cfc0742b0464113f362bb49e34481ddd2751969b74a8aeae9c08d31d1c
calibration_px_per_mm: 20.4061 x, 20.4017 y
anisotropy: 1.0002
fit_tolerance_mm: 1.000
courtyard_containment_tolerance_mm: 0.250
registration_datum: all_pad_centres
mount_side: not-graded
actual_footprint_side: front
plan_camera: top
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: N/A
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected all_pad_centres field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | registration centres inside | min pad margin mm |
|---|---:|---:|---:|---:|---:|
| J2 | 0.169 | 0.000 | 0.000 | 5/5 | 0.618 |

## Failures

- none
