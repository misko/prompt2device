# Native model physical registration — `native_top.png`

board_sha256: 8e95d03ff973c5b80cba72d16decc09312c60400b0bd88678091e484f01d80ef
coupon_sha256: 8cb3a32ead1f26bc9884e49d4b2ef6d23ab92fd348d204ce0f62a62628e97294
a-render_verdict: PASS
registration_kind: P-MODEL-REG
render_source: origin-centred per-tuple coupon with provenance-bound native models
model_sha256: 17cbdea22e6ca94e56fb0facf4c7642df6b57fb94bc9835af2bbe51b7e712aba
footprint_registration_datum_sha256: e49c775a4163d6d43bd082b2ece99253a248f7472b2146c6ea813ce8d20cbf93
model_transform_sha256: 233c621e94a0d847ccc36c7ceaac3f4abf8c6446c5ad7610b23212d7e1aa1af9
registration_contract_sha256: cbf44361e496af5848c522707fd606fafadfcbcdacd90eff92e090f3228fc1d5
tuple_cache_key: 48668b4e69d919911a7a3c9013e4f9922032355e4d7f63e8b8eb6e6d4923b5c8
calibration_px_per_mm: 20.4061 x, 20.4017 y
anisotropy: 1.0002
fit_tolerance_mm: 1.000
courtyard_containment_tolerance_mm: 0.250
registration_datum: drilled_centres
mount_side: not-graded
actual_footprint_side: front
plan_camera: top
plan_projection: board XY
mount_side_min_fraction: 0.750
mount_side_measured_fraction: N/A
overlay: native_top_registration_overlay.png

Orange is F.CrtYd; green is the independent F.Fab body envelope; pink is the populated-minus-bare native-model pixel envelope; cyan is the selected drilled_centres field. Pink/green agreement alone is not enough: both must also register to the footprint and courtyard.

| ref | centre delta mm | measured beyond F.Fab mm | measured beyond courtyard mm | registration centres inside | min pad margin mm |
|---|---:|---:|---:|---:|---:|
| J2 | 0.169 | 0.000 | 0.000 | 5/5 | 0.618 |

## Failures

- none
