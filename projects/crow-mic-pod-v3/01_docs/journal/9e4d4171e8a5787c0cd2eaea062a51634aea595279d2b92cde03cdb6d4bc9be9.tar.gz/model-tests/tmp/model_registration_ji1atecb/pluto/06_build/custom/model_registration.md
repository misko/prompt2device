# Project native model physical registration

board_sha256: 8e95d03ff973c5b80cba72d16decc09312c60400b0bd88678091e484f01d80ef
a-render_verdict: PASS
registration_kind: P-MODEL-REG
config_sha256: b5075a303d4f3a45788e94251420d841f443927fa14752624281759bb97f4859
stage_receipt: 06_build/custom/model_registration.stage.json
accepted_bundle: 06_build/custom/model_registration_bundle/bundle.json

This aggregate is independent physical-registration evidence. Each group uses an origin-centred coupon and compares native-model pixels with mounted-side Fab/courtyard and each group's declared drilled-centre, all-pad-centre or SMD-overlap datum. Catalog-twin renderer fidelity is a separate gate.

| group | refs | tuple cache key | group report | result |
|---|---|---|---|---|
| shifted_sma | J2 | `48668b4e69d919911a7a3c9013e4f9922032355e4d7f63e8b8eb6e6d4923b5c8` | `06_build/pre_route/native_registration/shifted_sma/native_model_registration.md` | CACHE-HIT |
