review_stage: pre-route
review_kind: pin
reviewer: /root/pod_r12_pin_review fresh independent read-only reviewer
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: af9bb3c0dcf5e9be20239d725d10dd4d4c1bf95cc0b7518badc3e27bd6523938
netlist_sha256: b4edc879929e85fb35953e06f24ca6f8ade42b14d777b7751cbda47bc84aadff
parts_sha256: d0d0026dd67cbfaa98176799ea34ea3bfde384675d74d58d8cf8f0c88e41fd89
design_rules_sha256: eea86c5464dfd8e042080fd26b91999228eb3c41ff1aff8b7e3b0521c41ac795
route_yaml_sha256: e283b636f90fefac9120fc4bcd4193032cb71ba31668a6527e24bcc660eb005e
completed_at: 2026-09-14T04:42:00Z

# Pod R12.1 seed targeted pin review

## Verdict

SOUND for the exact pre-route pin-review scope. The only reviewed source delta is a deterministic `OUTP_DRV` escape from R12.1 to an off-pad via at (55.0, 36.0) mm. It changes no footprint, pad identity, mounted side, component value, part selection, or netlist node. Complete critical coverage remains six references: D1, D2, J1, U1, U2, and U3. All six remain PASS on the exact current board and netlist. This verdict does not accept routing completion or authorize ordering.

## Six-reference coverage

| Ref | Exact native identity result | Pin/net result | Verdict |
|---|---|---|---|
| D1 | S1M-E3/61T, two independent SMA terminals, F.Cu | 1 K=`VIN_PROTECTED`; 2 A=`12V_FUSED` | PASS |
| D2 | SMBJ15A, two independent SMB terminals, F.Cu | 1 K=`VIN_PROTECTED`; 2 A=`GND` | PASS |
| J1 | Würth 615008160221, 8 contacts + 2 shield tabs + 2 NPTH locators, front THT | contacts 1..8=`12V_POD,GND,12V_POD,AUDIO_N,AUDIO_P,GND,12V_POD,GND`; tabs 9/10=`POD_SHIELD` | PASS |
| U1 | OPA1679IDR, 14 distinct SOIC pins, F.Cu, CCW top view | pins 1..14 retain `VREF,VREF,VREF_RAW,5V_QUIET,VREF,PRE_FB,PRE_OUT,OUTP_DRV,OUTP_FB,VREF,GND,VREF,SPARE_BUF,SPARE_BUF` | PASS |
| U2 | TPS7A4901DGNR, 8 leads + distinct PowerPAD 9, F.Cu, CCW top view | 1 OUT=`5V_QUIET`; 2 FB=`LDO_FB`; 3 NC isolated; 4 GND; 5 EN=`VIN_PROTECTED`; 6 NR/SS=`LDO_NR`; 7 DNC isolated; 8 IN=`VIN_PROTECTED`; 9 PowerPAD=`GND` | PASS |
| U3 | TPD2E2U06DRLR, five distinct DRL pins, F.Cu, CCW top view | pins 1/2 NC isolated; 3 IO1=`AUDIO_P`; 4=`GND`; 5 IO2=`AUDIO_N` | PASS |

The regenerated exact-board dossiers contain all six commissioned refs. P-PINMAP independently reports PASS over four multi-pin refs and all 38 declared physical identities in its scope. The unchanged exact board and normalized netlist retain the hashes above; the changed semantic rules digest is caused by the new deterministic seed geometry.

## R12.1 seed impact

R12 is a front-mounted 0805 resistor at (57.0, 36.0) mm. Pad 1 is `OUTP_DRV`, centered at (56.0875, 36.0) mm with a 1.025 x 1.4 mm copper land. The seed is a 0.26 mm F.Cu segment from that pad center to a 0.60 mm / 0.30 mm via centered at (55.0, 36.0) mm.

Measured consequences:

- pad-center to via-center distance: 1.0875 mm;
- the segment begins at the exact pad center and continuously bridges the 0.275 mm pad-edge-to-via-annulus gap;
- the via is off-pad and its annulus ends at x=55.30 mm, 0.02 mm outside the R12 courtyard boundary at x=55.32 mm;
- clearance from the via annulus to R12.2 (`AUDIO_P`) pad bounding copper is 2.10 mm;
- the next non-R12 pad is TP5.1, with conservative via-annulus-to-pad-bounding-copper separation 4.513 mm;
- no fitted SMD moves to B.Cu and the via is not beneath a component body or paste land.

The seed therefore creates no pin-numbering, polarity, via-in-pad, solder-wicking, body-clearance, or one-sided-assembly concern. It remains a routing-stage obligation to ensure the completed `OUTP_DRV` route consumes this escape without leaving a dangling stub and passes the unfiltered post-route checks.

## Evidence and qualification

Evidence is under `/tmp/pod-r12-pin-review`: `identity.json`, `board-measurements.json`, `dossiers-current/{D1,D2,J1,U1,U2,U3}.md`, `complete-bom.csv`, and `pin-map-check.txt`.

The current generated `06_build/fab/bom.csv` predates the exact D1 source renewal and still names the superseded JKSEMI part; it also intentionally omits manual J1. For this pin audit only, the temporary evidence BOM selects D1 from the native board MPN (`S1M-E3/61T`) and adds manual J1 so the dossier denominator matches the six commissioned references. This is not a pin-design defect, but the manufacturing BOM must be regenerated before any release/fab acceptance and must never be used as the complete physical-pin census.

FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains in force.
