import pcbnew, json, math, hashlib, yaml
from pathlib import Path
root=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
project=root/'projects/crow-mic-pod-v3'
board_path=project/'04_kicad/crow_mic_pod_v3.kicad_pcb'
board=pcbnew.LoadBoard(str(board_path))
mm=pcbnew.ToMM
refs=['D1','D2','J1','U1','U2','U3']
footprints={f.GetReference():f for f in board.GetFootprints()}
def layers(p):
    return [pcbnew.LayerName(i) for i in range(pcbnew.PCB_LAYER_ID_COUNT) if p.IsOnLayer(i)]
def pdata(p):
    pos=p.GetPosition(); size=p.GetSize(); drill=p.GetDrillSize()
    return {'pad':p.GetNumber(),'net':p.GetNetname(),'x_mm':mm(pos.x),'y_mm':mm(pos.y),
            'size_x_mm':mm(size.x),'size_y_mm':mm(size.y),'drill_x_mm':mm(drill.x),'drill_y_mm':mm(drill.y),
            'attribute':str(p.GetAttribute()), 'layers':layers(p)}
out={'board_sha256':hashlib.sha256(board_path.read_bytes()).hexdigest(),'refs':{}}
for ref in refs+['R12']:
    f=footprints[ref]
    pos=f.GetPosition()
    out['refs'][ref]={'x_mm':mm(pos.x),'y_mm':mm(pos.y),'orientation_deg':f.GetOrientationDegrees(),
                      'layer':pcbnew.LayerName(f.GetLayer()),'pads':[pdata(p) for p in f.Pads()]}
via=(55.0,36.0); a=(56.0875,36.0); b=via
# conservative axis-aligned copper edge distance from circular via to pad bboxes; enough to identify closest pads.
near=[]
for f in board.GetFootprints():
  for p in f.Pads():
    pos=p.GetPosition(); size=p.GetSize(); px,py=mm(pos.x),mm(pos.y); sx,sy=mm(size.x),mm(size.y)
    dx=max(abs(via[0]-px)-sx/2,0); dy=max(abs(via[1]-py)-sy/2,0)
    bbox_dist=math.hypot(dx,dy)
    near.append({'ref':f.GetReference(),'pad':p.GetNumber(),'net':p.GetNetname(),'center_x_mm':px,'center_y_mm':py,
                 'size_x_mm':sx,'size_y_mm':sy,'via_center_to_pad_bbox_mm':bbox_dist,
                 'conservative_via_annulus_to_pad_bbox_mm':bbox_dist-0.3})
out['r12_seed']={'net':'OUTP_DRV','pad':'R12.1','start_mm':a,'end_via_mm':b,'segment_width_mm':0.26,
 'via_size_mm':0.6,'via_drill_mm':0.3,'center_distance_mm':math.dist(a,b),
 'nearest_pads_by_bbox':sorted(near,key=lambda x:x['via_center_to_pad_bbox_mm'])[:12],
 'r12_courtyard_bbox_mm':{'x_min':55.32,'x_max':58.68,'y_min':35.05,'y_max':36.95},
 'via_center_x_clearance_outside_r12_courtyard_mm':55.32-55.0,
 'via_annulus_intrusion_into_r12_courtyard_bbox_mm':max(0,55.3-55.32)}
Path('/tmp/pod-r12-pin-review/board-measurements.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out['r12_seed'],indent=2))
