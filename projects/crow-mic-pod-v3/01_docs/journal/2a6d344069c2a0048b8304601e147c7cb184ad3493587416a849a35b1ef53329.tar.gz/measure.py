import hashlib, importlib.util, json, math
from datetime import datetime, timezone
from pathlib import Path
import pcbnew
ROOT=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
P=ROOT/'projects/crow-mic-pod-v3'
BOARD=P/'04_kicad/crow_mic_pod_v3.kicad_pcb'
NET=P/'06_build/netlists/crow_mic_pod_v3.net'
ROUTE=P/'03_src/route.yaml'
R0=P/'06_build/route/r0.kicad_pcb'
CHECK=ROOT/'skills/kicad-pcb/scripts/pre_route_review_check.py'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('pr',CHECK); pr=importlib.util.module_from_spec(spec); spec.loader.exec_module(pr)
b=pcbnew.LoadBoard(str(R0))
IU=1_000_000
def mm(x): return x/IU
def pos(v): return [mm(v.x),mm(v.y)]
def target(net, xy):
    for t in b.GetTracks():
        if isinstance(t,pcbnew.PCB_VIA): continue
        if t.GetNetname()!=net: continue
        ends={tuple(round(z,3) for z in pos(t.GetStart())),tuple(round(z,3) for z in pos(t.GetEnd()))}
        if ends=={tuple(p) for p in xy}: return t
    raise RuntimeError((net,xy))
def target_via(net, at):
    for t in b.GetTracks():
        if isinstance(t,pcbnew.PCB_VIA) and t.GetNetname()==net and all(abs(a-c)<1e-6 for a,c in zip(pos(t.GetPosition()),at)): return t
    raise RuntimeError((net,at))
def pad(ref,num):
    f=b.FindFootprintByReference(ref)
    return next(p for p in f.Pads() if p.GetNumber()==str(num))
def obstacle_shapes(layer,target_net,exclude):
    out=[]
    for f in b.GetFootprints():
      for p in f.Pads():
        if p.GetNetname()==target_net or not p.IsOnLayer(layer): continue
        out.append((f'{f.GetReference()}.{p.GetNumber()} {p.GetNetname()}',p.GetEffectiveShape(layer)))
    for t in b.GetTracks():
      if id(t) in exclude or t.GetNetname()==target_net: continue
      if isinstance(t,pcbnew.PCB_VIA):
        if t.IsOnLayer(layer): out.append((f'via {t.GetNetname()} at {pos(t.GetPosition())}',t.GetEffectiveShape(layer)))
      elif t.GetLayer()==layer:
        out.append((f'track {t.GetNetname()} {pos(t.GetStart())}->{pos(t.GetEnd())}',t.GetEffectiveShape(layer)))
    return out
def nearest(sh,obs):
    vals=[(mm(sh.GetClearance(s)),name) for name,s in obs]
    return min(vals) if vals else (None,None)
def one(ref,num,net,start,end,width):
    p=pad(ref,num); seg=target(net,[start,end]); v=target_via(net,end)
    assert abs(mm(seg.GetWidth())-width)<1e-9
    ps=pos(p.GetPosition()); psz=[mm(p.GetSizeX()),mm(p.GetSizeY())]
    ss=pos(seg.GetStart()); ee=pos(seg.GetEnd()); vc=pos(v.GetPosition())
    # segment start is rounded to KiCad nanometre grid by producer
    start_offset=math.dist(ps,ss)
    axis_edge=psz[0]/2 if abs(end[0]-start[0])>abs(end[1]-start[1]) else psz[1]/2
    center_dist=math.dist(ps,vc); ann=mm(v.GetWidth(pcbnew.F_Cu))/2-mm(v.GetDrillValue())/2
    copper_gap=center_dist-axis_edge-mm(v.GetWidth(pcbnew.F_Cu))/2
    drill_gap=center_dist-axis_edge-mm(v.GetDrillValue())/2
    excluded={id(seg),id(v)}
    sobs=obstacle_shapes(pcbnew.F_Cu,net,excluded); vobsf=obstacle_shapes(pcbnew.F_Cu,net,excluded); vobsb=obstacle_shapes(pcbnew.B_Cu,net,excluded)
    ns=nearest(seg.GetEffectiveShape(pcbnew.F_Cu),sobs)
    nvf=nearest(v.GetEffectiveShape(pcbnew.F_Cu),vobsf)
    nvb=nearest(v.GetEffectiveShape(pcbnew.B_Cu),vobsb)
    edge_shapes=[d.GetEffectiveShape() for d in b.GetDrawings() if d.GetLayer()==pcbnew.Edge_Cuts]
    edge=min(mm(v.GetEffectiveShape(pcbnew.F_Cu).GetClearance(s)) for s in edge_shapes)
    # nearest footprint origins, a supplementary locator only
    comps=[]
    for f in b.GetFootprints():
      if f.GetReference()==ref: continue
      comps.append((math.dist(vc,pos(f.GetPosition())),f.GetReference(),pos(f.GetPosition())))
    comps.sort()
    return {
      'net':net,'pin':f'{ref}.{num}','pad_center_mm':ps,'pad_size_mm':psz,
      'realized_segment_mm':[ss,ee],'segment_width_mm':mm(seg.GetWidth()),
      'via_center_mm':vc,'via_size_mm':mm(v.GetWidth(pcbnew.F_Cu)),'via_drill_mm':mm(v.GetDrillValue()),
      'via_annulus_mm':ann,'segment_start_offset_from_pad_center_mm':start_offset,
      'segment_centerline_inside_pad_to_edge_mm':axis_edge-start_offset,
      'pad_copper_to_via_annulus_gap_mm':copper_gap,'pad_copper_to_via_drill_gap_mm':drill_gap,
      'nearest_foreign_clearance_segment_FCu_mm':ns[0],'nearest_foreign_segment_limiter':ns[1],
      'nearest_foreign_clearance_via_FCu_mm':nvf[0],'nearest_foreign_via_FCu_limiter':nvf[1],
      'nearest_foreign_clearance_via_BCu_mm':nvb[0],'nearest_foreign_via_BCu_limiter':nvb[1],
      'nearest_board_edge_clearance_from_via_annulus_mm':edge,
      'nearest_component_origins_mm':[{'distance':x,'reference':r,'position':p} for x,r,p in comps[:5]],
    }
drc=json.loads(Path('/tmp/pod-final-layout-review-20260914T044153Z/r0-drc-parity.json').read_text())
from collections import Counter
vtypes=Counter(x.get('type') for x in drc.get('violations',[]))
seed_via_positions=[]
for x in drc.get('violations',[]):
  if x.get('type')=='via_dangling':
    for item in x.get('items',[]):
      p=item.get('pos',{}); xy=[p.get('x'),p.get('y')]
      if xy in ([55.0,36.0],[66.0,39.0]): seed_via_positions.append(xy)
res={
 'schema':1,'reviewer':'Codex /root/pod_r3_layout_review final','completed_at':datetime.now(timezone.utc).isoformat(),
 'design_verdict':'SOUND','board_sha256':sha(BOARD),'netlist_sha256':pr.netlist_digest(NET),
 'design_rules_sha256':pr.design_rules_digest(P),'route_yaml_sha256':sha(ROUTE),
 'checker_sha256':sha(CHECK),'prepared_board_sha256':sha(R0),
 'census':{'footprints_FCu':sum(f.GetLayer()==pcbnew.F_Cu for f in b.GetFootprints()),'footprints_BCu':sum(f.GetLayer()==pcbnew.B_Cu for f in b.GetFootprints()),
           'smd_footprints_FCu':sum(bool(f.GetAttributes() & pcbnew.FP_SMD) and f.GetLayer()==pcbnew.F_Cu for f in b.GetFootprints()),
           'smd_footprints_BCu':sum(bool(f.GetAttributes() & pcbnew.FP_SMD) and f.GetLayer()==pcbnew.B_Cu for f in b.GetFootprints())},
 'drc':{'returncode':0,'violations_total':len(drc.get('violations',[])),'unconnected_items':len(drc.get('unconnected_items',[])),
        'schematic_parity':len(drc.get('schematic_parity',[])),'types':dict(vtypes),
        'hard_physical_clearance_short_drill_findings':sum(vtypes.get(k,0) for k in ('clearance','shorting_items','hole_clearance','drill_out_of_range','track_width')),
        'seed_specific_via_dangling_positions':seed_via_positions},
 'required_clearance_mm':0.15,
 'seeds':[
  one('R12',1,'OUTP_DRV',[56.087,36.0],[55.0,36.0],0.26),
  one('R3',2,'MIC_BIAS',[64.912,39.0],[66.0,39.0],0.5),
 ],
 'limitations':['prepared pre-route anchors remain intentionally dangling on B.Cu until routing consumes them','completed-route and release/order acceptance are not claimed']
}
Path('/tmp/pod-final-layout-review-20260914T044153Z/measurements-base.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n')
print(json.dumps(res,indent=2,sort_keys=True))
