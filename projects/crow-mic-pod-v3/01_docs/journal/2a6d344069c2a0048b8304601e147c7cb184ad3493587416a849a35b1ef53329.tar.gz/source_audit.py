import json, hashlib
from pathlib import Path
from collections import Counter,defaultdict
import yaml,pcbnew
root=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901'); p=root/'projects/crow-mic-pod-v3'
route=yaml.safe_load((p/'03_src/route.yaml').read_text())
r0=pcbnew.LoadBoard(str(p/'06_build/route/r0.kicad_pcb'))
tracks=[t for t in r0.GetTracks() if not isinstance(t,pcbnew.PCB_VIA)]
vias=[t for t in r0.GetTracks() if isinstance(t,pcbnew.PCB_VIA)]
def pos(v): return [round(x,6) for x in pcbnew.ToMM(v)]
def has_seg(net,a,b):
 q={tuple(a),tuple(b)}
 return any(t.GetNetname()==net and {tuple(pos(t.GetStart())),tuple(pos(t.GetEnd()))}==q for t in tracks)
def has_via(net,at): return any(t.GetNetname()==net and pos(t.GetPosition())==at for t in vias)
canon=route['stitch']['canonicalize_chains']['edits']
floors={'AUDIO_P':.25,'AUDIO_N':.25,'OUTP_DRV':.25,'MIC_BIAS':.4}
ca=[]
for e in canon:
 ca.append({'net':e['net'],'layer':e['layer'],'width_mm':e['width'],'floor_mm':floors[e['net']],
            'reason':e['reason'],'remove_count':len(e['remove']),'add_count':len(e['add']),
            'all_points_numeric':all(isinstance(x,(int,float)) and not isinstance(x,bool) for s in e['remove']+e['add'] for pt in s for x in pt),
            'no_zero_length':all(s[0]!=s[1] for s in e['remove']+e['add'])})
res={
 'schema':1,
 'r0_copper':{'track_count':len(tracks),'via_count':len(vias),
   'tracks_by_layer':dict(Counter(t.GetLayerName() for t in tracks)),
   'vias_by_net':dict(Counter(t.GetNetname() for t in vias)),
   'minimum_track_width_by_net_mm':{n:min(round(pcbnew.ToMM(t.GetWidth()),6) for t in tracks if t.GetNetname()==n) for n in sorted({t.GetNetname() for t in tracks})}},
 'removed_prepared_copper_absence':{
   'PRE_OUT_stub':not has_seg('PRE_OUT',[55.025,52.81],[53.5,52.81]),
   'AUDIO_P_via_49_6_34_25':not has_via('AUDIO_P',[49.6,34.25]),
   'AUDIO_N_via_47_2875_36_25':not has_via('AUDIO_N',[47.2875,36.25]),
   'AUDIO_N_via_62_913_34_7':not has_via('AUDIO_N',[62.913,34.7])},
 'required_seed_presence':{
   'OUTP_DRV_segment':has_seg('OUTP_DRV',[56.087,36.0],[55.0,36.0]),
   'OUTP_DRV_via':has_via('OUTP_DRV',[55.0,36.0]),
   'MIC_BIAS_segment':has_seg('MIC_BIAS',[64.912,39.0],[66.0,39.0]),
   'MIC_BIAS_via':has_via('MIC_BIAS',[66.0,39.0])},
 'canonicalization':{'edit_count':len(canon),'remove_count':sum(len(e['remove']) for e in canon),'add_count':sum(len(e['add']) for e in canon),
   'all_FCu':all(e['layer']=='F.Cu' for e in canon),'all_widths_meet_net_floor':all(e['width']>=floors[e['net']] for e in canon),
   'edits':ca},
 'v9_evidence':{'board_sha256':hashlib.sha256(Path('/tmp/pod-clean-test-v9/crow_mic_pod_v3.kicad_pcb').read_bytes()).hexdigest(),
                'drc_sha256':hashlib.sha256(Path('/tmp/pod-clean-test-v9/drc.json').read_bytes()).hexdigest(),
                'critical_path_sha256':hashlib.sha256(Path('/tmp/pod-clean-test-v9/realized.json').read_bytes()).hexdigest()},
}
Path('/tmp/pod-final-layout-review-20260914T044153Z/source-audit.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n')
print(json.dumps(res,indent=2,sort_keys=True))
