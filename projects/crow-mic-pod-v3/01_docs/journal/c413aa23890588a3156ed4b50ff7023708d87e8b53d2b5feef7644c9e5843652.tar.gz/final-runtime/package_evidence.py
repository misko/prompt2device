from pathlib import Path, PurePosixPath
import hashlib
import json
import shutil
import stat
import sys
import tarfile

ROOT = Path("/tmp/rj45-pin-pod-interface-s1m2-3wbqj5q7")
RUN = ROOT / "06_build/task_runs/rj45-pin-pod-interface-s1m2"
SCRATCH = RUN / "scratch"
OUTPUTS = RUN / "outputs"
PAYLOAD = SCRATCH / "evidence-payload"
sys.path.insert(0, "/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts")
from pipeline_execution import TaskEnvelope, verify_input_packet


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


envelope = TaskEnvelope.from_json((RUN / "envelope.json").read_text())
ok_before, failures_before = verify_input_packet(envelope, ROOT)
if not ok_before:
    raise SystemExit(f"input verification before packaging failed: {failures_before}")

PAYLOAD.mkdir(exist_ok=False)
verification_before = {
    "status": "PASS",
    "phase": "before engineering comparison",
    "items": [
        {"name": item.name, "path": item.path, "size": item.size, "sha256": item.sha256}
        for item in envelope.input_packet
    ],
    "failures": [],
}
(PAYLOAD / "input-verification-before.json").write_text(
    json.dumps(verification_before, indent=2, sort_keys=True) + "\n")

copies = {
    ROOT / "TASK.md": PAYLOAD / "TASK.md",
    ROOT / "pin-review-protocol.md": PAYLOAD / "pin-review-protocol.md",
    ROOT / "dossiers/J1.md": PAYLOAD / "dossier-J1.md",
    ROOT / "dossiers/U3.md": PAYLOAD / "dossier-U3.md",
    OUTPUTS / "report.md": PAYLOAD / "report.md",
    OUTPUTS / "evidence.json": PAYLOAD / "evidence.json",
    SCRATCH / "methods.md": PAYLOAD / "methods.md",
    SCRATCH / "wurth-1.png": PAYLOAD / "wurth-page-1.png",
    SCRATCH / "wurth-2.png": PAYLOAD / "wurth-page-2.png",
    SCRATCH / "ti-03.png": PAYLOAD / "ti-page-03.png",
    SCRATCH / "ti-12.png": PAYLOAD / "ti-page-12.png",
    SCRATCH / "wurth.txt": PAYLOAD / "wurth-pdftotext.txt",
    SCRATCH / "ti.txt": PAYLOAD / "ti-pdftotext.txt",
    SCRATCH / "runtime-outcomes.json": PAYLOAD / "runtime-outcomes.json",
}
for source, target in copies.items():
    shutil.copyfile(source, target)
for source in sorted(SCRATCH.glob("*.log")):
    shutil.copyfile(source, PAYLOAD / source.name)

ok_after, failures_after = verify_input_packet(envelope, ROOT)
if not ok_after:
    raise SystemExit(f"input verification after review failed: {failures_after}")
(PAYLOAD / "input-verification-after.json").write_text(json.dumps({
    "status": "PASS",
    "phase": "after engineering comparison and before packaging",
    "verified_item_count": len(envelope.input_packet),
    "failures": [],
}, indent=2, sort_keys=True) + "\n")

archive = OUTPUTS / "evidence.tar.gz"
members = []
with tarfile.open(archive, "x:gz", format=tarfile.PAX_FORMAT) as bundle:
    for source in sorted(PAYLOAD.iterdir(), key=lambda p: p.name):
        if source.is_symlink() or not source.is_file():
            raise SystemExit(f"non-regular payload member: {source}")
        arcname = f"evidence/{source.name}"
        bundle.add(source, arcname=arcname, recursive=False)

seen = set()
with tarfile.open(archive, "r:gz") as bundle:
    for info in bundle.getmembers():
        path = PurePosixPath(info.name)
        if info.name in seen or path.is_absolute() or ".." in path.parts:
            raise SystemExit(f"unsafe or duplicate archive member: {info.name}")
        seen.add(info.name)
        if not info.isfile():
            raise SystemExit(f"archive contains non-regular member: {info.name}")
        extracted = bundle.extractfile(info)
        if extracted is None:
            raise SystemExit(f"cannot reopen archive member: {info.name}")
        data = extracted.read()
        if len(data) != info.size:
            raise SystemExit(f"archive size mismatch: {info.name}")
        members.append({
            "path": info.name,
            "size": info.size,
            "sha256": hashlib.sha256(data).hexdigest(),
        })

manifest = {
    "archive_sha256": digest(archive),
    "archive_size": archive.stat().st_size,
    "member_count": len(members),
    "members": members,
}
(OUTPUTS / "evidence-manifest.json").write_text(
    json.dumps(manifest, indent=2, sort_keys=True) + "\n")
