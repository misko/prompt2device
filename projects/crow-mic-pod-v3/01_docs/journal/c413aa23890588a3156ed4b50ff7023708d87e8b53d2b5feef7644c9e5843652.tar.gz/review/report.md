review_stage: pre-route
review_kind: pin
reviewer: /root/rj45_pin_pod_interface_s1m2
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: af9bb3c0dcf5e9be20239d725d10dd4d4c1bf95cc0b7518badc3e27bd6523938
parts_sha256: d0d0026dd67cbfaa98176799ea34ea3bfde384675d74d58d8cf8f0c88e41fd89
design_rules_sha256: 474e5d0a81baf576aefac32e9c60bce37704bb138961c16bf92573843b6409c4
completed_at: 2026-09-14T03:45:40.832231Z

# Fresh independent pin review — pod interface

Coverage is deliberately limited to the commissioned group `J1,U3`. This is not whole-board acceptance. Both commissioned references were reviewed from the frozen native dossiers and their digest-bound primary manufacturer PDFs. No live project content or prior review was used.

## J1 — 615008160221

VERDICT: PASS

- Measured native inventory: 10 numbered plated pads representing 8 individual contacts and 2 individual shield solder-tab identities, plus 2 separate anonymous NPTH locating features. Physical identity count is 10 electrical/shield identities; total footprint feature count is 12. No fused identities, exposed pad, or declared aliases apply.
- Primary evidence: Würth Elektronik PDF SHA-256 `6ed18749211d4e6cbffd99cd0b90461dfe4ec6d70f558ceceeb5901651f0e048`, PDF page 1/6, figures `Dimensions: [mm]` and `Recommended Hole Pattern: [mm]`; page 2/6, `Article Properties` (`8P8C`).
- Expected package and identities: eight contact holes on 1.02 mm pitch in two rows separated by 4.00 mm; two 3.18 mm locating holes separated by 13.70 mm; and two shield solder slots separated by 14.80 mm and offset 3.05 mm from the locating-hole axis. Observed dossier geometry matches every dimension: contacts 1–8 use 1.02 mm x pitch and 4.00 mm row spacing; NPTH centers differ by 13.70 mm; shield pad centers differ by 14.80 mm and are 3.05 mm from the NPTH axis. The manufacturer hole-pattern contact identities `8,6,4,2` / `7,5,3,1`, as drawn, become dossier rows `1,3,5,7` / `2,4,6,8` by a 180° rotation only. Pin 1 therefore lands at dossier local `(0,0)` without a mirror.
- Winding interpretation: this connector's staggered, collinear contact rows do not independently establish a perimeter winding. Under the protocol's connector/collinear rule, the individual manufacturer contact identities are controlling evidence. All eight identities agree after rotation; the dossier's reported CCW result is not being used to conceal a mirror.
- Electrical sanity: `CONTACT_1..8` are generic connector contacts and the observed `12V_POD`, `GND`, `AUDIO_N`, and `AUDIO_P` nets are permissible contact nets. The two independent shield tabs both connect to `POD_SHIELD`, consistent with their physical role. The primary connector document imposes no contact-function assignment that conflicts with the dossier.
- Instance symmetry: not applicable; this packet contains one instance of this part.

## U3 — TPD2E2U06DRLR

VERDICT: PASS

- Measured native inventory: 5 copper pads and 5 individual physical pin identities. There is no exposed pad and no fused or declared alias.
- Primary evidence: Texas Instruments SLLSEG9C PDF SHA-256 `a133b86ea3d3c3d34667339b92d3b5e98d541d10e9775d63e7cdfa153794f4ed`, PDF page 3, `DRL Package 5-Pin SOT Top View` and Pin Functions table; PDF page 12, Figure 12 `Routing with DRL Package`.
- Expected package, pin-1 corner, and winding: DRL 5-pin SOT top view has pin 1 at upper left, pins 1/2/3 descending on the left, pin 4 at lower right, and pin 5 at upper right, a CCW top-view sequence. Observed component-top coordinates put pins 1/2/3 at left top/middle/bottom and pins 4/5 at right bottom/top. This is an exact rotation-frame match with no mirror.
- Expected vs observed functions: pin 1 `NC` -> isolated net `unconnected-(U3-NC1-Pad1)`; pin 2 `NC` -> isolated net `unconnected-(U3-NC2-Pad2)`; pin 3 `IO1` -> `AUDIO_P`; pin 4 `GND` -> `GND`; pin 5 `IO2` -> `AUDIO_N`. TI explicitly permits NC pins to float, be grounded, or connect to VCC, so the observed isolated identities are valid. Both IO pins carry signal nets and the ground pin carries ground, consistent with the page-3 table and page-12 routing figure.
- Instance symmetry: not applicable; this packet contains one instance of this part.

No unresolved findings were found in the commissioned group. The engineering domain verdict is SOUND. The order verdict remains DO-NOT-ORDER because this limited review is not release authorization.
