from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,sys
from datetime import datetime,timezone
N=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');name='rj45-pod-clamp-seed-source';m=json.loads((N/(name+'-opened.json')).read_text());D=Path(m['project']);E=Path(m['envelope']);O=Path(m['output_dir']);env=json.loads(E.read_text());assert json.loads((E.parent/'attempt.json').read_text())['status']=='PASS';close=json.loads((N/(name+'-closeout-summary.json')).read_text());assert hashlib.sha256(Path(close['archive']).read_bytes()).hexdigest()==close['sha256']
for row in env['input_packet']:
 p=D/row['path'];b=p.read_bytes();assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256']
for p in (D/'input').rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(D/'input').as_posix()
 if rel.startswith(('skills/','projects/crow-mic-pod-v3/02_parts/','projects/crow-mic-pod-v3/03_src/','projects/crow-mic-pod-v3/03_tscircuit/','projects/crow-mic-pod-v3/04_kicad/')):assert (R/rel).read_bytes()==p.read_bytes(),rel
x=json.loads((O/'evidence.json').read_text());assert x['subject']==env['subject'];assert x['source_revision_count']==1 and x['candidate_prep']['refused']==0 and x['candidate_prep']['served_banks']==12;assert not x['native_proof']['foreign_copper_collisions'];assert x['native_proof']['footprint_projections_unchanged'];change=x['candidate_source'];assert change['path']=='projects/crow-mic-pod-v3/03_src/route.yaml';assert hashlib.sha256((R/change['path']).read_bytes()).hexdigest()==change['before_sha256']
f=json.loads((O/'evidence-manifest.json').read_text());assert hashlib.sha256((O/'evidence.tar.gz').read_bytes()).hexdigest()==f['archive_sha256'];idx={r['path']:r for r in f['members']};selected={}
with tarfile.open(O/'evidence.tar.gz') as t:
 assert len(t.getmembers())==len(idx)==f['member_count']
 for member in t.getmembers():
  assert member.isfile() and not PurePosixPath(member.name).is_absolute() and '..' not in PurePosixPath(member.name).parts
  b=t.extractfile(member).read();r=idx[member.name];assert len(b)==r['size'] and hashlib.sha256(b).hexdigest()==r['sha256']
  if member.name.startswith('source_candidate/'):selected[member.name.removeprefix('source_candidate/')]=b
assert list(selected)==[change['path']];candidate=selected[change['path']];assert hashlib.sha256(candidate).hexdigest()==change['after_sha256'];root=json.loads((N/'pod-clamp-root-source-geometry.json').read_text());assert root['candidate_sha256']==change['after_sha256'];assert len(root['paths'])==3 and all(r['copper_edge_gap_mm']>=.15 for r in root['pair_clearances'])
record={'created_at':datetime.now(timezone.utc).isoformat(),'source_change':change,'author_closeout':close,'root_independent_geometry':root,'scope':'Accept exact three source coordinate lists only. Fresh source/checkpoint/schematic/placement renewal required. Candidate full native6/34/0 and VIN_PROTECTED oracle failure remain open.','applied':'--apply' in sys.argv}
if record['applied']:
 target=R/change['path'];target.write_bytes(candidate);assert hashlib.sha256(target.read_bytes()).hexdigest()==change['after_sha256'];(N/'pod-clamp-source-adoption.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'change':change,'applied':record['applied'],'inputs':len(env['input_packet']),'archive_members':len(idx)},indent=2))
