from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,tarfile,gzip,io
R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');N=Path(__file__).parent;I=Path('/tmp/carrier-connector-integration-20260911');P=R/'projects/crow-mic-pod-v3';files={}
def add(p,k):
 assert p.is_file() and not p.is_symlink() and k not in files;files[k]=p.read_bytes()
for n in ['pod-clamp-source-adoption.json','pod-clamp-root-source-geometry.json','check_pod_clamp_source_geometry.py','adopt_pod_clamp_source.py','preserve_placement_source.py','archive_placement_restart.py','crow-mic-pod-v3-clamp-seed1-restart-summary.json','preserve_pod_clamp_adoption.py']:
 add(N/n,'root/'+n)
for prefix in ['pod-clamp-root-source-geometry','pod-clamp-seed1-full-native']:
 for p in I.glob(prefix+'*'):
  if p.is_file():add(p,'runtime/'+p.name)
for rel in ['03_src/route.yaml','01_docs/STATUS.md','01_docs/findings.yaml','06_build/agent_handoff.yaml']:
 add(P/rel,'current/'+rel)
files['CHECKPOINT.json']=(json.dumps({'created_at':datetime.now(timezone.utc).isoformat(),'scope':'Exact three pod source paths accepted; regenerated schematic awaits normal public admission and independent current reviews. Existing physical and full-route holds remain.'},indent=2)+'\n').encode();files['MANIFEST.json']=(json.dumps({'files':[{'path':k,'size':len(v),'sha256':hashlib.sha256(v).hexdigest()} for k,v in sorted(files.items())]},indent=2)+'\n').encode();tmp=N/'pod-clamp-adoption.tmp'
with tmp.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for k,b in sorted(files.items()):x=tarfile.TarInfo(k);x.size=len(b);x.mode=0o644;t.addfile(x,io.BytesIO(b))
with tarfile.open(tmp) as t:
 assert len(t.getmembers())==len(files)==len({x.name for x in t.getmembers()})
 for x in t.getmembers():assert x.isfile() and t.extractfile(x).read()==files[x.name]
b=tmp.read_bytes();h=hashlib.sha256(b).hexdigest();J=P/'01_docs/journal';dest=J/(h+'.tar.gz');assert not dest.exists();dest.write_bytes(b)
with (J/'contracts.md').open('a') as f:f.write(f'\n## Allowed pod clamp source adoption checkpoint\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | Exact one-file adoption, root independent source geometry and methods, bounded normal regeneration and current state; no layout/release acceptance |\n\nAudit: SHA-256 equals filename; {len(b)} bytes / {len(files)} regular members, all reopened against MANIFEST.json.\n')
s={'archive':str(dest),'sha256':h,'size':len(b),'members':len(files)};(N/'pod-clamp-adoption-summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s,indent=2))
