from pathlib import Path
import yaml,math,json,hashlib,itertools
N=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');live=R/'projects/crow-mic-pod-v3/03_src/route.yaml';p=Path('/tmp/rj45-pod-clamp-seed-source-d8xdompb/06_build/task_runs/rj45-pod-clamp-seed-source/scratch/variants/candidate1/route.yaml');a=yaml.safe_load(live.read_text());b=yaml.safe_load(p.read_text());wanted={'GND':'U3.4','AUDIO_P':'J1.5','AUDIO_N':'J1.4'};rows=[];lines={}
def point_segment(p,a,b):
 d=[b[i]-a[i] for i in (0,1)];den=sum(x*x for x in d);assert den>0
 t=max(0,min(1,sum((p[i]-a[i])*d[i] for i in (0,1))/den));return math.dist(p,[a[i]+t*d[i] for i in (0,1)])
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
def seg_distance(a,b,c,d):
 if cross(a,b,c)*cross(a,b,d)<0 and cross(c,d,a)*cross(c,d,b)<0:return 0
 return min(point_segment(a,c,d),point_segment(b,c,d),point_segment(c,a,b),point_segment(d,a,b))
for old,new in zip(a['prep']['seed_stubs']['stubs'],b['prep']['seed_stubs']['stubs'],strict=True):
 if old==new:continue
 assert new['net'] in wanted and wanted[new['net']]==new['pin'];assert len(new['segments'])==len(old['segments'])==1
 save=old['segments'][0]['pts'];old['segments'][0]['pts']=new['segments'][0]['pts'];assert old==new
 seg=new['segments'][0];assert seg['layer']=='B.Cu';assert seg['width']==(.50 if new['net']=='GND' else .26)
 lines[new['net']]=(list(zip(seg['pts'],seg['pts'][1:])),seg['width']);length=sum(math.dist(x,y) for x,y in zip(seg['pts'],seg['pts'][1:]));rows.append({'net':new['net'],'start':seg['pts'][0],'end':seg['pts'][-1],'length_mm':length,'before':save,'after':seg['pts']})
assert a==b and len(rows)==3
pairs=[]
for (n,(line,width)),(n2,(other,w2)) in itertools.combinations(lines.items(),2):
 gap=min(seg_distance(*s,*t) for s in line for t in other)-(width+w2)/2;assert gap>=.15,(n,n2,gap);pairs.append({'a':n,'b':n2,'copper_edge_gap_mm':gap})
o={'scope':'Root independent analytical source delta and whole-polyline pair clearance; native pad/obstacle/DRC proof remains separate','setup':'Initial optional Shapely import unavailable, no files changed; pure analytic endpoint-to-segment distance plus crossing test used.','candidate_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'paths':rows,'pair_clearances':pairs};(N/'pod-clamp-root-source-geometry.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2))
