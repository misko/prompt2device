# pin dossier: U_LDO_EN  (74LVC1G14GV,125)

- footprint: Package_TO_SOT_SMD:SOT-23-5
- board position: (57.1, 70.8) rot 0
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/74LVC1G14GV,125/74LVC1G14_Rev19.pdf
- part.yaml verification note: CITED: Nexperia Rev19 p1 arbitrary input slew and partial-power operation; p3 exact SOT753 pinout; p5 1uA input /2uA Ioff and 100uA VOH/VOL limits across -40..125C. Source-only design selection; physical tests OWED.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-1.14,-0.95) | W | 1.32x0.6 | NC | unconnected-(U_LDO_EN-NC-Pad1) |
| 2 | (-1.14,+0.00) | W | 1.32x0.6 | A | DUMP_GATE |
| 3 | (-1.14,+0.95) | W | 1.32x0.6 | GND | GND |
| 4 | (+1.14,+0.95) | E | 1.32x0.6 | Y | LDO_EN |
| 5 | (+1.14,-0.95) | E | 1.32x0.6 | VCC | 5V_LDO_HOLD |
