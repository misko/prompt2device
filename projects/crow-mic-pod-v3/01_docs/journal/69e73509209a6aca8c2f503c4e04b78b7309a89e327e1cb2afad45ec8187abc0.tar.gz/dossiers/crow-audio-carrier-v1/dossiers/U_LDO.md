# pin dossier: U_LDO  (LT3041ADE#TRPBF)

- footprint: Package_DFN_QFN:DFN-14-1EP_3x4mm_P0.5mm_EP1.7x3.3mm
- board position: (64.5, 70.0) rot 0
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/LT3041ADE-TRPBF/LT3041_RevA.pdf
- part.yaml verification note: Primary Rev.A pin table and package05-08-1708 inspected independently; standard KiCad pad1(-1.45,-1.5),14(1.45,-1.5), EP15(0,0),1.7x3.3mm match the rotated manufacturer land drawing. JLC model/rotation and new placement remain unreviewed.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-1.45,-1.50) | N | 0.7x0.25 | IN | 5V_LDO_HOLD |
| 2 | (-1.45,-1.00) | W | 0.7x0.25 | IN | 5V_LDO_HOLD |
| 3 | (-1.45,-0.50) | W | 0.7x0.25 | IN | 5V_LDO_HOLD |
| 4 | (-1.45,+0.00) | W | 0.7x0.25 | VIOC | unconnected-(U_LDO-VIOC_NC-Pad4) |
| 5 | (-1.45,+0.50) | W | 0.7x0.25 | EN_UV | LDO_EN |
| 6 | (-1.45,+1.00) | W | 0.7x0.25 | PG | unconnected-(U_LDO-PG_NC-Pad6) |
| 7 | (-1.45,+1.50) | S | 0.7x0.25 | ILIM | GND |
| 8 | (+1.45,+1.50) | S | 0.7x0.25 | PGFB | 5V_LDO_HOLD |
| 9 | (+1.45,+1.00) | E | 0.7x0.25 | SET | LDO_NR |
| 10 | (+1.45,+0.50) | E | 0.7x0.25 | GND | GND |
| 11 | (+1.45,+0.00) | E | 0.7x0.25 | GND | GND |
| 12 | (+1.45,-0.50) | E | 0.7x0.25 | OUTS | 3V3_ADC |
| 13 | (+1.45,-1.00) | E | 0.7x0.25 | OUT | 3V3_ADC |
| 14 | (+1.45,-1.50) | N | 0.7x0.25 | OUT | 3V3_ADC |
| 15 | (+0.00,+0.00) | center | 1.7x3.3 | GND | GND |

(8 unnumbered paste/mechanical pads not shown)
