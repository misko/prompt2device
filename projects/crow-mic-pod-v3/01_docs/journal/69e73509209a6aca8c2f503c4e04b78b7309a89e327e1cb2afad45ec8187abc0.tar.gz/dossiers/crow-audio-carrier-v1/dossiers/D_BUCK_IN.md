# pin dossier: D_BUCK_IN  (US1B-13-F)

- footprint: Diode_SMD:D_SMA
- board position: (26.0, 58.0) rot 90
- computed winding of pins 1..N: **n/a (too few perimeter pins)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/US1B-13-F/Diodes_US1A_US1M_DS16008_Rev11-2.pdf
- part.yaml verification note: Primary exact US1B-13-F identity, cathode band, package and limits re-read 2026-09-09. Public exact C154439 identity only; not allocation or order acceptance.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-2.00,+0.00) | W | 2.5x1.8 | K | 12V_BUCK_IN |
| 2 | (+2.00,+0.00) | E | 2.5x1.8 | A | 12V_PROTECTED |
