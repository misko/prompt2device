# pin dossier: U_RST2  (SN74LVC1G123DCTR)

- footprint: Package_SO:SSOP-8_2.95x2.8mm_P0.65mm
- board position: (118.0, 72.0) rot 0
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/SN74LVC1G123DCTR/SN74LVC1G123_SCES586E.pdf
- part.yaml verification note: CITED: TI SCES586E Figure 4-1 and Table 4-1, PDF p.3, independently fix DCT pins 1=A, 2=B, 3=CLR, 4=GND, 5=Q, 6=Cext, 7=Rext/Cext, 8=VCC; re-read 2026-09-01.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-1.70,-0.97) | W | 0.3x1.6 | A | GND |
| 2 | (-1.70,-0.33) | W | 0.3x1.6 | B | 3V3_ADC |
| 3 | (-1.70,+0.33) | W | 0.3x1.6 | CLR# | POR_N |
| 4 | (-1.70,+0.97) | W | 0.3x1.6 | GND | GND |
| 5 | (+1.70,+0.97) | E | 0.3x1.6 | Q | RESET_PULSE_H |
| 6 | (+1.70,+0.33) | E | 0.3x1.6 | Cext | RESET_C |
| 7 | (+1.70,-0.33) | E | 0.3x1.6 | Rext/Cext | RESET_RC |
| 8 | (+1.70,-0.97) | E | 0.3x1.6 | VCC | 3V3_ADC |
