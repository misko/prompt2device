# pin dossier: Q_RST1  (2N7002K-7)

- footprint: crow_audio_carrier:Diodes_2N7002K_SOT23_Exact
- board position: (109.5, 73.5) rot 0
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/2N7002K-7/2N7002K_DS30896_Rev20-2.pdf
- part.yaml verification note: CITED: Diodes DS30896 Rev. 20-2 pin configuration and equivalent-circuit top-view figures, PDF p.1, independently fix pin 1=G, pin 2=S, pin 3=D; re-read 2026-09-01.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-1.00,-0.95) | W | 0.9x0.8 | G | RESET_PULSE_H |
| 2 | (-1.00,+0.95) | W | 0.9x0.8 | S | GND |
| 3 | (+1.00,+0.00) | E | 0.9x0.8 | D | ADC_RESET_N |
