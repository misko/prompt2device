# pin dossier: U_RST1  (TPS3839K33DBZR)

- footprint: Package_TO_SOT_SMD:SOT-23
- board position: (110.0, 68.0) rot 0
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/TPS3839K33DBZR/TPS3839_SBVS193D.pdf
- part.yaml verification note: CITED: TI SBVS193D DBZ package top view and pin table, PDF p.5, fix 1=GND, 2=RESET, 3=VDD; device-information/electrical tables, PDF pp.2 and 7, fix K33 threshold and delay; re-read 2026-09-01.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-0.94,-0.95) | N | 1.48x0.6 | GND | GND |
| 2 | (-0.94,+0.95) | S | 1.48x0.6 | RESET# | POR_N |
| 3 | (+0.94,+0.00) | E | 1.48x0.6 | VDD | 3V3_ADC |
