# pin dossier: U_AFE6  (OPA2320AIDR)

- footprint: Package_SO:SOIC-8_3.9x4.9mm_P1.27mm
- board position: (72.5, 93.0) rot 180
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/OPA2320AIDR/OPA2320_SBOS513F.pdf
- part.yaml verification note: CITED: SBOS513F p4 OPA2320 D-package top view and pin-functions table:1=OUTA,2=-INA,3=+INA,4=V-,5=+INB,6=-INB,7=OUTB,8=V+. Main visual read and fresh independent source review2026-09-09; generated/native acceptance remains incomplete.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-2.48,-1.91) | W | 1.95x0.6 | OUTA | OPA_P6 |
| 2 | (-2.48,-0.64) | W | 1.95x0.6 | -INA | FB_P6 |
| 3 | (-2.48,+0.64) | W | 1.95x0.6 | +INA | AIN_P6 |
| 4 | (-2.48,+1.91) | W | 1.95x0.6 | V- | GND |
| 5 | (+2.48,+1.91) | E | 1.95x0.6 | +INB | AIN_N6 |
| 6 | (+2.48,+0.64) | E | 1.95x0.6 | -INB | FB_N6 |
| 7 | (+2.48,-0.64) | E | 1.95x0.6 | OUTB | OPA_N6 |
| 8 | (+2.48,-1.91) | E | 1.95x0.6 | V+ | 3V3_ADC |
