# pin dossier: Q_IN  (DMP6023LFG-13)

- footprint: Package_SON:Diodes_PowerDI3333-8
- board position: (40.0, 74.8) rot 0
- computed winding of pins 1..N: **n/a (collinear perimeter pins)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/DMP6023LFG-13/DMP6023LFG_DS37204_Rev2-2.pdf
- part.yaml verification note: CITED: Diodes DS37204 Rev. 2-2 bottom/top-view pin drawing and ordering table, PDF p.1, fix pins 1-3=source, pin 4=gate, pins 5-8=common drain and the -13 suffix; the Maximum Ratings and Electrical Characteristics tables, PDF p.2, fix -60V VDS, +/-20V VGS, -6.2A at 70C and 25mOhm maximum at VGS=-10V. Extraction correction 2026-09-07: all eight physical identities retained, with explicit cited aliases for the manufacturer-fused drain positions; primary PDF revision/bytes unchanged.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-1.50,-0.97) | W | 0.7x0.42 | SOURCE | 12V_PROTECTED |
| 2 | (-1.50,-0.33) | W | 0.7x0.42 | SOURCE | 12V_PROTECTED |
| 3 | (-1.50,+0.33) | W | 0.7x0.42 | SOURCE | 12V_PROTECTED |
| 4 | (-1.50,+0.97) | W | 0.7x0.42 | GATE | Q_IN_GATE |
| 5 | (+0.46,+0.00) | E | 1.71x2.37 | DRAIN_COMMON | 12V_FUSED |

Declared pin aliases (review these against the manufacturer drawing):
- `6`: schematic `5`, footprint `5`, fused: `true`; why: Manufacturer drain positions 5-8 share the exposed drain leadframe; the source symbol and exact KiCad composite drain land use identity 5.; evidence: Diodes DS37204 Rev.2-2 p.1 bottom-view package figure and equivalent circuit; p.5 package/land drawing; Package_SON:Diodes_PowerDI3333-8 composite pad 5 includes all four drain fingers.
- `7`: schematic `5`, footprint `5`, fused: `true`; why: Manufacturer drain positions 5-8 share the exposed drain leadframe; the source symbol and exact KiCad composite drain land use identity 5.; evidence: Diodes DS37204 Rev.2-2 p.1 bottom-view package figure and equivalent circuit; p.5 package/land drawing; Package_SON:Diodes_PowerDI3333-8 composite pad 5 includes all four drain fingers.
- `8`: schematic `5`, footprint `5`, fused: `true`; why: Manufacturer drain positions 5-8 share the exposed drain leadframe; the source symbol and exact KiCad composite drain land use identity 5.; evidence: Diodes DS37204 Rev.2-2 p.1 bottom-view package figure and equivalent circuit; p.5 package/land drawing; Package_SON:Diodes_PowerDI3333-8 composite pad 5 includes all four drain fingers.

(8 unnumbered paste/mechanical pads not shown)
