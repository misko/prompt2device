# pin dossier: U_CLK  (SN74LVC3G34DCUR)

- footprint: Package_SO:VSSOP-8_2.3x2mm_P0.5mm
- board position: (147.0, 59.0) rot 0
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/SN74LVC3G34DCUR/SN74LVC3G34_SCES366L.pdf
- part.yaml verification note: CITED: TI SCES366L DCU top view and pin-functions table, PDF p.3, independently fix 1=1A, 2=3Y, 3=2A, 4=GND, 5=2Y, 6=3A, 7=1Y, 8=VCC; re-read 2026-09-01.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-1.40,-0.75) | W | 1.25x0.35 | 1A | MCH_MCLK |
| 2 | (-1.40,-0.25) | W | 1.25x0.35 | 3Y | FSYNC_BUF |
| 3 | (-1.40,+0.25) | W | 1.25x0.35 | 2A | MCH_BCLK |
| 4 | (-1.40,+0.75) | W | 1.25x0.35 | GND | GND |
| 5 | (+1.40,+0.75) | E | 1.25x0.35 | 2Y | BCLK_BUF |
| 6 | (+1.40,+0.25) | E | 1.25x0.35 | 3A | MCH_FSYNC |
| 7 | (+1.40,-0.25) | E | 1.25x0.35 | 1Y | MCLK_BUF |
| 8 | (+1.40,-0.75) | E | 1.25x0.35 | VCC | 3V3_ADC |
