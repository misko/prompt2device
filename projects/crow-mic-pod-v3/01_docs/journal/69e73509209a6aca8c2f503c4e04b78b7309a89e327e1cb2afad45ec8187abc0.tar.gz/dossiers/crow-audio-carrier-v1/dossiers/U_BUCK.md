# pin dossier: U_BUCK  (AP63205WU-7)

- footprint: Package_TO_SOT_SMD:TSOT-23-6
- board position: (42.0, 66.0) rot 0
- computed winding of pins 1..N: **CCW (top view)**
- datasheet: projects/crow-audio-carrier-v1/02_parts/AP63205WU-7/AP63205_DS41326_Rev3-2.pdf
- part.yaml verification note: CITED: Diodes DS41326 Rev. 3-2 Pin Descriptions, PDF p.2, fix 1=FB, 2=EN, 3=VIN, 4=GND, 5=SW, 6=BST; Table 3, Section 10, and ordering table, PDF pp.12-16, fix the 5V network, inductor constraints, and AP63205WU-7 identity; re-read 2026-09-01.

Coordinates are FOOTPRINT-LOCAL mm, rotation undone; +y is DOWN
(so this table reads like the top view of the part on the board).

| pad | local (x,y) | side | size | function (part.yaml) | NET on board |
|---|---|---|---|---|---|
| 1 | (-1.14,-0.95) | W | 1.32x0.6 | FB | 5V_BUCK |
| 2 | (-1.14,+0.00) | W | 1.32x0.6 | EN | 12V_BUCK_IN |
| 3 | (-1.14,+0.95) | W | 1.32x0.6 | VIN | 12V_BUCK_IN |
| 4 | (+1.14,+0.95) | E | 1.32x0.6 | GND | GND |
| 5 | (+1.14,+0.00) | E | 1.32x0.6 | SW | BUCK_SW |
| 6 | (+1.14,-0.95) | E | 1.32x0.6 | BST | BUCK_BST |
