review_stage: pre-route
review_kind: topology
revieweridentity: carrier_rj45_native_pod_topology_top_only1
context: FRESH
date: 2026-09-13
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
netlist_sha256: b82a49919941a654940e371ae6860e2429c349316f3aed8d8c503ee075656227
design_rules_sha256: 7f661d2ef79dd9004962238eac953f194ac18722cd344d1c91443cab29402ca9
schematic_pdf_sha256: 062878cc6755eb779e1ada9ea6cadf562433a2046754b569a887495c3de65ab8
exact_netlist_sha256: 390760e7fdf02afa918513c13114b528626f86b940140c113c20d0f2d6a1c422
circuit_json_sha256: 0823177ef256d91f7675eb40ac6a7aba5741e4b7b7b538db990f75de7062e720
kicad_schematic_sha256: cbe67395b0a62a9ff9e668c13ca7c00240b2454b2f7631ab40d3affb93f45a29
parts_sha256: 24c1d667aa95629d5dabb75f306a3b1f1e2b4293e40230d6c448d4e53da5a287

The exact frozen pod schematic is SOUND for the commissioned pre-route topology lens. There are no newly discovered electrical-topology defects. This verdict does not accept placement, copper, mechanical mating, fabrication, release, stock allocation, or ordering. FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains in force.

Independent measured coverage

- Independently verified all 293/293 envelope inputs at review entry and again at packaging. The packet contains 118 immediately accepted subject files: 106 are byte-identical, 12 differ, and none were removed. Thirty-seven current files have no counterpart in the supplied accepted subset; that means unpaired evidence, not 37 design additions. Root's separate full authored-input/checkpoint verification is outside this reviewer's 293-file measurement.
- Direct parsing of the current TSX independently reproduces all 40 component identities/values/MPNs, 103 physical pins, 99 connected endpoints and 20 connected nets in CircuitJSON and the delivered native netlist. The four remaining pins are intentional NCs: U2.3, U2.7, U3.1 and U3.2. Native exports represent these as four additional single-pin NC nets, giving 24 native nets and 103 nodes. A fresh KiCad CLI export from the frozen schematic matches the owning normalized netlist hash. No existing exporter implementation was reused for the direct TSX comparison.
- Current versus immediately accepted native census: 40 versus 40 components; zero added, zero removed and zero changed component value/footprint/non-sheet properties. All 103 node/pin-function/type assignments and all 24 native nets match. Native schematic differences disappear when generated UUIDs and UUID references are normalized. Of 1,188 CircuitJSON records, the only changed row classes are 15 supplier-footprint-warning records and one source-project metadata record; warning identity/order plus filesystem metadata explain the difference. Electrical and drawing records remain equal.
- The maintained electrical invariant checker independently ran against this exact netlist: 39/39 PASS. All seven subject hashes were recomputed using the frozen owning algorithm, including all 34 part.yaml dossiers and semantic design-rule projection, and match expected-subject.json.

Current pod population

The 40 schematic identities are 11 capacitors, 14 resistors, 3 ICs, 2 diodes, 1 fuse, J1, MK1 and 7 testpoint pads. Native schematic BOM membership is 33, with TP1–TP7 explicitly excluded. The current first-power card lists exactly those 33 identities, once each: 31 fitted SMD, the manually fitted J1 jack, and the off-board capsule represented by MK1 wire landings. Thus board-mounted fitted population is 32, machine SMD population is 31, and MK1 is a board-only two-wire landing rather than a board-mounted capsule. Four source-defined mounting holes add mechanical board footprints to the 40 electrical objects, giving the source's 44-footprint intent; this is not a fresh physical-board census. J1, MK1 and TP1–TP7 remain absent from the machine assembly BOM/CPL by explicit source dispositions. There are no electrical additions hidden by these exclusions.

Actual authored delta and disposition

All eight changed common authored files were read and classified, along with current ADR-0009. The adoption receipt's seven pod postimage hashes were independently matched to the frozen files. Its source acceptance is provenance only; the schematic received the independent current review above.

1. TPD2E2U06DRLR/part.yaml changes layout guidance, not pinmap, value, electrical limits or supplier identity. It increases connector-to-clamp center budgets from 4.0 mm to 8.6 mm AUDIO_P / 5.7 mm AUDIO_N and adds a top rear cell, direct channel paths and dedicated ground-via guidance. All electrical fields in all 34 old/current dossiers match.
2. floorplan.yaml keeps the 60 × 40 mm outline and every other anchor; U3 changes from bottom (49.07, 27.86, 0°) to top (48, 34.75, 180°). Assembly sides become top only in assembly.yaml, and J1's manual process follows top-side SMT. The changed contracts.md row makes side policy cover all fitted SMD, including manual/consigned parts, and forbids duplicate dispositions. It does not erase fitted population.
3. route.yaml changes J1.5/J1.4 clamp prefixes to F.Cu, changes U3.4's GND launch to a 0.50 mm-wide, 0.85 mm-long front trace and dedicated via, adds distinct U3.3/U3.5 post-clamp launches/vias, and adds the R13.2 front launch from (62.913,36) to (62.913,34.7) with explicit 0.60/0.30 mm via. All six changed/added stub banks were compared individually. The flow blocker narrative is provenance, not electrical connectivity. Unchanged banks and net assignments were retained.
4. critical_paths.yaml changes only the two connector-prefix layer/span/length rows: AUDIO_P F.Cu ≤9.0 mm with ≤8.6 mm center span; AUDIO_N F.Cu ≤7.5 mm with ≤5.7 mm center span. nets.yaml updates the same layer intent, retaining the 0.25 mm audio width floor. Test fixtures now reject B.Cu and over-budget paths for these values. No unrelated checker suite was rerun.
5. Current ADR-0009 explicitly describes those geometry budgets as engineering estimates, not TI ratings. Its supplemental R13.2→TP6.1 F.Cu ≤5 mm constraint is reproducibly tied to the unchanged critical-path entry and expressly does not claim completed copper. Proposal-labelled history is superseded for adoption only by the exact acceptance receipt. This schematic verdict does not grade the unfinished probe route, residual ground-island stitching, native spacing or service access.

Integrated electrical judgment

J1 is the nonmagnetic Würth 615008160221, with all ten electrical pins delivered and visible: 1/3/7 = 12V_POD; 2/6/8 = GND; 5 = AUDIO_P; 4 = AUDIO_N; 9/10 = POD_SHIELD. The shield net has exactly two nodes, both J1 shell tabs, and no connection to GND. The unchanged project footprint maps manufacturer S1/S2 to 9/10. The current source factory cord is Weidmüller 8909650150, straight-through T568B with audio on pair 4/5 and three paired power/return circuits. This is custom analog/power over factory Cat6A cord, NOT Ethernet or PoE; mating is power off. Jack 1.5 A/20 mΩ data are jack-only, not cord qualification. The 150 VAC row is not converted to DC: the existing 28.5 V project insulation ceiling remains explicitly an engineering inference, and 24.4 V × 1.10 = 26.84 V stays below it.

Input protection is correctly ordered 12V_POD→F1→12V_FUSED→D1 anode→D1 cathode/VIN_PROTECTED. D2 cathode and R14 join that protected node; their returns are GND. C1/C2 and U2 IN/EN see the protected node. D1 reverse leakage at the dossier's 50 µA hot limit across 4.7 kΩ +1% gives −0.23735 V, inside the retained −0.3 V U2 bound. R14 worst-resistance dissipation is 37.45 mW at 13.2 V and 127.95 mW at 24.4 V, below its 250 mW rating at the admitted temperature boundary. F1's 100 mA hold, 250 mA trip and 10 A prospective-fault limit are unchanged. The system source/fault waveform remains a first-article obligation.

The SMBJ15A 15 V standoff exceeds the 13.2 V normal ceiling; the retained 24.4 V component clamp is below U2's 35 V operating/36 V absolute input limits and C1/C2's 50 V rating. The admitted transient is at most 10 A / 244 W for the stated 10/1000 µs component envelope, with no lightning/system surge claim. Nominal connector-side capacitance is 10.1 µF, under the existing 47 µF ceiling. Input/first-power/current limits are unchanged: 10.5–13.2 V pod header, 100 mA spoke maximum, 20 mA expected pod load and 30 mA first-power current limit.

U2 pins 4/9 are grounded, 7 DNC and 3 NC stay open, 6 has its NR capacitor, and output/feedback use 324 kΩ / 100 kΩ with 10 nF feed-forward. Independently recomputed signed-feedback-current corners are 4.792587–5.229513 V, within the frozen 4.79–5.23 V envelope. The stated conservative C5 effective-capacitance floor is 3.825 µF versus the 2.2 µF requirement; exact bias/effective-capacitance verification remains OWED and is not measured here.

The microphone bias uses R3 3.9 kΩ/C7 100 µF, R4 2.2 kΩ, correct capsule landing polarity, C8 1 µF coupling and R5 100 kΩ to VREF. R6/R7 divide the quiet rail and U1A buffers it. U1B is an inverting 18k/22k stage; U1C restores polarity with equal 10 kΩ resistors. AUDIO_P and AUDIO_N each have 100 Ω, giving nominal differential gain 18/11 V/V and preserving the 1.2 Vrms output ceiling and 2.35–2.65 V common-mode envelope. Signal-bearing inverting inputs remain near VREF; U1D is a private unity follower on SPARE_BUF, never a parallel output. U3 DRL pins 3/5 clamp only the two audio nets, pin 4 returns to GND and pins 1/2 remain open. Its 5.5 V working limit and 12.4 V TLP clamp are not a system ESD guarantee. Pin authority and TI Figure 12 were freshly inspected as images; the figure gives no numeric trace-length budget.

Rendered integration and ERC limits

All 4/4 delivered PDF pages were freshly viewed as images, covering 7 + 11 + 10 + 12 = 40 components. Checked J1's ten labels, diode K/A polarity, isolated shield, LDO input/EN and NCs, half-rail/reference, capsule polarity, both audio legs and the spare follower. The current VIN_PROTECTED cross-sheet label is visible on page 2. Each page was also independently rendered at 2200 × 1486 pixels and compared with its immediately accepted counterpart. All differences are confined to the identified generated identity-header line; excluding y=120…145 leaves 3,212,000 identical RGB pixels/page, 12,848,000/12,848,000 total. Current headers show circuit hash prefix 0823177ef256d91f and correct page/component census. No prior reviewer reasoning was loaded or restamped; the full current visual inspection stands independently of equality evidence.

Retained ERC is 0 errors and 158 warnings: 64 embedded-library-configuration warnings and 94 off-grid endpoint warnings. All native symbols are embedded, and actual exported node parity was independently checked. These warnings are classified, not erased. Passive-typed generated IC pins limit what ERC alone can establish; explicit pin/rail/topology review supplies the electrical judgment. Zero errors is not an all-severity-clean claim.

Limitations and actions owed at their owning gates

The frozen connector source gate is PASS for J1 while FULL is authentically INCOMPLETE with nine physical obligations: installed cable routing, interface fit, mate/unmate/latch operation, reaction loads and three installed tolerance stacks. Source admission does not close them. Preserve the accepted prototype boundary; no extra physical measurement prerequisite is introduced by this schematic review. The coordinator's carrier scope remains separate, including its 23 physical obligations and J9 setback. LAYOUT001's commissioned closed 3/3 disposition is unchanged; this topology review does not renew layout.

Complete actual routing/return/ESD path and geometry reviews, sourcing allocation, physical connector/capsule/service qualification, and first-article rail/noise/gain/polarity/cable/EMC/thermal tests under their existing gates. Public catalog design admission and blank operator responses do not allocate stock or authorize an order. Historical Micro-Fit releases/drawings and unchanged narrative mentioning bottom-clamp assembly are historical context; current top-only assembly.yaml, exact accepted postimages and current schematic determine this review subject.

Evidence integrity

The archive contains independent methods, direct source/native maps, per-file deltas, input packet, primary-source/render images, bounded-runtime receipts and raw logs. An exploratory parser initially encountered a valueless exclude_from_bom property; the corrected parser retained that property and completed the census. A probe found PyMuPDF unavailable; Poppler and Pillow then produced the actual image measurements. Both nonpassing probes remain visible in raw logs and are not engineering passes. Every subprocess used the shared finite direct-argv runtime; writes were confined to allocated scratch/outputs. The archive is reopened member by member for name/type/size/hash checks; the supplied preflight runs after packaging.
