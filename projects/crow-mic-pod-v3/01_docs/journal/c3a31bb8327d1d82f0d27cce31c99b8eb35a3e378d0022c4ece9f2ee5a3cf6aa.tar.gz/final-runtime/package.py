from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,shutil,datetime
S=Path(__file__).parent;R=S.parents[3];O=S.parent/'outputs';env=json.loads((S.parent/'envelope.json').read_text());a=json.loads((S/'analysis.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
items=[]
for i in env['input_packet']:
 p=R/i['path'];b=p.read_bytes();assert len(b)==i['size'] and sha(b)==i['sha256'];items.append({'path':i['path'],'size':len(b),'sha256':sha(b),'status':'PASS'})
(S/'input-integrity.json').write_text(json.dumps({'count':len(items),'before':'293/293 independently verified in inspect.log','after':items},indent=2)+'\n')
(S/'input-envelope.json').write_text(json.dumps(env,indent=2)+'\n')
methods=S/'method-authority';methods.mkdir(exist_ok=True)
base=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901')
for rel in ['skills/pcb-design/scripts/pipeline_runtime.py','skills/pcb-design/scripts/pipeline_execution.py','skills/pcb-design/scripts/pipeline_artifacts.py','skills/kicad-pcb/scripts/electrical_invariants.py']:
 shutil.copyfile(base/rel,methods/Path(rel).name)
shutil.copyfile(R/'context/skills/kicad-pcb/scripts/pre_route_review_check.py',methods/'pre_route_review_check.py')
header={'review_stage':'pre-route','review_kind':'topology','revieweridentity':'carrier_rj45_native_pod_topology_top_only1','context':'FRESH','date':'2026-09-13','design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER',**a['hashes']}
(O/'report.md').write_text('\n'.join(f'{k}: {v}' for k,v in header.items())+'\n\n'+(S/'report-body.md').read_text())
e={'schema':1,'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','subject':env['subject'],'exact_hashes':a['hashes'],'review_stage':'pre-route','review_kind':'topology','revieweridentity':header['revieweridentity'],'context':'FRESH','methods':['Independent direct TSX literal/connection parse, CircuitJSON source-trace graph and native S-expression graph comparison','Fresh KiCad native re-export and frozen owning hash algorithms','All four delivered PDF pages visually inspected; full Poppler/Pillow per-pixel comparison excluding generated identity line','All eight changed common authored files, current ADR9, all 34 dossier electrical fields, current rating calculations and 39 maintained invariants','293 frozen input hashes verified before and after; all archive members independently reopened'],'counts':{'frozen_inputs_verified':293,'compared_prior_files':118,'unchanged_prior_files':106,'changed_prior_files':12,'changed_common_authored_files':8,'dossiers':34,'native_components':40,'native_pins':103,'connected_endpoints':99,'connected_nets':20,'nc_pins':4,'native_nets_including_nc':24,'schematic_bom':33,'first_power_installed':33,'board_fitted':32,'smt_fitted':31,'testpoint_exclusions':7,'source_board_mounting_holes':4,'pages_inspected':4,'components_inspected_per_page':[7,11,10,12],'equal_nonheader_pixels':12848000,'invariants_passed':39,'invariants_total':39,'erc_errors':0,'erc_warnings':158,'erc_warning_classes':{'lib_symbol_issues':64,'endpoint_off_grid':94}},'analysis':a,'findings':[],'limitations':['Pre-route schematic topology acceptance only; physical/routing/release/order gates remain separate','SOURCE PASS / FULL INCOMPLETE nine pod physical obligations retained','31 top SMD is source population intent, not an independently measured current physical-board census','R13 probe <=5mm and new clamp prefixes are estimated routing constraints, no realized-copper pass','No physical hardware, current provider allocation or system ESD qualification','Full authored checkpoint census is independently owned by coordinator, not claimed from this 293-file packet'],'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(O/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
files=[p for p in S.rglob('*') if p.is_file() and p.name not in ['package.log','package.runtime.json']]
files+= [O/'report.md',O/'evidence.json']
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in sorted(files):
  assert not p.is_symlink();name=('review/'+p.name) if p.parent==O else 'evidence/'+str(p.relative_to(S));tf.add(p,arcname=name,recursive=False)
members=[];seen=set()
with tarfile.open(archive,'r:gz') as tf:
 for m in tf.getmembers():
  q=PurePosixPath(m.name);assert m.isfile() and not m.issym() and not m.islnk() and not q.is_absolute() and '..' not in q.parts and m.name not in seen and not m.name.endswith('.tar.gz');seen.add(m.name)
  b=tf.extractfile(m).read();assert len(b)==m.size;members.append({'path':m.name,'size':len(b),'sha256':sha(b)})
manifest={'archive_sha256':sha(archive.read_bytes()),'archive_size':archive.stat().st_size,'member_count':len(members),'members':members}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(O/'result.json').write_text(json.dumps({'subject':env['subject'],'checks':{c:'PASS' for c in env['completion']['checks']},'unresolved':[]},indent=2)+'\n')
assert sorted(p.name for p in O.iterdir())==['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md','result.json']
print(json.dumps({'outputs':str(O),'input_count':len(items),'archive':{k:v for k,v in manifest.items() if k!='members'},'verdict':'SOUND'}))
