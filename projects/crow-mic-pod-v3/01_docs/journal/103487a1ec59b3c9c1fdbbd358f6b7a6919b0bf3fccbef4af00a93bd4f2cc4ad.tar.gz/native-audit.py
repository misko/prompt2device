import pcbnew, json, math, hashlib, xml.etree.ElementTree as ET
from pathlib import Path
P=Path("projects/crow-mic-pod-v3")
base=P/"04_kicad/crow_mic_pod_v3.kicad_pcb"
r0=P/"06_build/route/r0.kicad_pcb"
net=P/"06_build/netlists/crow_mic_pod_v3.net"
def mm(v): return pcbnew.ToMM(v)
def fp_data(board_path):
 b=pcbnew.LoadBoard(str(board_path))
 fps={fp.GetReference():fp for fp in b.GetFootprints()}
 out={"board":str(board_path),"footprints":len(fps),"tracks":len(list(b.GetTracks()))}
 out["refs"]={}
 for ref in ["R3","R12","J1","U1","U2","U3","D1","D2","F1"]:
  fp=fps[ref]
  out["refs"][ref]={
    "value":fp.GetValue(),"layer":pcbnew.LayerName(fp.GetLayer()),
    "pos":[mm(fp.GetPosition().x),mm(fp.GetPosition().y)],
    "pads":[{
      "num":p.GetNumber(),"net":p.GetNetname(),
      "pos":[mm(p.GetPosition().x),mm(p.GetPosition().y)],
      "size":[mm(p.GetSize().x),mm(p.GetSize().y)],
      "layers":[pcbnew.LayerName(x) for x in range(pcbnew.PCB_LAYER_ID_COUNT) if p.IsOnLayer(x)]
    } for p in fp.Pads()]
  }
 smd_bottom=[]; smd_top=[]; tht=[]
 for ref,fp in fps.items():
  pads=list(fp.Pads())
  has_smd=any(p.GetAttribute()==pcbnew.PAD_ATTRIB_SMD for p in pads)
  has_tht=any(p.GetAttribute() in (pcbnew.PAD_ATTRIB_PTH,pcbnew.PAD_ATTRIB_NPTH) for p in pads)
  if has_smd:
   (smd_top if fp.GetLayer()==pcbnew.F_Cu else smd_bottom).append(ref)
  if has_tht: tht.append(ref)
 out["smd_top"]=sorted(smd_top);out["smd_bottom"]=sorted(smd_bottom);out["tht"]=sorted(tht)
 if board_path==r0:
  for target in [("OUTP_DRV",(55.0,36.0)),("MIC_BIAS",(66.0,39.0))]:
   name,(x,y)=target
   related=[]
   for t in b.GetTracks():
    if t.GetNetname()!=name: continue
    kind="via" if isinstance(t,pcbnew.PCB_VIA) else "seg"
    d={"kind":kind,"net":name,"width":mm(t.GetWidth(t.GetLayer())) if isinstance(t,pcbnew.PCB_VIA) else mm(t.GetWidth())}
    if kind=="via":
     d.update(pos=[mm(t.GetPosition().x),mm(t.GetPosition().y)],drill=mm(t.GetDrillValue()))
    else:
     d.update(start=[mm(t.GetStart().x),mm(t.GetStart().y)],end=[mm(t.GetEnd().x),mm(t.GetEnd().y)],layer=pcbnew.LayerName(t.GetLayer()))
    related.append(d)
   out.setdefault("seed_copper",{})[name]=related
 return b,out
bb,bo=fp_data(base); rb,ro=fp_data(r0)
# netlist nodes
import re
txt=net.read_text()
def balanced_blocks(text, marker):
 out=[]; pos=0
 while True:
  i=text.find(marker,pos)
  if i<0: break
  depth=0; quoted=False; esc=False
  for j in range(i,len(text)):
   c=text[j]
   if quoted:
    if esc: esc=False
    elif c=="\\": esc=True
    elif c=='"': quoted=False
   else:
    if c=='"': quoted=True
    elif c=='(': depth+=1
    elif c==')':
     depth-=1
     if depth==0:
      out.append(text[i:j+1]);pos=j+1;break
  else: break
 return out
nodes={}
for blk in balanced_blocks(txt,"(net"):
 m=re.search(r'\(name "([^"]+)"\)',blk)
 if not m: continue
 nodes[m.group(1)]=sorted(re.findall(r'\(node\s+\(ref "([^"]+)"\)\s+\(pin "([^"]+)"\)',blk))
wanted={k:nodes.get(k) for k in ["OUTP_DRV","MIC_BIAS","AUDIO_P","AUDIO_N","12V_POD","POD_SHIELD"]}
# exact pad clearance approximations using axis-aligned pad bbox against via copper circle and foreign pad bboxes
def seed_gap(board,ref,padnum,vx,vy,vdiam):
 fp=next(f for f in board.GetFootprints() if f.GetReference()==ref)
 pad=next(p for p in fp.Pads() if p.GetNumber()==padnum)
 ppos=(mm(pad.GetPosition().x),mm(pad.GetPosition().y)); psz=(mm(pad.GetSize().x),mm(pad.GetSize().y))
 pxedge=max(abs(vx-ppos[0])-psz[0]/2,abs(vy-ppos[1])-psz[1]/2)
 # intended collinear axis gap exact from bbox to via circumference
 bboxdist=math.hypot(max(abs(vx-ppos[0])-psz[0]/2,0),max(abs(vy-ppos[1])-psz[1]/2,0))-vdiam/2
 nearest=[]
 for f in board.GetFootprints():
  for p in f.Pads():
   if p==pad: continue
   q=(mm(p.GetPosition().x),mm(p.GetPosition().y)); s=(mm(p.GetSize().x),mm(p.GetSize().y))
   gap=math.hypot(max(abs(vx-q[0])-s[0]/2,0),max(abs(vy-q[1])-s[1]/2,0))-vdiam/2
   nearest.append((gap,f.GetReference(),p.GetNumber(),p.GetNetname(),q,s))
 return {"pad_pos":ppos,"pad_size":psz,"via_pos":[vx,vy],"copper_edge_gap":bboxdist,"nearest_foreign_pads":sorted(nearest)[:8]}
geo={"R12.1":seed_gap(rb,"R12","1",55,36,.6),"R3.2":seed_gap(rb,"R3","2",66,39,.6)}
print(json.dumps({"base":bo,"r0":ro,"netlist":wanted,"geometry":geo},indent=2,sort_keys=True))
