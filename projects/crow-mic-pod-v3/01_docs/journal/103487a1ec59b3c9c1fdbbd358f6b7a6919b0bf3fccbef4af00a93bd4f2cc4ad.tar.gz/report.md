review_stage: pre-route
review_kind: pin
reviewer: /root/pod_r3_pin_review fresh independent read-only reviewer
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: af9bb3c0dcf5e9be20239d725d10dd4d4c1bf95cc0b7518badc3e27bd6523938
netlist_sha256: b4edc879929e85fb35953e06f24ca6f8ade42b14d777b7751cbda47bc84aadff
parts_sha256: d0d0026dd67cbfaa98176799ea34ea3bfde384675d74d58d8cf8f0c88e41fd89
design_rules_sha256: d5b3fb88a0300059a60a2e2874514f34957702cf2bb334acd78c221a1611c5b3
route_yaml_sha256: bec9d821cccb3c7e431010700b1185d807eb7a5bbb99ac9179f072cad43f20a3
r0_sha256: 2c7bd6ac83c538be78e3f1413e60c7eba4be33a9369ff7a525ec280218a374e7
completed_at: 2026-09-14T04:12:00Z

# Pod combined source-escape pin review

## Verdict

SOUND for the exact pre-route pin/source and population scope. The two deterministic source escapes preserve the intended pin and net identities, meet the authored width floors, and place their vias off the source pads with clear neighboring copper. The exact prepared board preserves all 44 base-board footprints, values, library identities, pad numbers/nets, positions, orientations, and mounted sides. This verdict accepts the combined R12.1 and R3.2 source geometry for continued routing. It does not accept a completed route, fabrication package, release, physical qualification, or order.

## Exact source escapes

| Source | Native identity | Authored / prepared geometry | Governing class | Result |
|---|---|---|---|---|
| R12.1 | OUTP_DRV; R12=100 ohm; pad center (56.0875,36.0) mm, size 1.025 x 1.4 mm | F.Cu segment to (55.0,36.0), 0.26 mm wide; 0.60/0.30 mm via | BALANCED_AUDIO, minimum 0.25 mm | PASS |
| R3.2 | MIC_BIAS; R3=3.9 kohm; pad center (64.9125,39.0) mm, size 1.025 x 1.4 mm | F.Cu segment to (66.0,39.0), 0.50 mm wide; 0.60/0.30 mm via | QUIET_POWER, minimum 0.40 mm | PASS |

The netlist independently places OUTP_DRV on R12.1, R11.1, and U1.8, and MIC_BIAS on R3.2, R4.1, and C7.1. The native prepared board gives the same nets to the two source pads and to their segment/via pairs. KiCad serializes the segment starts to 0.001 mm, giving x=56.087 and x=64.912 in r0; each 0.26/0.50 mm segment still begins within its source land and overlaps it continuously.

Each via annulus is 0.275 mm beyond the source pad copper edge and is bridged by the declared segment. The nearest foreign copper to the R12 via is R12.2 (AUDIO_P) at a conservative 2.10 mm annulus-to-pad-box gap. The nearest foreign copper to the R3 via is R3.1 (5V_QUIET) at 2.10 mm; R4.2 is next at 2.43 mm. Native DRC on exact r0 reports no clearance, track-width, via-in-pad, courtyard, or solder-mask physical violation. Its non-release findings are 44 local footprint-library warnings, five dangling vias, four dangling tracks, and 33 unconnected items expected on this prepared, incompletely routed artifact.

## Pin and connector invariants

The generated netlist passes 39/39 authored electrical invariants. Its three protection/topology ADRs have 3/3 invariant coverage. The net-reference audit resolves 81/82 rule references with zero ghost names; the sole unreached item is the explicitly advisory power-tree label QUIET_5V.

The exact board retains the critical six-reference pin census:

- D1 is S1M-E3/61T: pin 1 VIN_PROTECTED, pin 2 12V_FUSED.
- D2 is SMBJ15A: pin 1 VIN_PROTECTED, pin 2 GND.
- J1 is Würth 615008160221: contacts 1..8 are 12V_POD,GND,12V_POD,AUDIO_N,AUDIO_P,GND,12V_POD,GND; tabs 9/10 are isolated POD_SHIELD.
- U1 retains the 14-pin OPA1679 map, including U1.8=OUTP_DRV.
- U2 retains eight leads plus distinct grounded PowerPAD 9; pins 3 and 7 retain their separate NC/DNC nets.
- U3 retains pins 3=AUDIO_P, 4=GND, 5=AUDIO_N, with pins 1/2 isolated NC.

The independent spoke checker realizes exactly 1/1 required pod connector with the exact MPN, footprint, and ten-net assignment above.

## Population and process invariants

The base board and r0 each contain 44 footprints. All 38 footprints containing SMD pads are on F.Cu; none is on B.Cu. Seven of those are bare TP1–TP7 probe lands, leaving 31 populated top-side SMT references. J1 and MK1 remain manual through-hole work, and H1–H4 remain mechanical holes. This matches assembly.yaml (sides: [top]) and preserves the one-sided SMT process.

The current generated fab BOM/CPL is stale: it still calls D1 the superseded JKSEMI 1N4007(M7)SMA, while the exact board and source authority use Vishay S1M-E3/61T. J1 is intentionally absent from machine assembly because it is manual THT. The fab package must be regenerated and rechecked before fabrication/release acceptance; this does not invalidate the exact pin/source geometry reviewed here.

FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains in force.
