import json,hashlib,tarfile,io,os
from pathlib import Path
from datetime import datetime,timezone
S=Path(__file__).parent;T=S.parent;R=S.parents[3];O=T/'outputs';E=json.loads((T/'envelope.json').read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
verified=[]
for x in E['input_packet']:
 p=R/x['path'];assert p.is_file() and not p.is_symlink();b=p.read_bytes();assert len(b)==x['size'] and sha(b)==x['sha256'];verified.append({'path':x['path'],'size':len(b),'sha256':sha(b)})
canonical=sha(json.dumps(E,sort_keys=True,separators=(',',':')).encode());assert canonical=='1d4461d204ea02917f00511aad33c0f5094e02882e0902890a1a7141661c3cae'
(S/'inputs-after.json').write_text(json.dumps({'count':len(verified),'mismatches':[],'canonical_envelope_sha256':canonical,'files':verified},indent=2))
analysis=json.loads((S/'analysis.json').read_text());fidelity=json.loads((S/'fidelity.json').read_text());equivalence=json.loads((S/'equivalence.json').read_text());ratings=json.loads((S/'rating-math.json').read_text());hashes=analysis['hashes']
fields={'review_stage':'pre-route','review_kind':'topology','reviewer':'/root/carrier_rj45_native_pod_topology_orientation1','reviewer_identity':'/root/carrier_rj45_native_pod_topology_orientation1','context':'FRESH','date':'2026-09-13','design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER',**hashes}
report='\n'.join(k+': '+v for k,v in fields.items())+'\n\n'+(S/'review-notes.md').read_text()+'\nBounded runtime: engineering/export/raster/analysis stages used shared pipeline_runtime.run_stage with explicit argv,cwd,environment and120-second limits. This is bounded process and post-hoc writer observation, not a hermetic sandbox. No child agents or live edits.293/293 frozen inputs verified before and after.\n'
(O/'report.md').write_text(report)
evidence={'schema':1,'verdict':'SOUND','design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','subject':E['subject'],'envelope_sha256':canonical,'reviewer':fields['reviewer'],'context':'FRESH','date':datetime.now(timezone.utc).isoformat(),'seven_subject_hashes':hashes,'methods':['Independent complete S-expression netlist graph extraction and accepted/current comparison','Union-find source_trace graph compared at each103 source ports to native pins','Fresh kicad-cli netlist reexport from current native schematic','Maintained39 invariants and3 cited electrical ADRs','All114 hand-source/part file bytes compared','All four PDF pages rendered and inspected; complete pixel equality measured outside identified identity headers','Primary manufacturer active-package figures and RJ45 drawing visually reopened','Rating margins recalculated and33-reference first-power set independently reconciled','293 frozen files verified before/after; each regular archive member reopened'], 'counts':analysis['counts'],'source_census':{'files':114,'unchanged':112,'changed':2,'added':0,'removed':0},'graph_delta':analysis['graph_delta'],'fidelity':fidelity,'equivalence':equivalence,'rating_math':ratings,'invariants':{'passed':39,'total':39,'adr_cited':3,'adr_required':3},'findings':[],'preserved_limits':['FIRST-ARTICLE-ONLY / DO-NOT-ORDER','Connector SOURCE PASS / FULL INCOMPLETE with9 physical unknowns','No physical, layout, route, release, manufacturer allocation or user orientation acceptance','No new pre-fabrication physical measurement prerequisite','158 ERC warnings retained:64 synthesized-library and94 off-grid;0 errors separately'],'inputs_verified':len(verified),'review_complete':True,'diagnostic_corrections':['Initial native-reference regex counted embedded-library default prefixes; corrected physical-ref filter and independently confirmed native component graph/manifest/render counts. Failed diagnostic retained.']}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2))
# Snapshot complete finished raw/method evidence. Exclude only the currently growing packaging runtime.
excluded={'package.log','package-runtime.json','preflight.log','preflight-runtime.json'}
files=[p for p in sorted(S.rglob('*')) if p.is_file() and p.name not in excluded]
assert all(not p.is_symlink() for p in files)
archive=O/'evidence.tar.gz';members=[]
with tarfile.open(archive,'w:gz') as tf:
 for p in files:
  data=p.read_bytes();name='evidence/'+p.relative_to(S).as_posix();ti=tarfile.TarInfo(name);ti.size=len(data);ti.mode=0o644;ti.mtime=0;tf.addfile(ti,io.BytesIO(data));members.append({'path':name,'size':len(data),'sha256':sha(data)})
# Independently reopen every regular member and match the entire census, no extraction needed.
with tarfile.open(archive,'r:gz') as tf:
 seen=set();raw=tf.getmembers();assert len(raw)==len(members)
 bypath={x['path']:x for x in members};assert len(bypath)==len(members)
 for m in raw:
  assert m.isfile() and not m.issym() and not m.islnk();assert not m.name.startswith('/') and '..' not in Path(m.name).parts and m.name not in seen;seen.add(m.name)
  assert not m.name.endswith(('.tar','.tar.gz','.tgz'));b=tf.extractfile(m).read();x=bypath[m.name];assert len(b)==m.size==x['size'] and sha(b)==x['sha256']
manifest={'archive_sha256':sha(archive.read_bytes()),'archive_size':archive.stat().st_size,'member_count':len(members),'members':members,'regular_members_reopened':len(members)}
(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2))
(O/'result.json').write_text(json.dumps({'subject':E['subject'],'checks':{x:'PASS' for x in E['completion']['checks']},'unresolved':[]},indent=2))
assert sorted(p.name for p in O.iterdir())==['evidence-manifest.json','evidence.json','evidence.tar.gz','report.md','result.json']
print(json.dumps({'outputs':str(O),'design_verdict':'SOUND','order_verdict':'DO-NOT-ORDER','archive_sha256':manifest['archive_sha256'],'archive_size':manifest['archive_size'],'regular_members_reopened':len(members),'inputs_verified':len(verified),'canonical_envelope_sha256':canonical},indent=2))
