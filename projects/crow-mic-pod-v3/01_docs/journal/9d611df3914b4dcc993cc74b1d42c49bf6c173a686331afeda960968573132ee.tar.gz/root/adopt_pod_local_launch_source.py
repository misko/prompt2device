from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,tarfile
N=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');sha=lambda b:hashlib.sha256(b).hexdigest()
metas={}
for name in ['rj45-pod-local-launch-source','rj45-pod-local-launch-review']:
 m=json.loads((N/(name+'-opened.json')).read_text());E=Path(m['envelope']);D=Path(m['project']);env=json.loads(E.read_text());assert json.loads((E.parent/'attempt.json').read_text())['status']=='PASS'
 for row in env['input_packet']:
  p=D/row['path'];b=p.read_bytes();assert p.is_file() and not p.is_symlink() and len(b)==row['size'] and sha(b)==row['sha256']
 c=json.loads((N/(name+'-closeout-summary.json')).read_text());assert c['delivery_status']=='PASS';assert sha(Path(c['archive']).read_bytes())==c['sha256'];metas[name]=(m,c,env)
am,ac,ae=metas['rj45-pod-local-launch-source'];rm,rc,re=metas['rj45-pod-local-launch-review'];O=Path(rm['output_dir']);review=json.loads((O/'evidence.json').read_text());assert review['subject']==re['subject'] and review['domain_result'].startswith('SOUND:');report=(O/'report.md').read_text();assert report.startswith('SOUND for the exact candidate4 combined source.')
expected={'floorplan.yaml':'64266744063dfb4c8725865e46443229e777eb25e8e41ec808a8292e6affa8bb','route.yaml':'e1a8c697603eb6bf3f110a956838e8e1489ded893e3492c6c0ed6a07fdb2c89d'};plans=[]
with tarfile.open(Path(am['output_dir'])/'evidence.tar.gz') as t:
 for filename,h in expected.items():
  rel='projects/crow-mic-pod-v3/03_src/'+filename;before=t.extractfile('beforeimages/'+rel).read();after=t.extractfile('source_candidate/'+rel).read();assert (R/rel).read_bytes()==before;assert sha(after)==h and h in report and sha(before) in report;plans.append((rel,before,after))
record={'created_at':datetime.now(timezone.utc).isoformat(),'review_archive':rc['sha256'],'author_archive':ac['sha256'],'claim':'Adopt exactly two independently SOUND combined source files. Four cumulative candidates remain spent; candidate3 remains rejected. Normal full authority renewal is owed; no native/routing/release acceptance.','files':[{'path':r,'before_sha256':sha(b),'after_sha256':sha(a)} for r,b,a in plans]}
for rel,before,after in plans:assert (R/rel).read_bytes()==before
for rel,before,after in plans:(R/rel).write_bytes(after)
for rel,before,after in plans:assert (R/rel).read_bytes()==after
(N/'pod-local-launch-source-adoption.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
