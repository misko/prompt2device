from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io,sys
from datetime import datetime,timezone
N=Path(__file__).parent;R=Path('/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901');spec=json.loads(Path(sys.argv[1]).read_text());payload={}
for key,path in spec['files'].items():
 p=Path(path);assert p.is_file() and not p.is_symlink();assert key not in payload and not PurePosixPath(key).is_absolute() and '..' not in PurePosixPath(key).parts;payload[key]=p.read_bytes()
record={'created_at':datetime.now(timezone.utc).isoformat(),'scope':spec['scope']};payload['CHECKPOINT.json']=(json.dumps(record,indent=2)+'\n').encode();payload['MANIFEST.json']=(json.dumps({'files':[{'path':k,'size':len(v),'sha256':hashlib.sha256(v).hexdigest()} for k,v in sorted(payload.items())]},indent=2)+'\n').encode();tmp=N/(spec['name']+'.tmp')
with tmp.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for k,b in sorted(payload.items()):x=tarfile.TarInfo(k);x.size=len(b);x.mode=0o644;t.addfile(x,io.BytesIO(b))
with tarfile.open(tmp) as t:
 assert len(t.getmembers())==len(payload)==len({x.name for x in t.getmembers()})
 for x in t.getmembers():assert x.isfile() and t.extractfile(x).read()==payload[x.name]
b=tmp.read_bytes();h=hashlib.sha256(b).hexdigest();J=R/'projects'/spec['project']/'01_docs/journal';assert J.resolve().is_relative_to(R/'projects');dest=J/(h+'.tar.gz');assert not dest.exists();dest.write_bytes(b)
with (J/'contracts.md').open('a') as f:f.write(f'\n## Allowed {spec["name"]} checkpoint\n\n| Pattern | What |\n|---|---|\n| `{h}.tar.gz` | {spec["scope"]} |\n\nAudit: SHA-256 equals filename; {len(b)} bytes / {len(payload)} regular members, all reopened against MANIFEST.json.\n')
s={'archive':str(dest),'sha256':h,'size':len(b),'members':len(payload),**record};(N/(spec['name']+'-summary.json')).write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s,indent=2))
