from pathlib import Path
import pcbnew,json,hashlib
N=Path(__file__).parent;p=Path('/tmp/rj45-pod-clamp-seed-source-d8xdompb/06_build/task_runs/rj45-pod-clamp-seed-source/scratch/variants/candidate1/r0.kicad_pcb');b=pcbnew.LoadBoard(str(p));c1=next(q for q in b.FindFootprintByReference('C1').Pads() if q.GetNumber()=='1');rows=[]
for t in b.GetTracks():
 if t.GetClass()!='PCB_TRACK' or t.GetNetname()!='VIN_PROTECTED' or not c1.IsOnLayer(t.GetLayer()):continue
 contact=t.GetEffectiveShape().Collide(c1.GetEffectiveShape(t.GetLayer()),0)
 if contact:rows.append({'uuid':t.m_Uuid.AsString(),'start_mm':[t.GetStart().x/1e6,t.GetStart().y/1e6],'end_mm':[t.GetEnd().x/1e6,t.GetEnd().y/1e6],'start_in_pad':c1.HitTest(t.GetStart()),'end_in_pad':c1.HitTest(t.GetEnd()),'native_shape_contact':contact,'width_mm':t.GetWidth()/1e6})
out={'board_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'C1_1':{'net':c1.GetNetname(),'size_mm':[c1.GetSize().x/1e6,c1.GetSize().y/1e6],'position_mm':[c1.GetPosition().x/1e6,c1.GetPosition().y/1e6]},'actual_contacts':rows,'thermal_source':{ref:[{'pin':q.GetNumber(),'net':q.GetNetname(),'zone_connection':q.GetLocalZoneConnection()} for q in b.FindFootprintByReference(ref).Pads()] for ref in ['C2','C9']},'scope':'Read-only causal diagnosis of existing seed candidate; no source/copper change or route acceptance. Initial introspection used unavailable GetZoneConnection then corrected to actual GetLocalZoneConnection; no design variant.'};(N/'pod-seed-residual-diagnosis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
