# Exact RJ45 Fab feature source owner

Mandatory fresh D-BACK implementation after closed independent diagnosis.
Root is sole live writer of both boards. Only write isolated scratch/candidate
and allocated outputs. Do not edit input/, diagnosis/, live repo, releases or
Git. No children, replacements or automatic deadline changes. Work cutoff 2026-09-13T04:32:52.020992+00:00;
hard 2026-09-13T04:42:52.020992+00:00. At most TWO coherent source candidates under this distinct exact-part
feature scope; all prior fuse2methods, camera2variants and pod4source candidates
remain spent. No source/config/camera search beyond this admitted hypothesis.

Read CLAUDE and supplied skill/runtime/canon before any gate documentation
change, tests/README before tests. Reopen complete diagnosis/report.md, exact
archive manifest and measurements. Diagnosis establishes the SAME physical
jack on both boards: nominal 15mm shell Fab omits four lateral spring fingers;
native full local extent X[-5.058081,12.218081], Y[-6.360054,7.09]. Existing
carrier two-pixel erosion loses all7934 lateral feature pixels; pod retains
them and fails1.059223mm. The frozen diagnosis includes independent native
assemblies, source BRep sections and original-pixel replay; rederive rather
than inherit relevant coordinates. Official STEP supplies nominal CAD, not
manufacturing tolerances; drawingp1 depicts but does not dimension free span.

Admitted hypothesis: add faithful primary-supported spring-finger plan detail
to BOTH identical source F.Fab footprints, retaining the original nominal-shell
rectangle and existing courtyard, and provide independent exact-product shell,
drill and occupied-extent evidence. Correct only proven expectation ownership.
Do not enlarge a generic rectangle to fit a result, change footprint/model
position/rotation/scale, remove physical model features, relax tolerances,
change courtyard, pads/drills/copper/silk, source parts/pins/nets, routing,
assembly, source models or camera recipes. Every detail must trace to actual
manufacturer geometry and have its nominal/free-state grade explicit. A native
Fab union measures outer features after this change; do not claim it separately
recognizes nominal shell. Independently retain nominal-shell/drill datum
checks against primary drawing and native shape sections.

Production source scope:
- both03_src/lib/<projectlib>.pretty/Wurth_615008160221_RJ45.kicad_mod;
- both02_parts/615008160221/{part.yaml,primary-source-record.md} and
  both03_src/lib/3dmodels/wurth/provenance.md only relevant provenance/hash
  updates. Preserve historical derivations and clearly append the new change.
- native_model_registration.py MODULE DOCSTRING only, tests/t1_model_registration.py
  one maintained G-VACUOUS fixture plus necessary helper, tests/README.md and
  digital-twin.md for the newly measured thin-feature sampling limitation.
  NO extraction algorithm, thresholds, source group settings, wrapper,
  approval schema or unrelated gate behavior changes. Use existing contract
  names; change governing contracts only if required for changed semantics.
  Skill text must contain no project paths. Before a requested out-of-scope
  change, report the exact reason; do not silently implement it.

G-VACUOUS requires an executable declaration, not prose alone: retain all
14 existing model tests and the previous buried-model blind spot unchanged.
New fixture must construct an actual thin native exterior feature that the
original extraction drops and assert its false PASS first, followed by a
must_fail contrast (e.g. a physically thicker exterior feature at the same
extent). Reopen what the native consumer actually constructed before claiming
the fixture geometry; avoid nested-transform assumptions from the prior
incident. At most one thin fixture and one decisive thick contrast, no
parameter sweep. It documents an existing limitation; do not reclassify any
required-fail existing control. No general CAD parser/classifier.

Exact-product supplemental acceptance is essential: independently inspect
all9 jack instances in normally generated source-candidate boards, the nominal
shell and physical drill/slot correspondences, full original STEP and native
export extents vs unchanged courtyard, and original raw image features at both
existing coupon scales. Explicitly fail/incomplete a thin feature actually
outside courtyard even if eroded pixels pass. Demonstrate that exact-product
supplemental method with a controlled translated/extended model counterexample;
preserve genuine native outputs and uncertainty. It must not infer measured
extent from expected Fab or mask pixels to expected regions. Nominal courtyard
tip margin is as small as0.001919mm, so never call nominal containment a
manufacturing tolerance guarantee; existing physical first-article obligations
remain. This proof supplements, never skips, ordinary P-MODEL-REG.

Construct scratch boards from frozen current source/netlist using unchanged
stock generate_board_generic.py (no live TSX/conductor or hand-patched PCB).
Show original pod failure under unchanged gate, candidate normal native
registration for both current groups/full projects where practical, all9refs
covered, and unchanged copper/pads/positions/net associations. Run appropriate
native DRCall-severity/refill/parity; classify every violation/unconnected/parity
row and compare prior retained rows, not only totals. Root owns later full
regeneration/schematic reviews/placement/orientation; your scratch approval
cannot advance them. Do not render new orientation views here or mint signatures.

All native/tests through shared pipeline_runtime.run_stage, explicit cwd/env,
/usr/bin/python3 -B and <=300s per run. Exact dependencies may be copied
read-only from /home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901 when missing, with hashes recorded. Preserve setup
failures and both candidates if used. Deliver by cutoff then package promptly.
Five outputs EXACTLY report.md,evidence.json,evidence-manifest.json,
evidence.tar.gz,result.json. Archive source_candidate/<repo-relative changed
files>, beforeimages, methods, direct measurements, full native/raw/runtime
results and controls; no nested diagnosis/dependency archives. Manifest has
archive_sha256/archive_size/member_count/members(path,size,sha256); reopen
every regular member and reject symlinks/traversal/duplicates. evidence
domain_result string independent of delivery. result exact envelope subject
and checks evidence-complete,inputs-verified,review-complete for honest handback.
Run supplied preflight; actual FINAL immediately when complete. Root closes,
preserves and commissions fresh independent source selection before adoption.
No waiver, routing/layout/release/order or physical acceptance.
