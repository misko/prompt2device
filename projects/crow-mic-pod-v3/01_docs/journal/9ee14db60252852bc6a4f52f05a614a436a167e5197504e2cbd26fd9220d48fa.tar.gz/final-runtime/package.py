import json,pathlib,hashlib,shutil,tarfile,datetime,math
S=pathlib.Path(__file__).parent;ROOT=S.parents[3];P=ROOT/'project';T=S.parent;O=T/'outputs';O.mkdir(exist_ok=True);E=json.loads((T/'envelope.json').read_text());M=json.loads((S/'measurements.json').read_text());D=json.loads((S/'detail.json').read_text());F=json.loads((S/'floors.json').read_text());C=json.loads((S/'drc-classification.json').read_text());PC=json.loads((S/'prep-comparison.json').read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
verified=[]
for x in E['input_packet']:
 p=ROOT/x['path'];verified.append({'path':x['path'],'sha256':digest(p),'size':p.stat().st_size,'ok':digest(p)==x['sha256'] and p.stat().st_size==x['size']})
assert all(x['ok'] for x in verified);(S/'inputs-after.json').write_text(json.dumps(verified,indent=2));assert C['design_rules_sha256']=='02c4ed58432368b92e3019a06bf20c137dbf90765af16c96c458790e88d54a9f'
# All these exact pixel files were independently opened with view_image in this review.
images=['approved_native_top.png','approved_native_bottom.png']+['orientation/renders/populated_'+n+'.png' for n in ['front','back','left','right','top']]+['orientation/views/J1_'+n+'.png' for n in ['inside','outside','profile_a','profile_b','top']]
for g,ref,side in [('j1_wurth_615008160221_official_step','J1',True),('u2_ti_dgn0008g_official_step','U2',False)]:
 images += ['native_registration/'+g+'/'+n+'.png' for n in ['native_overlay_'+ref,'native_top','native_bare_top','native_top_registration_overlay']+(['native_side_front','native_side_right'] if side else [])]
image_rows=[{'path':'project/06_build/pre_route/'+n,'sha256':digest(P/'06_build/pre_route'/n),'size':(P/'06_build/pre_route'/n).stat().st_size,'inspected':True} for n in images];assert len(image_rows)==22
(S/'inspected-images.json').write_text(json.dumps(image_rows,indent=2))
findings=[
{'id':'L1','severity':'P2 routing completion obligation; nonblocking for pre-route placement','ref_pad':'C10.2','coordinates_mm':[52.12,49.0],'finding':'Prepared r0 refill leaves the bypass GND land disconnected from F.Cu GND; the positive bypass path alone is not a completed decoupling loop.','evidence':'drc-r0-resolved.json unconnected_items[0]; exact-detail-final log/detail.json','next_owner':'routing/stitch','required_action':'Restore and natively verify a short return before routed acceptance. The hypothetical off-pad location (51.2,49.0), diameter0.6/drill0.3, is 0.92mm away with >=0.908847mm foreign-copper clearance; this is a feasibility screen, not added or accepted routing.'},
{'id':'L2','severity':'P3 layout guidance advisory; nonblocking for pre-route placement','ref_pad':'J1.5/U3.3 and J1.4/U3.5','coordinates_mm':[[50.45,28.36],[47.65,27.36]],'finding':'Both connector-to-clamp prefixes use a square final elbow. TI SLLSEG9C section10.1 recommends rounded corners on exposed ESD traces. Source path length, layer, clearance and connector-first constraints all pass.','evidence':'primary-tpd.txt section10.1; native.json r0 AUDIO_P/AUDIO_N tracks','next_owner':'route source owner','required_action':'Consider radiusing these elbows while retaining exact clamp-first order and rerunning the existing bounds before final copper acceptance. No placement relocation or limit relaxation is requested.'},
{'id':'L3','severity':'physical first-article hold; not a nominal placement defect','ref_pad':'J1.9/10, J1 guides and U3','coordinates_mm':[[56.47,23.51],[41.67,23.51],[49.07,27.86]],'finding':'Shell-land/guide nominal clearance is 0.268639mm, only0.018639mm over the0.25mm floor; native free spring fingers nearly reach the courtyard centerline. Solder fillets, lead seating, bottom assembly, molded variation, enclosure latch access and cord bend/strain relief are not measured manufacturing fit.','evidence':'floors.json; primary Wurth drawing and source record; approved top/bottom plus current orientation views','next_owner':'mechanical/assembly/first-article owner','required_action':'Retain existing exact-part fit, hand-solder and populated latch/mating qualification; do not convert nominal registration into order readiness.'}]
methods=[{'id':'M1','method':'499 input SHA-256/size checks before and after; semantic design rules digest computed with frozen pre_route_review_check.design_rules_digest','artifacts':['inputs-before.json','inputs-after.json','drc-classification.json']},{'id':'M2','method':'KiCad10.0.4 pcbnew independently loads native and r0; extracts all footprints/pads/nets/side/orientation/models and tracks. Geometry compared after sorting duplicate Fab graphics; no board modifications.','artifacts':['native.py','native.json','detail.json','floors.json']},{'id':'M3','method':'Native kicad-cli full-severity refill DRC on isolated copies; schematic parity requested on native. Resolve only r0 library lookup in scratch and rerun unchanged board/pro/dru. Every raw violation/open item retained with exact node pair and classification.','artifacts':['drc-native.json','drc-r0.json','drc-r0-resolved.json','drc-classification.json','drc-classification.md']},{'id':'M4','method':'Independent Euclidean pad-center and saved-track centerline graph measurement; <=1um endpoint attachment accommodates emitted source rounding. Source seed multiset comparison is separate. No routing or route-candidate execution.','artifacts':['measure.py','measurements.json','prep_compare.py','prep-comparison.json']},{'id':'M5','method':'Exact pcbnew SHAPE.GetClearance for U3/J1, package pad gaps and shell/NPTH; conservative native Fab/courtyard bounding-box screens for component and screw access. Hypothetical C10 return via is a read-only geometry probe, not a copper addition.','artifacts':['detail.py','detail.json','floors.py','floors.json']},{'id':'M6','method':'Reopened two current aggregate model-registration groups, receipts/bundles, source bound input/output hashes and 22 supplied pixel files. Native model declarations resolved using supported kicad_env/resolve_model then reopened and hashed. No new camera recipes.','artifacts':['inspected-images.json','detail.json']},{'id':'M7','method':'Primary local Wurth/TI PDFs converted with finite direct-argv pdftotext through shared pipeline_runtime.run_stage; inspected exact layout sections and Wurth drawing dimensions.','artifacts':['primary-wurth.txt','primary-tpd.txt','primary-tps.txt','primary-opa.txt']}]
counts={'inputs_verified_before':499,'inputs_verified_after':499,'native_footprints':44,'native_pad_objects':113,'electrical_numbered_pad_objects':103,'native_tracks':0,'native_vias':0,'native_zones':2,'fitted_bodies':32,'top_smt':30,'bottom_smt':1,'manual_connector':1,'bare_mic_landing':1,'bare_testpoints':7,'mounting_holes':4,'resolved_native_models':32,'anchors_checked':40,'pad_net_assertions_checked':27,'part_dossier_proximity_rules_checked':6,'prepared_segments':78,'prepared_vias':8,'prepared_seed_segment_matches':78,'prepared_route_budget_paths_checked':11,'future_probe_paths':2,'user2_keepout_rectangles':15,'inspected_images':22,'native_drc_violations':0,'native_drc_opens':58,'native_schematic_parity':0,'r0_initial_warnings':48,'r0_initial_library_warnings':44,'r0_final_dangling_warnings':4,'r0_final_opens':33,'raw_drc_records_classified_including_initial_environment_run':176}
# Numbered count is derived, not guessed.
N=json.loads((S/'native.json').read_text());counts['electrical_numbered_pad_objects']=sum(bool(p['number']) for f in N['native']['footprints'] for p in f['pads'])
EV={'verdict':'SOUND','review_stage':'pre-route','review_kind':'layout','reviewer':'/root/rj45_pod_layout_approved','context':'FRESH','order_verdict':'DO-NOT-ORDER','subject':E['subject'],'board_sha256':digest(P/'04_kicad/crow_mic_pod_v3.kicad_pcb'),'prepared_board_sha256':digest(P/'06_build/route/r0.kicad_pcb'),'design_rules_sha256':C['design_rules_sha256'],'methods':methods,'findings':findings,'measured_counts':counts,'critical_path_measurements':M['critical_paths'],'current_model_groups':['j1_wurth_615008160221_official_step','u2_ti_dgn0008g_official_step'],'inspected_images':image_rows,'limitations':['Pre-route placement acceptance only; no global route, final return continuity, noise/thermal/ESD performance or order readiness is certified.','Full supplied scenes retain real occlusion; no parts were removed. Native model registration is nominal geometry and does not prove tolerance or manufactured fit.','Package source dimensions and current registered pixels were reviewed; no independent BREP reconstruction or manufactured plug/enclosure stack was performed in this layout lens.','R0 DRC was run without schematic parity; the native board has zero parity findings, and native/r0 footprint identity, nets and pad geometry independently match.','The scripts retain initial API/environment corrections and their failed runs, rather than hiding unsuccessful methods.']}
(O/'evidence.json').write_text(json.dumps(EV,indent=2)+'\n')
rows='\n'.join(f"| {c['from']} → {c['to']} | {c['pad_centre_mm']:.4f} | {c['r0_same_layer_centerline_mm']:.4f} | {c['max_length_mm']:.1f} | {c['layer']} |" for c in M['critical_paths'] if c['max_length_mm'] is not None and c['prepared'])
report=f'''review_stage: pre-route
review_kind: layout
reviewer: /root/rj45_pod_layout_approved
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
board_sha256: {EV['board_sha256']}
design_rules_sha256: {EV['design_rules_sha256']}
prepared_board_sha256: {EV['prepared_board_sha256']}

# Independent current pod placement judgment

The exact frozen native placement is SOUND for the pre-route stage. The source-owned r0 launches meet their authored lengths, layers and widths, and the current footprint arrangement leaves usable clamp, regulator, analog and mounting space. This is not routed-clean acceptance: native DRC has58 expected opens; r0 has33 opens and4 intended dangling launch warnings. The separate ground-return finding below is retained explicitly. FIRST-ARTICLE-ONLY / DO-NOT-ORDER remains in force.

## Authority and measured census

All499 envelope inputs match their sizes and SHA-256 before and after review. The rules digest was independently recomputed from the frozen semantic source projection. The exact envelope subject is `{json.dumps(E['subject'],sort_keys=True)}`. No source, board, rule, live file or historical route was adopted or edited; no KRT, rebuild, children or background process was used.

Native and r0 have the same44 footprints,113 pad objects ({counts['electrical_numbered_pad_objects']} numbered electrical pads,6 unnumbered NPTH objects and4 U2 paste-only apertures), side/rotation/pad nets and model transforms. Sorting duplicate J1 Fab arc graphics removes an object enumeration-order difference; there is no placement change. All40 authored anchors and27 explicit pad/net assertions match. U3's native180° is the expected underside transform of its authored0° placement.

Population is32 fitted bodies:30 top SMT, U3 as the sole bottom SMT, and manual J1. MK1 is a bare two-wire landing; TP1–TP7 are seven bare1.5mm probe pads; H1–H4 are mechanical holes. These12 nonfitted features have intentionally hidden refdes; all32 fitted references are visible on their mounted silkscreen at0.6mm. All32 fitted native model declarations resolve and their files were reopened and hashed. No microphone body is claimed on the PCB.

## Geometry, component bodies and access

The outline is the four native edges at X20..80/Y20..60mm,60×40mm. J1 at(45.5,25.86),0° has its north-going mouth at Y19.50:0.50mm nominal exposure. The manufacturer hole pattern is preserved: eight0.8mm signal drills on2.04mm row pitch with1.02mm stagger and4mm row separation, two3.18mm guides at(42.22,26.56)/(55.92,26.56), and two1×2mm shell slots. Pads9/10 remain POD_SHIELD, separate from signal GND2/6/8.

Native exact shape clearance from either shell land to its adjacent guide is0.268639mm, above the0.25mm hole-to-copper floor by0.018639mm. The derived1.5×2.5mm shell ovals retain0.25mm nominal annulus. Every native pad bounding box is inboard; minimum edge gap is2.260mm at J1 shell pads, comfortably above0.3mm. Four3.2mm mounting drills occupy(24,24),(76,24),(24,56),(76,56). The smallest conservative clearance from a3mm screw radius to a different courtyard is0.725mm at H3/TP4; the other three are2.725,6.5915 and6.2534mm.

No same-side courtyard box intersects another; the tightest conservative box gaps are0.10mm C1/U2 and D2/TP2. D1/J1 is0.55mm. This is positive nominal separation, not a new tolerance allowance. U3 is beneath the jack, in the gap between its tail rows. Its exact pad-to-J1-copper minimum is0.675mm; the conservative Fab-body-to-J1 pad-box minimum is0.50mm. The nearest guide is4.56mm from its Fab box. The bottom view shows its body and pin1 mark in that gap; full-scene sides retain real occlusion by the tails. U3 reflow followed by hand-soldered J1 remains an assembly qualification obligation.

R0 contains15 actual User.2 rectangles: four3mm H-prefixed mounting exclusions, six drill-plus0.6mm NPTH boxes (including the four mounting drills), four edge bands and the one U2/C6/C5 local-copper reservation. The J1 guide boxes are X40.03..44.41 and53.73..58.11/Y24.37..28.75; they leave0.44mm to the nearest signal-pad bounding boxes and do not swallow the8 contacts or U3. The shell lands overlap the guide box at their inner tips, but their centers and outboard exits remain available; their exact physical drill clearance is separately graded above. The U2 output reservation intentionally contains authored copper and blocks future stochastic intrusion.

## Proximity and actual prepared launches

All6 part-dossier proximity rules pass independently, including each of the four U2 capacitors separately and both J1/U3 channels. All11 already-prepared critical path budgets pass. Distances below are millimetres measured from current pad centers and saved track centerlines; up to1µm attachment handles source endpoint rounding. These measurements do not count empty future routes as completed.

| Path | Pad centers | Prepared path | Limit | Layer |
|---|---:|---:|---:|---|
{rows}

The future R12.2→TP5 and R13.2→TP6 probe connections are not in r0; their3.9300/3.5000mm center distances fit the5mm budget with useful direct-route room. U3.4 has a prepared0.50mm-wide, via-free B.Cu return to J1.6, measured3.6035mm including the0.0005mm pad-center attachment. It does not use POD_SHIELD.

Saved r0 has exactly78 authored segments and8 authored off-pad vias; the independent source-to-saved multiset comparison finds no missing or extra segment and all8 via positions match. D1.1 reaches D2.1 first on F.Cu before the protected tree departs left/down to TP2/C1/C2/U2/R14; there is no pre-D2 same-layer branch. AUDIO_P and AUDIO_N each have only their own three-segment B.Cu connector-to-clamp prefix, without vias or downstream tee. Future routes must depart the clamp pads; a ratline endpoint on a connector-side track does not authorize bypassing that order.

The source floors survive identically in native/r0 project settings:0.127mm fab track/clearance;0.15mm netclass clearance;0.50mm input,0.40mm quiet-power and0.25mm audio/analog width floors;0.6/0.3mm vias;0.15mm annulus;0.25mm hole-to-copper;0.5mm hole-to-hole;0.3mm copper-to-edge. Actual r0 widths are0.26/0.40/0.50mm. U2/U3 adjacent different-net pads reach0.15mm clearance, so their existing direct escapes are appropriate; uncontrolled in-pad layer changes would not be interchangeable with the current launch plan.

The east MK1/C8/R4/R5 bias and input cell is separated from the west power entry. The R8/R9 and R10/R11 feedback satellites are close to their respective U1 inverting pins (roughly4–4.5mm); U1's C10 supply bypass is1.945mm from pin4. MIC_AC still traverses from the east landing cell to the preamp input resistor, so future routing must keep that sensitive run compact and separated from output and supply traces. Shared two-layer GND rather than an arbitrary analog split is the declared return intent; the source owns later ground stitching. No final continuous return, thermal result or noise performance is inferred from placement.

## Native DRC classification

Native command: full severity, refill, schematic parity and exit-on-violations on the isolated byte-identical native PCB/pro/dru. Result:0 violations,58 opens,0 parity findings. R0 initially yielded44 library-resolution warnings plus4 dangling warnings and33 opens because its route directory lacks a library table. Repeating with only a scratch table resolving the frozen libraries yields4 dangling warnings and33 opens; no clearance, short, width, edge, courtyard, drill or thermal violation remains.

`drc-classification.json` and `drc-classification.md` retain all176 raw records across the three runs, including every exact description, node pair, coordinate and UUID, with a row-specific class/reason/next owner. Native58, initial r081 and resolved r037 are all represented. The four dangling tracks are source-owned VREF U1.2, PRE_OUT U1.7, OUTP_FB R11.2 and MIC_AC R5.1 launches. The32 ordinary r0 signal/power/shield opens await their declared waves. The remaining open is C10.2-to-GND-zone and is explicitly a return/stitch obligation, L1 below. R0 parity was not requested; the separately checked native schematic parity and matched pad/net population provide the applicable pre-route binding.

The native report's five ignored check types are retained verbatim in classification evidence: missing_courtyard, track_not_centered_on_via, tuning_profile_track_geometries, footprint_filters_mismatch and footprint_type_mismatch. Courtyard existence and geometry were measured independently; no ignored type is silently presented as checked.

## Current model and rendered evidence

I reopened aggregate model_registration.md, stage receipt, bundle and index, then both selected group receipts/bundles and all their output pixels. Aggregate and group board inputs bind this exact a44b769b native board. The current two groups are Wurth J1 and TI U2; the old MicroFit group and failed/last_pass material carry no authority here. Supplied group metrics are12/12 J1 drilled centers with0.024067mm image center delta and13/13 U2 pad/aperture centers with0.000mm delta; the U2 count includes four paste apertures and is not13 electrical pins. The U2 lead envelope extends0.903466mm beyond the body Fab box as expected for gull-wing leads, inside its courtyard. Those image-calibration metrics were reopened, not falsely represented as newly regenerated measurements.

I inspected22 exact images, including both approved opaque full-board top/bottom views, all five current full-scene orientation renders, all five J1 crops, and all ten current group images. `inspected-images.json` binds every viewed pixel file by hash and size, and the archive preserves each unchanged. No new render recipe was needed. J1's socket/latch opening faces outboard north; the rear pin structure faces inboard. The two profiles show the shell above the PCB with tails below. There is no visible main-body overlap with top passives or blocked screw hole. The jack's top occludes its pin1 pad, so orientation is supported by bottom pad geometry, the mouth views and current registration, not by an invented visible top pad mark.

D1's cathode stripe faces its west pad1, D2's stripe its north pad1, U1 and U2 pin1 markings agree with their actual pad positions, and U3's bottom-view pin1 mark agrees after underside mirroring. MK1's southern square pad is the positive MIC_RAW landing. The NOT ETHERNET / NOT POE warning, connector pin map, PTC and seven functional testpoint legends are legible in the inspected top pixels. This visual judgment is independent of user P-ORIENT approval. Pixels cannot establish final solder fillets, manufactured tolerance, enclosure access or cord fit.

## Findings and next ownership

- **L1 — P2 routing completion obligation, not a placement blockage.** C10.2 at(52.12,49.00) is isolated from the filled r0 GND plane. Route/stitch owner must restore and verify its short return before routed acceptance. An exact native foreign-copper screen of a hypothetical0.6/0.3mm via at(51.2,49.0),0.92mm away, has minimum0.908847mm clearance; no copper was added and this is not a route certificate.
- **L2 — P3 guidance advisory.** The last ESD elbows at(50.45,28.36) and(47.65,27.36) are square; TI section10.1 recommends rounded exposed corners. The route source owner should consider radiusing them before final copper acceptance while preserving current prefix order and bounds. The current clamp-first placement, length and clearance pass; no physical limit is relaxed.
- **L3 — first-article physical hold.** Qualify nominal shell-guide margin, free spring-finger variation, bottom U3 assembly beside hand-soldered J1 tails, populated latch/mating/unmating, seating, cord strain relief/bend and enclosure stack. Source notes put the free finger only0.001919mm inside the courtyard centerline, so nominal registration cannot become a manufacturing containment claim. The existing owner is mechanical/assembly/first-article qualification.

The source's exact factory Cat6A cord is a custom analog/DC connection, not Ethernet/PoE, and mating is power-off only. Exact carrier fault/transient bounds, sourcing/assembly allocation, rails, noise/gain/clipping, ESD/EMC, capsule acoustics and outdoor enclosure qualification remain held under source authority. They do not require a commissioning measurement to render this honest nominal pre-route placement verdict, and they do not permit ordering.

## Evidence and limits

Raw pcbnew measurements, the exact native DRC files and complete item classification, supported-runtime logs/results, unsuccessful API/environment probes, scripts, current primary PDF extracts, viewed images and relevant frozen inputs are archived. Body/courtyard screens use conservative native boxes where stated; exact copper gaps use native SHAPE.GetClearance. Package source dimensions and registered pixels were inspected; this layout lens did not independently reconstruct the full STEP BREP or a manufactured plug/enclosure tolerance stack. No global routing, source regeneration, procurement, manufacturing or release acceptance was performed.
'''
(O/'report.md').write_text(report)
# Retain reproducible evidence without recursive archives or unrelated historical artifacts.
A=S/'archive-members';A.mkdir(exist_ok=True)
for p in S.iterdir():
 if p.is_file() and p.name!='package.py':shutil.copy2(p,A/p.name)
shutil.copy2(S/'package.py',A/'package.py')
for n in ['report.md','evidence.json']:shutil.copy2(O/n,A/n)
inputs=['TASK.md','context/CLAUDE.md','context/skills/kicad-pcb/references/design-policies.md','context/skills/kicad-pcb/references/placement-and-proximity.md','context/skills/kicad-pcb/references/drc-discipline.md','context/skills/kicad-pcb/scripts/pre_route_review_check.py','context/skills/kicad-pcb/scripts/model_coverage_check.py']
inputs += ['project/'+n for n in ['01_docs/BRIEF.md','03_src/floorplan.yaml','03_src/route.yaml','03_tscircuit/src/crow_mic_pod_v3.tsx','04_kicad/crow_mic_pod_v3.kicad_pcb','04_kicad/crow_mic_pod_v3.kicad_pro','04_kicad/crow_mic_pod_v3.kicad_dru','04_kicad/crow_mic_pod_v3.kicad_sch','04_kicad/fp-lib-table','04_kicad/refdes_waiver.json','06_build/route/r0.kicad_pcb','06_build/route/r0.kicad_pro','06_build/route/r0.kicad_dru','06_build/pre_route/model_registration.md','06_build/pre_route/model_registration.stage.json','06_build/pre_route/model_registration_bundle/bundle.json','06_build/pre_route/model_registration_bundle/model_registration_index.json','06_build/placement_policy_audit.md']]
inputs += [str(p.relative_to(ROOT)) for p in (P/'03_src/rules').glob('*.yaml')]
for part,pdf in [('615008160221','Wurth_615008160221_rev001003.pdf'),('TPD2E2U06DRLR','tpd2e2u06.pdf'),('TPS7A4901DGNR','tps7a49.pdf'),('OPA1679IDR','opa1679.pdf')]:
 inputs+=['project/02_parts/'+part+'/'+pdf,'project/02_parts/'+part+'/part.yaml']
inputs+=['project/02_parts/615008160221/primary-source-record.md']
for g in EV['current_model_groups']:
 for p in (P/'06_build/pre_route/native_registration'/g).iterdir():
  if p.is_file():inputs.append(str(p.relative_to(ROOT)))
inputs += [x['path'] for x in image_rows]
for n in sorted(set(inputs)):
 p=ROOT/n;q=A/'inputs'/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
shutil.copy2(T/'envelope.json',A/'envelope.json')
# Preserve actual scratch resolver configuration used for the second r0 DRC.
shutil.copy2(S/'project/06_build/route/fp-lib-table',A/'r0-resolved-fp-lib-table.txt')
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in sorted(A.rglob('*')):
  if p.is_file():assert not p.is_symlink();tf.add(p,arcname=p.relative_to(A).as_posix(),recursive=False)
records=[];seen=set()
with tarfile.open(archive,'r:gz') as tf:
 for member in tf.getmembers():
  assert member.isfile() and member.name not in seen and not member.name.startswith('/') and '..' not in pathlib.PurePosixPath(member.name).parts
  assert not member.name.endswith(('.tar','.tar.gz','.tgz','.zip'));seen.add(member.name);data=tf.extractfile(member).read();assert len(data)==member.size
  records.append({'path':member.name,'size':member.size,'sha256':hashlib.sha256(data).hexdigest()})
manifest={'archive_sha256':digest(archive),'archive_size':archive.stat().st_size,'member_count':len(records),'members':records};(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(O/'result.json').write_text(json.dumps({'subject':E['subject'],'checks':{x:'PASS' for x in E['completion']['checks']},'unresolved':[]},indent=2)+'\n')
print('VERDICT SOUND; report',O/'report.md');print('ARCHIVE',archive,'members',len(records),'bytes',archive.stat().st_size,'sha256',digest(archive));print('counts',counts)
