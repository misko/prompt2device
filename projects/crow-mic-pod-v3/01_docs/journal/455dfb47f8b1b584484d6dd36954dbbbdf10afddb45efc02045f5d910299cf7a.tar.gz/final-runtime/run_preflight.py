from pathlib import Path
import os, sys, json
ROOT=Path('/tmp/rj45-pod-s1m-source-review2-tnmv8i13')
RUN=ROOT/'06_build/task_runs/rj45-pod-s1m-source-review2'
SCR=RUN/'scratch'
sys.path.insert(0,'/home/mouse9911/gits/circuits-worktrees/crow-roof-array-v1-20260901/skills/pcb-design/scripts')
from pipeline_runtime import run_stage
spec={'id':'exact_source_review_preflight','work_class':'review_wait','timeout_s':90,'produces':[]}
o=run_stage(spec,['/usr/bin/python3','-B',str(ROOT/'preflight.py'),str(RUN/'envelope.json')],log_path=SCR/'runtime/final_preflight2.log',cwd=ROOT,env=dict(os.environ),heartbeat_s=5,console=None,run_id='final_preflight2')
(SCR/'runtime/final_preflight2_outcome.json').write_text(json.dumps({'status':o.status,'returncode':o.returncode,'started_at':o.started_at,'finished_at':o.finished_at},indent=2)+'\n')
print(o.status,o.returncode)
assert o.status=='PASS' and o.returncode==0
