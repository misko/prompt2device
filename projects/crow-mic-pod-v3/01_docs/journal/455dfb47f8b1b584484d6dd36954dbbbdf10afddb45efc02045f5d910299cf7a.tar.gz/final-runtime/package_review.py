from pathlib import Path, PurePosixPath
import hashlib, json, os, shutil, tarfile, re

ROOT=Path('/tmp/rj45-pod-s1m-source-review2-tnmv8i13')
RUN=ROOT/'06_build/task_runs/rj45-pod-s1m-source-review2'
SCR=RUN/'scratch'
OUT=RUN/'outputs'
EVD=SCR/'archive_evidence'
ENV=json.loads((RUN/'envelope.json').read_text())
BIND=json.loads((ROOT/'BINDINGS.json').read_text())
SUB=ENV['subject']

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

verification=[]
for item in ENV['input_packet']:
    p=ROOT/item['path']
    verification.append({'name':item['name'],'path':item['path'],'expected_size':item['size'],'observed_size':p.stat().st_size,'expected_sha256':item['sha256'],'observed_sha256':sha(p),'match':p.stat().st_size==item['size'] and sha(p)==item['sha256']})
assert all(x['match'] for x in verification)

if EVD.exists(): shutil.rmtree(EVD)
EVD.mkdir(parents=True)
(EVD/'renders').mkdir()
(EVD/'runtime').mkdir()
(EVD/'text_indexes').mkdir()
for p in sorted((SCR/'render').glob('*.png')): shutil.copy2(p,EVD/'renders'/p.name)
for p in sorted((SCR/'runtime').glob('*')):
    if p.is_file(): shutil.copy2(p,EVD/'runtime'/p.name)
for p in sorted((SCR/'text').glob('*.txt')): shutil.copy2(p,EVD/'text_indexes'/p.name)
shutil.copy2(SCR/'run_evidence_tools.py',EVD/'run_evidence_tools.py')
shutil.copy2(SCR/'render_ti.py',EVD/'render_ti.py')
(EVD/'input_verification.json').write_text(json.dumps({'phase':'pre-package-and-post-review','count':len(verification),'all_match':True,'files':verification},indent=2)+'\n')

old=(ROOT/'baseline/03_src/lib/JKSEMI_1N4007_M7_SMA.kicad_mod').read_text().splitlines()
new=(ROOT/'candidate/03_src/lib/Vishay_S1M_SMA.kicad_mod').read_text().splitlines()
geometry_prefixes=('  (fp_line','  (fp_rect','  (pad ','  (model ')
old_geo=[x for x in old if x.startswith(geometry_prefixes)]
new_geo=[x for x in new if x.startswith(geometry_prefixes)]
geom={
 'old_geometry_lines':old_geo,'new_geometry_lines':new_geo,
 'geometry_byte_equal':old_geo==new_geo,
 'old_geometry_sha256':hashlib.sha256(('\n'.join(old_geo)+'\n').encode()).hexdigest(),
 'new_geometry_sha256':hashlib.sha256(('\n'.join(new_geo)+'\n').encode()).hexdigest(),
 'pads':{'numbers':['1','2'],'centers_mm':[-2.0,2.0],'center_spacing_mm':4.0,'size_mm':[2.5,1.8],'inner_gap_mm':1.5,'outer_span_mm':6.5},
 'vishay_body_mm':{'length_min':3.99,'length_max':4.50,'width_min':2.54,'width_max':2.79,'overall_terminal_span_min':4.93,'overall_terminal_span_max':5.28},
 'vishay_mounting_layout_mm':{'pad_length_min':1.52,'pad_width_min':1.68,'inner_gap_max':1.88,'overall_span_ref':5.28},
 'compatibility':{'pad_length_meets_min':2.5>=1.52,'pad_width_meets_min':1.8>=1.68,'inner_gap_meets_max':1.5<=1.88,'courtyard_mm':[7.0,3.1],'courtyard_contains_body_outline':True},
 'documentation_note':'Retained F.Fab is 4.60 x 2.50 mm and under-represents Vishay body width 2.54..2.79 mm; F.CrtYd is 7.00 x 3.10 mm and contains the body. Source review does not grant placement acceptance.'
}
(EVD/'geometry.json').write_text(json.dumps(geom,indent=2)+'\n')
calc={'reverse_hookup_model':'D1 reverse leakage is sunk toward the negative source; R14 supplies it from ground, so VIN_PROTECTED = -IR*R14.','ir_max_125c_uA':50.0,'r14_nominal_ohm':4700.0,'r14_tolerance_pct':1.0,'r14_max_ohm':4747.0,'vin_protected_worst_v':-0.23735,'ti_in_to_gnd_absolute_min_v':-0.3,'margin_v':0.06265,'limit_fraction_used_pct':79.1166666667,'result':'PASS'}
(EVD/'calculation.json').write_text(json.dumps(calc,indent=2)+'\n')
(EVD/'source_observations.txt').write_text(
 'Vishay 88711 visual pages 1-4: page 1 names S1M, SMA (DO-214AC), states color band denotes cathode end, and gives S1M 1000 V, 1 A, 30 A surge; page 2 gives 1.1 V at 1 A, 5 uA at 25 C and 50 uA at 125 C and ordering-form examples; page 3 gives exact package and mounting layout; page 4 is disclaimer.\n'
 'JKSEMI visual pages 1-3: page 1 gives baseline 1000 V, 1 A, 30 A, 1.1 V, 5/50 uA; page 3 gives SMA dimensions and 1.8 x 1.8 mm pads separated 2.4 mm. It does not explicitly state cathode-band meaning.\n'
 'TI SBVS121E visual PDF pages 4-6 inspected: page 4 identifies DGN pin 8 as IN and pin 4 as GND; page 5 Absolute Maximum Ratings explicitly gives IN pin to GND pin MIN -0.3 V, MAX 36 V; page 6 was checked as adjacent electrical context.\n')

binding_lines='\n'.join(f'{k}: {v}' for k,v in BIND.items())
report=f'''review_stage: source
review_kind: exact-part
reviewer: rj45-pod-s1m-source-review2 fresh judgment agent
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
{binding_lines}

# Exact source review: D1 Vishay S1M-E3/61T

The frozen candidate source composition is SOUND for adoption into subsequent schematic/native generation. This is source acceptance only. It is not schematic, placement, routing, sourcing-stock, fabrication, physical-fit, or release acceptance, and the design remains DO-NOT-ORDER / FIRST-ARTICLE-ONLY.

## Expected and observed facts

| Fact | Expected | Observed | Result |
|---|---:|---:|---|
| exact D1 MPN | S1M-E3/61T | `part.yaml`, TSX, Fab value, architecture and rule agree | PASS |
| supplier code | C144860 | `part.yaml`, TSX and footprint tags agree | PASS |
| manufacturer/family | Vishay S1M | Vishay document 88711 rev. 07-May-2024, family S1A..S1M | PASS |
| package | SMA / DO-214AC | stated on Vishay pages 1 and 3 | PASS |
| polarity evidence | band marks cathode | Vishay page 1 explicitly says color band denotes cathode end; page 3 labels cathode band | PASS |
| terminal mapping | pad 1 K, pad 2 A | part metadata and TSX agree; pad 1/left has footprint cathode silk, connects VIN_PROTECTED; pad 2/right connects 12V_FUSED | PASS |
| recurrent/DC reverse voltage | 1000 V | S1M column: 1000 V | PASS |
| average forward current | 1.0 A | 1.0 A | PASS |
| max forward drop | 1.1 V at 1 A | 1.1 V at 1.0 A | PASS |
| peak forward surge | 30 A, 8.3 ms half sine | S1K/S1M: 30 A | PASS |
| max reverse leakage, 25 C | 5 uA | S1K/S1M: 5.0 uA at rated blocking voltage | PASS |
| max reverse leakage, 125 C | 50 uA | 50 uA | PASS |
| TI negative input authority | -0.3 V IN-to-GND absolute minimum | TI SBVS121E PDF page 5, Absolute Maximum Ratings, explicitly gives -0.3 V | PASS |

The baseline JKSEMI PDF independently shows the same core maxima: 1000 V, 1 A, 1.1 V at 1 A, 30 A for the 8.3 ms surge, and 5/50 uA at 25/125 C. Its package page does not explicitly define the pictured band as cathode, which is the source gap repaired by the Vishay replacement.

## R14 arithmetic

Reverse hookup drives D1 in reverse. Its worst published hot leakage draws the protected node below ground through the negative source, while R14 supplies that current from ground. With R14 at its +1% corner, `Rmax = 4700 * 1.01 = 4747 ohm`. Therefore `VIN_PROTECTED = -(50 uA)(4747 ohm) = -0.23735 V`. TI's explicit IN-to-GND absolute minimum is -0.300 V, leaving `0.300 - 0.23735 = 0.06265 V` (62.65 mV) of margin. This conservative 125 C leakage check exceeds the design's admitted +70 C powered/transient ambient.

## Footprint geometry

The old and new KiCad geometry lines are byte-identical: three silk lines, courtyard, Fab outline, reference placement, two pads and the 3D model transform. Only identity/description/tags/value text changed. Both use pad 1 at -2.00 mm and pad 2 at +2.00 mm, each 2.50 x 1.80 mm: 4.00 mm centers, 1.50 mm inner gap and 6.50 mm outer copper span. TSX reproduces the same pad numbers, centers and sizes.

Vishay page 3 gives body length 3.99..4.50 mm, body width 2.54..2.79 mm, total terminal span 4.93..5.28 mm, and a mounting layout with at least 1.52 mm pad length, at least 1.68 mm pad width, at most 1.88 mm inner gap and 5.28 mm overall reference. The retained land has larger pad length and width and a smaller inner gap, so it catches the full terminal range. The 7.00 x 3.10 mm courtyard contains the maximum body. The retained 4.60 x 2.50 mm F.Fab outline is narrower than the Vishay 2.54..2.79 mm body and is therefore documentation, not physical-fit proof; this source gate excludes placement acceptance. Paste volume, toe/heel/side fillets, tombstoning and assembly yield remain mandatory first-article checks because the retained land is not Vishay's nominal mounting drawing.

## Internal composition and scope

The filesystem-safe dossier is `candidate/02_parts/S1M-E3-61T`, while its first field preserves exact slash-containing MPN `S1M-E3/61T`. TSX binds D1 to C144860, K/pad 1/VIN_PROTECTED and A/pad 2/12V_FUSED. The protection rule names the exact MPN and 1000 V limit. Architecture places D1 in series from fused 12 V into VIN_PROTECTED and preserves R14 as the reverse-leakage pull-down. U2 pin 8 IN and pin 4 GND agree with TI.

All 18 envelope inputs were hash/size verified before packaging and again by the final preflight. All four Vishay pages and all three JKSEMI pages were visually inspected from 180 dpi renders; TI PDF pages 4-6 were visually inspected, including the controlling page 5 absolute-rating table. Text extraction was used only as a page locator/index. Qualification logs were read as prior command evidence and were not substituted for independent judgment.

Unresolved findings: none within this exact source-review scope. The expressly excluded physical and downstream gates remain open by design.
'''

evidence={
 'schema':1,'verdict':'SOUND','subject':SUB,'review_stage':'source','review_kind':'exact-part','reviewer':'rj45-pod-s1m-source-review2 fresh judgment agent','context':'FRESH',
 'methods':['verified every envelope input size and SHA-256','rendered PDFs with pdftoppm at 180 dpi under finite shared pipeline_runtime.run_stage','visually inspected all Vishay and JKSEMI pages and TI PDF pages 4-6 with view_image','used pdftotext only to index and locate controlling tables','compared KiCad geometry lines byte-for-byte and numerically checked Vishay mounting dimensions','recomputed R14 leakage corner from primary maxima'],
 'measured_counts':{'envelope_inputs_verified':18,'manufacturer_pdfs':3,'pdf_pages_total':46,'pages_rendered_and_visually_inspected':10,'vishay_pages_inspected':4,'jksemi_pages_inspected':3,'ti_pages_inspected':3,'footprints_compared':2,'footprint_geometry_lines_each':len(old_geo),'pad_count_each':2,'qualification_logs_read':3},
 'findings':[
  {'id':'d1-primary-identity-and-ratings','status':'PASS','observed':{'mpn':'S1M-E3/61T','package':'SMA (DO-214AC)','band':'color band denotes cathode end','pins':{'1':'K','2':'A'},'vrrm_v':1000,'if_av_a':1.0,'vf_max_v_at_a':[1.1,1.0],'ifsm_a_8_3ms':30,'ir_max_ua_25c':5,'ir_max_ua_125c':50}},
  {'id':'r14-hot-leakage','status':'PASS','observed':calc},
  {'id':'ti-negative-absolute-limit','status':'PASS','observed':'SBVS121E PDF page 5 explicitly gives IN pin to GND pin -0.3 V minimum and 36 V maximum.'},
  {'id':'footprint-geometry','status':'PASS_WITH_FIRST_ARTICLE_LIMIT','observed':geom},
  {'id':'composition-consistency','status':'PASS','observed':'part.yaml, TSX, footprint identity/value, protection rule and architecture agree on exact MPN, C144860, polarity, nets and ratings; filesystem-safe directory preserves the exact MPN inside part.yaml.'}
 ],
 'scope_limits':['no schematic/native generation acceptance','no placement or routing acceptance','no sourcing stock acceptance','no fabrication, solder-fillet, physical-fit or release acceptance','first-article assembly and thermal checks remain required'],
 'unresolved':[]
}

if OUT.exists(): shutil.rmtree(OUT)
OUT.mkdir(parents=True)
(OUT/'report.md').write_text(report)
(OUT/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
shutil.copy2(OUT/'report.md',EVD/'report.md')
shutil.copy2(OUT/'evidence.json',EVD/'evidence.json')

members=[]
for p in sorted(EVD.rglob('*')):
    if p.is_file() and not p.is_symlink():
        rel=p.relative_to(EVD).as_posix()
        assert '..' not in PurePosixPath(rel).parts and not PurePosixPath(rel).is_absolute()
        members.append({'path':rel,'size':p.stat().st_size,'sha256':sha(p)})
archive=OUT/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tf:
    for m in members: tf.add(EVD/m['path'],arcname=m['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tf:
    names=tf.getnames(); assert len(names)==len(set(names))==len(members)
    assert set(names)=={m['path'] for m in members}
    for m in members:
        ti=tf.getmember(m['path']); assert ti.isfile() and not ti.issym() and not ti.islnk()
        data=tf.extractfile(ti).read(); assert len(data)==m['size'] and hashlib.sha256(data).hexdigest()==m['sha256']
manifest={'schema':1,'archive_sha256':sha(archive),'archive_size':archive.stat().st_size,'member_count':len(members),'members':members,'reopened_all_regular_members':True,'no_symlink_traversal_duplicate_or_recursive_archive':True}
(OUT/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
result={'subject':SUB,'checks':{'inputs-verified':'PASS','review-complete':'PASS','evidence-complete':'PASS'},'unresolved':[]}
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'verdict':'SOUND','members':len(members),'archive_sha256':manifest['archive_sha256'],'inputs_verified':len(verification)}))
