review_stage: source
review_kind: exact-part
reviewer: rj45-pod-s1m-source-review2 fresh judgment agent
context: FRESH
design_verdict: SOUND
order_verdict: DO-NOT-ORDER
candidate/03_tscircuit/src/crow_mic_pod_v3.tsx: 0a3649381ee95ec7b1e6f0e65f9891d55218b5bd7d6089b77603a3c0dde86c08
candidate/03_src/rules/protection_paths.yaml: 53762a56d6e655249b261170e0d8b3743ffd42cf4534e0765a8042362599c5f5
candidate/03_src/lib/Vishay_S1M_SMA.kicad_mod: 10684446429362a4fce09698640950790eacf5949f4f9484bc4479add283fd9e
candidate/02_parts/S1M-E3-61T/part.yaml: 5cacc48aa84a7bc577221a1a5bbf5fa26fbd04bd34bd9d3ec481713b4fec46d9
candidate/02_parts/S1M-E3-61T/Vishay_S1_88711.pdf: 49c11fe1f333fda1bcdacc72754927dda4ee5bf977bf88d3c46eb1cd6ffe9277
candidate/01_docs/ARCHITECTURE.md: de1ab65364efe29a7d966be1a5135ce81db163b3c9194859222dc2544f4c7083
baseline/02_parts/1N4007-M7-SMA/part.yaml: 1dd6d20b1de204f4abb54620dfdeb8d621c5c443cc81d4cd307f40ec854102e6
baseline/02_parts/1N4007-M7-SMA/JKSEMI.pdf: f893d8385c6fee5af85b9053653bd8e93547c335c031cbab9ecb592c0bb5eddd
baseline/03_src/lib/JKSEMI_1N4007_M7_SMA.kicad_mod: fc47222d04972d8f48ee6db0938bcba7aa6d30f3c8020290eec934ee3be56991
dependencies/R14/part.yaml: 1c16c3aceb41003910a476c87ceee7e8d26418b7e557103d65d9fda3b59177a8
dependencies/U2/part.yaml: 49da49aa583fbf903b8a89e5e19b680cbd1afc5ecd98959768308f3ca7cfdb31
dependencies/U2/tps7a49.pdf: 0a5e198966ab05ebb39f4512355352c0946af5f52e1fbd2e9ec554041123a126
qualification/tsx-preflight.log: 42b0f1674f8cd7df917b42171c982209c2a474591343c812f7b3252f67ee6742
qualification/early-design.log: 4385b6907dc3690729b2e734dc9e156176180707c54ba956b338100ff0e1971f
qualification/policy-source.log: 14dd009a38e96016a86afbd003c26c011ffca58c65658528f2eb3e43e77946f5

# Exact source review: D1 Vishay S1M-E3/61T

The frozen candidate source composition is SOUND for adoption into subsequent schematic/native generation. This is source acceptance only. It is not schematic, placement, routing, sourcing-stock, fabrication, physical-fit, or release acceptance, and the design remains DO-NOT-ORDER / FIRST-ARTICLE-ONLY.

## Expected and observed facts

| Fact | Expected | Observed | Result |
|---|---:|---:|---|
| exact D1 MPN | S1M-E3/61T | `part.yaml`, TSX, Fab value, architecture and rule agree | PASS |
| supplier code | C144860 | `part.yaml`, TSX and footprint tags agree | PASS |
| manufacturer/family | Vishay S1M | Vishay document 88711 rev. 07-May-2024, family S1A..S1M | PASS |
| package | SMA / DO-214AC | stated on Vishay pages 1 and 3 | PASS |
| polarity evidence | band marks cathode | Vishay page 1 explicitly says color band denotes cathode end; page 3 labels cathode band | PASS |
| terminal mapping | pad 1 K, pad 2 A | part metadata and TSX agree; pad 1/left has footprint cathode silk, connects VIN_PROTECTED; pad 2/right connects 12V_FUSED | PASS |
| recurrent/DC reverse voltage | 1000 V | S1M column: 1000 V | PASS |
| average forward current | 1.0 A | 1.0 A | PASS |
| max forward drop | 1.1 V at 1 A | 1.1 V at 1.0 A | PASS |
| peak forward surge | 30 A, 8.3 ms half sine | S1K/S1M: 30 A | PASS |
| max reverse leakage, 25 C | 5 uA | S1K/S1M: 5.0 uA at rated blocking voltage | PASS |
| max reverse leakage, 125 C | 50 uA | 50 uA | PASS |
| TI negative input authority | -0.3 V IN-to-GND absolute minimum | TI SBVS121E PDF page 5, Absolute Maximum Ratings, explicitly gives -0.3 V | PASS |

The baseline JKSEMI PDF independently shows the same core maxima: 1000 V, 1 A, 1.1 V at 1 A, 30 A for the 8.3 ms surge, and 5/50 uA at 25/125 C. Its package page does not explicitly define the pictured band as cathode, which is the source gap repaired by the Vishay replacement.

## R14 arithmetic

Reverse hookup drives D1 in reverse. Its worst published hot leakage draws the protected node below ground through the negative source, while R14 supplies that current from ground. With R14 at its +1% corner, `Rmax = 4700 * 1.01 = 4747 ohm`. Therefore `VIN_PROTECTED = -(50 uA)(4747 ohm) = -0.23735 V`. TI's explicit IN-to-GND absolute minimum is -0.300 V, leaving `0.300 - 0.23735 = 0.06265 V` (62.65 mV) of margin. This conservative 125 C leakage check exceeds the design's admitted +70 C powered/transient ambient.

## Footprint geometry

The old and new KiCad geometry lines are byte-identical: three silk lines, courtyard, Fab outline, reference placement, two pads and the 3D model transform. Only identity/description/tags/value text changed. Both use pad 1 at -2.00 mm and pad 2 at +2.00 mm, each 2.50 x 1.80 mm: 4.00 mm centers, 1.50 mm inner gap and 6.50 mm outer copper span. TSX reproduces the same pad numbers, centers and sizes.

Vishay page 3 gives body length 3.99..4.50 mm, body width 2.54..2.79 mm, total terminal span 4.93..5.28 mm, and a mounting layout with at least 1.52 mm pad length, at least 1.68 mm pad width, at most 1.88 mm inner gap and 5.28 mm overall reference. The retained land has larger pad length and width and a smaller inner gap, so it catches the full terminal range. The 7.00 x 3.10 mm courtyard contains the maximum body. The retained 4.60 x 2.50 mm F.Fab outline is narrower than the Vishay 2.54..2.79 mm body and is therefore documentation, not physical-fit proof; this source gate excludes placement acceptance. Paste volume, toe/heel/side fillets, tombstoning and assembly yield remain mandatory first-article checks because the retained land is not Vishay's nominal mounting drawing.

## Internal composition and scope

The filesystem-safe dossier is `candidate/02_parts/S1M-E3-61T`, while its first field preserves exact slash-containing MPN `S1M-E3/61T`. TSX binds D1 to C144860, K/pad 1/VIN_PROTECTED and A/pad 2/12V_FUSED. The protection rule names the exact MPN and 1000 V limit. Architecture places D1 in series from fused 12 V into VIN_PROTECTED and preserves R14 as the reverse-leakage pull-down. U2 pin 8 IN and pin 4 GND agree with TI.

All 18 envelope inputs were hash/size verified before packaging and again by the final preflight. All four Vishay pages and all three JKSEMI pages were visually inspected from 180 dpi renders; TI PDF pages 4-6 were visually inspected, including the controlling page 5 absolute-rating table. Text extraction was used only as a page locator/index. Qualification logs were read as prior command evidence and were not substituted for independent judgment.

Unresolved findings: none within this exact source-review scope. The expressly excluded physical and downstream gates remain open by design.
