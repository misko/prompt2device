import hashlib, json, math, sys
from pathlib import Path
import pcbnew

board_path=Path(sys.argv[1]).resolve()
b=pcbnew.LoadBoard(str(board_path))
mm=lambda v: v/1_000_000.0

def xy(p): return [round(mm(p.x),6),round(mm(p.y),6)]
def box_vals(bb): return [round(mm(bb.GetX()),6),round(mm(bb.GetY()),6),round(mm(bb.GetRight()),6),round(mm(bb.GetBottom()),6)]
def box_gap(circle_xy,r,bb):
    x,y=circle_xy; x0,y0,x1,y1=box_vals(bb)
    dx=max(x0-x-r, x-x1-r, 0.0)
    dy=max(y0-y-r, y-y1-r, 0.0)
    if dx or dy: return math.hypot(dx,dy)
    # negative penetration to nearest boundary when circle meets/intersects bbox
    return -min(x+r-x0,x1-(x-r),y+r-y0,y1-(y-r))

def fab_bbox(f):
    bbs=[]
    for it in f.GraphicalItems():
        if it.GetLayer()==pcbnew.F_Fab: bbs.append(it.GetBoundingBox())
    if not bbs: return None
    x0=min(x.GetX() for x in bbs); y0=min(x.GetY() for x in bbs)
    x1=max(x.GetRight() for x in bbs); y1=max(x.GetBottom() for x in bbs)
    return [round(mm(x0),6),round(mm(y0),6),round(mm(x1),6),round(mm(y1),6)]

fps=list(b.GetFootprints())
fitted=[f for f in fps if not f.IsExcludedFromBOM() and not f.IsDNP()]
smd=[f for f in fitted if f.GetAttributes() & pcbnew.FP_SMD]
tht=[f for f in fitted if f.GetAttributes() & pcbnew.FP_THROUGH_HOLE]
refs=[]
for f in fitted:
    refs.append({'ref':f.GetReference(),'layer':b.GetLayerName(f.GetLayer()),'smd':bool(f.GetAttributes()&pcbnew.FP_SMD),'tht':bool(f.GetAttributes()&pcbnew.FP_THROUGH_HOLE),'model_count':len(f.Models()),'reference_visible':f.Reference().IsVisible(),'reference_layer':b.GetLayerName(f.Reference().GetLayer()),'reference_position_mm':xy(f.Reference().GetPosition())})

seeds={}
for ref,pad_no,net,target in [('R12','1','OUTP_DRV',(55.0,36.0)),('R3','2','MIC_BIAS',(66.0,39.0))]:
    f=b.FindFootprintByReference(ref); p=f.FindPadByNumber(pad_no)
    vias=[t for t in b.GetTracks() if isinstance(t,pcbnew.PCB_VIA) and t.GetNetname()==net and abs(mm(t.GetPosition().x)-target[0])<1e-6 and abs(mm(t.GetPosition().y)-target[1])<1e-6]
    tracks=[t for t in b.GetTracks() if isinstance(t,pcbnew.PCB_TRACK) and not isinstance(t,pcbnew.PCB_VIA) and t.GetNetname()==net and (xy(t.GetStart())==list(target) or xy(t.GetEnd())==list(target))]
    assert len(vias)==1,(ref,len(vias)); assert tracks,(ref,'no source track')
    v=vias[0]; center=(target[0],target[1]); radius=mm(v.GetWidth())/2
    owner_cy=f.GetCourtyard(pcbnew.F_CrtYd).BBox()
    foreign=[]
    for other in fps:
        if other==f: continue
        cy=other.GetCourtyard(pcbnew.F_CrtYd)
        if cy.OutlineCount()==0: continue
        foreign.append((box_gap(center,radius,cy.BBox()),other.GetReference(),box_vals(cy.BBox())))
    foreign.sort()
    pad_size=xy(p.GetSize()); pad_center=xy(p.GetPosition())
    # exact axis-aligned pad-to-via copper gap; these pads and escape are horizontal.
    pad_edge=max(pad_center[0],target[0]) - pad_size[0]/2 if target[0]<pad_center[0] else min(pad_center[0],target[0])+pad_size[0]/2
    copper_gap=abs(target[0]-pad_center[0])-pad_size[0]/2-radius
    drill_gap=abs(target[0]-pad_center[0])-pad_size[0]/2-mm(v.GetDrillValue())/2
    seeds[ref+'.'+pad_no]={
      'net':net,'pad_center_mm':pad_center,'pad_size_mm':pad_size,
      'tracks':[{'start_mm':xy(t.GetStart()),'end_mm':xy(t.GetEnd()),'width_mm':round(mm(t.GetWidth()),6),'layer':b.GetLayerName(t.GetLayer())} for t in tracks],
      'via_center_mm':list(center),'via_size_mm':round(mm(v.GetWidth()),6),'via_drill_mm':round(mm(v.GetDrillValue()),6),
      'pad_to_via_copper_gap_before_bridge_mm':round(copper_gap,6),
      'pad_to_drill_gap_mm':round(drill_gap,6),
      'owner_courtyard_bbox_mm':box_vals(owner_cy),
      'annulus_to_owner_courtyard_signed_gap_mm':round(box_gap(center,radius,owner_cy),6),
      'owner_fab_bbox_mm':fab_bbox(f),
      'nearest_foreign_courtyard':{'ref':foreign[0][1],'annulus_gap_mm':round(foreign[0][0],6),'bbox_mm':foreign[0][2]},
      'reference':{'visible':f.Reference().IsVisible(),'layer':b.GetLayerName(f.Reference().GetLayer()),'position_mm':xy(f.Reference().GetPosition())}
    }

j=b.FindFootprintByReference('J1')
out={
 'board':str(board_path),'board_sha256':hashlib.sha256(board_path.read_bytes()).hexdigest(),
 'footprints_total':len(fps),'fitted_total':len(fitted),'fitted_smd':len(smd),'fitted_smd_front':sum(f.GetLayer()==pcbnew.F_Cu for f in smd),'fitted_smd_back':sum(f.GetLayer()==pcbnew.B_Cu for f in smd),'fitted_tht':len(tht),
 'fitted_model_coverage':[sum(bool(f.Models()) for f in fitted),len(fitted)],
 'fitted_references':sorted(refs,key=lambda x:x['ref']),
 'all_fitted_references_visible':all(f.Reference().IsVisible() for f in fitted),
 'connector':{'ref':'J1','position_mm':xy(j.GetPosition()),'orientation_deg':j.GetOrientationDegrees(),'layer':b.GetLayerName(j.GetLayer()),'courtyard_bbox_mm':box_vals(j.GetCourtyard(pcbnew.F_CrtYd).BBox()),'reference_visible':j.Reference().IsVisible(),'reference_layer':b.GetLayerName(j.Reference().GetLayer()),'reference_position_mm':xy(j.Reference().GetPosition())},
 'seeds':seeds
}
print(json.dumps(out,indent=2,sort_keys=True))
