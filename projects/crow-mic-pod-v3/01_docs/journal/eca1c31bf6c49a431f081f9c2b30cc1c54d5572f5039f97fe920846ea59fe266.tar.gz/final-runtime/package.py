from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,io,sys
T=Path(__file__).resolve().parent.parent;S=T/'scratch';O=T/'outputs';P=T.parents[2];R=P.parents[1]
read=lambda n:json.loads((S/n).read_text());sha=lambda data:hashlib.sha256(data).hexdigest();inv=read('native-inventory.json');drc=read('drc-classification.json');pres=read('final-preservation.json');run=read('continuation.runtime.json');E=json.loads((T/'envelope.json').read_text())
report=f'''# Fresh pod schematic-to-placement result

MEASURED domain result: PLACEMENT PASS / ROUTING HANDOFF REQUIRED. One authorized normal continuation stopped at authenticated route import: `ERROR: route source is build but no build/FINAL marker exists — run route`. Import rc1/0.407s; conductor rc1/7.499s; bounded outer rc1/{run['elapsed_s']:.9f}s. No retry or router execution. Root owns final closure/commits.

Exact input canonical envelope: b404ab0350e7f58bb8ee5000670ab438c054565f322d8f67c2db5457e6227218. Frozen335/335, protected source/tool299/299, source checkpoint311/311, prelayout11/11 and schematic7/7 verified. Live initial compact handoff passed.

Schematic reviews2/2 and placement reviews4/4 passed current exact subjects. Component parity40/40 across all four sources; pin-map4multi-pin refs/38physical identities; feasibility7/7; model coverage32/32; model registration2/2; orientation machine1/1 and human1/1 reused existing approved images with no restamp. Pad-separation5224copper comparisons and7822paste comparisons passed. Land escape69/103copper pads with34no-floor exclusions passed. Tier advisory PF-LEGALIZE remains0.25mm versus0.8mm recommendation,0FAIL/1WARN. Connector SOURCE admitted, FULL9physical facts deferred under first-article decision. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.

The normal driver promoted the reviewed schematic and generated the board from source. Prepared r0 contains86declared deterministic seed primitives; this is preparation only. Current native board contains0tracks/vias and2GND zones. The driver imported no copper. Physical service, routing, route taps/stitch, realized routing including C10.2GND return verification, final route acceptance, layout seal, fabrication, release, order, and physical qualification are NOT RUN in this attempt.

The compact outgoing handoff generator separately refused rc1/0.081s because existing `06_build/drc/gate.json` is older than regenerated inputs. No fresh compact handoff exists; old handoff and stale final gate retained byte-for-byte and with unchanged mtimes. No DRC gate deletion, touch, replacement or approval restamp. Fresh placement report is `06_build/drc/pre_route.json` with0violations/58unconnected/0parity. Every raw row and116endpoint occurrences are independently verified in native pcbnew by UUID, net and position. Full row multisets equal the retained older gate; this does not override the freshness refusal.

PCB SHA256: {inv['board_sha256']}

Component inventory SHA256 (40components, canonical JSON): {inv['component_inventory_sha256']}

Pin-object inventory SHA256 (109pads excluding4mount holes, canonical JSON): {inv['pin_inventory_sha256']}

Placement DRC SHA256: {drc['report_sha256']}

Source/tool protected preimages remain299/299identical, entire input packet335/335unchanged. Final exclusive writer scope PASS with18changed allowed paths and0violations. Frozen handoff files and task ownership claim/attempt receipt were not edited. No child agents, source edits, stale copper import or commits.

Exact command/runtime, full raw output, preimages, generated subjects, receipts, native inventory and complete JSON classifications are in `evidence.tar.gz`. `evidence-manifest.json` records every regular member, size and SHA256 plus archive digest/size. Every archive member is independently reopened; no symlinks, duplicate paths, traversal or recursive archives are admitted. Delivery PASS is separate from the engineering handoff/blockers.

## Complete DRC classifications

Violations: none (0rows). Schematic parity: none (0nodes). Each row below is an error-severity `unconnected_items` finding. Each named same-net pad pair lacks connecting copper: exact native board has0tracks/vias and no zone for that net. Both endpoints exist with matching UUID, net and position. These are19specific unrouted nets, not diagnosed placement congestion. Resolution for every row belongs to fresh routing and is NOT RUN. Machine record retains the complete raw row and exact endpoints.

| Row | Net | Native endpoints | Cause |
|---|---|---|---|
'''
for r in drc['unconnected_items']:
 ends=' ↔ '.join(f"{v['ref']}.{v['pad']} ({v['x_mm']:g},{v['y_mm']:g})" for v in r['verified_native_endpoints']);report+=f"| {r['id']} | {r['net']} | {ends} | No track/via or {r['net']} zone connects this pair. |\n"
report+='\nC10.2 GND exists at(52.12,49)mm and is not an open placement row. That observation does not prove its routed return; the exact realized check remains owed.\n'
(O/'report.md').write_text(report)
result={'subject':E['subject'],'checks':{k:'PASS' for k in E['completion']['checks']},'unresolved':[]};(O/'result.json').write_text(json.dumps(result,indent=2)+'\n')
files={}
def add(f,name):
 if f.is_symlink():raise RuntimeError(f'symlink rejected {f}')
 if not f.is_file():raise RuntimeError(f'not regular {f}')
 if name in files:raise RuntimeError(f'duplicate {name}')
 pp=PurePosixPath(name);assert not pp.is_absolute() and '..' not in pp.parts
 files[name]=f.read_bytes()
for f in sorted(S.rglob('*')):
 if f.is_file() or f.is_symlink(): add(f,'scratch/'+f.relative_to(S).as_posix())
selected=set(pres['writer_scope']['changed_paths'])|{'06_build/drc/gate.json','06_build/agent_handoff.yaml','06_build/route/r0.kicad_pcb','06_build/route/r0.kicad_pro','06_build/route/r0.kicad_dru','06_build/verification/placement_routability_receipt.json','06_build/verification/model_coverage.json','06_build/placement_policy_audit.md','06_build/checkpoints/prelayout-inputs.json','06_build/checkpoints/prelayout.json','06_build/checkpoints/schematic.json','03_tscircuit/build/circuit.json','03_tscircuit/build/schematic.pdf','06_build/netlists/crow_mic_pod_v3.net','08_reviews/pre-route_topology.md','08_reviews/pre-route_schematic_render.md','08_reviews/pre-route_pin.md','08_reviews/pre-route_layout.md','08_reviews/pre-route_render.md'}
selected.update(f.relative_to(P).as_posix() for f in (P/'04_kicad').rglob('*') if f.is_file())
missing=[]
for rel in sorted(selected):
 f=P/rel
 if f.is_file():add(f,'current/'+rel)
 else:missing.append(rel)
for n in ['envelope.json','admission.json']:add(T/n,'task/'+n)
records=[{'path':k,'size':len(v),'sha256':sha(v)} for k,v in sorted(files.items())]
evidence={'schema':1,'subject':E['subject'],'envelope_canonical_sha256':'b404ab0350e7f58bb8ee5000670ab438c054565f322d8f67c2db5457e6227218','domain_result':'PLACEMENT_PASS_ROUTING_HANDOFF_REQUIRED','stopping_gate':'route_import missing current06_build/route/FINAL','command':read('continuation-command.json'),'runtime':run,'conductor':{'returncode':1,'elapsed_s':7.499},'route_import':{'returncode':1,'elapsed_s':0.407},'compact_handoff':{'result':'REFUSED','returncode':1,'reason':'existing final DRC gate is older than regenerated input','prior_gate_and_handoff_preserved':True},'drc_classification':drc,'native_inventory_summary':{k:v for k,v in inv.items() if k not in ['components','pins']},'preservation':pres,'stages_not_run':['stochastic routing','route taps','stitch','realized-route checks including C10.2 GND','final route acceptance','layout seal','fabrication','release','order','physical qualification'],'holds':['FIRST-ARTICLE-ONLY','DO-NOT-ORDER','connector FULL9physical unknowns deferred'],'archived_subjects':records,'selected_optional_paths_absent':missing,'delivery_scope':'execution-recorded, inputs-verified, outputs-preserved are delivery consistency only; domain gate result remains separate'}
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
for n in ['report.md','evidence.json','result.json']:add(O/n,'delivery/'+n)
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for name,data in sorted(files.items()):
  item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;tf.addfile(item,io.BytesIO(data))
reopened=[];seen=set()
with tarfile.open(archive,'r:gz') as tf:
 for m in tf.getmembers():
  assert m.isfile() and m.name not in seen;seen.add(m.name);pp=PurePosixPath(m.name);assert not pp.is_absolute() and '..' not in pp.parts and not m.name.endswith(('.tar','.tar.gz','.tgz'));data=tf.extractfile(m).read();assert data==files[m.name] and len(data)==m.size;reopened.append({'path':m.name,'size':len(data),'sha256':sha(data)})
assert set(files)==seen
manifest={'schema':1,'archive_sha256':sha(archive.read_bytes()),'archive_size':archive.stat().st_size,'member_count':len(reopened),'members':reopened,'independent_reopen':'PASS'};(O/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k!='members'},indent=2));print('optional absent',missing)
