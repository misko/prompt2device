# Fresh pod schematic-to-placement result

MEASURED domain result: PLACEMENT PASS / ROUTING HANDOFF REQUIRED. One authorized normal continuation stopped at authenticated route import: `ERROR: route source is build but no build/FINAL marker exists — run route`. Import rc1/0.407s; conductor rc1/7.499s; bounded outer rc1/7.578001900s. No retry or router execution. Root owns final closure/commits.

Exact input canonical envelope: b404ab0350e7f58bb8ee5000670ab438c054565f322d8f67c2db5457e6227218. Frozen335/335, protected source/tool299/299, source checkpoint311/311, prelayout11/11 and schematic7/7 verified. Live initial compact handoff passed.

Schematic reviews2/2 and placement reviews4/4 passed current exact subjects. Component parity40/40 across all four sources; pin-map4multi-pin refs/38physical identities; feasibility7/7; model coverage32/32; model registration2/2; orientation machine1/1 and human1/1 reused existing approved images with no restamp. Pad-separation5224copper comparisons and7822paste comparisons passed. Land escape69/103copper pads with34no-floor exclusions passed. Tier advisory PF-LEGALIZE remains0.25mm versus0.8mm recommendation,0FAIL/1WARN. Connector SOURCE admitted, FULL9physical facts deferred under first-article decision. FIRST-ARTICLE-ONLY / DO-NOT-ORDER.

The normal driver promoted the reviewed schematic and generated the board from source. Prepared r0 contains86declared deterministic seed primitives; this is preparation only. Current native board contains0tracks/vias and2GND zones. The driver imported no copper. Physical service, routing, route taps/stitch, realized routing including C10.2GND return verification, final route acceptance, layout seal, fabrication, release, order, and physical qualification are NOT RUN in this attempt.

The compact outgoing handoff generator separately refused rc1/0.081s because existing `06_build/drc/gate.json` is older than regenerated inputs. No fresh compact handoff exists; old handoff and stale final gate retained byte-for-byte and with unchanged mtimes. No DRC gate deletion, touch, replacement or approval restamp. Fresh placement report is `06_build/drc/pre_route.json` with0violations/58unconnected/0parity. Every raw row and116endpoint occurrences are independently verified in native pcbnew by UUID, net and position. Full row multisets equal the retained older gate; this does not override the freshness refusal.

PCB SHA256: a44b769b1a5ad5fa959b476bd30f91a64aeaba9ad64d7868fa4e60ffbb62ee48

Component inventory SHA256 (40components, canonical JSON): 5aa98d4049ca3f6c8c82d1a74e706a2925d48c717c39ce544347ed330668ad39

Pin-object inventory SHA256 (109pads excluding4mount holes, canonical JSON): 0160e0e4ed70bb85a406a747dd5fef009dedf0a09b542293e03dff73639b3810

Placement DRC SHA256: 66ef05400e06a273b804f94f91d3c4cda85d3009fc3349faec1517bf97039cd5

Source/tool protected preimages remain299/299identical, entire input packet335/335unchanged. Final exclusive writer scope PASS with18changed allowed paths and0violations. Frozen handoff files and task ownership claim/attempt receipt were not edited. No child agents, source edits, stale copper import or commits.

Exact command/runtime, full raw output, preimages, generated subjects, receipts, native inventory and complete JSON classifications are in `evidence.tar.gz`. `evidence-manifest.json` records every regular member, size and SHA256 plus archive digest/size. Every archive member is independently reopened; no symlinks, duplicate paths, traversal or recursive archives are admitted. Delivery PASS is separate from the engineering handoff/blockers.

## Complete DRC classifications

Violations: none (0rows). Schematic parity: none (0nodes). Each row below is an error-severity `unconnected_items` finding. Each named same-net pad pair lacks connecting copper: exact native board has0tracks/vias and no zone for that net. Both endpoints exist with matching UUID, net and position. These are19specific unrouted nets, not diagnosed placement congestion. Resolution for every row belongs to fresh routing and is NOT RUN. Machine record retains the complete raw row and exact endpoints.

| Row | Net | Native endpoints | Cause |
|---|---|---|---|
| U001 | VREF | TP4.1 (24,51) ↔ U1.5 (55.025,50.27) | No track/via or VREF zone connects this pair. |
| U002 | VREF | U1.2 (55.025,46.46) ↔ U1.1 (55.025,45.19) | No track/via or VREF zone connects this pair. |
| U003 | VREF | U1.2 (55.025,46.46) ↔ U1.5 (55.025,50.27) | No track/via or VREF zone connects this pair. |
| U004 | VREF | U1.5 (55.025,50.27) ↔ U1.10 (59.975,50.27) | No track/via or VREF zone connects this pair. |
| U005 | VREF | U1.12 (59.975,47.73) ↔ U1.10 (59.975,50.27) | No track/via or VREF zone connects this pair. |
| U006 | VREF | U1.12 (59.975,47.73) ↔ R5.2 (64.5,42.49) | No track/via or VREF zone connects this pair. |
| U007 | VREF_RAW | R6.2 (46,44.49) ↔ R7.1 (46,48.51) | No track/via or VREF_RAW zone connects this pair. |
| U008 | VREF_RAW | R7.1 (46,48.51) ↔ C9.1 (49,47.45) | No track/via or VREF_RAW zone connects this pair. |
| U009 | VREF_RAW | U1.3 (55.025,47.73) ↔ C9.1 (49,47.45) | No track/via or VREF_RAW zone connects this pair. |
| U010 | 5V_QUIET | TP3.1 (24,47) ↔ C6.1 (32.48,47) | No track/via or 5V_QUIET zone connects this pair. |
| U011 | 5V_QUIET | C6.1 (32.48,47) ↔ U2.1 (34.025,47.15) | No track/via or 5V_QUIET zone connects this pair. |
| U012 | 5V_QUIET | C5.1 (32.6,49.5) ↔ C3.1 (34.12,49.2) | No track/via or 5V_QUIET zone connects this pair. |
| U013 | 5V_QUIET | U2.1 (34.025,47.15) ↔ C3.1 (34.12,49.2) | No track/via or 5V_QUIET zone connects this pair. |
| U014 | 5V_QUIET | R1.1 (36.2,50.51) ↔ C3.1 (34.12,49.2) | No track/via or 5V_QUIET zone connects this pair. |
| U015 | 5V_QUIET | R6.1 (46,45.51) ↔ R1.1 (36.2,50.51) | No track/via or 5V_QUIET zone connects this pair. |
| U016 | 5V_QUIET | C10.1 (53.08,49) ↔ R6.1 (46,45.51) | No track/via or 5V_QUIET zone connects this pair. |
| U017 | 5V_QUIET | U1.4 (55.025,49) ↔ C10.1 (53.08,49) | No track/via or 5V_QUIET zone connects this pair. |
| U018 | 5V_QUIET | U1.4 (55.025,49) ↔ C11.1 (58.05,41) | No track/via or 5V_QUIET zone connects this pair. |
| U019 | 5V_QUIET | R3.1 (63.0875,39) ↔ C11.1 (58.05,41) | No track/via or 5V_QUIET zone connects this pair. |
| U020 | PRE_FB | R8.2 (51,50.49) ↔ R9.2 (51,53.49) | No track/via or PRE_FB zone connects this pair. |
| U021 | PRE_FB | U1.6 (55.025,51.54) ↔ R8.2 (51,50.49) | No track/via or PRE_FB zone connects this pair. |
| U022 | PRE_OUT | R9.1 (51,54.51) ↔ U1.7 (55.025,52.81) | No track/via or PRE_OUT zone connects this pair. |
| U023 | PRE_OUT | R10.1 (64,51.51) ↔ U1.7 (55.025,52.81) | No track/via or PRE_OUT zone connects this pair. |
| U024 | PRE_OUT | R10.1 (64,51.51) ↔ R13.1 (61.0875,36) | No track/via or PRE_OUT zone connects this pair. |
| U025 | OUTP_DRV | R12.1 (56.0875,36) ↔ U1.8 (59.975,52.81) | No track/via or OUTP_DRV zone connects this pair. |
| U026 | OUTP_DRV | U1.8 (59.975,52.81) ↔ R11.1 (64,54.51) | No track/via or OUTP_DRV zone connects this pair. |
| U027 | OUTP_FB | R10.2 (64,50.49) ↔ U1.9 (59.975,51.54) | No track/via or OUTP_FB zone connects this pair. |
| U028 | OUTP_FB | R11.2 (64,53.49) ↔ R10.2 (64,50.49) | No track/via or OUTP_FB zone connects this pair. |
| U029 | SPARE_BUF | U1.14 (59.975,45.19) ↔ U1.13 (59.975,46.46) | No track/via or SPARE_BUF zone connects this pair. |
| U030 | LDO_FB | U2.2 (34.675,47.15) ↔ C3.2 (35.08,49.2) | No track/via or LDO_FB zone connects this pair. |
| U031 | LDO_FB | C3.2 (35.08,49.2) ↔ R1.2 (36.2,49.49) | No track/via or LDO_FB zone connects this pair. |
| U032 | LDO_FB | R2.1 (38,50.51) ↔ R1.2 (36.2,49.49) | No track/via or LDO_FB zone connects this pair. |
| U033 | AUDIO_N | U3.5 (48.3575,27.36) ↔ J1.4 (48.56,29.86) | No track/via or AUDIO_N zone connects this pair. |
| U034 | AUDIO_N | J1.4 (48.56,29.86) ↔ TP6.1 (62.9,32.5) | No track/via or AUDIO_N zone connects this pair. |
| U035 | AUDIO_N | R13.2 (62.9125,36) ↔ TP6.1 (62.9,32.5) | No track/via or AUDIO_N zone connects this pair. |
| U036 | VIN_PROTECTED | TP2.1 (24,43) ↔ R14.1 (28,47.4625) | No track/via or VIN_PROTECTED zone connects this pair. |
| U037 | VIN_PROTECTED | D2.1 (27.3,35.85) ↔ TP2.1 (24,43) | No track/via or VIN_PROTECTED zone connects this pair. |
| U038 | VIN_PROTECTED | C2.1 (32.48,44.2) ↔ C1.1 (31.5,42.675) | No track/via or VIN_PROTECTED zone connects this pair. |
| U039 | VIN_PROTECTED | C2.1 (32.48,44.2) ↔ U2.8 (34.025,42.85) | No track/via or VIN_PROTECTED zone connects this pair. |
| U040 | VIN_PROTECTED | C2.1 (32.48,44.2) ↔ R14.1 (28,47.4625) | No track/via or VIN_PROTECTED zone connects this pair. |
| U041 | VIN_PROTECTED | U2.8 (34.025,42.85) ↔ U2.5 (35.975,42.85) | No track/via or VIN_PROTECTED zone connects this pair. |
| U042 | VIN_PROTECTED | U2.5 (35.975,42.85) ↔ D1.1 (37.5,35.6) | No track/via or VIN_PROTECTED zone connects this pair. |
| U043 | AUDIO_P | J1.5 (49.58,25.86) ↔ U3.3 (49.7825,28.36) | No track/via or AUDIO_P zone connects this pair. |
| U044 | AUDIO_P | R12.2 (57.9125,36) ↔ TP5.1 (59.7,32.5) | No track/via or AUDIO_P zone connects this pair. |
| U045 | AUDIO_P | TP5.1 (59.7,32.5) ↔ U3.3 (49.7825,28.36) | No track/via or AUDIO_P zone connects this pair. |
| U046 | 12V_POD | TP1.1 (23.5,31) ↔ F1.1 (32.1,33.5) | No track/via or 12V_POD zone connects this pair. |
| U047 | 12V_POD | F1.1 (32.1,33.5) ↔ J1.1 (45.5,25.86) | No track/via or 12V_POD zone connects this pair. |
| U048 | 12V_POD | J1.3 (47.54,25.86) ↔ J1.1 (45.5,25.86) | No track/via or 12V_POD zone connects this pair. |
| U049 | 12V_POD | J1.7 (51.62,25.86) ↔ J1.3 (47.54,25.86) | No track/via or 12V_POD zone connects this pair. |
| U050 | POD_SHIELD | J1.10 (41.67,23.51) ↔ J1.9 (56.47,23.51) | No track/via or POD_SHIELD zone connects this pair. |
| U051 | LDO_NR | C4.1 (35.3,40.98) ↔ U2.6 (35.325,42.85) | No track/via or LDO_NR zone connects this pair. |
| U052 | MIC_BIAS | R3.2 (64.9125,39) ↔ R4.1 (69,40.01) | No track/via or MIC_BIAS zone connects this pair. |
| U053 | MIC_BIAS | C7.1 (67.525,34) ↔ R3.2 (64.9125,39) | No track/via or MIC_BIAS zone connects this pair. |
| U054 | MIC_AC | R5.1 (64.5,43.51) ↔ R8.1 (51,51.51) | No track/via or MIC_AC zone connects this pair. |
| U055 | MIC_AC | C8.2 (67.5,42.225) ↔ R5.1 (64.5,43.51) | No track/via or MIC_AC zone connects this pair. |
| U056 | MIC_RAW | C8.1 (67.5,43.775) ↔ MK1.1 (73,45) | No track/via or MIC_RAW zone connects this pair. |
| U057 | MIC_RAW | R4.2 (69,38.99) ↔ C8.1 (67.5,43.775) | No track/via or MIC_RAW zone connects this pair. |
| U058 | 12V_FUSED | F1.2 (34.9,33.5) ↔ D1.2 (41.5,35.6) | No track/via or 12V_FUSED zone connects this pair. |

C10.2 GND exists at(52.12,49)mm and is not an open placement row. That observation does not prove its routed return; the exact realized check remains owed.
